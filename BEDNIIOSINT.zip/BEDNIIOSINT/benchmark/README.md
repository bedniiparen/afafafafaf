# BEDNIIOSINT benchmark data

`ground_truth.json` is the search-quality dataset. Each case needs:

```json
{
  "target": "alice",
  "entity_type": "username",
  "expected": [
    "https://github.com/alice",
    "github:alice"
  ]
}
```

Use source-qualified keys such as `github:alice`, `crtsh:example.com` or
`gravatar:alice@example.com` whenever possible. They let the benchmark report
per-source recall, not only global precision/recall.

The committed seed set is built from public organization/project/domain/IP/URL
targets only. `ground_truth.json` contains confirmed exact `status=exists` hits;
`pairs.json` keeps both positives and negative/unknown variants for calibration;
`replay.json` is a compact offline fixture for deterministic CI quality gates.
Source-qualified URL keys are supported as `urlscan:https://www.python.org/`.

Validate without network:

```bash
python scripts/run_benchmark.py benchmark/ground_truth.json --validate-only --min-cases 3 --min-entity-types 3
```

Run a live quality gate:

```bash
python scripts/run_benchmark.py benchmark/ground_truth.json --min-precision 0.7 --min-recall 0.7 --min-f1 0.7
```

Collect raw payloads for review:

```bash
python -m scripts.collect_cases --targets benchmark/targets.json --out runtime/cases --max-results 60
```

Create review files and finalize ground truth:

```bash
python -m scripts.make_dataset scaffold-gt runtime/cases/username_alice.json --target alice --entity-type username --out benchmark/review/alice.json
python -m scripts.make_dataset finalize-gt benchmark/review/alice.json --out benchmark/ground_truth.json
python -m scripts.make_dataset scaffold-pairs runtime/cases/*.json --out benchmark/pairs.todo.json
```

Record and replay deterministic benchmark predictions:

```bash
python -m scripts.run_benchmark --dataset benchmark/ground_truth.json --record benchmark/replay.json
python -m scripts.run_benchmark --dataset benchmark/ground_truth.json --replay benchmark/replay.json --min-recall 0.7 --min-precision 0.7
```

Train pairwise LTR weights:

```bash
python -m scripts.train_ranker --rows benchmark/pairs.json --out eval/calibration.json
```

`pairs.json` is for confidence calibration. It accepts simple rows:

```json
{"confidence": 0.82, "label": 1}
```

or richer real-review rows:

```json
{
  "target": "alice",
  "source_id": "github",
  "prediction": {"confidence_score": 0.82},
  "is_match": true,
  "signals": {"status_exists": true, "control_passed": true}
}
```
