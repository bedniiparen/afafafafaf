#!/usr/bin/env python3
"""Sync the WhatsMyName dataset into bedniiosint/data/wmn-data.json.

Run where network access is available:
    python3 tools/sync_wmn.py
Optional custom destination:
    python3 tools/sync_wmn.py /path/to/wmn-data.json
"""
from __future__ import annotations

import json
import pathlib
import sys
import urllib.request

UPSTREAM = "https://raw.githubusercontent.com/WebBreacher/WhatsMyName/main/wmn-data.json"


def main() -> int:
    if len(sys.argv) > 1:
        dest = pathlib.Path(sys.argv[1])
    else:
        dest = pathlib.Path(__file__).resolve().parents[1] / "bedniiosint" / "data" / "wmn-data.json"
    req = urllib.request.Request(UPSTREAM, headers={"User-Agent": "BEDNIIOSINT-sync"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    sites = payload.get("sites") or []
    if not sites:
        print("upstream payload had no sites; aborting", file=sys.stderr)
        return 1
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    print("wrote", dest, "->", len(sites), "sites")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
