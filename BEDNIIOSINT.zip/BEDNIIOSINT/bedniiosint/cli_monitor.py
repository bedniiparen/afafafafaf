from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

monitor_app = typer.Typer(help="Monitoring and case-diff commands")
console = Console()


def _load_case_summary_arg(value: str) -> dict:
    path = Path(value)
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    from .core.case_summary import build_case_summary

    summary = build_case_summary(value)
    if not summary.get("meta", {}).get("found"):
        raise typer.BadParameter(f"case or JSON file not found: {value}")
    return summary


def _case_diff_payload(previous: str, current: str) -> dict:
    from .core.case_diff import diff_case_summaries

    return diff_case_summaries(
        _load_case_summary_arg(previous),
        _load_case_summary_arg(current),
    )


@monitor_app.command("diff")
def monitor_diff(
    previous: str = typer.Argument(..., help="Previous case name or summary JSON file"),
    current: str = typer.Argument(..., help="Current case name or summary JSON file"),
    json_out: bool = typer.Option(True, "--json/--table", help="Print JSON diff by default"),
):
    """Compare two runs as the monitoring diff primitive."""
    diff = _case_diff_payload(previous, current)
    if json_out:
        console.print(json.dumps(diff, indent=2, ensure_ascii=False, default=str))
        return
    table = Table(title="Case Diff")
    table.add_column("Metric")
    table.add_column("Count")
    for key, value in diff["summary"].items():
        table.add_row(str(key), str(value))
    console.print(table)


@monitor_app.command("add")
def monitor_add(
    target: str = typer.Argument(..., help="Target to monitor"),
    module: str = typer.Option("auto", "--module", help="Module or auto"),
    case_prefix: str | None = typer.Option(None, "--case-prefix"),
    interval_minutes: int = typer.Option(1440, "--interval-minutes", min=1),
    disabled: bool = typer.Option(False, "--disabled"),
):
    """Add or update a scheduled monitor."""
    from .core.monitoring import add_monitor_schedule

    result = add_monitor_schedule(
        target,
        module=module,
        case_prefix=case_prefix,
        interval_minutes=interval_minutes,
        enabled=not disabled,
    )
    console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


@monitor_app.command("list")
def monitor_list(
    json_out: bool = typer.Option(False, "--json/--table"),
):
    """List scheduled monitors and recent alerts."""
    from .core.monitoring import list_monitor_schedules

    payload = list_monitor_schedules()
    if json_out:
        console.print(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
        return
    table = Table(title="Monitor Schedules")
    table.add_column("ID")
    table.add_column("Enabled")
    table.add_column("Target")
    table.add_column("Module")
    table.add_column("Interval")
    table.add_column("Next run")
    table.add_column("Last case")
    for row in payload["schedules"]:
        table.add_row(
            str(row.get("id") or ""),
            "yes" if row.get("enabled") else "no",
            str(row.get("target") or ""),
            str(row.get("module") or ""),
            str(row.get("interval_minutes") or ""),
            str(row.get("next_run_at") or ""),
            str(row.get("last_case") or ""),
        )
    console.print(table)


@monitor_app.command("due")
def monitor_due(
    json_out: bool = typer.Option(False, "--json/--table"),
):
    """Show monitors due to run now."""
    from .core.monitoring import due_monitor_schedules

    payload = due_monitor_schedules()
    if json_out:
        console.print(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
        return
    table = Table(title="Due Monitor Schedules")
    table.add_column("ID")
    table.add_column("Target")
    table.add_column("Module")
    table.add_column("Next run")
    for row in payload["schedules"]:
        table.add_row(
            str(row.get("id") or ""),
            str(row.get("target") or ""),
            str(row.get("module") or ""),
            str(row.get("next_run_at") or ""),
        )
    console.print(table)


@monitor_app.command("run-due")
def monitor_run_due(
    max_runs: int | None = typer.Option(None, "--max-runs", min=1),
    dry_run: bool = typer.Option(False, "--dry-run"),
):
    """Run due monitors through the resumable job queue and record diffs."""
    from .core.monitoring import run_due_monitor_schedules

    payload = run_due_monitor_schedules(max_runs=max_runs, execute=not dry_run)
    console.print(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
