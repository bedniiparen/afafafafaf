"""Evaluation harness for BEDNIIOSINT search quality."""
