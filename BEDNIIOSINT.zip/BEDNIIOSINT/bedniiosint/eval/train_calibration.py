from __future__ import annotations

"""Train and evaluate the search confidence calibration model."""

import argparse
import json
import math
import random
from pathlib import Path
from typing import Any, Callable, Sequence

from bedniiosint.core.confidence_weights import DEFAULT_WEIGHTS
from bedniiosint.search.calibration import IsotonicCalibrator

try:
    from bedniiosint.eval.benchmark import _expected_key, _pred_keys
except Exception:  # pragma: no cover - keeps offline pair training usable
    _expected_key = None
    _pred_keys = None

Pair = tuple[float, int]
SIGNAL_FIELDS = tuple(DEFAULT_WEIGHTS)
SIGNAL_ALIASES = {
    "status_exists": ("status_exists", "status_is_exists"),
    "username_in_final_url": ("username_in_final_url",),
    "notfound_marker_absent": ("notfound_marker_absent",),
    "found_marker_present": ("found_marker_present",),
    "control_passed": ("control_passed",),
}


def collect_pairs_from_dataset(
    dataset: Sequence[dict[str, Any]],
    search_fn: Callable[[str, str], Sequence[Any]],
) -> list[Pair]:
    if _expected_key is None or _pred_keys is None:
        raise RuntimeError("benchmark matching helpers unavailable; use --pairs instead")
    pairs: list[Pair] = []
    for case in dataset:
        target = str(case.get("target") or "")
        entity_type = str(case.get("entity_type") or "username")
        expected = {_expected_key(item) for item in (case.get("expected") or []) if item}
        for pred in search_fn(target, entity_type):
            data = pred.as_dict() if hasattr(pred, "as_dict") else dict(pred)
            score = float(data.get("confidence_score") or data.get("confidence") or 0.0)
            label = 1 if (_pred_keys(pred) & expected) else 0
            pairs.append((score, label))
    return pairs


def load_pairs_file(path: str | Path) -> list[Pair]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    pairs: list[Pair] = []
    for row in raw:
        if not isinstance(row, dict):
            continue
        score = _score_from_row(row)
        label = _label_from_row(row)
        if score is None or label is None:
            continue
        pairs.append((score, 1 if label else 0))
    return pairs


def _nested_get(row: dict[str, Any], path: str) -> Any:
    current: Any = row
    for part in path.split("."):
        if not isinstance(current, dict):
            return None
        current = current.get(part)
    return current


def _score_from_row(row: dict[str, Any]) -> float | None:
    for key in (
        "confidence",
        "score",
        "raw_confidence",
        "prediction.confidence_score",
        "prediction.confidence",
        "result.confidence_score",
        "result.confidence",
    ):
        value = _nested_get(row, key) if "." in key else row.get(key)
        if value is None:
            continue
        try:
            return float(value)
        except (TypeError, ValueError):
            continue
    return None


def _label_from_row(row: dict[str, Any]) -> int | None:
    for key in ("label", "correct", "is_match", "matched", "positive"):
        if key in row:
            value = row.get(key)
            if isinstance(value, str):
                clean = value.strip().lower()
                if clean in {"1", "true", "yes", "match", "matched", "positive", "hit"}:
                    return 1
                if clean in {"0", "false", "no", "no_match", "negative", "miss"}:
                    return 0
            return 1 if value else 0
    return None


def validate_pairs_file(path: str | Path) -> list[str]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        return ["pairs file must be a JSON list"]
    errors: list[str] = []
    positives = negatives = usable = 0
    for index, row in enumerate(raw):
        if not isinstance(row, dict):
            errors.append(f"{index}: row must be an object")
            continue
        score = _score_from_row(row)
        label = _label_from_row(row)
        if score is None:
            errors.append(f"{index}: missing numeric confidence/score")
            continue
        if not 0.0 <= score <= 1.0:
            errors.append(f"{index}: confidence/score must be between 0 and 1")
            continue
        if label is None:
            errors.append(f"{index}: missing label/correct/is_match")
            continue
        positives += 1 if label else 0
        negatives += 0 if label else 1
        usable += 1
    if usable and (positives == 0 or negatives == 0):
        errors.append("pairs file must contain both positive and negative labels")
    return errors


def _signal_value(row: dict[str, Any], field: str) -> float | None:
    signals = row.get("signals")
    source = signals if isinstance(signals, dict) else row
    for key in SIGNAL_ALIASES[field]:
        if key in source:
            try:
                return 1.0 if bool(source.get(key)) else 0.0
            except Exception:
                return None
    return None


def collect_signal_rows(dataset: Sequence[dict[str, Any]]) -> list[tuple[dict[str, float], int]]:
    rows: list[tuple[dict[str, float], int]] = []
    for item in dataset:
        if not isinstance(item, dict):
            continue
        label = _label_from_row(item)
        if label is None:
            continue
        signals: dict[str, float] = {}
        for field in SIGNAL_FIELDS:
            value = _signal_value(item, field)
            if value is not None:
                signals[field] = value
        if signals:
            rows.append((signals, label))
    return rows


def _sigmoid(value: float) -> float:
    if value >= 40:
        return 1.0
    if value <= -40:
        return 0.0
    return 1.0 / (1.0 + math.exp(-value))


def train_signal_weights(
    signal_rows: Sequence[tuple[dict[str, float], int]],
    *,
    iterations: int = 900,
    learning_rate: float = 0.25,
    l2: float = 0.01,
) -> dict[str, float]:
    if not signal_rows:
        return dict(DEFAULT_WEIGHTS)
    labels = [label for _signals, label in signal_rows]
    if not any(labels) or all(labels):
        return dict(DEFAULT_WEIGHTS)

    coeffs = {field: 0.0 for field in SIGNAL_FIELDS}
    bias = 0.0
    n = float(len(signal_rows))
    for _ in range(iterations):
        grad = {field: 0.0 for field in SIGNAL_FIELDS}
        bias_grad = 0.0
        for signals, label in signal_rows:
            z = bias + sum(coeffs[field] * float(signals.get(field, 0.0)) for field in SIGNAL_FIELDS)
            err = _sigmoid(z) - label
            bias_grad += err
            for field in SIGNAL_FIELDS:
                grad[field] += err * float(signals.get(field, 0.0))
        bias -= learning_rate * (bias_grad / n)
        for field in SIGNAL_FIELDS:
            coeffs[field] -= learning_rate * ((grad[field] / n) + l2 * coeffs[field])

    positive = {field: max(0.0, coeffs[field]) for field in SIGNAL_FIELDS}
    total = sum(positive.values())
    if total <= 0:
        return dict(DEFAULT_WEIGHTS)
    return {field: round(positive[field] / total, 4) for field in SIGNAL_FIELDS}


def write_signal_weights(
    weights: dict[str, float],
    path: str | Path,
    *,
    rows: int,
) -> Path:
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(
            {
                "weights": weights,
                "meta": {
                    "rows": rows,
                    "method": "logistic_regression_gradient_descent_normalized_positive_coefficients",
                    "fields": list(SIGNAL_FIELDS),
                },
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    return out


def brier_score(probs: Sequence[float], labels: Sequence[int]) -> float:
    if not probs:
        return 0.0
    return sum((p - y) ** 2 for p, y in zip(probs, labels)) / len(probs)


def log_loss(probs: Sequence[float], labels: Sequence[int], eps: float = 1e-12) -> float:
    if not probs:
        return 0.0
    total = 0.0
    for prob, label in zip(probs, labels):
        prob = min(1.0 - eps, max(eps, prob))
        total += -(label * math.log(prob) + (1 - label) * math.log(1.0 - prob))
    return total / len(probs)


def reliability_table(
    probs: Sequence[float],
    labels: Sequence[int],
    bins: int = 10,
) -> list[dict[str, float | int | str]]:
    buckets: list[dict[str, float]] = [
        {"lo": i / bins, "hi": (i + 1) / bins, "count": 0, "sum_p": 0.0, "sum_y": 0.0}
        for i in range(bins)
    ]
    for prob, label in zip(probs, labels):
        idx = min(bins - 1, max(0, int(prob * bins)))
        buckets[idx]["count"] += 1
        buckets[idx]["sum_p"] += prob
        buckets[idx]["sum_y"] += label

    table: list[dict[str, float | int | str]] = []
    for bucket in buckets:
        count = int(bucket["count"])
        table.append(
            {
                "range": f"{bucket['lo']:.1f}-{bucket['hi']:.1f}",
                "count": count,
                "avg_pred": round(bucket["sum_p"] / count, 4) if count else 0.0,
                "actual": round(bucket["sum_y"] / count, 4) if count else 0.0,
            }
        )
    return table


def expected_calibration_error(
    probs: Sequence[float],
    labels: Sequence[int],
    bins: int = 10,
) -> float:
    n = len(probs)
    if not n:
        return 0.0
    ece = 0.0
    for row in reliability_table(probs, labels, bins):
        count = int(row["count"])
        if count:
            ece += (count / n) * abs(float(row["avg_pred"]) - float(row["actual"]))
    return round(ece, 4)


def cross_validate(pairs: list[Pair], folds: int = 5, seed: int = 13) -> dict[str, Any]:
    if len(pairs) < folds * 2:
        folds = max(2, len(pairs) // 2) if len(pairs) >= 4 else 0
    if folds < 2:
        return {"folds": 0, "note": "not enough data for cross-validation"}

    shuffled = list(pairs)
    random.Random(seed).shuffle(shuffled)
    chunks: list[list[Pair]] = [shuffled[i::folds] for i in range(folds)]
    raw_brier = raw_log_loss = raw_ece = 0.0
    cal_brier = cal_log_loss = cal_ece = 0.0

    for index in range(folds):
        test = chunks[index]
        train = [pair for chunk_index, chunk in enumerate(chunks) if chunk_index != index for pair in chunk]
        if not test or not train:
            continue

        model = IsotonicCalibrator().fit([score for score, _ in train], [label for _, label in train])
        test_scores = [score for score, _ in test]
        test_labels = [label for _, label in test]
        cal_scores = [model.predict(score) for score in test_scores]

        raw_brier += brier_score(test_scores, test_labels)
        raw_log_loss += log_loss(test_scores, test_labels)
        raw_ece += expected_calibration_error(test_scores, test_labels)
        cal_brier += brier_score(cal_scores, test_labels)
        cal_log_loss += log_loss(cal_scores, test_labels)
        cal_ece += expected_calibration_error(cal_scores, test_labels)

    return {
        "folds": folds,
        "raw": {
            "brier": round(raw_brier / folds, 4),
            "log_loss": round(raw_log_loss / folds, 4),
            "ece": round(raw_ece / folds, 4),
        },
        "calibrated": {
            "brier": round(cal_brier / folds, 4),
            "log_loss": round(cal_log_loss / folds, 4),
            "ece": round(cal_ece / folds, 4),
        },
    }


def _improvement(cv: dict[str, Any]) -> str:
    if not cv.get("folds"):
        return str(cv.get("note", "n/a"))

    raw = cv["raw"]
    calibrated = cv["calibrated"]

    def pct(before: float, after: float) -> str:
        if before <= 0:
            return "n/a"
        return f"{round((before - after) / before * 100, 1)}% better"

    return (
        f"Brier {raw['brier']} -> {calibrated['brier']} "
        f"({pct(raw['brier'], calibrated['brier'])}); "
        f"log-loss {raw['log_loss']} -> {calibrated['log_loss']} "
        f"({pct(raw['log_loss'], calibrated['log_loss'])}); "
        f"ECE {raw['ece']} -> {calibrated['ece']} ({pct(raw['ece'], calibrated['ece'])})"
    )


def default_search_fn(target: str, entity_type: str) -> Sequence[Any]:
    from bedniiosint.search.pipeline import run_planned_search_pipeline

    payload = run_planned_search_pipeline(target, entity_type=entity_type)
    return payload.get("search_results") or []


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Train the search confidence calibration model.")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--dataset", help="ground_truth.json; runs live search per target")
    source.add_argument("--pairs", help="pre-collected pairs.json [{confidence,label}]")
    parser.add_argument("--out", default="data/calibration.json", help="output model path")
    parser.add_argument(
        "--weights-out",
        default="eval/calibration.json",
        help="output confidence signal weights path",
    )
    parser.add_argument("--folds", type=int, default=5, help="cross-validation folds")
    parser.add_argument("--bins", type=int, default=10, help="reliability-table bins")
    parser.add_argument("--seed", type=int, default=13)
    parser.add_argument("--save-pairs", help="optional: dump collected pairs here for reuse")
    args = parser.parse_args(argv)

    signal_rows: list[tuple[dict[str, float], int]] = []
    if args.pairs:
        pair_errors = validate_pairs_file(args.pairs)
        if pair_errors:
            print("Invalid pairs file:")
            for error in pair_errors:
                print(f"  - {error}")
            return 2
        pairs = load_pairs_file(args.pairs)
        raw_rows = json.loads(Path(args.pairs).read_text(encoding="utf-8"))
        if isinstance(raw_rows, list):
            signal_rows = collect_signal_rows(raw_rows)
    else:
        dataset = json.loads(Path(args.dataset).read_text(encoding="utf-8"))
        print(f"Running search for {len(dataset)} labeled cases...")
        pairs = collect_pairs_from_dataset(dataset, default_search_fn)
        if isinstance(dataset, list):
            signal_rows = collect_signal_rows(dataset)

    if not pairs:
        print("No (score,label) pairs collected. Check your dataset/pairs file.")
        return 1

    positives = sum(1 for _, label in pairs if label)
    print(f"Collected {len(pairs)} pairs ({positives} positive / {len(pairs) - positives} negative).")
    if positives == 0 or positives == len(pairs):
        print("WARNING: need both positive and negative labels for a useful calibration.")

    if args.save_pairs:
        save_pairs_path = Path(args.save_pairs)
        save_pairs_path.parent.mkdir(parents=True, exist_ok=True)
        save_pairs_path.write_text(
            json.dumps([{"confidence": score, "label": label} for score, label in pairs], indent=2),
            encoding="utf-8",
        )
        print(f"Saved raw pairs to {save_pairs_path}")

    cv = cross_validate(pairs, folds=args.folds, seed=args.seed)
    print("\nCross-validation (honest, out-of-fold):")
    print("  " + _improvement(cv))

    model = IsotonicCalibrator().fit([score for score, _ in pairs], [label for _, label in pairs])
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    model.save(out_path)
    print(f"\nSaved calibration model -> {out_path}")

    if signal_rows:
        weights = train_signal_weights(signal_rows)
        weights_path = write_signal_weights(weights, args.weights_out, rows=len(signal_rows))
        print(f"Saved confidence weights -> {weights_path}")
    else:
        print("No labeled signal rows found; confidence weights remain defaults.")

    calibrated = [model.predict(score) for score, _ in pairs]
    labels = [label for _, label in pairs]
    print("\nReliability table (calibrated, full fit):")
    print("  range        count   avg_pred   actual")
    for row in reliability_table(calibrated, labels, args.bins):
        if row["count"]:
            print(f"  {row['range']:<11} {row['count']:>5}   {row['avg_pred']:>8}   {row['actual']:>6}")

    print("\nNext step:")
    print(f"  set BEDNIIOSINT_SEARCH_CALIBRATION_MODEL={out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
