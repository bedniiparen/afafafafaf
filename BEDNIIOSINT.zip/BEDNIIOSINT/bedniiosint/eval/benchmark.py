from __future__ import annotations

"""Precision / recall / F1 / MRR benchmark harness."""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Sequence

from ..search.canonicalize import canonical_url


def _looks_like_url(value: str) -> bool:
    clean = str(value or "").strip()
    return "://" in clean or (clean.count(".") >= 1 and "/" in clean)


def _source_qualified_url_key(value: str) -> str | None:
    clean = str(value or "").strip()
    if ":" not in clean:
        return None
    source, _, rest = clean.partition(":")
    source = source.strip().lower()
    rest = rest.strip()
    if not source or source in {"http", "https"} or not _looks_like_url(rest):
        return None
    url_key = canonical_url(rest)
    return f"{source}:{url_key}" if url_key else clean.lower()


def _pred_keys(pred: Any) -> set[str]:
    data = pred.as_dict() if hasattr(pred, "as_dict") else dict(pred)
    keys: set[str] = set()
    url = canonical_url(str(data.get("url") or ""))
    if url:
        keys.add(url)
    source_id = str(data.get("source_id") or "").strip().lower()
    matched = str(data.get("matched_entity") or data.get("entity_input") or "").strip().lower()
    if source_id:
        keys.add(source_id)
        if matched:
            keys.add(f"{source_id}:{matched}")
            matched_url = canonical_url(matched) if _looks_like_url(matched) else ""
            if matched_url:
                keys.add(f"{source_id}:{matched_url}")
            if source_id.startswith("api:"):
                keys.add(f"{source_id[4:]}:{matched}")
                if matched_url:
                    keys.add(f"{source_id[4:]}:{matched_url}")
            if ":" in source_id:
                keys.add(f"{source_id.rsplit(':', 1)[-1]}:{matched}")
                if matched_url:
                    keys.add(f"{source_id.rsplit(':', 1)[-1]}:{matched_url}")
    platform = str(data.get("detected_platform") or "").strip().lower()
    if platform and matched:
        keys.add(f"{platform}:{matched}")
        matched_url = canonical_url(matched) if _looks_like_url(matched) else ""
        if matched_url:
            keys.add(f"{platform}:{matched_url}")
    return {key for key in keys if key}


def _expected_key(item: str) -> str:
    clean = str(item or "").strip()
    source_url = _source_qualified_url_key(clean)
    if source_url:
        return source_url
    if "://" in clean or (clean.count(".") >= 1 and "/" in clean):
        return canonical_url(clean)
    return clean.lower()


def _source_token(value: str) -> str:
    clean = str(value or "").strip().lower()
    if not clean:
        return ""
    if ":" not in clean:
        return ""
    source = clean.split(":", 1)[0]
    if source in {"http", "https"}:
        return ""
    return source.removeprefix("api:")


def _source_aliases(pred: Any) -> set[str]:
    data = pred.as_dict() if hasattr(pred, "as_dict") else dict(pred)
    aliases: set[str] = set()
    raw = str(data.get("source_id") or "").strip().lower()
    platform = str(data.get("detected_platform") or "").strip().lower()
    for value in (raw, platform):
        if not value:
            continue
        aliases.add(value)
        if value.startswith("api:"):
            aliases.add(value[4:])
        if ":" in value:
            aliases.add(value.rsplit(":", 1)[-1])
    return aliases


def _case_key(raw: dict[str, Any]) -> str:
    return f"{str(raw.get('entity_type') or 'username').strip().lower()}:{str(raw.get('target') or '').strip().lower()}"


@dataclass
class BenchmarkDatasetIssue:
    level: str
    index: int | None
    field: str
    message: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "level": self.level,
            "index": self.index,
            "field": self.field,
            "message": self.message,
        }


@dataclass
class CaseMetrics:
    target: str
    expected: int
    retrieved: int
    true_positives: int
    reciprocal_rank: float
    precision: float
    recall: float
    f1: float


@dataclass
class BenchmarkReport:
    precision: float
    recall: float
    f1: float
    mrr: float
    cases: list[CaseMetrics] = field(default_factory=list)
    per_source: dict[str, dict[str, float]] = field(default_factory=dict)
    source_recall: dict[str, dict[str, float]] = field(default_factory=dict)
    dataset: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "precision": self.precision,
            "recall": self.recall,
            "f1": self.f1,
            "mrr": self.mrr,
            "cases": [vars(case) for case in self.cases],
            "per_source": self.per_source,
            "source_recall": self.source_recall,
            "dataset": self.dataset,
        }


def dataset_summary(dataset: Sequence[dict[str, Any]]) -> dict[str, Any]:
    entity_counts: dict[str, int] = {}
    expected_total = 0
    expected_by_source: dict[str, int] = {}
    for raw in dataset:
        entity_type = str(raw.get("entity_type") or "username").strip().lower()
        entity_counts[entity_type] = entity_counts.get(entity_type, 0) + 1
        expected = [item for item in (raw.get("expected") or []) if item]
        expected_total += len(expected)
        for item in expected:
            source = _source_token(_expected_key(str(item)))
            if source:
                expected_by_source[source] = expected_by_source.get(source, 0) + 1
    return {
        "cases": len(dataset),
        "entity_types": entity_counts,
        "entity_type_count": len(entity_counts),
        "expected": expected_total,
        "expected_by_source": dict(sorted(expected_by_source.items())),
    }


def validate_dataset(
    dataset: Sequence[dict[str, Any]],
    *,
    min_cases: int = 1,
    min_entity_types: int = 1,
) -> list[BenchmarkDatasetIssue]:
    issues: list[BenchmarkDatasetIssue] = []
    if len(dataset) < min_cases:
        issues.append(
            BenchmarkDatasetIssue(
                "error",
                None,
                "dataset",
                f"dataset has {len(dataset)} cases; expected at least {min_cases}",
            )
        )
    summary = dataset_summary(dataset)
    if int(summary["entity_type_count"]) < min_entity_types:
        issues.append(
            BenchmarkDatasetIssue(
                "error",
                None,
                "entity_type",
                f"dataset has {summary['entity_type_count']} entity types; expected at least {min_entity_types}",
            )
        )
    seen: set[str] = set()
    for index, raw in enumerate(dataset):
        if not isinstance(raw, dict):
            issues.append(BenchmarkDatasetIssue("error", index, "case", "case must be an object"))
            continue
        target = str(raw.get("target") or "").strip()
        entity_type = str(raw.get("entity_type") or "username").strip()
        expected = raw.get("expected")
        if not target:
            issues.append(BenchmarkDatasetIssue("error", index, "target", "target is required"))
        if not entity_type:
            issues.append(BenchmarkDatasetIssue("error", index, "entity_type", "entity_type is required"))
        if not isinstance(expected, list) or not expected:
            issues.append(
                BenchmarkDatasetIssue("error", index, "expected", "expected must be a non-empty list")
            )
        else:
            clean_expected = [_expected_key(str(item)) for item in expected if str(item or "").strip()]
            if len(clean_expected) != len(set(clean_expected)):
                issues.append(
                    BenchmarkDatasetIssue(
                        "warning",
                        index,
                        "expected",
                        "expected contains duplicate normalized keys",
                    )
                )
            if not any(_source_token(item) for item in clean_expected):
                issues.append(
                    BenchmarkDatasetIssue(
                        "warning",
                        index,
                        "expected",
                        "no source-qualified expected key like github:alice; per-source recall will be partial",
                    )
                )
        key = _case_key(raw)
        if key in seen:
            issues.append(
                BenchmarkDatasetIssue(
                    "warning",
                    index,
                    "target",
                    "duplicate target/entity_type pair",
                )
            )
        seen.add(key)
    return issues


def _prf(tp: int, retrieved: int, expected: int) -> tuple[float, float, float]:
    precision = tp / retrieved if retrieved else 0.0
    recall = tp / expected if expected else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
    return round(precision, 4), round(recall, 4), round(f1, 4)


def evaluate_case(target: str, expected: Sequence[str], predictions: Sequence[Any]) -> CaseMetrics:
    expected_keys = {_expected_key(item) for item in expected if item}
    ranked = list(predictions)
    matched: set[str] = set()
    reciprocal_rank = 0.0
    for index, pred in enumerate(ranked, start=1):
        hit = _pred_keys(pred) & expected_keys
        if hit:
            matched |= hit
            if reciprocal_rank == 0.0:
                reciprocal_rank = 1.0 / index
    tp = len(matched)
    precision, recall, f1 = _prf(tp, len(ranked), len(expected_keys))
    return CaseMetrics(
        target=target,
        expected=len(expected_keys),
        retrieved=len(ranked),
        true_positives=tp,
        reciprocal_rank=round(reciprocal_rank, 4),
        precision=precision,
        recall=recall,
        f1=f1,
    )


def run_benchmark(
    dataset: Sequence[dict[str, Any]],
    search_fn: Callable[[str, str], Sequence[Any]],
) -> BenchmarkReport:
    cases: list[CaseMetrics] = []
    agg_tp = 0
    agg_ret = 0
    agg_exp = 0
    rr_sum = 0.0
    source_tp: dict[str, int] = {}
    source_ret: dict[str, int] = {}
    expected_source_count: dict[str, int] = {}
    expected_source_hits: dict[str, int] = {}
    for raw in dataset:
        target = str(raw.get("target") or "")
        entity_type = str(raw.get("entity_type") or "username")
        expected = list(raw.get("expected") or [])
        predictions = list(search_fn(target, entity_type))
        metric = evaluate_case(target, expected, predictions)
        cases.append(metric)
        agg_tp += metric.true_positives
        agg_ret += metric.retrieved
        agg_exp += metric.expected
        rr_sum += metric.reciprocal_rank
        expected_keys = {_expected_key(item) for item in expected if item}
        for expected_key in expected_keys:
            expected_source = _source_token(expected_key)
            if expected_source:
                expected_source_count[expected_source] = expected_source_count.get(expected_source, 0) + 1
        for pred in predictions:
            data = pred.as_dict() if hasattr(pred, "as_dict") else dict(pred)
            source_id = str(data.get("source_id") or "unknown")
            source_ret[source_id] = source_ret.get(source_id, 0) + 1
            hit_keys = _pred_keys(pred) & expected_keys
            if hit_keys:
                source_tp[source_id] = source_tp.get(source_id, 0) + 1
                aliases = _source_aliases(pred)
                for hit_key in hit_keys:
                    expected_source = _source_token(hit_key)
                    if expected_source and (not aliases or expected_source in aliases):
                        expected_source_hits[expected_source] = (
                            expected_source_hits.get(expected_source, 0) + 1
                        )
    precision, recall, f1 = _prf(agg_tp, agg_ret, agg_exp)
    per_source: dict[str, dict[str, float]] = {}
    for source_id, retrieved in sorted(source_ret.items()):
        hits = source_tp.get(source_id, 0)
        per_source[source_id] = {
            "precision": round(hits / retrieved, 4) if retrieved else 0.0,
            "retrieved": retrieved,
            "hits": hits,
        }
    source_recall: dict[str, dict[str, float]] = {}
    for source_id, expected_count in sorted(expected_source_count.items()):
        hits = expected_source_hits.get(source_id, 0)
        source_recall[source_id] = {
            "recall": round(hits / expected_count, 4) if expected_count else 0.0,
            "expected": expected_count,
            "hits": hits,
        }
    return BenchmarkReport(
        precision=precision,
        recall=recall,
        f1=f1,
        mrr=round(rr_sum / len(cases), 4) if cases else 0.0,
        cases=cases,
        per_source=per_source,
        source_recall=source_recall,
        dataset=dataset_summary(dataset),
    )


def load_dataset(path: str | Path) -> list[dict[str, Any]]:
    return list(json.loads(Path(path).read_text(encoding="utf-8")))


def report_markdown(report: BenchmarkReport) -> str:
    lines = [
        "# BEDNIIOSINT search benchmark",
        "",
        f"- **Precision:** {report.precision}",
        f"- **Recall:** {report.recall}",
        f"- **F1:** {report.f1}",
        f"- **MRR:** {report.mrr}",
        f"- **Cases:** {report.dataset.get('cases', len(report.cases))}",
        f"- **Expected keys:** {report.dataset.get('expected', 0)}",
        "",
        "## Per-source precision",
        "",
        "| source | retrieved | hits | precision |",
        "| --- | --- | --- | --- |",
    ]
    for source_id, stats in report.per_source.items():
        lines.append(
            f"| {source_id} | {stats['retrieved']} | {stats['hits']} | {stats['precision']} |"
        )
    if report.source_recall:
        lines.extend(
            [
                "",
                "## Source recall",
                "",
                "| source | expected | hits | recall |",
                "| --- | --- | --- | --- |",
            ]
        )
        for source_id, stats in report.source_recall.items():
            lines.append(
                f"| {source_id} | {stats['expected']} | {stats['hits']} | {stats['recall']} |"
            )
    return "\n".join(lines)
