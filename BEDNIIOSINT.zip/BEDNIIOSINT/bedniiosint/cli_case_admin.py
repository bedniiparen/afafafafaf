from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console


console = Console()
case_admin_app = typer.Typer(add_completion=False, help="Case and evidence administration commands")


@case_admin_app.command("evidence-inspect")
def evidence_bundle_inspect(
    bundle: Path = typer.Argument(...),
    sign_key: str | None = typer.Option(None, "--sign-key"),
):
    """Inspect an evidence vault bundle and verify hashes/signature when possible."""
    from .evidence.bundle import inspect_evidence_bundle

    console.print(
        json.dumps(
            inspect_evidence_bundle(bundle, signing_key=sign_key),
            indent=2,
            ensure_ascii=False,
            default=str,
        )
    )


@case_admin_app.command("evidence-import")
def evidence_bundle_import(
    bundle: Path = typer.Argument(...),
    out_dir: Path = typer.Option(Path("imported_evidence"), "--out"),
):
    """Safely extract an evidence vault bundle archive."""
    from .evidence.bundle import import_evidence_bundle

    console.print(
        json.dumps(
            import_evidence_bundle(bundle, out_dir),
            indent=2,
            ensure_ascii=False,
            default=str,
        )
    )


@case_admin_app.command("merge")
def case_merge(
    target: str = typer.Argument(...),
    source: str = typer.Argument(...),
):
    """Merge all rows from one case database into another case."""
    from .core.case_admin import merge_cases

    console.print(json.dumps(merge_cases(target, source), indent=2, ensure_ascii=False, default=str))


@case_admin_app.command("archive")
def case_archive(
    case: str = typer.Argument(...),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """Write a ZIP archive containing a case DB and vault files."""
    from .core.case_admin import archive_case

    path = archive_case(case, out_dir)
    console.print(f"[dim]Case archive ->[/] {path}")


@case_admin_app.command("import")
def case_import(
    bundle: Path = typer.Argument(...),
    case: str | None = typer.Option(None, "--case"),
    overwrite: bool = typer.Option(False, "--overwrite"),
):
    """Import a case archive ZIP into the local cases directory."""
    from .core.case_admin import import_case_archive

    console.print(
        json.dumps(
            import_case_archive(bundle, case_name=case, overwrite=overwrite),
            indent=2,
            ensure_ascii=False,
            default=str,
        )
    )


@case_admin_app.command("schema-status")
def schema_status_cmd(case: str | None = typer.Option(None, "--case")):
    """Print storage schema version and applied migrations."""
    from .core.case_admin import schema_status

    console.print(json.dumps(schema_status(case), indent=2, ensure_ascii=False, default=str))


@case_admin_app.command("recheck")
def recheck(
    case: str = typer.Argument(..., help="Case name"),
    finding_id: int = typer.Argument(..., help="Finding id to re-check"),
):
    """Re-run a runnable registry-backed finding and persist the new evidence."""
    from .core.recheck import recheck_finding

    try:
        summary = recheck_finding(case, finding_id)
    except KeyError as exc:
        console.print(f"[red]{exc}[/]")
        raise typer.Exit(1) from exc
    console.print(json.dumps(summary, indent=2, ensure_ascii=False, default=str))
