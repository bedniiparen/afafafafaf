from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

api_keys_app = typer.Typer(help="API key setup and encrypted secret-store commands")
console = Console()


@api_keys_app.command("setup")
def api_key_setup(
    source: str | None = typer.Option(None, "--source", help="Filter by source id, e.g. api:shodan"),
    missing_only: bool = typer.Option(False, "--missing-only"),
    limit: int = typer.Option(50, "--limit", min=1),
):
    """Print API key setup hints for catalog sources."""
    from .catalog.health import source_health

    rows = source_health()
    if source:
        needle = source.lower().replace("api:", "")
        rows = [
            row
            for row in rows
            if row.source_id.lower() == source.lower()
            or row.source_id.lower().replace("api:", "") == needle
        ]
    if missing_only:
        rows = [row for row in rows if row.missing_env]

    table = Table(title="API Key Setup")
    table.add_column("Source")
    table.add_column("Priority")
    table.add_column("Risk")
    table.add_column("Env vars")
    table.add_column("Opt-in")
    table.add_column("Setup")
    table.add_column("Docs")
    shown = 0
    for row in rows:
        if not row.missing_env and not row.auth_required:
            continue
        table.add_row(
            row.source_id,
            row.priority or "",
            row.terms_risk,
            ", ".join(row.missing_env) if row.missing_env else "configured / optional",
            "yes" if row.requires_opt_in else "no",
            row.setup_hint,
            row.docs_url,
        )
        shown += 1
        if shown >= limit:
            break
    console.print(table)


@api_keys_app.command("template")
def api_key_template(
    source: str | None = typer.Option(None, "--source", help="Filter by source id, e.g. api:shodan"),
    missing_only: bool = typer.Option(False, "--missing-only", help="Include keys missing from current environment only"),
    required_only: bool = typer.Option(False, "--required-only", help="Exclude optional API keys"),
    out: Path | None = typer.Option(None, "--out", help="Write template to a file instead of stdout"),
    overwrite: bool = typer.Option(False, "--overwrite", help="Allow replacing an existing output file"),
):
    """Generate a safe .env template with blank API key values."""
    from .catalog.secrets import api_key_env_template, write_api_key_env_template

    if out is None:
        console.print(
            api_key_env_template(
                source=source,
                missing_only=missing_only,
                include_optional=not required_only,
            )
        )
        return
    try:
        path = write_api_key_env_template(
            out,
            source=source,
            missing_only=missing_only,
            include_optional=not required_only,
            overwrite=overwrite,
        )
    except FileExistsError as exc:
        console.print(f"[red]{exc}[/]")
        raise typer.Exit(1) from exc
    console.print(f"[dim]API key template ->[/] {path}")


@api_keys_app.command("store-set")
def api_key_store_set(
    name: str = typer.Argument(..., help="Environment variable name, e.g. SHODAN_API_KEY"),
    value: str = typer.Option(..., "--value", prompt=True, hide_input=True, help="Secret value"),
    overwrite: bool = typer.Option(True, "--overwrite/--no-overwrite"),
):
    """Store an API key in the encrypted local secret store."""
    from .core.secret_store import store_secret

    try:
        record = store_secret(name, value, overwrite=overwrite)
    except Exception as exc:
        console.print(f"[red]{exc}[/]")
        raise typer.Exit(1) from exc
    console.print(json.dumps(record, indent=2, ensure_ascii=False, default=str))


@api_keys_app.command("store-list")
def api_key_store_list():
    """List encrypted local secret names without revealing values."""
    from .core.secret_store import list_secrets

    table = Table(title="Encrypted API Key Store")
    table.add_column("Name")
    table.add_column("Backend")
    table.add_column("Created")
    table.add_column("Updated")
    for row in list_secrets():
        table.add_row(
            str(row["name"]),
            str(row["backend"]),
            str(row["created_at"]),
            str(row["updated_at"]),
        )
    console.print(table)


@api_keys_app.command("store-setup")
def api_key_store_setup(
    profile: str = typer.Option(
        "windows-cmd-user",
        "--profile",
        help="windows-cmd-session, windows-cmd-user, powershell-session, powershell-user, systemd-env, docker-env or env-file",
    ),
    out: Path | None = typer.Option(None, "--out", help="Write setup template to this file"),
    overwrite: bool = typer.Option(False, "--overwrite", help="Allow replacing an existing output file"),
    placeholder: str = typer.Option(
        "<set-a-long-passphrase>",
        "--placeholder",
        help="Placeholder text to include instead of a real passphrase",
    ),
    apply: bool = typer.Option(False, "--apply", help="Apply BEDNIIOSINT_SECRETS_KEY for supported profiles"),
    allow_secret_file: bool = typer.Option(
        False,
        "--allow-secret-file",
        help="Allow --apply to write plaintext secret deployment files for systemd/docker/env-file profiles",
    ),
    install_service: str | None = typer.Option(
        None,
        "--install-service",
        help="Install a systemd drop-in for this service when using --apply",
    ),
    system_service: bool = typer.Option(
        False,
        "--system-service",
        help="Install/reload a system-level systemd service instead of a user service",
    ),
    reload_service: bool = typer.Option(
        False,
        "--reload-service",
        help="Run systemctl daemon-reload after installing a systemd drop-in",
    ),
    restart_service: bool = typer.Option(
        False,
        "--restart-service",
        help="Run systemctl restart for the installed service",
    ),
    passphrase: str | None = typer.Option(
        None,
        "--passphrase",
        help="Passphrase to apply; if omitted with --apply, an interactive hidden prompt is used",
    ),
):
    """Generate or apply setup for BEDNIIOSINT_SECRETS_KEY."""
    from .core.secret_store import (
        apply_secret_store_setup,
        install_secret_store_systemd_dropin,
        secret_store_setup_template,
        write_secret_store_setup_template,
    )

    try:
        if apply:
            value = passphrase
            if value is None:
                value = typer.prompt(
                    "BEDNIIOSINT_SECRETS_KEY",
                    hide_input=True,
                    confirmation_prompt=True,
                )
            if install_service:
                if profile.strip().lower() != "systemd-env":
                    raise ValueError("--install-service requires --profile systemd-env")
                result = install_secret_store_systemd_dropin(
                    service=install_service,
                    passphrase=value,
                    user=not system_service,
                    overwrite=overwrite,
                    allow_secret_file=allow_secret_file,
                    reload_daemon=reload_service or restart_service,
                    restart_service=restart_service,
                )
                console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
                return
            result = apply_secret_store_setup(
                profile=profile,
                passphrase=value,
                out=out,
                overwrite=overwrite,
                allow_secret_file=allow_secret_file,
            )
            console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
            return
        if out is None:
            console.print(
                secret_store_setup_template(profile=profile, placeholder=placeholder),
                markup=False,
            )
            return
        path = write_secret_store_setup_template(
            out,
            profile=profile,
            placeholder=placeholder,
            overwrite=overwrite,
        )
    except Exception as exc:
        console.print(f"[red]{exc}[/]")
        raise typer.Exit(1) from exc
    console.print(f"[dim]Secret store setup template ->[/] {path}")


@api_keys_app.command("store-delete")
def api_key_store_delete(name: str = typer.Argument(...)):
    """Delete a key from the encrypted local secret store."""
    from .core.secret_store import delete_secret

    deleted = delete_secret(name)
    console.print(json.dumps({"name": name, "deleted": deleted}, indent=2))


@api_keys_app.command("store-audit")
def api_key_store_audit(
    json_out: bool = typer.Option(False, "--json", help="Print full JSON audit"),
):
    """Audit encrypted secret-store metadata without returning secret values."""
    from .core.secret_store import audit_secret_store

    result = audit_secret_store()
    if json_out:
        console.print(
            json.dumps(result, indent=2, ensure_ascii=False, default=str),
            markup=False,
            soft_wrap=True,
        )
        if not result["valid"]:
            raise typer.Exit(1)
        return
    summary = result["summary"]
    table = Table(
        title=(
            "Secret store audit: "
            f"{summary['records']} records, "
            f"{summary['rotation_required']} rotation required"
        )
    )
    table.add_column("Name")
    table.add_column("KDF")
    table.add_column("Iterations")
    table.add_column("Status")
    table.add_column("Auth")
    table.add_column("Rotate")
    for row in result["records"]:
        table.add_row(
            str(row.get("name") or ""),
            str(row.get("kdf") or ""),
            str(row.get("iterations") or ""),
            str(row.get("status") or ""),
            str(row.get("auth_status") or ""),
            "yes" if row.get("rotation_required") else "no",
        )
    console.print(table)
    for warning in result["warnings"]:
        console.print(f"[yellow]{warning}[/]")
    for error in result["errors"]:
        console.print(f"[red]{error}[/]")
    if not result["valid"]:
        raise typer.Exit(1)


@api_keys_app.command("store-rotate")
def api_key_store_rotate():
    """Re-encrypt stored API keys with the current KDF policy."""
    from .core.secret_store import rotate_secret_store

    try:
        result = rotate_secret_store()
    except Exception as exc:
        console.print(f"[red]{exc}[/]")
        raise typer.Exit(1) from exc
    console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
