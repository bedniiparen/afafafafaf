from __future__ import annotations

import json
import time

import typer
from rich.console import Console
from rich.table import Table

jobs_app = typer.Typer(help="Resumable scan job commands")
console = Console()


@jobs_app.command("create")
def job_create(
    target: str = typer.Argument(...),
    module: str = typer.Option("auto", "--module"),
    case: str | None = typer.Option(None, "--case"),
    max_retries: int = typer.Option(1, "--max-retries", min=0),
    rate_limit_budget: str | None = typer.Option(
        None, "--rate-limit-budget", help="JSON or source=limit pairs, e.g. *=2,GitHub=1"
    ),
    resume: bool = typer.Option(False, "--resume"),
):
    """Create a queued scan job."""
    from .core.jobs import create_job, job_as_dict

    job = create_job(
        target,
        module=module,
        case_name=case,
        max_retries=max_retries,
        rate_limit_budget=rate_limit_budget,
        resume=resume,
    )
    console.print(json.dumps(job_as_dict(job), indent=2, ensure_ascii=False, default=str))


@jobs_app.command("run")
def job_run(
    job_id: int = typer.Argument(...),
    max_retries: int | None = typer.Option(None, "--max-retries", min=0),
    resume: bool = typer.Option(False, "--resume"),
):
    """Run a queued scan job synchronously."""
    from .core.jobs import run_job

    result = run_job(job_id, max_retries=max_retries, resume=resume)
    console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


@jobs_app.command("list")
def job_list(limit: int = typer.Option(25, "--limit", min=1)):
    """List recent scan jobs."""
    from .core.jobs import job_as_dict, list_jobs

    table = Table(title="Jobs")
    table.add_column("ID")
    table.add_column("Case")
    table.add_column("Module")
    table.add_column("Target")
    table.add_column("Status")
    table.add_column("Progress")
    for job in list_jobs(limit):
        row = job_as_dict(job)
        table.add_row(
            str(row["id"]),
            str(row["case_name"]),
            str(row["module"]),
            str(row["target"]),
            str(row["status"]),
            f"{float(row['progress']):.2f}",
        )
    console.print(table)


@jobs_app.command("cancel")
def job_cancel(job_id: int = typer.Argument(...)):
    """Request cancellation for a queued/running scan job."""
    from .core.jobs import cancel_job, job_as_dict

    job = cancel_job(job_id)
    console.print(json.dumps(job_as_dict(job), indent=2, ensure_ascii=False, default=str))


@jobs_app.command("resume")
def job_resume(job_id: int = typer.Argument(...), run: bool = typer.Option(False, "--run")):
    """Queue a cancelled/partial job for resumable execution."""
    from .core.jobs import job_as_dict, resume_job, run_job

    job = resume_job(job_id)
    if run:
        console.print(json.dumps(run_job(job_id, resume=True), indent=2, ensure_ascii=False, default=str))
    else:
        console.print(json.dumps(job_as_dict(job), indent=2, ensure_ascii=False, default=str))


@jobs_app.command("events")
def job_events(job_id: int = typer.Argument(...)):
    """Print job/source progress events."""
    from .core.jobs import job_event_as_dict, list_job_events

    table = Table(title=f"Job {job_id} events")
    table.add_column("Time")
    table.add_column("Kind")
    table.add_column("Source")
    table.add_column("Status")
    table.add_column("Attempt")
    table.add_column("Progress")
    table.add_column("Message")
    for event in list_job_events(job_id):
        row = job_event_as_dict(event)
        table.add_row(
            str(row["created_at"]),
            str(row["kind"]),
            str(row["source"]),
            str(row["status"]),
            str(row["attempt"]),
            f"{float(row['progress']):.2f}",
            str(row["message"]),
        )
    console.print(table)


@jobs_app.command("worker-once")
def job_worker_once(
    stale_after: float = typer.Option(300.0, "--stale-after", min=0.0),
    no_recover_stale: bool = typer.Option(False, "--no-recover-stale"),
):
    """Run the next queued job, if any."""
    from .core.jobs import run_worker_once

    result = run_worker_once(
        recover_stale=not no_recover_stale,
        stale_after_seconds=stale_after,
    )
    console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


@jobs_app.command("worker-loop")
def job_worker_loop(
    poll_interval: float = typer.Option(1.0, "--poll-interval", min=0.05),
    stale_after: float = typer.Option(300.0, "--stale-after", min=0.0),
    limit: int | None = typer.Option(None, "--limit", min=1),
    idle_exit: bool = typer.Option(False, "--idle-exit"),
):
    """Run the job worker in the foreground."""
    from .core.jobs import run_worker_once

    ran = 0
    while limit is None or ran < limit:
        result = run_worker_once(stale_after_seconds=stale_after)
        if result is None:
            if idle_exit:
                break
            time.sleep(poll_interval)
            continue
        ran += 1
        console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


@jobs_app.command("recover-stale")
def job_recover_stale(
    stale_after: float = typer.Option(300.0, "--stale-after", min=0.0),
):
    """Requeue claimed/running jobs whose worker heartbeat is stale."""
    from .core.jobs import recover_stale_jobs

    result = recover_stale_jobs(stale_after_seconds=stale_after)
    console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


@jobs_app.command("worker-status")
def job_worker_status(stale_after: float = typer.Option(300.0, "--stale-after", min=0.0)):
    """Print in-process worker state."""
    from .core.jobs import worker_status

    console.print(
        json.dumps(
            worker_status(stale_after_seconds=stale_after),
            indent=2,
            ensure_ascii=False,
            default=str,
        )
    )
