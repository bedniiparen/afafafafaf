(function () {
  function qsa(selector) {
    return Array.from(document.querySelectorAll(selector));
  }

  function closestTarget(event, selector) {
    const target = event.target && event.target.nodeType === 1
      ? event.target
      : event.target && event.target.parentElement;
    return target ? target.closest(selector) : null;
  }

  function showWorkspaceTab(key, options) {
    const selected = String(key || '').trim();
    const panel = document.getElementById('tab-' + selected);
    if (!selected || !panel) return false;
    qsa('.tab-button').forEach(function (item) {
      const active = item.dataset.tab === selected;
      item.classList.toggle('active', active);
      item.setAttribute('aria-selected', String(active));
      item.setAttribute('tabindex', active ? '0' : '-1');
    });
    qsa('.tab-panel').forEach(function (item) {
      const active = item.id === 'tab-' + selected;
      item.classList.toggle('active', active);
    });
    if (!options || options.hash !== false) {
      const hash = '#tab-' + selected;
      if (window.location.hash !== hash) history.replaceState(null, '', hash);
    }
    document.dispatchEvent(new CustomEvent('bedniiosint:workspace-tab', {detail: {tab: selected}}));
    return true;
  }

  window.bedniiosintShowWorkspaceTab = showWorkspaceTab;

  document.addEventListener('click', function (event) {
    const button = closestTarget(event, '.tab-button,[data-open-tab]');
    if (!button) return;
    const key = button.dataset.tab || button.dataset.openTab;
    if (!key) return;
    event.preventDefault();
    showWorkspaceTab(key);
  }, true);

  window.addEventListener('hashchange', function () {
    const key = String(window.location.hash || '').replace(/^#tab-/, '');
    if (key) showWorkspaceTab(key, {hash: false});
  });

  document.addEventListener('DOMContentLoaded', function () {
    const key = String(window.location.hash || '').replace(/^#tab-/, '');
    if (key) showWorkspaceTab(key, {hash: false});
  });
})();
