﻿const graphData = JSON.parse(document.getElementById('graphData').textContent);
const canvas = document.getElementById('graphCanvas');
const ctx = canvas.getContext('2d');
const search = document.getElementById('graphSearch');
const typeFilter = document.getElementById('graphType');
const nodeInfo = document.getElementById('nodeInfo');
const nodeList = document.getElementById('nodeList');
const legend = document.getElementById('graphLegend');
const palette = ['#4D9EFF','#3DDC97','#F7C948','#FF5C7A','#B08CFF','#46D9D3','#FF9F43','#E6EDF7'];
const typeColor = new Map();
const nodes = graphData.nodes.map((row, index) => {
  const d = row.data || {};
  const type = d.type || 'unknown';
  if (!typeColor.has(type)) typeColor.set(type, palette[typeColor.size % palette.length]);
  const ring = Math.floor(index / 24);
  const angle = (Math.PI * 2 * index) / Math.max(1, graphData.nodes.length);
  return {...d, type, x: canvas.width / 2 + Math.cos(angle) * (190 + ring * 42), y: canvas.height / 2 + Math.sin(angle) * (150 + ring * 34), r: 15};
});
const nodeById = new Map(nodes.map(node => [node.id, node]));
const edges = graphData.edges.map(row => row.data || {}).filter(edge => nodeById.has(edge.source) && nodeById.has(edge.target));
let selected = nodes[0] || null;
let activeNodes = new Set(nodes.map(node => node.id));

function visibleNodes() {
  const q = search.value.trim().toLowerCase();
  const t = typeFilter.value;
  return nodes.filter(node => (!t || node.type === t) && (!q || String(node.label || node.id).toLowerCase().includes(q) || String(node.id).toLowerCase().includes(q)));
}
function rebuildActive() {
  activeNodes = new Set(visibleNodes().map(node => node.id));
  if (selected && !activeNodes.has(selected.id)) selected = [...activeNodes].map(id => nodeById.get(id))[0] || null;
  draw();
  renderList();
  renderInspector();
}
function neighbors(id) {
  const out = new Set([id]);
  edges.forEach(edge => {
    if (edge.source === id) out.add(edge.target);
    if (edge.target === id) out.add(edge.source);
  });
  return out;
}
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#0A1019';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  const highlight = selected ? neighbors(selected.id) : new Set();
  edges.forEach(edge => {
    if (!activeNodes.has(edge.source) || !activeNodes.has(edge.target)) return;
    const a = nodeById.get(edge.source), b = nodeById.get(edge.target);
    const strong = selected && highlight.has(edge.source) && highlight.has(edge.target);
    ctx.strokeStyle = strong ? '#86BFFF' : '#344259';
    ctx.lineWidth = strong ? 2.4 : 1.1;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  });
  nodes.forEach(node => {
    if (!activeNodes.has(node.id)) return;
    const strong = selected && highlight.has(node.id);
    ctx.globalAlpha = selected && !strong ? .28 : 1;
    ctx.fillStyle = typeColor.get(node.type);
    ctx.beginPath();
    ctx.arc(node.x, node.y, node === selected ? 20 : node.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = node === selected ? '#E6EDF7' : '#101722';
    ctx.lineWidth = node === selected ? 3 : 1.5;
    ctx.stroke();
    ctx.fillStyle = '#E6EDF7';
    ctx.font = '12px Segoe UI, Arial';
    const label = String(node.label || node.id).slice(0, 28);
    ctx.fillText(label, node.x + 23, node.y + 4);
    ctx.globalAlpha = 1;
  });
}
function renderInspector() {
  if (!selected) {
    nodeInfo.innerHTML = 'No nodes match the current filters.';
    return;
  }
  const connected = edges.filter(edge => edge.source === selected.id || edge.target === selected.id);
  nodeInfo.innerHTML = `<div class="kv"><div class="muted">Type</div><div>${escapeHtml(selected.type)}</div></div>
  <div class="kv"><div class="muted">Label</div><div>${escapeHtml(selected.label || selected.id)}</div></div>
  <div class="kv"><div class="muted">ID</div><div>${escapeHtml(selected.id)}</div></div>
  <div class="kv"><div class="muted">Links</div><div>${connected.length}</div></div>`;
}
function renderList() {
  nodeList.innerHTML = visibleNodes().slice(0, 80).map(node => `<li><button type="button" data-id="${escapeAttr(node.id)}">${escapeHtml(node.label || node.id)} <span class="muted">${escapeHtml(node.type)}</span></button></li>`).join('');
}
function renderLegend() {
  legend.innerHTML = [...typeColor.entries()].map(([type, color]) => `<span class="legend-item"><span class="legend-dot" style="background:${color}"></span>${escapeHtml(type)}</span>`).join('');
}
function hitNode(x, y) {
  return [...visibleNodes()].reverse().find(node => Math.hypot(node.x - x, node.y - y) <= 22) || null;
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function escapeAttr(value) { return escapeHtml(value).replace(/`/g, '&#96;'); }
canvas.addEventListener('click', event => {
  const rect = canvas.getBoundingClientRect();
  const node = hitNode((event.clientX - rect.left) * canvas.width / rect.width, (event.clientY - rect.top) * canvas.height / rect.height);
  if (node) { selected = node; draw(); renderInspector(); }
});
nodeList.addEventListener('click', event => {
  const button = event.target.closest('button[data-id]');
  if (!button) return;
  selected = nodeById.get(button.dataset.id);
  draw(); renderInspector();
});
search.addEventListener('input', rebuildActive);
typeFilter.addEventListener('change', rebuildActive);
document.getElementById('graphReset').addEventListener('click', () => {
  search.value = ''; typeFilter.value = ''; selected = nodes[0] || null; rebuildActive();
});
renderLegend(); rebuildActive();
