(() => {
  "use strict";

  const loadingPanel = document.getElementById("loadingPanel");
  const searchForm = document.getElementById("searchForm");
  const targetInput = document.getElementById("targetInput");
  const moduleInput = document.getElementById("moduleInput") || searchForm?.querySelector('input[name="module"]');
  const feelingButton = document.getElementById("feelingButton");
  const clearButton = document.getElementById("clearSearch") || document.querySelector(".clear");
  const loadingClose = document.getElementById("loadingClose");
  const loadingHide = document.getElementById("loadingHide");
  const loadingCancel = document.getElementById("loadingCancel");
  const loadingBar = document.getElementById("loadingBar");
  const progressTrack = document.getElementById("loadingTrack");
  const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || "";
  let currentJobId = null;
  let elapsedTimer = null;
  let startedAt = 0;

  if (!searchForm || !targetInput) return;

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const STATIC_PLACEHOLDER = "Search username, email, domain, IP, phone, URL...";
  const placeholderWords = [
    "username",
    "email",
    "domain",
    "IP address",
    "phone",
    "URL",
    "crypto wallet",
  ];
  const placeholderPrefix = "Search by ";
  const feelingExamples = [
    "torvalds",
    "example.com",
    "user@example.com",
    "8.8.8.8",
    "Acme Corp",
    "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
  ];

  function text(id, value) {
    const node = document.getElementById(id);
    if (node) node.textContent = value;
  }

  function syncClear() {
    if (clearButton) clearButton.hidden = !targetInput.value;
  }

  function startPlaceholderLoop() {
    if (reduceMotion) {
      targetInput.placeholder = STATIC_PLACEHOLDER;
      return;
    }

    let wordIndex = 0;
    let charIndex = 0;
    let deleting = false;
    let paused = 0;

    function tick() {
      if (document.activeElement === targetInput || targetInput.value) {
        targetInput.placeholder = STATIC_PLACEHOLDER;
        window.setTimeout(tick, 600);
        return;
      }
      if (paused > 0) {
        paused -= 1;
        window.setTimeout(tick, 60);
        return;
      }

      const word = placeholderWords[wordIndex];
      charIndex += deleting ? -1 : 1;
      targetInput.placeholder = placeholderPrefix + word.slice(0, charIndex) + "...";

      if (!deleting && charIndex === word.length) {
        deleting = true;
        paused = 18;
      } else if (deleting && charIndex === 0) {
        deleting = false;
        wordIndex = (wordIndex + 1) % placeholderWords.length;
      }
      window.setTimeout(tick, deleting ? 35 : 75);
    }

    tick();
  }

  document.querySelectorAll(".scope-chip").forEach((button) => {
    button.addEventListener("click", () => {
      const value = button.dataset.target || "";
      if (value) targetInput.value = value;
      targetInput.placeholder = button.dataset.placeholder || STATIC_PLACEHOLDER;
      syncClear();
      targetInput.focus();
    });
  });

  if (feelingButton) {
    feelingButton.addEventListener("click", () => {
      const value = feelingExamples[Math.floor(Math.random() * feelingExamples.length)];
      targetInput.value = value;
      syncClear();
      targetInput.focus();
    });
  }

  targetInput.addEventListener("input", syncClear);
  if (clearButton) {
    clearButton.addEventListener("click", () => {
      targetInput.value = "";
      targetInput.placeholder = STATIC_PLACEHOLDER;
      syncClear();
      targetInput.focus();
    });
  }

  document.addEventListener("keydown", (event) => {
    const tag = document.activeElement ? document.activeElement.tagName : "";
    const editing = ["INPUT", "TEXTAREA", "SELECT"].includes(tag);
    if (event.key === "/" && document.activeElement !== targetInput && !editing) {
      event.preventDefault();
      targetInput.focus();
    }
  });

  function addRipple(event) {
    const element = event.currentTarget;
    const rect = element.getBoundingClientRect();
    const size = Math.max(element.clientWidth, element.clientHeight);
    const ripple = document.createElement("span");
    ripple.className = "ripple";
    ripple.style.width = size + "px";
    ripple.style.height = size + "px";
    ripple.style.left = event.clientX - rect.left - size / 2 + "px";
    ripple.style.top = event.clientY - rect.top - size / 2 + "px";
    element.appendChild(ripple);
    window.setTimeout(() => ripple.remove(), 600);
  }

  if (!reduceMotion) {
    document.querySelectorAll(".home-action, .tile").forEach((element) => {
      element.addEventListener("click", addRipple);
    });
  }

  function setStep(id, state) {
    const node = document.getElementById(id);
    if (!node) return;
    node.className = `step ${state === "running" ? "running" : state === "failed" ? "failed" : state === "done" ? "done" : ""}`;
    const label = node.querySelector(".step-state");
    if (label) label.textContent = state;
  }

  function setLoadingMessage(message) {
    text("loadingMessage", message);
  }

  function setProgressBar(job) {
    if (!loadingBar || !progressTrack) return;
    const pct = Math.round(Number(job.progress || 0) * 100);
    if (job.status === "running" && pct <= 0) {
      progressTrack.classList.add("indeterminate");
      loadingBar.style.width = "";
    } else {
      progressTrack.classList.remove("indeterminate");
      loadingBar.style.width = Math.max(0, Math.min(100, pct)) + "%";
    }
  }

  function stopElapsed() {
    if (elapsedTimer) {
      window.clearInterval(elapsedTimer);
      elapsedTimer = null;
    }
  }

  function startElapsed() {
    startedAt = Date.now();
    stopElapsed();
    text("loadingElapsed", "0s");
    elapsedTimer = window.setInterval(() => {
      const secs = Math.floor((Date.now() - startedAt) / 1000);
      const mm = Math.floor(secs / 60);
      const ss = secs % 60;
      text("loadingElapsed", mm > 0 ? `${mm}m ${ss}s` : `${ss}s`);
    }, 1000);
  }

  function hideLoading() {
    stopElapsed();
    if (progressTrack) progressTrack.classList.remove("indeterminate");
    if (loadingPanel) loadingPanel.classList.remove("active");
  }

  async function cancelCurrentJob() {
    if (currentJobId == null) {
      hideLoading();
      return;
    }
    setLoadingMessage("Cancelling search...");
    try {
      await fetch(`/jobs/${encodeURIComponent(currentJobId)}/cancel`, {
        method: "POST",
        headers: {
          "Accept": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-csrf-token": csrfToken,
        },
      });
    } catch (error) {
      /* closing anyway */
    }
    hideLoading();
  }

  if (loadingClose) loadingClose.addEventListener("click", cancelCurrentJob);
  if (loadingCancel) loadingCancel.addEventListener("click", cancelCurrentJob);
  if (loadingHide) loadingHide.addEventListener("click", hideLoading);
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && loadingPanel && loadingPanel.classList.contains("active")) {
      hideLoading();
    }
  });

  function updateJob(job) {
    if (job.id != null) currentJobId = job.id;
    text("loadingJobId", job.id ?? "pending");
    text("loadingType", job.module || "auto");
    text("loadingProgress", Math.round(Number(job.progress || 0) * 100) + "%");
    text("loadingSource", job.current_source || job.status || "queued");
    setProgressBar(job);

    if (job.status === "queued" || job.status === "claimed") {
      setStep("stepSubmit", "done");
      setStep("stepRun", "pending");
      setStep("stepFinish", "pending");
      setLoadingMessage("Job is queued. Waiting for worker/background execution.");
    } else if (job.status === "running") {
      setStep("stepSubmit", "done");
      setStep("stepRun", "running");
      setStep("stepFinish", "pending");
      setLoadingMessage("Processing server-side workflow.");
    } else if (job.status === "finished") {
      setStep("stepSubmit", "done");
      setStep("stepRun", "done");
      setStep("stepFinish", "running");
      stopElapsed();
      if (progressTrack) progressTrack.classList.remove("indeterminate");
      setLoadingMessage("Job finished. Opening case workspace.");
    } else if (job.status === "failed" || job.status === "cancelled") {
      stopElapsed();
      if (progressTrack) progressTrack.classList.remove("indeterminate");
      setStep("stepRun", "failed");
      setStep("stepFinish", "pending");
      setLoadingMessage(job.error || `Job ${job.status}.`);
    }
  }

  async function pollJob(jobId) {
    for (;;) {
      const response = await fetch(`/jobs/${encodeURIComponent(jobId)}`, {
        headers: {"Accept": "application/json"},
      });
      if (!response.ok) throw new Error(await response.text());
      const job = await response.json();
      updateJob(job);
      if (job.status === "finished") {
        window.location.href = `/case/${encodeURIComponent(job.case_name)}`;
        return;
      }
      if (job.status === "failed" || job.status === "cancelled") return;
      await new Promise((resolve) => window.setTimeout(resolve, 1000));
    }
  }

  function parseEventData(event) {
    try {
      return JSON.parse(event.data);
    } catch {
      return {};
    }
  }

  function streamJob(jobId) {
    return new Promise((resolve, reject) => {
      if (!window.EventSource) {
        pollJob(jobId).then(resolve).catch(reject);
        return;
      }

      const stream = new EventSource(`/jobs/${encodeURIComponent(jobId)}/events/stream`);
      let settled = false;

      function finish() {
        if (settled) return;
        settled = true;
        stream.close();
        resolve();
      }

      function fail(error) {
        if (settled) return;
        settled = true;
        stream.close();
        reject(error);
      }

      function handleJob(job) {
        updateJob(job);
        if (job.status === "finished") {
          window.location.href = `/case/${encodeURIComponent(job.case_name)}`;
          finish();
        } else if (job.status === "failed" || job.status === "cancelled") {
          finish();
        }
      }

      stream.addEventListener("job", (event) => handleJob(parseEventData(event)));
      stream.addEventListener("done", (event) => {
        handleJob(parseEventData(event));
        finish();
      });
      stream.addEventListener("error", (event) => {
        if (event.data) {
          fail(new Error(parseEventData(event).detail || "Job stream failed."));
        }
      });
      stream.addEventListener("timeout", () => {
        fail(new Error("Job stream timed out."));
      });
      stream.onerror = () => {
        if (settled) return;
        stream.close();
        pollJob(jobId).then(resolve).catch(reject);
      };
    });
  }

  searchForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (moduleInput) moduleInput.value = "investigate";
    text("loadingTarget", targetInput.value || "pending");
    text("loadingJobId", "creating");
    setStep("stepSubmit", "running");
    setStep("stepRun", "pending");
    setStep("stepFinish", "pending");
    setLoadingMessage("Creating job.");
    currentJobId = null;
    if (loadingBar) loadingBar.style.width = "0%";
    if (progressTrack) progressTrack.classList.add("indeterminate");
    startElapsed();
    if (loadingPanel) loadingPanel.classList.add("active");

    try {
      const response = await fetch("/jobs", {
        method: "POST",
        headers: {"Accept": "application/json", "X-Requested-With": "XMLHttpRequest"},
        body: new URLSearchParams(new FormData(searchForm)),
      });
      if (!response.ok) throw new Error(await response.text());
      const job = await response.json();
      updateJob(job);
      await streamJob(job.id);
    } catch (error) {
      stopElapsed();
      if (progressTrack) progressTrack.classList.remove("indeterminate");
      setStep("stepSubmit", "failed");
      setLoadingMessage(error.message || "Job creation failed.");
    }
  });

  syncClear();
  startPlaceholderLoop();
})();
