(function () {
  const THEME_KEY = 'bedniiosint.theme';
  const LANG_KEY = 'bedniiosint.lang';
  const RU = {
    'Search': '\u041f\u043e\u0438\u0441\u043a',
    'History': '\u0418\u0441\u0442\u043e\u0440\u0438\u044f',
    'Monitoring': '\u041c\u043e\u043d\u0438\u0442\u043e\u0440\u0438\u043d\u0433',
    'Live Results': 'Live-\u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u044b',
    'Jobs': '\u0417\u0430\u0434\u0430\u0447\u0438',
    'Logout': '\u0412\u044b\u0439\u0442\u0438',
    'Open-source investigation workspace': '\u0420\u0430\u0431\u043e\u0447\u0435\u0435 \u043f\u0440\u043e\u0441\u0442\u0440\u0430\u043d\u0441\u0442\u0432\u043e OSINT-\u0440\u0430\u0441\u0441\u043b\u0435\u0434\u043e\u0432\u0430\u043d\u0438\u0439',
    'Search target': '\u0426\u0435\u043b\u044c \u043f\u043e\u0438\u0441\u043a\u0430',
    'Search username, email, domain, IP, phone, URL...': '\u0418\u0441\u043a\u0430\u0442\u044c username, email, \u0434\u043e\u043c\u0435\u043d, IP, \u0442\u0435\u043b\u0435\u0444\u043e\u043d, URL...',
    'Start investigation': '\u041d\u0430\u0447\u0430\u0442\u044c \u0440\u0430\u0441\u0441\u043b\u0435\u0434\u043e\u0432\u0430\u043d\u0438\u0435',
    'Sample target': '\u041f\u0440\u0438\u043c\u0435\u0440 \u0446\u0435\u043b\u0438',
    'No recent cases': '\u041d\u0435\u0442 \u043d\u0435\u0434\u0430\u0432\u043d\u0438\u0445 \u043a\u0435\u0439\u0441\u043e\u0432',
    'Investigation job': '\u0417\u0430\u0434\u0430\u0447\u0430 \u0440\u0430\u0441\u0441\u043b\u0435\u0434\u043e\u0432\u0430\u043d\u0438\u044f',
    'Target': '\u0426\u0435\u043b\u044c',
    'Data type': '\u0422\u0438\u043f \u0434\u0430\u043d\u043d\u044b\u0445',
    'Job id': 'ID \u0437\u0430\u0434\u0430\u0447\u0438',
    'Progress': '\u041f\u0440\u043e\u0433\u0440\u0435\u0441\u0441',
    'Elapsed': '\u041f\u0440\u043e\u0448\u043b\u043e',
    'Current source': '\u0422\u0435\u043a\u0443\u0449\u0438\u0439 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a',
    'Hide and keep running': '\u0421\u0432\u0435\u0440\u043d\u0443\u0442\u044c, \u043f\u043e\u0438\u0441\u043a \u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u0441\u044f',
    'Cancel search': '\u041e\u0442\u043c\u0435\u043d\u0438\u0442\u044c \u043f\u043e\u0438\u0441\u043a',
    'Cancelling search...': '\u041e\u0442\u043c\u0435\u043d\u0430 \u043f\u043e\u0438\u0441\u043a\u0430...',
    'Submitting target to the job queue': '\u041e\u0442\u043f\u0440\u0430\u0432\u043a\u0430 \u0446\u0435\u043b\u0438 \u0432 \u043e\u0447\u0435\u0440\u0435\u0434\u044c',
    'Processing sources and modules': '\u041e\u0431\u0440\u0430\u0431\u043e\u0442\u043a\u0430 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u043e\u0432 \u0438 \u043c\u043e\u0434\u0443\u043b\u0435\u0439',
    'Opening case workspace': '\u041e\u0442\u043a\u0440\u044b\u0442\u0438\u0435 \u043a\u0435\u0439\u0441\u0430',
    'Waiting for server response.': '\u041e\u0436\u0438\u0434\u0430\u043d\u0438\u0435 \u043e\u0442\u0432\u0435\u0442\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0430.',
    'Theme': '\u0422\u0435\u043c\u0430',
    'Light': '\u0421\u0432\u0435\u0442\u043b\u0430\u044f',
    'Dark': '\u0422\u0435\u043c\u043d\u0430\u044f',
    'Midnight': '\u041f\u043e\u043b\u043d\u043e\u0447\u044c',
    'Ocean': '\u041e\u043a\u0435\u0430\u043d',
    'Forest': '\u041b\u0435\u0441',
    'Sunset': '\u0417\u0430\u043a\u0430\u0442',
    'Mono': '\u041c\u043e\u043d\u043e',
    'Overview': '\u041e\u0431\u0437\u043e\u0440',
    'Profiles': '\u041f\u0440\u043e\u0444\u0438\u043b\u0438',
    'Emails': 'Email',
    'Phones': '\u0422\u0435\u043b\u0435\u0444\u043e\u043d\u044b',
    'Domains': '\u0414\u043e\u043c\u0435\u043d\u044b',
    'Mentions': '\u0423\u043f\u043e\u043c\u0438\u043d\u0430\u043d\u0438\u044f',
    'Sources': '\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u0438',
    'Evidence': '\u0414\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044c\u0441\u0442\u0432\u0430',
    'Graph': '\u0413\u0440\u0430\u0444',
    'Exports': '\u042d\u043a\u0441\u043f\u043e\u0440\u0442',
    'Priority Leads': '\u041f\u0440\u0438\u043e\u0440\u0438\u0442\u0435\u0442\u043d\u044b\u0435 \u0437\u0430\u0446\u0435\u043f\u043a\u0438',
    'Cases': '\u041a\u0435\u0439\u0441\u044b',
    'Details': '\u0414\u0435\u0442\u0430\u043b\u0438',
    'Clear': '\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c',
    'Platform': '\u041f\u043b\u0430\u0442\u0444\u043e\u0440\u043c\u0430',
    'Handle': '\u041d\u0438\u043a',
    'Profile': '\u041f\u0440\u043e\u0444\u0438\u043b\u044c',
    'Status': '\u0421\u0442\u0430\u0442\u0443\u0441',
    'Verification': '\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430',
    'Confidence': '\u0423\u0432\u0435\u0440\u0435\u043d\u043d\u043e\u0441\u0442\u044c',
    'Source': '\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a',
    'Seen': '\u0417\u0430\u043c\u0435\u0447\u0435\u043d\u043e',
    'Actions': '\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044f',
    'All': '\u0412\u0441\u0435',
    'Candidate': '\u041a\u0430\u043d\u0434\u0438\u0434\u0430\u0442',
    'Category': '\u041a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u044f',
    'search current table': '\u043f\u043e\u0438\u0441\u043a \u043f\u043e \u0442\u0430\u0431\u043b\u0438\u0446\u0435',
    'Confidence is scored from source signals (handle/URL match, DNS, registries, corroborating sources and preserved evidence) - not guesswork. Hover the Confidence badge to see why. Social links (VK, Telegram, Instagram, YouTube) are listed first.': '\u0423\u0432\u0435\u0440\u0435\u043d\u043d\u043e\u0441\u0442\u044c \u0441\u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044f \u043f\u043e \u0441\u0438\u0433\u043d\u0430\u043b\u0430\u043c \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u043e\u0432 (\u0441\u043e\u0432\u043f\u0430\u0434\u0435\u043d\u0438\u0435 \u043d\u0438\u043a\u0430/URL, DNS, \u0440\u0435\u0435\u0441\u0442\u0440\u044b, \u043f\u043e\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044e\u0449\u0438\u0435 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u0438 \u0438 \u0434\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044c\u0441\u0442\u0432\u0430), \u0430 \u043d\u0435 \u00ab\u043d\u0430 \u0433\u043b\u0430\u0437\u00bb. \u041d\u0430\u0432\u0435\u0434\u0438\u0442\u0435 \u043d\u0430 \u0431\u0435\u0439\u0434\u0436 Confidence, \u0447\u0442\u043e\u0431\u044b \u0443\u0432\u0438\u0434\u0435\u0442\u044c \u043f\u0440\u0438\u0447\u0438\u043d\u044b. \u0421\u0441\u044b\u043b\u043a\u0438 \u043d\u0430 \u0441\u043e\u0446\u0441\u0435\u0442\u0438 (VK, Telegram, Instagram, YouTube) \u043f\u043e\u043a\u0430\u0437\u0430\u043d\u044b \u043f\u0435\u0440\u0432\u044b\u043c\u0438.'
  };
  const EN = Object.fromEntries(Object.entries(RU).map(([key, value]) => [value, key]));
  const SKIP_SELECTOR = 'script,style,pre,code,textarea,tbody,.case-nav,.query-link,.summary-list,.cluster-list,#drawerContent,#manifestPreview,#integrityPreview,#timelineStream,#graphNodeList,.node-list,canvas';

  const THEMES = ['dark', 'light', 'midnight', 'ocean', 'forest', 'sunset', 'mono'];
  const THEME_LABELS = {
    dark: 'Dark',
    light: 'Light',
    midnight: 'Midnight',
    ocean: 'Ocean',
    forest: 'Forest',
    sunset: 'Sunset',
    mono: 'Mono'
  };

  function storedTheme() {
    const value = localStorage.getItem(THEME_KEY);
    if (THEMES.includes(value)) return value;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }

  function applyTheme(theme) {
    const selected = THEMES.includes(theme) ? theme : 'dark';
    const label = THEME_LABELS[selected] || 'Theme';
    const displayLabel = lang() === 'ru' ? (RU[label] || label) : label;
    document.documentElement.dataset.theme = selected;
    document.querySelectorAll('[data-theme-current]').forEach(node => { node.textContent = displayLabel; });
    document.querySelectorAll('[data-theme-menu-toggle]').forEach(button => {
      button.setAttribute('aria-pressed', selected !== 'dark' ? 'true' : 'false');
      button.title = 'Theme: ' + displayLabel;
    });
    document.querySelectorAll('[data-theme-toggle]').forEach(button => {
      button.classList.toggle('active', true);
      button.setAttribute('aria-pressed', selected !== 'dark' ? 'true' : 'false');
      button.textContent = displayLabel;
      button.title = 'Theme: ' + displayLabel + ' (click for next)';
    });
    document.querySelectorAll('[data-theme-select]').forEach(item => {
      item.classList.toggle('active', item.dataset.themeSelect === selected);
      item.setAttribute('aria-checked', String(item.dataset.themeSelect === selected));
    });
  }

  function buildThemeMenu() {
    const menu = document.getElementById('themeMenu');
    if (!menu) return;
    const cur = lang();
    menu.innerHTML = THEMES.map(t => {
      const name = cur === 'ru' ? (RU[THEME_LABELS[t]] || THEME_LABELS[t]) : THEME_LABELS[t];
      return `<button class="theme-option" type="button" role="menuitemradio" data-theme-select="${t}">`
        + `<span class="theme-swatch theme-swatch-${t}"></span><span>${name}</span></button>`;
    }).join('');
    menu.querySelectorAll('[data-theme-select]').forEach(item => {
      item.addEventListener('click', () => {
        const next = item.dataset.themeSelect;
        localStorage.setItem(THEME_KEY, next);
        applyTheme(next);
        closeThemeMenu();
      });
    });
  }

  function openThemeMenu() {
    const menu = document.getElementById('themeMenu');
    if (!menu) return;
    buildThemeMenu();
    applyTheme(storedTheme());
    menu.hidden = false;
    document.querySelectorAll('[data-theme-menu-toggle]').forEach(button => button.setAttribute('aria-expanded', 'true'));
  }

  function closeThemeMenu() {
    const menu = document.getElementById('themeMenu');
    if (menu) menu.hidden = true;
    document.querySelectorAll('[data-theme-menu-toggle]').forEach(button => button.setAttribute('aria-expanded', 'false'));
  }

  function toggleThemeMenu() {
    const menu = document.getElementById('themeMenu');
    if (!menu) {
      toggleTheme();
      return;
    }
    if (menu.hidden) openThemeMenu();
    else closeThemeMenu();
  }

  function toggleTheme() {
    const current = document.documentElement.dataset.theme || 'dark';
    const index = THEMES.indexOf(current);
    const next = THEMES[(index + 1) % THEMES.length];
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
  }

  function cookieLang() {
    const match = document.cookie.match(/(?:^|; )bedniiosint_lang=(en|ru)(?:;|$)/);
    return match ? match[1] : null;
  }

  function lang() {
    const stored = localStorage.getItem(LANG_KEY);
    if (stored === 'ru' || stored === 'en') return stored;
    return cookieLang() === 'ru' ? 'ru' : 'en';
  }

  function dictFor(targetLang) {
    return targetLang === 'ru' ? RU : EN;
  }

  function translateString(value, dict) {
    const clean = String(value || '').trim();
    return dict[clean] || null;
  }

  function translateTextNode(node, dict) {
    const parent = node.parentElement;
    if (!parent || parent.closest(SKIP_SELECTOR)) return;
    const translated = translateString(node.nodeValue, dict);
    if (!translated) return;
    node.nodeValue = node.nodeValue.replace(node.nodeValue.trim(), translated);
  }

  function translateAttributes(root, dict) {
    root.querySelectorAll('[placeholder],[aria-label],title').forEach(node => {
      ['placeholder', 'aria-label', 'title'].forEach(attr => {
        if (!node.hasAttribute(attr)) return;
        const translated = translateString(node.getAttribute(attr), dict);
        if (translated) node.setAttribute(attr, translated);
      });
    });
  }

  function translateTree(root, targetLang) {
    const dict = dictFor(targetLang);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => translateTextNode(node, dict));
    translateAttributes(root, dict);
    document.documentElement.lang = targetLang;
    document.querySelectorAll('[data-lang-option]').forEach(button => {
      button.classList.toggle('active', button.dataset.langOption === targetLang);
      button.setAttribute('aria-pressed', String(button.dataset.langOption === targetLang));
    });
  }

  function setLang(targetLang) {
    const selected = targetLang === 'ru' ? 'ru' : 'en';
    localStorage.setItem(LANG_KEY, selected);
    document.cookie = `bedniiosint_lang=${selected};path=/;max-age=31536000;samesite=lax`;
    translateTree(document.body, selected);
    buildThemeMenu();
    applyTheme(storedTheme());
    if (window.bedniiosintRerender) window.bedniiosintRerender();
  }

  applyTheme(storedTheme());
  window.bedniiosintSetLang = setLang;
  window.bedniiosintApplyLang = function () { translateTree(document.body, lang()); };

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-theme-menu-toggle]').forEach(button => {
      button.addEventListener('click', event => { event.stopPropagation(); toggleThemeMenu(); });
    });
    document.querySelectorAll('[data-theme-toggle]').forEach(button => {
      button.addEventListener('click', toggleTheme);
    });
    document.addEventListener('click', () => closeThemeMenu());
    document.addEventListener('keydown', event => { if (event.key === 'Escape') closeThemeMenu(); });
    applyTheme(storedTheme());
    document.querySelectorAll('[data-lang-option]').forEach(button => {
      button.addEventListener('click', () => setLang(button.dataset.langOption));
    });
    window.bedniiosintApplyLang();
    const observer = new MutationObserver(records => {
      if (lang() !== 'ru') return;
      records.forEach(record => {
        record.addedNodes.forEach(node => {
          if (node.nodeType === Node.ELEMENT_NODE) translateTree(node, 'ru');
          if (node.nodeType === Node.TEXT_NODE) translateTextNode(node, RU);
        });
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });
})();
