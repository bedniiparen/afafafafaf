﻿const CASE_NAME = JSON.parse(document.getElementById('caseNameData').textContent);
const PAGE_SIZE = 100;
const state = {
  workspace: null,
  findingPage: 1,
  sourcePage: 1,
  evidencePage: 1,
  tableState: {},
  tableRows: {},
  rawSection: '',
  editingRelationId: null,
  selectedNode: null,
  graphPositions: new Map(),
  graphView: {x: 0, y: 0, scale: 1},
  graphDrag: null,
  graphNeedsLayout: true,
  graphLastKey: '',
  graphVisibleNodeIds: new Set(),
  graphData: {nodes: [], edges: []},
  graphHitNodes: [],
  graphFrame: 0,
  graphResizeFrame: 0,
  denseRows: false,
  graphLayoutMode: 'radial',
};
const el = id => document.getElementById(id);
const qsa = selector => Array.from(document.querySelectorAll(selector));
const WS_RU = {
  found: '\u043d\u0430\u0439\u0434\u0435\u043d\u043e',
  candidate: '\u043a\u0430\u043d\u0434\u0438\u0434\u0430\u0442',
  unknown: '\u043d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u043e',
  unavailable: '\u043d\u0435\u0442 \u0434\u0430\u043d\u043d\u044b\u0445',
  blocked: '\u0437\u0430\u0431\u043b\u043e\u043a\u0438\u0440\u043e\u0432\u0430\u043d\u043e',
  rejected: '\u043e\u0442\u043a\u043b\u043e\u043d\u0435\u043d\u043e',
  error: '\u043e\u0448\u0438\u0431\u043a\u0430',
  exists: '\u0435\u0441\u0442\u044c'
};
const PRIORITY_PLATFORMS = ['vk', 'telegram', 'instagram', 'youtube'];
function closestTarget(event, selector) {
  const target = event.target && event.target.nodeType === 1
    ? event.target
    : event.target && event.target.parentElement;
  return target ? target.closest(selector) : null;
}
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function attr(value) { return esc(value).replace(/`/g, '&#96;'); }
function textOf(row) { return JSON.stringify(row ?? {}).toLowerCase(); }
function wtr(value) {
  if (document.documentElement.lang !== 'ru') return value;
  return WS_RU[String(value || '').toLowerCase()] || value;
}
function pct(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.round(n * 100) + '%' : '';
}
function confidenceClass(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return 'low';
  return n >= .8 ? 'high' : n >= .45 ? 'mid' : 'low';
}
function confidenceBadge(row) {
  const n = Number(row.confidence);
  const label = Number.isFinite(n) && n > 0 ? pct(n) : '0%';
  const reason = n > 0 ? '' : (row.reject_reason || row.reason || row.status || 'no confidence signal');
  return `<span class="confidence ${confidenceClass(n)}">${label}</span>${reason ? `<div class="muted small">${esc(reason)}</div>` : ''}`;
}
function statusBadge(row) {
  const status = row.rejected ? 'rejected' : (row.status || 'unknown');
  const cls = status === 'exists' ? 'status-active' : status === 'rejected' ? 'status-empty' : '';
  return `<span class="case-badge ${cls}">${esc(status)}</span>`;
}
function verdictBadge(row) {
  const verdict = row.verdict || row.display?.verdict || (row.rejected ? 'Rejected' : 'Weak');
  const cls = verdict === 'Confirmed' ? 'verdict-confirmed' : verdict === 'Likely' ? 'verdict-likely' : verdict === 'Rejected' ? 'verdict-rejected' : 'verdict-weak';
  return `<span class="verdict-pill ${cls}">${esc(verdict)}</span>`;
}
function listHtml(items, empty = 'No data yet.') {
  const rows = (items || []).filter(Boolean);
  return rows.length ? `<ul class="summary-list">${rows.map(item => `<li>${esc(item)}</li>`).join('')}</ul>` : `<div class="muted">${esc(empty)}</div>`;
}
const DATA_GROUP_ORDER = [
  ['social_profiles', 'Social profiles'],
  ['music_platforms', 'Music platforms'],
  ['emails', 'Emails'],
  ['phones', 'Phone numbers'],
  ['domains', 'Domains'],
  ['links', 'Links'],
  ['ips', 'IP addresses'],
  ['wallets', 'Wallets'],
  ['other', 'Other data'],
];
function isHttpUrl(value) {
  return /^https?:\/\//i.test(String(value || '').trim());
}
function likelyDomain(value) {
  const clean = String(value || '').trim();
  return /^[a-z0-9-]+(\.[a-z0-9-]+)+$/i.test(clean) && !clean.includes(' ');
}
function hrefFor(value, type = '') {
  const raw = String(value || '').trim();
  const kind = String(type || '').toLowerCase();
  if (!raw) return '';
  if (isHttpUrl(raw)) return raw;
  if (kind === 'email' || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(raw)) return `mailto:${raw}`;
  if (kind === 'phone' || /^\+?[\d\s().-]{7,25}$/.test(raw)) {
    const phone = raw.replace(/[^\d+]/g, '');
    return phone ? `tel:${phone}` : '';
  }
  if (kind === 'domain' || likelyDomain(raw)) return `https://${raw.replace(/^https?:\/\//i, '')}`;
  return '';
}
function linkHtml(value, type = '', fallbackHref = '') {
  const label = String(value || '').trim();
  const href = hrefFor(fallbackHref || label, type);
  if (!label) return '<span class="muted">No value</span>';
  return href ? `<a class="data-link" href="${attr(href)}" target="_blank" rel="noopener noreferrer">${esc(label)}</a>` : `<span class="data-value">${esc(label)}</span>`;
}
function findingValue(row) {
  const displayValue = row.display_entity_value || row.display?.display_entity_value || row.entity_value || '';
  const url = row.primary_link || row.display?.primary_link || row.profile_url || row.final_url || '';
  const category = row.data_category || row.display?.data_category || '';
  if (['social_profiles', 'music_platforms'].includes(category) && isHttpUrl(url)) return url;
  if ((row.entity_type === 'url' || category === 'links') && isHttpUrl(url || displayValue)) return url || displayValue;
  return displayValue || url || row.profile_url || row.final_url || row.source_name || '';
}
function findingKind(row) {
  return row.data_category_label || row.display?.data_category_label || row.display_entity_type || row.display?.display_entity_type || row.entity_type || 'Other data';
}
function groupedFindings(rows) {
  const groups = new Map(DATA_GROUP_ORDER.map(([key, label]) => [key, {key, label, rows: []}]));
  rows.forEach(row => {
    const key = row.data_category || row.display?.data_category || 'other';
    if (!groups.has(key)) groups.set(key, {key, label: row.data_category_label || row.display?.data_category_label || 'Other data', rows: []});
    groups.get(key).rows.push(row);
  });
  return [...groups.values()].filter(group => group.rows.length);
}
function dataCounts(rows) {
  return Object.fromEntries(DATA_GROUP_ORDER.map(([key]) => [key, rows.filter(row => (row.data_category || row.display?.data_category || 'other') === key).length]));
}
function compactDate(value) {
  return String(value || '').replace('T', ' ').replace('+00:00', '').slice(0, 19);
}
function unique(rows, getter) {
  return [...new Set(rows.map(getter).filter(value => value !== undefined && value !== null && String(value) !== ''))].sort((a, b) => String(a).localeCompare(String(b)));
}
function fillSelect(id, values, label) {
  const node = el(id);
  if (!node) return;
  const current = node.value;
  node.innerHTML = `<option value="">${esc(label)}</option>` + values.map(value => `<option value="${attr(value)}">${esc(value)}</option>`).join('');
  if (values.map(String).includes(current)) node.value = current;
}
function showEmpty(colspan, message) {
  return `<tr><td colspan="${colspan}" class="empty"><b>No matching data</b><br>${esc(message)}<br><span class="muted">Adjust filters or run additional sources for this case.</span></td></tr>`;
}
function renderPager(id, total, page, setter) {
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  el(id).innerHTML = `<span class="muted">${total} rows | page ${page}/${pages}</span>
    <span><button type="button" data-dir="-1">Prev</button> <button type="button" data-dir="1">Next</button></span>`;
  el(id).querySelectorAll('button').forEach(button => {
    button.disabled = (button.dataset.dir === '-1' && page <= 1) || (button.dataset.dir === '1' && page >= pages);
    button.addEventListener('click', () => setter(Math.min(pages, Math.max(1, page + Number(button.dataset.dir)))));
  });
}
async function api(path, options = {}) {
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
  const method = String(options.method || 'GET').toUpperCase();
  if (csrf && !['GET','HEAD','OPTIONS'].includes(method)) {
    options.headers = {...(options.headers || {}), 'X-CSRF-Token': csrf};
  }
  const response = await fetch(path, options);
  if (!response.ok) throw new Error(await response.text());
  return response.json();
}
function workspaceModel() { return state.workspace?.workspace_model || {tables: {}, overview: {counts: {}}, exports: {items: []}, raw: {sections: {}}}; }
function tableModel(key) { return workspaceModel().tables?.[key] || {key, columns: [], rows: [], filters: {}, filter_labels: {}, status_counts: {}, empty: 'No rows.'}; }
function tableState(key) {
  if (!state.tableState[key]) state.tableState[key] = {page: 1, sortKey: '', sortDir: 1};
  return state.tableState[key];
}
async function loadWorkspace() {
  state.workspace = await api(`/cases/${encodeURIComponent(CASE_NAME)}/workspace`);
  state.tableState = {};
  state.tableRows = {};
  state.graphNeedsLayout = true;
  state.graphLastKey = '';
  hydrateFilters();
  renderAll();
}
function hydrateFilters() {
  const w = state.workspace || {};
  fillSelect('graphTypeFilter', unique(w.graph?.nodes || [], row => row.data?.type || 'unknown'), 'All node types');
  fillSelect('graphRelationFilter', unique(w.graph?.edges || [], row => row.data?.label), 'All relations');
  qsa('[data-table-filters]').forEach(container => {
    const key = container.dataset.tableFilters;
    const model = tableModel(key);
    const labels = model.filter_labels || {};
    container.innerHTML = Object.entries(model.filters || {}).map(([filterKey, values]) => `
      <label>${esc(labels[filterKey] || filterKey)}<select data-table-filter="${attr(key)}" data-filter-key="${attr(filterKey)}">
        <option value="">All</option>
        ${(values || []).map(value => `<option value="${attr(value)}">${esc(value)}</option>`).join('')}
      </select></label>`).join('');
  });
}
function renderAll() {
  updateTabCounts();
  renderOverview();
  renderWorkspaceTables();
  if (graphTabActive()) renderGraph();
  renderRelations();
  renderExports();
  renderRaw();
  renderManifest();
}
function updateTabCounts() {
  const counts = workspaceModel().overview?.counts || {};
  document.querySelectorAll('[data-tab-count]').forEach(node => {
    const n = Number(counts[node.dataset.tabCount] || 0);
    node.textContent = n;
    node.classList.toggle('is-zero', n === 0);
  });
}
window.bedniiosintRerender = () => { if (state.workspace) renderAll(); };
function tableRows(key) {
  return (tableModel(key).rows || []);
}
function platformPriorityBoost(row) {
  const blob = `${row.platform || ''} ${row.url || row.source || ''}`.toLowerCase();
  const hit = PRIORITY_PLATFORMS.findIndex(p =>
    blob.includes(p) ||
    (p === 'vk' && blob.includes('vk.com')) ||
    (p === 'telegram' && blob.includes('t.me')) ||
    (p === 'instagram' && blob.includes('instagr')) ||
    (p === 'youtube' && (blob.includes('youtu.be') || blob.includes('youtube.com')))
  );
  return hit === -1 ? 0 : (PRIORITY_PLATFORMS.length - hit) * 10;
}
function leadScore(row) {
  const score = Number(row.confidence?.score ?? row.confidence ?? 0);
  const statusBoost = row.status === 'found' || row.status === 'exists' ? 2 : row.status === 'candidate' ? 1 : 0;
  const evidenceBoost = Number(row.evidence?.count || 0) > 0 ? .5 : 0;
  return platformPriorityBoost(row) + statusBoost + score + evidenceBoost;
}
function priorityLeadRows() {
  const order = ['profiles', 'emails', 'phones', 'domains', 'mentions'];
  return order.flatMap(key => tableRows(key).map(row => ({...row, _tableKey: key, _tableTitle: tableModel(key).title || key})))
    .sort((a, b) => leadScore(b) - leadScore(a))
    .slice(0, 8);
}
function renderOverview() {
  const summarySection = el('investigationSummary');
  if (summarySection) {
    summarySection.innerHTML = '';
    summarySection.style.display = 'none';
  }
  const cards = el('overviewTableCards');
  if (cards) cards.innerHTML = '';
  const leads = priorityLeadRows();
  el('priorityLeadsBody').innerHTML = leads.length ? leads.map(row => `
    <tr class="row-click" data-priority-row="${attr(row.row_id)}" data-priority-table="${attr(row._tableKey)}">
      <td>${esc(row._tableTitle)}<div class="muted small">${esc(row.platform || row.source || '')}</div></td>
      <td>${linkHtml(row.primary_link || row.profile_url || row.final_url || row.url || row.email || row.phone || row.domain || row.mention || row.handle || '', row._tableKey === 'emails' ? 'email' : row._tableKey === 'phones' ? 'phone' : row._tableKey === 'domains' ? 'domain' : 'url')}</td>
      <td>${statusPill(row.status)}</td>
      <td>${confidencePill(row.confidence)}</td>
      <td>${evidenceCell(row.evidence)}</td>
    </tr>`).join('') : '<tr><td class="empty" colspan="5">No priority leads yet.</td></tr>';
  el('priorityLeadsBody').querySelectorAll('[data-priority-row]').forEach(row => row.addEventListener('click', () => openTableRow(row.dataset.priorityTable, row.dataset.priorityRow)));
}
function statusPill(status) {
  const clean = String(status || 'unknown').toLowerCase();
  return `<span class="status-badge status-${attr(clean)}">${esc(wtr(clean))}</span>`;
}
function confidencePill(info) {
  const data = (info && typeof info === 'object') ? info : {label: info ? String(info) : 'None / 0%', band: 'none'};
  const band = String(data.bucket || data.band || 'none').toLowerCase();
  const reasons = Array.isArray(data.reasons) ? data.reasons.filter(Boolean) : [];
  const title = reasons.length ? attr('Why: ' + reasons.join(' | ')) : '';
  const hint = reasons.length ? '<span class="conf-why" aria-hidden="true">?</span>' : '';
  return `<span class="confidence-badge confidence-${attr(band)}"${title ? ` title="${title}"` : ''}>${esc(data.label || 'None / 0%')}${hint}</span>`;
}
function evidenceCell(value) {
  const data = (value && typeof value === 'object') ? value : {count: Number(value || 0)};
  const count = Number(data.count || 0);
  const detail = [data.hash ? String(data.hash).slice(0, 12) : '', data.timestamp ? compactDate(data.timestamp) : ''].filter(Boolean).join(' | ');
  return `<span>${count} artifact${count === 1 ? '' : 's'}</span>${detail ? `<div class="muted small">${esc(detail)}</div>` : ''}`;
}
function signalsCell(values) {
  const rows = Array.isArray(values) ? values : (values ? [values] : []);
  return rows.length ? `<div class="signal-list">${rows.slice(0, 5).map(item => `<span class="signal-chip" title="${attr(item)}">${esc(item)}</span>`).join('')}</div>` : '<span class="muted">No signals</span>';
}
function rowActions(row) {
  return `<div class="row-actions">${(row.actions || [{type:'inspect', label:'Inspect'}]).map(action => {
    if (action.type === 'open' && action.url) return `<a class="btn" href="${attr(action.url)}" target="_blank" rel="noopener noreferrer" data-stop-row="1">${esc(action.label || 'Open')}</a>`;
    if (action.type === 'finding' && action.finding_id) return `<button class="ghost-button" type="button" data-open-finding="${attr(action.finding_id)}">${esc(action.label || 'Finding')}</button>`;
    return `<button class="ghost-button" type="button" data-inspect-row="1">${esc(action.label || 'Inspect')}</button>`;
  }).join('')}</div>`;
}
function cellValue(row, key) {
  const value = row[key];
  if (value && typeof value === 'object' && !Array.isArray(value)) return value.label || value.count || value.score || JSON.stringify(value);
  if (Array.isArray(value)) return value.join(' ');
  return value ?? '';
}
function sortValue(row, key) {
  const value = row[key];
  if (value && typeof value === 'object' && !Array.isArray(value)) return Number(value.score ?? value.count ?? -1) || String(value.label || '');
  return value ?? '';
}
function tableCellHtml(row, column) {
  const value = row[column.key];
  if (column.type === 'status') return statusPill(value);
  if (column.type === 'confidence') return confidencePill(value);
  if (column.type === 'signals') return signalsCell(value);
  if (column.type === 'evidence') return evidenceCell(value);
  if (column.type === 'actions') return rowActions(row);
  if (column.type === 'url') return linkHtml(value, 'url');
  if (column.type === 'email') return linkHtml(value, 'email');
  if (column.type === 'phone') return linkHtml(value, 'phone');
  if (column.type === 'domain') return linkHtml(value, 'domain');
  return esc(value ?? '');
}
function filteredTableRows(key) {
  const model = tableModel(key);
  const q = (el(`${key}Search`)?.value || '').trim().toLowerCase();
  const activeFilters = qsa(`[data-table-filter="${key}"]`).map(node => [node.dataset.filterKey, node.value]).filter(([, value]) => value);
  let rows = (model.rows || []).filter(row => {
    if (q && !textOf(row).includes(q)) return false;
    return activeFilters.every(([filterKey, value]) => String(cellValue(row, filterKey)) === String(value));
  });
  const table = tableState(key);
  if (table.sortKey) {
    rows = [...rows].sort((a, b) => {
      const av = sortValue(a, table.sortKey);
      const bv = sortValue(b, table.sortKey);
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * table.sortDir;
      return String(av).localeCompare(String(bv), undefined, {numeric: true, sensitivity: 'base'}) * table.sortDir;
    });
  }
  state.tableRows[key] = rows;
  return rows;
}
function renderWorkspaceTable(key) {
  const model = tableModel(key);
  const table = tableState(key);
  const rows = filteredTableRows(key);
  const pageCount = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  table.page = Math.min(pageCount, Math.max(1, table.page));
  const pageRows = rows.slice((table.page - 1) * PAGE_SIZE, table.page * PAGE_SIZE);
  const totalRows = (model.rows || []).length;
  if (el(`${key}Title`)) el(`${key}Title`).textContent = model.title || key;
  if (el(`${key}Meta`)) el(`${key}Meta`).textContent = `${rows.length} visible of ${totalRows} rows`;
  el(`${key}Head`).innerHTML = `<tr>${(model.columns || []).map(column => `<th>${column.sortable ? `<button class="table-sort ${table.sortKey === column.key ? 'active' : ''}" type="button" data-sort-table="${attr(key)}" data-sort-key="${attr(column.key)}">${esc(column.label)}${table.sortKey === column.key ? (table.sortDir > 0 ? ' ^' : ' v') : ''}</button>` : esc(column.label)}</th>`).join('')}</tr>`;
  el(`${key}Body`).innerHTML = pageRows.length ? pageRows.map(row => `
    <tr class="row-click" data-table-row="${attr(row.row_id)}" data-table-key="${attr(key)}">
      ${(model.columns || []).map(column => `<td>${tableCellHtml(row, column)}</td>`).join('')}
    </tr>`).join('') : showEmpty(Math.max(1, (model.columns || []).length), model.empty || 'No matching rows.');
  const counts = model.status_counts || {};
  el(`${key}StatusStrip`).innerHTML = Object.entries(counts).length
    ? Object.entries(counts).map(([status, count]) => `${statusPill(status)} <span class="data-chip">${count}</span>`).join('')
    : '<span class="muted small">No statuses.</span>';
  renderPager(`${key}Pager`, rows.length, table.page, page => { table.page = page; renderWorkspaceTable(key); });
  el(`${key}Head`).querySelectorAll('[data-sort-table]').forEach(button => button.addEventListener('click', () => {
    const current = tableState(button.dataset.sortTable);
    if (current.sortKey === button.dataset.sortKey) current.sortDir *= -1;
    else { current.sortKey = button.dataset.sortKey; current.sortDir = 1; }
    renderWorkspaceTable(button.dataset.sortTable);
  }));
  el(`${key}Body`).querySelectorAll('[data-table-row]').forEach(row => row.addEventListener('click', () => openTableRow(row.dataset.tableKey, row.dataset.tableRow)));
  el(`${key}Body`).querySelectorAll('[data-open-finding]').forEach(button => button.addEventListener('click', event => { event.stopPropagation(); openFinding(button.dataset.openFinding); }));
  el(`${key}Body`).querySelectorAll('[data-inspect-row]').forEach(button => button.addEventListener('click', event => {
    event.stopPropagation();
    const row = button.closest('[data-table-row]');
    openTableRow(row.dataset.tableKey, row.dataset.tableRow);
  }));
  el(`${key}Body`).querySelectorAll('[data-stop-row]').forEach(anchor => anchor.addEventListener('click', event => event.stopPropagation()));
}
function renderWorkspaceTables() {
  Object.keys(workspaceModel().tables || {}).forEach(renderWorkspaceTable);
}
function renderInspector(inspector, fallback = {}) {
  if (!inspector) return `<div class="drawer-section"><h3>Row</h3>${kvRows(fallback)}</div>`;
  return (inspector.sections || []).map(section => `<div class="drawer-section"><h3>${esc(section.title || 'Section')}</h3>${(section.rows || []).map(row => {
    const key = row[0] ?? '';
    const value = row[1] ?? '';
    const linked = /url|email|phone|domain|artifact/i.test(String(key));
    return `<div class="kv"><div class="muted">${esc(key)}</div><div>${linked ? linkHtml(value) : esc(value)}</div></div>`;
  }).join('')}</div>`).join('') || `<div class="drawer-section"><h3>${esc(inspector.title || 'Row')}</h3>${kvRows(fallback)}</div>`;
}
function openDrawer() {
  el('evidenceDrawer')?.classList.add('open');
}
function closeDrawer() {
  el('evidenceDrawer')?.classList.remove('open');
}
function openTableRow(key, rowId) {
  const row = (tableModel(key).rows || []).find(item => String(item.row_id) === String(rowId));
  if (!row) return;
  openDrawer();
  el('drawerHint').textContent = `${tableModel(key).title || key} row selected`;
  el('drawerContent').innerHTML = renderInspector(row.inspector, row);
}
function exportTable(key, format) {
  const model = tableModel(key);
  const rows = state.tableRows[key] || filteredTableRows(key);
  const columns = (model.columns || []).filter(column => column.type !== 'actions');
  if (format === 'json') {
    downloadText(`${CASE_NAME}-${key}.json`, 'application/json', JSON.stringify(rows, null, 2));
    return;
  }
  const csvEscape = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
  const lines = [
    columns.map(column => csvEscape(column.label)).join(','),
    ...rows.map(row => columns.map(column => csvEscape(cellValue(row, column.key))).join(','))
  ];
  downloadText(`${CASE_NAME}-${key}.csv`, 'text/csv;charset=utf-8', lines.join('\\n'));
}
function downloadText(filename, type, text) {
  const blob = new Blob([text], {type});
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}
function renderExports() {
  const items = workspaceModel().exports?.items || [];
  el('exportsModelBody').innerHTML = `<h2>Workspace Exports</h2><div class="report-actions">${items.map(item => item.url
    ? `<a class="btn" href="${attr(item.url)}" download target="_blank" rel="noopener noreferrer">${esc(item.label)} <span class="muted">${esc(item.format || '')}</span></a>`
    : `<button class="ghost-button" type="button" disabled>${esc(item.label)} <span class="muted">${esc(item.format || '')}</span></button>`).join('')}</div>`;
}
function renderRaw(sectionKey = '') {
  const raw = workspaceModel().raw || {sections: {}};
  const keys = Object.keys(raw.sections || {});
  if (!state.rawSection || !keys.includes(state.rawSection)) state.rawSection = sectionKey || keys[0] || '';
  el('rawNav').innerHTML = keys.map(key => `<button class="ghost-button ${state.rawSection === key ? 'active' : ''}" type="button" data-raw-section="${attr(key)}">${esc(key)}</button>`).join('') || '<div class="muted">No raw sections.</div>';
  el('rawPreview').textContent = state.rawSection ? JSON.stringify(raw.sections[state.rawSection] || {}, null, 2) : 'No raw data.';
  el('rawNav').querySelectorAll('[data-raw-section]').forEach(button => button.addEventListener('click', () => { state.rawSection = button.dataset.rawSection; renderRaw(); }));
}
function graphRows() {
  const q = el('graphTextFilter').value.trim().toLowerCase();
  const type = el('graphTypeFilter').value;
  const rel = el('graphRelationFilter').value;
  const hideSources = Boolean(el('graphHideSources')?.checked);
  const hideWeak = Boolean(el('graphHideWeak')?.checked);
  let nodes = state.workspace.graph.nodes.map(row => row.data || {});
  let edges = state.workspace.graph.edges.map(row => row.data || {});
  if (hideSources) {
    const sourceIds = new Set(nodes.filter(node => String(node.type || '').toLowerCase() === 'source').map(node => node.id));
    nodes = nodes.filter(node => !sourceIds.has(node.id));
    edges = edges.filter(edge => !sourceIds.has(edge.source) && !sourceIds.has(edge.target));
  }
  if (hideWeak) {
    edges = edges.filter(edge => Number(edge.confidence || 0) >= .45 || Number(edge.evidence_count || 0) > 0);
    const connected = new Set();
    edges.forEach(edge => { connected.add(edge.source); connected.add(edge.target); });
    nodes = nodes.filter(node => connected.has(node.id) || Number(node.confidence || 0) >= .45);
  }
  let allowed = new Set(nodes.filter(node => (!type || node.type === type) && (!q || textOf(node).includes(q))).map(node => node.id));
  if (rel) {
    const related = new Set();
    edges.filter(edge => edge.label === rel).forEach(edge => { related.add(edge.source); related.add(edge.target); });
    allowed = new Set([...allowed].filter(id => related.has(id)));
  }
  return {nodes: nodes.filter(node => allowed.has(node.id)), edges: edges.filter(edge => allowed.has(edge.source) && allowed.has(edge.target))};
}
function graphTabActive() {
  return el('tab-graph')?.classList.contains('active');
}
function graphPalette() {
  return new Map([
    ['person', '#33d69f'], ['username', '#33d69f'], ['company', '#f5c451'],
    ['domain', '#4ea1ff'], ['email', '#ff6673'], ['phone', '#46d9d3'],
    ['ip', '#a78bfa'], ['url', '#8bc2ff'], ['source', '#7c8797'], ['unknown', '#7c8797']
  ]);
}
function resizeGraphCanvas() {
  if (!document.getElementById("workspaceGraphCanvas")) return;
  const canvas = el('workspaceGraphCanvas');
  const ctx = canvas.getContext('2d');
  const rect = canvas.getBoundingClientRect();
  const width = Math.max(320, Math.floor(rect.width || canvas.clientWidth || 960));
  const height = Math.max(420, Math.floor(rect.height || canvas.clientHeight || 560));
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const targetWidth = Math.round(width * dpr);
  const targetHeight = Math.round(height * dpr);
  if (canvas.width !== targetWidth || canvas.height !== targetHeight) {
    canvas.width = targetWidth;
    canvas.height = targetHeight;
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return {canvas, ctx, width, height, dpr};
}
function graphLayoutKey(data) {
  return [
    state.graphLayoutMode,
    data.nodes.map(node => node.id).sort().join('|'),
    data.edges.map(edge => `${edge.source}>${edge.target}:${edge.label || ''}`).sort().join('|')
  ].join('::');
}
function initializeGraphLayout(data, force = false) {
  const key = graphLayoutKey(data);
  const existing = state.graphPositions;
  const missing = data.nodes.some(node => !existing.has(node.id));
  if (!force && !state.graphNeedsLayout && state.graphLastKey === key && !missing) return;
  const degree = new Map(data.nodes.map(node => [node.id, 0]));
  data.edges.forEach(edge => {
    degree.set(edge.source, (degree.get(edge.source) || 0) + 1);
    degree.set(edge.target, (degree.get(edge.target) || 0) + 1);
  });
  const sorted = [...data.nodes].sort((a, b) => (degree.get(b.id) || 0) - (degree.get(a.id) || 0) || String(a.label || a.id).localeCompare(String(b.label || b.id)));
  const next = new Map();
  const keepExisting = !force && state.graphLastKey === key;
  if (state.graphLayoutMode === 'wide') {
    const groups = new Map();
    sorted.forEach(node => {
      const type = String(node.type || 'unknown').toLowerCase();
      if (!groups.has(type)) groups.set(type, []);
      groups.get(type).push(node);
    });
    const groupRows = [...groups.entries()];
    const rowGap = 118;
    groupRows.forEach(([type, rows], groupIndex) => {
      const width = Math.max(1, rows.length - 1) * 190;
      rows.forEach((node, index) => {
        const old = existing.get(node.id);
        if (keepExisting && old) { next.set(node.id, {...old, ...node}); return; }
        next.set(node.id, {...node, x: index * 190 - width / 2, y: groupIndex * rowGap - ((groupRows.length - 1) * rowGap) / 2, r: 14 + Math.min(8, degree.get(node.id) || 0)});
      });
    });
  } else {
    const hasHub = sorted.length > 2 && (degree.get(sorted[0]?.id) || 0) > 1;
    sorted.forEach((node, index) => {
      const old = existing.get(node.id);
      if (keepExisting && old) { next.set(node.id, {...old, ...node}); return; }
      if (sorted.length === 1) {
        next.set(node.id, {...node, x: 0, y: 0, r: 16});
        return;
      }
      if (hasHub && index === 0) {
        next.set(node.id, {...node, x: 0, y: 0, r: 18});
        return;
      }
      const ringIndex = hasHub ? index - 1 : index;
      const totalRingNodes = hasHub ? sorted.length - 1 : sorted.length;
      const ring = Math.floor(ringIndex / 24);
      const ringStart = ring * 24;
      const ringSize = Math.min(24, Math.max(1, totalRingNodes - ringStart));
      const angle = (Math.PI * 2 * (ringIndex - ringStart)) / ringSize;
      const radiusX = 190 + ring * 88;
      const radiusY = 145 + ring * 70;
      next.set(node.id, {...node, x: Math.cos(angle) * radiusX, y: Math.sin(angle) * radiusY, r: 14 + Math.min(8, degree.get(node.id) || 0)});
    });
  }
  state.graphPositions = next;
  state.graphLastKey = key;
}
function graphBounds(data) {
  const nodes = data.nodes.map(node => state.graphPositions.get(node.id)).filter(Boolean);
  if (!nodes.length) return null;
  const xs = nodes.map(node => node.x);
  const ys = nodes.map(node => node.y);
  return {minX: Math.min(...xs), maxX: Math.max(...xs), minY: Math.min(...ys), maxY: Math.max(...ys)};
}
function fitGraphToData(data) {
  const size = resizeGraphCanvas();
  const bounds = graphBounds(data);
  if (!bounds) {
    state.graphView = {x: size.width / 2, y: size.height / 2, scale: 1};
    return;
  }
  const boxW = Math.max(80, bounds.maxX - bounds.minX + 120);
  const boxH = Math.max(80, bounds.maxY - bounds.minY + 100);
  const scale = Math.max(0.18, Math.min(2.4, Math.min(size.width / boxW, size.height / boxH)));
  const cx = (bounds.minX + bounds.maxX) / 2;
  const cy = (bounds.minY + bounds.maxY) / 2;
  state.graphView = {x: size.width / 2 - cx * scale, y: size.height / 2 - cy * scale, scale};
}
function screenToGraph(x, y) {
  return {x: (x - state.graphView.x) / state.graphView.scale, y: (y - state.graphView.y) / state.graphView.scale};
}
function graphPointer(event) {
  const rect = el('workspaceGraphCanvas').getBoundingClientRect();
  return {x: event.clientX - rect.left, y: event.clientY - rect.top};
}
function hitGraphNode(screenX, screenY) {
  const point = screenToGraph(screenX, screenY);
  const hitRadius = 20 / Math.max(0.25, state.graphView.scale);
  return [...(state.graphHitNodes || [])].reverse().find(node => Math.hypot(node.x - point.x, node.y - point.y) <= Math.max(node.r || 14, hitRadius));
}
function drawGraphCanvas(data = state.graphData || {nodes: [], edges: []}) {
  const fallback = el('graphEmptyFallback');
  if (fallback) fallback.style.display = data.nodes.length ? 'none' : 'block';
  const {ctx, width, height} = resizeGraphCanvas();
  const palette = graphPalette();
  const typeColor = new Map();
  data.nodes.forEach(node => {
    const type = String(node.type || 'unknown').toLowerCase();
    if (!typeColor.has(type)) typeColor.set(type, palette.get(type) || palette.get('unknown'));
  });
  state.graphVisibleNodeIds = new Set(data.nodes.map(node => node.id));
  state.graphHitNodes = data.nodes.map(node => state.graphPositions.get(node.id)).filter(Boolean);
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = '#08101a';
  ctx.fillRect(0, 0, width, height);
  const grid = 32 * state.graphView.scale;
  if (grid >= 12) {
    ctx.strokeStyle = 'rgba(148,163,184,.08)';
    ctx.lineWidth = 1;
    const offsetX = ((state.graphView.x % grid) + grid) % grid;
    const offsetY = ((state.graphView.y % grid) + grid) % grid;
    for (let x = offsetX; x < width; x += grid) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke(); }
    for (let y = offsetY; y < height; y += grid) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke(); }
  }
  if (!data.nodes.length) {
    ctx.fillStyle = '#94a3b8'; ctx.font = '14px Segoe UI, Arial'; ctx.fillText('No graph nodes match the current filters.', 24, 40);
    return;
  }
  ctx.save();
  ctx.translate(state.graphView.x, state.graphView.y);
  ctx.scale(state.graphView.scale, state.graphView.scale);
  const selectedId = state.selectedNode?.id || '';
  data.edges.forEach(edge => {
    const a = state.graphPositions.get(edge.source), b = state.graphPositions.get(edge.target);
    if (!a || !b) return;
    const strong = selectedId && (edge.source === selectedId || edge.target === selectedId);
    ctx.strokeStyle = strong ? '#8bc2ff' : 'rgba(79,94,118,.76)';
    ctx.lineWidth = (strong ? 2.5 : 1.05) / state.graphView.scale;
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    const shouldLabel = strong || data.edges.length <= 35;
    if (shouldLabel) {
      const label = [edge.label, edge.confidence ? pct(edge.confidence) : '', edge.evidence_count ? `${edge.evidence_count} ev` : ''].filter(Boolean).join(' | ');
      if (label) {
        const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        const fontSize = 11 / state.graphView.scale;
        const labelWidth = Math.min(210 / state.graphView.scale, label.length * 6.2 / state.graphView.scale + 10 / state.graphView.scale);
        ctx.fillStyle = 'rgba(8,12,18,.84)';
        ctx.fillRect(mx - 4 / state.graphView.scale, my - 12 / state.graphView.scale, labelWidth, 18 / state.graphView.scale);
        ctx.fillStyle = '#cbd5e1';
        ctx.font = `${fontSize}px Segoe UI, Arial`;
        ctx.fillText(label.slice(0, 34), mx, my + 1 / state.graphView.scale);
      }
    }
  });
  state.graphPositions.forEach(node => {
    if (!state.graphVisibleNodeIds.has(node.id)) return;
    const selected = selectedId === node.id;
    const neighbor = selectedId && data.edges.some(edge => (edge.source === selectedId && edge.target === node.id) || (edge.target === selectedId && edge.source === node.id));
    const faded = selectedId && !selected && !neighbor;
    const type = String(node.type || 'unknown').toLowerCase();
    const radius = Math.max(9, (selected ? (node.r || 14) + 5 : (node.r || 14)) / Math.sqrt(Math.max(0.75, state.graphView.scale)));
    ctx.globalAlpha = faded ? 0.32 : 1;
    ctx.fillStyle = typeColor.get(type) || '#7c8797';
    ctx.beginPath(); ctx.arc(node.x, node.y, radius, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = selected ? '#e6edf7' : '#0d131c'; ctx.lineWidth = (selected ? 3 : 1.4) / state.graphView.scale; ctx.stroke();
    if (data.nodes.length <= 180 || selected || neighbor || state.graphView.scale > .55) {
      ctx.fillStyle = '#e6edf7';
      ctx.font = `${12 / state.graphView.scale}px Segoe UI, Arial`;
      ctx.fillText(String(node.label || node.id).slice(0, 34), node.x + radius + 7 / state.graphView.scale, node.y + 4 / state.graphView.scale);
    }
    ctx.globalAlpha = 1;
  });
  ctx.restore();
}
function renderGraphList(data) {
  const selectedId = state.selectedNode?.id || '';
  el('graphNodeList').innerHTML = data.nodes.slice(0, 160).map(node => `<button type="button" class="${selectedId === node.id ? 'active' : ''}" data-node="${attr(node.id)}">${esc(node.label || node.id)} <span class="muted">${esc(node.type || 'unknown')}</span></button>`).join('') || '<div class="empty small">No nodes.</div>';
  el('graphNodeList').querySelectorAll('[data-node]').forEach(button => button.addEventListener('click', () => openNode(button.dataset.node)));
}
function renderGraph(options = {}) {
  if (!document.getElementById("workspaceGraphCanvas")) return;
  if (!state.workspace || !graphTabActive()) return;
  const data = graphRows();
  state.graphData = data;
  el('sparseGraphNote').style.display = data.nodes.length > 0 && data.nodes.length < 3 ? 'block' : 'none';
  if (state.selectedNode && !data.nodes.some(node => node.id === state.selectedNode.id)) state.selectedNode = null;
  initializeGraphLayout(data, Boolean(options.relayout));
  if (options.fit || state.graphNeedsLayout) fitGraphToData(data);
  drawGraphCanvas(data);
  el('graphStats').innerHTML = `<span class="data-chip">${data.nodes.length} nodes</span><span class="data-chip">${data.edges.length} edges</span><span class="data-chip">${Math.round(state.graphView.scale * 100)}%</span>`;
  renderGraphList(data);
  renderGraphInspector();
  state.graphNeedsLayout = false;
}
function requestGraphDraw() {
  cancelAnimationFrame(state.graphFrame);
  state.graphFrame = requestAnimationFrame(() => {
    const data = state.graphData || {nodes: [], edges: []};
    drawGraphCanvas(data);
    el('graphStats').innerHTML = `<span class="data-chip">${data.nodes.length} nodes</span><span class="data-chip">${data.edges.length} edges</span><span class="data-chip">${Math.round(state.graphView.scale * 100)}%</span>`;
  });
}
function zoomGraph(factor, origin = null) {
  const size = resizeGraphCanvas();
  const point = origin || {x: size.width / 2, y: size.height / 2};
  const before = screenToGraph(point.x, point.y);
  const nextScale = Math.max(0.18, Math.min(3.8, state.graphView.scale * factor));
  state.graphView.scale = nextScale;
  state.graphView.x = point.x - before.x * nextScale;
  state.graphView.y = point.y - before.y * nextScale;
  requestGraphDraw();
}
function renderGraphInspector() {
  const node = state.selectedNode;
  if (!node) { el('graphInspector').innerHTML = '<div class="muted">Select a node.</div>'; return; }
  const edges = state.workspace.graph.edges.map(row => row.data || {}).filter(edge => edge.source === node.id || edge.target === node.id);
  el('graphInspector').innerHTML = `<div class="kv"><div class="muted">Type</div><div>${esc(node.type)}</div></div>
    <div class="kv"><div class="muted">Label</div><div>${esc(node.label || node.id)}</div></div>
    <div class="kv"><div class="muted">ID</div><div>${esc(node.id)}</div></div>
    <div class="kv"><div class="muted">Relations</div><div>${edges.length}</div></div>`;
}
function renderRelations() {
  const relations = state.workspace.relations || [];
  el('relationsBody').innerHTML = relations.length ? relations.map(row => `
    <tr>
      <td>${esc(row.src_type)}:${esc(row.src_value)}</td>
      <td><span class="badge">${esc(row.rel)}</span></td>
      <td>${esc(row.dst_type)}:${esc(row.dst_value)}</td>
      <td class="form-actions">
        <button class="ghost-button" type="button" data-edit-relation="${row.id}">Edit</button>
        <button class="danger-button" type="button" data-delete-relation="${row.id}">Delete</button>
      </td>
    </tr>`).join('') : showEmpty(4, 'No relations yet.');
  el('relationsBody').querySelectorAll('[data-edit-relation]').forEach(button => button.addEventListener('click', () => editRelation(button.dataset.editRelation)));
  el('relationsBody').querySelectorAll('[data-delete-relation]').forEach(button => button.addEventListener('click', () => deleteRelation(button.dataset.deleteRelation)));
}
function resetRelationForm() {
  state.editingRelationId = null;
  el('relationForm').reset();
  el('relationSubmit').textContent = 'Add Relation';
}
function editRelation(id) {
  const relation = state.workspace.relations.find(row => String(row.id) === String(id));
  if (!relation) return;
  openDrawer();
  state.editingRelationId = relation.id;
  const form = el('relationForm');
  form.elements.src_type.value = relation.src_type || '';
  form.elements.src_value.value = relation.src_value || '';
  form.elements.rel.value = relation.rel || '';
  form.elements.dst_type.value = relation.dst_type || '';
  form.elements.dst_value.value = relation.dst_value || '';
  el('relationSubmit').textContent = 'Update Relation';
  el('drawerHint').textContent = 'Relation selected';
  el('drawerContent').innerHTML = `<div class="drawer-section"><h3>Relation</h3>${kvRows(relation)}</div>`;
}
async function deleteRelation(id) {
  await api(`/cases/${encodeURIComponent(CASE_NAME)}/relations/${encodeURIComponent(id)}`, {method:'DELETE'});
  if (String(state.editingRelationId) === String(id)) resetRelationForm();
  await loadWorkspace();
}
function openNode(id) {
  const node = (state.workspace.graph.nodes.map(row => row.data || {}).find(row => row.id === id));
  if (!node) return;
  openDrawer();
  state.selectedNode = node;
  renderGraph();
  const value = node.label || String(node.id || '').split(':').slice(1).join(':');
  const notes = state.workspace.notes.filter(note => note.entity_value === value || note.entity_value === node.id);
  const findings = state.workspace.findings.filter(row => row.entity_value === value || row.profile_url === value);
  const relations = state.workspace.relations.filter(row => row.src_value === value || row.dst_value === value || row.src_value === node.id || row.dst_value === node.id);
  el('drawerHint').textContent = 'Graph node selected';
  el('drawerContent').innerHTML = `<div class="drawer-section"><h3>Node</h3>${kvRows(node)}</div>
    <div class="drawer-section"><h3>Related Findings</h3>${findings.length ? findings.map(row => `<button class="linkish" type="button" data-finding="${row.id}">${esc(row.source_name)} / ${esc(row.status)}</button>`).join('<br>') : '<div class="muted">No linked findings.</div>'}</div>
    <div class="drawer-section"><h3>Relations</h3>${relations.length ? relations.map(row => `${esc(row.src_type)}:${esc(row.src_value)} -> ${esc(row.rel)} -> ${esc(row.dst_type)}:${esc(row.dst_value)}`).join('<br>') : '<div class="muted">No manual relations.</div>'}</div>
    <div class="drawer-section"><h3>Notes</h3>${notes.length ? notes.map(row => `<div>${esc(row.note)} <span class="muted">${esc(compactDate(row.created_at))}</span></div>`).join('') : '<div class="muted">No notes.</div>'}</div>`;
  el('drawerContent').querySelectorAll('[data-finding]').forEach(button => button.addEventListener('click', () => openFinding(button.dataset.finding)));
  const relationForm = el('relationForm');
  relationForm.elements.src_type.value = node.type || '';
  relationForm.elements.src_value.value = value || node.id || '';
  const mergeForm = el('mergeForm');
  mergeForm.elements.from_type.value = node.type || '';
  mergeForm.elements.from_value.value = value || node.id || '';
  const splitForm = el('splitForm');
  splitForm.elements.entity_type.value = node.type || '';
  splitForm.elements.entity_value.value = value || node.id || '';
  const noteForm = el('noteForm');
  noteForm.elements.entity_type.value = node.type || '';
  noteForm.elements.entity_value.value = value || node.id || '';
}
function renderTimeline() {
  const q = el('timelineTextFilter').value.trim().toLowerCase();
  const source = el('timelineSourceFilter').value;
  const rows = state.workspace.timeline.filter(row => (!q || textOf(row).includes(q)) && (!source || row.source === source || row.source_name === source));
  el('timelineStream').innerHTML = rows.length ? rows.map((row, index) => `
    <button class="timeline-item" type="button" data-timeline="${index}">
      <div class="timeline-meta"><span class="badge">${esc(row.kind || 'event')}</span><span class="muted">${esc(compactDate(row.when) || 'unknown time')}</span><span class="muted">${esc(row.source || row.source_name || '')}</span></div>
      <b>${esc(row.entity || row.entity_value || '')}</b>
      <div>${esc(row.description || '')}</div>
    </button>`).join('') : '<div class="empty">No timeline events match the current filters.</div>';
  el('timelineStream').querySelectorAll('[data-timeline]').forEach(button => button.addEventListener('click', () => openTimeline(rows[Number(button.dataset.timeline)])));
}
function renderEvidence() {
  const q = el('evidenceTextFilter').value.trim().toLowerCase();
  const module = el('evidenceModuleFilter').value;
  const status = el('evidenceStatusFilter').value;
  const kind = el('attachmentKindFilter').value;
  const rows = state.workspace.evidence.filter(row => (!q || textOf(row).includes(q)) && (!module || row.source_module === module) && (!status || String(row.http_status) === String(status)) && (!kind || state.workspace.attachments.some(att => att.finding_id === row.finding_id && att.kind === kind)));
  const pageRows = rows.slice((state.evidencePage - 1) * PAGE_SIZE, state.evidencePage * PAGE_SIZE);
  el('evidenceBody').innerHTML = pageRows.length ? pageRows.map(row => `
    <tr data-evidence="${row.id}">
      <td>${esc(compactDate(row.captured_at))}</td><td>${esc(row.source_module)}</td><td>${esc(row.http_status)}</td>
      <td>${esc(String(row.sha256 || '').slice(0, 18))}</td>
      <td>${row.url ? `<a href="${attr(row.url)}" target="_blank">${esc(row.url)}</a>` : ''}</td>
      <td>${esc(row.artifact_path || '')}</td>
    </tr>`).join('') : showEmpty(6, 'No evidence matches the current filters.');
  el('evidenceBody').querySelectorAll('[data-evidence]').forEach(row => row.addEventListener('click', () => openEvidence(row.dataset.evidence)));
  renderPager('evidencePager', rows.length, state.evidencePage, page => { state.evidencePage = page; renderEvidence(); });
}
function renderManifest() {
  el('integrityPreview').textContent = JSON.stringify(state.workspace.integrity || {}, null, 2).slice(0, 8000);
  el('manifestPreview').textContent = JSON.stringify(state.workspace.manifest || {}, null, 2).slice(0, 8000);
}
function kvRows(obj) {
  return Object.entries(obj || {}).slice(0, 24).map(([key, value]) => `<div class="kv"><div class="muted">${esc(key)}</div><div>${esc(typeof value === 'object' ? JSON.stringify(value) : value)}</div></div>`).join('');
}
function detailRows(title, rows, empty) {
  return `<div class="drawer-section"><h3>${esc(title)}</h3>${rows && rows.length ? rows.map(row => {
    const key = String(row[0] || '');
    const value = row[1] ?? '';
    const keyLower = key.toLowerCase();
    const linked = keyLower.includes('url') || keyLower.includes('link') || keyLower.includes('email') || keyLower.includes('phone') || keyLower.includes('domain');
    return `<div class="kv"><div class="muted">${esc(key)}</div><div>${linked ? linkHtml(value) : esc(value)}</div></div>`;
  }).join('') : `<div class="muted">${esc(empty || 'No data.')}</div>`}</div>`;
}
function rawDetails(title, value) {
  return `<details class="drawer-section"><summary>${esc(title)}</summary><pre class="pre">${esc(JSON.stringify(value || {}, null, 2))}</pre></details>`;
}
async function openFinding(id) {
  const detail = await api(`/cases/${encodeURIComponent(CASE_NAME)}/findings/${encodeURIComponent(id)}`);
  const finding = detail.finding || {};
  const display = finding.display || {};
  const chain = display.evidence_chain || {};
  const match = display.match_explanation || {};
  const noteMatches = state.workspace.notes.filter(note => note.entity_value === detail.finding.entity_value || note.entity_value === detail.finding.profile_url);
  openDrawer();
  el('drawerHint').textContent = 'Finding evidence selected';
  el('drawerContent').innerHTML =
    detailRows('A. Summary', [
      ['Verdict', display.verdict || finding.verdict || 'Weak'],
      ['Confidence', display.confidence?.label || pct(finding.confidence) || '0%'],
      ['Entity', display.display_entity_value || finding.display_entity_value || finding.entity_value || finding.profile_url || 'unknown'],
      ['Data type', findingKind(finding)],
      ['Source', finding.source_name || finding.source_id || 'unknown'],
      ['URL', finding.profile_url || finding.final_url || ''],
    ]) +
    detailRows('B. Match explanation', [
      ['What was found', display.what_found || finding.what_found || 'Source observation'],
      ['Matched value', match.matched_value || finding.entity_value || ''],
      ['Matched variant', match.matched_variant || finding.display_entity_value || finding.profile_url || ''],
      ['Match reason', match.match_reason || finding.reject_reason || finding.finding_type || ''],
      ['Scope relevance', match.scope_relevance || 'Review required.'],
      ['Source reliability', match.source_reliability ?? finding.source_reliability ?? 'unknown'],
    ]) +
    detailRows('C. Evidence chain', [
      ['Source observed URL', chain.source_observed_url || finding.profile_url || finding.final_url || ''],
      ['Captured at', compactDate(chain.captured_at || finding.captured_at || '')],
      ['HTTP status', chain.http_status || finding.status_code || ''],
      ['SHA-256', chain.sha256 || ''],
      ['Body length', chain.body_len || ''],
      ['Evidence file/link', chain.artifact_path || ''],
    ]) +
    `<div class="drawer-section"><h3>D. Why confidence is low/high</h3>${listHtml(display.confidence_explanation || finding.confidence_explanation || [], 'No confidence explanation recorded.')}</div>` +
    `<div class="drawer-section"><h3>E. Recommended next actions</h3>${listHtml(display.recommended_actions || finding.recommended_actions || [], 'No recommended actions generated.')}</div>` +
    `<div class="drawer-section"><h3>Evidence rows</h3>${detail.evidence.length ? detail.evidence.map(row => `<div class="kv"><div class="muted">${esc(compactDate(row.captured_at) || row.kind || 'evidence')}</div><div>${row.url ? linkHtml(row.url) : esc(row.sha256 || row.artifact_path || row.source_module || '')}</div></div>`).join('') : '<div class="muted">No preserved evidence rows.</div>'}</div>` +
    `<div class="drawer-section"><h3>Legal/privacy note</h3><div class="muted">${esc(finding.legal_notes || finding.tos_notes || 'Review source terms and confidence before external reporting.')}</div></div>` +
    `<div class="drawer-section"><h3>Notes</h3>${noteMatches.length ? noteMatches.map(row => `<div>${esc(row.note)} <span class="muted">${esc(compactDate(row.created_at))}</span></div>`).join('') : '<div class="muted">No analyst notes.</div>'}</div>`;
}
function openTimeline(row) {
  openDrawer();
  el('drawerHint').textContent = 'Timeline event selected';
  el('drawerContent').innerHTML = `<div class="drawer-section"><h3>Timeline Event</h3>${kvRows(row)}</div>`;
  if (row?.finding_id) openFinding(row.finding_id);
}
function openEvidence(id) {
  const row = state.workspace.evidence.find(item => String(item.id) === String(id));
  if (!row) return;
  const attachments = state.workspace.attachments.filter(item => item.finding_id === row.finding_id);
  openDrawer();
  el('drawerHint').textContent = 'Evidence selected';
  el('drawerContent').innerHTML =
    detailRows('Summary', [
      ['Captured', compactDate(row.captured_at)],
      ['Module', row.source_module || ''],
      ['HTTP', row.http_status || ''],
      ['SHA-256', row.sha256 || ''],
    ]) +
    detailRows('Source details', [
      ['URL', row.url || ''],
      ['Artifact', row.artifact_path || ''],
      ['Finding ID', row.finding_id || ''],
    ]) +
    `<div class="drawer-section"><h3>Evidence chain</h3>${attachments.length ? attachments.map(item => `<div class="kv"><div class="muted">${esc(item.kind || 'attachment')}</div><div>${esc(item.path || item.artifact_path || item.sha256 || '')}</div></div>`).join('') : '<div class="muted">No attachments linked to this evidence row.</div>'}</div>` +
    `<div class="drawer-section"><h3>Legal/privacy note</h3><div class="muted">Evidence is local case material. Verify hashes and source context before reporting externally.</div></div>`;
}
function showTab(key) {
  return showWorkspaceTab(key);
}
function showWorkspaceTab(key, options = {}) {
  if (window.bedniiosintShowWorkspaceTab && window.bedniiosintShowWorkspaceTab !== showWorkspaceTab) {
    const switched = window.bedniiosintShowWorkspaceTab(key, options);
    if (!switched) return false;
    const selected = String(key || '').trim();
    if (selected === 'graph') renderGraph({fit: state.graphNeedsLayout});
    if (selected === 'raw') renderRaw();
    return true;
  }
  const selected = String(key || '').trim();
  const panel = el(`tab-${selected}`);
  if (!selected || !panel) return false;
  qsa('.tab-button').forEach(item => {
    const active = item.dataset.tab === selected;
    item.classList.toggle('active', active);
    item.setAttribute('aria-selected', String(active));
    item.setAttribute('tabindex', active ? '0' : '-1');
  });
  qsa('.tab-panel').forEach(item => {
    const active = item.id === `tab-${selected}`;
    item.classList.toggle('active', active);
  });
  if (options.hash !== false && window.location.hash !== `#tab-${selected}`) {
    history.replaceState(null, '', `#tab-${selected}`);
  }
  if (selected === 'graph') renderGraph({fit: state.graphNeedsLayout});
  if (selected === 'raw') renderRaw();
  return true;
}
function wireEvents() {
  qsa('.tab-button').forEach(button => button.addEventListener('click', event => {
    event.preventDefault();
    event.stopPropagation();
    showTab(button.dataset.tab);
  }));
  document.addEventListener('click', event => {
    const button = closestTarget(event, '.tab-button,[data-open-tab]');
    if (!button) return;
    const key = button.dataset.tab || button.dataset.openTab;
    if (!key) return;
    event.preventDefault();
    showTab(key);
  });
  const initialTab = String(window.location.hash || '').replace(/^#tab-/, '');
  if (initialTab) showWorkspaceTab(initialTab, {hash: false});
  qsa('[data-table-search]').forEach(input => input.addEventListener('input', () => {
    const key = input.dataset.tableSearch;
    tableState(key).page = 1;
    renderWorkspaceTable(key);
  }));
  qsa('[data-table-filters]').forEach(container => container.addEventListener('change', event => {
    const select = closestTarget(event, '[data-table-filter]');
    if (!select) return;
    tableState(select.dataset.tableFilter).page = 1;
    renderWorkspaceTable(select.dataset.tableFilter);
  }));
  qsa('[data-table-export]').forEach(button => button.addEventListener('click', () => exportTable(button.dataset.tableExport, button.dataset.format || 'csv')));
  ['graphTextFilter','graphTypeFilter','graphRelationFilter','graphHideSources','graphHideWeak'].forEach(id => {
    const node = el(id);
    if (!node) return;
    const eventName = id === 'graphTextFilter' ? 'input' : 'change';
    node.addEventListener(eventName, () => { state.graphNeedsLayout = true; renderGraph({fit: true}); });
  });
  const graphCanvas = el('workspaceGraphCanvas');
  if (graphCanvas) {
  graphCanvas.addEventListener('pointerdown', event => {
    if (!graphTabActive()) return;
    const p = graphPointer(event);
    const hit = hitGraphNode(p.x, p.y);
    const world = screenToGraph(p.x, p.y);
    state.graphDrag = {
      mode: hit ? 'node' : 'pan',
      nodeId: hit?.id || '',
      startX: p.x,
      startY: p.y,
      originX: state.graphView.x,
      originY: state.graphView.y,
      offsetX: hit ? world.x - hit.x : 0,
      offsetY: hit ? world.y - hit.y : 0,
      moved: false,
    };
    if (hit) {
      state.selectedNode = hit;
      renderGraphInspector();
      drawGraphCanvas();
    }
    graphCanvas.classList.add('dragging');
    graphCanvas.setPointerCapture(event.pointerId);
  });
  graphCanvas.addEventListener('pointermove', event => {
    if (!state.graphDrag) {
      const p = graphPointer(event);
      graphCanvas.style.cursor = hitGraphNode(p.x, p.y) ? 'pointer' : 'grab';
      return;
    }
    const p = graphPointer(event);
    const dx = p.x - state.graphDrag.startX;
    const dy = p.y - state.graphDrag.startY;
    if (Math.hypot(dx, dy) > 3) state.graphDrag.moved = true;
    if (state.graphDrag.mode === 'node') {
      const node = state.graphPositions.get(state.graphDrag.nodeId);
      if (node) {
        const world = screenToGraph(p.x, p.y);
        node.x = world.x - state.graphDrag.offsetX;
        node.y = world.y - state.graphDrag.offsetY;
      }
    } else {
      state.graphView.x = state.graphDrag.originX + dx;
      state.graphView.y = state.graphDrag.originY + dy;
    }
    requestGraphDraw();
  });
  function finishGraphDrag(event) {
    if (!state.graphDrag) return;
    const drag = state.graphDrag;
    state.graphDrag = null;
    graphCanvas.classList.remove('dragging');
    graphCanvas.style.cursor = 'grab';
    try { graphCanvas.releasePointerCapture(event.pointerId); } catch (err) {}
    if (drag.mode === 'node' && !drag.moved && drag.nodeId) openNode(drag.nodeId);
    else renderGraphInspector();
  }
  graphCanvas.addEventListener('pointerup', finishGraphDrag);
  graphCanvas.addEventListener('pointercancel', finishGraphDrag);
  graphCanvas.addEventListener('wheel', event => {
    if (!graphTabActive()) return;
    event.preventDefault();
    const p = graphPointer(event);
    zoomGraph(event.deltaY < 0 ? 1.12 : 0.89, p);
  }, {passive: false});
  el('graphFit').addEventListener('click', () => renderGraph({fit: true}));
  el('graphCenter').addEventListener('click', () => { state.selectedNode = null; renderGraph({fit: true}); });
  el('graphZoomOut').addEventListener('click', () => zoomGraph(0.82));
  el('graphZoomIn').addEventListener('click', () => zoomGraph(1.18));
  el('graphLayout').addEventListener('click', () => {
    state.graphLayoutMode = state.graphLayoutMode === 'wide' ? 'radial' : 'wide';
    state.graphNeedsLayout = true;
    renderGraph({relayout: true, fit: true});
  });
  el('graphResetView').addEventListener('click', () => {
    state.selectedNode = null;
    state.graphPositions = new Map();
    state.graphNeedsLayout = true;
    renderGraph({relayout: true, fit: true});
  });
  }
  window.addEventListener('resize', () => {
    if (!graphTabActive()) return;
    cancelAnimationFrame(state.graphResizeFrame);
    state.graphResizeFrame = requestAnimationFrame(() => renderGraph({fit: false}));
  });
  el('caseSidebarFilter').addEventListener('input', event => {
    const q = event.target.value.trim().toLowerCase();
    qsa('.case-nav-item').forEach(item => {
      item.style.display = !q || item.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
  el('caseSidebarToggle').addEventListener('click', () => el('caseSidebar')?.classList.toggle('open'));
  el('drawerToggle').addEventListener('click', () => el('evidenceDrawer')?.classList.toggle('open'));
  el('drawerClear').addEventListener('click', () => { el('drawerHint').textContent = 'Click a table row, node, finding, or evidence artifact.'; el('drawerContent').innerHTML = '<div class="muted">No selection.</div>'; closeDrawer(); });
  el('relationForm').addEventListener('submit', async event => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.target).entries());
    const relationPath = state.editingRelationId
      ? `/cases/${encodeURIComponent(CASE_NAME)}/relations/${encodeURIComponent(state.editingRelationId)}`
      : `/cases/${encodeURIComponent(CASE_NAME)}/relations`;
    await api(relationPath, {method: state.editingRelationId ? 'PUT' : 'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)});
    resetRelationForm();
    await loadWorkspace();
  });
  el('relationReset').addEventListener('click', resetRelationForm);
  el('mergeForm').addEventListener('submit', async event => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.target).entries());
    await api(`/cases/${encodeURIComponent(CASE_NAME)}/entities/merge`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)});
    event.target.elements.note.value = '';
    await loadWorkspace();
  });
  el('splitForm').addEventListener('submit', async event => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.target).entries());
    await api(`/cases/${encodeURIComponent(CASE_NAME)}/entities/split`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)});
    event.target.elements.new_type.value = '';
    event.target.elements.new_value.value = '';
    event.target.elements.note.value = '';
    await loadWorkspace();
  });
  el('dedupeCase').addEventListener('click', async () => {
    const result = await api(`/cases/${encodeURIComponent(CASE_NAME)}/dedupe`, {method:'POST'});
    el('drawerHint').textContent = 'Case dedupe complete';
    el('drawerContent').innerHTML = `<div class="drawer-section"><h3>Dedupe</h3>${kvRows(result.removed || {})}</div>`;
    await loadWorkspace();
  });
  el('noteForm').addEventListener('submit', async event => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.target).entries());
    await api(`/cases/${encodeURIComponent(CASE_NAME)}/notes`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)});
    event.target.elements.note.value = '';
    await loadWorkspace();
  });
}
wireEvents();
loadWorkspace().catch(error => {
  el('drawerHint').textContent = 'Workspace load failed';
  el('drawerContent').innerHTML = `<pre class="pre">${esc(error.message)}</pre>`;
});
