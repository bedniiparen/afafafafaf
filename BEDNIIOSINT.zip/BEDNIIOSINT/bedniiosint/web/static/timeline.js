﻿const timelineData = JSON.parse(document.getElementById('timelineData').textContent);
const stream = document.getElementById('timelineStream');
const search = document.getElementById('timelineSearch');
const kind = document.getElementById('timelineKind');
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function renderTimeline() {
  const q = search.value.trim().toLowerCase();
  const k = kind.value;
  const rows = timelineData.filter(row => (!k || row.kind === k) && (!q || JSON.stringify(row).toLowerCase().includes(q)));
  if (!rows.length) {
    stream.innerHTML = '<div class="timeline-empty">No timeline events match the current filters.</div>';
    return;
  }
  stream.innerHTML = rows.map((row, index) => `
    <article class="timeline-item">
      <div class="timeline-dot">${index + 1}</div>
      <div class="timeline-body">
        <div class="timeline-meta">
          <span class="badge">${escapeHtml(row.kind || 'event')}</span>
          <span class="muted">${escapeHtml(row.when || 'unknown time')}</span>
          <span class="muted">${escapeHtml(row.precision || '')}</span>
        </div>
        <div><b>${escapeHtml(row.entity || '')}</b></div>
        <div class="muted">${escapeHtml(row.source || '')}</div>
        <div>${escapeHtml(row.description || '')}</div>
      </div>
    </article>`).join('');
}
search.addEventListener('input', renderTimeline);
kind.addEventListener('change', renderTimeline);
document.getElementById('timelineReset').addEventListener('click', () => { search.value = ''; kind.value = ''; renderTimeline(); });
renderTimeline();
