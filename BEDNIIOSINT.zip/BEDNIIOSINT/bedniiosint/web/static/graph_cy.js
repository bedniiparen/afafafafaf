/* graph_cy.js - interactive investigation graph (cytoscape.js) */
(() => {
  "use strict";
  const mount = document.getElementById("cyGraph");
  if (!mount || typeof cytoscape === "undefined") return;

  const TYPE_COLORS = {
    person: "#33d69f", username: "#33d69f",
    domain: "#4ea1ff", url: "#4ea1ff",
    email: "#ff6673",
    ip: "#a78bfa",
    phone: "#f7b955",
    source: "#7c8797",
  };
  const colorFor = (t) => TYPE_COLORS[(t || "").toLowerCase()] || "#9aa4b2";
  const el = (id) => document.getElementById(id);

  function endpoint() {
    const a = document.querySelector('#tab-graph a[href$="/graph"]');
    if (a) return a.getAttribute("href");
    const m = location.pathname.match(/\/cases\/[^/]+/);
    return m ? m[0] + "/graph" : null;
  }

  function buildElements(payload) {
    const rawNodes = payload.nodes || (payload.elements && payload.elements.nodes) || [];
    const rawEdges = payload.edges || (payload.elements && payload.elements.edges) || [];
    const nodes = rawNodes.map((n) => {
      const d = n.data || n;
      return { data: Object.assign({}, d, {
        id: String(d.id),
        label: d.label || d.id,
        type: (d.type || "").toLowerCase(),
      }) };
    });
    const seen = new Set(nodes.map((n) => n.data.id));
    const edges = [];
    rawEdges.forEach((e, i) => {
      const d = e.data || e;
      const s = String(d.source);
      const t = String(d.target);
      if (!seen.has(s) || !seen.has(t)) return;
      edges.push({ data: Object.assign({}, d, {
        id: d.id ? String(d.id) : "e" + i,
        source: s,
        target: t,
        label: d.label || "",
      }) });
    });
    return { nodes, edges };
  }

  let cy = null;

  function styleArr() {
    return [
      { selector: "node", style: {
        "background-color": (n) => colorFor(n.data("type")),
        "label": "data(label)", "color": "#e7ecf3", "font-size": 11,
        "text-valign": "bottom", "text-margin-y": 4, "min-zoomed-font-size": 8,
        "width": 22, "height": 22, "border-width": 1, "border-color": "rgba(0,0,0,.35)",
      } },
      { selector: "node.faded", style: { "opacity": 0.12 } },
      { selector: "node.pick", style: { "border-width": 3, "border-color": "#ffffff", "width": 30, "height": 30 } },
      { selector: "edge", style: {
        "width": 1.4, "line-color": "rgba(150,164,178,.5)",
        "target-arrow-color": "rgba(150,164,178,.6)", "target-arrow-shape": "triangle",
        "curve-style": "bezier", "label": "data(label)", "font-size": 9,
        "color": "#9aa4b2", "text-rotation": "autorotate", "min-zoomed-font-size": 9,
      } },
      { selector: "edge.faded", style: { "opacity": 0.06 } },
    ];
  }

  function inspect(node) {
    const box = el("graphInspector");
    if (box) {
      box.hidden = false;
      box.innerHTML = "";
      const d = node.data();
      const h = document.createElement("div");
      h.className = "gi-title";
      h.textContent = (d.type ? d.type.toUpperCase() + ": " : "") + (d.label || d.id);
      box.appendChild(h);
      const sub = document.createElement("div");
      sub.className = "gi-sub muted";
      sub.textContent = "connections: " + node.connectedEdges().length;
      box.appendChild(sub);
    }
    const list = el("graphNodeList");
    if (list) {
      list.innerHTML = "";
      node.neighborhood("node").forEach((nb) => {
        const li = document.createElement("li");
        li.textContent = (nb.data("type") || "node") + " - " + (nb.data("label") || nb.id());
        list.appendChild(li);
      });
    }
  }

  function focusNode(node) {
    cy.elements().addClass("faded");
    node.closedNeighborhood().removeClass("faded");
    cy.nodes().removeClass("pick");
    node.addClass("pick");
    inspect(node);
  }

  function clearFocus() {
    cy.elements().removeClass("faded");
    cy.nodes().removeClass("pick");
  }

  function applyFilters() {
    if (!cy) return;
    const text = (el("graphTextFilter") ? el("graphTextFilter").value : "").trim().toLowerCase();
    const type = (el("graphTypeFilter") ? el("graphTypeFilter").value : "").trim().toLowerCase();
    const rel = (el("graphRelationFilter") ? el("graphRelationFilter").value : "").trim().toLowerCase();
    const hideSources = !!(el("graphHideSources") && el("graphHideSources").checked);
    const hideWeak = !!(el("graphHideWeak") && el("graphHideWeak").checked);
    cy.batch(() => {
      cy.nodes().forEach((n) => {
        const d = n.data();
        let show = true;
        if (text && String(d.label || d.id).toLowerCase().indexOf(text) === -1) show = false;
        if (type && (d.type || "") !== type) show = false;
        if (hideSources && (d.type || "") === "source") show = false;
        if (hideWeak && Number(d.weight || d.confidence || 1) < 0.4) show = false;
        n.style("display", show ? "element" : "none");
      });
      cy.edges().forEach((e) => {
        const d = e.data();
        let show = true;
        if (rel && String(d.label || "").toLowerCase() !== rel) show = false;
        if (e.source().style("display") === "none" || e.target().style("display") === "none") show = false;
        e.style("display", show ? "element" : "none");
      });
    });
  }

  function wireControls() {
    const on = (id, fn) => { const node = el(id); if (node) node.addEventListener("click", fn); };
    on("graphFit", () => cy.fit(undefined, 30));
    on("graphCenter", () => cy.center());
    on("graphZoomIn", () => cy.zoom(cy.zoom() * 1.2));
    on("graphZoomOut", () => cy.zoom(cy.zoom() / 1.2));
    on("graphResetView", () => { clearFocus(); cy.reset(); cy.fit(undefined, 30); });
    const layouts = ["cose", "concentric", "breadthfirst", "circle"];
    let layoutIdx = 0;
    on("graphLayout", () => {
      layoutIdx = (layoutIdx + 1) % layouts.length;
      cy.layout({ name: layouts[layoutIdx], animate: false, padding: 30 }).run();
    });
    ["graphTextFilter", "graphTypeFilter", "graphRelationFilter"].forEach((id) => {
      const node = el(id);
      if (!node) return;
      node.addEventListener("input", applyFilters);
      node.addEventListener("change", applyFilters);
    });
    ["graphHideSources", "graphHideWeak"].forEach((id) => {
      const node = el(id);
      if (node) node.addEventListener("change", applyFilters);
    });
  }

  function render(payload) {
    const elements = buildElements(payload);
    const fallback = el("graphEmptyFallback");
    if (!elements.nodes.length) {
      if (fallback) fallback.hidden = false;
      return;
    }
    if (fallback) fallback.hidden = true;
    cy = cytoscape({
      container: mount,
      elements: elements,
      style: styleArr(),
      layout: { name: "cose", animate: false, padding: 30, nodeRepulsion: 6000 },
      wheelSensitivity: 0.2,
      minZoom: 0.2,
      maxZoom: 3,
    });
    cy.on("tap", "node", (ev) => focusNode(ev.target));
    cy.on("tap", (ev) => { if (ev.target === cy) clearFocus(); });
    const stats = el("graphStats");
    if (stats) stats.textContent = elements.nodes.length + " nodes - " + elements.edges.length + " edges";
    wireControls();
    applyFilters();
  }

  function load() {
    const url = endpoint();
    if (!url) return;
    fetch(url, { headers: { "Accept": "application/json" } })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error("graph " + r.status))))
      .then(render)
      .catch(() => { const f = el("graphEmptyFallback"); if (f) f.hidden = false; });
  }

  function ready() {
    const tab = document.getElementById("tab-graph");
    const visible = () => tab && !tab.hidden && tab.getAttribute("aria-hidden") !== "true";
    if (!tab || visible()) { load(); return; }
    const obs = new MutationObserver(() => { if (visible() && !cy) load(); });
    obs.observe(tab, { attributes: true, attributeFilter: ["hidden", "aria-hidden", "class"] });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ready);
  else ready();
})();
