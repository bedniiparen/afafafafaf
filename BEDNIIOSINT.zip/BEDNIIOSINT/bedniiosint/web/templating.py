from __future__ import annotations

from pathlib import Path
from typing import Any

try:
    from jinja2 import Environment, FileSystemLoader, select_autoescape
    from markupsafe import Markup
except Exception:  # pragma: no cover
    Environment = None
    FileSystemLoader = None
    Markup = None
    select_autoescape = None


TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"

TEMPLATE_ENV = (
    Environment(
        loader=FileSystemLoader(TEMPLATE_DIR),
        autoescape=select_autoescape(("html", "xml")),
    )
    if Environment is not None and FileSystemLoader is not None and select_autoescape is not None
    else None
)


def safe_markup(value: str) -> Any:
    return Markup(value) if Markup is not None else value


def render_template(name: str, **context: Any) -> str | None:
    if TEMPLATE_ENV is None:
        return None
    return TEMPLATE_ENV.get_template(name).render(**context)
