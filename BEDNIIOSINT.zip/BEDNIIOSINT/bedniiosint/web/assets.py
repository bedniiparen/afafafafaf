from __future__ import annotations

from pathlib import Path


STATIC_DIR = Path(__file__).with_name("static")
ASSET_VERSION = "20260608.2"
STATIC_CACHE_CONTROL = "no-cache"


def _asset_version(filename: str) -> str:
    path = STATIC_DIR / filename
    try:
        return str(int(path.stat().st_mtime))
    except OSError:
        return ASSET_VERSION


def asset_tags(*, include_refresh: bool = True) -> str:
    refresh = (
        f'<link rel="stylesheet" href="/static/refresh.css?v={_asset_version("refresh.css")}">\n'
        if include_refresh
        else ""
    )
    return (
        f'<link rel="stylesheet" href="/static/app.css?v={_asset_version("app.css")}">\n'
        f"{refresh}"
        f'<script src="/static/app.js?v={_asset_version("app.js")}" defer></script>'
    )


def script_tag(filename: str) -> str:
    safe_name = filename.strip().lstrip("/")
    if "/" in safe_name or "\\" in safe_name or not safe_name.endswith(".js"):
        raise ValueError("static script filename must be a top-level .js file")
    return f'<script src="/static/{safe_name}?v={_asset_version(safe_name)}" defer></script>'


def style_tag(filename: str) -> str:
    safe_name = filename.strip().lstrip("/")
    if "/" in safe_name or "\\" in safe_name or not safe_name.endswith(".css"):
        raise ValueError("static stylesheet filename must be a top-level .css file")
    return f'<link rel="stylesheet" href="/static/{safe_name}?v={_asset_version(safe_name)}">'


def is_static_path(path: str) -> bool:
    return path == "/static" or path.startswith("/static/")
