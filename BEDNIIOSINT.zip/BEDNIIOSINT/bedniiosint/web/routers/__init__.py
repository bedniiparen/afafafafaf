"""FastAPI router package for BEDNIIOSINT web domains."""
