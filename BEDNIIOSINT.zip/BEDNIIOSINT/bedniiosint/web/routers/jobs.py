from __future__ import annotations

import asyncio
import json
from html import escape
from urllib.parse import parse_qs

try:
    from fastapi import APIRouter, BackgroundTasks, HTTPException, Request
    from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
except Exception:  # pragma: no cover
    APIRouter = None
    BackgroundTasks = None
    HTTPException = Exception
    Request = None
    HTMLResponse = None
    RedirectResponse = None
    StreamingResponse = None

from ...core.jobs import (
    cancel_job,
    create_job,
    get_job,
    job_as_dict,
    job_event_as_dict,
    job_stale_after_seconds,
    list_job_events,
    list_jobs,
    recover_stale_jobs,
    resume_job,
    run_job,
    start_worker,
    stop_worker,
    worker_status,
)
from ..assets import asset_tags, style_tag
from ..schemas import JobAPI, JobEventAPI, WorkerStatusAPI
from ..security import CSRF_FIELD, csrf_token
from ..templating import TEMPLATE_ENV, safe_markup


def _wants_html_redirect(request: Request) -> bool:
    content_type = str(request.headers.get("content-type", "")).lower()
    accept = str(request.headers.get("accept", "")).lower()
    async_header = str(request.headers.get("x-requested-with", "")).lower()
    if async_header == "xmlhttprequest" or (
        "application/json" in accept and "text/html" not in accept
    ):
        return False
    return (
        "application/x-www-form-urlencoded" in content_type
        or "multipart/form-data" in content_type
        or "text/html" in accept
    )


def _jobs_redirect() -> RedirectResponse:
    return RedirectResponse("/jobs", status_code=303)


def _sse_event(event: str, payload: dict) -> str:
    data = json.dumps(payload, ensure_ascii=False, default=str).replace("\n", "\\n")
    return f"event: {event}\ndata: {data}\n\n"


async def _job_event_stream(job_id: int):
    seen_event_ids: set[int] = set()
    for _ in range(900):
        job = get_job(job_id)
        if job is None:
            yield _sse_event("error", {"detail": "job not found"})
            return
        for event in list_job_events(job_id):
            if event.id in seen_event_ids:
                continue
            if event.id is not None:
                seen_event_ids.add(event.id)
            yield _sse_event("job-event", job_event_as_dict(event))
        job_payload = job_as_dict(job)
        yield _sse_event("job", job_payload)
        if job_payload.get("status") in {"finished", "failed", "cancelled"}:
            yield _sse_event("done", job_payload)
            return
        await asyncio.sleep(1)
    yield _sse_event("timeout", {"job_id": job_id, "detail": "stream timeout"})


def _jobs_html() -> str:
    if TEMPLATE_ENV is None:
        return _jobs_html_fallback()
    return TEMPLATE_ENV.get_template("jobs.html").render(
        asset_tags=safe_markup(asset_tags()),
        jobs_style=safe_markup(style_tag("jobs.css")),
        csrf_field=CSRF_FIELD,
        csrf_token=csrf_token(),
        jobs=[job_as_dict(job) for job in list_jobs()],
        worker=worker_status(),
    )


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _csrf_input() -> str:
    token = csrf_token()
    return f'<input type="hidden" name="{_e(CSRF_FIELD)}" value="{_e(token)}">'


def _jobs_html_fallback() -> str:
    jobs = [job_as_dict(job) for job in list_jobs()]
    worker = worker_status()
    token = csrf_token()
    csrf = _csrf_input()
    rows = "".join(
        "<tr>"
        f"<td><a href=\"/jobs/{_e(row['id'])}/events\" target=\"_blank\">{_e(row['id'])}</a></td>"
        f"<td>{_e(row['case_name'])}</td>"
        f"<td>{_e(row['module'])}</td>"
        f"<td>{_e(row['target'])}</td>"
        f"<td><span class=\"status {'exists' if row['status'] == 'finished' else ''}\">{_e(row['status'])}</span></td>"
        f"<td>{_e(row['completed_sources'])}/{_e(row['total_sources'])}</td>"
        f"<td>{_e(row['current_source'])}</td>"
        f"<td>{_e(round(float(row['progress']) * 100, 1))}%</td>"
        f"<td>{_e(row.get('max_retries', 0))}</td>"
        f"<td><code>{_e(row.get('rate_limit_budget_json', '{}'))}</code></td>"
        f"<td>{_e(row['updated_at'])}</td>"
        "<td class=\"row-actions\">"
        f"<a class=\"btn small\" href=\"/jobs/{_e(row['id'])}/events\" target=\"_blank\">Events</a>"
        f"<form method=\"post\" action=\"/jobs/{_e(row['id'])}/run\">{csrf}<button class=\"small\" type=\"submit\">Start</button></form>"
        f"<form method=\"post\" action=\"/jobs/{_e(row['id'])}/resume\">{csrf}<button class=\"small\" type=\"submit\">Resume</button></form>"
        f"<form method=\"post\" action=\"/jobs/{_e(row['id'])}/cancel\">{csrf}<button class=\"small\" type=\"submit\">Cancel</button></form>"
        "</td>"
        "</tr>"
        for row in jobs
    )
    if not rows:
        rows = '<tr><td colspan="12" class="muted">No jobs yet.</td></tr>'
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{_e(token)}">
<title>BEDNIIOSINT Jobs</title>
{asset_tags()}
{style_tag("jobs.css")}
</head>
<body>
<header><div class="topbar"><a class="brand" href="/"><span class="brand-mark">B</span><span>BEDNIIOSINT</span></a><nav><a class="nav" href="/">Search</a><a class="nav" href="/history">History</a><a class="nav active" href="/jobs">Jobs</a><a class="nav" href="/reports">Reports</a><div class="theme-switch" role="group" aria-label="Theme"><button class="theme-button" id="themeToggle" type="button" data-theme-toggle aria-pressed="false" title="Switch theme">Theme</button></div></nav></div></header>
<main>
<div class="page-head">
  <div>
    <h1>Jobs</h1>
    <div class="muted">Queued, running, cancelled and finished scans.</div>
    <div class="worker-strip">
      <span class="muted">Worker: {_e('running' if worker.get('running') else 'stopped')} | queued {_e(worker.get('queued', 0))} | claimed {_e(worker.get('claimed', 0))} | stale {_e(worker.get('stale_active', 0))}</span>
      <form method="post" action="/jobs/worker/start">{csrf}<button type="submit">Start Worker</button></form>
      <form method="post" action="/jobs/worker/stop">{csrf}<button type="submit">Stop Worker</button></form>
      <a class="btn small" href="/jobs/worker/status" target="_blank">Worker JSON</a>
    </div>
  </div>
  <a class="btn" href="/jobs.json" target="_blank">Jobs JSON</a>
</div>
<section class="search-panel">
  <form class="search-form" method="post" action="/jobs">
    {csrf}
    <label>Target<input name="target" placeholder="username, email, domain, ip" required></label>
    <label>Module<input name="module" value="auto" placeholder="auto, pipeline, domain_pipeline"></label>
    <label>Retries<input name="max_retries" type="number" min="0" value="1"></label>
    <label>Budget<input name="rate_limit_budget" placeholder="*=2,GitHub=1"></label>
    <label class="checkline"><input name="resume" type="checkbox"> Resume</label>
    <label class="checkline"><input name="run_now" type="checkbox"> Start immediately</label>
    <button type="submit">Queue</button>
  </form>
</section>
<div class="table-shell"><table>
<tr><th>ID</th><th>Case</th><th>Module</th><th>Target</th><th>Status</th><th>Sources</th><th>Current</th><th>Progress</th><th>Retries</th><th>Budget</th><th>Updated</th><th>Actions</th></tr>
{rows}
</table></div>
</main>
<script src="/static/app.js?v=20260608" defer></script>
</body>
</html>"""


if APIRouter is not None:
    router = APIRouter()

    @router.get("/jobs", response_class=HTMLResponse)
    def jobs_page():
        recover_stale_jobs(stale_after_seconds=job_stale_after_seconds())
        return HTMLResponse(_jobs_html())

    @router.get("/jobs.json", response_model=list[JobAPI])
    def jobs_api():
        recover_stale_jobs(stale_after_seconds=job_stale_after_seconds())
        return [job_as_dict(job) for job in list_jobs()]

    @router.get("/jobs/worker/status", response_model=WorkerStatusAPI)
    def jobs_worker_status_api():
        return worker_status()

    @router.post("/jobs/worker/start", response_model=WorkerStatusAPI)
    def jobs_worker_start_api(request: Request):
        result = worker_status() if worker_status().get("running") else start_worker()
        if _wants_html_redirect(request):
            return _jobs_redirect()
        return result

    @router.post("/jobs/worker/stop", response_model=WorkerStatusAPI)
    def jobs_worker_stop_api(request: Request):
        result = stop_worker()
        if _wants_html_redirect(request):
            return _jobs_redirect()
        return result

    @router.post("/jobs", response_model=JobAPI)
    async def create_job_api(request: Request, background_tasks: BackgroundTasks):
        recover_stale_jobs(stale_after_seconds=job_stale_after_seconds())
        body = (await request.body()).decode("utf-8", errors="replace")
        fields = parse_qs(body, keep_blank_values=True)
        target = fields.get("target", [""])[0].strip()
        module = fields.get("module", ["auto"])[0].strip() or "auto"
        case = fields.get("case", [""])[0].strip() or None
        try:
            max_retries = int(fields.get("max_retries", ["1"])[0] or "1")
        except ValueError as exc:
            raise HTTPException(400, "max_retries must be an integer") from exc
        budget = fields.get("rate_limit_budget", [""])[0].strip() or None
        resume = fields.get("resume", [""])[0].lower() in {"1", "true", "yes", "on"}
        run_now = fields.get("run_now", [""])[0].lower() in {"1", "true", "yes", "on"}
        if not target:
            raise HTTPException(400, "target is required")
        try:
            job = create_job(
                target,
                module=module,
                case_name=case,
                max_retries=max_retries,
                rate_limit_budget=budget,
                resume=resume,
            )
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        if run_now and job.id is not None:
            background_tasks.add_task(run_job, job.id, raise_on_error=False)
        if _wants_html_redirect(request):
            return _jobs_redirect()
        return job_as_dict(job)

    @router.get("/jobs/{job_id}", response_model=JobAPI)
    def job_api(job_id: int):
        recover_stale_jobs(stale_after_seconds=job_stale_after_seconds())
        job = get_job(job_id)
        if job is None:
            raise HTTPException(404, "job not found")
        return job_as_dict(job)

    @router.get("/jobs/{job_id}/events", response_model=list[JobEventAPI])
    def job_events_api(job_id: int):
        if get_job(job_id) is None:
            raise HTTPException(404, "job not found")
        return [job_event_as_dict(event) for event in list_job_events(job_id)]

    @router.get("/jobs/{job_id}/events/stream")
    def job_events_stream_api(job_id: int):
        if get_job(job_id) is None:
            raise HTTPException(404, "job not found")
        return StreamingResponse(
            _job_event_stream(job_id),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )

    @router.post("/jobs/{job_id}/run", response_model=JobAPI)
    def run_job_api(job_id: int, request: Request, background_tasks: BackgroundTasks):
        job = get_job(job_id)
        if job is None:
            raise HTTPException(404, "job not found")
        background_tasks.add_task(run_job, job_id, raise_on_error=False)
        if _wants_html_redirect(request):
            return _jobs_redirect()
        return job_as_dict(job)

    @router.post("/jobs/{job_id}/resume", response_model=JobAPI)
    def resume_job_api(job_id: int, request: Request, background_tasks: BackgroundTasks):
        try:
            job = resume_job(job_id)
        except KeyError as exc:
            raise HTTPException(404, "job not found") from exc
        background_tasks.add_task(run_job, job_id, resume=True, raise_on_error=False)
        if _wants_html_redirect(request):
            return _jobs_redirect()
        return job_as_dict(job)

    @router.post("/jobs/{job_id}/cancel", response_model=JobAPI)
    def cancel_job_api(job_id: int, request: Request):
        try:
            job = cancel_job(job_id)
        except KeyError as exc:
            raise HTTPException(404, "job not found") from exc
        if _wants_html_redirect(request):
            return _jobs_redirect()
        return job_as_dict(job)

else:
    router = None
