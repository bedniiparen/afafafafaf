from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

try:
    from fastapi import APIRouter, HTTPException
except Exception:  # pragma: no cover
    APIRouter = None
    HTTPException = Exception

from ...core.case_diff import diff_case_summaries
from ...core.case_lookup import case_ids
from ...core.case_summary import build_case_summary
from ...core.case_admin import merge_cases
from ...core.case_workspace import (
    WorkspaceFilters,
    add_manual_event,
    add_manual_relation,
    add_note,
    delete_manual_relation,
    dedupe_case,
    get_finding_detail,
    get_workspace,
    merge_entities,
    split_entity,
    update_manual_relation,
)
from ...core.recheck import recheck_finding
from ...core.timeline import get_timeline
from ...config import settings
from ...evidence.manifest import evidence_manifest
from ...storage.models import Finding
from ...storage.sqlite import Storage
from ..schemas import CaseDiffAPI
from ..schemas import (
    CaseMergeResultAPI,
    CaseSummaryAPI,
    DedupeCaseAPI,
    DeleteRelationAPI,
    EntityMergeAPI,
    EntityMergeResultAPI,
    EntitySplitAPI,
    EntitySplitResultAPI,
    EvidenceManifestAPI,
    FindingAPI,
    FindingDetailAPI,
    GraphAPI,
    NoteAPI,
    NoteCreateAPI,
    RelationAPI,
    RelationCreateAPI,
    TimelineEventCreateAPI,
    TimelineRowAPI,
    WorkspaceAPI,
)


def _storage(case: str) -> Storage:
    path = settings.db_path(case)
    if not Path(path).exists():
        raise HTTPException(404, f"case '{case}' not found")
    return Storage(path)


if APIRouter is not None:
    router = APIRouter()

    @router.get("/cases/diff", response_model=CaseDiffAPI)
    def case_diff_api(previous: str, current: str) -> dict[str, Any]:
        previous_summary = build_case_summary(previous)
        current_summary = build_case_summary(current)
        if not previous_summary.get("meta", {}).get("found"):
            raise HTTPException(404, f"case not found: {previous}")
        if not current_summary.get("meta", {}).get("found"):
            raise HTTPException(404, f"case not found: {current}")
        return diff_case_summaries(previous_summary, current_summary)

    @router.get("/cases/{name}/findings", response_model=list[FindingAPI])
    def findings(name: str):
        storage = _storage(name)
        ids = case_ids(storage, name)
        if not ids:
            raise HTTPException(404, "case not found")
        with storage.session() as session:
            rows = []
            for cid in ids:
                rows.extend(session.query(Finding).filter(Finding.case_id == cid).all())
        return [
            {
                "source": finding.source_name,
                "url": finding.profile_url,
                "status": finding.status,
                "confidence": finding.confidence,
                "rejected": finding.rejected,
            }
            for finding in rows
            if finding.status == "exists" and not finding.rejected
        ]

    @router.post("/cases/{name}/findings/{finding_id}/recheck", response_model=CaseSummaryAPI)
    def recheck_finding_api(name: str, finding_id: int):
        try:
            return recheck_finding(name, finding_id)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.get("/cases/{name}/summary", response_model=CaseSummaryAPI)
    def case_summary_api(name: str):
        summary = build_case_summary(name)
        if not summary.get("meta", {}).get("found"):
            raise HTTPException(404, "case not found")
        return summary

    @router.get("/cases/{name}/workspace", response_model=WorkspaceAPI)
    def case_workspace_api(
        name: str,
        entity_type: str = "",
        source: str = "",
        status: str = "",
        min_confidence: float | None = None,
        since: str = "",
        until: str = "",
        kind: str = "",
    ):
        try:
            return get_workspace(
                name,
                filters=WorkspaceFilters(
                    entity_type=entity_type,
                    source=source,
                    status=status,
                    min_confidence=min_confidence,
                    since=since,
                    until=until,
                    kind=kind,
                ),
            )
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.get("/cases/{name}/findings/{finding_id}", response_model=FindingDetailAPI)
    def finding_detail_api(name: str, finding_id: int):
        try:
            return get_finding_detail(name, finding_id)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.post("/cases/{name}/notes", response_model=NoteAPI)
    def add_note_api(name: str, payload: NoteCreateAPI):
        note = payload.note.strip()
        if not note:
            raise HTTPException(400, "note is required")
        try:
            return add_note(
                name,
                entity_type=payload.entity_type.strip(),
                entity_value=payload.entity_value.strip(),
                note=note,
            )
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.post("/cases/{name}/timeline", response_model=TimelineRowAPI)
    def add_timeline_event_api(name: str, payload: TimelineEventCreateAPI):
        when = None
        if payload.when:
            try:
                when = datetime.fromisoformat(payload.when)
            except ValueError as exc:
                raise HTTPException(400, "when must be ISO-8601 datetime") from exc
        try:
            return add_manual_event(
                name,
                kind=payload.kind.strip() or "manual",
                entity_type=payload.entity_type.strip(),
                entity_value=payload.entity_value.strip(),
                when=when,
                confidence=payload.confidence,
                description=payload.description,
            )
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.post("/cases/{name}/relations", response_model=RelationAPI)
    def add_relation_api(name: str, payload: RelationCreateAPI):
        try:
            return add_manual_relation(
                name,
                src_type=payload.src_type.strip(),
                src_value=payload.src_value.strip(),
                rel=payload.rel.strip(),
                dst_type=payload.dst_type.strip(),
                dst_value=payload.dst_value.strip(),
            )
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.put("/cases/{name}/relations/{relation_id}", response_model=RelationAPI)
    def update_relation_api(name: str, relation_id: int, payload: RelationCreateAPI):
        try:
            return update_manual_relation(
                name,
                relation_id,
                src_type=payload.src_type.strip(),
                src_value=payload.src_value.strip(),
                rel=payload.rel.strip(),
                dst_type=payload.dst_type.strip(),
                dst_value=payload.dst_value.strip(),
            )
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @router.delete("/cases/{name}/relations/{relation_id}", response_model=DeleteRelationAPI)
    def delete_relation_api(name: str, relation_id: int):
        try:
            return delete_manual_relation(name, relation_id)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.post("/cases/{name}/entities/merge", response_model=EntityMergeResultAPI)
    def merge_entities_api(name: str, payload: EntityMergeAPI):
        try:
            return merge_entities(
                name,
                from_type=payload.from_type.strip(),
                from_value=payload.from_value.strip(),
                into_type=payload.into_type.strip(),
                into_value=payload.into_value.strip(),
                note=payload.note.strip(),
            )
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @router.post("/cases/{name}/entities/split", response_model=EntitySplitResultAPI)
    def split_entity_api(name: str, payload: EntitySplitAPI):
        try:
            return split_entity(
                name,
                entity_type=payload.entity_type.strip(),
                entity_value=payload.entity_value.strip(),
                new_type=payload.new_type.strip(),
                new_value=payload.new_value.strip(),
                rel=payload.rel.strip(),
                note=payload.note.strip(),
            )
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @router.post("/cases/{name}/dedupe", response_model=DedupeCaseAPI)
    def dedupe_case_api(name: str):
        try:
            return dedupe_case(name)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.post("/cases/{target}/merge/{source}", response_model=CaseMergeResultAPI)
    def case_merge_api(target: str, source: str):
        try:
            return merge_cases(target, source)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.get("/cases/{name}/evidence-manifest", response_model=EvidenceManifestAPI)
    def case_evidence_manifest_api(name: str):
        storage = _storage(name)
        ids = case_ids(storage, name)
        if not ids:
            raise HTTPException(404, "case not found")
        return evidence_manifest(storage, ids)

    @router.get("/cases/{name}/graph", response_model=GraphAPI)
    def graph(name: str):
        try:
            workspace = get_workspace(name)
        except KeyError:
            raise HTTPException(404, "case not found") from None
        display_graph = workspace.get("graph") or {}
        return {
            "metrics": display_graph.get("metrics") or {},
            "elements": {
                "nodes": display_graph.get("nodes") or [],
                "edges": display_graph.get("edges") or [],
            },
        }

    @router.get("/cases/{name}/timeline", response_model=list[TimelineRowAPI])
    def timeline(name: str):
        storage = _storage(name)
        ids = case_ids(storage, name)
        if not ids:
            raise HTTPException(404, "case not found")
        return get_timeline(storage, ids)

else:
    router = None
