from __future__ import annotations

import json
import shutil
from html import escape
from pathlib import Path
from typing import Any
from urllib.parse import quote

try:
    from fastapi import APIRouter
    from fastapi.responses import HTMLResponse
except Exception:  # pragma: no cover
    APIRouter = None
    HTMLResponse = None

from ...catalog import source_health_summary
from ...config import settings
from ...core.target import safe_case_name
from ...reports.manifest import case_name_for_report_file, write_report_manifest
from ...search.readiness import search_sources_status
from ...storage.models import Case as CaseRow
from ...storage.sqlite import Storage
from ..assets import asset_tags, script_tag, style_tag
from ..security import CSRF_FIELD, auth_enabled, csrf_token
from ..templating import TEMPLATE_ENV, safe_markup


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def compact_date(value: Any) -> str:
    return str(value or "").replace("T", " ").replace("+00:00", "")[:19] or "unknown"


def header_html(active: str = "") -> str:
    history_class = "active" if active == "history" else ""
    home_class = "active" if active == "home" else ""
    live_class = "active" if active == "live" else ""
    jobs_class = "active" if active == "jobs" else ""
    monitoring_class = "active" if active == "monitoring" else ""
    auth_item = (
        '<form method="post" action="/auth/logout" class="nav-form">'
        f'<input type="hidden" name="{_e(CSRF_FIELD)}" value="{_e(csrf_token())}">'
        '<button class="nav" type="submit">Logout</button>'
        "</form>"
        if auth_enabled()
        else ""
    )
    lang_switch = (
        '<div class="lang-switch" role="group" aria-label="Language">'
        '<button class="lang-button" type="button" data-lang-option="en">EN</button>'
        '<button class="lang-button" type="button" data-lang-option="ru">RU</button>'
        "</div>"
    )
    theme_switch = (
        '<div class="theme-switch" role="group" aria-label="Theme">'
        '<button class="theme-button" id="themeToggle" type="button" '
        'data-theme-menu-toggle aria-haspopup="true" aria-expanded="false" title="Theme">'
        '<span class="theme-dot"></span><span data-theme-current>Theme</span></button>'
        '<div class="theme-menu" id="themeMenu" role="menu" hidden></div>'
        "</div>"
    )
    brand = (
        '<a class="brand" href="/"><span class="brand-mark">B</span><span>BEDNIIOSINT</span></a>'
        if active != "home"
        else '<a class="brand-mini" href="/">BEDNIIOSINT</a>'
    )
    return (
        f'<header class="{"home-topbar" if active == "home" else ""}">'
        '<div class="topbar">'
        f"{brand}"
        "<nav>"
        f'<a class="nav {home_class}" href="/">Search</a>'
        f'<a class="nav {history_class}" href="/history">History</a>'
        f'<a class="nav {monitoring_class}" href="/monitoring">Monitoring</a>'
        f'<a class="nav {live_class}" href="/live-results/view">Live Results</a>'
        f'<a class="nav {jobs_class}" href="/jobs">Jobs</a>'
        f"{auth_item}"
        f"{lang_switch}"
        f"{theme_switch}"
        "</nav>"
        "</div>"
        "</header>"
    )


def _reports_root() -> Path:
    return settings.db_dir.parent / "reports_out"


def _safe_existing_child(path: Path, root: Path) -> Path | None:
    if not path.exists():
        return None
    try:
        resolved_root = root.resolve()
        resolved_path = path.resolve()
    except OSError:
        return None
    if resolved_path == resolved_root or not resolved_path.is_relative_to(resolved_root):
        return None
    return resolved_path


def _remove_file_if_safe(path: Path, root: Path) -> bool:
    safe_path = _safe_existing_child(path, root)
    if safe_path is None or not safe_path.is_file():
        return False
    try:
        safe_path.unlink()
    except OSError:
        return False
    return True


def _remove_dir_if_safe(path: Path, root: Path) -> bool:
    safe_path = _safe_existing_child(path, root)
    if safe_path is None or not safe_path.is_dir():
        return False
    try:
        shutil.rmtree(safe_path)
    except OSError:
        return False
    return True


def history_case_names() -> set[str]:
    case_names: set[str] = set()
    if settings.db_dir.exists():
        case_names.update(
            safe_case_name(path.stem)
            for path in settings.db_dir.glob("*.db")
            if not path.stem.startswith("_")
        )
        case_names.update(
            safe_case_name(path.name[: -len("_vault")])
            for path in settings.db_dir.glob("*_vault")
            if path.is_dir()
        )
    reports_root = _reports_root()
    if reports_root.exists():
        case_names.update(
            safe_case_name(case_name_for_report_file(path))
            for path in reports_root.glob("*")
            if path.is_file() and path.name != "reports-manifest.json"
        )
    return {case for case in case_names if case}


def _report_files_for_case(case: str) -> list[Path]:
    reports_root = _reports_root()
    if not reports_root.exists():
        return []
    safe_case = safe_case_name(case)
    return [
        path
        for path in reports_root.glob("*")
        if path.is_file()
        and path.name != "reports-manifest.json"
        and safe_case_name(case_name_for_report_file(path)) == safe_case
    ]


def _refresh_reports_manifest_after_cleanup() -> None:
    reports_root = _reports_root()
    if not reports_root.exists():
        return
    remaining = [
        path
        for path in reports_root.glob("*")
        if path.is_file() and path.name != "reports-manifest.json"
    ]
    if remaining:
        write_report_manifest(reports_root)
        return
    _remove_file_if_safe(reports_root / "reports-manifest.json", reports_root)
    try:
        reports_root.rmdir()
    except OSError:
        pass


def history_hidden_path() -> Path:
    return settings.db_dir / "_history_hidden.json"


def hidden_history_cases() -> set[str]:
    path = history_hidden_path()
    if not path.exists():
        return set()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return set()
    cases = data.get("cases", []) if isinstance(data, dict) else data
    if not isinstance(cases, list):
        return set()
    return {str(item) for item in cases if item}


def write_hidden_history_cases(cases: set[str]) -> Path:
    settings.db_dir.mkdir(parents=True, exist_ok=True)
    path = history_hidden_path()
    path.write_text(
        json.dumps(
            {"schema_version": "0.1", "cases": sorted(cases)},
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    return path


def clear_history() -> int:
    case_names = history_case_names()
    db_root = settings.db_dir
    reports_root = _reports_root()
    for case in sorted(case_names):
        safe_case = safe_case_name(case)
        _remove_file_if_safe(db_root / f"{safe_case}.db", db_root)
        _remove_dir_if_safe(db_root / f"{safe_case}_vault", db_root)
        for report_file in _report_files_for_case(safe_case):
            _remove_file_if_safe(report_file, reports_root)
    _remove_file_if_safe(history_hidden_path(), db_root)
    _refresh_reports_manifest_after_cleanup()
    return len(case_names)


def unhide_history_case(case: str) -> None:
    hidden = hidden_history_cases()
    if case not in hidden:
        return
    hidden.remove(case)
    write_hidden_history_cases(hidden)


def case_rows(*, include_hidden: bool = False) -> list[dict]:
    rows: list[dict] = []
    if not settings.db_dir.exists():
        return rows
    hidden = set() if include_hidden else hidden_history_cases()

    for db_path in settings.db_dir.glob("*.db"):
        if db_path.stem.startswith("_"):
            continue
        case_name = db_path.stem
        if case_name in hidden:
            continue
        try:
            storage = Storage(db_path)
            with storage.session() as session:
                cases = session.query(CaseRow).all()
        except Exception:
            cases = []

        if not cases:
            rows.append(
                {
                    "case": case_name,
                    "module": "",
                    "target": "",
                    "created_at": "",
                    "runs": 0,
                }
            )
            continue

        for item in cases:
            if item.name in hidden:
                continue
            rows.append(
                {
                    "case": item.name,
                    "module": item.module,
                    "target": item.target,
                    "created_at": item.created_at.isoformat()
                    if hasattr(item.created_at, "isoformat")
                    else item.created_at,
                    "runs": len(cases),
                }
            )

    rows.sort(key=lambda row: row.get("created_at") or "", reverse=True)
    return rows


def history_table(rows: list[dict], limit: int | None = None) -> str:
    selected = rows if limit is None else rows[:limit]
    result_rows = "".join(
        "<tr>"
        f"<td><a href=\"/case/{quote(row['case'], safe='')}\">{_e(row['target'] or row['case'])}</a></td>"
        f"<td>{_e(row['module'])}</td>"
        f"<td>{_e(row['case'])}</td>"
        f"<td>{_e(row['created_at'])}</td>"
        f"<td>{_e(row['runs'])}</td>"
        "</tr>"
        for row in selected
    )
    if not result_rows:
        result_rows = '<tr><td colspan="5" class="muted">No history yet.</td></tr>'
    return (
        "<table>"
        "<tr><th>Query</th><th>Type</th><th>Saved as</th><th>Created</th><th>Executions</th></tr>"
        f"{result_rows}"
        "</table>"
    )


def source_coverage_by_target_items() -> list[str]:
    status = search_sources_status(compact=True)
    items: list[str] = []
    for row in status.get("summary", {}).get("coverage_by_target_type", []):
        if not isinstance(row, dict) or not row.get("sources"):
            continue
        items.append(f"{row.get('target_type')} {row.get('configured_label')}")
    return items


def index_html() -> str:
    categories = [
        {
            "key": "profiles",
            "title": "Profiles",
            "sub": "social handles",
            "sample": "username /identity/username",
            "placeholder": "username /identity/username",
        },
        {
            "key": "music",
            "title": "Music",
            "sub": "VK, YouTube, Genius",
            "sample": "scally milano /music",
            "placeholder": "artist, track or channel /music",
        },
        {
            "key": "emails",
            "title": "Emails",
            "sub": "verification leads",
            "sample": "name@example.com /identity/email",
            "placeholder": "name@example.com /identity/email",
        },
        {
            "key": "domains",
            "title": "Domains",
            "sub": "DNS and web",
            "sample": "example.com /infra/domain",
            "placeholder": "example.com /infra/domain",
        },
        {
            "key": "phones",
            "title": "Phones",
            "sub": "public traces",
            "sample": "+15551234567 /identity/phone",
            "placeholder": "+15551234567 /identity/phone",
        },
        {
            "key": "mentions",
            "title": "Mentions",
            "sub": "web references",
            "sample": "target name /news/mentions",
            "placeholder": "target name /news/mentions",
        },
        {
            "key": "crypto",
            "title": "Crypto",
            "sub": "wallet context",
            "sample": "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa /crypto/address",
            "placeholder": "wallet address /crypto/address",
        },
        {
            "key": "media",
            "title": "Media",
            "sub": "metadata checks",
            "sample": "https://example.com/image.jpg /media/verify",
            "placeholder": "image or video URL /media/verify",
        },
        {
            "key": "geo",
            "title": "Geo",
            "sub": "location context",
            "sample": "place or coordinates /geo/location",
            "placeholder": "place or coordinates /geo/location",
        },
        {
            "key": "advanced",
            "title": "Advanced",
            "sub": "scoped query",
            "sample": "ivanbeats /creator/video/youtube +producer -anime",
            "placeholder": "scoped query with /type and + - filters",
        },
    ]
    recent_by_name: dict[str, dict[str, Any]] = {}
    for row in case_rows():
        recent_by_name.setdefault(str(row.get("case") or ""), row)
    recent_cases = list(recent_by_name.values())
    health = source_health_summary()
    statuses = health.get("statuses", {})
    health_items = (
        f"{health.get('sources', 0)} sources",
        f"{statuses.get('available', 0)} available",
        f"{statuses.get('missing_keys', 0)} missing keys",
        f"{health.get('typed_parsers', 0)} typed parsers",
    )
    coverage_items = source_coverage_by_target_items()
    coverage_line = " | ".join([*health_items, *coverage_items[:6]])
    recent_context = None
    if recent_cases:
        recent = recent_cases[0]
        recent_context = {
            "case": str(recent.get("case") or ""),
            "href": f"/case/{quote(str(recent.get('case') or ''), safe='')}",
            "updated": compact_date(recent.get("created_at")),
        }
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("home.html").render(
            title="BEDNIIOSINT",
            asset_tags=safe_markup(asset_tags()),
            home_style=safe_markup(style_tag("home.css")),
            home_script=safe_markup(script_tag("home.js")),
            header=safe_markup(header_html("home")),
            categories=categories,
            coverage_line=coverage_line,
            health_items=health_items,
            coverage_items=coverage_items,
            recent=recent_context,
        )
    chips = "".join(
        '<button class="scope-chip tile" type="button" '
        f'data-placeholder="{_e(row["placeholder"])}" data-target="{_e(row["sample"])}" '
        f'data-type="{_e(row["key"])}"><span class="tile-title">{_e(row["title"])}</span>'
        f'<span class="tile-sub">{_e(row["sub"])}</span></button>'
        for row in categories
    )
    health_html = '<span aria-hidden="true">&middot;</span>'.join(
        f'<span class="meta-item">{_e(item)}</span>' for item in health_items
    )
    coverage_html = ""
    if coverage_items:
        values = ["Coverage", *coverage_items]
        coverage_html = (
            '<div class="home-meta coverage-meta" aria-label="Configured source coverage">'
            + '<span aria-hidden="true">&middot;</span>'.join(
                f'<span class="meta-item">{_e(item)}</span>' for item in values
            )
            + "</div>"
        )
    if recent_context:
        recent_html = (
            '<div class="recent-line reveal" style="--d:6">'
            "<span>Recent:</span> "
            f'<a href="{_e(recent_context["href"])}">{_e(recent_context["case"])}</a>'
            f" <span aria-hidden=\"true\">&middot;</span> updated {_e(recent_context['updated'])}"
            "</div>"
        )
    else:
        recent_html = '<div class="recent-line reveal" style="--d:6">No recent cases</div>'
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BEDNIIOSINT</title>
{asset_tags()}
{style_tag("home.css")}
</head>
<body>
{header_html("home")}
<main class="google-home home-page">
  <section class="hero search-hero" aria-labelledby="homeWordmark">
    <h1 class="brand-logo wordmark reveal" id="homeWordmark" style="--d:0">BEDNIIOSINT</h1>
    <p class="brand-subtitle">Open-source investigation workspace</p>
    <form class="google-search-form search" action="/jobs" method="post" id="searchForm" role="search">
      <input type="hidden" name="module" value="investigate" id="moduleInput">
      <input type="hidden" name="run_now" value="1">
      <input type="hidden" name="max_retries" value="1">
      <label class="sr-only" for="targetInput">Search target</label>
      <div class="search-box reveal" style="--d:2">
        <svg class="search-ico" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M21 21l-4.3-4.3M11 19a8 8 0 110-16 8 8 0 010 16z"></path>
        </svg>
        <input class="google-search-field" id="targetInput" name="target" type="text" placeholder="Search username, email, domain, IP, phone, URL..." autocomplete="off" spellcheck="false" required autofocus aria-label="Search target">
      </div>
      <div class="search-actions actions reveal" style="--d:3">
        <button class="btn btn-primary home-action" type="submit" id="searchBtn">Search</button>
        <button class="btn home-action" type="button" id="feelingButton">Sample target</button>
      </div>
    </form>
    <div class="scope-chips tiles reveal" aria-label="Scope and entity hints" style="--d:4">{chips}</div>
    <div class="home-meta coverage reveal" aria-label="Source health summary" style="--d:5">{_e(coverage_line)}</div>
    {coverage_html}
    {recent_html}
  </section>
</main>
<div class="loading-panel" id="loadingPanel">
  <div class="loading-box">
    <div class="loading-head">
      <h2>Investigation job</h2>
      <button type="button" class="loading-close" id="loadingClose" aria-label="Close" title="Cancel and close">&times;</button>
    </div>
    <div class="progress-track" id="loadingTrack" aria-hidden="true"><div class="progress-fill" id="loadingBar"></div></div>
    <div class="job-meta">
      <div><span class="muted">Target</span> <b id="loadingTarget">pending</b></div>
      <div><span class="muted">Data type</span> <span id="loadingType">auto</span></div>
      <div><span class="muted">Job id</span> <span id="loadingJobId">pending</span></div>
      <div><span class="muted">Progress</span> <span id="loadingProgress">0%</span></div>
      <div><span class="muted">Elapsed</span> <span id="loadingElapsed">0s</span></div>
      <div><span class="muted">Current source</span> <span id="loadingSource">queued</span></div>
    </div>
    <div class="step running" id="stepSubmit"><span class="step-state">running</span><span>Submitting target to the job queue</span></div>
    <div class="step" id="stepRun"><span class="step-state">pending</span><span>Processing sources and modules</span></div>
    <div class="step" id="stepFinish"><span class="step-state">pending</span><span>Opening case workspace</span></div>
    <div class="muted small" id="loadingMessage">Waiting for server response.</div>
    <div class="loading-actions">
      <button type="button" class="btn" id="loadingHide">Hide and keep running</button>
      <button type="button" class="btn btn-danger" id="loadingCancel">Cancel search</button>
    </div>
  </div>
</div>
{script_tag("home.js")}
</body>
</html>"""


def history_html() -> str:
    rows = case_rows()
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("history.html").render(
            asset_tags=safe_markup(asset_tags()),
            header=safe_markup(header_html("history")),
            rows=[
                {
                    **row,
                    "href": f"/case/{quote(str(row.get('case') or ''), safe='')}",
                }
                for row in rows
            ],
            has_rows=bool(rows),
        )
    clear_button = (
        '<form action="/history/clear" method="post">'
        '<button class="danger" type="submit">Clear History</button>'
        "</form>"
        if rows
        else ""
    )
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BEDNIIOSINT History</title>
{asset_tags()}
</head>
<body>
{header_html("history")}
<main>
<section class="page-head">
  <div><h2>History</h2><div class="muted">Clears saved cases, vault files and exported reports.</div></div>
  {clear_button}
</section>
<section>
  {history_table(rows)}
</section>
</main>
</body>
</html>"""


if APIRouter is not None:
    router = APIRouter()

    @router.get("/", response_class=HTMLResponse)
    def index():
        return HTMLResponse(index_html())

    @router.get("/history", response_class=HTMLResponse)
    def history():
        return HTMLResponse(history_html())

    @router.post("/history/clear", response_class=HTMLResponse)
    def history_clear():
        clear_history()
        return HTMLResponse(history_html())

else:  # pragma: no cover
    router = None
