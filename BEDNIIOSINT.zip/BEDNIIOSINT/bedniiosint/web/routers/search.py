from __future__ import annotations

from html import escape
import json
from pathlib import Path

try:
    from fastapi import APIRouter, HTTPException, Query
    from fastapi.responses import HTMLResponse, PlainTextResponse
except Exception:  # pragma: no cover
    APIRouter = None
    HTTPException = Exception
    Query = None
    HTMLResponse = None
    PlainTextResponse = None

from ...config import settings
from ...core.cache_policy import merge_cache_ttl_presets
from ...core.jobs import resolve_rate_limit_budget
from ...core.source_context import SourceRunContext, parse_cache_ttl_by_source
from ...core.source_pipeline import pipeline_sources, run_source_pipeline
from ...graph.investigation_graph import investigation_graph_cytoscape, investigation_graph_html
from ...reports.case_timeline import build_timeline, timeline_markdown
from ...search.auto_pivot import run_recursive_investigation
from ...search.playbooks import list_playbooks, run_playbook
from ...search.explain import explain_search_run
from ...search.investigation import build_investigation_plan
from ...search.pipeline import run_planned_search_pipeline
from ...search.planner import plan_search
from ...search.readiness import search_sources_status
from ...search.source_registry import filter_sources
from ...storage.fts import search_index as search_fts_index
from ..schemas import (
    InvestigationPlanAPI,
    PipelineRunAPI,
    PipelineSourcesAPI,
    SearchIndexAPI,
    SearchPlanAPI,
    SearchRunAPI,
    SearchSourcesAPI,
)


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def search_index_payload(
    *,
    query: str,
    case: str,
    source: str | None = None,
    limit: int = 25,
) -> dict[str, Any]:
    db_path = settings.db_path(case)
    if not Path(db_path).exists():
        raise HTTPException(404, f"case '{case}' not found")
    source_ids = [item.strip() for item in source.split(",") if item.strip()] if source else None
    rows = search_fts_index(
        db_path,
        query,
        case_name=case,
        source_ids=source_ids,
        limit=limit,
    )
    return {
        "query": query,
        "case": case,
        "db_path": str(db_path),
        "count": len(rows),
        "results": rows,
    }


def search_index_view_html(
    *,
    query: str = "",
    case: str = "",
    source: str | None = None,
    limit: int = 25,
) -> str:
    rows: list[dict[str, object]] = []
    error = ""
    if query and case:
        try:
            rows = search_index_payload(query=query, case=case, source=source, limit=limit)["results"]
        except Exception as exc:
            error = str(getattr(exc, "detail", exc))
    source_value = source or ""
    result_rows = "".join(
        "<tr>"
        f"<td>{_e(row.get('source_id'))}</td>"
        f"<td>{_e(row.get('entity_type'))}</td>"
        f"<td>{_e(row.get('matched_entity'))}</td>"
        f"<td><a href=\"{_e(row.get('url'))}\" target=\"_blank\" rel=\"noopener\">{_e(row.get('title') or row.get('url'))}</a></td>"
        f"<td>{_e(row.get('confidence_score'))}</td>"
        "</tr>"
        for row in rows
    )
    if not result_rows:
        result_rows = '<tr><td colspan="5" class="muted">No indexed results.</td></tr>'
    error_html = f'<p class="error">{_e(error)}</p>' if error else ""
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BEDNIIOSINT Index Search</title>
<style>
body {{ font-family: system-ui, -apple-system, Segoe UI, sans-serif; margin: 24px; color: #172033; }}
form {{ display: grid; grid-template-columns: minmax(180px, 1fr) minmax(240px, 2fr) minmax(160px, 1fr) auto; gap: 8px; align-items: end; }}
label {{ display: grid; gap: 4px; font-size: 13px; color: #556070; }}
input {{ padding: 10px 12px; border: 1px solid #c9d2df; border-radius: 6px; font: inherit; }}
button {{ padding: 10px 14px; border: 0; border-radius: 6px; background: #185abc; color: white; font: inherit; cursor: pointer; }}
table {{ width: 100%; border-collapse: collapse; margin-top: 20px; }}
th, td {{ padding: 10px; border-bottom: 1px solid #e3e8ef; text-align: left; vertical-align: top; }}
th {{ font-size: 12px; text-transform: uppercase; color: #667085; }}
.muted {{ color: #667085; }}
.error {{ color: #b42318; }}
@media (max-width: 800px) {{ form {{ grid-template-columns: 1fr; }} }}
</style>
</head>
<body>
<main>
<h1>Index Search</h1>
<form method="get" action="/search/index/view">
<label>Case<input name="case" value="{_e(case)}" required></label>
<label>Query<input name="query" value="{_e(query)}" required></label>
<label>Source<input name="source" value="{_e(source_value)}" placeholder="github,api:rdap"></label>
<button type="submit">Search</button>
</form>
{error_html}
<table>
<tr><th>Source</th><th>Type</th><th>Matched</th><th>Result</th><th>Confidence</th></tr>
{result_rows}
</table>
</main>
</body>
</html>"""


if APIRouter is not None:
    router = APIRouter()

    @router.get("/search/plan", response_model=SearchPlanAPI)
    def search_plan_api(
        target: str,
        entity_type: str | None = None,
        scope: str | None = None,
        max_sources: int | None = None,
        include_auth_required: bool = False,
        source: str | None = None,
    ):
        source_ids = [item.strip() for item in source.split(",") if item.strip()] if source else None
        return plan_search(
            target,
            entity_type=entity_type,
            scope=scope,
            max_sources=max_sources,
            include_auth_required=include_auth_required,
            source_ids=source_ids,
        ).as_dict()

    @router.get("/search/run", response_model=SearchRunAPI)
    def search_run_api(
        target: str,
        entity_type: str | None = None,
        scope: str | None = None,
        max_sources: int | None = None,
        include_auth_required: bool = False,
        source: str | None = None,
        configured_only: bool = False,
        save: bool = False,
        case: str | None = None,
        cache_ttl: int = 0,
        cache_ttl_source: str | None = None,
        request_budget: str | None = None,
        budget_preset: str = "none",
        timeout: float | None = None,
        rate_limit_delay: float | None = None,
        concurrent: bool = False,
        max_workers: int = 4,
        include_dorking: bool = True,
        include_username_scan: bool = False,
        dry_run: bool = False,
        explain: bool = False,
        compact: bool = True,
    ):
        source_ids = [item.strip() for item in source.split(",") if item.strip()] if source else None
        if dry_run or explain:
            return explain_search_run(
                target,
                entity_type=entity_type,
                scope=scope,
                max_sources=max_sources,
                include_auth_required=include_auth_required,
                source_ids=source_ids,
                configured_only=configured_only,
                compact=compact,
            )
        try:
            budget = resolve_rate_limit_budget(request_budget, preset=budget_preset)
            cache_ttls = merge_cache_ttl_presets(parse_cache_ttl_by_source(cache_ttl_source))
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise HTTPException(
                400,
                "request_budget/cache_ttl_source must be valid and budget_preset must be valid",
            ) from exc
        context = SourceRunContext(
            scope=scope or "public_osint",
            timeout=timeout if timeout is not None else settings.timeout,
            rate_limit_delay=rate_limit_delay
            if rate_limit_delay is not None
            else settings.http_rate_limit_delay,
            cache_enabled=cache_ttl > 0 or bool(cache_ttls),
            cache_ttl_seconds=max(0, int(cache_ttl)),
            cache_ttl_by_source=cache_ttls,
            request_budget=budget,
        )
        return run_planned_search_pipeline(
            target,
            entity_type=entity_type,
            scope=scope,
            max_sources=max_sources,
            include_auth_required=include_auth_required,
            source_ids=source_ids,
            available_only=configured_only,
            save=save,
            case_name=case,
            context=context,
            concurrent=concurrent,
            max_workers=max_workers,
            include_dorking=include_dorking,
            include_username_scan=include_username_scan,
        )

    @router.get("/search/sources", response_model=SearchSourcesAPI)
    def search_sources_api(
        entity_type: str | None = None,
        scope: str | None = None,
        category: str | None = None,
        compact: bool = True,
    ):
        status = search_sources_status(compact=compact)
        allowed_ids = {
            str(source.get("id") or "")
            for source in filter_sources(entity_type=entity_type, scope=scope, category=category)
        }
        status["sources"] = [
            row for row in status["sources"] if str(row.get("source_id") or "") in allowed_ids
        ]
        status["summary"] = {
            **status["summary"],
            "filtered": len(status["sources"]),
        }
        return status

    @router.get("/search/index", response_model=SearchIndexAPI)
    def search_index_api(
        query: str = Query(..., description="Full-text query over saved search results"),
        case: str = Query(..., description="Saved case name"),
        source: str | None = Query(None, description="Comma-separated source_id filter"),
        limit: int = Query(25, ge=1, le=500),
    ):
        return search_index_payload(query=query, case=case, source=source, limit=limit)

    @router.get("/search/index/view", response_class=HTMLResponse)
    def search_index_view(
        query: str = "",
        case: str = "",
        source: str | None = None,
        limit: int = Query(25, ge=1, le=500),
    ):
        return HTMLResponse(
            search_index_view_html(query=query, case=case, source=source, limit=limit)
        )

    @router.get("/search/investigate")
    def search_investigate_api(
        target: str = Query(..., description="Selector: username/email/domain/ip/phone/url"),
        entity_type: str | None = Query(None),
        scope: str | None = Query(None),
        max_depth: int | None = Query(None, ge=0, le=4),
        max_nodes: int | None = Query(None, ge=1, le=100),
        min_pivot_confidence: float | None = Query(None, ge=0.0, le=1.0),
        include_dorking: bool = Query(False),
        include_username_scan: bool = Query(True),
        concurrent: bool = Query(True),
        save: bool = Query(False),
        case: str | None = Query(None),
    ):
        return run_recursive_investigation(
            target,
            entity_type=entity_type,
            scope=scope,
            max_depth=max_depth,
            max_nodes=max_nodes,
            min_pivot_confidence=min_pivot_confidence,
            include_dorking=include_dorking,
            include_username_scan=include_username_scan,
            concurrent=concurrent,
            save=save,
            case_name=case,
        )

    @router.get("/search/investigate/graph")
    def search_investigate_graph_api(
        target: str = Query(..., description="Selector: username/email/domain/ip/phone/url"),
        entity_type: str | None = Query(None),
        scope: str | None = Query(None),
        max_depth: int | None = Query(None, ge=0, le=4),
        max_nodes: int | None = Query(None, ge=1, le=100),
        min_pivot_confidence: float | None = Query(None, ge=0.0, le=1.0),
        include_dorking: bool = Query(False),
        include_username_scan: bool = Query(True),
        concurrent: bool = Query(True),
        save: bool = Query(False),
        case: str | None = Query(None),
        fmt: str = Query("html", description="html or cytoscape"),
    ):
        payload = run_recursive_investigation(
            target,
            entity_type=entity_type,
            scope=scope,
            max_depth=max_depth,
            max_nodes=max_nodes,
            min_pivot_confidence=min_pivot_confidence,
            include_dorking=include_dorking,
            include_username_scan=include_username_scan,
            concurrent=concurrent,
            save=save,
            case_name=case,
        )
        selected = fmt.strip().lower()
        if selected == "html":
            return HTMLResponse(investigation_graph_html(payload))
        if selected in {"cytoscape", "json"}:
            return investigation_graph_cytoscape(payload)
        raise HTTPException(400, "fmt must be html or cytoscape")

    @router.get("/search/investigate/timeline")
    def search_investigate_timeline_api(
        target: str = Query(..., description="Selector: username/email/domain/ip/phone/url"),
        entity_type: str | None = Query(None),
        scope: str | None = Query(None),
        max_depth: int | None = Query(None, ge=0, le=4),
        max_nodes: int | None = Query(None, ge=1, le=100),
        min_pivot_confidence: float | None = Query(None, ge=0.0, le=1.0),
        include_dorking: bool = Query(False),
        include_username_scan: bool = Query(True),
        concurrent: bool = Query(True),
        save: bool = Query(False),
        case: str | None = Query(None),
        fmt: str = Query("json", description="json or markdown"),
    ):
        payload = run_recursive_investigation(
            target,
            entity_type=entity_type,
            scope=scope,
            max_depth=max_depth,
            max_nodes=max_nodes,
            min_pivot_confidence=min_pivot_confidence,
            include_dorking=include_dorking,
            include_username_scan=include_username_scan,
            concurrent=concurrent,
            save=save,
            case_name=case,
        )
        selected = fmt.strip().lower()
        if selected == "json":
            return {"timeline": build_timeline(payload), "seed": payload.get("seed") or {}}
        if selected in {"markdown", "md"}:
            return PlainTextResponse(timeline_markdown(payload), media_type="text/markdown")
        raise HTTPException(400, "fmt must be json or markdown")

    @router.get("/search/playbooks")
    def search_playbooks_api():
        return {"playbooks": list_playbooks()}

    @router.get("/search/playbook/run")
    def search_playbook_run_api(
        playbook: str = Query(...),
        target: str = Query(...),
        entity_type: str | None = Query(None),
        save: bool = Query(False),
        case: str | None = Query(None),
    ):
        try:
            return run_playbook(playbook, target, entity_type=entity_type, save=save, case_name=case)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @router.get("/investigation/plan", response_model=InvestigationPlanAPI)
    def investigation_plan_api(
        target: str,
        entity_type: str | None = None,
    ):
        return build_investigation_plan(target, entity_type=entity_type)

    @router.get("/pipeline/sources/{input_type}", response_model=PipelineSourcesAPI)
    def pipeline_sources_api(input_type: str, limit: int | None = None):
        return {
            "input_type": input_type,
            "sources": pipeline_sources(input_type, limit=limit),
        }

    @router.get("/pipeline/run", response_model=PipelineRunAPI)
    def pipeline_run_api(
        target: str,
        input_type: str | None = None,
        sources: str | None = None,
        limit: int | None = None,
        configured_only: bool = False,
        save: bool = False,
        case: str | None = None,
        cache_ttl: int = 0,
        cache_ttl_source: str | None = None,
        request_budget: str | None = None,
        budget_preset: str = "none",
        timeout: float | None = None,
        rate_limit_delay: float | None = None,
        scope: str = "public_osint",
        public_only: bool = False,
        max_terms_risk: str | None = None,
        allow_sensitive_sources: bool = False,
        allow_uploads: bool = False,
        allow_active_checks: bool = False,
    ):
        source_ids = (
            [item.strip() for item in sources.split(",") if item.strip()]
            if sources
            else None
        )
        try:
            budget = resolve_rate_limit_budget(request_budget, preset=budget_preset)
            cache_ttls = merge_cache_ttl_presets(
                parse_cache_ttl_by_source(cache_ttl_source),
                source_ids=source_ids,
            )
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise HTTPException(
                400,
                "request_budget/cache_ttl_source must be valid and budget_preset must be valid",
            ) from exc
        context = SourceRunContext(
            scope=scope,
            timeout=timeout if timeout is not None else settings.timeout,
            rate_limit_delay=rate_limit_delay
            if rate_limit_delay is not None
            else settings.http_rate_limit_delay,
            cache_enabled=cache_ttl > 0 or bool(cache_ttls),
            cache_ttl_seconds=max(0, int(cache_ttl)),
            cache_ttl_by_source=cache_ttls,
            request_budget=budget,
            legal_flags={
                "public_only": public_only,
                "max_terms_risk": max_terms_risk,
                "allow_sensitive_sources": allow_sensitive_sources,
                "allow_uploads": allow_uploads,
                "allow_active_checks": allow_active_checks,
            },
        )
        return run_source_pipeline(
            target,
            input_type=input_type,
            source_ids=source_ids,
            limit=limit,
            available_only=configured_only,
            save=save,
            case_name=case,
            context=context,
        ).as_dict()

else:  # pragma: no cover
    router = None
