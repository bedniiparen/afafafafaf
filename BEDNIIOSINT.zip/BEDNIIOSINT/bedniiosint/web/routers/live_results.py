from __future__ import annotations

from html import escape
from urllib.parse import parse_qs, quote

try:
    from fastapi import APIRouter, HTTPException, Request
    from fastapi.responses import HTMLResponse, Response
except Exception:  # pragma: no cover
    APIRouter = None
    HTTPException = Exception
    Request = None
    HTMLResponse = None
    Response = None

from ...core.live_plan import live_validation_plan
from ...core.live_validation_results import (
    cleanup_live_validation_results,
    export_live_validation_history,
    live_validation_audit_history,
    live_validation_export_hash,
    live_validation_history,
    record_live_validation_audit_event,
)
from ..assets import asset_tags
from ..schemas import (
    LiveValidationAuditEnvelopeAPI,
    LiveValidationCleanupEnvelopeAPI,
    LiveValidationHistoryEnvelopeAPI,
)
from ..security import CSRF_FIELD, csrf_token


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _header_html() -> str:
    return (
        '<header><div class="topbar">'
        '<a class="brand" href="/"><span class="brand-mark">B</span><span>BEDNIIOSINT</span></a>'
        '<nav>'
        '<a class="nav" href="/">Search</a>'
        '<a class="nav" href="/history">History</a>'
        '<a class="nav" href="/sources">Sources</a>'
        '<a class="nav" href="/monitoring">Monitoring</a>'
        '<a class="nav active" href="/live-results/view">Live Results</a>'
        '<a class="nav" href="/jobs">Jobs</a>'
        '<a class="nav" href="/reports">Reports</a>'
        '<div class="theme-switch" role="group" aria-label="Theme">'
        '<button class="theme-button" id="themeToggle" type="button" data-theme-toggle '
        'aria-pressed="false" title="Switch theme">Theme</button>'
        '</div>'
        '</nav></div></header>'
    )


def _csrf_input() -> str:
    token = csrf_token()
    return f'<input type="hidden" name="{_e(CSRF_FIELD)}" value="{_e(token)}">'


def live_results_html(
    *,
    source: str | None = None,
    run_id: str | None = None,
    limit: int = 100,
    message: str = "",
    is_error: bool = False,
) -> str:
    limit = max(1, min(int(limit or 100), 500))
    history = live_validation_history(source_id=source, run_id=run_id, limit=limit)
    audit = live_validation_audit_history(source_id=source, run_id=run_id, limit=20)
    summary = history.get("summary") or {}
    audit_summary = audit.get("summary") or {}
    rows = list(history.get("results") or [])
    source_value = _e(source or "")
    run_value = _e(run_id or "")
    query_bits = []
    if source:
        query_bits.append(f"source={quote(source)}")
    if run_id:
        query_bits.append(f"run_id={quote(run_id)}")
    query_bits.append(f"limit={limit}")
    query = "&".join(query_bits)
    json_href = f"/live-results?{query}" if query else "/live-results"
    export_base = f"/live-results/export?{query}&" if query else "/live-results/export?"
    cleanup_base = f"/live-results/cleanup?{query}&" if query else "/live-results/cleanup?"
    notice = (
        f'<div class="status {"bad" if is_error else "exists"}">{_e(message)}</div>'
        if message
        else ""
    )
    row_html = []
    for row in rows:
        redacted = "yes" if row.get("redacted") else "no"
        network = "yes" if row.get("network_required") else "no"
        opt_in = "yes" if row.get("allow_opt_in") else "no"
        status = str(row.get("status") or "unknown")
        status_class = "exists" if status == "passed" else "low" if status == "skipped" else ""
        row_html.append(
            "<tr>"
            f"<td>{_e(row.get('recorded_at'))}</td>"
            f"<td><span class=\"badge\">{_e(row.get('run_id'))}</span></td>"
            f"<td>{_e(row.get('source_id'))}<div class=\"muted\">{_e(row.get('name'))}</div></td>"
            f"<td>{_e(row.get('mode'))}</td>"
            f"<td><span class=\"status {status_class}\">{_e(status)}</span><div class=\"muted\">{_e(row.get('reason'))}</div></td>"
            f"<td>{_e(row.get('target') or 'not recorded')}</td>"
            f"<td>{_e(row.get('verification_status'))}<div class=\"muted\">health {_e(row.get('health_status'))}</div></td>"
            f"<td>{_e(network)}</td>"
            f"<td>{_e(opt_in)}</td>"
            f"<td>{_e(redacted)}</td>"
            "</tr>"
        )
    body = "".join(row_html) or '<tr><td colspan="10" class="muted">No live validation results recorded.</td></tr>'
    audit_rows = []
    for row in audit.get("results") or []:
        audit_rows.append(
            "<tr>"
            f"<td>{_e(row.get('created_at'))}</td>"
            f"<td>{_e(row.get('action'))}</td>"
            f"<td>{_e(row.get('channel'))}</td>"
            f"<td>{_e(row.get('run_id'))}</td>"
            f"<td>{_e(row.get('source_id'))}</td>"
            f"<td>{_e(row.get('matched'))}</td>"
            f"<td>{_e(row.get('affected'))}</td>"
            f"<td>{_e(row.get('export_format'))}</td>"
            f"<td>{_e(row.get('output_path'))}</td>"
            f"<td>{_e(str(row.get('output_sha256') or '')[:16])}</td>"
            "</tr>"
        )
    audit_body = "".join(audit_rows) or '<tr><td colspan="10" class="muted">No live validation audit events recorded.</td></tr>'
    csrf = _csrf_input()
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{_e(csrf_token())}">
<title>BEDNIIOSINT Live Results</title>
{asset_tags()}
</head>
<body>
{_header_html()}
<main>
<div class="page-head">
  <div>
    <h1>Live Validation Results</h1>
    <div class="muted">Persisted opt-in validation history. No provider network calls are made from this page.</div>
    <div class="muted">Retention guidance: keep only records needed for provider-account validation and delete old local databases according to the investigation retention policy.</div>
  </div>
  <div class="actions">
    <a class="btn" href="{_e(json_href)}" target="_blank">JSON</a>
    <a class="btn" href="{_e(export_base)}format=csv" target="_blank">CSV</a>
    <a class="btn" href="{_e(export_base)}format=markdown" target="_blank">Markdown</a>
    <a class="btn" href="/live-results/audit" target="_blank">Audit JSON</a>
    <a class="btn" href="/live-plan" target="_blank">Live Plan</a>
  </div>
</div>
{notice}
<section class="search-panel">
  <form class="search-form" method="get" action="/live-results/view">
    <label>Source<input name="source" value="{source_value}" placeholder="api:crtsh"></label>
    <label>Execution ID<input name="run_id" value="{run_value}" placeholder="provider-check-001"></label>
    <label>Limit<input name="limit" type="number" min="1" max="500" value="{_e(limit)}"></label>
    <button type="submit">Filter</button>
  </form>
</section>
<section class="search-panel">
  <div class="section-head">
    <div>
      <h2>Retention Cleanup</h2>
      <div class="muted">Dry-run by default. Check Apply only after exporting the rows you need to retain.</div>
    </div>
    <a class="btn small" href="{_e(cleanup_base)}older_than_days=30" target="_blank">Dry-run JSON</a>
  </div>
  <form class="search-form" method="post" action="/live-results/cleanup">
    {csrf}
    <label>Source<input name="source" value="{source_value}" placeholder="api:crtsh"></label>
    <label>Execution ID<input name="run_id" value="{run_value}" placeholder="provider-check-001"></label>
    <label>Older than days<input name="older_than_days" type="number" min="0" placeholder="30"></label>
    <label>Before ISO time<input name="before" placeholder="2026-01-01T00:00:00+00:00"></label>
    <label>Apply<input type="checkbox" name="apply" value="1"></label>
    <button type="submit">Cleanup</button>
  </form>
</section>
<section class="panel">
  <div class="cards">
    <div class="card"><div class="n">{_e(summary.get("rows", 0))}</div><div class="l">Rows</div></div>
    <div class="card"><div class="n">{_e(summary.get("sources", 0))}</div><div class="l">Sources</div></div>
    <div class="card"><div class="n">{_e(summary.get("network_required", 0))}</div><div class="l">Network rows</div></div>
    <div class="card"><div class="n">{_e(summary.get("redacted_rows", 0))}</div><div class="l">Redacted rows</div></div>
  </div>
  <div class="table-shell">
    <table>
      <tr><th>Recorded</th><th>Execution</th><th>Source</th><th>Mode</th><th>Status</th><th>Target</th><th>Verification</th><th>Network</th><th>Opt-in</th><th>Redacted</th></tr>
      {body}
    </table>
  </div>
</section>
<section class="panel">
  <div class="section-head">
    <div>
      <h2>Audit Evidence</h2>
      <div class="muted">{_e(audit_summary.get("rows", 0))} audit events for export and cleanup actions. Secret values are not recorded.</div>
    </div>
    <a class="btn small" href="/live-results/audit" target="_blank">Audit JSON</a>
  </div>
  <div class="table-shell">
    <table>
      <tr><th>Created</th><th>Action</th><th>Channel</th><th>Execution</th><th>Source</th><th>Matched</th><th>Affected</th><th>Format</th><th>Output</th><th>SHA-256</th></tr>
      {audit_body}
    </table>
  </div>
</section>
</main>
<script src="/static/app.js?v=20260608" defer></script>
</body>
</html>"""


if APIRouter is not None:
    router = APIRouter()

    @router.get("/live-plan")
    def live_plan_api():
        return live_validation_plan()

    @router.get("/live-results", response_model=LiveValidationHistoryEnvelopeAPI)
    def live_results_api(
        source: str | None = None,
        run_id: str | None = None,
        limit: int = 100,
    ):
        return live_validation_history(source_id=source, run_id=run_id, limit=limit)

    @router.get("/live-results/view", response_class=HTMLResponse)
    def live_results_page(
        source: str | None = None,
        run_id: str | None = None,
        limit: int = 100,
    ):
        return HTMLResponse(live_results_html(source=source, run_id=run_id, limit=limit))

    @router.get("/live-results/export")
    def live_results_export_api(
        source: str | None = None,
        run_id: str | None = None,
        limit: int = 100,
        format: str = "json",
    ):
        history = live_validation_history(source_id=source, run_id=run_id, limit=limit)
        try:
            content, content_type = export_live_validation_history(history, export_format=format)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        digest = live_validation_export_hash(content)
        audit_event = record_live_validation_audit_event(
            action="export",
            channel="web",
            source_id=source,
            run_id=run_id,
            filters={"source_id": source or "", "run_id": run_id or "", "limit": limit},
            export_format=format,
            matched=int(history["summary"].get("rows") or 0),
            affected=int(history["summary"].get("returned") or 0),
            output_path="http-download",
            output_sha256=str(digest["sha256"]),
            output_bytes=int(digest["bytes"]),
        )
        extension = "md" if format.lower() in {"md", "markdown"} else format.lower()
        filename = f"bedniiosint-live-results.{extension}"
        return Response(
            content,
            media_type=content_type,
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "X-BEDNIIOSINT-Export-SHA256": str(digest["sha256"]),
                "X-BEDNIIOSINT-Export-Bytes": str(digest["bytes"]),
                "X-BEDNIIOSINT-Audit-Event-ID": str(audit_event.get("id") or ""),
            },
        )

    @router.get("/live-results/cleanup", response_model=LiveValidationCleanupEnvelopeAPI)
    def live_results_cleanup_api(
        source: str | None = None,
        run_id: str | None = None,
        older_than_days: int | None = None,
        before: str | None = None,
    ):
        return cleanup_live_validation_results(
            source_id=source,
            run_id=run_id,
            older_than_days=older_than_days,
            before=before,
            apply=False,
            channel="web",
        )

    @router.get("/live-results/audit", response_model=LiveValidationAuditEnvelopeAPI)
    def live_results_audit_api(
        action: str | None = None,
        source: str | None = None,
        run_id: str | None = None,
        limit: int = 100,
    ):
        return live_validation_audit_history(
            action=action,
            source_id=source,
            run_id=run_id,
            limit=limit,
        )

    @router.post("/live-results/cleanup", response_class=HTMLResponse)
    async def live_results_cleanup_post(request: Request):
        body = (await request.body()).decode("utf-8", errors="replace")
        fields = parse_qs(body, keep_blank_values=True)
        source = fields.get("source", [""])[0].strip() or None
        run_id = fields.get("run_id", [""])[0].strip() or None
        before = fields.get("before", [""])[0].strip() or None
        older_raw = fields.get("older_than_days", [""])[0].strip()
        apply_cleanup = fields.get("apply", [""])[0] == "1"
        try:
            older_than_days = int(older_raw) if older_raw else None
        except ValueError:
            return HTMLResponse(
                live_results_html(
                    source=source,
                    run_id=run_id,
                    message="older_than_days must be an integer",
                    is_error=True,
                )
            )
        try:
            cleanup = cleanup_live_validation_results(
                source_id=source,
                run_id=run_id,
                older_than_days=older_than_days,
                before=before,
                apply=apply_cleanup,
                channel="web",
            )
        except ValueError as exc:
            return HTMLResponse(
                live_results_html(
                    source=source,
                    run_id=run_id,
                    message=str(exc),
                    is_error=True,
                )
            )
        summary = cleanup["summary"]
        message = (
            f"Cleanup {'deleted' if apply_cleanup else 'matched'} "
            f"{summary.get('deleted') if apply_cleanup else summary.get('matched')} rows."
        )
        return HTMLResponse(live_results_html(source=source, run_id=run_id, message=message))

else:
    router = None
