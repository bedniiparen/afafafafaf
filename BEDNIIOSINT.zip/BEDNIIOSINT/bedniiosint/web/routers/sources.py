from __future__ import annotations

from html import escape
from pathlib import Path

try:
    from fastapi import APIRouter
    from fastapi.responses import HTMLResponse
except Exception:  # pragma: no cover
    APIRouter = None
    HTMLResponse = None

from ...catalog import (
    api_key_status,
    filter_registry,
    registry_summary,
    source_health,
    source_health_summary,
    source_maintenance_report,
    verify_sources,
)
from ...config import DEFAULT_SITES_FILE
from ...modules.username.scanner import (
    load_sites as load_username_sites,
    select_sites as select_username_sites,
    site_catalog_stats as username_site_catalog_stats,
)
from ...search.readiness import search_sources_status
from ..schemas import (
    SourceHealthEnvelopeAPI,
    SourceMaintenanceEnvelopeAPI,
    SourceVerificationEnvelopeAPI,
    UsernameSourcesAPI,
)
from ..assets import asset_tags
from ..templating import TEMPLATE_ENV, safe_markup


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _header_html(active: str = "sources") -> str:
    def nav_item(label: str, href: str, key: str) -> str:
        cls = "nav active" if active == key else "nav"
        return f'<a class="{cls}" href="{href}">{_e(label)}</a>'

    return (
        "<header><div class=\"topbar\">"
        "<a class=\"brand\" href=\"/\">"
        "<span class=\"brand-mark\">B</span><span>BEDNIIOSINT</span>"
        "</a><nav>"
        f"{nav_item('Search', '/', 'search')}"
        f"{nav_item('History', '/history', 'history')}"
        f"{nav_item('Jobs', '/jobs', 'jobs')}"
        f"{nav_item('Sources', '/sources', 'sources')}"
        f"{nav_item('Plugins', '/plugins', 'plugins')}"
        f"{nav_item('Reports', '/reports', 'reports')}"
        '<div class="theme-switch" role="group" aria-label="Theme">'
        '<button class="theme-button" id="themeToggle" type="button" '
        'data-theme-toggle aria-pressed="false" title="Switch theme">Theme</button>'
        "</div></nav></div></header>"
    )


def _source_page_context(
    *,
    input_type: str | None = None,
    auth: str | None = None,
    kind: str | None = None,
    runnable: bool | None = None,
) -> dict:
    summary = registry_summary()
    health_summary = source_health_summary()
    maintenance_report = source_maintenance_report(fixture_dir=Path("tests/fixtures/sources"))
    search_status = search_sources_status(compact=True)
    health_by_source = {row.source_id: row for row in source_health()}
    rows = []
    for source in filter_registry(
        input_type=input_type,
        auth=auth,
        kind=kind,
        runnable=runnable,
    ):
        health = health_by_source.get(source.id)
        health_status = health.status if health else "unknown"
        health_class = (
            "exists"
            if health_status == "available"
            else "low"
            if health_status == "catalog_only"
            else ""
        )
        rows.append(
            {
                **source.as_dict(),
                "inputs_text": ", ".join(source.inputs),
                "env_vars_text": ", ".join(source.env_vars),
                "configured_text": "yes" if source.configured else ", ".join(source.env_vars),
                "opt_in_text": "yes" if source.requires_opt_in else "no",
                "health_status": health_status,
                "health_reason": health.reason if health else "",
                "health_class": health_class,
                "remediation": health.remediation if health else "",
                "verification_status": health.verification_status if health else "unknown",
                "contract_gaps_text": ", ".join(health.contract_gaps) if health else "",
            }
        )
    return {
        "summary": summary,
        "health_summary": health_summary,
        "maintenance_report": maintenance_report,
        "maintenance_summary": maintenance_report["summary"],
        "target_coverage": search_status["summary"].get("coverage_by_target_type", []),
        "sources": rows,
        "filters": {
            "input_type": input_type or "",
            "auth": auth or "",
            "kind": kind or "",
            "runnable": bool(runnable),
        },
    }


def sources_html(
    input_type: str | None = None,
    auth: str | None = None,
    kind: str | None = None,
    runnable: bool | None = None,
) -> str:
    context = _source_page_context(
        input_type=input_type,
        auth=auth,
        kind=kind,
        runnable=runnable,
    )
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("sources.html").render(
            **context,
            asset_tags=safe_markup(asset_tags()),
            header=safe_markup(_header_html("sources")),
        )
    return _sources_html_fallback(context)


def _sources_html_fallback(context: dict) -> str:
    summary = context["summary"]
    health_summary = context["health_summary"]
    maintenance_summary = context["maintenance_summary"]
    filters = context["filters"]
    rows = "".join(_source_row_fallback(row) for row in context["sources"])
    if not rows:
        rows = '<tr><td colspan="20" class="muted">No sources match this filter.</td></tr>'
    runnable_checked = " checked" if filters["runnable"] else ""
    target_coverage_html = _target_coverage_html_fallback(context["target_coverage"])
    maintenance_html = _sources_maintenance_html_fallback(context["maintenance_report"])
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BEDNIIOSINT Sources</title>
{asset_tags()}
</head>
<body>
{_header_html("sources")}
<main>
<div class="page-head">
  <div>
    <h1>Sources</h1>
    <div class="muted">{_e(summary["sources"])} sources | {_e(summary["runnable"])} runnable | {_e(summary["configured"])} configured | {_e(summary["auth_required"])} require auth | {_e(summary["typed_parsers"])} typed parsers</div>
    <div class="muted">Health: {_e(health_summary["statuses"]["available"])} available | {_e(health_summary["statuses"]["missing_keys"])} missing keys | {_e(health_summary["statuses"]["catalog_only"])} catalog only</div>
    <div class="muted">Verification: {_e(health_summary["verification_statuses"].get("fixture_ready", 0))} fixture ready | {_e(health_summary["verification_statuses"].get("needs_api_key", 0))} need keys | {_e(health_summary["contract_gaps"])} contract gaps</div>
    <div class="muted">Maintenance: score {_e(maintenance_summary["average_readiness_score"])} | {_e(maintenance_summary["action_required"])} action required | {_e(maintenance_summary["watch"])} watch | live ready {_e(maintenance_summary["live_readiness"].get("ready", 0))}</div>
  </div>
  <div class="actions">
    <a class="btn" href="/sources/health" target="_blank">Health JSON</a>
    <a class="btn" href="/sources/maintenance" target="_blank">Maintenance JSON</a>
  </div>
</div>
{target_coverage_html}
{maintenance_html}
<section class="search-panel">
  <form class="search-form" method="get" action="/sources">
    <label>Input type<input name="input_type" value="{_e(filters["input_type"])}" placeholder="domain, email, ip"></label>
    <label>Kind<input name="kind" value="{_e(filters["kind"])}" placeholder="module, api"></label>
    <label>Auth<input name="auth" value="{_e(filters["auth"])}" placeholder="none, api_key"></label>
    <label>Runnable only<input type="checkbox" name="runnable" value="true"{runnable_checked}></label>
    <button type="submit">Filter</button>
  </form>
</section>
<div class="table-shell">
<table>
<tr><th>ID</th><th>Name</th><th>Kind</th><th>Inputs</th><th>Auth</th><th>Runnable</th><th>Configured</th><th>Health</th><th>Remediation</th><th>Verification</th><th>Maturity</th><th>Priority</th><th>Value</th><th>Terms Risk</th><th>Opt-in</th><th>Quota</th><th>Setup</th><th>Adapter</th><th>Endpoints</th><th>Docs</th></tr>
{rows}
</table>
</div>
</main>
</body>
</html>"""


def _target_coverage_html_fallback(coverage: list[dict]) -> str:
    rows = []
    for row in coverage:
        status_class = "exists" if row.get("configuration_gap") == 0 else ""
        missing = list(row.get("missing_env_vars") or [])
        missing_text = ", ".join(str(item) for item in missing[:4])
        if len(missing) > 4:
            missing_text += ", ..."
        rows.append(
            "<tr>"
            f"<td><span class=\"badge\">{_e(row.get('target_type'))}</span></td>"
            f"<td><span class=\"status {status_class}\">{_e(row.get('configured_label'))}</span></td>"
            f"<td>{_e(row.get('implemented'))}/{_e(row.get('sources'))}</td>"
            f"<td>{_e(row.get('runnable'))}</td>"
            f"<td>{_e(row.get('auth_required'))}</td>"
            f"<td>{_e(missing_text)}</td>"
            "</tr>"
        )
    body = "".join(rows) or '<tr><td colspan="6" class="muted">No target coverage data.</td></tr>'
    return f"""
<section class="panel">
  <div class="section-head">
    <div>
      <h2>Target Coverage</h2>
      <div class="muted">Configured search sources by target type.</div>
    </div>
    <a class="btn small" href="/search/sources?compact=true" target="_blank">Search Sources JSON</a>
  </div>
  <div class="table-shell">
    <table>
      <tr><th>Target</th><th>Configured</th><th>Implemented</th><th>Runnable</th><th>Requires auth</th><th>Missing keys</th></tr>
      {body}
    </table>
  </div>
</section>"""


def _source_row_fallback(row: dict) -> str:
    runnable = '<span class="status exists">yes</span>' if row.get("runnable") else '<span class="muted">no</span>'
    configured = (
        '<span class="status exists">yes</span>'
        if row.get("configured")
        else _e(row.get("env_vars_text"))
    )
    docs = (
        f'<a href="{_e(row.get("docs_url"))}" target="_blank">Docs</a>'
        if row.get("docs_url")
        else ""
    )
    return (
        "<tr>"
        f"<td><span class=\"badge\">{_e(row.get('id'))}</span></td>"
        f"<td>{_e(row.get('name'))}</td>"
        f"<td>{_e(row.get('kind'))}</td>"
        f"<td>{_e(row.get('inputs_text'))}</td>"
        f"<td>{_e(row.get('auth'))}</td>"
        f"<td>{runnable}</td>"
        f"<td>{configured}</td>"
        f"<td><span class=\"status {_e(row.get('health_class'))}\">{_e(row.get('health_status'))}</span><div class=\"muted\">{_e(row.get('health_reason'))}</div></td>"
        f"<td>{_e(row.get('remediation'))}</td>"
        f"<td>{_e(row.get('verification_status'))}<div class=\"muted\">{_e(row.get('contract_gaps_text'))}</div></td>"
        f"<td>{_e(row.get('source_maturity'))}</td>"
        f"<td>{_e(row.get('priority'))}</td>"
        f"<td>{_e(row.get('product_value'))}</td>"
        f"<td>{_e(row.get('terms_risk'))}</td>"
        f"<td>{_e(row.get('opt_in_text'))}</td>"
        f"<td>{_e(row.get('quota_policy'))}</td>"
        f"<td>{_e(row.get('setup_hint'))}</td>"
        f"<td>{_e(row.get('adapter'))}</td>"
        f"<td>{_e(row.get('endpoints'))}</td>"
        f"<td>{docs}</td>"
        "</tr>"
    )


def _sources_maintenance_html_fallback(report: dict) -> str:
    summary = report.get("summary") or {}
    fixture = summary.get("fixture_coverage") or {}
    live = summary.get("live_validation") or {}
    top_actions = list(report.get("top_actions") or [])[:10]
    rows = []
    for row in top_actions:
        docs = (
            f'<a href="{_e(row.get("docs_url"))}" target="_blank">Docs</a>'
            if row.get("docs_url")
            else ""
        )
        rows.append(
            "<tr>"
            f"<td><span class=\"badge\">{_e(row.get('source_id'))}</span><div class=\"muted\">{_e(row.get('name'))}</div></td>"
            f"<td>{_e(row.get('priority'))}</td>"
            f"<td>{_e(row.get('maintenance_status'))}</td>"
            f"<td>{_e(row.get('readiness_score'))}</td>"
            f"<td>{_e(row.get('live_readiness'))}</td>"
            f"<td>{_e(row.get('next_action'))}</td>"
            f"<td>{_e(', '.join(row.get('fixture_variants') or []))}</td>"
            f"<td>{docs}</td>"
            "</tr>"
        )
    body = "".join(rows) or '<tr><td colspan="8" class="muted">No maintenance actions found.</td></tr>'
    return f"""
<section class="panel">
  <div class="section-head">
    <div>
      <h2>Source Maintenance</h2>
      <div class="muted">Offline readiness view. No provider network calls are made.</div>
    </div>
    <a class="btn small" href="/live-plan" target="_blank">Live Plan</a>
    <a class="btn small" href="/live-results/view">Live Results</a>
  </div>
  <div class="cards">
    <div class="card"><div class="n">{_e(summary.get("average_readiness_score", 0))}</div><div class="l">Readiness score</div></div>
    <div class="card"><div class="n">{_e(summary.get("action_required", 0))}</div><div class="l">Action required</div></div>
    <div class="card"><div class="n">{_e(fixture.get("ok_coverage", 0))}</div><div class="l">OK fixture coverage</div></div>
    <div class="card"><div class="n">{_e(live.get("ready", 0))}</div><div class="l">Live sections ready</div></div>
  </div>
  <div class="table-shell">
    <table>
      <tr><th>Source</th><th>Priority</th><th>Status</th><th>Score</th><th>Live readiness</th><th>Next action</th><th>Fixtures</th><th>Docs</th></tr>
      {body}
    </table>
  </div>
</section>"""


if APIRouter is not None:
    router = APIRouter()

    @router.get("/sources", response_class=HTMLResponse)
    def sources_page(
        input_type: str | None = None,
        auth: str | None = None,
        kind: str | None = None,
        runnable: bool = False,
    ):
        return HTMLResponse(
            sources_html(
                input_type=input_type,
                auth=auth,
                kind=kind,
                runnable=True if runnable else None,
            )
        )

    @router.get("/sources/health", response_model=SourceHealthEnvelopeAPI)
    def sources_health_api():
        return {
            "summary": source_health_summary(),
            "sources": [row.as_dict() for row in source_health()],
            "api_keys": [row.as_dict() for row in api_key_status()],
        }

    @router.get("/sources/maintenance", response_model=SourceMaintenanceEnvelopeAPI)
    def sources_maintenance_api(
        fixture_dir: str | None = "tests/fixtures/sources",
    ):
        return source_maintenance_report(
            fixture_dir=Path(fixture_dir) if fixture_dir else None,
        )

    @router.get("/sources/verify", response_model=SourceVerificationEnvelopeAPI)
    def sources_verify_api(
        mode: str = "contract",
        source: str | None = None,
        input_type: str | None = None,
        kind: str | None = None,
        runnable: bool = False,
        target: str | None = None,
        fixture_dir: str | None = None,
        fixture: str = "ok",
        allow_opt_in: bool = False,
    ):
        return verify_sources(
            mode=mode,
            source_id=source,
            input_type=input_type,
            kind=kind,
            runnable=True if runnable else None,
            target=target,
            fixture_dir=Path(fixture_dir) if fixture_dir else None,
            fixture_name=fixture,
            allow_opt_in=allow_opt_in,
        )

    @router.get("/username/sources", response_model=UsernameSourcesAPI)
    def username_sources_api(
        category: str | None = None,
        site: str | None = None,
        offset: int = 0,
        limit: int | None = None,
        include_protected: bool = True,
    ):
        sites = load_username_sites(DEFAULT_SITES_FILE)
        categories = [item.strip() for item in category.split(",") if item.strip()] if category else None
        names = [item.strip() for item in site.split(",") if item.strip()] if site else None
        selected = select_username_sites(
            sites,
            categories=categories,
            names=names,
            include_protected=include_protected,
            offset=offset,
            limit=limit,
        )
        payload = username_site_catalog_stats(sites)
        payload["selected"] = len(selected)
        payload["selected_names"] = list(selected)
        return payload

else:
    router = None
