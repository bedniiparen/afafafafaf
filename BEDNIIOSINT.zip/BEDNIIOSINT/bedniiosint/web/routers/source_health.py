from __future__ import annotations

try:
    from fastapi import APIRouter
except Exception:  # pragma: no cover
    APIRouter = None

from ...search.source_health import GLOBAL_SOURCE_HEALTH
from ..schemas import SourceRuntimeHealthEnvelopeAPI


if APIRouter is not None:
    router = APIRouter()

    @router.get("/api/source-health", response_model=SourceRuntimeHealthEnvelopeAPI)
    def source_health():
        return {"sources": GLOBAL_SOURCE_HEALTH.snapshot()}

else:
    router = None
