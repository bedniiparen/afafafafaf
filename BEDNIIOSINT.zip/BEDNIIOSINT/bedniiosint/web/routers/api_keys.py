from __future__ import annotations

from html import escape
import os
from urllib.parse import parse_qs
from urllib.parse import quote

try:
    from fastapi import APIRouter, Request
    from fastapi.responses import HTMLResponse
except Exception:  # pragma: no cover
    APIRouter = None
    Request = None
    HTMLResponse = None

from ...catalog import api_key_setup_plan, api_key_status, source_health_summary
from ..assets import asset_tags, style_tag
from ..security import CSRF_FIELD, csrf_token
from ..templating import TEMPLATE_ENV, safe_markup


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _header_html(active: str = "keys") -> str:
    def nav_item(label: str, href: str, key: str) -> str:
        cls = "nav active" if active == key else "nav"
        return f'<a class="{cls}" href="{href}">{_e(label)}</a>'

    return (
        "<header><div class=\"topbar\">"
        "<a class=\"brand\" href=\"/\">"
        "<span class=\"brand-mark\">B</span><span>BEDNIIOSINT</span>"
        "</a><nav>"
        f"{nav_item('Search', '/', 'search')}"
        f"{nav_item('History', '/history', 'history')}"
        f"{nav_item('Jobs', '/jobs', 'jobs')}"
        f"{nav_item('Sources', '/sources', 'sources')}"
        f"{nav_item('Plugins', '/plugins', 'plugins')}"
        f"{nav_item('Reports', '/reports', 'reports')}"
        f"{nav_item('API Keys', '/api-keys', 'keys')}"
        '<div class="theme-switch" role="group" aria-label="Theme">'
        '<button class="theme-button" id="themeToggle" type="button" '
        'data-theme-toggle aria-pressed="false" title="Switch theme">Theme</button>'
        "</div></nav></div></header>"
    )


def api_keys_html(message: str = "", *, is_error: bool = False) -> str:
    from ...core.secret_store import SECRET_KEY_ENV, list_secrets

    keys = api_key_status()
    summary = source_health_summary()
    stored = {row["name"]: row for row in list_secrets()}
    key_names = sorted({key.name for key in keys} | set(stored))
    options = key_names or ["CUSTOM_API_KEY"]
    passphrase_ready = bool(os.getenv(SECRET_KEY_ENV, "").strip())
    status_note = (
        "encrypted store ready"
        if passphrase_ready
        else f"set {SECRET_KEY_ENV} before saving keys in the web UI"
    )
    rows = [_api_key_row_context(key, stored) for key in keys]
    for name in sorted(set(stored) - {key.name for key in keys}):
        rows.append(
            {
                "name": name,
                "status_html": '<span class="status exists">store</span>',
                "requirement": "custom",
                "sources": "not attached to catalog source",
                "delete_href": f"/api-keys/{quote(name, safe='')}/delete",
                "delete": True,
            }
        )
    setup = _api_key_setup_context()
    context = {
        "message": message,
        "is_error": is_error,
        "summary": summary,
        "status_note": status_note,
        "passphrase_ready": passphrase_ready,
        "secret_key_env": SECRET_KEY_ENV,
        "options": options,
        "rows": rows,
        "setup": setup,
        "csrf_name": CSRF_FIELD,
        "csrf_token": csrf_token(),
    }
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("api_keys.html").render(
            **context,
            asset_tags=safe_markup(asset_tags()),
            api_keys_style=safe_markup(style_tag("api-keys.css")),
            header=safe_markup(_header_html("keys")),
        )
    return _api_keys_html_fallback(context)


def _api_key_setup_context() -> dict:
    plan = api_key_setup_plan(priorities=("P1",), missing_only=True, include_optional=True)
    rows = []
    for row in plan["sources"][:12]:
        rows.append(
            {
                "source_id": row["source_id"],
                "name": row["name"],
                "key_text": ", ".join(row["missing_env"] or row["env_vars"]),
                "docs_url": row.get("docs_url") or "",
                "opt_in": "yes" if row.get("requires_opt_in") else "no",
                "required": "required" if row.get("required") else "optional",
                "terms_risk": row.get("terms_risk"),
                "verification_status": row.get("verification_status"),
            }
        )
    return {
        "summary": plan["summary"],
        "rows": rows,
        "safe_env_template": plan.get("safe_env_template") or "# No missing P1 key variables.",
    }


def _api_key_row_context(key, stored: dict[str, dict]) -> dict:
    in_env = bool(os.getenv(key.name, ""))
    in_store = key.name in stored
    if in_env and in_store:
        status_html = '<span class="status exists">environment + store</span>'
    elif in_env:
        status_html = '<span class="status exists">environment</span>'
    elif in_store:
        status_html = '<span class="status exists">store</span>'
    else:
        status_html = '<span class="muted">missing</span>'
    return {
        "name": key.name,
        "status_html": status_html,
        "requirement": "required" if key.required else "optional",
        "sources": ", ".join(key.sources),
        "delete_href": f"/api-keys/{quote(key.name, safe='')}/delete",
        "delete": in_store,
    }


def _csrf_input(context: dict) -> str:
    return (
        f'<input type="hidden" name="{_e(context["csrf_name"])}" '
        f'value="{_e(context["csrf_token"])}">'
    )


def _api_keys_html_fallback(context: dict) -> str:
    message_html = ""
    if context["message"]:
        cls = "bad" if context["is_error"] else "exists"
        message_html = f'<div class="notice {cls}">{_e(context["message"])}</div>'
    options = "".join(
        f"<option value=\"{_e(name)}\">{_e(name)}</option>"
        for name in context["options"]
    )
    csrf = _csrf_input(context)
    setup = context["setup"]
    rows = "".join(_api_key_row_html(row, csrf) for row in context["rows"])
    if not rows:
        rows = '<tr><td colspan="5" class="muted">No API key environment variables are registered.</td></tr>'
    setup_rows = "".join(
        "<tr>"
        f"<td><span class=\"badge\">{_e(row['source_id'])}</span><div class=\"muted\">{_e(row['name'])}</div></td>"
        f"<td>{_e(row['key_text'])}</td>"
        f"<td>{_e(row['required'])}</td>"
        f"<td>{_e(row['terms_risk'])}</td>"
        f"<td>{_e(row['opt_in'])}</td>"
        f"<td>{_e(row['verification_status'])}</td>"
        f"<td>{f'<a href=\"{_e(row['docs_url'])}\" target=\"_blank\">Docs</a>' if row.get('docs_url') else ''}</td>"
        "</tr>"
        for row in setup["rows"]
    )
    if not setup_rows:
        setup_rows = '<tr><td colspan="7" class="muted">No missing P1 keyed source setup items.</td></tr>'
    passphrase_html = ""
    if not context["passphrase_ready"]:
        passphrase_html = f"""
<section class="panel">
  <h2>Initialize Encrypted Store</h2>
  <div class="muted">This sets {_e(context["secret_key_env"])} only for the current dashboard process. It is not written to disk.</div>
  <form class="setup-form" method="post" action="/api-keys/passphrase">
    {csrf}
    <label>Passphrase<input name="passphrase" type="password" autocomplete="new-password" required></label>
    <button type="submit">Enable Store</button>
  </form>
</section>"""
    summary = context["summary"]
    setup_summary = setup["summary"]
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{_e(context["csrf_token"])}">
<title>BEDNIIOSINT API Keys</title>
{asset_tags()}
{style_tag("api-keys.css")}
</head>
<body>
{_header_html("keys")}
<main>
<div class="page-head">
  <div>
    <h1>API Keys</h1>
    <div class="muted">{_e(summary["configured_keys"])} configured | {_e(summary["missing_required_keys"])} required keys missing | {_e(context["status_note"])}. Values are never shown after saving.</div>
  </div>
  <a class="btn" href="/sources/health" target="_blank">Source Health JSON</a>
</div>
{message_html}
<div class="cards">
  <div class="card"><div class="n">{_e(summary["api_keys"])}</div><div class="l">Key vars</div></div>
  <div class="card"><div class="n">{_e(summary["configured_keys"])}</div><div class="l">Configured</div></div>
  <div class="card"><div class="n">{_e(summary["missing_required_keys"])}</div><div class="l">Missing required</div></div>
  <div class="card"><div class="n">{_e(summary["statuses"]["available"])}</div><div class="l">Sources available</div></div>
</div>
{passphrase_html}
<section class="panel">
  <div class="section-head">
    <div>
      <h2>P1 Keyed Source Setup</h2>
      <div class="muted">{_e(setup_summary["missing_sources"])} missing source setups | {_e(setup_summary["missing_keys"])} missing key variables | blank values only</div>
    </div>
    <a class="btn small" href="/api-keys/setup?priority=P1" target="_blank">Setup JSON</a>
  </div>
  <div class="table-shell">
    <table>
      <tr><th>Source</th><th>Missing env vars</th><th>Requirement</th><th>Risk</th><th>Opt-in</th><th>Verification</th><th>Docs</th></tr>
      {setup_rows}
    </table>
  </div>
  <h3>Blank .env Template</h3>
  <pre class="env-template">{_e(setup["safe_env_template"])}</pre>
</section>
<section class="panel">
  <form class="key-form" method="post" action="/api-keys">
    {csrf}
    <label>Environment variable<select name="name">{options}</select></label>
    <label>Secret value<input name="value" type="password" autocomplete="off" required></label>
    <button type="submit">Save Key</button>
  </form>
</section>
<div class="table-shell">
<table>
<tr><th>Environment variable</th><th>Status</th><th>Requirement</th><th>Sources</th><th>Store action</th></tr>
{rows}
</table>
</div>
</main>
</body>
</html>"""


def _api_key_row_html(row: dict, csrf: str) -> str:
    action = (
        f'<form method="post" action="{_e(row["delete_href"])}">{csrf}'
        '<button class="small" type="submit">Delete Store Key</button></form>'
        if row["delete"]
        else '<span class="muted">-</span>'
    )
    return (
        "<tr>"
        f"<td><span class=\"badge\">{_e(row['name'])}</span></td>"
        f"<td>{row['status_html']}</td>"
        f"<td>{_e(row['requirement'])}</td>"
        f"<td>{_e(row['sources'])}</td>"
        f"<td>{action}</td>"
        "</tr>"
    )


def build_api_keys_router(
):
    if APIRouter is None:  # pragma: no cover
        return None

    router = APIRouter()

    @router.get("/api-keys", response_class=HTMLResponse)
    def api_keys_page():
        return HTMLResponse(api_keys_html())

    @router.get("/api-keys/setup")
    def api_keys_setup_api(
        priority: str = "P1",
        missing_only: bool = True,
        include_optional: bool = True,
    ):
        priorities = tuple(item.strip().upper() for item in priority.split(",") if item.strip())
        if not priorities:
            priorities = ("P1",)
        return api_key_setup_plan(
            priorities=priorities,
            missing_only=missing_only,
            include_optional=include_optional,
        )

    @router.post("/api-keys/passphrase", response_class=HTMLResponse)
    async def api_key_passphrase_api(request: Request):
        from ...core.secret_store import SECRET_KEY_ENV

        body = (await request.body()).decode("utf-8", errors="replace")
        fields = parse_qs(body, keep_blank_values=True)
        value = fields.get("passphrase", [""])[0].strip()
        if not value:
            return HTMLResponse(api_keys_html(f"{SECRET_KEY_ENV} must not be empty.", is_error=True))
        os.environ[SECRET_KEY_ENV] = value
        return HTMLResponse(
            api_keys_html(
                f"{SECRET_KEY_ENV} is set for this running dashboard process. Set it in your shell or service config before restarting."
            )
        )

    @router.post("/api-keys", response_class=HTMLResponse)
    async def api_key_store_api(request: Request):
        from ...core.secret_store import store_secret

        body = (await request.body()).decode("utf-8", errors="replace")
        fields = parse_qs(body, keep_blank_values=True)
        name = fields.get("name", [""])[0].strip()
        value = fields.get("value", [""])[0]
        try:
            store_secret(name, value, overwrite=True)
        except Exception as exc:
            return HTMLResponse(api_keys_html(str(exc), is_error=True))
        return HTMLResponse(api_keys_html(f"Stored {name} in encrypted local store."))

    @router.post("/api-keys/{name}/delete", response_class=HTMLResponse)
    def api_key_delete_api(name: str):
        from ...core.secret_store import delete_secret

        deleted = delete_secret(name)
        if deleted:
            message = f"Deleted {name} from encrypted local store."
        else:
            message = f"No encrypted store entry found for {name}."
        return HTMLResponse(api_keys_html(message))

    return router
