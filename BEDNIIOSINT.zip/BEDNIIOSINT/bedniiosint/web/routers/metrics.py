from __future__ import annotations

try:
    from fastapi import APIRouter
    from fastapi.responses import PlainTextResponse
except Exception:  # pragma: no cover
    APIRouter = None
    PlainTextResponse = None

from ...monitoring.metrics import metrics

if APIRouter is not None and PlainTextResponse is not None:
    router = APIRouter()

    @router.get("/metrics", response_class=PlainTextResponse)
    def prometheus_metrics() -> str:
        return metrics.render_prometheus()

else:
    router = None
