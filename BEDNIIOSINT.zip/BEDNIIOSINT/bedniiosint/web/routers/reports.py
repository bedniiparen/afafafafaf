from __future__ import annotations

from html import escape
import json
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote

try:
    from fastapi import APIRouter, HTTPException
    from fastapi.responses import FileResponse, HTMLResponse
except Exception:  # pragma: no cover
    APIRouter = None
    HTTPException = Exception
    FileResponse = None
    HTMLResponse = None

from ...core.case_admin import archive_case
from ...core.case_lookup import case_ids
from ...core.target import safe_case_name
from ...evidence.bundle import write_evidence_bundle
from ...reports.manifest import (
    report_manifest,
    verify_report_manifest,
    write_case_bundle,
    write_report_manifest,
)
from ..assets import asset_tags
from ..schemas import (
    EvidenceBundleInspectionAPI,
    ReportManifestAPI,
    ReportVerificationAPI,
)
from ..templating import TEMPLATE_ENV, safe_markup


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _header_html(active: str = "reports") -> str:
    def nav_item(label: str, href: str, key: str) -> str:
        cls = "nav active" if active == key else "nav"
        return f'<a class="{cls}" href="{href}">{_e(label)}</a>'

    return (
        "<header><div class=\"topbar\">"
        "<a class=\"brand\" href=\"/\">"
        "<span class=\"brand-mark\">B</span><span>BEDNIIOSINT</span>"
        "</a><nav>"
        f"{nav_item('Search', '/', 'search')}"
        f"{nav_item('History', '/history', 'history')}"
        f"{nav_item('Jobs', '/jobs', 'jobs')}"
        f"{nav_item('Sources', '/sources', 'sources')}"
        f"{nav_item('Plugins', '/plugins', 'plugins')}"
        f"{nav_item('Reports', '/reports', 'reports')}"
        '<div class="theme-switch" role="group" aria-label="Theme">'
        '<button class="theme-button" id="themeToggle" type="button" '
        'data-theme-toggle aria-pressed="false" title="Switch theme">Theme</button>'
        "</div></nav></div></header>"
    )


def reports_html(
    reports_dir: Callable[[], Path],
    evidence_bundle_inspection: Callable[[Path], dict[str, Any]],
) -> str:
    root = reports_dir()
    context = _reports_context(root, evidence_bundle_inspection)
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("reports.html").render(
            **context,
            asset_tags=safe_markup(asset_tags()),
            header=safe_markup(_header_html("reports")),
        )
    return _reports_html_fallback(context)


def _reports_context(
    root: Path,
    evidence_bundle_inspection: Callable[[Path], dict[str, Any]],
) -> dict[str, Any]:
    manifest = report_manifest(root)
    saved_manifest = root / "reports-manifest.json"
    verification = verify_report_manifest(saved_manifest)
    files = manifest["files"]
    file_rows = []
    for row in sorted(files, key=lambda item: item["modified_at"], reverse=True):
        name = str(row["name"])
        case = str(row["case"])
        file_rows.append(
            {
                "name": name,
                "href": f"/reports/{quote(name, safe='')}",
                "case": case,
                "case_href": f"/case/{quote(case, safe='')}",
                "kind": str(row["kind"]).upper(),
                "size_kb": round(row["size"] / 1024, 1),
                "modified": str(row["modified_at"])[:16].replace("T", " "),
            }
        )
    case_rows = []
    for case in manifest["cases"]:
        case_name = str(case["case"])
        evidence_bundle = root / f"{case_name}-evidence-bundle.zip"
        integrity_links = [
            {
                "href": f"/reports/verify?case={quote(case_name, safe='')}",
                "label": "Report Verify",
            }
        ]
        if evidence_bundle.exists():
            integrity_links.append(
                {
                    "href": f"/reports/evidence-bundle/{quote(case_name, safe='')}/inspect",
                    "label": "Evidence Inspect",
                }
            )
        case_rows.append(
            {
                "case": case_name,
                "case_href": f"/case/{quote(case_name, safe='')}",
                "files": case["files"],
                "size_kb": round(case["size"] / 1024, 1),
                "kinds": ", ".join(sorted(case["kinds"])),
                "bundle_href": f"/reports/bundle/{quote(case_name, safe='')}",
                "integrity_links": integrity_links,
            }
        )
    report_status = "valid" if verification["valid"] else "invalid"
    if not saved_manifest.exists():
        report_status = "missing manifest"
    integrity_rows = [
        {
            "artifact": "reports-manifest.json",
            "status": report_status,
            "files": f"{verification['summary']['present']}/{verification['summary']['files']}",
            "href": "/reports/verify",
            "label": "Verify JSON",
            "muted": "",
        }
    ]
    evidence_bundles = sorted(root.glob("*-evidence-bundle.zip"))
    for bundle in evidence_bundles:
        case_name = bundle.name[: -len("-evidence-bundle.zip")]
        inspected = evidence_bundle_inspection(bundle)
        status = "valid" if inspected["valid"] else "invalid"
        integrity_rows.append(
            {
                "artifact": bundle.name,
                "status": status,
                "files": len(inspected["files"]),
                "href": f"/reports/evidence-bundle/{quote(case_name, safe='')}/inspect",
                "label": "Inspect JSON",
                "muted": "",
            }
        )
    if not evidence_bundles:
        integrity_rows.append(
            {
                "artifact": "Evidence bundles",
                "status": "none",
                "files": 0,
                "href": "",
                "label": "",
                "muted": "No evidence bundle files yet.",
            }
        )
    return {
        "files": files,
        "manifest": manifest,
        "file_rows": file_rows,
        "case_rows": case_rows,
        "integrity_rows": integrity_rows,
    }


def _reports_html_fallback(context: dict[str, Any]) -> str:
    file_body = (
        "".join(
            "<tr>"
            f"<td><a href=\"{_e(row['href'])}\" target=\"_blank\">{_e(row['name'])}</a></td>"
            f"<td><a class=\"query-link\" href=\"{_e(row['case_href'])}\">{_e(row['case'])}</a></td>"
            f"<td><span class=\"badge\">{_e(row['kind'])}</span></td>"
            f"<td>{_e(row['size_kb'])} KB</td>"
            f"<td>{_e(row['modified'])}</td>"
            "</tr>"
            for row in context["file_rows"]
        )
        or '<tr><td colspan="5" class="muted">No reports yet.</td></tr>'
    )
    case_body = (
        "".join(
            "<tr>"
            f"<td><a class=\"query-link\" href=\"{_e(row['case_href'])}\">{_e(row['case'])}</a></td>"
            f"<td>{_e(row['files'])}</td>"
            f"<td>{_e(row['size_kb'])} KB</td>"
            f"<td>{_e(row['kinds'])}</td>"
            f"<td><a href=\"{_e(row['bundle_href'])}\">Bundle ZIP</a></td>"
            f"<td>{' | '.join(f'<a href=\"{_e(link['href'])}\" target=\"_blank\">{_e(link['label'])}</a>' for link in row['integrity_links'])}</td>"
            "</tr>"
            for row in context["case_rows"]
        )
        or '<tr><td colspan="6" class="muted">No report groups yet.</td></tr>'
    )
    integrity_body = "".join(
        "<tr>"
        f"<td>{_e(row['artifact'])}</td>"
        f"<td><span class=\"badge\">{_e(row['status'])}</span></td>"
        f"<td>{_e(row['files'])}</td>"
        f"<td>{f'<a href=\"{_e(row['href'])}\" target=\"_blank\">{_e(row['label'])}</a>' if row.get('href') else f'<span class=\"muted\">{_e(row.get('muted'))}</span>'}</td>"
        "</tr>"
        for row in context["integrity_rows"]
    )
    files = context["files"]
    manifest = context["manifest"]
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BEDNIIOSINT Report Center</title>
{asset_tags()}
</head>
<body>
{_header_html("reports")}
<main>
<div class="page-head">
  <div>
    <h1>Report Center</h1>
    <div class="muted">Reports: {len(files)} generated files across {len(manifest["cases"])} cases in runtime/reports_out.</div>
  </div>
  <div>
    <a class="btn" href="/reports-manifest.json" target="_blank">Manifest JSON</a>
    <a class="btn" href="/reports/verify" target="_blank">Verify</a>
  </div>
</div>
<section class="section-head"><h2>Integrity</h2></section>
<div class="table-shell">
<table>
<tr><th>Artifact</th><th>Status</th><th>Files</th><th>Action</th></tr>
{integrity_body}
</table>
</div>
<section class="section-head"><h2>Cases</h2></section>
<div class="table-shell">
<table>
<tr><th>Case</th><th>Files</th><th>Size</th><th>Formats</th><th>Bundle</th><th>Integrity</th></tr>
{case_body}
</table>
</div>
<section class="section-head"><h2>Files</h2></section>
<div class="table-shell">
<table>
<tr><th>File</th><th>Case</th><th>Type</th><th>Size</th><th>Modified</th></tr>
{file_body}
</table>
</div>
</main>
</body>
</html>"""


def build_reports_router(
    *,
    reports_dir: Callable[[], Path],
    storage_for_case: Callable[[str], Any],
    evidence_bundle_inspection: Callable[[Path], dict[str, Any]],
    html_response: Callable[[str], Any] | None = None,
):
    if APIRouter is None:  # pragma: no cover
        return None

    router = APIRouter()

    @router.get("/reports", response_class=HTMLResponse)
    def reports_page():
        return HTMLResponse(reports_html(reports_dir, evidence_bundle_inspection))

    @router.get("/reports-manifest.json", response_model=ReportManifestAPI)
    def reports_manifest():
        path = write_report_manifest(reports_dir())
        return json.loads(path.read_text(encoding="utf-8"))

    @router.get("/reports/verify", response_model=ReportVerificationAPI)
    def reports_verify_api(case: str | None = None):
        return verify_report_manifest(
            reports_dir() / "reports-manifest.json",
            case_name=safe_case_name(case) if case else None,
        )

    @router.get("/reports/bundle/{case_name}")
    def reports_bundle(case_name: str):
        bundle = write_case_bundle(reports_dir(), safe_case_name(case_name))
        if not bundle.exists():
            raise HTTPException(404, "bundle not found")
        return FileResponse(bundle, media_type="application/zip", filename=bundle.name)

    @router.get("/reports/case-archive/{case_name}")
    def reports_case_archive(case_name: str):
        try:
            bundle = archive_case(case_name, reports_dir())
        except KeyError as exc:
            raise HTTPException(404, "case not found") from exc
        return FileResponse(bundle, media_type="application/zip", filename=bundle.name)

    @router.get("/reports/evidence-bundle/{case_name}")
    def reports_evidence_bundle(case_name: str):
        case = safe_case_name(case_name)
        storage = storage_for_case(case)
        ids = case_ids(storage, case)
        if not ids:
            raise HTTPException(404, "case not found")
        bundle = write_evidence_bundle(
            storage,
            ids,
            reports_dir() / f"{case}-evidence-bundle.zip",
        )
        return FileResponse(bundle, media_type="application/zip", filename=bundle.name)

    @router.get("/reports/evidence-bundle/{case_name}/inspect", response_model=EvidenceBundleInspectionAPI)
    def reports_evidence_bundle_inspect_api(case_name: str):
        case = safe_case_name(case_name)
        return evidence_bundle_inspection(
            reports_dir() / f"{case}-evidence-bundle.zip"
        )

    @router.get("/reports/{filename}")
    def report_file(filename: str):
        root = reports_dir().resolve()
        path = (reports_dir() / filename).resolve()
        if root not in path.parents and path != root:
            raise HTTPException(400, "invalid filename")
        if not path.exists() or not path.is_file():
            raise HTTPException(404, "report not found")
        suffix = path.suffix.lower()
        if suffix == ".html":
            html = path.read_text(encoding="utf-8")
            return html_response(html) if html_response is not None else HTMLResponse(html)
        if suffix == ".json":
            return FileResponse(path, media_type="application/json", filename=path.name)
        if suffix == ".csv":
            return FileResponse(path, media_type="text/csv", filename=path.name)
        if suffix == ".pdf":
            return FileResponse(path, media_type="application/pdf", filename=path.name)
        return FileResponse(path, media_type="application/octet-stream", filename=path.name)

    return router
