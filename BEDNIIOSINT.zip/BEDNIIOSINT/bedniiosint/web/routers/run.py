from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote

try:
    from fastapi import APIRouter, HTTPException
    from fastapi.responses import HTMLResponse
except Exception:  # pragma: no cover
    APIRouter = None
    HTTPException = Exception
    HTMLResponse = None

from ...core.case import UsernameCase
from ...core.case_domain import DomainCase
from ...core.case_email import EmailCase
from ...core.case_extra import CompanyCase, IPCase, PhoneCase, URLCase, WalletCase
from ...core.case_metadata import MetadataCase
from ...core.target import auto_case_name, detect_module, safe_case_name
from ..assets import asset_tags, style_tag
from ..templating import TEMPLATE_ENV


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _file_link(path: Path, label: str) -> dict[str, str]:
    return {"href": f"/reports/{quote(path.name)}", "label": label}


def _run_module(case: str, module: str, target: str, *, no_resolve: bool) -> dict[str, Any]:
    if module == "username":
        return UsernameCase(case, target).run()
    if module == "email":
        return EmailCase(case, target).run()
    if module == "domain":
        return DomainCase(case, target, resolve_subs=not no_resolve).run()
    if module == "metadata":
        if not Path(target).exists():
            raise HTTPException(400, f"file not found: {target}")
        return MetadataCase(case, target).run()
    if module == "ip":
        return IPCase(case, target).run()
    if module == "url":
        return URLCase(case, target).run()
    if module == "phone":
        return PhoneCase(case, target).run()
    if module == "wallet":
        return WalletCase(case, target).run()
    if module == "company":
        return CompanyCase(case, target).run()
    raise HTTPException(400, f"unknown module: {module}")


def result_html(case: str, module: str, target: str, files: dict[str, Path]) -> str:
    links = [
        _file_link(path, label)
        for key, label in (
            ("case_html", "HTML report"),
            ("case_json", "JSON"),
            ("graph_json", "Graph JSON"),
            ("graphml", "GraphML"),
            ("gexf", "GEXF"),
            ("evidence_manifest", "Evidence manifest"),
            ("module_json", f"{module} JSON"),
            ("csv_findings", "Findings CSV"),
            ("csv_entities", "Entities CSV"),
            ("csv_relations", "Relations CSV"),
        )
        if (path := files.get(key)) is not None
    ]
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("result.html").render(
            asset_tags=asset_tags(),
            result_style=style_tag("result.css"),
            case=case,
            module=module,
            target=target,
            case_href=f"/case/{quote(case)}",
            links=links,
        )
    fallback_links = "".join(
        f'<li><a href="{_e(link["href"])}" target="_blank">{_e(link["label"])}</a></li>'
        for link in links
    )
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_e(case)} complete</title>
{asset_tags()}
{style_tag("result.css")}
</head>
<body>
<main>
<div class="box">
<h1>Done: {_e(module)} / {_e(target)}</h1>
<div>Result: <b>{_e(case)}</b></div>
<ul>{fallback_links}</ul>
<div class="actions">
  <a class="btn" href="/case/{quote(case)}">Open result</a>
  <a class="btn" href="/">Back</a>
</div>
</div>
</main>
</body>
</html>"""


def build_run_router(
    *,
    write_outputs: Callable[[str, str, dict[str, Any]], dict[str, Path]],
    unhide_history_case: Callable[[str], None],
    html_response: Callable[[str], HTMLResponse],
):
    if APIRouter is None:  # pragma: no cover
        return None

    router = APIRouter()

    @router.get("/find", response_class=HTMLResponse)
    @router.get("/run", response_class=HTMLResponse)
    def run_case(
        target: str,
        module: str = "auto",
        case: str | None = None,
        no_resolve: bool = False,
    ):
        module = module.strip().lower()
        target = target.strip()
        if not target:
            raise HTTPException(400, "target is required")
        if module == "auto":
            module = detect_module(target)
        case_name = safe_case_name(case) if case else auto_case_name(module, target)
        try:
            summary = _run_module(case_name, module, target, no_resolve=no_resolve)
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(500, str(exc)) from exc

        files = write_outputs(case_name, module, summary)
        unhide_history_case(case_name)
        return html_response(result_html(case_name, module, target, files))

    return router
