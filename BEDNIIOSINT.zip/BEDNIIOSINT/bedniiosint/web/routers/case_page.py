from __future__ import annotations

from html import escape
import json
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote

try:
    from fastapi import APIRouter, HTTPException
    from fastapi.responses import HTMLResponse
except Exception:  # pragma: no cover
    APIRouter = None
    HTTPException = Exception
    HTMLResponse = None

from ...core.case_summary import build_case_summary
from ..assets import asset_tags, script_tag, style_tag
from ..templating import TEMPLATE_DIR, TEMPLATE_ENV
from .pages import case_rows, compact_date, header_html


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _report_card(
    *,
    title: str,
    description: str,
    fmt: str,
    purpose: str,
    href: str = "",
    status: str = "available",
) -> str:
    action = (
        f'<a class="btn" href="{_e(href)}" target="_blank">{_e(title)}</a>'
        if href and status != "missing"
        else f'<button class="ghost-button" type="button" disabled>{_e(title)}</button>'
    )
    return (
        '<article class="report-card">'
        f'<div class="report-card-top"><b>{_e(title)}</b><span class="case-badge">{_e(status)}</span></div>'
        f"<p>{_e(description)}</p>"
        '<div class="report-card-meta">'
        f"<span>Format: {_e(fmt)}</span>"
        f"<span>Purpose: {_e(purpose)}</span>"
        "</div>"
        f"{action}"
        "</article>"
    )


def _file_card(
    files: dict[str, Path],
    key: str,
    title: str,
    description: str,
    fmt: str,
    purpose: str,
) -> str:
    path = files.get(key)
    return _report_card(
        title=title,
        description=description,
        fmt=fmt,
        purpose=purpose,
        href=f"/reports/{quote(path.name)}" if path else "",
        status="generated" if path else "missing",
    )


_SAFE_TEMPLATE_KEYS = {
    "asset_tags",
    "case_links",
    "case_name_json",
    "case_title_json",
    "csv_links_or_empty",
    "diagnostics_links",
    "evidence_links",
    "graph_export_links",
    "header",
    "machine_links",
    "primary_report_links_or_empty",
    "table_panels",
    "workspace_script",
    "workspace_style",
    "workspace_tabs_script",
    "workspace_tab_buttons",
}


def _render_case_template(context: dict[str, Any]) -> str:
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("case.html").render(**context)
    template = (TEMPLATE_DIR / "case.html").read_text(encoding="utf-8")
    rendered = template
    for key, value in sorted(context.items(), key=lambda item: len(item[0]), reverse=True):
        text = str(value)
        safe_text = text if key in _SAFE_TEMPLATE_KEYS else _e(text)
        rendered = rendered.replace(f"{{{{ {key} | safe }}}}", text)
        rendered = rendered.replace(f"{{{{ {key} }}}}", safe_text)
    return rendered


def _workspace_tab_buttons(tabs: tuple[tuple[str, str], ...]) -> str:
    counted = {"profiles", "emails", "phones", "domains", "mentions", "sources", "evidence"}
    buttons = []
    for key, label in tabs:
        is_overview = key == "overview"
        count_span = (
            f'<span class="tab-count" data-tab-count="{_e(key)}"></span>'
            if key in counted
            else ""
        )
        buttons.append(
            f'<a class="tab-button {"active" if is_overview else ""}" '
            f'href="#tab-{_e(key)}" role="tab" data-tab="{_e(key)}" '
            f'aria-controls="tab-{_e(key)}" aria-selected="{"true" if is_overview else "false"}" '
            f'tabindex="{"0" if is_overview else "-1"}">'
            f'<span class="tab-label">{_e(label)}</span>{count_span}</a>'
        )
    return "".join(buttons)


def _table_panels(keys: tuple[str, ...]) -> str:
    return "".join(
        f"""
  <section class="tab-panel table-panel" id="tab-{_e(key)}" data-table-panel="{_e(key)}" role="tabpanel">
    <div class="tab-panel-head">
      <div>
        <h2 id="{_e(key)}Title">{_e(key.title())}</h2>
        <div class="muted small" id="{_e(key)}Meta">Loading table...</div>
      </div>
    </div>
    <div class="table-toolbar">
      <label>Search<input id="{_e(key)}Search" data-table-search="{_e(key)}" placeholder="search current table"></label>
      <div class="table-filter-row" data-table-filters="{_e(key)}"></div>
      <div class="table-actions">
        <button class="ghost-button" type="button" data-table-export="{_e(key)}" data-format="csv">CSV</button>
        <button class="ghost-button" type="button" data-table-export="{_e(key)}" data-format="json">JSON</button>
      </div>
    </div>
    <div class="table-status-strip" id="{_e(key)}StatusStrip"></div>
    <div class="workspace-card">
      <div class="table-shell">
        <table class="workspace-table" id="{_e(key)}Table">
          <thead id="{_e(key)}Head"></thead>
          <tbody id="{_e(key)}Body"></tbody>
        </table>
      </div>
      <div class="pager" id="{_e(key)}Pager"></div>
    </div>
  </section>"""
        for key in keys
    )


def case_html(name: str, summary: dict[str, Any], files: dict[str, Path]) -> str:
    runs = summary.get("meta", {}).get("runs", [])
    query = runs[-1].get("target", name) if runs else name
    findings = list(summary.get("findings") or [])
    risk_summary = dict(summary.get("risk_summary") or {})
    confidence_score = float(risk_summary.get("confidence_score") or 0.0)
    confidence_label = f"{round(confidence_score)}%" if confidence_score else "review"
    status_label = "active" if findings else "empty"
    updated_at = compact_date(runs[-1].get("created_at") if runs else "")
    case_rows_by_name: dict[str, dict[str, Any]] = {}
    for row in case_rows():
        case_rows_by_name.setdefault(str(row.get("case") or ""), row)
    case_links = "".join(
        "<a "
        f"class=\"case-nav-item {'active' if row.get('case') == name else ''}\" "
        f"href=\"/case/{quote(str(row.get('case') or ''))}\">"
        f"<b>{_e(row.get('case'))}</b>"
        f"<span>{_e(row.get('target') or row.get('case'))}</span>"
        '<span class="case-card-meta">'
        f"<em>{_e(compact_date(row.get('created_at')))}</em>"
        f"<em>{_e(row.get('runs', 0))} runs</em>"
        "<em>saved</em>"
        "<em>confidence review</em>"
        "</span>"
        "</a>"
        for row in list(case_rows_by_name.values())[:120]
    )
    if not case_links:
        case_links = '<div class="empty small">No saved cases.</div>'

    csv_links = "".join(
        _file_card(files, f"csv_{key}", label, f"Structured {label.lower()} table.", "CSV", "table export")
        for key, label in (
            ("findings", "Findings CSV"),
            ("entities", "Entities CSV"),
            ("relations", "Relations CSV"),
            ("evidence", "Evidence CSV"),
            ("attachments", "Attachments CSV"),
            ("sources", "Sources CSV"),
            ("timeline", "Timeline CSV"),
            ("notes", "Notes CSV"),
        )
    )
    primary_report_links = "".join(
        item
        for item in (
            _file_card(files, "case_html", "Open HTML Report", "Analyst report with summary, findings, evidence and confidence.", "HTML", "analyst report"),
            _file_card(files, "case_markdown", "Export Markdown", "Markdown Report for notes and review.", "Markdown", "executive export"),
            _file_card(files, "case_pdf", "Export PDF", "PDF Report when PDF renderer is available.", "PDF", "print/export"),
        )
        if item
    )
    machine_links = "".join(
        item
        for item in (
            _file_card(files, "case_json", "Case JSON", "Legacy structured case summary for integrations.", "JSON", "API/integration"),
            _file_card(files, "technical_json", "Technical JSON Report", "Full report view model with raw appendix.", "JSON", "technical appendix"),
            _file_card(files, "stix", "STIX JSON", "STIX 2.1 bundle for CTI tooling.", "JSON", "threat intelligence"),
            _file_card(files, "opencti", "OpenCTI JSON", "OpenCTI import envelope.", "JSON", "OpenCTI connector"),
            _file_card(files, "misp", "MISP JSON", "MISP event export with review-only attributes.", "JSON", "MISP connector"),
            _file_card(files, "taxii", "TAXII JSON", "TAXII-style envelope for transport workflows.", "JSON", "TAXII transport"),
        )
        if item
    )
    quoted_name = quote(name)
    graph_export_links = (
        _report_card(
            title="Cytoscape JSON",
            description="Graph nodes and edges for browser or Cytoscape analysis.",
            fmt="JSON",
            purpose="graph analysis",
            href=f"/cases/{quoted_name}/graph",
            status="available",
        )
        + "".join(
            item
            for item in (
                _file_card(files, "graph_json", "Graph JSON", "Saved Cytoscape graph export.", "JSON", "graph archive"),
                _file_card(files, "graphml", "GraphML", "GraphML export for graph tools.", "GraphML", "graph exchange"),
                _file_card(files, "gexf", "GEXF", "GEXF export for graph tools.", "GEXF", "graph exchange"),
            )
            if item
        )
    )
    evidence_links = "".join(
        item
        for item in (
            _file_card(files, "evidence_manifest", "Evidence Manifest", "Hash manifest and chain-of-custody evidence metadata.", "JSON", "integrity verification"),
            _report_card(title="Bundle ZIP", description="All generated case report files grouped into one archive.", fmt="ZIP", purpose="report bundle", href=f"/reports/bundle/{quoted_name}", status="available"),
            _report_card(title="Evidence Bundle", description="Preserved evidence files and manifest in a ZIP bundle.", fmt="ZIP", purpose="evidence preservation", href=f"/reports/evidence-bundle/{quoted_name}", status="available"),
            _report_card(title="Case Archive", description="Case database/archive package for local retention.", fmt="ZIP", purpose="case preservation", href=f"/reports/case-archive/{quoted_name}", status="available"),
            _report_card(title="Integrity Summary", description="Offline report manifest verification.", fmt="JSON", purpose="integrity check", href=f"/reports/verify?case={quoted_name}", status="available"),
        )
        if item
    )
    technical_href = f"/reports/{quote(files['technical_json'].name)}" if files.get("technical_json") else ""
    technical_status = "generated" if files.get("technical_json") else "missing"
    diagnostics_links = "".join(
        [
            _report_card(title="Source coverage", description="Which sources succeeded, failed, timed out or need keys.", fmt="JSON/HTML", purpose="diagnostics", href=technical_href, status=technical_status),
            _report_card(title="Performance diagnostics", description="Recorded source duration fields when available.", fmt="JSON", purpose="diagnostics", href=technical_href, status=technical_status),
            _report_card(title="Missing API keys", description="Sources that could not run because credentials are absent.", fmt="JSON/HTML", purpose="setup diagnostics", href="/api-keys/setup?priority=P1", status="available"),
            _report_card(title="Timeout sources", description="Sources marked as timed out in report coverage.", fmt="JSON", purpose="diagnostics", href=technical_href, status=technical_status),
        ]
    )
    workspace_tabs = (
        ("overview", "Overview"),
        ("profiles", "Profiles"),
        ("emails", "Emails"),
        ("phones", "Phones"),
        ("domains", "Domains"),
        ("mentions", "Mentions"),
        ("sources", "Sources"),
        ("evidence", "Evidence"),
        ("graph", "Graph"),
        ("exports", "Exports"),
    )
    table_panel_keys = ("profiles", "emails", "phones", "domains", "mentions", "sources", "evidence")
    return _render_case_template(
        {
            "asset_tags": asset_tags(include_refresh=False),
            "case_links": case_links,
            "case_name": name,
            "case_name_json": json.dumps(name, ensure_ascii=False),
            "case_title": query,
            "case_title_json": json.dumps(query, ensure_ascii=False),
            "csv_links": csv_links,
            "csv_links_or_empty": csv_links or '<div class="empty-state">No CSV exports generated.</div>',
            "diagnostics_links": diagnostics_links,
            "evidence_links": evidence_links,
            "graph_export_links": graph_export_links,
            "header": header_html("history"),
            "machine_links": machine_links,
            "primary_report_links": primary_report_links,
            "primary_report_links_or_empty": primary_report_links or '<div class="empty-state">No primary report files generated for this case.</div>',
            "quoted_name": quoted_name,
            "status_label": status_label,
            "confidence_label": confidence_label,
            "table_panels": _table_panels(table_panel_keys),
            "updated_at": updated_at,
            "workspace_tabs_script": script_tag("workspace-tabs.js"),
            "workspace_script": script_tag("workspace.js"),
            "workspace_style": f'{style_tag("workspace.css")}\n{style_tag("refresh.css")}',
            "workspace_tab_buttons": _workspace_tab_buttons(workspace_tabs),
        }
    )


def build_case_page_router(
    *,
    write_outputs: Callable[[str, str, dict[str, Any]], dict[str, Path]],
    html_response: Callable[[str], HTMLResponse],
    render_case_html: Callable[[str, dict[str, Any], dict[str, Path]], str] = case_html,
):
    if APIRouter is None:  # pragma: no cover
        return None

    router = APIRouter()

    @router.get("/case/{name}", response_class=HTMLResponse)
    def case_page(name: str):
        summary = build_case_summary(name)
        if not summary.get("meta", {}).get("found"):
            raise HTTPException(404, "case not found")
        files = write_outputs(name, "case", summary)
        return html_response(render_case_html(name, summary, files))

    return router
