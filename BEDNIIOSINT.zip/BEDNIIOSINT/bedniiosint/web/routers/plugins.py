from __future__ import annotations

import json
from html import escape
from urllib.parse import parse_qs, quote

try:
    from fastapi import APIRouter, HTTPException, Request
    from fastapi.responses import HTMLResponse
except Exception:  # pragma: no cover
    APIRouter = None
    HTTPException = Exception
    Request = None
    HTMLResponse = None

from ...core.plugins import (
    all_plugin_manifests,
    get_plugin_config,
    set_plugin_config,
    set_plugin_enabled,
)
from ..assets import asset_tags, style_tag
from ..schemas import PluginManifestAPI
from ..security import CSRF_FIELD, csrf_token
from ..templating import TEMPLATE_ENV, safe_markup


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _csrf_input() -> str:
    return f'<input type="hidden" name="{_e(CSRF_FIELD)}" value="{_e(csrf_token())}">'


def _header_html(active: str = "plugins") -> str:
    def nav_item(label: str, href: str, key: str) -> str:
        cls = "nav active" if active == key else "nav"
        return f'<a class="{cls}" href="{href}">{_e(label)}</a>'

    return (
        "<header><div class=\"topbar\">"
        "<a class=\"brand\" href=\"/\">"
        "<span class=\"brand-mark\">B</span><span>BEDNIIOSINT</span>"
        "</a><nav>"
        f"{nav_item('Search', '/', 'search')}"
        f"{nav_item('History', '/history', 'history')}"
        f"{nav_item('Jobs', '/jobs', 'jobs')}"
        f"{nav_item('Sources', '/sources', 'sources')}"
        f"{nav_item('Plugins', '/plugins', 'plugins')}"
        f"{nav_item('Reports', '/reports', 'reports')}"
        '<div class="theme-switch" role="group" aria-label="Theme">'
        '<button class="theme-button" id="themeToggle" type="button" '
        'data-theme-toggle aria-pressed="false" title="Switch theme">Theme</button>'
        "</div></nav></div></header>"
    )


def _signature_label(status: dict) -> str:
    if status.get("verified") is True:
        return "verified"
    if status.get("signed"):
        return "signed / unverified"
    return "unsigned"


def _plugin_rows() -> list[dict]:
    rows: list[dict] = []
    for manifest in all_plugin_manifests(include_disabled=True):
        row = manifest.as_dict()
        enabled = bool(row.get("enabled", True))
        name = str(row.get("name") or "")
        row.update(
            {
                "name": name,
                "name_url": quote(name, safe=""),
                "enabled": enabled,
                "state": "enabled" if enabled else "disabled",
                "state_class": "exists" if enabled else "",
                "signature_label": _signature_label(row.get("signature_status") or {}),
            }
        )
        rows.append(row)
    return rows


def plugins_html() -> str:
    plugins = _plugin_rows()
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("plugins.html").render(
            asset_tags=safe_markup(asset_tags()),
            plugins_style=safe_markup(style_tag("plugins.css")),
            header=safe_markup(_header_html("plugins")),
            csrf_name=CSRF_FIELD,
            csrf_token=csrf_token(),
            plugins=plugins,
        )
    return _plugins_html_fallback(plugins)


def _plugins_html_fallback(plugins: list[dict]) -> str:
    csrf = _csrf_input()
    rows = []
    for row in plugins:
        name = str(row.get("name") or "")
        name_url = str(row.get("name_url") or quote(name, safe=""))
        enabled = bool(row.get("enabled", True))
        rows.append(
            "<tr>"
            f"<td><b>{_e(name)}</b><div class=\"muted small\">{_e(row.get('description'))}</div></td>"
            f"<td>{_e(row.get('version'))}</td>"
            f"<td>{_e(', '.join(row.get('consumes') or []))}</td>"
            f"<td>{_e(', '.join(row.get('produces') or []))}</td>"
            f"<td>{_e(row.get('auth'))}</td>"
            f"<td><span class=\"status {'exists' if enabled else ''}\">{_e(row.get('state'))}</span></td>"
            f"<td>{_e(row.get('signature_label'))}</td>"
            "<td class=\"row-actions\">"
            f"<form method=\"post\" action=\"/plugins/{name_url}/enable\">{csrf}<button class=\"small\" type=\"submit\">Enable</button></form>"
            f"<form method=\"post\" action=\"/plugins/{name_url}/disable\">{csrf}<button class=\"small\" type=\"submit\">Disable</button></form>"
            f"<a class=\"btn small\" href=\"/plugins/{name_url}/config\">Config</a>"
            "</td>"
            "</tr>"
        )
    body = "".join(rows) or '<tr><td colspan="8" class="muted">No plugins found.</td></tr>'
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{_e(csrf_token())}">
<title>BEDNIIOSINT Plugins</title>
{asset_tags()}
{style_tag("plugins.css")}
</head>
<body>
{_header_html("plugins")}
<main>
<div class="page-head">
  <div>
    <h1>Plugins</h1>
    <div class="muted">Local and built-in plugin manifests, enablement, signatures and config.</div>
  </div>
  <a class="btn" href="/plugins.json" target="_blank">Plugins JSON</a>
</div>
<div class="table-shell">
<table>
<tr><th>Name</th><th>Version</th><th>Consumes</th><th>Produces</th><th>Auth</th><th>State</th><th>Signature</th><th>Actions</th></tr>
{body}
</table>
</div>
</main>
</body>
</html>"""


def plugin_config_html(name: str) -> str:
    config = get_plugin_config(name)
    config_text = json.dumps(config, indent=2, ensure_ascii=False)
    manifest = next(
        (
            row
            for row in all_plugin_manifests(include_disabled=True)
            if row.name == name
        ),
        None,
    )
    title = manifest.description if manifest else "Plugin config"
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("plugin_config.html").render(
            asset_tags=safe_markup(asset_tags()),
            config_style=safe_markup(style_tag("plugin-config.css")),
            header=safe_markup(_header_html("plugins")),
            csrf_name=CSRF_FIELD,
            csrf_token=csrf_token(),
            name=name,
            name_url=quote(name, safe=""),
            title=title,
            config_text=config_text,
        )
    return _plugin_config_html_fallback(name, title, config_text)


def _plugin_config_html_fallback(name: str, title: str, config_text: str) -> str:
    name_url = quote(name, safe="")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{_e(csrf_token())}">
<title>Plugin Config: {_e(name)}</title>
{asset_tags()}
{style_tag("plugin-config.css")}
</head>
<body>
{_header_html("plugins")}
<main>
<div class="page-head">
  <div>
    <h1>Plugin Config: {_e(name)}</h1>
    <div class="muted">{_e(title)}</div>
  </div>
  <a class="btn" href="/plugins">Back</a>
</div>
<section class="panel">
  <form class="config-form" method="post" action="/plugins/{name_url}/config">
    {_csrf_input()}
    <label>Config JSON<textarea name="config_json">{_e(config_text)}</textarea></label>
    <button type="submit">Save Config</button>
  </form>
</section>
</main>
</body>
</html>"""


if APIRouter is not None:
    router = APIRouter()

    @router.get("/plugins", response_class=HTMLResponse)
    def plugins_page():
        return HTMLResponse(plugins_html())

    @router.get("/plugins.json", response_model=list[PluginManifestAPI])
    def plugins_api():
        return [row.as_dict() for row in all_plugin_manifests(include_disabled=True)]

    @router.post("/plugins/{name}/enable", response_class=HTMLResponse)
    def plugin_enable_api(name: str):
        set_plugin_enabled(name, True)
        return HTMLResponse(plugins_html())

    @router.post("/plugins/{name}/disable", response_class=HTMLResponse)
    def plugin_disable_api(name: str):
        set_plugin_enabled(name, False)
        return HTMLResponse(plugins_html())

    @router.get("/plugins/{name}/config", response_class=HTMLResponse)
    def plugin_config_page(name: str):
        return HTMLResponse(plugin_config_html(name))

    @router.post("/plugins/{name}/config", response_class=HTMLResponse)
    async def plugin_config_update_api(name: str, request: Request):
        body = (await request.body()).decode("utf-8", errors="replace")
        fields = parse_qs(body, keep_blank_values=True)
        raw = fields.get("config_json", ["{}"])[0].strip() or "{}"
        try:
            config = json.loads(raw)
        except ValueError as exc:
            raise HTTPException(400, "config_json must be valid JSON") from exc
        if not isinstance(config, dict):
            raise HTTPException(400, "config_json must be a JSON object")
        set_plugin_config(name, config)
        return HTMLResponse(plugin_config_html(name))

else:  # pragma: no cover
    router = None
