from __future__ import annotations

from html import escape
from urllib.parse import parse_qs

try:
    from fastapi import APIRouter, Request
    from fastapi.responses import HTMLResponse, RedirectResponse
except Exception:  # pragma: no cover
    APIRouter = None
    Request = None
    HTMLResponse = None
    RedirectResponse = None

from ...core.monitoring import (
    add_monitor_schedule,
    due_monitor_schedules,
    list_monitor_schedules,
    run_due_monitor_schedules,
)
from ..assets import asset_tags, style_tag
from ..schemas import (
    MonitorScheduleAddAPI,
    MonitoringDueAPI,
    MonitoringEnvelopeAPI,
    MonitoringRunAPI,
)
from ..security import CSRF_FIELD, csrf_token
from ..templating import render_template, safe_markup
from .pages import header_html


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _monitoring_context(message: str = "") -> dict:
    payload = list_monitor_schedules()
    due = due_monitor_schedules()
    return {
        "asset_tags": safe_markup(asset_tags()),
        "monitoring_style": safe_markup(style_tag("monitoring.css")),
        "header": safe_markup(header_html("monitoring")),
        "message": message,
        "summary": payload.get("summary") or {},
        "due_summary": due.get("summary") or {},
        "schedules": list(payload.get("schedules") or []),
        "alerts": list(reversed(list(payload.get("alerts") or [])[-25:])),
        "csrf_field": CSRF_FIELD,
        "csrf_token": csrf_token(),
        "modules": ("auto", "username", "domain", "email", "ip", "url", "company"),
    }


def _monitoring_html(message: str = "") -> str:
    context = _monitoring_context(message)
    rendered = render_template("monitoring.html", **context)
    if rendered is not None:
        return rendered
    return _monitoring_html_fallback(context)


def _monitoring_html_fallback(context: dict) -> str:
    schedules = list(context.get("schedules") or [])
    alerts = list(context.get("alerts") or [])
    token = str(context.get("csrf_token") or "")
    schedule_rows = []
    for row in schedules:
        last_alert = row.get("last_alert") or {}
        schedule_rows.append(
            "<tr>"
            f"<td>{_e(row.get('id'))}</td>"
            f"<td>{'yes' if row.get('enabled') else 'no'}</td>"
            f"<td>{_e(row.get('target'))}</td>"
            f"<td>{_e(row.get('module'))}</td>"
            f"<td>{_e(row.get('interval_minutes'))}</td>"
            f"<td>{_e(row.get('next_run_at'))}</td>"
            f"<td>{_e(row.get('last_case'))}</td>"
            f"<td>{_e(last_alert.get('message') or '')}</td>"
            "</tr>"
        )
    if not schedule_rows:
        schedule_rows.append('<tr><td colspan="8" class="muted">No monitors.</td></tr>')
    alert_rows = []
    for row in alerts:
        changed = row.get("changed") or {}
        alert_rows.append(
            "<tr>"
            f"<td>{_e(row.get('created_at'))}</td>"
            f"<td>{_e(row.get('target'))}</td>"
            f"<td>{_e(row.get('previous_case'))}</td>"
            f"<td>{_e(row.get('current_case'))}</td>"
            f"<td>{_e(changed.get('new_findings', 0))}</td>"
            f"<td>{_e(changed.get('new_entities', 0))}</td>"
            f"<td>{_e(changed.get('new_relations', 0))}</td>"
            "</tr>"
        )
    if not alert_rows:
        alert_rows.append('<tr><td colspan="7" class="muted">No alerts.</td></tr>')
    message = str(context.get("message") or "")
    message_html = f'<div class="notice">{_e(message)}</div>' if message else ""
    summary = context.get("summary") or {}
    due_summary = context.get("due_summary") or {}
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>BEDNIIOSINT Monitoring</title>
{asset_tags()}
{style_tag("monitoring.css")}
</head>
<body>
{header_html("monitoring")}
<main>
<h1>Monitoring</h1>
{message_html}
<div class="grid">
<div class="metric"><b>{_e(summary.get('schedules', 0))}</b><span>Schedules</span></div>
<div class="metric"><b>{_e(summary.get('enabled', 0))}</b><span>Enabled</span></div>
<div class="metric"><b>{_e(due_summary.get('due', 0))}</b><span>Due now</span></div>
<div class="metric"><b>{_e(summary.get('alerts', 0))}</b><span>Alerts</span></div>
</div>
<form action="/monitoring/add" method="post">
<input type="hidden" name="{_e(CSRF_FIELD)}" value="{_e(token)}"/>
<label>Target<input name="target" required placeholder="example.com"/></label>
<label>Module<select name="module"><option value="auto">auto</option><option value="username">username</option><option value="domain">domain</option><option value="email">email</option><option value="ip">ip</option><option value="url">url</option><option value="company">company</option></select></label>
<label>Interval minutes<input name="interval_minutes" type="number" min="1" value="1440"/></label>
<button type="submit">Add</button>
</form>
<form action="/monitoring/run-due-form" method="post">
<input type="hidden" name="{_e(CSRF_FIELD)}" value="{_e(token)}"/>
<input type="hidden" name="max_runs" value=""/>
<input type="hidden" name="dry_run" value="0"/>
<button type="submit">Run Due</button>
</form>
<h2>Schedules</h2>
<table><tr><th>ID</th><th>Enabled</th><th>Target</th><th>Module</th><th>Interval</th><th>Next run</th><th>Last case</th><th>Last alert</th></tr>{''.join(schedule_rows)}</table>
<h2>Alerts</h2>
<table><tr><th>Created</th><th>Target</th><th>Previous</th><th>Current</th><th>New findings</th><th>New entities</th><th>New relations</th></tr>{''.join(alert_rows)}</table>
</main>
</body>
</html>"""


if APIRouter is not None:
    router = APIRouter()

    @router.get("/monitoring", response_class=HTMLResponse)
    def monitoring_page():
        return HTMLResponse(_monitoring_html())

    @router.get("/monitoring.json", response_model=MonitoringEnvelopeAPI)
    def monitoring_api():
        return list_monitor_schedules()

    @router.get("/monitoring/due", response_model=MonitoringDueAPI)
    def monitoring_due_api():
        return due_monitor_schedules()

    @router.post("/monitoring/schedules", response_model=MonitorScheduleAddAPI)
    def monitoring_add_api(
        target: str,
        module: str = "auto",
        case_prefix: str | None = None,
        interval_minutes: int = 1440,
        enabled: bool = True,
    ):
        return add_monitor_schedule(
            target,
            module=module,
            case_prefix=case_prefix,
            interval_minutes=interval_minutes,
            enabled=enabled,
        )

    @router.post("/monitoring/run-due", response_model=MonitoringRunAPI)
    def monitoring_run_due_api(
        max_runs: int | None = None,
        dry_run: bool = False,
    ):
        return run_due_monitor_schedules(max_runs=max_runs, execute=not dry_run)

    @router.post("/monitoring/add", response_class=HTMLResponse)
    async def monitoring_add_form(request: Request):
        body = (await request.body()).decode("utf-8", errors="replace")
        fields = parse_qs(body, keep_blank_values=True)
        target = fields.get("target", [""])[0].strip()
        module = fields.get("module", ["auto"])[0].strip() or "auto"
        case_prefix = fields.get("case_prefix", [""])[0].strip() or None
        try:
            interval_minutes = int(fields.get("interval_minutes", ["1440"])[0] or "1440")
            if interval_minutes < 1:
                raise ValueError
        except ValueError:
            return HTMLResponse(_monitoring_html("interval_minutes must be a positive integer"))
        if target:
            add_monitor_schedule(
                target,
                module=module,
                case_prefix=case_prefix,
                interval_minutes=interval_minutes,
            )
        return RedirectResponse("/monitoring", status_code=303)

    @router.post("/monitoring/run-due-form", response_class=HTMLResponse)
    async def monitoring_run_due_form(request: Request):
        body = (await request.body()).decode("utf-8", errors="replace")
        fields = parse_qs(body, keep_blank_values=True)
        raw_max = fields.get("max_runs", [""])[0].strip()
        max_runs = int(raw_max) if raw_max else None
        dry_run = fields.get("dry_run", ["0"])[0] in {"1", "true", "yes"}
        result = run_due_monitor_schedules(max_runs=max_runs, execute=not dry_run)
        summary = result.get("summary") or {}
        return HTMLResponse(
            _monitoring_html(
                f"Processed {summary.get('processed', 0)} due monitor(s); alerts {summary.get('alerts', 0)}."
            )
        )

else:
    router = None

