from __future__ import annotations

from html import escape
from urllib.parse import parse_qs

try:
    from fastapi import APIRouter, HTTPException, Request
    from fastapi.responses import HTMLResponse
except Exception:  # pragma: no cover
    APIRouter = None
    HTTPException = Exception
    Request = None
    HTMLResponse = None

from ...core.case_admin import schema_status
from ..assets import asset_tags, style_tag
from ..schemas import AuthStatusAPI, StorageSchemaAPI
from ..security import (
    AUTH_COOKIE,
    auth_enabled,
    secure_cookie_enabled,
    security_status,
    session_cookie_value,
    token_matches,
)
from ..templating import TEMPLATE_ENV
from .pages import header_html


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _html_response(html: str) -> HTMLResponse:
    return HTMLResponse(html)


def login_html(message: str = "") -> str:
    status = security_status()
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("login.html").render(
            asset_tags=asset_tags(),
            login_style=style_tag("login.css"),
            header=header_html("auth"),
            message=message,
            disabled=not status.enabled,
        )
    message_html = f'<div class="muted">{_e(message)}</div>' if message else ""
    disabled = "" if status.enabled else " disabled"
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BEDNIIOSINT Login</title>
{asset_tags()}
{style_tag("login.css")}
</head>
<body>
{header_html("auth")}
<main class="login-shell">
  <section class="login-panel">
    <h1>Dashboard Access</h1>
    {message_html}
    <form class="search-form" method="post" action="/auth/login">
      <label>Token<input name="token" type="password" autocomplete="current-password"{disabled}></label>
      <button type="submit"{disabled}>Sign In</button>
    </form>
  </section>
</main>
</body>
</html>"""


router = APIRouter() if APIRouter is not None else None

if router is not None:

    @router.get("/auth/status", response_model=AuthStatusAPI)
    def auth_status_api():
        return security_status().as_dict()

    @router.get("/auth/login", response_class=HTMLResponse)
    def auth_login_page():
        return _html_response(login_html(""))

    @router.post("/auth/login", response_class=HTMLResponse)
    async def auth_login_api(request: Request):
        if not auth_enabled():
            return _html_response(login_html("Dashboard auth is not enabled."))
        body = (await request.body()).decode("utf-8", errors="replace")
        fields = parse_qs(body, keep_blank_values=True)
        token = fields.get("token", [""])[0]
        if not token_matches(token):
            raise HTTPException(401, "invalid token")
        response = _html_response(login_html("Authenticated."))
        response.set_cookie(
            AUTH_COOKIE,
            session_cookie_value(),
            httponly=True,
            samesite="lax",
            secure=secure_cookie_enabled(),
        )
        return response

    @router.post("/auth/logout", response_class=HTMLResponse)
    def auth_logout_api():
        response = _html_response(login_html("Logged out."))
        response.delete_cookie(AUTH_COOKIE)
        return response

    @router.get("/storage/schema", response_model=StorageSchemaAPI)
    def storage_schema_api(case: str | None = None):
        return schema_status(case)
