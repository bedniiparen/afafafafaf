from __future__ import annotations

import json
from html import escape
from pathlib import Path
from urllib.parse import quote

try:
    from fastapi import APIRouter, HTTPException
    from fastapi.responses import HTMLResponse
except Exception:  # pragma: no cover
    APIRouter = None
    HTTPException = Exception
    HTMLResponse = None

from ...config import settings
from ...core.case_lookup import case_ids
from ...core.case_summary import build_case_summary
from ...graph.builder import build_graph, graph_metrics
from ...graph.export import to_cytoscape
from ...storage.sqlite import Storage
from ..assets import asset_tags, script_tag, style_tag
from ..templating import TEMPLATE_ENV, safe_markup


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _header_html(active: str = "history") -> str:
    def nav_item(label: str, href: str, key: str) -> str:
        cls = "nav active" if active == key else "nav"
        return f'<a class="{cls}" href="{href}">{_e(label)}</a>'

    return (
        "<header><div class=\"topbar\">"
        "<a class=\"brand\" href=\"/\">"
        "<span class=\"brand-mark\">B</span><span>BEDNIIOSINT</span>"
        "</a><nav>"
        f"{nav_item('Search', '/', 'search')}"
        f"{nav_item('History', '/history', 'history')}"
        f"{nav_item('Jobs', '/jobs', 'jobs')}"
        f"{nav_item('Sources', '/sources', 'sources')}"
        f"{nav_item('Plugins', '/plugins', 'plugins')}"
        f"{nav_item('Reports', '/reports', 'reports')}"
        '<div class="theme-switch" role="group" aria-label="Theme">'
        '<button class="theme-button" id="themeToggle" type="button" '
        'data-theme-toggle aria-pressed="false" title="Switch theme">Theme</button>'
        "</div></nav></div></header>"
    )


def _storage(case: str) -> Storage:
    path = settings.db_path(case)
    if not Path(path).exists():
        raise HTTPException(404, f"case '{case}' not found")
    return Storage(path)


def graph_html(name: str, graph) -> str:
    data = to_cytoscape(graph)["elements"]
    metrics = graph_metrics(graph)
    payload = json.dumps(data, ensure_ascii=False).replace("<", "\\u003c")
    types = sorted(
        {
            str(node.get("data", {}).get("type") or "unknown")
            for node in data.get("nodes", [])
        }
    )
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("graph.html").render(
            asset_tags=safe_markup(asset_tags()),
            graph_style=safe_markup(style_tag("graph.css")),
            graph_script=safe_markup(script_tag("graph.js")),
            header=safe_markup(_header_html("history")),
            name=name,
            nodes=metrics.get("nodes"),
            edges=metrics.get("edges"),
            api_href=f"/cases/{quote(name, safe='')}/graph",
            types=types,
            payload=safe_markup(payload),
        )
    return _graph_html_fallback(name, metrics, data, payload, types)


def _graph_html_fallback(name: str, metrics: dict, data: dict, payload: str, types: list[str]) -> str:
    del data
    type_options = "".join(
        f'<option value="{_e(node_type)}">{_e(node_type)}</option>'
        for node_type in types
    )
    name_url = quote(name, safe="")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BEDNIIOSINT Graph</title>
{asset_tags()}
{style_tag("graph.css")}
</head>
<body>
{_header_html("history")}
<main>
<div class="page-head">
  <div>
    <h1>Graph: {_e(name)}</h1>
    <div class="muted">{_e(metrics.get("nodes"))} nodes | {_e(metrics.get("edges"))} edges | interactive canvas</div>
  </div>
  <a class="btn" href="/cases/{name_url}/graph" target="_blank">JSON API</a>
</div>
<section class="panel">
  <div class="graph-toolbar">
    <input id="graphSearch" placeholder="Search nodes" autocomplete="off">
    <select id="graphType"><option value="">All types</option>{type_options}</select>
    <button id="graphReset" type="button">Reset</button>
  </div>
  <div class="graph-workspace">
    <div class="graph-stage">
      <canvas id="graphCanvas" width="1040" height="620"></canvas>
      <div class="graph-legend" id="graphLegend"></div>
    </div>
    <aside class="inspector">
      <h2>Inspector</h2>
      <div id="nodeInfo" class="muted">Select a node.</div>
      <ul class="graph-list" id="nodeList"></ul>
    </aside>
  </div>
</section>
<script type="application/json" id="graphData">{payload}</script>
{script_tag("graph.js")}
</main>
</body>
</html>"""


def timeline_html(name: str, timeline: list[dict]) -> str:
    kinds = sorted({str(row.get("kind") or "unknown") for row in timeline})
    payload = json.dumps(timeline, ensure_ascii=False, default=str).replace("<", "\\u003c")
    kind_cards = [
        {"kind": kind, "count": sum(1 for row in timeline if row.get("kind") == kind)}
        for kind in kinds[:4]
    ]
    if TEMPLATE_ENV is not None:
        return TEMPLATE_ENV.get_template("timeline.html").render(
            asset_tags=safe_markup(asset_tags()),
            timeline_style=safe_markup(style_tag("timeline.css")),
            timeline_script=safe_markup(script_tag("timeline.js")),
            header=safe_markup(_header_html("history")),
            name=name,
            events=len(timeline),
            api_href=f"/cases/{quote(name, safe='')}/timeline",
            kinds=kinds,
            kind_cards=kind_cards,
            payload=safe_markup(payload),
        )
    return _timeline_html_fallback(name, timeline, payload, kinds, kind_cards)


def _timeline_html_fallback(
    name: str,
    timeline: list[dict],
    payload: str,
    kinds: list[str],
    kind_cards: list[dict],
) -> str:
    kind_options = "".join(
        f'<option value="{_e(kind)}">{_e(kind)}</option>' for kind in kinds
    )
    kind_card_html = "".join(
        f'<div class="card"><div class="n">{_e(card["count"])}</div><div class="l">{_e(card["kind"])}</div></div>'
        for card in kind_cards
    )
    name_url = quote(name, safe="")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BEDNIIOSINT Timeline</title>
{asset_tags()}
{style_tag("timeline.css")}
</head>
<body>
{_header_html("history")}
<main>
<div class="page-head">
  <div>
    <h1>Timeline: {_e(name)}</h1>
    <div class="muted">{len(timeline)} events</div>
  </div>
  <a class="btn" href="/cases/{name_url}/timeline" target="_blank">JSON API</a>
</div>
<div class="cards">
  <div class="card"><div class="n">{len(timeline)}</div><div class="l">Events</div></div>
  {kind_card_html}
</div>
<section class="panel">
  <div class="timeline-toolbar">
    <input id="timelineSearch" placeholder="Search events" autocomplete="off">
    <select id="timelineKind"><option value="">All kinds</option>{kind_options}</select>
    <button id="timelineReset" type="button">Reset</button>
  </div>
  <div class="timeline-stream" id="timelineStream"></div>
</section>
<script type="application/json" id="timelineData">{payload}</script>
{script_tag("timeline.js")}
</main>
</body>
</html>"""


if APIRouter is not None:
    router = APIRouter()

    @router.get("/graph/{name}", response_class=HTMLResponse)
    def graph_page(name: str):
        summary = build_case_summary(name)
        if not summary.get("meta", {}).get("found"):
            raise HTTPException(404, "case not found")
        storage = _storage(name)
        ids = case_ids(storage, name)
        result = build_graph(storage, ids)
        return HTMLResponse(graph_html(name, result))

    @router.get("/timeline/{name}", response_class=HTMLResponse)
    def timeline_page(name: str):
        summary = build_case_summary(name)
        if not summary.get("meta", {}).get("found"):
            raise HTTPException(404, "case not found")
        return HTMLResponse(timeline_html(name, summary.get("timeline", [])))

else:  # pragma: no cover
    router = None
