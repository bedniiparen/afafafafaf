from __future__ import annotations

from html import escape
import logging
from pathlib import Path
import re
from typing import Any

try:
    from fastapi import FastAPI, HTTPException, Request
    from fastapi.responses import (
        HTMLResponse,
        JSONResponse,
    )
    from fastapi.staticfiles import StaticFiles
except Exception:  # pragma: no cover
    FastAPI = None
    HTTPException = Exception
    Request = None
    HTMLResponse = None
    JSONResponse = None
    StaticFiles = None

from ..config import settings
from ..observability import setup_tracing
from ..core.case_lookup import case_ids
from ..core.case_summary import build_case_summary
from ..core.case_workspace import get_workspace
from ..graph.export import graph_from_cytoscape_elements, write_gexf, write_graph_json, write_graphml
from ..evidence.bundle import inspect_evidence_bundle
from ..evidence.manifest import write_evidence_manifest
from ..reports.case_html import write_case_html
from ..reports.csv import write_case_csv
from ..reports.json import write_json
from ..reports.markdown import write_case_markdown
from ..reports.manifest import (
    write_report_manifest,
)
from ..reports.view_model import build_report_view_model
from ..reports.misp import write_misp_event
from ..reports.opencti import write_opencti_envelope
from ..reports.pdf import html_to_pdf, pdf_unavailable_reason
from ..reports.stix import write_stix, write_taxii_envelope
from ..storage.sqlite import Storage
from .assets import (
    STATIC_CACHE_CONTROL,
    STATIC_DIR,
)
from .routers.api_keys import build_api_keys_router
from .routers.auth import login_html as _login_html
from .routers.auth import router as auth_router
from .routers.case_page import build_case_page_router
from .routers.case_page import case_html as _case_html
from .routers.cases import router as cases_router
from .routers.jobs import router as jobs_router
from .routers.live_results import router as live_results_router
from .routers.metrics import router as metrics_router
from .routers.monitoring import router as monitoring_router
from .routers.pages import (
    case_rows as _case_rows,
    clear_history as _clear_history,
    header_html as _page_header_html,
    history_html as _history_html,
    index_html as _index_html,
    unhide_history_case as _unhide_history_case,
)
from .routers.pages import router as pages_router
from .routers.plugins import router as plugins_router
from .routers.reports import build_reports_router
from .routers.run import build_run_router
from .routers.run import result_html as _result_html
from .routers.search import router as search_router
from .routers.source_health import router as source_health_router
from .routers.sources import router as sources_router
from .routers.visualizations import router as visualizations_router
from .security import (
    csrf_token,
    csrf_valid,
    request_is_authenticated,
    should_skip_security,
)

logger = logging.getLogger(__name__)

if FastAPI is None:  # pragma: no cover

    async def app(scope, receive, send):
        if scope.get("type") != "http":
            return
        body = (
            b"BEDNIIOSINT dashboard requires fastapi. "
            b"Install optional dependencies and run uvicorn again."
        )
        await send(
            {
                "type": "http.response.start",
                "status": 503,
                "headers": [(b"content-type", b"text/plain; charset=utf-8")],
            }
        )
        await send({"type": "http.response.body", "body": body})

else:
    app = FastAPI(title="BEDNIIOSINT Dashboard", version="0.6")
    setup_tracing(app)
    if StaticFiles is not None:
        app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
    app.include_router(cases_router)
    app.include_router(jobs_router)
    app.include_router(live_results_router)
    app.include_router(monitoring_router)
    app.include_router(auth_router)
    app.include_router(pages_router)
    app.include_router(metrics_router)
    app.include_router(sources_router)
    app.include_router(source_health_router)
    app.include_router(plugins_router)
    app.include_router(search_router)
    app.include_router(visualizations_router)


if FastAPI is not None:

    @app.middleware("http")
    async def static_cache_middleware(request: Request, call_next):
        response = await call_next(request)
        if request.url.path == "/static" or request.url.path.startswith("/static/"):
            response.headers.setdefault("Cache-Control", STATIC_CACHE_CONTROL)
        return response

    @app.middleware("http")
    async def web_security_middleware(request: Request, call_next):
        if should_skip_security(request.url.path):
            return await call_next(request)
        if not request_is_authenticated(request):
            return JSONResponse(
                {"detail": "authentication required"},
                status_code=401,
                headers={"WWW-Authenticate": "Bearer"},
            )
        body = b""
        secured_request = request
        method = request.method.upper()
        content_type = str(request.headers.get("content-type", "")).lower()
        if method in {"POST", "PUT", "PATCH", "DELETE"} and "application/x-www-form-urlencoded" in content_type:
            body = await request.body()

            async def receive():
                return {"type": "http.request", "body": body, "more_body": False}

            secured_request = Request(request.scope, receive)
        if not csrf_valid(secured_request, body):
            return JSONResponse({"detail": "CSRF token required"}, status_code=403)
        return await call_next(secured_request)


API_SCHEMA_MODELS = (
    "AuthStatusAPI",
    "ApiKeyStatusAPI",
    "CaseMergeResultAPI",
    "CaseDiffAPI",
    "CaseSummaryAPI",
    "DedupeCaseAPI",
    "DeleteRelationAPI",
    "EntityMergeAPI",
    "EntityMergeResultAPI",
    "EntitySplitAPI",
    "EntitySplitResultAPI",
    "EvidenceManifestAPI",
    "FindingAPI",
    "FindingDetailAPI",
    "GraphAPI",
    "JobAPI",
    "JobEventAPI",
    "InvestigationPlanAPI",
    "LiveValidationAuditEnvelopeAPI",
    "LiveValidationAuditEventAPI",
    "LiveValidationCleanupEnvelopeAPI",
    "LiveValidationHistoryEnvelopeAPI",
    "LiveValidationResultAPI",
    "MigrationRecordAPI",
    "MonitorScheduleAddAPI",
    "MonitoringDueAPI",
    "MonitoringEnvelopeAPI",
    "MonitoringRunAPI",
    "NoteAPI",
    "NoteCreateAPI",
    "PipelineRunAPI",
    "PipelineSourcesAPI",
    "PluginManifestAPI",
    "RelationAPI",
    "RelationCreateAPI",
    "ReportManifestAPI",
    "ReportVerificationAPI",
    "EvidenceBundleInspectionAPI",
    "SearchPlanAPI",
    "SearchIndexAPI",
    "SearchRunAPI",
    "SearchSourcesAPI",
    "SourceHealthAPI",
    "SourceHealthEnvelopeAPI",
    "SourceRuntimeHealthEnvelopeAPI",
    "SourceMaintenanceAPI",
    "SourceMaintenanceEnvelopeAPI",
    "SourceVerificationAPI",
    "SourceVerificationEnvelopeAPI",
    "StorageSchemaAPI",
    "TimelineEventCreateAPI",
    "TimelineRowAPI",
    "UsernameSourcesAPI",
    "WorkerStatusAPI",
    "WorkspaceAPI",
)

JSON_API_CONTRACT = (
    {"method": "GET", "path": "/auth/status", "response_model": "AuthStatusAPI"},
    {"method": "GET", "path": "/plugins.json", "response_model": "list[PluginManifestAPI]"},
    {"method": "GET", "path": "/sources/health", "response_model": "SourceHealthEnvelopeAPI"},
    {"method": "GET", "path": "/api/source-health", "response_model": "SourceRuntimeHealthEnvelopeAPI"},
    {"method": "GET", "path": "/sources/maintenance", "response_model": "SourceMaintenanceEnvelopeAPI"},
    {"method": "GET", "path": "/sources/verify", "response_model": "SourceVerificationEnvelopeAPI"},
    {"method": "GET", "path": "/live-results", "response_model": "LiveValidationHistoryEnvelopeAPI"},
    {"method": "GET", "path": "/live-results/cleanup", "response_model": "LiveValidationCleanupEnvelopeAPI"},
    {"method": "GET", "path": "/live-results/audit", "response_model": "LiveValidationAuditEnvelopeAPI"},
    {"method": "GET", "path": "/monitoring.json", "response_model": "MonitoringEnvelopeAPI"},
    {"method": "GET", "path": "/monitoring/due", "response_model": "MonitoringDueAPI"},
    {"method": "POST", "path": "/monitoring/schedules", "response_model": "MonitorScheduleAddAPI"},
    {"method": "POST", "path": "/monitoring/run-due", "response_model": "MonitoringRunAPI"},
    {"method": "GET", "path": "/username/sources", "response_model": "UsernameSourcesAPI"},
    {"method": "GET", "path": "/search/plan", "response_model": "SearchPlanAPI"},
    {"method": "GET", "path": "/search/index", "response_model": "SearchIndexAPI"},
    {"method": "GET", "path": "/search/run", "response_model": "SearchRunAPI"},
    {"method": "GET", "path": "/search/sources", "response_model": "SearchSourcesAPI"},
    {"method": "GET", "path": "/investigation/plan", "response_model": "InvestigationPlanAPI"},
    {"method": "GET", "path": "/pipeline/sources/{input_type}", "response_model": "PipelineSourcesAPI"},
    {"method": "GET", "path": "/pipeline/run", "response_model": "PipelineRunAPI"},
    {"method": "GET", "path": "/reports-manifest.json", "response_model": "ReportManifestAPI"},
    {"method": "GET", "path": "/reports/verify", "response_model": "ReportVerificationAPI"},
    {"method": "GET", "path": "/reports/evidence-bundle/{case_name}/inspect", "response_model": "EvidenceBundleInspectionAPI"},
    {"method": "GET", "path": "/storage/schema", "response_model": "StorageSchemaAPI"},
    {"method": "GET", "path": "/jobs.json", "response_model": "list[JobAPI]"},
    {"method": "GET", "path": "/jobs/worker/status", "response_model": "WorkerStatusAPI"},
    {"method": "POST", "path": "/jobs/worker/start", "response_model": "WorkerStatusAPI"},
    {"method": "POST", "path": "/jobs/worker/stop", "response_model": "WorkerStatusAPI"},
    {"method": "POST", "path": "/jobs", "response_model": "JobAPI"},
    {"method": "GET", "path": "/jobs/{job_id}", "response_model": "JobAPI"},
    {"method": "GET", "path": "/jobs/{job_id}/events", "response_model": "list[JobEventAPI]"},
    {"method": "POST", "path": "/jobs/{job_id}/run", "response_model": "JobAPI"},
    {"method": "POST", "path": "/jobs/{job_id}/resume", "response_model": "JobAPI"},
    {"method": "POST", "path": "/jobs/{job_id}/cancel", "response_model": "JobAPI"},
    {"method": "GET", "path": "/cases/{name}/findings", "response_model": "list[FindingAPI]"},
    {"method": "POST", "path": "/cases/{name}/findings/{finding_id}/recheck", "response_model": "CaseSummaryAPI"},
    {"method": "GET", "path": "/cases/{name}/summary", "response_model": "CaseSummaryAPI"},
    {"method": "GET", "path": "/cases/{name}/workspace", "response_model": "WorkspaceAPI"},
    {"method": "GET", "path": "/cases/{name}/findings/{finding_id}", "response_model": "FindingDetailAPI"},
    {"method": "POST", "path": "/cases/{name}/notes", "response_model": "NoteAPI"},
    {"method": "POST", "path": "/cases/{name}/timeline", "response_model": "TimelineRowAPI"},
    {"method": "POST", "path": "/cases/{name}/relations", "response_model": "RelationAPI"},
    {"method": "PUT", "path": "/cases/{name}/relations/{relation_id}", "response_model": "RelationAPI"},
    {"method": "DELETE", "path": "/cases/{name}/relations/{relation_id}", "response_model": "DeleteRelationAPI"},
    {"method": "POST", "path": "/cases/{name}/entities/merge", "response_model": "EntityMergeResultAPI"},
    {"method": "POST", "path": "/cases/{name}/entities/split", "response_model": "EntitySplitResultAPI"},
    {"method": "POST", "path": "/cases/{name}/dedupe", "response_model": "DedupeCaseAPI"},
    {"method": "POST", "path": "/cases/{target}/merge/{source}", "response_model": "CaseMergeResultAPI"},
    {"method": "GET", "path": "/cases/diff", "response_model": "CaseDiffAPI"},
    {"method": "GET", "path": "/cases/{name}/evidence-manifest", "response_model": "EvidenceManifestAPI"},
    {"method": "GET", "path": "/cases/{name}/graph", "response_model": "GraphAPI"},
    {"method": "GET", "path": "/cases/{name}/timeline", "response_model": "list[TimelineRowAPI]"},
)


def api_schema_contract() -> dict[str, Any]:
    return {
        "schema_version": "0.1",
        "models": list(API_SCHEMA_MODELS),
        "routes": [dict(row) for row in JSON_API_CONTRACT],
    }


def _openapi_schema_for_response_model(model: str) -> dict[str, Any]:
    if model.startswith("list[") and model.endswith("]"):
        return {
            "type": "array",
            "items": {"$ref": f"#/components/schemas/{model[5:-1]}"},
        }
    return {"$ref": f"#/components/schemas/{model}"}


def api_contract_openapi() -> dict[str, Any]:
    contract = api_schema_contract()
    paths: dict[str, Any] = {}
    for route in contract["routes"]:
        path = route["path"]
        method = route["method"].lower()
        paths.setdefault(path, {})[method] = {
            "responses": {
                "200": {
                    "description": "Successful Response",
                    "content": {
                        "application/json": {
                            "schema": _openapi_schema_for_response_model(
                                route["response_model"]
                            )
                        }
                    },
                }
            }
        }
    return {
        "openapi": "3.1.0",
        "info": {"title": "BEDNIIOSINT Dashboard", "version": "0.6"},
        "paths": paths,
        "components": {
            "schemas": {
                name: {
                    "title": name,
                    "type": "object",
                    "additionalProperties": True,
                }
                for name in contract["models"]
            }
        },
    }


if FastAPI is None:
    setattr(app, "openapi", api_contract_openapi)


def _storage(case: str) -> Storage:
    path = settings.db_path(case)
    if not Path(path).exists():
        raise HTTPException(404, f"case '{case}' not found")
    return Storage(path)


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def compact_date(value: Any) -> str:
    return str(value or "").replace("T", " ").replace("+00:00", "")[:19] or "unknown"


def _secure_html(html: str) -> str:
    token = csrf_token()
    if not token:
        return html
    meta = f'<meta name="csrf-token" content="{_e(token)}">'
    if "<head>" in html:
        html = html.replace("<head>", f"<head>\n{meta}", 1)
    hidden = f'<input type="hidden" name="_csrf" value="{_e(token)}">'
    pattern = re.compile(
        r"(<form\b(?=[^>]*\bmethod=[\"']post[\"'])[^>]*>)",
        flags=re.IGNORECASE,
    )
    return pattern.sub(lambda match: match.group(1) + hidden, html)


def _html_response(html: str) -> HTMLResponse:
    return HTMLResponse(_secure_html(html))


def _reports_root() -> Path:
    return settings.db_dir.parent / "reports_out"


def _reports_dir() -> Path:
    path = _reports_root()
    path.mkdir(parents=True, exist_ok=True)
    return path


def _write_outputs(case: str, module: str, summary: dict) -> dict[str, Path]:
    out_dir = _reports_dir()
    files: dict[str, Path] = {}

    files["module_json"] = write_json(summary, out_dir / f"{case}-{module}.json")
    case_summary = build_case_summary(case)
    report_view = build_report_view_model(case_summary)
    files["case_json"] = write_json(case_summary, out_dir / f"{case}-case.json")
    files["technical_json"] = write_json(report_view, out_dir / f"{case}-technical.json")
    files["case_html"] = write_case_html(case_summary, out_dir / f"{case}-case.html")
    files["case_markdown"] = write_case_markdown(case_summary, out_dir / f"{case}-case.md")
    pdf_path = html_to_pdf(files["case_html"], out_dir / f"{case}-case.pdf")
    if pdf_path is not None:
        files["case_pdf"] = pdf_path
    elif pdf_unavailable_reason():
        logger.warning("%s", pdf_unavailable_reason())
    files["stix"] = write_stix(case_summary, out_dir / f"{case}-stix.json")
    files["taxii"] = write_taxii_envelope(case_summary, out_dir / f"{case}-taxii.json")
    files["opencti"] = write_opencti_envelope(case_summary, out_dir / f"{case}-opencti.json")
    files["misp"] = write_misp_event(case_summary, out_dir / f"{case}-misp.json")
    for name, path in write_case_csv(case_summary, out_dir, case).items():
        files[f"csv_{name}"] = path

    ids = case_ids(Storage(settings.db_path(case)), case)
    if ids:
        storage = Storage(settings.db_path(case))
        display = get_workspace(case).get("graph") or {}
        elements = {
            "nodes": display.get("nodes") or [],
            "edges": display.get("edges") or [],
        }
        graph = graph_from_cytoscape_elements(elements)
        files["graph_json"] = write_graph_json(graph, out_dir / f"{case}-graph.json")
        files["graphml"] = write_graphml(graph, out_dir / f"{case}-graphml.graphml")
        files["gexf"] = write_gexf(graph, out_dir / f"{case}-gexf.gexf")
        files["evidence_manifest"] = write_evidence_manifest(
            storage,
            ids,
            out_dir / f"{case}-evidence-manifest.json",
        )
    files["manifest"] = write_report_manifest(out_dir)
    return files


def _header_html(active: str = "") -> str:
    return _page_header_html(active)


def _base_css() -> str:
    return ""

def _evidence_bundle_inspection(bundle: Path) -> dict[str, Any]:
    errors: list[str] = []
    if not bundle.exists() or not bundle.is_file():
        return {
            "valid": False,
            "bundle": str(bundle),
            "manifest": {},
            "signature": None,
            "signature_verified": None,
            "files": [],
            "errors": [f"evidence bundle not found: {bundle}"],
            "secrets_returned": False,
        }
    try:
        inspected = inspect_evidence_bundle(bundle)
    except (OSError, ValueError) as exc:
        return {
            "valid": False,
            "bundle": str(bundle),
            "manifest": {},
            "signature": None,
            "signature_verified": None,
            "files": [],
            "errors": [f"evidence bundle inspection failed: {exc}"],
            "secrets_returned": False,
        }
    for row in inspected.get("files", []):
        if not row.get("present"):
            errors.append(f"bundle member missing: {row.get('archive_path')}")
        if row.get("sha256_ok") is False:
            errors.append(f"bundle member SHA-256 mismatch: {row.get('archive_path')}")
    if inspected.get("signature_verified") is False:
        errors.append("evidence bundle signature verification failed")
    return {
        "valid": not errors,
        "bundle": str(bundle),
        "manifest": inspected.get("manifest") or {},
        "signature": inspected.get("signature"),
        "signature_verified": inspected.get("signature_verified"),
        "files": list(inspected.get("files") or []),
        "errors": errors,
        "secrets_returned": False,
    }


if FastAPI is not None:
    app.include_router(
        build_run_router(
            write_outputs=_write_outputs,
            unhide_history_case=_unhide_history_case,
            html_response=_html_response,
        )
    )
    app.include_router(
        build_case_page_router(
            write_outputs=_write_outputs,
            html_response=_html_response,
        )
    )
    app.include_router(build_api_keys_router())
    app.include_router(
        build_reports_router(
            reports_dir=_reports_dir,
            storage_for_case=_storage,
            evidence_bundle_inspection=_evidence_bundle_inspection,
            html_response=_html_response,
        )
    )

