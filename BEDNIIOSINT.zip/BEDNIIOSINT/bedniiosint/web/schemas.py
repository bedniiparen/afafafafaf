from __future__ import annotations

from typing import Any

try:
    from pydantic import BaseModel, ConfigDict, Field
except Exception:  # pragma: no cover
    BaseModel = None
    ConfigDict = None
    Field = None


if BaseModel is not None:

    class APIModel(BaseModel):
        model_config = ConfigDict(extra="allow")


    class AuthStatusAPI(APIModel):
        enabled: bool
        csrf_required: bool
        auth_methods: list[str]


    class MigrationRecordAPI(APIModel):
        version: int
        name: str
        applied_at: str | None = None


    class StorageSchemaAPI(APIModel):
        current_version: int
        latest_version: int
        applied: list[MigrationRecordAPI]
        pending: list[MigrationRecordAPI]
        database: str


    class ApiKeyStatusAPI(APIModel):
        name: str
        configured: bool
        required: bool
        sources: list[str]


    class SourceHealthAPI(APIModel):
        source_id: str
        name: str
        status: str
        reason: str
        configured: bool
        runnable: bool
        missing_env: list[str]
        inputs: list[str]
        auth_required: bool
        docs_url: str
        source_maturity: str
        terms_risk: str
        cache_policy: str
        quota_policy: str
        priority: str
        product_value: str
        setup_hint: str
        requires_opt_in: bool
        remediation: str
        verification_status: str
        contract_gaps: list[str]


    class SourceHealthEnvelopeAPI(APIModel):
        summary: dict[str, Any]
        sources: list[SourceHealthAPI]
        api_keys: list[ApiKeyStatusAPI]


    class SourceRuntimeHealthAPI(APIModel):
        source_id: str
        requests: int
        attempts: int | None = None
        successes: int | None = None
        failures: int | None = None
        success_rate: float | None = None
        avg_latency: float | None = None
        results: int | None = None
        last_status: Any = None
        last_error: str = ""
        last_ts: float | None = None
        health: str | None = None


    class SourceRuntimeHealthEnvelopeAPI(APIModel):
        sources: list[SourceRuntimeHealthAPI]


    class SourceMaintenanceAPI(APIModel):
        source_id: str
        name: str
        priority: str
        maintenance_status: str
        readiness_score: int
        live_readiness: str
        next_action: str
        blockers: list[str]
        warnings: list[str]
        fixture_variants: list[str]
        missing_env: list[str]
        verification_status: str
        docs_url: str
        terms_risk: str


    class SourceMaintenanceEnvelopeAPI(APIModel):
        summary: dict[str, Any]
        top_actions: list[SourceMaintenanceAPI]
        sources: list[SourceMaintenanceAPI]


    class SourceVerificationAPI(APIModel):
        source_id: str
        name: str
        mode: str
        status: str
        reason: str
        checks: list[str]
        errors: list[str]
        health_status: str
        verification_status: str
        contract_gaps: list[str]
        fixture_path: str
        fixture_variant: str
        normalized_counts: dict[str, int]
        live_health: dict[str, Any]
        target: str


    class SourceVerificationEnvelopeAPI(APIModel):
        summary: dict[str, Any]
        results: list[SourceVerificationAPI]


    class PluginManifestAPI(APIModel):
        name: str
        consumes: list[str]
        produces: list[str]
        version: str
        entrypoint: str
        description: str
        source_id: str
        auth: str
        env_vars: list[str]
        path: str
        enabled: bool
        config: dict[str, Any]
        signature: dict[str, Any]
        signature_status: dict[str, Any]
        validation: dict[str, Any] = Field(default_factory=dict)


    class PipelineSourcesAPI(APIModel):
        input_type: str
        sources: list[str]


    class PipelineRunAPI(APIModel):
        target: str
        input_type: str
        sources: list[str]
        results: list[dict[str, Any]]
        normalized: list[dict[str, Any]]
        persisted: list[dict[str, Any]]
        persisted_case: dict[str, Any]
        counts: dict[str, int]


    class SearchPlanAPI(APIModel):
        entity_input: str
        entity_type: str
        scope: str
        sources: list[dict[str, Any]]
        queries: list[dict[str, Any]]
        variant_details: list[dict[str, Any]]


    class SearchRunAPI(APIModel):
        target: str
        entity_input: str
        entity_type: str
        scope: str
        search_source_ids: list[str]
        catalog_source_ids: list[str]
        plan: dict[str, Any]
        pipeline: dict[str, Any]
        search_results: list[dict[str, Any]]
        correlations: list[dict[str, Any]] = Field(default_factory=list)
        identities: list[dict[str, Any]] = Field(default_factory=list)
        identity_clusters: list[dict[str, Any]] = Field(default_factory=list)
        visual_artifacts: dict[str, Any] = Field(default_factory=dict)
        source_health: dict[str, Any] = Field(default_factory=dict)
        source_health_markdown: str = ""
        result_groups: dict[str, Any] = Field(default_factory=dict)
        result_group_counts: dict[str, int] = Field(default_factory=dict)
        source_event_plan: dict[str, Any] = Field(default_factory=dict)
        result_pivots: dict[str, Any] = Field(default_factory=dict)
        result_clusters: list[dict[str, Any]] = Field(default_factory=list)
        dedup_summary: dict[str, Any] = Field(default_factory=dict)
        evidence_summary: dict[str, Any]
        run_evidence: dict[str, Any] = Field(default_factory=dict)
        run_summary: dict[str, Any] = Field(default_factory=dict)
        report_summary: dict[str, Any] = Field(default_factory=dict)
        report_markdown: str = ""
        execution: dict[str, Any] = Field(default_factory=dict)
        counts: dict[str, int]
        dry_run: bool = False
        planned_catalog_source_ids: list[str] = Field(default_factory=list)
        skipped_catalog_sources: list[dict[str, Any]] = Field(default_factory=list)
        skipped_search_sources: list[dict[str, Any]] = Field(default_factory=list)
        sources: list[dict[str, Any]] = Field(default_factory=list)


    class SearchIndexAPI(APIModel):
        query: str
        case: str
        db_path: str
        count: int
        results: list[dict[str, Any]]


    class SearchSourcesAPI(APIModel):
        summary: dict[str, Any]
        sources: list[dict[str, Any]]


    class InvestigationPlanAPI(APIModel):
        target: str
        entity_input: str
        entity_type: str
        parsed_query: dict[str, Any]
        routes: list[dict[str, Any]]
        counts: dict[str, int]


    class UsernameSourcesAPI(APIModel):
        sites: int
        categories: dict[str, int]
        protected: int
        regex_checked: int
        supports_external_catalog: bool
        scale_target: str
        selected: int
        selected_names: list[str]


    class CaseDiffAPI(APIModel):
        schema_version: str
        entities: dict[str, Any]
        findings: dict[str, Any]
        relations: dict[str, Any]
        summary: dict[str, int]


    class FindingAPI(APIModel):
        source: str
        url: str
        status: str
        confidence: float
        rejected: bool


    class CaseSummaryAPI(APIModel):
        meta: dict[str, Any]
        result: dict[str, Any] = Field(default_factory=dict)
        entities: list[dict[str, Any]] = Field(default_factory=list)
        findings: list[dict[str, Any]] = Field(default_factory=list)
        relations: list[dict[str, Any]] = Field(default_factory=list)
        evidence: list[dict[str, Any]] = Field(default_factory=list)
        sources: list[dict[str, Any]] = Field(default_factory=list)
        pivot_plan: dict[str, Any] = Field(default_factory=dict)
        attachments: list[dict[str, Any]] = Field(default_factory=list)
        notes: list[dict[str, Any]] = Field(default_factory=list)
        timeline: list[dict[str, Any]] = Field(default_factory=list)
        graph: dict[str, Any] = Field(default_factory=dict)


    class WorkspaceAPI(APIModel):
        meta: dict[str, Any]
        counts: dict[str, int]
        findings: list[dict[str, Any]]
        generated_url_candidates: list[dict[str, Any]] = Field(default_factory=list)
        entities: list[dict[str, Any]]
        entity_resolution: dict[str, Any]
        relations: list[dict[str, Any]]
        sources: list[dict[str, Any]]
        timeline: list[dict[str, Any]]
        evidence: list[dict[str, Any]]
        attachments: list[dict[str, Any]]
        notes: list[dict[str, Any]]
        evidence_by_finding: dict[int, list[dict[str, Any]]]
        attachments_by_finding: dict[int, list[dict[str, Any]]]
        graph: dict[str, Any]
        manifest: dict[str, Any]
        integrity: dict[str, Any]
        presentation: dict[str, Any] = Field(default_factory=dict)
        workspace_model: dict[str, Any] = Field(default_factory=dict)
        tables: dict[str, Any] = Field(default_factory=dict)


    class FindingDetailAPI(APIModel):
        finding: dict[str, Any]
        evidence: list[dict[str, Any]]
        attachments: list[dict[str, Any]]


    class NoteCreateAPI(APIModel):
        entity_type: str
        entity_value: str
        note: str


    class TimelineEventCreateAPI(APIModel):
        kind: str
        entity_type: str
        entity_value: str
        when: str | None = None
        confidence: float = 1.0
        description: str = ""


    class RelationCreateAPI(APIModel):
        src_type: str
        src_value: str
        rel: str
        dst_type: str
        dst_value: str


    class RelationAPI(APIModel):
        id: int | None
        case_id: int
        src_type: str
        src_value: str
        rel: str
        dst_type: str
        dst_value: str


    class TimelineRowAPI(APIModel):
        id: int | None
        case_id: int
        finding_id: int | None = None
        when: str | None = None
        when_precision: str | None = None
        precision: str = "exact"
        kind: str
        entity_type: str
        entity_value: str
        entity: str | None = None
        source: str = ""
        source_name: str = ""
        confidence: float
        description: str = ""


    class NoteAPI(APIModel):
        id: int | None
        case_id: int
        entity_type: str
        entity_value: str
        note: str
        created_at: str


    class DeleteRelationAPI(APIModel):
        deleted: bool
        relation: RelationAPI


    class DedupeCaseAPI(APIModel):
        deduped: bool
        case: str
        removed: dict[str, int]


    class EntityMergeAPI(APIModel):
        from_type: str
        from_value: str
        into_type: str
        into_value: str
        note: str = ""


    class EntityMergeResultAPI(APIModel):
        merged: bool
        from_: dict[str, Any] = Field(default_factory=dict, alias="from")
        into: dict[str, Any] = Field(default_factory=dict)
        changed: dict[str, int]


    class EntitySplitAPI(APIModel):
        entity_type: str
        entity_value: str
        new_type: str
        new_value: str
        rel: str = "split_from"
        note: str = ""


    class EntitySplitResultAPI(APIModel):
        split: bool
        original: dict[str, Any]
        entity: dict[str, Any]
        relation: RelationAPI


    class CaseMergeResultAPI(APIModel):
        target: str
        source: str
        merged: dict[str, int]


    class EvidenceManifestAPI(APIModel):
        schema_version: str


    class GraphAPI(APIModel):
        metrics: dict[str, Any]
        elements: dict[str, list[dict[str, Any]]]


    class JobAPI(APIModel):
        id: int | None
        case_name: str
        target: str
        module: str
        status: str
        total_sources: int
        completed_sources: int
        current_source: str
        claimed_by: str
        claimed_at: str | None
        heartbeat_at: str | None
        progress: float
        cancel_requested: bool
        max_retries: int
        rate_limit_budget_json: str
        resume: bool
        error: str
        created_at: str
        updated_at: str
        finished_at: str | None


    class JobEventAPI(APIModel):
        id: int | None
        job_id: int
        kind: str
        source: str
        status: str
        message: str
        progress: float
        attempt: int
        budget_remaining: int | None
        created_at: str


    class WorkerStatusAPI(APIModel):
        running: bool
        last_job_id: int | None
        last_error: str
        jobs_run: int
        started_at: str | None
        queued: int
        claimed: int
        stale_active: int
        worker_id: str
        active: int
        status_counts: dict[str, int]
        polling: bool


    class LiveValidationResultAPI(APIModel):
        id: int | None
        run_id: str
        source_id: str
        name: str
        mode: str
        target: str
        status: str
        reason: str
        verification_status: str
        health_status: str
        network_required: bool
        allow_opt_in: bool
        checks: list[Any]
        errors: list[Any]
        live_health: dict[str, Any]
        redacted: bool
        recorded_at: str


    class LiveValidationHistoryEnvelopeAPI(APIModel):
        summary: dict[str, Any]
        results: list[LiveValidationResultAPI]


    class LiveValidationCleanupEnvelopeAPI(APIModel):
        summary: dict[str, Any]
        results: list[LiveValidationResultAPI]


    class LiveValidationAuditEventAPI(APIModel):
        id: int | None
        action: str
        channel: str
        source_id: str
        run_id: str
        filters: dict[str, Any]
        export_format: str
        matched: int
        affected: int
        dry_run: bool
        applied: bool
        output_path: str
        output_sha256: str
        output_bytes: int
        manifest_path: str
        secrets_returned: bool
        created_at: str


    class LiveValidationAuditEnvelopeAPI(APIModel):
        summary: dict[str, Any]
        results: list[LiveValidationAuditEventAPI]


    class MonitorScheduleAddAPI(APIModel):
        created: bool
        schedule: dict[str, Any]


    class MonitoringEnvelopeAPI(APIModel):
        summary: dict[str, Any]
        schedules: list[dict[str, Any]]
        alerts: list[dict[str, Any]]


    class MonitoringDueAPI(APIModel):
        summary: dict[str, Any]
        schedules: list[dict[str, Any]]


    class MonitoringRunAPI(APIModel):
        summary: dict[str, Any]
        results: list[dict[str, Any]]


    class ReportManifestAPI(APIModel):
        schema_version: str
        generated_at: str
        files: list[dict[str, Any]]
        cases: dict[str, Any] | list[dict[str, Any]]


    class ReportVerificationAPI(APIModel):
        valid: bool
        manifest_path: str
        reports_dir: str
        case: str
        summary: dict[str, Any]
        checks: dict[str, bool]
        files: list[dict[str, Any]]
        errors: list[str]
        secrets_returned: bool


    class EvidenceBundleInspectionAPI(APIModel):
        valid: bool
        bundle: str
        manifest: dict[str, Any]
        signature: dict[str, Any] | None = None
        signature_verified: bool | None = None
        files: list[dict[str, Any]]
        errors: list[str]
        secrets_returned: bool

else:  # pragma: no cover
    AuthStatusAPI = None
    MigrationRecordAPI = None
    StorageSchemaAPI = None
    ApiKeyStatusAPI = None
    SourceHealthAPI = None
    SourceHealthEnvelopeAPI = None
    SourceRuntimeHealthAPI = None
    SourceRuntimeHealthEnvelopeAPI = None
    SourceMaintenanceAPI = None
    SourceMaintenanceEnvelopeAPI = None
    SourceVerificationAPI = None
    SourceVerificationEnvelopeAPI = None
    PluginManifestAPI = None
    PipelineSourcesAPI = None
    PipelineRunAPI = None
    SearchPlanAPI = None
    SearchRunAPI = None
    SearchIndexAPI = None
    SearchSourcesAPI = None
    InvestigationPlanAPI = None
    UsernameSourcesAPI = None
    CaseDiffAPI = None
    FindingAPI = None
    CaseSummaryAPI = None
    WorkspaceAPI = None
    FindingDetailAPI = None
    NoteCreateAPI = None
    TimelineEventCreateAPI = None
    RelationCreateAPI = None
    RelationAPI = None
    TimelineRowAPI = None
    NoteAPI = None
    DeleteRelationAPI = None
    DedupeCaseAPI = None
    EntityMergeAPI = None
    EntityMergeResultAPI = None
    EntitySplitAPI = None
    EntitySplitResultAPI = None
    CaseMergeResultAPI = None
    EvidenceManifestAPI = None
    GraphAPI = None
    JobAPI = None
    JobEventAPI = None
    WorkerStatusAPI = None
    LiveValidationResultAPI = None
    LiveValidationHistoryEnvelopeAPI = None
    LiveValidationCleanupEnvelopeAPI = None
    LiveValidationAuditEventAPI = None
    LiveValidationAuditEnvelopeAPI = None
    MonitorScheduleAddAPI = None
    MonitoringEnvelopeAPI = None
    MonitoringDueAPI = None
    MonitoringRunAPI = None
    ReportManifestAPI = None
    ReportVerificationAPI = None
    EvidenceBundleInspectionAPI = None
