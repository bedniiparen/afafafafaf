"""FastAPI dashboard."""
