from __future__ import annotations

from collections import Counter, defaultdict
import json
from pathlib import Path
import re
from typing import Any
from urllib.parse import parse_qs, quote, urlparse


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _lower(value: Any) -> str:
    return _clean(value).lower()


def _confidence(value: Any) -> float:
    try:
        score = float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0
    if score > 1.0 and score <= 100.0:
        score = score / 100.0
    return max(0.0, min(1.0, score))


def _pct(value: Any) -> int:
    return int(round(_confidence(value) * 100))


def _host(value: str) -> str:
    raw = _clean(value)
    if not raw:
        return ""
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    return (parsed.netloc or parsed.path).split("@")[-1].split(":")[0].strip("/")


SEARCH_ENGINE_HOSTS = {
    "www.google.com",
    "google.com",
    "www.bing.com",
    "bing.com",
    "search.brave.com",
    "duckduckgo.com",
    "www.duckduckgo.com",
}

SOCIAL_PROFILE_HOSTS = {
    "bsky.app",
    "dev.to",
    "facebook.com",
    "github.com",
    "gitlab.com",
    "instagram.com",
    "linkedin.com",
    "medium.com",
    "pinterest.com",
    "reddit.com",
    "stackoverflow.com",
    "t.me",
    "telegram.me",
    "threads.net",
    "tiktok.com",
    "twitch.tv",
    "twitter.com",
    "vk.com",
    "x.com",
    "youtube.com",
}

MUSIC_PROFILE_HOSTS = {
    "bandcamp.com",
    "deezer.com",
    "genius.com",
    "last.fm",
    "music.apple.com",
    "music.yandex.ru",
    "musicbrainz.org",
    "open.spotify.com",
    "soundcloud.com",
}

DATA_CATEGORY_LABELS = {
    "social_profiles": "Social profiles",
    "music_platforms": "Music platforms",
    "emails": "Emails",
    "phones": "Phone numbers",
    "domains": "Domains",
    "links": "Links",
    "ips": "IP addresses",
    "wallets": "Wallets",
    "other": "Other data",
}

UNAVAILABLE_PAGE_MARKERS = (
    "resource (profile) unavailable",
    "profile unavailable",
    "profile is unavailable",
    "profile isn't available",
    "page isn't available",
    "page is not available",
    "this page isn't available",
    "this content isn't available",
    "this content is no longer available",
    "content is no longer available",
    "profile deleted",
    "profile removed",
    "account suspended",
    "account is suspended",
    "user not found",
    "404",
    "ресурс (profile) недоступен",
    "ресурс недоступен",
    "профиль недоступен",
    "страница недоступна",
    "ссылка недействительна",
    "профиль удален",
    "профиль удалён",
    "материал больше не доступен",
    "контент больше не доступен",
    "больше не доступен",
    "машины времени",
    "пользователь не найден",
    "аккаунт заблокирован",
    "аккаунт удален",
    "аккаунт удалён",
)


def _host_matches(host: str, candidates: set[str]) -> bool:
    clean = host.lower().removeprefix("www.")
    return any(clean == candidate or clean.endswith(f".{candidate}") for candidate in candidates)


def _looks_like_email(value: str) -> bool:
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", _clean(value)))


def _looks_like_phone(value: str) -> bool:
    clean = _clean(value)
    digits = re.sub(r"\D", "", clean)
    return len(digits) >= 7 and bool(re.fullmatch(r"\+?[\d\s().-]{7,25}", clean))


def _is_http_url(value: str) -> bool:
    return urlparse(_clean(value)).scheme in {"http", "https"}


def _row_handle(row: dict[str, Any], *, allow_at: bool = False) -> str:
    for key in ("entity_value", "display_entity_value", "matched_entity", "entity_input", "target"):
        candidate = _clean(row.get(key))
        if not candidate or _is_http_url(candidate):
            continue
        if not allow_at:
            candidate = candidate.lstrip("@")
        if " " in candidate or "/" in candidate:
            continue
        if not allow_at and "@" in candidate:
            continue
        return candidate
    return ""


def _query_first(parsed, key: str) -> str:
    values = parse_qs(parsed.query).get(key) or []
    return _clean(values[0] if values else "")


def _profile_path(base: str, value: str, safe: str = "-_.") -> str:
    return base + quote(value.strip().lstrip("@"), safe=safe)


def _public_profile_url(value: Any, row: dict[str, Any] | None = None) -> str:
    raw = _clean(value)
    if not raw:
        return ""
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = (parsed.netloc or "").lower().removeprefix("www.")
    parts = [part for part in parsed.path.strip("/").split("/") if part]
    row = row or {}
    source = _lower(row.get("source_id") or row.get("source_name"))
    if host == "api.github.com" and len(parts) >= 2 and parts[0].lower() == "users":
        return _profile_path("https://github.com/", parts[1])
    if "github" in source and host == "api.github.com":
        login = _row_handle(row)
        if login:
            return _profile_path("https://github.com/", login)
    if host == "gitlab.com" and parts[:3] == ["api", "v4", "users"]:
        login = _query_first(parsed, "username") or _row_handle(row)
        if login:
            return _profile_path("https://gitlab.com/", login)
    if host == "hacker-news.firebaseio.com" and len(parts) >= 3 and parts[0] == "v0" and parts[1] == "user":
        login = parts[2].removesuffix(".json")
        if login:
            return "https://news.ycombinator.com/user?id=" + quote(login, safe="-_.")
    if host == "codeforces.com" and parsed.path.lower().startswith("/api/user.info"):
        login = (_query_first(parsed, "handles") or _row_handle(row)).split(";")[0].split(",")[0]
        if login:
            return _profile_path("https://codeforces.com/profile/", login)
    if host == "public.api.bsky.app" and parsed.path.lower() == "/xrpc/app.bsky.actor.getprofile":
        actor = _query_first(parsed, "actor") or _row_handle(row)
        if actor:
            return _profile_path("https://bsky.app/profile/", actor, safe="-_.:")
    if host == "hub.docker.com" and len(parts) >= 3 and parts[0] == "v2" and parts[1] in {"users", "orgs"}:
        login = parts[2]
        if login:
            return _profile_path("https://hub.docker.com/u/", login)
    if host == "crates.io" and len(parts) >= 4 and parts[:3] == ["api", "v1", "users"]:
        login = parts[3]
        if login:
            return _profile_path("https://crates.io/users/", login)
    if host == "lichess.org" and len(parts) >= 3 and parts[:2] == ["api", "user"]:
        login = parts[2]
        if login:
            return _profile_path("https://lichess.org/@/", login)
    if host == "duolingo.com" and parsed.path.lower().startswith("/2017-06-30/users"):
        login = _query_first(parsed, "username") or _row_handle(row)
        if login:
            return _profile_path("https://www.duolingo.com/profile/", login)
    if host == "reddit.com" and len(parts) >= 3 and parts[0] == "user" and parts[2].lower() == "about.json":
        return _profile_path("https://www.reddit.com/user/", parts[1])
    if host == "gravatar.com" and len(parts) == 1 and parts[0].lower().endswith(".json"):
        return "https://www.gravatar.com/" + quote(parts[0][:-5], safe="-_.")
    if len(parts) >= 4 and parts[:3] == ["api", "v1", "accounts"] and parts[3] == "lookup":
        acct = _query_first(parsed, "acct") or _row_handle(row, allow_at=True)
        if "@" in acct:
            user, instance = acct.rsplit("@", 1)
            if user and instance and " " not in instance and "/" not in instance:
                return "https://" + instance + "/@" + quote(user.lstrip("@"), safe="-_.")
        if acct and host:
            return "https://" + host + "/@" + quote(acct.lstrip("@"), safe="-_.")
    return raw


def _primary_link(row: dict[str, Any], entity: dict[str, str]) -> str:
    raw_url = _clean(
        row.get("profile_url")
        or row.get("final_url")
        or row.get("url")
        or row.get("link")
    )
    raw_url = _public_profile_url(raw_url, row)
    if _is_http_url(raw_url):
        return raw_url

    entity_type = _lower(entity.get("entity_type"))
    value = _clean(entity.get("entity_value"))
    if _is_http_url(value):
        return value
    if entity_type == "email" or _looks_like_email(value):
        return f"mailto:{value}"
    if entity_type == "phone" or _looks_like_phone(value):
        phone = re.sub(r"[^\d+]", "", value)
        return f"tel:{phone}" if phone else ""
    if entity_type == "domain" and value and " " not in value:
        return f"https://{value.removeprefix('http://').removeprefix('https://')}"
    return ""


def _data_category(row: dict[str, Any], entity: dict[str, str]) -> dict[str, str]:
    entity_type = _lower(entity.get("entity_type"))
    entity_value = _clean(entity.get("entity_value"))
    url = _clean(row.get("profile_url") or row.get("final_url") or entity_value)
    host = _host(url).lower()
    source = _lower(row.get("source_id") or row.get("source_name"))
    finding_type = _lower(row.get("finding_type"))

    if _is_search_engine_url(url):
        key = "links"
    elif entity_type == "email" or _looks_like_email(entity_value):
        key = "emails"
    elif entity_type == "phone" or _looks_like_phone(entity_value):
        key = "phones"
    elif (
        source.startswith(("dorking:music_profile:", "dorking:music_search:"))
        or (host and _host_matches(host, MUSIC_PROFILE_HOSTS))
        or "music" in source
    ):
        key = "music_platforms"
    elif (
        entity_type in {"profile", "username"}
        or (host and _host_matches(host, SOCIAL_PROFILE_HOSTS))
        or source.startswith(("dorking:profile:", "dorking:company_profile:"))
        or "social" in source
        or "profile" in source
        or "profile" in finding_type
    ):
        key = "social_profiles"
    elif entity_type == "domain":
        key = "domains"
    elif entity_type == "ip":
        key = "ips"
    elif entity_type == "wallet":
        key = "wallets"
    elif entity_type == "url" or _is_http_url(entity_value) or _is_http_url(url):
        key = "links"
    else:
        key = "other"
    return {"key": key, "label": DATA_CATEGORY_LABELS[key]}


def _source_is_review_only(row: dict[str, Any]) -> bool:
    source = _lower(row.get("source_id") or row.get("source_name"))
    markers = " ".join(_markers(row.get("matched_markers"))).lower()
    return (
        source.startswith("dorking:")
        or "review_only" in markers
        or "manual_verification_required" in markers
    )


def _source_is_direct_candidate(row: dict[str, Any]) -> bool:
    source = _lower(row.get("source_id") or row.get("source_name"))
    url = _clean(row.get("profile_url") or row.get("final_url") or row.get("entity_value"))
    if _is_search_engine_url(url):
        return False
    raw = row.get("raw_data") or row.get("normalized_data") or {}
    if isinstance(raw, str):
        raw = {}
    markers = " ".join(_markers(row.get("matched_markers"))).lower()
    return (
        source.startswith("dorking:profile:")
        or source.startswith("dorking:company_profile:")
        or source.startswith("dorking:domain:")
        or source.startswith("dorking:domain_url:")
        or source.startswith("dorking:music_profile:")
        or source.startswith("dorking:music_search:")
        or bool(raw.get("direct_candidate"))
        or "candidate_url" in markers
    )


def _source_is_generated_profile_url(row: dict[str, Any]) -> bool:
    source = _lower(row.get("source_id") or row.get("source_name"))
    return source.startswith(
        (
            "dorking:profile:",
            "dorking:company_profile:",
            "dorking:music_profile:",
            "dorking:music_search:",
            "dorking:domain_url:",
        )
    )


def _text_probe(value: Any, *, depth: int = 0) -> list[str]:
    if value is None or depth > 3:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (int, float, bool)):
        return [str(value)]
    if isinstance(value, dict):
        texts: list[str] = []
        for key in (
            "title",
            "page_title",
            "snippet",
            "text",
            "body",
            "error",
            "message",
            "status",
            "reason",
            "html",
        ):
            if key in value:
                texts.extend(_text_probe(value.get(key), depth=depth + 1))
        return texts
    if isinstance(value, list):
        return [item for row in value[:10] for item in _text_probe(row, depth=depth + 1)]
    return []


def finding_has_unavailable_marker(finding: dict[str, Any]) -> bool:
    texts: list[str] = []
    for key in (
        "page_title",
        "snippet",
        "confidence_reason",
        "reject_reason",
        "matched_markers",
        "status",
    ):
        texts.extend(_text_probe(finding.get(key)))
    texts.extend(_text_probe(finding.get("raw_data")))
    texts.extend(_text_probe(finding.get("normalized_data")))
    haystack = "\n".join(texts).casefold()
    return any(marker.casefold() in haystack for marker in UNAVAILABLE_PAGE_MARKERS)


def finding_is_unverified_generated_profile_url(finding: dict[str, Any]) -> bool:
    if not _source_is_generated_profile_url(finding):
        return False
    if finding.get("rejected"):
        return True
    if finding_has_unavailable_marker(finding):
        return True
    status = _lower(finding.get("status"))
    try:
        status_code = int(finding.get("status_code") or 0)
    except (TypeError, ValueError):
        status_code = 0
    return status in {
        "not_exists",
        "not_found",
        "missing",
        "unavailable",
        "deleted",
        "removed",
        "rejected",
    } or status_code in {404, 410}


def _is_search_engine_url(value: Any) -> bool:
    raw = _clean(value)
    if not raw:
        return False
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = (parsed.netloc or "").split("@")[-1].split(":")[0].lower()
    path = parsed.path.lower()
    query = parsed.query.lower()
    return host in SEARCH_ENGINE_HOSTS and (
        path.startswith("/search")
        or bool(query)
        or host in {"duckduckgo.com", "www.duckduckgo.com"}
    )


def _is_review_only_search_lead(row: dict[str, Any]) -> bool:
    url = _clean(row.get("profile_url") or row.get("final_url") or row.get("entity_value"))
    return _source_is_review_only(row) and _is_search_engine_url(url)


def _is_profile_candidate(row: dict[str, Any]) -> bool:
    if not _source_is_direct_candidate(row):
        return False
    url = _clean(row.get("profile_url") or row.get("final_url") or row.get("entity_value"))
    return bool(url) and not _is_search_engine_url(url)


def _looks_like_api_endpoint(value: str) -> bool:
    raw = _clean(value)
    if not raw:
        return False
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = (parsed.netloc or "").lower()
    path = parsed.path.lower()
    query = parsed.query.lower()
    return (
        host.startswith("api.")
        or ".api." in host
        or "/api/" in path
        or path.startswith("/api/")
        or path.endswith(".json")
        or "format=json" in query
        or "mode=artlist" in query
    )


def _has_empty_api_payload(value: Any, *, depth: int = 0) -> bool:
    if depth > 5:
        return False
    if isinstance(value, dict):
        data = value.get("data")
        meta = value.get("meta")
        if isinstance(data, list) and not data and isinstance(meta, dict) and not meta:
            return True
        return any(_has_empty_api_payload(item, depth=depth + 1) for item in value.values())
    if isinstance(value, list):
        return any(_has_empty_api_payload(item, depth=depth + 1) for item in value[:20])
    return False


def _evidence_has_empty_api_response(evidence: list[dict[str, Any]]) -> bool:
    for row in evidence:
        url = _clean(row.get("url") or row.get("final_url"))
        artifact = _clean(row.get("artifact_path") or row.get("path"))
        if not _looks_like_api_endpoint(url) or not artifact:
            continue
        try:
            path = Path(artifact)
            if not path.is_file() or path.stat().st_size > 2_000_000:
                continue
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            continue
        if _has_empty_api_payload(payload):
            return True
    return False


def infer_case_entity_type(case: dict[str, Any]) -> str:
    case_name = _lower(case.get("case"))
    module = _lower(case.get("module"))
    explicit = _lower(case.get("entity_type"))
    if explicit and explicit not in {"search_dorking", "query_pipeline", "pipeline"}:
        return explicit
    for candidate in ("username", "email", "domain", "ip", "phone", "wallet", "company", "url", "image"):
        if (
            module == candidate
            or module == f"{candidate}_pipeline"
            or case_name.startswith(f"{candidate}_search")
            or case_name.startswith(f"{candidate}-search")
            or case_name.startswith(f"{candidate}_")
            or case_name.startswith(f"{candidate}-")
        ):
            return candidate
    return module or "case"


def _markers(value: Any) -> list[str]:
    if isinstance(value, list):
        return [_clean(item) for item in value if _clean(item)]
    return [_clean(item) for item in _clean(value).split(",") if _clean(item)]


def _result_meta_value(row: dict[str, Any], key: str) -> str:
    for container_name in ("normalized_data", "raw_data"):
        container = row.get(container_name)
        if not isinstance(container, dict):
            continue
        value = _clean(container.get(key))
        if value:
            return value
        dorking = container.get("dorking")
        if isinstance(dorking, dict):
            value = _clean(dorking.get(key))
            if value:
                return value
    prefix = f"{key}:"
    for marker in _markers(row.get("matched_markers")):
        if marker.lower().startswith(prefix):
            return marker.split(":", 1)[1].strip()
    return ""


def _source_key(row: dict[str, Any]) -> str:
    return _clean(row.get("source_id") or row.get("source_name") or row.get("name"))


def _source_name(row: dict[str, Any]) -> str:
    return _clean(row.get("source_name") or row.get("name") or row.get("source_id") or "unknown")


def _is_company_domain_observation(row: dict[str, Any]) -> bool:
    source = _lower(row.get("source_name") or row.get("source_id"))
    profile_url = _clean(row.get("profile_url"))
    return "company-analyzer" in source and bool(_host(profile_url))


def _display_entity(row: dict[str, Any]) -> dict[str, str]:
    if _is_company_domain_observation(row):
        return {"entity_type": "domain", "entity_value": _host(_clean(row.get("profile_url")))}
    entity_type = _clean(row.get("entity_type") or row.get("finding_type") or "unknown")
    entity_value = _clean(row.get("entity_value") or row.get("profile_url") or row.get("final_url"))
    return {
        "entity_type": entity_type or "unknown",
        "entity_value": entity_value or "unknown",
    }


def humanize_status(status: str, confidence: float = 0.0, rejected: bool = False) -> str:
    if rejected:
        return "Rejected"
    clean = _lower(status)
    if clean == "exists" and confidence >= 0.8:
        return "Confirmed"
    if clean == "exists" and confidence >= 0.5:
        return "Likely"
    if clean == "exists":
        return "Observed"
    if clean in {"unknown", "", "skipped"}:
        return "Unconfirmed"
    return clean.replace("_", " ").title()


def confidence_badge(confidence: float) -> dict[str, Any]:
    score = _confidence(confidence)
    percent = _pct(score)
    if score >= 0.8:
        band = "High"
    elif score >= 0.5:
        band = "Medium"
    elif score >= 0.2:
        band = "Low"
    elif score > 0:
        band = "Weak"
    else:
        band = "None"
    return {
        "score": score,
        "percent": percent,
        "label": f"{band} / {percent}%" if percent else "None / 0%",
        "band": band,
    }


def verdict_for_finding(row: dict[str, Any]) -> str:
    if row.get("rejected"):
        return "Rejected"
    confidence = _confidence(row.get("confidence"))
    if confidence >= 0.8:
        return "Confirmed"
    if confidence >= 0.5:
        return "Likely"
    return "Weak"


def humanize_finding_type(finding_type: str, fields: dict[str, Any] | None = None) -> str:
    fields = fields or {}
    clean = _lower(finding_type)
    if _is_review_only_search_lead(fields):
        return "Review-only search lead"
    if _is_profile_candidate(fields):
        return "Profile URL candidate"
    if _is_company_domain_observation(fields):
        return "Possible domain"
    if clean in {"profile", "profile_url"}:
        return "Public profile"
    if clean in {"pipeline_adapter_result", "adapter_result"}:
        return "Catalog source observation"
    if clean in {"dns_record", "dns_subdomain", "passive_subdomain_enum"}:
        return "Infrastructure observation"
    if clean in {"registry_record", "company_registry"}:
        return "Business registry record"
    if clean in {"observation", "", "unknown"}:
        entity_type = _lower(fields.get("entity_type"))
        return f"{entity_type.title()} observation" if entity_type else "Source observation"
    return clean.replace("_", " ").title()


def humanize_matched_markers(markers: Any) -> dict[str, list[str]]:
    positive: list[str] = []
    weaknesses: list[str] = []
    technical: list[str] = []
    for marker in _markers(markers):
        lower = marker.lower()
        if ":miss:" in lower:
            reason = marker.split(":miss:", 1)[1].strip()
            if "registry" in lower:
                weaknesses.append("No registry match was found.")
            elif "domain_dns" in lower:
                weaknesses.append(reason or "The guessed domain has no DNS confirmation.")
            elif "domain_registration" in lower:
                weaknesses.append("No domain registration date was found.")
            elif "independent" in lower:
                weaknesses.append("No independent source confirmation was found.")
            elif reason:
                weaknesses.append(reason[0].upper() + reason[1:] + ".")
            else:
                weaknesses.append(marker)
            technical.append(marker)
            continue
        if "registry_match" in lower:
            positive.append("Registry match signal is present.")
        elif "domain_dns" in lower:
            positive.append("Domain DNS signal is present.")
        elif "domain_registration" in lower:
            positive.append("Domain registration signal is present.")
        elif "status_exists" in lower:
            positive.append("Source reported the target as observed.")
        elif "username_in_final_url" in lower:
            positive.append("Username appears in the final URL.")
        elif "control_passed" in lower:
            positive.append("False-positive control check passed.")
        elif "weak_data" in lower:
            weaknesses.append("Evidence is sparse or weak.")
        elif "reputation_only" in lower:
            weaknesses.append("The result is reputation-only and needs corroboration.")
        elif "source_history" in lower:
            technical.append(marker)
        else:
            technical.append(marker)
    return {
        "positive": list(dict.fromkeys(positive)),
        "weaknesses": list(dict.fromkeys(weaknesses)),
        "technical": list(dict.fromkeys(technical)),
    }


def explain_confidence(
    finding: dict[str, Any],
    *,
    independent_sources: int = 0,
) -> list[str]:
    confidence = _confidence(finding.get("confidence"))
    marker_notes = humanize_matched_markers(finding.get("matched_markers"))
    reasons: list[str] = []
    if finding.get("rejected"):
        reasons.append(_clean(finding.get("reject_reason")) or "Finding was rejected by the source/module.")
    if confidence <= 0:
        reasons.append(
            "Confidence is 0% because the current evidence is only an unconfirmed observation."
        )
    if independent_sources <= 1:
        reasons.append("Only one source contributed this finding; independent confirmation is required.")
    reasons.extend(marker_notes["weaknesses"])
    if confidence > 0 and marker_notes["positive"]:
        reasons.extend(marker_notes["positive"])
    if not reasons:
        reasons.append("Confidence is based on the available source signals and preserved evidence.")
    return list(dict.fromkeys(reason for reason in reasons if reason))


def _why_it_matters(row: dict[str, Any], entity: dict[str, str]) -> str:
    finding_type = _lower(row.get("finding_type"))
    if _is_review_only_search_lead(row):
        return "Search-engine lead only; open manually and promote only if it resolves to a real profile, email, domain or related page."
    if _is_profile_candidate(row):
        return "Candidate public profile URL generated from the username. It is useful for manual verification, not confirmed attribution."
    if _is_company_domain_observation(row):
        return "Domain-like match for the target company name; useful as an unconfirmed infrastructure lead."
    if entity["entity_type"] == "domain":
        return "Domain or infrastructure lead that can be checked with DNS, RDAP, CT logs and archives."
    if entity["entity_type"] in {"username", "profile", "url"} or "profile" in finding_type:
        return "Public profile or URL lead that can link the target to an online presence."
    if entity["entity_type"] == "email":
        return "Email-related lead that can connect identity, domain and breach/reputation checks."
    return "Observation may help connect entities, sources or timeline events in the case."


def build_recommended_next_actions(
    *,
    target: str = "",
    entity_type: str = "",
    entity_value: str = "",
    finding: dict[str, Any] | None = None,
) -> list[str]:
    finding = finding or {}
    target = _clean(target or finding.get("entity_value"))
    entity_type = _lower(entity_type or finding.get("entity_type"))
    entity_value = _clean(entity_value or finding.get("profile_url") or finding.get("entity_value"))
    domain = _host(entity_value) if entity_value else ""
    if entity_type == "domain" and not domain:
        domain = entity_value
    actions: list[str] = []
    if _is_review_only_search_lead(finding):
        actions.append("Open the search result manually and extract only real profile/email/domain/page matches.")
        actions.append("Promote confirmed URLs into findings only after evidence is preserved.")
    elif _is_profile_candidate(finding):
        actions.append(f"Open {entity_value} and confirm that the page exists.")
        actions.append("Look for matching bio, avatar, username, outbound links, or cross-linked accounts.")
        actions.append("Corroborate the profile with another independent source before reporting.")
    elif _is_company_domain_observation(finding) or entity_type == "company":
        if domain:
            actions.append(f"Run: bedniiosint search-run {domain} --scope /infra/domain --include-auth-required --configured-only")
            actions.append(f"Check archive/wayback for {domain}.")
        if target:
            actions.append(f"Run: bedniiosint search-run \"{target} /business/registry\" --include-auth-required --configured-only")
            actions.append(f"Run: bedniiosint search-run \"{target} /news/mentions\" --include-auth-required --configured-only")
            actions.append(f"Run: bedniiosint search-run \"{target} /social\" --include-auth-required --configured-only")
    elif entity_type == "domain":
        if domain:
            actions.append(f"Run: bedniiosint search-run {domain} --scope /infra/domain --include-auth-required --configured-only")
            actions.append(f"Check CT logs, urlscan and Wayback for {domain}.")
    elif entity_type in {"username", "profile", "url"}:
        actions.append("Check official social profiles and public mentions.")
        actions.append("Corroborate this profile with a second independent source.")
    else:
        actions.append("Run a broader unified search with configured sources.")
        actions.append("Add independent source confirmation before reporting.")
    return list(dict.fromkeys(actions))


def build_finding_display(
    finding: dict[str, Any],
    evidence: list[dict[str, Any]] | None = None,
    *,
    attachments: list[dict[str, Any]] | None = None,
    independent_sources: int = 0,
    target: str = "",
) -> dict[str, Any]:
    evidence = evidence or []
    attachments = attachments or []
    entity = _display_entity(finding)
    confidence = _confidence(finding.get("confidence"))
    marker_notes = humanize_matched_markers(finding.get("matched_markers"))
    verdict = verdict_for_finding(finding)
    what = humanize_finding_type(_clean(finding.get("finding_type")), finding)
    confidence_info = confidence_badge(confidence)
    data_category = _data_category(finding, entity)
    weaknesses = list(marker_notes["weaknesses"])
    if confidence <= 0:
        weaknesses.append("No independent confirmation.")
    if independent_sources <= 1:
        weaknesses.append("Only one source currently supports this observation.")
    display = {
        "verdict": verdict,
        "status_label": humanize_status(
            _clean(finding.get("status")),
            confidence,
            bool(finding.get("rejected")),
        ),
        "confidence": confidence_info,
        "display_entity_type": entity["entity_type"],
        "display_entity_value": entity["entity_value"],
        "data_category": data_category["key"],
        "data_category_label": data_category["label"],
        "primary_link": _primary_link(finding, entity),
        "what_found": what,
        "why_it_matters": _why_it_matters(finding, entity),
        "match_explanation": {
            "matched_value": _clean(finding.get("entity_value")),
            "matched_variant": entity["entity_value"],
            "match_reason": _clean(finding.get("confidence_reason"))
            or _clean(finding.get("reject_reason"))
            or what,
            "scope_relevance": "Review required before treating this as attribution.",
            "source_reliability": finding.get("source_reliability"),
        },
        "strengths": marker_notes["positive"],
        "weaknesses": list(dict.fromkeys(weaknesses)),
        "confidence_explanation": explain_confidence(
            finding,
            independent_sources=independent_sources,
        ),
        "evidence_chain": {
            "evidence_count": len(evidence),
            "attachment_count": len(attachments),
            "source_observed_url": _clean(finding.get("profile_url") or finding.get("final_url")),
            "captured_at": _clean(finding.get("captured_at") or finding.get("last_seen")),
            "http_status": finding.get("status_code")
            or next((row.get("http_status") for row in evidence if row.get("http_status")), None),
            "sha256": next((row.get("sha256") for row in evidence if row.get("sha256")), ""),
            "body_len": next((row.get("body_len") for row in evidence if row.get("body_len")), 0),
            "artifact_path": next((row.get("artifact_path") for row in evidence if row.get("artifact_path")), ""),
        },
        "recommended_actions": build_recommended_next_actions(
            target=target,
            entity_type=entity["entity_type"],
            entity_value=entity["entity_value"],
            finding=finding,
        ),
        "raw_available": True,
        "review_only_search_lead": _is_review_only_search_lead(finding),
        "profile_candidate": _is_profile_candidate(finding),
    }
    return display


def classify_finding_cluster(finding: dict[str, Any]) -> str:
    if _is_review_only_search_lead(finding):
        return "Review-only search leads"
    if _is_profile_candidate(finding):
        return "Profile URL candidates"
    if finding.get("rejected") or _clean(finding.get("verdict")) == "Rejected":
        return "Rejected / false positives"
    confidence = _confidence(finding.get("confidence"))
    display = finding.get("display") if isinstance(finding.get("display"), dict) else {}
    entity_type = _lower(display.get("display_entity_type") or finding.get("entity_type"))
    source = _lower(finding.get("source_name") or finding.get("source_id"))
    if confidence >= 0.8:
        return "Confirmed matches"
    if confidence >= 0.5:
        return "Likely matches"
    if entity_type == "domain":
        return "Infrastructure"
    if "registry" in source:
        return "Business registry"
    if entity_type in {"url", "profile", "username"}:
        return "Public profiles"
    if confidence <= 0:
        return "Weak observations"
    return "Unknown"


def _entity_key(row: dict[str, Any]) -> tuple[str, str]:
    display = row.get("display") if isinstance(row.get("display"), dict) else {}
    return (
        _clean(display.get("display_entity_type") or row.get("entity_type") or "unknown"),
        _clean(display.get("display_entity_value") or row.get("entity_value") or row.get("profile_url") or "unknown"),
    )


def _independent_sources(findings: list[dict[str, Any]]) -> dict[tuple[str, str], set[str]]:
    sources: dict[tuple[str, str], set[str]] = defaultdict(set)
    for row in findings:
        if row.get("rejected") or _is_review_only_search_lead(row):
            continue
        entity = _display_entity(row)
        key = (entity["entity_type"], entity["entity_value"])
        source = _source_key(row)
        if source:
            sources[key].add(source)
    return sources


def build_result_clusters(findings: list[dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in findings:
        grouped[_entity_key(row)].append(row)

    clusters: list[dict[str, Any]] = []
    categories = {
        "Confirmed matches": [],
        "Likely matches": [],
        "Weak observations": [],
        "Same-name only": [],
        "Infrastructure": [],
        "Public profiles": [],
        "Profile URL candidates": [],
        "Review-only search leads": [],
        "Business registry": [],
        "Rejected / false positives": [],
        "Unknown": [],
    }
    for (entity_type, entity_value), rows in grouped.items():
        max_confidence = max((_confidence(row.get("confidence")) for row in rows), default=0.0)
        rejected = all(bool(row.get("rejected")) for row in rows)
        representative = max(rows, key=lambda row: _confidence(row.get("confidence")))
        category = classify_finding_cluster({**representative, "confidence": max_confidence, "rejected": rejected})
        if _is_company_domain_observation(representative) and max_confidence <= 0:
            category = "Weak observations"
        cluster = {
            "entity_type": entity_type,
            "entity_value": entity_value,
            "category": category,
            "verdict": "Rejected" if rejected else ("Confirmed" if max_confidence >= 0.8 else "Likely" if max_confidence >= 0.5 else "Weak"),
            "confidence": confidence_badge(max_confidence),
            "source_ids": sorted({_source_key(row) for row in rows if _source_key(row)}),
            "source_count": len({_source_key(row) for row in rows if _source_key(row)}),
            "finding_ids": [row.get("id") for row in rows if row.get("id")],
            "reasons": list(
                dict.fromkeys(
                    reason
                    for row in rows
                    for reason in (row.get("display") or {}).get("weaknesses", [])
                    if reason
                )
            ),
        }
        clusters.append(cluster)
        categories.setdefault(category, []).append(cluster)

    clusters.sort(
        key=lambda row: (
            [
                "Confirmed matches",
                "Likely matches",
                "Public profiles",
                "Profile URL candidates",
                "Weak observations",
                "Infrastructure",
                "Business registry",
                "Same-name only",
                "Review-only search leads",
                "Rejected / false positives",
                "Unknown",
            ].index(row["category"])
            if row["category"] in categories
            else 99,
            -float(row["confidence"]["score"]),
            row["entity_type"],
            row["entity_value"],
        )
    )
    return {"clusters": clusters, "categories": categories}


def build_source_coverage(case: dict[str, Any]) -> dict[str, Any]:
    sources = list(case.get("sources") or [])
    findings = list(case.get("findings") or [])
    statuses = Counter(_clean(row.get("status") or "unknown") for row in findings)
    return {
        "checked_sources": len(sources),
        "review_only_sources": sum(1 for row in sources if _lower(row.get("source_id") or row.get("name")).startswith("dorking:")),
        "successful_sources": sum(1 for row in sources if int(row.get("success_count") or 0) > 0),
        "timeout_or_error_sources": sum(1 for row in sources if int(row.get("error_count") or 0) > 0 or row.get("last_error")),
        "missing_api_keys": sum(1 for row in sources if _lower(row.get("health_status")) == "missing_keys"),
        "unavailable_sources": sum(1 for row in sources if _lower(row.get("health_status")) in {"error", "unavailable"}),
        "finding_statuses": dict(statuses),
    }


def build_evidence_quality(case: dict[str, Any]) -> dict[str, Any]:
    findings = list(case.get("findings") or [])
    evidence = list(case.get("evidence") or [])
    attachments = list(case.get("attachments") or [])
    source_sets = _independent_sources(findings)
    duplicates = len(findings) - len({_entity_key(row) + (_source_key(row),) for row in findings})
    return {
        "independent_sources_count": max((len(value) for value in source_sets.values()), default=0),
        "duplicate_findings_count": max(0, duplicates),
        "weak_findings_count": sum(
            1
            for row in findings
            if verdict_for_finding(row) == "Weak" and not _is_review_only_search_lead(row)
        ),
        "review_only_search_leads_count": sum(1 for row in findings if _is_review_only_search_lead(row)),
        "profile_candidates_count": sum(1 for row in findings if _is_profile_candidate(row)),
        "rejected_count": sum(1 for row in findings if row.get("rejected")),
        "evidence_files_count": len(evidence) + len(attachments),
    }


def build_confidence_breakdown(case: dict[str, Any]) -> dict[str, Any]:
    positives: list[str] = []
    negatives: list[str] = []
    for row in case.get("findings") or []:
        display = row.get("display") or {}
        positives.extend(display.get("strengths") or [])
        negatives.extend(display.get("weaknesses") or [])
        if _confidence(row.get("confidence")) <= 0:
            negatives.append("Confidence is 0 for at least one observation.")
    return {
        "positive": list(dict.fromkeys(positives)) or ["No positive confidence signals recorded yet."],
        "negative": list(dict.fromkeys(negatives)) or ["No major negative confidence drivers recorded."],
    }


def build_unconfirmed_hypotheses(case: dict[str, Any]) -> list[str]:
    hypotheses: list[str] = []
    for row in case.get("findings") or []:
        if row.get("rejected"):
            continue
        if _is_review_only_search_lead(row):
            continue
        display = row.get("display") or {}
        if _confidence(row.get("confidence")) < 0.5:
            entity = display.get("display_entity_value") or row.get("entity_value") or row.get("profile_url")
            hypotheses.append(
                f"{entity} may be related to the target, but this is unconfirmed."
            )
            if _is_company_domain_observation(row):
                hypotheses.append("The result is based on a guessed domain pattern.")
                hypotheses.append("No public registry confirmation was found.")
    return list(dict.fromkeys(item for item in hypotheses if item))


def build_case_summary(case: dict[str, Any]) -> dict[str, Any]:
    target = _clean(case.get("target") or case.get("case") or "")
    entity_type = infer_case_entity_type(case)
    runs = list(case.get("runs") or [])
    findings = list(case.get("findings") or [])
    sources = list(case.get("sources") or [])
    evidence = list(case.get("evidence") or [])
    attachments = list(case.get("attachments") or [])
    clusters = build_result_clusters(findings)
    review_only_search = [row for row in findings if _is_review_only_search_lead(row)]
    profile_candidates = [row for row in findings if _is_profile_candidate(row)]
    primary_findings = [row for row in findings if row not in review_only_search]
    analyst_findings = [row for row in primary_findings if not row.get("rejected")]
    confirmed = [row for row in analyst_findings if verdict_for_finding(row) == "Confirmed"]
    likely = [row for row in analyst_findings if verdict_for_finding(row) == "Likely"]
    weak = [
        row
        for row in analyst_findings
        if verdict_for_finding(row) == "Weak" and not _is_review_only_search_lead(row)
    ]
    rejected = [row for row in primary_findings if row.get("rejected")]
    max_confidence = max((_confidence(row.get("confidence")) for row in analyst_findings), default=0.0)
    overall = confidence_badge(max_confidence)
    source_names = sorted({_source_name(row) for row in findings if _source_name(row)})
    possible_domains = [
        (row.get("display") or {}).get("display_entity_value")
        for row in findings
        if (row.get("display") or {}).get("what_found") == "Possible domain"
    ]
    what_found: list[str] = []
    observed_sources = sorted(
        {
            _source_name(row)
            for row in findings
            if not _source_is_review_only(row) and not row.get("rejected")
        }
    )
    if observed_sources:
        what_found.append(
            f"{len(observed_sources)} source observation(s): {', '.join(observed_sources[:5])}."
        )
    if profile_candidates:
        what_found.append(
            f"{len(profile_candidates)} profile URL candidate(s) generated for manual verification."
        )
    if review_only_search:
        what_found.append(
            f"{len(review_only_search)} search-engine lead(s) moved to Review-only search leads, not treated as profiles."
        )
    if weak:
        what_found.append(f"{len(weak)} weak observation(s) need corroboration.")
    if likely:
        what_found.append(f"{len(likely)} likely findings need analyst review.")
    if confirmed:
        what_found.append(f"{len(confirmed)} confirmed findings.")
    if possible_domains:
        what_found.append(f"Possible domain: {possible_domains[0]}.")
    registry_confirmations = sum(
        1
        for row in findings
        if "Registry match signal is present." in (row.get("display") or {}).get("strengths", [])
    )
    what_found.append(f"{registry_confirmations} registry confirmations.")
    independent_confirmations = build_evidence_quality(case)["independent_sources_count"]
    what_found.append(f"{independent_confirmations if independent_confirmations > 1 else 0} independent confirmations.")
    if rejected:
        what_found.append(f"{len(rejected)} rejected findings retained for review.")

    run_targets = sorted(
        {
            _clean(row.get("target"))
            for row in runs
            if isinstance(row, dict) and _clean(row.get("target"))
        }
    )
    run_modules = sorted(
        {
            _clean(row.get("module"))
            for row in runs
            if isinstance(row, dict) and _clean(row.get("module"))
        }
    )
    lineage_warning = ""
    if len(runs) > 1:
        lineage_warning = (
            f"This workspace contains {len(runs)} persisted run segment(s) with the same case name. "
            "They are shown together as one investigation case; start a new auto-case or omit resume to keep reruns separate."
        )

    if confirmed:
        status = "Has confirmed matches"
        main_issue = "Review evidence and raw appendix before external reporting."
    elif likely:
        status = "Needs corroboration"
        main_issue = "Likely findings still need independent corroboration."
    else:
        status = "Needs review"
        main_issue = (
            "Profile/search candidates are unconfirmed until opened, captured and corroborated."
        )

    return {
        "target": target,
        "entity_type": entity_type,
        "case_status": status,
        "overall_confidence": overall,
        "findings_count": len(analyst_findings),
        "all_findings_count": len(findings),
        "confirmed_findings": len(confirmed),
        "likely_findings": len(likely),
        "weak_findings": len(weak),
        "profile_candidates": len(profile_candidates),
        "review_only_search_leads": len(review_only_search),
        "rejected_findings": len(rejected),
        "sources_checked": len(sources),
        "evidence_files": len(evidence) + len(attachments),
        "last_updated": _clean(case.get("last_updated")),
        "run_segments": len(runs),
        "run_targets": run_targets,
        "run_modules": run_modules,
        "case_lineage_warning": lineage_warning,
        "what_found": list(dict.fromkeys(what_found)),
        "main_issue": main_issue,
        "confidence_reasons": build_confidence_breakdown(case),
        "clusters": clusters,
        "source_coverage": build_source_coverage(case),
        "evidence_quality": build_evidence_quality(case),
        "unconfirmed_hypotheses": build_unconfirmed_hypotheses(case),
        "recommended_next_actions": build_recommended_next_actions(
            target=target,
            entity_type=entity_type,
            entity_value=possible_domains[0] if possible_domains else target,
        ),
    }


def build_case_presentation(case: dict[str, Any]) -> dict[str, Any]:
    findings = [dict(row) for row in case.get("findings") or []]
    evidence_by_finding = case.get("evidence_by_finding") or {}
    attachments_by_finding = case.get("attachments_by_finding") or {}
    source_sets = _independent_sources(findings)
    target = _clean(case.get("target") or case.get("case") or "")
    enriched: list[dict[str, Any]] = []
    for row in findings:
        entity = _display_entity(row)
        key = (entity["entity_type"], entity["entity_value"])
        finding_id = row.get("id")
        evidence = evidence_by_finding.get(finding_id) or evidence_by_finding.get(str(finding_id)) or []
        attachments = attachments_by_finding.get(finding_id) or attachments_by_finding.get(str(finding_id)) or []
        display = build_finding_display(
            row,
            evidence,
            attachments=attachments,
            independent_sources=len(source_sets.get(key, set())),
            target=target,
        )
        row["display"] = display
        row["verdict"] = display["verdict"]
        row["display_entity_type"] = display["display_entity_type"]
        row["display_entity_value"] = display["display_entity_value"]
        row["data_category"] = display["data_category"]
        row["data_category_label"] = display["data_category_label"]
        row["primary_link"] = display["primary_link"]
        row["what_found"] = display["what_found"]
        row["why_it_matters"] = display["why_it_matters"]
        row["confidence_explanation"] = display["confidence_explanation"]
        row["weaknesses"] = display["weaknesses"]
        row["recommended_actions"] = display["recommended_actions"]
        enriched.append(row)

    presentation_case = {
        **case,
        "findings": enriched,
    }
    summary = build_case_summary(presentation_case)
    primary_findings = [
        row
        for row in enriched
        if not (row.get("display") or {}).get("review_only_search_lead")
        and not row.get("rejected")
    ]
    rejected_findings = [
        row
        for row in enriched
        if row.get("rejected")
        and not (row.get("display") or {}).get("review_only_search_lead")
    ]
    review_only_findings = [
        row
        for row in enriched
        if (row.get("display") or {}).get("review_only_search_lead")
    ]
    return {
        "summary": summary,
        "findings": primary_findings,
        "rejected_findings": rejected_findings,
        "review_only_search_leads": review_only_findings,
        "all_findings_count": len(enriched),
        "clusters": summary["clusters"],
        "entity_overview": {
            "entities": list(case.get("entities") or []),
            "display_entities": [
                {"type": row["display_entity_type"], "value": row["display_entity_value"]}
                for row in primary_findings
            ],
        },
        "source_coverage": summary["source_coverage"],
        "evidence_quality": summary["evidence_quality"],
        "confidence_breakdown": summary["confidence_reasons"],
        "unconfirmed_hypotheses": summary["unconfirmed_hypotheses"],
        "recommended_next_actions": summary["recommended_next_actions"],
    }


STATUS_ORDER = ("found", "candidate", "unavailable", "blocked", "rejected", "error", "unknown")
PRIORITY_PLATFORMS = ("vk", "telegram", "instagram", "youtube")
_PLATFORM_ALIASES = {
    "vk": ("vk.com", "vk.ru", "vkontakte", "m.vk.com"),
    "telegram": ("t.me", "telegram", "telegram.me", "telegram.org"),
    "instagram": ("instagram.com", "instagr.am"),
    "youtube": ("youtube.com", "youtu.be"),
}


def _platform_priority_rank(platform: str = "", url: str = "") -> int:
    blob = f"{platform} {url}".lower()
    for idx, key in enumerate(PRIORITY_PLATFORMS):
        if key in blob or any(alias in blob for alias in _PLATFORM_ALIASES[key]):
            return idx
    return len(PRIORITY_PLATFORMS)

PLATFORM_LABELS = {
    "bandcamp.com": "Bandcamp",
    "bsky.app": "Bluesky",
    "deezer.com": "Deezer",
    "facebook.com": "Facebook",
    "genius.com": "Genius",
    "github.com": "GitHub",
    "gitlab.com": "GitLab",
    "instagram.com": "Instagram",
    "last.fm": "Last.fm",
    "linkedin.com": "LinkedIn",
    "medium.com": "Medium",
    "music.apple.com": "Apple Music",
    "music.yandex.ru": "Yandex Music",
    "musicbrainz.org": "MusicBrainz",
    "open.spotify.com": "Spotify",
    "reddit.com": "Reddit",
    "soundcloud.com": "SoundCloud",
    "t.me": "Telegram",
    "telegram.me": "Telegram",
    "threads.net": "Threads",
    "tiktok.com": "TikTok",
    "twitch.tv": "Twitch",
    "twitter.com": "Twitter",
    "vk.com": "VK",
    "x.com": "X",
    "youtube.com": "YouTube",
    "youtu.be": "YouTube",
}

PLATFORM_SOURCE_HINTS = {
    "apple_music": "Apple Music",
    "bandcamp": "Bandcamp",
    "deezer": "Deezer",
    "facebook": "Facebook",
    "genius": "Genius",
    "github": "GitHub",
    "gitlab": "GitLab",
    "instagram": "Instagram",
    "lastfm": "Last.fm",
    "linkedin": "LinkedIn",
    "musicbrainz": "MusicBrainz",
    "reddit": "Reddit",
    "soundcloud": "SoundCloud",
    "spotify": "Spotify",
    "telegram": "Telegram",
    "tiktok": "TikTok",
    "twitch": "Twitch",
    "twitter": "Twitter",
    "vk": "VK",
    "x": "X",
    "yandex_music": "Yandex Music",
    "youtube": "YouTube",
}


def extract_platform(url: str) -> str:
    host = _host(url).lower().removeprefix("www.").removeprefix("m.")
    if not host:
        return "Unknown"
    if host in PLATFORM_LABELS:
        return PLATFORM_LABELS[host]
    for candidate, label in PLATFORM_LABELS.items():
        if host.endswith(f".{candidate}"):
            return label
    if host.endswith(".bandcamp.com"):
        return "Bandcamp"
    parts = host.split(".")
    if len(parts) >= 2:
        return parts[-2].replace("-", " ").replace("_", " ").title()
    return host.replace("-", " ").replace("_", " ").title()


def _platform_from_finding(finding: dict[str, Any]) -> str:
    url = _clean(
        finding.get("primary_link")
        or (finding.get("display") or {}).get("primary_link")
        or finding.get("profile_url")
        or finding.get("final_url")
        or finding.get("entity_value")
    )
    platform = extract_platform(url)
    if platform != "Unknown":
        return platform
    source = _lower(finding.get("source_id") or finding.get("source_name"))
    normalized = source.replace(":", "_").replace("-", "_").replace(" ", "_")
    for hint, label in PLATFORM_SOURCE_HINTS.items():
        if hint in normalized:
            return label
    return "Unknown"


def normalize_confidence(finding: dict[str, Any]) -> dict[str, Any]:
    info = confidence_badge(finding.get("confidence"))
    band = _lower(info.get("band"))
    if band == "none":
        bucket = "none"
    elif info["score"] >= 0.8:
        bucket = "high"
    elif info["score"] >= 0.5:
        bucket = "medium"
    else:
        bucket = "low"
    return {**info, "bucket": bucket, "reasons": explain_confidence(finding)}


def classify_result_status(finding: dict[str, Any]) -> str:
    if finding.get("rejected"):
        return "rejected"
    if finding_has_unavailable_marker(finding):
        return "unavailable"
    status = _lower(finding.get("status") or finding.get("health_status"))
    status_code = finding.get("status_code") or finding.get("http_status")
    try:
        code = int(status_code) if status_code not in {"", None} else 0
    except (TypeError, ValueError):
        code = 0
    joined = " ".join(
        _lower(finding.get(key))
        for key in ("reject_reason", "confidence_reason", "last_error", "matched_markers")
    )
    if status in {"blocked", "blocked_by_scope", "captcha", "rate_limited"} or code in {401, 403, 429}:
        return "blocked"
    if any(token in joined for token in ("blocked", "captcha", "rate limit", "rate_limited", "forbidden")):
        return "blocked"
    if status in {"error", "failed", "http_error", "parse_error", "timeout"} or code >= 500:
        return "error"
    if "timeout" in joined or "timed out" in joined:
        return "error"
    if status in {"not_exists", "not_found", "missing", "missing_keys", "missing_key", "unavailable", "skipped"} or code == 404:
        return "unavailable"
    if (
        _is_review_only_search_lead(finding)
        or _is_profile_candidate(finding)
        or (_source_is_review_only(finding) and _confidence(finding.get("confidence")) < 0.5)
    ):
        return "candidate"
    if status in {"exists", "ok", "available", "found"}:
        return "found"
    if code and 200 <= code < 400 and _confidence(finding.get("confidence")) >= 0.2:
        return "found"
    if _confidence(finding.get("confidence")) >= 0.5:
        return "found"
    return "unknown"


def extract_signals(
    finding: dict[str, Any],
    evidence: list[dict[str, Any]] | None = None,
) -> list[str]:
    evidence = evidence or []
    signals: list[str] = []
    display = finding.get("display") if isinstance(finding.get("display"), dict) else {}
    if display.get("profile_candidate") or _is_profile_candidate(finding):
        signals.append("candidate URL")
    if display.get("review_only_search_lead") or _is_review_only_search_lead(finding):
        signals.append("search lead")
    markers = {marker.lower() for marker in _markers(finding.get("matched_markers"))}
    candidate_status = _result_meta_value(finding, "candidate_status")
    if candidate_status:
        signals.append(f"candidate status: {candidate_status}")
    if "sherlock_style" in markers:
        signals.append("Sherlock catalog")
    if "site_regex_checked" in markers or _result_meta_value(finding, "regex_check"):
        signals.append("site regex checked")
    status = _clean(finding.get("status"))
    if status:
        signals.append(f"status: {status}")
    if finding.get("status_code"):
        signals.append(f"HTTP {finding.get('status_code')}")
    if finding.get("redirected"):
        signals.append("redirect observed")
    if _clean(finding.get("page_title")):
        signals.append("page title")
    if _confidence(finding.get("source_reliability")):
        signals.append(f"source reliability {_pct(finding.get('source_reliability'))}%")
    marker_notes = humanize_matched_markers(finding.get("matched_markers"))
    signals.extend(marker_notes["positive"])
    if evidence:
        signals.append(f"{len(evidence)} evidence artifact(s)")
    if any(row.get("sha256") for row in evidence):
        signals.append("hash captured")
    return list(dict.fromkeys(signal for signal in signals if signal))[:8]


def count_by_status(rows: list[dict[str, Any]]) -> dict[str, int]:
    counts = Counter(_clean(row.get("status") or "unknown") for row in rows)
    ordered = list(STATUS_ORDER) + sorted(status for status in counts if status not in STATUS_ORDER)
    return {status: counts.get(status, 0) for status in ordered if counts.get(status, 0)}


def _workspace_findings(case: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for section in ("findings", "review_only_search_leads", "rejected_findings"):
        for row in case.get(section) or []:
            key = _clean(row.get("id")) or "|".join(
                [
                    _source_key(row),
                    _clean(row.get("entity_type")),
                    _clean(row.get("entity_value")),
                    _clean(row.get("profile_url")),
                ]
            )
            if key in seen:
                continue
            seen.add(key)
            rows.append(row)
    return rows


def _evidence_for(case: dict[str, Any], finding: dict[str, Any]) -> list[dict[str, Any]]:
    evidence_by_finding = case.get("evidence_by_finding") or {}
    finding_id = finding.get("id")
    return list(evidence_by_finding.get(finding_id) or evidence_by_finding.get(str(finding_id)) or [])


def _attachments_for(case: dict[str, Any], finding: dict[str, Any]) -> list[dict[str, Any]]:
    attachments_by_finding = case.get("attachments_by_finding") or {}
    finding_id = finding.get("id")
    return list(attachments_by_finding.get(finding_id) or attachments_by_finding.get(str(finding_id)) or [])


def _confidence_filter_value(info: dict[str, Any]) -> str:
    bucket = _clean(info.get("bucket"))
    if bucket == "none":
        return "none"
    return bucket or "unknown"


def _table_filters(
    rows: list[dict[str, Any]],
    keys: list[tuple[str, str]],
) -> dict[str, list[str]]:
    filters: dict[str, list[str]] = {}
    for key, _label in keys:
        values: list[str] = []
        for row in rows:
            value = row.get(key)
            if isinstance(value, dict):
                value = value.get("band") or value.get("label")
            if isinstance(value, list):
                values.extend(_clean(item) for item in value)
            else:
                values.append(_clean(value))
        filters[key] = sorted({value for value in values if value})
    return filters


def _table_model(
    *,
    key: str,
    title: str,
    columns: list[dict[str, Any]],
    rows: list[dict[str, Any]],
    filter_keys: list[tuple[str, str]],
    empty: str,
) -> dict[str, Any]:
    for index, row in enumerate(rows, 1):
        row.setdefault("row_id", f"{key}:{index}")
    return {
        "key": key,
        "title": title,
        "columns": columns,
        "rows": rows,
        "filters": _table_filters(rows, filter_keys),
        "filter_labels": {filter_key: label for filter_key, label in filter_keys},
        "status_counts": count_by_status(rows),
        "empty": empty,
        "export": {"csv": True, "json": True},
    }


def _actions(url: str = "", finding_id: Any = None, evidence_count: int = 0) -> list[dict[str, str]]:
    actions = [{"type": "inspect", "label": "Inspect"}]
    if url:
        actions.insert(0, {"type": "open", "label": "Open", "url": url})
    if finding_id:
        actions.append({"type": "finding", "label": "Finding", "finding_id": str(finding_id)})
    if evidence_count:
        actions.append({"type": "evidence", "label": "Evidence"})
    return actions


def _handle_from_url(url: str, fallback: str = "") -> str:
    raw = _clean(url)
    if not raw:
        return fallback
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    path = parsed.path.strip("/")
    if not path:
        return fallback
    parts = [part for part in path.split("/") if part]
    if not parts:
        return fallback
    if parts[0].lower() in {"artist", "artists", "channel", "c", "user", "users", "profile"} and len(parts) > 1:
        return parts[1].lstrip("@")
    return parts[-1].lstrip("@") or fallback


def _finding_url(finding: dict[str, Any]) -> str:
    display = finding.get("display") if isinstance(finding.get("display"), dict) else {}
    return _public_profile_url(
        finding.get("primary_link")
        or display.get("primary_link")
        or finding.get("profile_url")
        or finding.get("final_url")
        or finding.get("entity_value"),
        finding,
    )


def _display_value(finding: dict[str, Any]) -> str:
    display = finding.get("display") if isinstance(finding.get("display"), dict) else {}
    return _clean(
        finding.get("display_entity_value")
        or display.get("display_entity_value")
        or finding.get("entity_value")
        or finding.get("profile_url")
        or finding.get("final_url")
    )


def _category(finding: dict[str, Any]) -> str:
    display = finding.get("display") if isinstance(finding.get("display"), dict) else {}
    return _clean(finding.get("data_category") or display.get("data_category") or "other")


def _last_seen(finding: dict[str, Any]) -> str:
    return _clean(finding.get("last_seen") or finding.get("captured_at") or finding.get("first_seen"))


def _evidence_summary(evidence: list[dict[str, Any]], attachments: list[dict[str, Any]]) -> dict[str, Any]:
    rows = evidence + attachments
    return {
        "count": len(rows),
        "label": f"{len(rows)} artifact(s)" if rows else "0 artifacts",
        "hash": next((_clean(row.get("sha256")) for row in rows if _clean(row.get("sha256"))), ""),
        "timestamp": next((_clean(row.get("captured_at")) for row in rows if _clean(row.get("captured_at"))), ""),
        "url": next((_clean(row.get("url") or row.get("final_url")) for row in evidence if _clean(row.get("url") or row.get("final_url"))), ""),
        "artifact": next((_clean(row.get("artifact_path") or row.get("path")) for row in rows if _clean(row.get("artifact_path") or row.get("path"))), ""),
    }


def build_profile_inspector(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "title": row.get("display_name") or row.get("handle") or row.get("url") or "Profile candidate",
        "sections": [
            {
                "title": "Profile",
                "rows": [
                    ["Platform", row.get("platform") or ""],
                    ["Username/Handle", row.get("handle") or ""],
                    ["Display Name", row.get("display_name") or ""],
                    ["URL", row.get("url") or ""],
                    ["Result status", row.get("status") or "unknown"],
                    ["Result label", row.get("result_label") or ""],
                    ["Candidate status", row.get("candidate_status") or ""],
                    ["Site category", row.get("site_category") or ""],
                ],
            },
            {
                "title": "Assessment",
                "rows": [
                    ["Confidence", (row.get("confidence") or {}).get("label") or ""],
                    ["Signals", ", ".join(row.get("signals") or [])],
                    ["Source", row.get("source") or ""],
                    ["Last Seen", row.get("last_seen") or ""],
                    ["Probe URL", row.get("probe_url") or ""],
                    ["Regex check", row.get("regex_check") or ""],
                ],
            },
            {
                "title": "Evidence Artifacts",
                "rows": [
                    ["Count", str((row.get("evidence") or {}).get("count") or 0)],
                    ["Hash", (row.get("evidence") or {}).get("hash") or ""],
                    ["Timestamp", (row.get("evidence") or {}).get("timestamp") or ""],
                    ["URL", (row.get("evidence") or {}).get("url") or ""],
                ],
            },
        ],
    }


def _profile_row(case: dict[str, Any], finding: dict[str, Any]) -> dict[str, Any]:
    evidence = _evidence_for(case, finding)
    attachments = _attachments_for(case, finding)
    status = classify_result_status(finding)
    confidence = normalize_confidence(finding)
    url = _finding_url(finding)
    value = _display_value(finding)
    evidence_info = _evidence_summary(evidence, attachments)
    candidate_status = _result_meta_value(finding, "candidate_status")
    site_category = _result_meta_value(finding, "site_category")
    row = {
        "finding_id": finding.get("id"),
        "platform": _platform_from_finding(finding),
        "handle": _handle_from_url(url, value),
        "display_name": _clean(finding.get("page_title")) or value,
        "url": url,
        "status": status,
        "confidence": confidence,
        "confidence_band": _confidence_filter_value(confidence),
        "signals": extract_signals(finding, evidence),
        "evidence": evidence_info,
        "source": _source_name(finding),
        "source_id": _source_key(finding),
        "last_seen": _last_seen(finding),
        "candidate_status": candidate_status or ("candidate" if _is_profile_candidate(finding) else ""),
        "site_category": site_category,
        "probe_url": _result_meta_value(finding, "probe_url"),
        "regex_check": _result_meta_value(finding, "regex_check"),
        "actions": _actions(
            "" if status in {"unavailable", "rejected", "error", "blocked"} else url,
            finding.get("id"),
            evidence_info["count"],
        ),
        "result_label": "Found profile" if status == "found" else "Candidate profile URL" if status == "candidate" else status.replace("_", " ").title(),
    }
    row["inspector"] = build_profile_inspector(row)
    return row


def build_profiles_table(case: dict[str, Any]) -> dict[str, Any]:
    rows = []
    for finding in _workspace_findings(case):
        if finding_is_unverified_generated_profile_url(finding):
            continue
        if _is_search_engine_url(_finding_url(finding)):
            continue
        category = _category(finding)
        if category in {"social_profiles", "music_platforms"} or _is_profile_candidate(finding):
            rows.append(_profile_row(case, finding))
    deduped: dict[str, dict[str, Any]] = {}
    for row in rows:
        dedupe_key = _clean(row.get("url")).lower() or "|".join(
            [
                _clean(row.get("platform")).lower(),
                _clean(row.get("handle")).lower(),
            ]
        )
        if not dedupe_key:
            dedupe_key = str(row.get("finding_id") or len(deduped))
        current = deduped.get(dedupe_key)
        if current is None:
            deduped[dedupe_key] = row
            continue

        def quality(candidate: dict[str, Any]) -> tuple[int, float, int, int]:
            status = _clean(candidate.get("status"))
            status_rank = STATUS_ORDER.index(status) if status in STATUS_ORDER else len(STATUS_ORDER)
            evidence_count = int((candidate.get("evidence") or {}).get("count") or 0)
            confidence = float((candidate.get("confidence") or {}).get("score") or 0.0)
            generated_penalty = 1 if _source_is_generated_profile_url(candidate) else 0
            return (-status_rank, confidence, evidence_count, -generated_penalty)

        if quality(row) > quality(current):
            deduped[dedupe_key] = row
    rows = list(deduped.values())
    rows.sort(
        key=lambda row: (
            _platform_priority_rank(row.get("platform") or "", row.get("url") or ""),
            STATUS_ORDER.index(row["status"]) if row["status"] in STATUS_ORDER else 99,
            -float((row.get("confidence") or {}).get("score") or 0.0),
            row.get("platform") or "",
            row.get("handle") or "",
        )
    )
    return _table_model(
        key="profiles",
        title="Profiles",
        columns=[
            {"key": "platform", "label": "Platform", "sortable": True},
            {"key": "handle", "label": "Handle", "sortable": True},
            {"key": "url", "label": "Profile", "type": "url", "sortable": True},
            {"key": "status", "label": "Status", "type": "status", "sortable": True},
            {"key": "confidence", "label": "Confidence", "type": "confidence", "sortable": True},
            {"key": "evidence", "label": "Evidence", "type": "evidence", "sortable": True},
            {"key": "source", "label": "Source", "sortable": True},
            {"key": "last_seen", "label": "Seen", "sortable": True},
        ],
        rows=rows,
        filter_keys=[
            ("status", "Status"),
            ("platform", "Platform"),
            ("candidate_status", "Candidate"),
            ("site_category", "Category"),
            ("confidence_band", "Confidence"),
            ("source", "Source"),
        ],
        empty="No profile rows yet. Run social or music sources for this target.",
    )


def _value_table_row(
    case: dict[str, Any],
    finding: dict[str, Any],
    *,
    value_key: str,
    type_label: str,
) -> dict[str, Any]:
    evidence = _evidence_for(case, finding)
    attachments = _attachments_for(case, finding)
    review_only_search = _is_review_only_search_lead(finding)
    empty_api_response = _evidence_has_empty_api_response(evidence)
    status = "unavailable" if empty_api_response else classify_result_status(finding)
    confidence = (
        confidence_badge(0.0)
        | {"bucket": "none", "reasons": ["Source API returned an empty response - nothing to confirm."]}
        if empty_api_response
        else normalize_confidence(finding)
    )
    raw_url = _finding_url(finding)
    value = _clean(finding.get("page_title")) if review_only_search and value_key == "mention" else _display_value(finding)
    url = "" if review_only_search or empty_api_response else raw_url
    evidence_info = _evidence_summary(evidence, attachments)
    action_url = "" if review_only_search or empty_api_response else url
    row = {
        "finding_id": finding.get("id"),
        value_key: value,
        "url": url,
        "raw_url": raw_url,
        "empty_api_response": empty_api_response,
        "status": status,
        "confidence": confidence,
        "confidence_band": _confidence_filter_value(confidence),
        "signals": [
            *extract_signals(finding, evidence),
            *(["empty API response"] if empty_api_response else []),
        ],
        "evidence": evidence_info,
        "source": _source_name(finding),
        "source_id": _source_key(finding),
        "last_seen": _last_seen(finding),
        "actions": _actions(
            "" if status in {"unavailable", "rejected", "error", "blocked"} else action_url,
            finding.get("id"),
            evidence_info["count"],
        ),
        "inspector": {
            "title": value or type_label,
            "sections": [
                {
                    "title": type_label,
                    "rows": [
                        [type_label, value],
                        ["URL", url],
                        ["Search/API URL", raw_url if raw_url != url else ""],
                        ["Status", status],
                        ["Confidence", confidence.get("label") or ""],
                        ["Data note", "API returned no records." if empty_api_response else ""],
                    ],
                },
                {
                    "title": "Signals",
                    "rows": [["Signals", ", ".join(extract_signals(finding, evidence))]],
                },
                {
                    "title": "Evidence Artifacts",
                    "rows": [
                        ["Count", str(evidence_info.get("count") or 0)],
                        ["Hash", evidence_info.get("hash") or ""],
                        ["Timestamp", evidence_info.get("timestamp") or ""],
                        ["URL", evidence_info.get("url") or ""],
                    ],
                },
            ],
        },
    }
    return row


def _basic_columns(value_key: str, value_label: str, value_type: str = "") -> list[dict[str, Any]]:
    return [
        {"key": value_key, "label": value_label, "type": value_type, "sortable": True},
        {"key": "status", "label": "Verification", "type": "status", "sortable": True},
        {"key": "confidence", "label": "Confidence", "type": "confidence", "sortable": True},
        {"key": "source", "label": "Source", "sortable": True},
        {"key": "evidence", "label": "Evidence", "type": "evidence", "sortable": True},
        {"key": "last_seen", "label": "Seen", "sortable": True},
    ]


def build_emails_table(case: dict[str, Any]) -> dict[str, Any]:
    rows = [
        _value_table_row(case, finding, value_key="email", type_label="Email")
        for finding in _workspace_findings(case)
        if _category(finding) == "emails" or _looks_like_email(_display_value(finding))
    ]
    return _table_model(
        key="emails",
        title="Emails",
        columns=_basic_columns("email", "Email", "email"),
        rows=rows,
        filter_keys=[("status", "Status"), ("confidence_band", "Confidence"), ("source", "Source")],
        empty="No email rows yet.",
    )


def build_phones_table(case: dict[str, Any]) -> dict[str, Any]:
    rows = [
        _value_table_row(case, finding, value_key="phone", type_label="Phone")
        for finding in _workspace_findings(case)
        if _category(finding) == "phones" or _looks_like_phone(_display_value(finding))
    ]
    return _table_model(
        key="phones",
        title="Phones",
        columns=_basic_columns("phone", "Phone", "phone"),
        rows=rows,
        filter_keys=[("status", "Status"), ("confidence_band", "Confidence"), ("source", "Source")],
        empty="No phone rows yet.",
    )


def build_domains_table(case: dict[str, Any]) -> dict[str, Any]:
    rows = [
        _value_table_row(case, finding, value_key="domain", type_label="Domain")
        for finding in _workspace_findings(case)
        if _category(finding) == "domains" or _lower((finding.get("display") or {}).get("display_entity_type")) == "domain"
    ]
    return _table_model(
        key="domains",
        title="Domains",
        columns=_basic_columns("domain", "Domain", "domain"),
        rows=rows,
        filter_keys=[("status", "Status"), ("confidence_band", "Confidence"), ("source", "Source")],
        empty="No domain rows yet.",
    )


def build_mentions_table(case: dict[str, Any]) -> dict[str, Any]:
    rows = []
    for finding in _workspace_findings(case):
        category = _category(finding)
        if category in {"links", "other"} or _is_review_only_search_lead(finding):
            row = _value_table_row(case, finding, value_key="mention", type_label="Mention")
            row["platform"] = _platform_from_finding(finding)
            row["context"] = _clean(finding.get("page_title") or finding.get("finding_type") or "Mention")
            rows.append(row)
    return _table_model(
        key="mentions",
        title="Mentions",
        columns=[
            {"key": "platform", "label": "Platform", "sortable": True},
            {"key": "mention", "label": "Mention", "sortable": True},
            {"key": "url", "label": "URL", "type": "url", "sortable": True},
            {"key": "status", "label": "Status", "type": "status", "sortable": True},
            {"key": "confidence", "label": "Confidence", "type": "confidence", "sortable": True},
            {"key": "source", "label": "Source", "sortable": True},
            {"key": "last_seen", "label": "Seen", "sortable": True},
        ],
        rows=rows,
        filter_keys=[
            ("status", "Status"),
            ("platform", "Platform"),
            ("confidence_band", "Confidence"),
            ("source", "Source"),
        ],
        empty="No mention rows yet.",
    )


def _classify_source_status(source: dict[str, Any]) -> str:
    if _source_is_generated_profile_url(source):
        return "candidate"
    health = source.get("health") if isinstance(source.get("health"), dict) else {}
    status = _lower(health.get("status") or source.get("health_status"))
    last_error = _lower(health.get("last_error") or source.get("last_error"))
    errors = int(health.get("error_count") or source.get("error_count") or 0)
    successes = int(health.get("success_count") or source.get("success_count") or 0)
    if "timeout" in last_error or "timed out" in last_error:
        return "timeout"
    if status in {"missing_keys", "missing_key"}:
        return "missing_key"
    if status in {"blocked", "blocked_by_scope"} or "blocked" in last_error:
        return "blocked"
    if status in {"error", "unavailable"} or errors or last_error:
        return "error"
    if successes:
        return "found"
    if status in {"available", "ok", "degraded", "catalog_only", "unknown"}:
        return status
    return status or "unknown"


def build_sources_table(case: dict[str, Any]) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for source in case.get("sources") or []:
        health = source.get("health") if isinstance(source.get("health"), dict) else {}
        reliability = health.get("effective_reliability")
        if reliability is None:
            reliability = source.get("reliability")
        status = _classify_source_status(source)
        url = "" if _source_is_generated_profile_url(source) else _clean(source.get("url_main"))
        row = {
            "source": _source_name(source),
            "source_id": _source_key(source),
            "category": _clean(source.get("category") or "misc"),
            "adapter": _clean(source.get("adapter")),
            "status": status,
            "reliability": confidence_badge(reliability),
            "success_count": int(health.get("success_count") or source.get("success_count") or 0),
            "error_count": int(health.get("error_count") or source.get("error_count") or 0),
            "last_error": _clean(health.get("last_error") or source.get("last_error")),
            "checked_at": _clean(health.get("checked_at") or source.get("health_checked_at")),
            "url": url,
            "actions": _actions(url),
            "inspector": {
                "title": _source_name(source),
                "sections": [
                    {
                        "title": "Source",
                        "rows": [
                            ["Name", _source_name(source)],
                            ["ID", _source_key(source)],
                            ["Category", _clean(source.get("category"))],
                            ["Adapter", _clean(source.get("adapter"))],
                            ["Status", status],
                            ["Reliability", confidence_badge(reliability)["label"]],
                        ],
                    },
                    {
                        "title": "Run Health",
                        "rows": [
                            ["Success", str(int(health.get("success_count") or source.get("success_count") or 0))],
                            ["Errors", str(int(health.get("error_count") or source.get("error_count") or 0))],
                            ["Last Error", _clean(health.get("last_error") or source.get("last_error"))],
                            ["Checked", _clean(health.get("checked_at") or source.get("health_checked_at"))],
                        ],
                    },
                ],
            },
        }
        rows.append(row)
    return _table_model(
        key="sources",
        title="Sources",
        columns=[
            {"key": "source", "label": "Source", "sortable": True},
            {"key": "category", "label": "Category", "sortable": True},
            {"key": "status", "label": "Status", "type": "status", "sortable": True},
            {"key": "reliability", "label": "Reliability", "type": "confidence", "sortable": True},
            {"key": "success_count", "label": "Success", "sortable": True},
            {"key": "error_count", "label": "Errors", "sortable": True},
            {"key": "checked_at", "label": "Checked", "sortable": True},
        ],
        rows=rows,
        filter_keys=[("status", "Status"), ("category", "Category"), ("adapter", "Adapter")],
        empty="No source rows yet.",
    )


def build_evidence_table(case: dict[str, Any]) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for evidence in case.get("evidence") or []:
        url = _clean(evidence.get("url") or evidence.get("final_url"))
        row = {
            "evidence_id": evidence.get("id"),
            "finding_id": evidence.get("finding_id"),
            "timestamp": _clean(evidence.get("captured_at")),
            "artifact_type": "evidence",
            "url": url,
            "http_status": evidence.get("http_status"),
            "hash": _clean(evidence.get("sha256")),
            "hash_short": _clean(evidence.get("sha256"))[:16],
            "artifact": _clean(evidence.get("artifact_path")),
            "source": _clean(evidence.get("source_module")),
            "status": "found" if _clean(evidence.get("sha256")) or url else "unknown",
            "actions": _actions(url, evidence.get("finding_id"), 1),
        }
        row["inspector"] = {
            "title": row["hash"] or row["url"] or "Evidence artifact",
            "sections": [
                {
                    "title": "Evidence Artifact",
                    "rows": [
                        ["Timestamp", row["timestamp"]],
                        ["URL", row["url"]],
                        ["HTTP", _clean(row["http_status"])],
                        ["Hash", row["hash"]],
                        ["Artifact", row["artifact"]],
                        ["Finding", _clean(row["finding_id"])],
                    ],
                }
            ],
        }
        rows.append(row)
    for attachment in case.get("attachments") or []:
        path = _clean(attachment.get("path") or attachment.get("artifact_path"))
        row = {
            "evidence_id": attachment.get("id"),
            "finding_id": attachment.get("finding_id"),
            "timestamp": _clean(attachment.get("captured_at")),
            "artifact_type": _clean(attachment.get("kind") or "attachment"),
            "url": "",
            "http_status": "",
            "hash": _clean(attachment.get("sha256")),
            "hash_short": _clean(attachment.get("sha256"))[:16],
            "artifact": path,
            "source": _clean(attachment.get("source_adapter_version")),
            "status": "found" if path or _clean(attachment.get("sha256")) else "unknown",
            "actions": _actions("", attachment.get("finding_id"), 1),
        }
        row["inspector"] = {
            "title": row["artifact"] or row["hash"] or "Evidence artifact",
            "sections": [
                {
                    "title": "Evidence Artifact",
                    "rows": [
                        ["Timestamp", row["timestamp"]],
                        ["Type", row["artifact_type"]],
                        ["Hash", row["hash"]],
                        ["Artifact", row["artifact"]],
                        ["Finding", _clean(row["finding_id"])],
                    ],
                }
            ],
        }
        rows.append(row)
    return _table_model(
        key="evidence",
        title="Evidence",
        columns=[
            {"key": "timestamp", "label": "Timestamp", "sortable": True},
            {"key": "artifact_type", "label": "Type", "sortable": True},
            {"key": "url", "label": "URL", "type": "url", "sortable": True},
            {"key": "hash_short", "label": "Hash", "sortable": True},
            {"key": "source", "label": "Source", "sortable": True},
            {"key": "finding_id", "label": "Finding", "sortable": True},
        ],
        rows=rows,
        filter_keys=[("status", "Status"), ("artifact_type", "Type"), ("source", "Source")],
        empty="No evidence artifacts yet.",
    )


def build_graph_model(case: dict[str, Any]) -> dict[str, Any]:
    graph = case.get("graph") or {}
    return {
        "metrics": graph.get("metrics") or {"nodes": len(graph.get("nodes") or []), "edges": len(graph.get("edges") or [])},
        "nodes": graph.get("nodes") or [],
        "edges": graph.get("edges") or [],
    }


def build_exports_model(case: dict[str, Any]) -> dict[str, Any]:
    case_name = _clean((case.get("meta") or {}).get("case") or case.get("case"))
    safe_case = quote(case_name, safe="")
    return {
        "items": [
            {"key": "current_table_csv", "label": "Current table CSV", "format": "CSV", "scope": "browser"},
            {"key": "current_table_json", "label": "Current table JSON", "format": "JSON", "scope": "browser"},
            {"key": "workspace_json", "label": "Workspace JSON", "format": "JSON", "url": f"/cases/{safe_case}/workspace"},
            {"key": "graph_json", "label": "Graph JSON", "format": "JSON", "url": f"/cases/{safe_case}/graph"},
            {"key": "evidence_bundle", "label": "Evidence bundle", "format": "ZIP", "url": f"/reports/evidence-bundle/{safe_case}"},
            {"key": "report_bundle", "label": "Report bundle", "format": "ZIP", "url": f"/reports/bundle/{safe_case}"},
        ],
        "formats": ["CSV", "JSON", "ZIP"],
    }


def build_overview_model(case: dict[str, Any], tables: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    tables = tables or {}
    summary = (case.get("presentation") or {}).get("summary") or {}
    counts = {
        "profiles": len((tables.get("profiles") or {}).get("rows") or []),
        "emails": len((tables.get("emails") or {}).get("rows") or []),
        "phones": len((tables.get("phones") or {}).get("rows") or []),
        "domains": len((tables.get("domains") or {}).get("rows") or []),
        "mentions": len((tables.get("mentions") or {}).get("rows") or []),
        "sources": len((tables.get("sources") or {}).get("rows") or []),
        "evidence": len((tables.get("evidence") or {}).get("rows") or []),
    }
    return {
        "target": _clean(summary.get("target") or (case.get("meta") or {}).get("target") or case.get("case")),
        "updated_at": _clean(summary.get("last_updated") or (case.get("meta") or {}).get("generated_at")),
        "counts": counts,
        "status_counts": {key: count_by_status(table.get("rows") or []) for key, table in tables.items()},
        "primary_tables": [
            {"key": key, "label": (tables.get(key) or {}).get("title", key.title()), "count": counts.get(key, 0)}
            for key in ("profiles", "emails", "phones", "domains", "mentions", "sources", "evidence")
        ],
        "notes": [
            "Profile candidates are separated from found profiles.",
            "Evidence artifacts are preserved separately from raw records.",
        ],
    }


def build_case_workspace_model(case: dict[str, Any]) -> dict[str, Any]:
    tables = {
        "profiles": build_profiles_table(case),
        "emails": build_emails_table(case),
        "phones": build_phones_table(case),
        "domains": build_domains_table(case),
        "mentions": build_mentions_table(case),
        "sources": build_sources_table(case),
        "evidence": build_evidence_table(case),
    }
    return {
        "case": _clean((case.get("meta") or {}).get("case") or case.get("case")),
        "target": _clean((case.get("meta") or {}).get("target") or case.get("target")),
        "tabs": [
            "overview",
            "profiles",
            "emails",
            "phones",
            "domains",
            "mentions",
            "sources",
            "evidence",
            "graph",
            "exports",
            "raw",
        ],
        "overview": build_overview_model(case, tables),
        "tables": tables,
        "graph": build_graph_model(case),
        "exports": build_exports_model(case),
        "raw": {
            "available": True,
            "sections": {
                "meta": case.get("meta") or {},
                "counts": case.get("counts") or {},
                "findings": _workspace_findings(case),
                "generated_url_candidates": case.get("generated_url_candidates") or [],
                "sources": case.get("sources") or [],
                "evidence": case.get("evidence") or [],
                "attachments": case.get("attachments") or [],
                "relations": case.get("relations") or [],
                "graph": case.get("graph") or {},
                "manifest": case.get("manifest") or {},
                "integrity": case.get("integrity") or {},
            },
        },
    }
