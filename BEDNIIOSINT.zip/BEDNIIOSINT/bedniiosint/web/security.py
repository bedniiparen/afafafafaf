from __future__ import annotations

import hashlib
import hmac
import os
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs


AUTH_COOKIE = "bedniiosint_auth"
CSRF_FIELD = "_csrf"
CSRF_HEADER = "x-csrf-token"
TOKEN_HEADER = "x-bedniiosint-token"
MUTATING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
PUBLIC_PATHS = {"/auth/login", "/auth/status"}


@dataclass(frozen=True)
class WebSecurityStatus:
    enabled: bool
    csrf_required: bool
    auth_methods: list[str]

    def as_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "csrf_required": self.csrf_required,
            "auth_methods": self.auth_methods,
        }


def web_token() -> str:
    return os.getenv("BEDNIIOSINT_WEB_TOKEN", "").strip()


def auth_enabled() -> bool:
    return bool(web_token())


def session_cookie_value() -> str:
    token = web_token()
    if not token:
        return ""
    return hmac.new(token.encode("utf-8"), b"bedniiosint:web-session:v1", hashlib.sha256).hexdigest()


def csrf_token() -> str:
    token = web_token()
    if not token:
        return ""
    explicit = os.getenv("BEDNIIOSINT_WEB_CSRF_TOKEN", "").strip()
    if explicit:
        return explicit
    return hmac.new(token.encode("utf-8"), b"bedniiosint:csrf:v1", hashlib.sha256).hexdigest()


def security_status() -> WebSecurityStatus:
    return WebSecurityStatus(
        enabled=auth_enabled(),
        csrf_required=auth_enabled(),
        auth_methods=["bearer", TOKEN_HEADER, "cookie"] if auth_enabled() else [],
    )


def secure_cookie_enabled() -> bool:
    return os.getenv("BEDNIIOSINT_WEB_COOKIE_SECURE", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def token_matches(candidate: str) -> bool:
    token = web_token()
    return bool(token and candidate and hmac.compare_digest(candidate, token))


def request_is_authenticated(request: Any) -> bool:
    if not auth_enabled():
        return True
    auth = str(request.headers.get("authorization", ""))
    if auth.lower().startswith("bearer ") and token_matches(auth.split(" ", 1)[1].strip()):
        return True
    if token_matches(str(request.headers.get(TOKEN_HEADER, ""))):
        return True
    cookie = request.cookies.get(AUTH_COOKIE, "")
    expected = session_cookie_value()
    return bool(cookie and expected and hmac.compare_digest(cookie, expected))


def csrf_valid(request: Any, body: bytes = b"") -> bool:
    if not auth_enabled() or request.method.upper() not in MUTATING_METHODS:
        return True
    expected = csrf_token()
    supplied = str(request.headers.get(CSRF_HEADER, ""))
    if supplied and hmac.compare_digest(supplied, expected):
        return True
    query_value = str(request.query_params.get(CSRF_FIELD, ""))
    if query_value and hmac.compare_digest(query_value, expected):
        return True
    content_type = str(request.headers.get("content-type", "")).lower()
    if body and "application/x-www-form-urlencoded" in content_type:
        fields = parse_qs(body.decode("utf-8", errors="replace"), keep_blank_values=True)
        form_value = fields.get(CSRF_FIELD, [""])[0]
        if form_value and hmac.compare_digest(form_value, expected):
            return True
    return False


def should_skip_security(path: str) -> bool:
    return path in PUBLIC_PATHS or path == "/static" or path.startswith("/static/")
