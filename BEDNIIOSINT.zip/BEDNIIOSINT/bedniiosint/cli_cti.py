from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console


console = Console()
cti_app = typer.Typer(add_completion=False, help="CTI export and live validation planning commands")


def _parse_key_value_options(items: list[str] | None, option_name: str) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for item in items or []:
        if "=" not in item:
            raise typer.BadParameter(f"{option_name} expects key=value")
        key, value = item.split("=", 1)
        clean_key = key.strip()
        if not clean_key:
            raise typer.BadParameter(f"{option_name} key must not be empty")
        parsed[clean_key] = value
    return parsed


@cti_app.command("sync")
def cti_sync(
    case: str = typer.Argument(...),
    opencti_url: str | None = typer.Option(None, "--opencti-url"),
    misp_url: str | None = typer.Option(None, "--misp-url"),
    send: bool = typer.Option(False, "--send", help="Actually POST to configured CTI endpoints"),
    read_back: bool = typer.Option(False, "--read-back", help="Read back the created MISP event after sending"),
    delete_after: bool = typer.Option(False, "--delete-after", help="Delete the created MISP event after sending"),
    opencti_patch_mutation: str = typer.Option(
        "",
        "--opencti-patch-mutation",
        help="OpenCTI patch mutation override, e.g. identityFieldPatch or identityEdit",
    ),
    opencti_patch: list[str] | None = typer.Option(
        None,
        "--opencti-patch",
        help="OpenCTI fieldPatch key=value; repeat for multiple fields",
    ),
    opencti_patch_map: list[str] | None = typer.Option(
        None,
        "--opencti-patch-map",
        help="OpenCTI entity_type=mutation inference override; repeat for multiple types",
    ),
):
    """Dry-run or POST local case exports to OpenCTI/MISP endpoints."""
    from .core.case_summary import build_case_summary
    from .reports.cti_sync import sync_misp, sync_opencti

    summary = build_case_summary(case)
    if not summary.get("meta", {}).get("found"):
        console.print("[red]case not found[/]")
        raise typer.Exit(1)
    opencti_patch_fields = _parse_key_value_options(opencti_patch, "--opencti-patch")
    opencti_patch_mutation_map = _parse_key_value_options(opencti_patch_map, "--opencti-patch-map")
    results = []
    if opencti_url:
        results.append(
            sync_opencti(
                summary,
                url=opencti_url,
                dry_run=not send,
                read_back=read_back,
                delete_after=delete_after,
                patch_fields=opencti_patch_fields or None,
                patch_mutation=opencti_patch_mutation,
                patch_mutation_map=opencti_patch_mutation_map or None,
            ).as_dict()
        )
    if misp_url:
        results.append(
            sync_misp(
                summary,
                url=misp_url,
                dry_run=not send,
                read_back=read_back,
                delete_after=delete_after,
            ).as_dict()
        )
    if not results:
        console.print("[red]provide --opencti-url or --misp-url[/]")
        raise typer.Exit(1)
    console.print(json.dumps({"case": case, "sent": send, "results": results}, indent=2, ensure_ascii=False))


@cti_app.command("preflight")
def cti_preflight(
    opencti_url: str | None = typer.Option(None, "--opencti-url"),
    misp_url: str | None = typer.Option(None, "--misp-url"),
):
    """Check OpenCTI/MISP endpoint/token compatibility without sending case data."""
    from .reports.cti_sync import preflight_misp, preflight_opencti

    results = []
    if opencti_url:
        results.append(preflight_opencti(url=opencti_url).as_dict())
    if misp_url:
        results.append(preflight_misp(url=misp_url).as_dict())
    if not results:
        console.print("[red]provide --opencti-url or --misp-url[/]")
        raise typer.Exit(1)
    console.print(json.dumps({"results": results}, indent=2, ensure_ascii=False))


@cti_app.command("live-plan")
def live_plan(
    runbook: bool = typer.Option(False, "--runbook", help="Print a Markdown live validation runbook"),
    account_runbook: bool = typer.Option(
        False,
        "--account-runbook",
        help="Print a Markdown keyed-provider account validation runbook",
    ),
    priority: str = typer.Option(
        "P0,P1",
        "--priority",
        help="Comma-separated source priorities for --account-runbook",
    ),
    out: Path | None = typer.Option(None, "--out", help="Write JSON or Markdown output to this path"),
):
    """Print live validation readiness without making network requests."""
    from .core.live_plan import (
        live_account_validation_runbook,
        live_validation_plan,
        live_validation_runbook,
    )

    plan = live_validation_plan()
    priorities = tuple(item.strip().upper() for item in priority.split(",") if item.strip())
    if account_runbook:
        output = live_account_validation_runbook(priorities=priorities)
    else:
        output = (
            live_validation_runbook(plan)
            if runbook
            else json.dumps(plan, indent=2, ensure_ascii=False)
        )
    if out:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(output, encoding="utf-8")
        label = "Live account validation runbook" if account_runbook else "Live validation plan"
        console.print(f"[dim]{label} ->[/] {out}")
        return
    console.print(output, markup=False)
