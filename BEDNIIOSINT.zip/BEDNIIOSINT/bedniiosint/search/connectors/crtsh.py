from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class CrtShConnector(BaseConnector):
    """crt.sh Certificate Transparency logs -> subdomains (keyless)."""

    source_id = "crtsh"
    source_name = "crt.sh (CT logs)"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "domain",
            "host",
        }

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        domain = query_plan.entity_input.lstrip("*.")
        response = request(
            "GET",
            "https://crt.sh/",
            params={"q": "%." + domain, "output": "json"},
        )
        try:
            data = response.json() if response.content else []
        except Exception:
            data = []
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "target": domain,
            "data": data if isinstance(data, list) else [],
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        seen: set[str] = set()
        rows: list[dict[str, Any]] = []
        for cert in raw_response.get("data") or []:
            for name in str(cert.get("name_value") or "").splitlines():
                name = name.strip().lstrip("*.").lower()
                if name and name not in seen:
                    seen.add(name)
                    rows.append({"subdomain": name, "issuer": cert.get("issuer_name")})
        return rows

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            sub = str(item.get("subdomain") or "")
            results.append(
                SearchResult(
                    id=f"crtsh:{index}:{sub}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=sub,
                    entity_type="domain",
                    matched_entity=sub,
                    title="Subdomain: " + sub,
                    url="https://" + sub,
                    snippet="Issuer: " + str(item.get("issuer") or "unknown"),
                    raw_data=item,
                    normalized_data={"connector": "crtsh", "subdomain": sub},
                    confidence_score=0.7,
                    tags=["subdomain", "attack_surface", "ct_logs"],
                    legal_notes="Public Certificate Transparency data.",
                    explanation="Subdomain discovered via crt.sh Certificate Transparency logs.",
                )
            )
        return results
