from __future__ import annotations

from typing import Any

from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class HoleheConnector(BaseConnector):
    source_id = "holehe"
    source_name = "Holehe"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "email"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        return {
            "status": "blocked",
            "query_plan": query_plan.as_dict(),
            "items": [
                {
                    "email": query_plan.entity_input,
                    "reason": "email_registration_enumeration_is_not_supported",
                }
            ],
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        return [dict(item) for item in raw_response.get("items") or [] if isinstance(item, dict)]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            email = str(item.get("email") or "")
            results.append(
                SearchResult(
                    id=f"holehe:{index}:{email}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=email,
                    entity_type="email",
                    matched_entity=email,
                    title="Blocked high-risk email registration enumeration",
                    url="",
                    snippet="Holehe-style account registration enumeration is disabled by policy.",
                    raw_data=item,
                    normalized_data={
                        "connector": "holehe",
                        "review_only": True,
                        "legal_status": "blocked",
                    },
                    confidence_score=0.0,
                    tags=["blocked_connector", "review_only"],
                    risk_flags=[
                        "blocked_source",
                        "email_registration_enumeration",
                        "manual_verification_required",
                    ],
                    legal_notes=(
                        "Holehe is marked reject/high risk in the BEDNIIOSINT catalog and is not run."
                    ),
                    explanation="Connector is present only as a policy guard; no account checks are executed.",
                )
            )
        return results
