from __future__ import annotations

from typing import Any

from ...config import settings
from ...core.http import async_request, request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class SecurityTrailsConnector(BaseConnector):
    """SecurityTrails passive DNS / subdomain enumeration."""

    source_id = "securitytrails"
    source_name = "SecurityTrails"
    supports_async = True

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "domain"

    def _headers(self) -> dict[str, str]:
        return {
            "Accept": "application/json",
            "APIKEY": getattr(settings, "securitytrails_api_key", "") or "",
        }

    def _url(self, query_plan: QueryPlan) -> str:
        return f"https://api.securitytrails.com/v1/domain/{query_plan.entity_input}/subdomains"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        if not getattr(settings, "securitytrails_api_key", ""):
            return {
                "status": "missing_keys",
                "missing_env": ["SECURITYTRAILS_API_KEY"],
                "query_plan": query_plan.as_dict(),
                "items": [],
            }
        response = request(
            "GET",
            self._url(query_plan),
            params={"children_only": "false"},
            headers=self._headers(),
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "apex": query_plan.entity_input,
            "data": data if isinstance(data, dict) else {},
        }

    async def arun(self, query_plan: QueryPlan) -> dict[str, Any]:
        if not getattr(settings, "securitytrails_api_key", ""):
            return {
                "status": "missing_keys",
                "missing_env": ["SECURITYTRAILS_API_KEY"],
                "query_plan": query_plan.as_dict(),
                "items": [],
            }
        response = await async_request(
            "GET",
            self._url(query_plan),
            params={"children_only": "false"},
            headers=self._headers(),
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "apex": query_plan.entity_input,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        if not isinstance(data, dict):
            return []
        apex = str(raw_response.get("apex") or "")
        subs = data.get("subdomains") or []
        return [
            {"host": f"{sub}.{apex}", "label": str(sub), "apex": apex}
            for sub in subs
            if str(sub).strip() and apex
        ]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            host = str(item.get("host") or "")
            if not host:
                continue
            apex = str(item.get("apex") or host)
            results.append(
                SearchResult(
                    id=f"securitytrails:{index}:{host}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=apex,
                    entity_type="domain",
                    matched_entity=host,
                    title="Subdomain: " + host,
                    url="https://" + host,
                    snippet="Passive-DNS subdomain of " + apex,
                    raw_data=item,
                    normalized_data={"connector": "securitytrails", "host": host},
                    detected_platform="dns",
                    confidence_score=0.75,
                    tags=["infrastructure", "subdomain", "dns"],
                    legal_notes="SecurityTrails passive DNS data.",
                    explanation="Subdomain enumerated via SecurityTrails passive DNS.",
                )
            )
        return results
