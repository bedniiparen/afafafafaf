from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class HackerTargetConnector(BaseConnector):
    """HackerTarget hostsearch -> subdomain/IP pairs (keyless, rate limited)."""

    source_id = "hackertarget"
    source_name = "HackerTarget"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "domain",
            "host",
        }

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = request(
            "GET",
            "https://api.hackertarget.com/hostsearch/",
            params={"q": query_plan.entity_input},
        )
        text = response.text if hasattr(response, "text") else ""
        return {
            "status": "ok" if response.status_code < 400 and "error" not in text.lower() else "error",
            "status_code": response.status_code,
            "text": text,
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        rows: list[dict[str, Any]] = []
        for line in str(raw_response.get("text") or "").splitlines():
            if "," in line:
                host, _, ip = line.partition(",")
                rows.append({"host": host.strip(), "ip": ip.strip()})
        return rows

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            host = str(item.get("host") or "")
            ip = str(item.get("ip") or "")
            results.append(
                SearchResult(
                    id=f"hackertarget:{index}:{host}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=host,
                    entity_type="domain",
                    matched_entity=host,
                    title=f"{host} -> {ip}",
                    url="https://" + host,
                    snippet="Resolves to " + ip,
                    raw_data=item,
                    normalized_data={"connector": "hackertarget", "ip": ip},
                    confidence_score=0.62,
                    tags=["subdomain", "dns", "attack_surface"],
                    legal_notes="Public passive DNS via HackerTarget; respect rate limits.",
                    explanation="Host/IP pair returned by HackerTarget hostsearch.",
                )
            )
        return results
