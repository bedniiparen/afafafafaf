from __future__ import annotations

from typing import Any

from ...config import settings
from ...core.http import async_request, request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class UrlscanConnector(BaseConnector):
    """urlscan.io passive scan search."""

    source_id = "urlscan"
    source_name = "urlscan.io"
    supports_async = True

    _TYPE_FIELD = {"domain": "domain", "ip": "ip", "url": "page.url"}

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "domain",
            "ip",
            "url",
        }

    def _headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        key = getattr(settings, "urlscan_api_key", "") or ""
        if key:
            headers["API-Key"] = key
        return headers

    def _params(self, query_plan: QueryPlan) -> dict[str, str]:
        field = self._TYPE_FIELD.get(query_plan.entity_type, "domain")
        return {"q": f"{field}:{query_plan.entity_input}", "size": "20"}

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = request(
            "GET",
            "https://urlscan.io/api/v1/search/",
            params=self._params(query_plan),
            headers=self._headers(),
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "data": data if isinstance(data, dict) else {},
        }

    async def arun(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = await async_request(
            "GET",
            "https://urlscan.io/api/v1/search/",
            params=self._params(query_plan),
            headers=self._headers(),
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        if not isinstance(data, dict):
            return []
        return [dict(item) for item in (data.get("results") or []) if isinstance(item, dict)]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            page = item.get("page") if isinstance(item.get("page"), dict) else {}
            task = item.get("task") if isinstance(item.get("task"), dict) else {}
            page_url = str(page.get("url") or task.get("url") or "")
            if not page_url:
                continue
            domain = str(page.get("domain") or "")
            ip = str(page.get("ip") or "")
            matched = domain or ip or page_url
            snippet_bits = [
                f"domain: {domain}" if domain else "",
                f"ip: {ip}" if ip else "",
                f"server: {page.get('server')}" if page.get("server") else "",
                f"country: {page.get('country')}" if page.get("country") else "",
            ]
            results.append(
                SearchResult(
                    id=f"urlscan:{index}:{item.get('_id') or page_url}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=matched,
                    entity_type="url",
                    matched_entity=matched,
                    title="urlscan: " + (domain or page_url),
                    url=str(item.get("result") or page_url),
                    snippet="; ".join(bit for bit in snippet_bits if bit) or f"Scanned {page_url}",
                    raw_data=item,
                    normalized_data={"connector": "urlscan", "domain": domain, "ip": ip},
                    detected_platform="web",
                    last_seen=str(task.get("time") or "") or None,
                    confidence_score=0.7,
                    tags=["infrastructure", "scan", "url"],
                    legal_notes="Public urlscan.io scan metadata.",
                    explanation="Passive scan record from urlscan.io for the supplied indicator.",
                )
            )
        return results
