from __future__ import annotations

from typing import Any, ClassVar

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class PublicProfileConnector(BaseConnector):
    """Public, keyless username existence check for one platform."""

    platform: ClassVar[str] = "generic"
    url_template: ClassVar[str] = "https://example.com/{username}"
    present_markers: ClassVar[tuple[str, ...]] = ()
    absent_markers: ClassVar[tuple[str, ...]] = ()
    require_present_marker: ClassVar[bool] = False
    confidence: ClassVar[float] = 0.6

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "username"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        username = query_plan.entity_input.lstrip("@").strip()
        url = self.url_template.format(username=username)
        try:
            response = request(
                "GET",
                url,
                headers={"User-Agent": "Mozilla/5.0 (compatible; BEDNIIOSINT)"},
            )
        except Exception as exc:
            return {"status": "error", "url": url, "username": username, "error": str(exc)}
        try:
            body = response.text or ""
        except Exception:
            body = ""
        return {
            "status": "ok",
            "status_code": response.status_code,
            "url": url,
            "username": username,
            "body": body[:40000],
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        status = int(raw_response.get("status_code") or 0)
        low = (raw_response.get("body") or "").lower()
        exists = 200 <= status < 300
        if exists and self.absent_markers and any(marker in low for marker in self.absent_markers):
            exists = False
        if exists and self.require_present_marker and self.present_markers:
            exists = any(marker in low for marker in self.present_markers)
        if not exists:
            return []
        return [
            {
                "username": raw_response.get("username"),
                "url": raw_response.get("url"),
                "status_code": status,
            }
        ]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            username = str(item.get("username") or "")
            results.append(
                SearchResult(
                    id=f"{self.source_id}:{index}:{username}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=username,
                    entity_type="username",
                    matched_entity=username,
                    title=f"{self.source_name}: {username}",
                    url=str(item.get("url") or ""),
                    snippet=f"Public {self.platform} profile page is reachable for {username}.",
                    raw_data=item,
                    normalized_data={"connector": self.source_id, "platform": self.platform},
                    detected_platform=self.platform,
                    confidence_score=self.confidence,
                    tags=["profile", "username", self.platform],
                    legal_notes="Public profile existence check; no authenticated access.",
                    explanation=f"{self.source_name} returned a reachable public profile page.",
                )
            )
        return results


class TelegramConnector(PublicProfileConnector):
    source_id = "telegram_public"
    source_name = "Telegram (public)"
    platform = "telegram"
    url_template = "https://t.me/{username}"
    present_markers = ("tgme_page_title", "tgme_page_photo")
    require_present_marker = True
    confidence = 0.6


class YouTubeConnector(PublicProfileConnector):
    source_id = "youtube_handle"
    source_name = "YouTube Channel"
    platform = "youtube"
    url_template = "https://www.youtube.com/@{username}"
    absent_markers = ("this page isn't available", "404 not found")
    confidence = 0.6


class VkConnector(PublicProfileConnector):
    source_id = "vk_public"
    source_name = "VK Profile"
    platform = "vk"
    url_template = "https://vk.com/{username}"
    absent_markers = ("page not found", "404 not found", "страница удалена")
    confidence = 0.5


def _profile_connector(
    source_id: str,
    source_name: str,
    platform: str,
    url_template: str,
    *,
    confidence: float = 0.6,
    require_present_marker: bool = False,
    present_markers: tuple[str, ...] = (),
    absent_markers: tuple[str, ...] = (),
) -> type[PublicProfileConnector]:
    return type(
        "Profile_" + source_id,
        (PublicProfileConnector,),
        {
            "source_id": source_id,
            "source_name": source_name,
            "platform": platform,
            "url_template": url_template,
            "confidence": confidence,
            "require_present_marker": require_present_marker,
            "present_markers": tuple(present_markers),
            "absent_markers": tuple(absent_markers),
        },
    )


_EXTRA_PROFILE_SPECS = [
    ("steam_id", "Steam Community", "steam", "https://steamcommunity.com/id/{username}", {"absent_markers": ("the specified profile could not be found",)}),
    ("twitch_user", "Twitch", "twitch", "https://www.twitch.tv/{username}", {"absent_markers": ("sorry. unless you've got a time machine",), "confidence": 0.55}),
    ("pinterest_user", "Pinterest", "pinterest", "https://www.pinterest.com/{username}/", {"absent_markers": ("user not found", "page not found"), "confidence": 0.55}),
    ("soundcloud_user", "SoundCloud", "soundcloud", "https://soundcloud.com/{username}", {"absent_markers": ("we can\u2019t find that user", "404 not found")}),
    ("medium_user", "Medium", "medium", "https://medium.com/@{username}", {"absent_markers": ("page not found", "out of nothing, something"), "confidence": 0.55}),
    ("devto_user", "DEV Community", "devto", "https://dev.to/{username}", {"absent_markers": ("this page does not exist",)}),
    ("patreon_user", "Patreon", "patreon", "https://www.patreon.com/{username}", {"absent_markers": ("page not found", "this page isn't available"), "confidence": 0.5}),
    ("linktree_user", "Linktree", "linktree", "https://linktr.ee/{username}", {"absent_markers": ("the page you\u2019re looking for doesn\u2019t exist",)}),
    ("lastfm_user", "Last.fm", "lastfm", "https://www.last.fm/user/{username}", {"absent_markers": ("page not found",)}),
    ("letterboxd_user", "Letterboxd", "letterboxd", "https://letterboxd.com/{username}/", {"absent_markers": ("sorry, we can\u2019t find the page",)}),
    ("vimeo_user", "Vimeo", "vimeo", "https://vimeo.com/{username}", {"absent_markers": ("page not found", "404"), "confidence": 0.5}),
    ("dailymotion_user", "Dailymotion", "dailymotion", "https://www.dailymotion.com/{username}", {"absent_markers": ("page not found",), "confidence": 0.5}),
    ("deviantart_user", "DeviantArt", "deviantart", "https://www.deviantart.com/{username}", {"absent_markers": ("page not found", "the page you were looking for")}),
    ("replit_user", "Replit", "replit", "https://replit.com/@{username}", {"absent_markers": ("404", "not found"), "confidence": 0.5}),
    ("kaggle_user", "Kaggle", "kaggle", "https://www.kaggle.com/{username}", {"absent_markers": ("page not found",), "confidence": 0.5}),
    ("behance_user", "Behance", "behance", "https://www.behance.net/{username}", {"absent_markers": ("page not found", "oops!"), "confidence": 0.55}),
    ("dribbble_user", "Dribbble", "dribbble", "https://dribbble.com/{username}", {"absent_markers": ("whoops, that page is gone",)}),
    ("keybase_user", "Keybase", "keybase", "https://keybase.io/{username}", {"absent_markers": ("user not found", "404")}),
    ("okru_user", "OK.ru", "okru", "https://ok.ru/{username}", {"absent_markers": ("\u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u0430", "page not found"), "confidence": 0.5}),
    ("habr_user", "Habr", "habr", "https://habr.com/ru/users/{username}/", {"absent_markers": ("\u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u0430", "404")}),
]

EXTRA_PROFILE_CONNECTORS = [
    _profile_connector(spec_id, name, platform, template, **kwargs)
    for (spec_id, name, platform, template, kwargs) in _EXTRA_PROFILE_SPECS
]

PUBLIC_PROFILE_CONNECTORS = [TelegramConnector, YouTubeConnector, VkConnector] + EXTRA_PROFILE_CONNECTORS
