from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class WaybackConnector(BaseConnector):
    """Wayback Machine CDX API -> archived URLs (keyless)."""

    source_id = "wayback"
    source_name = "Wayback Machine"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "domain",
            "host",
            "url",
        }

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        target = query_plan.entity_input
        pattern = target if "/" in target else target + "/*"
        response = request(
            "GET",
            "https://web.archive.org/cdx/search/cdx",
            params={
                "url": pattern,
                "output": "json",
                "fl": "original,timestamp,statuscode,mimetype",
                "collapse": "urlkey",
                "limit": "500",
            },
        )
        try:
            data = response.json() if response.content else []
        except Exception:
            data = []
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "target": target,
            "data": data if isinstance(data, list) else [],
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        rows = raw_response.get("data") or []
        if not rows or len(rows) < 2:
            return []
        header = rows[0]
        return [dict(zip(header, row)) for row in rows[1:]]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            original = str(item.get("original") or "")
            ts = str(item.get("timestamp") or "")
            snapshot = ("https://web.archive.org/web/" + ts + "/" + original) if ts else original
            results.append(
                SearchResult(
                    id=f"wayback:{index}:{original}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=original,
                    entity_type="url",
                    matched_entity=original,
                    title="Archived: " + original,
                    url=snapshot,
                    snippet=f"{item.get('statuscode', '')} {item.get('mimetype', '')} @ {ts}".strip(),
                    raw_data=item,
                    normalized_data={"connector": "wayback", "timestamp": ts},
                    confidence_score=0.6,
                    tags=["archive", "history", "url"],
                    legal_notes="Public Internet Archive snapshots.",
                    explanation="Archived URL captured by the Wayback Machine CDX index.",
                )
            )
        return results
