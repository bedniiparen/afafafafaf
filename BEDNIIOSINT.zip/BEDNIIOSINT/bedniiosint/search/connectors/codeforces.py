from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class CodeforcesConnector(BaseConnector):
    """Codeforces public user.info lookup (keyless)."""

    source_id = "codeforces"
    source_name = "Codeforces"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "username"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = request(
            "GET",
            "https://codeforces.com/api/user.info",
            params={"handles": query_plan.entity_input},
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 and data.get("status") == "OK" else "error",
            "status_code": response.status_code,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        return list((raw_response.get("data") or {}).get("result") or [])

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            handle = str(item.get("handle") or "")
            location = " ".join(
                str(item.get(k) or "") for k in ("city", "country", "organization")
            ).strip()
            results.append(
                SearchResult(
                    id=f"codeforces:{index}:{handle}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=handle,
                    entity_type="username",
                    matched_entity=handle,
                    title="Codeforces: " + handle,
                    url="https://codeforces.com/profile/" + handle,
                    snippet=("rating: " + str(item.get("rating") or "n/a") + "; " + location).strip("; "),
                    raw_data=item,
                    normalized_data={"connector": "codeforces", "rating": item.get("rating")},
                    detected_platform="codeforces",
                    confidence_score=0.7,
                    tags=["profile", "developer", "username"],
                    legal_notes="Public Codeforces profile data.",
                    explanation="Public Codeforces account resolved via user.info.",
                )
            )
        return results
