from __future__ import annotations

from typing import Any

from ...core.http import async_request, request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class WikidataConnector(BaseConnector):
    """Wikidata entity search for people, companies and organizations (keyless)."""

    source_id = "wikidata"
    source_name = "Wikidata"
    supports_async = True

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "name",
            "company",
            "org",
            "organization",
        }

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = request(
            "GET",
            "https://www.wikidata.org/w/api.php",
            params={
                "action": "wbsearchentities",
                "search": query_plan.entity_input,
                "language": "en",
                "format": "json",
                "limit": "10",
            },
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "data": data if isinstance(data, dict) else {},
        }

    async def arun(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = await async_request(
            "GET",
            "https://www.wikidata.org/w/api.php",
            params={
                "action": "wbsearchentities",
                "search": query_plan.entity_input,
                "language": "en",
                "format": "json",
                "limit": "10",
            },
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        return list((raw_response.get("data") or {}).get("search") or [])

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            qid = str(item.get("id") or "")
            label = str(item.get("label") or "")
            results.append(
                SearchResult(
                    id=f"wikidata:{index}:{qid}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=label,
                    entity_type="name",
                    matched_entity=label,
                    title="Wikidata: " + label + " (" + qid + ")",
                    url=str(item.get("concepturi") or ("https://www.wikidata.org/wiki/" + qid)),
                    snippet=str(item.get("description") or "Wikidata entity"),
                    raw_data=item,
                    normalized_data={"connector": "wikidata", "qid": qid},
                    confidence_score=0.55,
                    tags=["knowledge_base", "entity", "identity"],
                    legal_notes="Public Wikidata knowledge base (CC0).",
                    explanation="Candidate entity matched in the Wikidata knowledge base.",
                )
            )
        return results
