from __future__ import annotations

"""WhatsMyName data-driven username connector."""

import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ...core.http import request
from ..host_throttle import HostThrottle, NegativeCache, throttled_request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan

try:
    from ..presence import STRONG_NEGATIVE_MARKERS
except Exception:  # pragma: no cover - connector still works standalone
    STRONG_NEGATIVE_MARKERS = ()

_PLACEHOLDER = "{account}"
_USER_AGENT = "bedniiosint-osint/1.0 (+wmn)"
_SITES_CACHE: list[dict[str, Any]] | None = None
_CACHE_KEY: str | None = None
_THROTTLE = HostThrottle(default_rate=5.0, burst=5.0, min_rate=0.5, max_rate=20.0)
_NEGATIVE_CACHE = NegativeCache(ttl=3600.0)


def _default_data_paths() -> tuple[str, ...]:
    package_root = Path(__file__).resolve().parents[2]
    project_root = package_root.parent
    return (
        os.environ.get("BEDNIIOSINT_WMN_DATA", ""),
        str(package_root / "data" / "wmn-data.json"),
        str(project_root / "data" / "wmn-data.json"),
    )


def _resolve_data_path(explicit: str | None = None) -> Path | None:
    for candidate in (explicit or "", *_default_data_paths()):
        if candidate and Path(candidate).is_file():
            return Path(candidate)
    return None


def load_wmn_sites(path: str | None = None) -> list[dict[str, Any]]:
    """Load and cache WMN site definitions. Missing/invalid files return an empty list."""
    global _SITES_CACHE, _CACHE_KEY

    resolved = _resolve_data_path(path)
    if resolved is None:
        return []
    key = f"{resolved}:{resolved.stat().st_mtime_ns}"
    if _SITES_CACHE is not None and _CACHE_KEY == key:
        return _SITES_CACHE
    try:
        payload = json.loads(resolved.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []

    raw_sites = payload.get("sites") if isinstance(payload, dict) else payload
    sites = [
        dict(site)
        for site in (raw_sites or [])
        if isinstance(site, dict) and site.get("uri_check")
    ]
    _SITES_CACHE = sites
    _CACHE_KEY = key
    return sites


def _account_value(site: dict[str, Any], username: str) -> str:
    account = username
    for char in str(site.get("strip_bad_char") or ""):
        account = account.replace(char, "")
    return account


def _fill(template: Any, account: str) -> str:
    return str(template or "").replace(_PLACEHOLDER, account)


def _body_text(response: Any) -> str:
    try:
        return str(response.text or "")
    except Exception:
        return ""


def _as_int(value: Any) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _contains_marker(body: str, marker: Any) -> bool:
    if marker is None or marker == "":
        return False
    if isinstance(marker, list):
        return any(_contains_marker(body, item) for item in marker)
    return str(marker) in body


def _is_match(site: dict[str, Any], status_code: int, body: str) -> tuple[bool, str]:
    """Apply WMN detection rules and return (matched, reason)."""
    e_code = _as_int(site.get("e_code"))
    m_code = _as_int(site.get("m_code"))
    e_string = site.get("e_string")
    m_string = site.get("m_string")

    if _contains_marker(body, m_string):
        return False, "matched site missing-string (m_string)"
    if m_code is not None and status_code == m_code and not e_string:
        return False, "matched site missing-code (m_code)"

    code_ok = e_code is None or status_code == e_code
    string_ok = not e_string or _contains_marker(body, e_string)
    if not (code_ok and string_ok):
        return False, "no positive match"

    lowered = body.lower()
    for marker in STRONG_NEGATIVE_MARKERS:
        if marker and str(marker).lower() in lowered:
            return False, f"strong negative marker: {marker!r}"
    return True, "matched e_code/e_string"


class WmnConnector(BaseConnector):
    """Check a username across the WhatsMyName site catalog."""

    source_id = "wmn"
    source_name = "WhatsMyName"

    DEFAULT_WORKERS = 24
    DEFAULT_MAX_SITES = 0

    def __init__(self, source: dict[str, Any] | None = None) -> None:
        super().__init__(source)
        cfg = self.source if isinstance(self.source, dict) else {}
        self.data_path = str(cfg.get("wmn_data_path") or "") or None
        self.workers = int(cfg.get("wmn_workers") or self.DEFAULT_WORKERS)
        self.max_sites = int(cfg.get("wmn_max_sites") or self.DEFAULT_MAX_SITES)
        self.categories = {str(item).lower() for item in (cfg.get("wmn_categories") or [])}

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "username"

    def _selected_sites(self) -> list[dict[str, Any]]:
        sites = load_wmn_sites(self.data_path)
        try:
            from ..username_corpus import extend_wmn_sites

            sites = extend_wmn_sites(sites)
        except Exception:
            pass
        if self.categories:
            sites = [site for site in sites if str(site.get("cat") or "").lower() in self.categories]
        if self.max_sites > 0:
            sites = sites[: self.max_sites]
        return sites

    def _check_site(self, site: dict[str, Any], username: str) -> dict[str, Any] | None:
        account = _account_value(site, username)
        url = _fill(site.get("uri_check"), account)
        if not url or _PLACEHOLDER in url:
            return None
        headers = {"User-Agent": _USER_AGENT}
        extra_headers = site.get("headers")
        if isinstance(extra_headers, dict):
            headers.update({str(key): str(value) for key, value in extra_headers.items()})
        try:
            response = throttled_request(
                "GET",
                url,
                throttle=_THROTTLE,
                negative_cache=_NEGATIVE_CACHE,
                request_fn=request,
                headers=headers,
                follow_redirects=True,
            )
        except Exception:
            return None
        if response is None:
            return None

        status_code = int(getattr(response, "status_code", 0) or 0)
        matched, reason = _is_match(site, status_code, _body_text(response))
        if not matched:
            return None
        return {
            "site": str(site.get("name") or ""),
            "category": str(site.get("cat") or ""),
            "url": _fill(site.get("uri_pretty") or site.get("uri_check"), account),
            "check_url": url,
            "status_code": status_code,
            "username": username,
            "reason": reason,
        }

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        sites = self._selected_sites()
        items: list[dict[str, Any]] = []
        if not sites:
            return {"status": "empty", "reason": "wmn-data.json not found", "items": items}

        workers = max(1, min(self.workers, len(sites)))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(self._check_site, site, query_plan.entity_input) for site in sites]
            for future in as_completed(futures):
                hit = future.result()
                if hit:
                    items.append(hit)
        return {"status": "ok", "checked": len(sites), "items": items}

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if not isinstance(raw_response, dict):
            return []
        return list(raw_response.get("items") or [])

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        now = datetime.now(timezone.utc).isoformat()
        for item in parsed:
            site = str(item.get("site") or "site")
            username = str(item.get("username") or "")
            category = str(item.get("category") or "")
            status_code = int(item.get("status_code") or 0)
            confidence = 0.78 if status_code and status_code < 400 else 0.72
            results.append(
                SearchResult(
                    id=f"wmn:{site}:{username}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=username,
                    entity_type="username",
                    matched_entity=username,
                    matched_variant=username,
                    title=f"{site}: {username}",
                    url=str(item.get("url") or ""),
                    snippet=f"username present on {site}" + (f" ({category})" if category else ""),
                    raw_data=item,
                    normalized_data={
                        "connector": "wmn",
                        "site": site,
                        "category": category,
                        "status_code": status_code,
                        "presence_state": "found",
                        "detection": item.get("reason"),
                    },
                    detected_platform=site.lower(),
                    found_at=now,
                    tags=["profile", "username", "wmn"] + ([category] if category else []),
                    confidence_score=round(min(confidence, 0.95), 3),
                    context_match_score=1.0,
                    legal_notes="Public profile existence check via WhatsMyName ruleset.",
                    explanation=(
                        f"WhatsMyName matched '{username}' on {site} "
                        f"(HTTP {status_code}; {item.get('reason')})."
                    ),
                )
            )
        return results
