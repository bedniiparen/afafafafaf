from __future__ import annotations

import base64
from typing import Any

from ...config import settings
from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class CensysConnector(BaseConnector):
    source_id = "censys"
    source_name = "Censys"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "ip",
            "domain",
            "host",
        }

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        if not settings.censys_api_id or not settings.censys_api_secret:
            return {
                "status": "missing_keys",
                "missing_env": ["CENSYS_API_ID", "CENSYS_API_SECRET"],
                "query_plan": query_plan.as_dict(),
                "items": [],
            }
        token = f"{settings.censys_api_id}:{settings.censys_api_secret}".encode("utf-8")
        headers = {"Authorization": "Basic " + base64.b64encode(token).decode("ascii")}
        target = query_plan.entity_input
        url = "https://search.censys.io/api/v2/hosts/" + target
        response = request("GET", url, headers=headers)
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "data": response.json() if response.content else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        plan = raw_response.get("query_plan") or {}
        if isinstance(data, dict):
            result = data.get("result") if isinstance(data.get("result"), dict) else data
            services = result.get("services") if isinstance(result, dict) else []
            return [{**result, "services": services or [], "target": plan.get("entity_input")}]
        return []

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            target = str(item.get("target") or item.get("ip") or "")
            services = item.get("services") if isinstance(item.get("services"), list) else []
            service_names = [
                str(service.get("service_name") or service.get("port") or "")
                for service in services
                if isinstance(service, dict)
            ]
            results.append(
                SearchResult(
                    id=f"censys:{index}:{target}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=target,
                    entity_type="ip",
                    matched_entity=target,
                    title="Censys host intelligence for " + target,
                    url="https://search.censys.io/hosts/" + target if target else "",
                    snippet=", ".join(item for item in service_names if item) or "Censys host record.",
                    raw_data=item,
                    normalized_data={"connector": "censys", "services": services},
                    confidence_score=0.72,
                    tags=["attack_surface", "passive_lookup"],
                    legal_notes="Passive keyed lookup through Censys API; respect provider terms.",
                    explanation="Censys returned passive host and service metadata for the target.",
                )
            )
        return results
