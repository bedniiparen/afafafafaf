from __future__ import annotations

import hashlib
from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class GravatarConnector(BaseConnector):
    """Gravatar profile lookup by email hash (keyless)."""

    source_id = "gravatar"
    source_name = "Gravatar"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "email"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        email = query_plan.entity_input.strip().lower()
        digest = hashlib.md5(email.encode("utf-8")).hexdigest()
        response = request("GET", "https://www.gravatar.com/" + digest + ".json")
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "hash": digest,
            "email": email,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        entries = (raw_response.get("data") or {}).get("entry") or []
        rows = []
        for entry in entries:
            entry["_email"] = raw_response.get("email")
            entry["_hash"] = raw_response.get("hash")
            rows.append(entry)
        return rows

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            email = str(item.get("_email") or "")
            display = str(item.get("displayName") or item.get("preferredUsername") or email)
            accounts = [str(a.get("url")) for a in item.get("accounts") or [] if a.get("url")]
            results.append(
                SearchResult(
                    id=f"gravatar:{index}:{email}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=email,
                    entity_type="email",
                    matched_entity=email,
                    title="Gravatar: " + display,
                    url=str(item.get("profileUrl") or ""),
                    snippet=("Linked accounts: " + ", ".join(accounts[:10])) if accounts else "Gravatar profile found",
                    raw_data=item,
                    normalized_data={"connector": "gravatar", "linked_accounts": accounts},
                    confidence_score=0.7,
                    tags=["profile", "email", "avatar"],
                    legal_notes="Public Gravatar profile data.",
                    explanation="Public Gravatar profile resolved from the email MD5 hash.",
                )
            )
        return results
