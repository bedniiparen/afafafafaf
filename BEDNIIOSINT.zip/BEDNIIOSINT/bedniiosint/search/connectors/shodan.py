from __future__ import annotations

from typing import Any

from ...config import settings
from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class ShodanConnector(BaseConnector):
    source_id = "shodan"
    source_name = "Shodan"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "ip",
            "domain",
            "host",
        }

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        if not settings.shodan_api_key:
            return {
                "status": "missing_keys",
                "missing_env": ["SHODAN_API_KEY"],
                "query_plan": query_plan.as_dict(),
                "items": [],
            }
        target = query_plan.entity_input
        if query_plan.entity_type in {"domain", "host"}:
            url = "https://api.shodan.io/dns/domain/" + target
        else:
            url = "https://api.shodan.io/shodan/host/" + target
        response = request("GET", url, params={"key": settings.shodan_api_key})
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "data": response.json() if response.content else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        plan = raw_response.get("query_plan") or {}
        if not isinstance(data, dict):
            return []
        if "data" in data and isinstance(data.get("data"), list):
            ports = [str(row.get("port")) for row in data["data"] if row.get("port")]
            return [{**data, "open_ports": ports, "target": plan.get("entity_input")}]
        if "subdomains" in data:
            subs = [f"{item}.{data.get('domain')}" for item in data.get("subdomains") or []]
            return [{**data, "subdomains_full": subs, "target": plan.get("entity_input")}]
        return [{**data, "target": plan.get("entity_input")}]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            target = str(item.get("target") or item.get("ip_str") or item.get("domain") or "")
            ports = item.get("open_ports") or []
            subdomains = item.get("subdomains_full") or []
            title = "Shodan exposure for " + target
            snippet_bits = []
            if ports:
                snippet_bits.append("open ports: " + ", ".join(map(str, ports[:12])))
            if subdomains:
                snippet_bits.append("subdomains: " + ", ".join(map(str, subdomains[:8])))
            results.append(
                SearchResult(
                    id=f"shodan:{index}:{target}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=target,
                    entity_type="ip" if item.get("ip_str") else "domain",
                    matched_entity=target,
                    title=title,
                    url="https://www.shodan.io/host/" + target if item.get("ip_str") else "",
                    snippet="; ".join(snippet_bits) or title,
                    raw_data=item,
                    normalized_data={"connector": "shodan", "open_ports": ports, "subdomains": subdomains},
                    confidence_score=0.72,
                    tags=["attack_surface", "passive_lookup"],
                    legal_notes="Passive keyed lookup through Shodan API; respect provider terms.",
                    explanation="Shodan returned passive internet exposure metadata for the target.",
                )
            )
        return results
