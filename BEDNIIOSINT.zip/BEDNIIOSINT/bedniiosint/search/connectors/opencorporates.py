from __future__ import annotations

from typing import Any

from ...config import settings
from ...core.http import async_request, request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class OpenCorporatesConnector(BaseConnector):
    source_id = "opencorporates"
    source_name = "OpenCorporates"
    supports_async = True

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "company",
            "domain",
            "query",
        }

    def _params(self, query_plan: QueryPlan) -> dict[str, str]:
        params = {"q": query_plan.entity_input}
        token = str(
            self.source.get("api_key")
            or self.source.get("api_token")
            or settings.opencorporates_api_token
            or ""
        )
        if token:
            params["api_token"] = token
        return params

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = request(
            "GET",
            "https://api.opencorporates.com/v0.4/companies/search",
            params=self._params(query_plan),
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        items = data.get("results", {}).get("companies", []) if isinstance(data, dict) else []
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "items": items,
        }

    async def arun(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = await async_request(
            "GET",
            "https://api.opencorporates.com/v0.4/companies/search",
            params=self._params(query_plan),
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        items = data.get("results", {}).get("companies", []) if isinstance(data, dict) else []
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "items": items,
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        return list(raw_response.get("items") or [])

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        out: list[SearchResult] = []
        for index, item in enumerate(parsed):
            company = item.get("company") if isinstance(item, dict) else {}
            if not isinstance(company, dict):
                company = {}
            name = str(company.get("name") or "")
            number = str(company.get("company_number") or "")
            jurisdiction = str(company.get("jurisdiction_code") or "")
            if not name:
                continue
            out.append(
                SearchResult(
                    id=f"{self.source_id}:{index}:{number or name}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=name,
                    entity_type="company",
                    matched_entity=name,
                    matched_variant=name,
                    title=name,
                    url=str(company.get("opencorporates_url") or ""),
                    snippet=" | ".join(item for item in (jurisdiction, number) if item),
                    raw_data=item,
                    normalized_data={
                        "connector": self.source_id,
                        "jurisdiction_code": jurisdiction,
                        "company_number": number,
                    },
                    confidence_score=0.68,
                    tags=["company", "registry", "business"],
                    legal_notes="Public business registry match; verify jurisdiction and legal name.",
                    explanation="OpenCorporates returned a public company registry candidate.",
                )
            )
        return out
