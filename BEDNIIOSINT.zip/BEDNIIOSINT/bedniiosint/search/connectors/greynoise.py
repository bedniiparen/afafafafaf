from __future__ import annotations

from typing import Any

from ...config import settings
from ...core.http import async_request, request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class GreyNoiseConnector(BaseConnector):
    """GreyNoise Community IP reputation lookup."""

    source_id = "greynoise"
    source_name = "GreyNoise Community"
    supports_async = True

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "ip"

    def _headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        key = getattr(settings, "greynoise_api_key", "") or ""
        if key:
            headers["key"] = key
        return headers

    def _url(self, query_plan: QueryPlan) -> str:
        return "https://api.greynoise.io/v3/community/" + query_plan.entity_input

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = request("GET", self._url(query_plan), headers=self._headers())
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "data": data if isinstance(data, dict) else {},
        }

    async def arun(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = await async_request("GET", self._url(query_plan), headers=self._headers())
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        data = raw_response.get("data") or {}
        if not isinstance(data, dict) or not data.get("ip"):
            return []
        return [data]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            ip = str(item.get("ip") or "")
            if not ip:
                continue
            classification = str(item.get("classification") or "unknown")
            noise = bool(item.get("noise"))
            riot = bool(item.get("riot"))
            actor = str(item.get("name") or "")
            risk_flags = []
            if classification == "malicious":
                risk_flags.append("malicious")
            if noise:
                risk_flags.append("background_noise")
            snippet_bits = [
                f"classification: {classification}",
                "noise: " + ("yes" if noise else "no"),
                "riot: " + ("yes" if riot else "no"),
                f"actor: {actor}" if actor else "",
            ]
            results.append(
                SearchResult(
                    id=f"greynoise:{index}:{ip}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=ip,
                    entity_type="ip",
                    matched_entity=ip,
                    title=f"GreyNoise: {ip} ({classification})",
                    url=str(item.get("link") or f"https://viz.greynoise.io/ip/{ip}"),
                    snippet="; ".join(bit for bit in snippet_bits if bit),
                    raw_data=item,
                    normalized_data={"connector": "greynoise", "classification": classification},
                    detected_platform="greynoise",
                    last_seen=str(item.get("last_seen") or "") or None,
                    confidence_score=0.85 if classification != "unknown" else 0.5,
                    risk_flags=risk_flags,
                    tags=["infrastructure", "threat-intel", "ip"],
                    legal_notes="Public GreyNoise community classification.",
                    explanation="GreyNoise community reputation for the supplied IP address.",
                )
            )
        return results
