from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

from ..models import SearchResult


@dataclass
class QueryPlan:
    source_id: str
    source_name: str
    entity_input: str
    entity_type: str
    queries: list[str]
    scope: str = "public_osint"
    variants: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class BaseConnector:
    source_id = "base"
    source_name = "Base Connector"

    def __init__(self, source: dict[str, Any] | None = None) -> None:
        self.source = source or {}
        self.source_id = str(self.source.get("id") or self.source_id)
        self.source_name = str(self.source.get("name") or self.source_name)

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return bool(entity.get("value") and entity.get("type"))

    def build_queries(
        self,
        entity: dict[str, Any],
        scope: str | None = None,
        variants: list[str] | None = None,
    ) -> QueryPlan:
        if not self.validate_input(entity):
            raise ValueError("entity must contain non-empty type and value")
        entity_type = str(entity["type"]).strip().lower()
        entity_input = str(entity["value"]).strip()
        query_variants = [item for item in (variants or []) if item] or [entity_input]
        selected_scope = scope or "public_osint"
        return QueryPlan(
            source_id=self.source_id,
            source_name=self.source_name,
            entity_input=entity_input,
            entity_type=entity_type,
            queries=query_variants,
            scope=selected_scope,
            variants=query_variants,
            metadata={
                "source": self.source,
                "variant_details": [
                    {"value": variant, "kind": "provided" if variant != entity_input else "canonical"}
                    for variant in query_variants
                ],
            },
        )

    def run(self, query_plan: QueryPlan) -> Any:
        raise NotImplementedError

    def parse(self, raw_response: Any) -> Any:
        raise NotImplementedError

    def normalize(self, parsed: Any) -> list[SearchResult]:
        raise NotImplementedError

    def score(self, normalized: list[SearchResult]) -> list[SearchResult]:
        return normalized

    def explain(self, normalized: list[SearchResult]) -> list[SearchResult]:
        return normalized

    supports_async: bool = False

    async def arun(self, query_plan: QueryPlan) -> Any:
        """Native-async fetch hook.

        Sync connectors inherit this default, which offloads the blocking
        ``run`` to a worker thread. Connectors that implement real async I/O
        should set ``supports_async = True`` and override this method using
        ``core.http.async_request``.
        """
        import asyncio

        return await asyncio.to_thread(self.run, query_plan)


class DummyConnector(BaseConnector):
    source_id = "dummy"
    source_name = "Dummy Connector"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        return {
            "query_plan": query_plan.as_dict(),
            "status": "ok",
            "items": [
                {
                    "title": f"Dummy result for {query_plan.entity_input}",
                    "url": f"https://example.test/search?q={query_plan.entity_input}",
                    "snippet": f"{query_plan.entity_type} matched by dummy connector",
                    "matched_entity": query_plan.entity_input,
                }
            ],
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        return list(raw_response.get("items") or [])

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            matched = str(item.get("matched_entity") or "")
            results.append(
                SearchResult(
                    id=f"{self.source_id}:{index}:{matched}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=matched,
                    entity_type="unknown",
                    matched_entity=matched,
                    matched_variant=matched,
                    title=str(item.get("title") or ""),
                    url=str(item.get("url") or ""),
                    snippet=str(item.get("snippet") or ""),
                    raw_data=item,
                    normalized_data={"connector": "dummy"},
                    found_at=datetime.now(timezone.utc).isoformat(),
                    tags=["dummy", "test"],
                    confidence_score=0.5,
                    context_match_score=1.0,
                    explanation="DummyConnector returns deterministic offline SearchResult objects for tests.",
                )
            )
        return results
