from __future__ import annotations

from typing import Any

from ...config import settings
from ...core.http import async_request, request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class GithubUserConnector(BaseConnector):
    """GitHub public profile lookup by username (keyless; token raises limits)."""

    source_id = "github_user"
    source_name = "GitHub Profile"
    supports_async = True

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "username",
            "email",
        }

    def _headers(self) -> dict[str, str]:
        headers = {"Accept": "application/vnd.github+json"}
        token = getattr(settings, "github_token", "") or ""
        if token:
            headers["Authorization"] = "Bearer " + token
        return headers

    def _request_args(self, query_plan: QueryPlan) -> tuple[str, dict[str, str], dict[str, str]]:
        headers = self._headers()
        if query_plan.entity_type == "email":
            return (
                "https://api.github.com/search/users",
                headers,
                {"q": query_plan.entity_input + " in:email"},
            )
        return ("https://api.github.com/users/" + query_plan.entity_input, headers, {})

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        url, headers, params = self._request_args(query_plan)
        response = request("GET", url, params=params or None, headers=headers)
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "data": data,
        }

    async def arun(self, query_plan: QueryPlan) -> dict[str, Any]:
        url, headers, params = self._request_args(query_plan)
        response = await async_request("GET", url, params=params or None, headers=headers)
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "data": data,
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        if isinstance(data, dict) and "items" in data:
            return list(data.get("items") or [])
        return [data] if data else []

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            login = str(item.get("login") or "")
            if not login:
                continue
            bio = str(item.get("bio") or "")
            snippet_bits = [
                bio,
                ("repos: " + str(item.get("public_repos"))) if item.get("public_repos") is not None else "",
                ("followers: " + str(item.get("followers"))) if item.get("followers") is not None else "",
                ("company: " + str(item.get("company"))) if item.get("company") else "",
                ("location: " + str(item.get("location"))) if item.get("location") else "",
            ]
            results.append(
                SearchResult(
                    id=f"github_user:{index}:{login}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=login,
                    entity_type="username",
                    matched_entity=login,
                    title="GitHub: " + login,
                    url=str(item.get("html_url") or ("https://github.com/" + login)),
                    snippet="; ".join(b for b in snippet_bits if b) or ("GitHub profile " + login),
                    raw_data=item,
                    normalized_data={"connector": "github_user", "login": login},
                    detected_platform="github",
                    confidence_score=0.8,
                    tags=["profile", "developer", "username"],
                    legal_notes="Public GitHub profile data.",
                    explanation="Public GitHub profile resolved for the supplied identifier.",
                )
            )
        return results
