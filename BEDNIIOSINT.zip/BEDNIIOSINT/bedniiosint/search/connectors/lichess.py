from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class LichessConnector(BaseConnector):
    """Lichess public user lookup (keyless)."""

    source_id = "lichess"
    source_name = "Lichess"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "username"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        user = query_plan.entity_input
        response = request("GET", "https://lichess.org/api/user/" + user)
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        return [data] if data.get("id") else []

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            user = str(item.get("username") or item.get("id") or "")
            profile = item.get("profile") or {}
            bio = str(profile.get("bio") or "")
            results.append(
                SearchResult(
                    id=f"lichess:{index}:{user}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=user,
                    entity_type="username",
                    matched_entity=user,
                    title="Lichess: " + user,
                    url=str(item.get("url") or ("https://lichess.org/@/" + user)),
                    snippet=bio or ("games played; created: " + str(item.get("createdAt") or "")),
                    raw_data=item,
                    normalized_data={"connector": "lichess"},
                    detected_platform="lichess",
                    confidence_score=0.7,
                    tags=["profile", "gaming", "username"],
                    legal_notes="Public Lichess profile data.",
                    explanation="Public Lichess account resolved by username.",
                )
            )
        return results
