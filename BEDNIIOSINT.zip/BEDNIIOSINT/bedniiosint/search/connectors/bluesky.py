from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class BlueskyConnector(BaseConnector):
    """Bluesky public profile lookup (keyless public AppView API)."""

    source_id = "bluesky"
    source_name = "Bluesky"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "username"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        actor = query_plan.entity_input
        if "." not in actor:
            actor = actor + ".bsky.social"
        response = request(
            "GET",
            "https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile",
            params={"actor": actor},
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        return [data] if data.get("handle") else []

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            handle = str(item.get("handle") or "")
            results.append(
                SearchResult(
                    id=f"bluesky:{index}:{handle}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=handle,
                    entity_type="username",
                    matched_entity=handle,
                    title="Bluesky: " + str(item.get("displayName") or handle),
                    url="https://bsky.app/profile/" + handle,
                    snippet=str(item.get("description") or "")
                    + " followers: " + str(item.get("followersCount") or 0),
                    raw_data=item,
                    normalized_data={"connector": "bluesky", "did": item.get("did")},
                    detected_platform="bluesky",
                    confidence_score=0.75,
                    tags=["profile", "social", "username"],
                    legal_notes="Public Bluesky profile data.",
                    explanation="Public Bluesky profile resolved via the AppView API.",
                )
            )
        return results
