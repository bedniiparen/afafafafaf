from __future__ import annotations

import base64
from typing import Any

from ...config import settings
from ...core.http import async_request, request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class VirusTotalConnector(BaseConnector):
    """VirusTotal v3 reputation lookup for domains, IPs and URLs."""

    source_id = "virustotal"
    source_name = "VirusTotal"
    supports_async = True

    _PATH = {"domain": "domains", "ip": "ip_addresses", "url": "urls"}

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in self._PATH

    def _headers(self) -> dict[str, str]:
        return {
            "Accept": "application/json",
            "x-apikey": getattr(settings, "virustotal_api_key", "") or "",
        }

    def _indicator_id(self, query_plan: QueryPlan) -> str:
        if query_plan.entity_type != "url":
            return query_plan.entity_input
        encoded = base64.urlsafe_b64encode(query_plan.entity_input.encode("utf-8")).decode("ascii")
        return encoded.rstrip("=")

    def _url(self, query_plan: QueryPlan) -> str:
        path = self._PATH.get(query_plan.entity_type, "domains")
        return f"https://www.virustotal.com/api/v3/{path}/{self._indicator_id(query_plan)}"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        if not getattr(settings, "virustotal_api_key", ""):
            return {
                "status": "missing_keys",
                "missing_env": ["VIRUSTOTAL_API_KEY"],
                "query_plan": query_plan.as_dict(),
                "items": [],
            }
        response = request("GET", self._url(query_plan), headers=self._headers())
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "entity_type": query_plan.entity_type,
            "indicator": query_plan.entity_input,
            "data": data if isinstance(data, dict) else {},
        }

    async def arun(self, query_plan: QueryPlan) -> dict[str, Any]:
        if not getattr(settings, "virustotal_api_key", ""):
            return {
                "status": "missing_keys",
                "missing_env": ["VIRUSTOTAL_API_KEY"],
                "query_plan": query_plan.as_dict(),
                "items": [],
            }
        response = await async_request("GET", self._url(query_plan), headers=self._headers())
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "entity_type": query_plan.entity_type,
            "indicator": query_plan.entity_input,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = (raw_response.get("data") or {}).get("data") or {}
        if not isinstance(data, dict) or not data.get("id"):
            return []
        item = dict(data)
        item["_entity_type"] = raw_response.get("entity_type") or "domain"
        item["_indicator"] = raw_response.get("indicator") or item.get("id")
        return [item]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            indicator = str(item.get("_indicator") or item.get("id") or "")
            if not indicator:
                continue
            entity_type = str(item.get("_entity_type") or "domain")
            attrs = item.get("attributes") if isinstance(item.get("attributes"), dict) else {}
            stats = attrs.get("last_analysis_stats") if isinstance(attrs.get("last_analysis_stats"), dict) else {}
            malicious = int(stats.get("malicious") or 0)
            suspicious = int(stats.get("suspicious") or 0)
            reputation = attrs.get("reputation")
            risk_flags = []
            if malicious > 0:
                risk_flags.append("vt_malicious")
            if suspicious > 0:
                risk_flags.append("vt_suspicious")
            snippet_bits = [
                f"malicious: {malicious}",
                f"suspicious: {suspicious}",
                f"reputation: {reputation}" if reputation is not None else "",
            ]
            kind = "ip-address" if entity_type == "ip" else entity_type
            results.append(
                SearchResult(
                    id=f"virustotal:{index}:{indicator}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=indicator,
                    entity_type=entity_type,
                    matched_entity=indicator,
                    title="VirusTotal: " + indicator,
                    url=f"https://www.virustotal.com/gui/{kind}/{indicator}",
                    snippet="; ".join(bit for bit in snippet_bits if bit),
                    raw_data=item,
                    normalized_data={"connector": "virustotal", "malicious": malicious},
                    detected_platform="virustotal",
                    confidence_score=0.9 if malicious or suspicious else 0.6,
                    risk_flags=risk_flags,
                    tags=["infrastructure", "threat-intel", entity_type],
                    legal_notes="VirusTotal v3 reputation data.",
                    explanation="Reputation and detection stats from VirusTotal for the indicator.",
                )
            )
        return results
