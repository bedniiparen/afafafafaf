from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ...config import settings
from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class HIBPConnector(BaseConnector):
    source_id = "hibp"
    source_name = "Have I Been Pwned"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "email"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        if not settings.hibp_api_key:
            return {
                "status": "missing_keys",
                "missing_env": ["HIBP_API_KEY"],
                "query_plan": query_plan.as_dict(),
                "items": [],
            }
        email = query_plan.entity_input
        url = "https://haveibeenpwned.com/api/v3/breachedaccount/" + quote(email, safe="")
        response = request(
            "GET",
            url,
            headers={"hibp-api-key": settings.hibp_api_key, "User-Agent": settings.user_agent},
            params={"truncateResponse": "false"},
        )
        if response.status_code == 404:
            data: list[dict[str, Any]] = []
            status = "ok"
        else:
            data = response.json() if response.content else []
            status = "ok" if response.status_code < 400 else "error"
        return {
            "status": status,
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "data": data,
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        plan = raw_response.get("query_plan") or {}
        email = str(plan.get("entity_input") or "")
        rows = raw_response.get("data") or []
        if not isinstance(rows, list):
            return []
        return [{**dict(row), "email": email} for row in rows if isinstance(row, dict)]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            email = str(item.get("email") or "")
            breach = str(item.get("Name") or item.get("Title") or "breach")
            results.append(
                SearchResult(
                    id=f"hibp:{index}:{email}:{breach}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=email,
                    entity_type="email",
                    matched_entity=email,
                    title="HIBP breach exposure: " + breach,
                    url=(("https://" + str(item.get("Domain"))) if item.get("Domain") else ""),
                    snippet=str(item.get("Description") or "Email appears in a public HIBP breach record."),
                    raw_data=item,
                    normalized_data={"connector": "hibp", "breach": breach, "review_only": True},
                    confidence_score=0.78,
                    tags=["breach_exposure", "review_only"],
                    risk_flags=["sensitive_data", "manual_verification_required"],
                    legal_notes="Legal breach exposure lookup through HIBP only; do not import raw leaked data.",
                    explanation="HIBP indicates breach exposure; analyst review is required before acting on it.",
                )
            )
        return results
