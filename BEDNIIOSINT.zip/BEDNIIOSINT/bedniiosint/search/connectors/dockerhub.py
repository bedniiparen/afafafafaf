from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class DockerHubConnector(BaseConnector):
    """Docker Hub public user lookup (keyless)."""

    source_id = "dockerhub"
    source_name = "Docker Hub"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "username"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        user = query_plan.entity_input
        response = request("GET", "https://hub.docker.com/v2/users/" + user + "/")
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        return [data] if (data.get("username") or data.get("id")) else []

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            user = str(item.get("username") or "")
            results.append(
                SearchResult(
                    id=f"dockerhub:{index}:{user}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=user,
                    entity_type="username",
                    matched_entity=user,
                    title="Docker Hub: " + user,
                    url="https://hub.docker.com/u/" + user,
                    snippet=str(item.get("full_name") or "") + " joined: " + str(item.get("date_joined") or ""),
                    raw_data=item,
                    normalized_data={"connector": "dockerhub"},
                    detected_platform="dockerhub",
                    confidence_score=0.7,
                    tags=["profile", "developer", "username"],
                    legal_notes="Public Docker Hub profile data.",
                    explanation="Public Docker Hub account resolved by username.",
                )
            )
        return results
