from __future__ import annotations

from typing import Any

from ...config import settings
from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class HunterConnector(BaseConnector):
    source_id = "hunter"
    source_name = "Hunter.io"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "domain",
            "email",
            "company",
        }

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        if not settings.hunter_api_key:
            return {
                "status": "missing_keys",
                "missing_env": ["HUNTER_API_KEY"],
                "query_plan": query_plan.as_dict(),
                "items": [],
            }
        target = query_plan.entity_input
        if query_plan.entity_type == "email":
            url = "https://api.hunter.io/v2/email-verifier"
            params = {"email": target, "api_key": settings.hunter_api_key}
        else:
            url = "https://api.hunter.io/v2/domain-search"
            params = {"domain": target, "api_key": settings.hunter_api_key}
        response = request("GET", url, params=params)
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "query_plan": query_plan.as_dict(),
            "data": response.json() if response.content else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        plan = raw_response.get("query_plan") or {}
        if not isinstance(data, dict):
            return []
        body = data.get("data") if isinstance(data.get("data"), dict) else data
        if "emails" in body and isinstance(body.get("emails"), list):
            return [
                {**dict(row), "target": plan.get("entity_input"), "mode": "domain-search"}
                for row in body.get("emails") or []
                if isinstance(row, dict)
            ]
        return [{**body, "target": plan.get("entity_input"), "mode": "email-verifier"}]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            target = str(item.get("target") or "")
            email = str(item.get("value") or item.get("email") or target)
            confidence = float(item.get("confidence") or item.get("score") or 60.0) / 100.0
            results.append(
                SearchResult(
                    id=f"hunter:{index}:{email}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=target,
                    entity_type="email",
                    matched_entity=email,
                    title="Hunter contact lead: " + email,
                    url="",
                    snippet=str(item.get("position") or item.get("result") or "Hunter contact enrichment."),
                    raw_data=item,
                    normalized_data={"connector": "hunter", "mode": item.get("mode")},
                    confidence_score=max(0.0, min(1.0, confidence)),
                    tags=["email", "contact_enrichment", "lead"],
                    risk_flags=["manual_verification_required"],
                    legal_notes="Keyed public contact enrichment; verify context and provider terms.",
                    explanation="Hunter returned a public contact or email verification lead.",
                )
            )
        return results
