from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class GitlabConnector(BaseConnector):
    """GitLab public user lookup by username (keyless)."""

    source_id = "gitlab"
    source_name = "GitLab"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "username"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = request(
            "GET",
            "https://gitlab.com/api/v4/users",
            params={"username": query_plan.entity_input},
        )
        try:
            data = response.json() if response.content else []
        except Exception:
            data = []
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "data": data if isinstance(data, list) else [],
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        return list(raw_response.get("data") or [])

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            username = str(item.get("username") or "")
            results.append(
                SearchResult(
                    id=f"gitlab:{index}:{username}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=username,
                    entity_type="username",
                    matched_entity=username,
                    title="GitLab: " + str(item.get("name") or username),
                    url=str(item.get("web_url") or ("https://gitlab.com/" + username)),
                    snippet=str(item.get("bio") or "GitLab public profile"),
                    raw_data=item,
                    normalized_data={"connector": "gitlab", "username": username},
                    detected_platform="gitlab",
                    confidence_score=0.78,
                    tags=["profile", "developer", "username"],
                    legal_notes="Public GitLab profile data.",
                    explanation="Public GitLab profile resolved by username.",
                )
            )
        return results
