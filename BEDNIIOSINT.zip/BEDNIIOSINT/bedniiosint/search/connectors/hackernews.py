from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class HackerNewsConnector(BaseConnector):
    """Hacker News public user lookup (keyless Firebase API)."""

    source_id = "hackernews"
    source_name = "Hacker News"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "username"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        user = query_plan.entity_input
        response = request(
            "GET",
            "https://hacker-news.firebaseio.com/v0/user/" + user + ".json",
        )
        try:
            data = response.json() if response.content else None
        except Exception:
            data = None
        return {
            "status": "ok" if response.status_code < 400 and data else "error",
            "status_code": response.status_code,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        return [data] if data.get("id") else []

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            user = str(item.get("id") or "")
            results.append(
                SearchResult(
                    id=f"hackernews:{index}:{user}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=user,
                    entity_type="username",
                    matched_entity=user,
                    title="Hacker News: " + user,
                    url="https://news.ycombinator.com/user?id=" + user,
                    snippet="karma: " + str(item.get("karma") or 0) + "; created: " + str(item.get("created") or ""),
                    raw_data=item,
                    normalized_data={"connector": "hackernews", "karma": item.get("karma")},
                    detected_platform="hackernews",
                    confidence_score=0.72,
                    tags=["profile", "developer", "username"],
                    legal_notes="Public Hacker News profile data.",
                    explanation="Public Hacker News account resolved via the Firebase API.",
                )
            )
        return results
