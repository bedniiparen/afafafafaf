from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class RedditConnector(BaseConnector):
    """Reddit public user about.json (keyless)."""

    source_id = "reddit"
    source_name = "Reddit"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "username"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        user = query_plan.entity_input
        response = request(
            "GET",
            "https://www.reddit.com/user/" + user + "/about.json",
            headers={"User-Agent": "bedniiosint-osint/1.0"},
        )
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "user": user,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        payload = (raw_response.get("data") or {}).get("data") or {}
        if not payload:
            return []
        payload["_user"] = raw_response.get("user")
        return [payload]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            user = str(item.get("name") or item.get("_user") or "")
            karma = int(item.get("total_karma") or 0)
            results.append(
                SearchResult(
                    id=f"reddit:{index}:{user}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=user,
                    entity_type="username",
                    matched_entity=user,
                    title="Reddit: u/" + user,
                    url="https://www.reddit.com/user/" + user,
                    snippet="total karma: " + str(karma) + "; created utc: " + str(item.get("created_utc") or ""),
                    raw_data=item,
                    normalized_data={"connector": "reddit", "karma": karma},
                    detected_platform="reddit",
                    confidence_score=0.74,
                    tags=["profile", "social", "username"],
                    legal_notes="Public Reddit profile data.",
                    explanation="Public Reddit account resolved via about.json.",
                )
            )
        return results
