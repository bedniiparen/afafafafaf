from .base import BaseConnector, DummyConnector, QueryPlan
from .censys import CensysConnector
from .hibp import HIBPConnector
from .holehe import HoleheConnector
from .hunter import HunterConnector
from .shodan import ShodanConnector
from .securitytrails import SecurityTrailsConnector
from .virustotal import VirusTotalConnector

# --- keyless / free public sources (v3 expansion) ---
from .bluesky import BlueskyConnector
from .codeforces import CodeforcesConnector
from .crtsh import CrtShConnector
from .dockerhub import DockerHubConnector
from .github_user import GithubUserConnector
from .gitlab import GitlabConnector
from .gravatar import GravatarConnector
from .greynoise import GreyNoiseConnector
from .hackernews import HackerNewsConnector
from .hackertarget import HackerTargetConnector
from .ipwhois import IpWhoisConnector
from .lichess import LichessConnector
from .opencorporates import OpenCorporatesConnector
from .public_profile import EXTRA_PROFILE_CONNECTORS, TelegramConnector, YouTubeConnector, VkConnector
from .rdap import RdapConnector
from .reddit import RedditConnector
from .urlscan import UrlscanConnector
from .wayback import WaybackConnector
from .wikidata import WikidataConnector
from .wmn import WmnConnector

CONNECTOR_CLASSES = {
    connector.source_id: connector
    for connector in (
        # keyed providers
        ShodanConnector,
        CensysConnector,
        HIBPConnector,
        HunterConnector,
        HoleheConnector,
        SecurityTrailsConnector,
        VirusTotalConnector,
        UrlscanConnector,
        GreyNoiseConnector,
        # keyless / free providers
        CrtShConnector,
        WaybackConnector,
        RdapConnector,
        HackerTargetConnector,
        GithubUserConnector,
        GitlabConnector,
        GravatarConnector,
        RedditConnector,
        HackerNewsConnector,
        WikidataConnector,
        BlueskyConnector,
        LichessConnector,
        CodeforcesConnector,
        IpWhoisConnector,
        DockerHubConnector,
        OpenCorporatesConnector,
        WmnConnector,
        TelegramConnector,
        YouTubeConnector,
        VkConnector,
    )
}

for _profile_cls in EXTRA_PROFILE_CONNECTORS:
    CONNECTOR_CLASSES.setdefault(_profile_cls.source_id, _profile_cls)

__all__ = [
    "BaseConnector",
    "DummyConnector",
    "QueryPlan",
    "CONNECTOR_CLASSES",
    "ShodanConnector",
    "CensysConnector",
    "HIBPConnector",
    "HunterConnector",
    "HoleheConnector",
    "SecurityTrailsConnector",
    "VirusTotalConnector",
    "UrlscanConnector",
    "GreyNoiseConnector",
    "CrtShConnector",
    "WaybackConnector",
    "RdapConnector",
    "HackerTargetConnector",
    "GithubUserConnector",
    "GitlabConnector",
    "GravatarConnector",
    "RedditConnector",
    "HackerNewsConnector",
    "WikidataConnector",
    "BlueskyConnector",
    "LichessConnector",
    "CodeforcesConnector",
    "IpWhoisConnector",
    "DockerHubConnector",
    "OpenCorporatesConnector",
    "WmnConnector",
    "EXTRA_PROFILE_CONNECTORS",
    "TelegramConnector",
    "YouTubeConnector",
    "VkConnector",
]
