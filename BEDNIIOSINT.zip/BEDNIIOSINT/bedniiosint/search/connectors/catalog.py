from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from ...catalog import run_source
from ...catalog.adapters import AdapterResult
from ...config import settings
from ...core.normalizer import normalize_adapter_result
from ...core.source_context import SourceRunContext
from ..models import SearchResult
from ..pipeline import SEARCH_TO_CATALOG_SOURCE_IDS
from ..presence import apply_presence_filter
from ..results import search_result_from_normalized_record
from ..scoring import score_search_results
from .base import BaseConnector, QueryPlan


RunSourceFunc = Callable[..., AdapterResult]


class CatalogConnector(BaseConnector):
    source_id = "catalog"
    source_name = "Catalog Connector"

    def __init__(
        self,
        source: dict[str, Any] | None = None,
        *,
        catalog_source_ids: list[str] | None = None,
        plugin_dir: Path | None = None,
        context: SourceRunContext | None = None,
        runner: RunSourceFunc | None = None,
    ) -> None:
        super().__init__(source)
        self.catalog_source_ids = catalog_source_ids or SEARCH_TO_CATALOG_SOURCE_IDS.get(
            self.source_id,
            [],
        )
        self.plugin_dir = plugin_dir
        self.context = context
        self.runner = runner or run_source

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and bool(self.catalog_source_ids)

    def run(self, query_plan: QueryPlan) -> list[AdapterResult]:
        if not self.catalog_source_ids:
            raise ValueError(f"no catalog adapter mapping for search source: {self.source_id}")
        results: list[AdapterResult] = []
        for catalog_source_id in self.catalog_source_ids:
            results.append(
                self.runner(
                    catalog_source_id,
                    query_plan.entity_input,
                    plugin_dir=self.plugin_dir,
                    input_type=query_plan.entity_type,
                    context=self.context,
                )
            )
        return results

    def parse(self, raw_response: list[AdapterResult | dict[str, Any]]) -> list[dict[str, Any]]:
        parsed: list[dict[str, Any]] = []
        for row in raw_response:
            parsed.append(row.as_dict() if hasattr(row, "as_dict") else dict(row))
        return parsed

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        legal_notes = "; ".join(
            item
            for item in (
                str(self.source.get("legal_status") or ""),
                str(self.source.get("tos_notes") or ""),
            )
            if item
        )
        for row in parsed:
            record = normalize_adapter_result(row).as_dict()
            result = search_result_from_normalized_record(record, source=self.source)
            result.source_name = str(row.get("source_id") or self.source_name)
            if legal_notes:
                result.legal_notes = legal_notes
            result.tags = [*result.tags, "catalog_connector", self.source_id]
            result.explanation = (
                f"CatalogConnector mapped search source {self.source_id} to "
                f"{row.get('source_id')}. {result.explanation}"
            )
            results.append(result)
        return results

    def score(self, normalized: list[SearchResult]) -> list[SearchResult]:
        scored = score_search_results(normalized)
        if not settings.presence_filter_enabled:
            return scored
        return apply_presence_filter(scored, drop_absent=settings.presence_drop_absent)

    def explain(self, normalized: list[SearchResult]) -> list[SearchResult]:
        mapped = ", ".join(self.catalog_source_ids)
        for result in normalized:
            result.explanation = (
                f"{result.explanation} Catalog adapter mapping: {self.source_id} -> {mapped}."
            )
        return normalized
