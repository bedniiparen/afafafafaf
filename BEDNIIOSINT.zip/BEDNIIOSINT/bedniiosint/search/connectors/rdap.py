from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class RdapConnector(BaseConnector):
    """RDAP (rdap.org) -> registration data for domains and IPs (keyless)."""

    source_id = "rdap"
    source_name = "RDAP"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() in {
            "domain",
            "host",
            "ip",
        }

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        target = query_plan.entity_input
        kind = "ip" if query_plan.entity_type == "ip" else "domain"
        response = request("GET", "https://rdap.org/" + kind + "/" + target)
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        return {
            "status": "ok" if response.status_code < 400 else "error",
            "status_code": response.status_code,
            "target": target,
            "kind": kind,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        events = {e.get("eventAction"): e.get("eventDate") for e in data.get("events") or []}
        entities = []
        for ent in data.get("entities") or []:
            roles = ", ".join(ent.get("roles") or [])
            entities.append(str(ent.get("handle", "")) + " (" + roles + ")")
        return [
            {
                "target": raw_response.get("target"),
                "handle": data.get("handle") or data.get("ldhName"),
                "name": data.get("name"),
                "status": ", ".join(data.get("status") or []),
                "registration": events.get("registration"),
                "expiration": events.get("expiration"),
                "entities": "; ".join(entities),
            }
        ]

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            target = str(item.get("target") or "")
            snippet_bits = [
                ("status: " + str(item.get("status"))) if item.get("status") else "",
                ("registered: " + str(item.get("registration"))) if item.get("registration") else "",
                ("entities: " + str(item.get("entities"))) if item.get("entities") else "",
            ]
            results.append(
                SearchResult(
                    id=f"rdap:{index}:{target}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=target,
                    entity_type="domain",
                    matched_entity=target,
                    title="RDAP registration: " + target,
                    url="https://rdap.org/domain/" + target,
                    snippet="; ".join(b for b in snippet_bits if b) or "RDAP record",
                    raw_data=item,
                    normalized_data={"connector": "rdap", **item},
                    confidence_score=0.78,
                    tags=["whois", "registration", "rdap"],
                    legal_notes="Public RDAP registration metadata.",
                    explanation="Registration data retrieved via the RDAP bootstrap service.",
                )
            )
        return results
