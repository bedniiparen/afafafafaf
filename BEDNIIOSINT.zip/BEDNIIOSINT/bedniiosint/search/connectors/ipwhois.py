from __future__ import annotations

from typing import Any

from ...core.http import request
from ..models import SearchResult
from .base import BaseConnector, QueryPlan


class IpWhoisConnector(BaseConnector):
    """ipwho.is geolocation/ASN lookup for IP addresses (keyless)."""

    source_id = "ipwhois"
    source_name = "ipwho.is"

    def validate_input(self, entity: dict[str, Any]) -> bool:
        return super().validate_input(entity) and str(entity.get("type") or "").lower() == "ip"

    def run(self, query_plan: QueryPlan) -> dict[str, Any]:
        response = request("GET", "https://ipwho.is/" + query_plan.entity_input)
        try:
            data = response.json() if response.content else {}
        except Exception:
            data = {}
        ok = response.status_code < 400 and bool(data.get("success", True))
        return {
            "status": "ok" if ok else "error",
            "status_code": response.status_code,
            "data": data if isinstance(data, dict) else {},
        }

    def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
        if raw_response.get("status") != "ok":
            return []
        data = raw_response.get("data") or {}
        return [data] if data.get("ip") else []

    def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
        results: list[SearchResult] = []
        for index, item in enumerate(parsed):
            ip = str(item.get("ip") or "")
            conn = item.get("connection") or {}
            loc = ", ".join(
                str(item.get(k) or "") for k in ("city", "region", "country") if item.get(k)
            )
            asn = str(conn.get("asn") or "") + " " + str(conn.get("org") or conn.get("isp") or "")
            results.append(
                SearchResult(
                    id=f"ipwhois:{index}:{ip}",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=ip,
                    entity_type="ip",
                    matched_entity=ip,
                    title="IP geolocation: " + ip,
                    url="https://ipwho.is/" + ip,
                    snippet=(loc + "; AS" + asn).strip("; "),
                    raw_data=item,
                    normalized_data={"connector": "ipwhois", "asn": conn.get("asn")},
                    confidence_score=0.7,
                    tags=["geolocation", "network", "ip"],
                    legal_notes="Public IP geolocation data.",
                    explanation="IP geolocation and ASN resolved via ipwho.is.",
                )
            )
        return results
