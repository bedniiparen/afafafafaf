from __future__ import annotations

"""Self-contained interactive HTML report with graph and timeline."""

import json
from pathlib import Path
from typing import Any, Iterable

from .graphml_export import _as_dict, _rid, build_graph


def _timeline(results: Iterable[Any]) -> list[dict[str, Any]]:
    events = []
    for index, raw in enumerate(results):
        result = _as_dict(raw)
        if not result:
            continue
        when = str(result.get("first_seen") or result.get("found_at") or "")
        events.append(
            {
                "id": _rid(result, index),
                "when": when,
                "label": str(result.get("title") or result.get("matched_entity") or ""),
                "source": str(result.get("source_id") or result.get("source_name") or ""),
                "url": str(result.get("url") or ""),
            }
        )
    events.sort(key=lambda event: event["when"] or "~")
    return events


_TEMPLATE = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>__TITLE__</title>
<style>
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#0f1117;color:#e6e6e6}
header{padding:16px 20px;background:#171a23;border-bottom:1px solid #262b38}
h1{font-size:18px;margin:0}
.wrap{display:flex;flex-wrap:wrap}
#graph{flex:2;min-width:420px;height:600px}
#side{flex:1;min-width:280px;padding:16px;border-left:1px solid #262b38;max-height:600px;overflow:auto}
.node{cursor:pointer}.edge{stroke:#3a4256;stroke-width:1}.lbl{font-size:10px;fill:#9aa4b2}
.tl{margin:0;padding:0;list-style:none}.tl li{padding:8px 0;border-bottom:1px solid #20242f}
.src{color:#6ea8fe;font-size:11px}.tl a,#detail a{color:#8bd5a0;text-decoration:none;word-break:break-all}
.muted{color:#7b8494;font-size:12px}
</style></head>
<body>
<header><h1>__TITLE__</h1><div class="muted">__SUBTITLE__</div></header>
<div class="wrap">
<svg id="graph"></svg>
<div id="side"><div id="detail" class="muted">Click a node to inspect.</div>
<h3>Timeline</h3><ul id="timeline" class="tl"></ul></div>
</div>
<script id="data" type="application/json">__DATA__</script>
<script>
var DATA=JSON.parse(document.getElementById('data').textContent);
var svg=document.getElementById('graph');
function ns(t){return document.createElementNS('http://www.w3.org/2000/svg',t);}
function esc(s){return String(s||'').replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function layout(){
  var W=svg.clientWidth||600,H=svg.clientHeight||600,cx=W/2,cy=H/2,R=Math.min(W,H)/2-60;
  var n=DATA.nodes.length,pos={};
  DATA.nodes.forEach(function(nd,i){var a=2*Math.PI*i/Math.max(1,n);pos[nd.id]={x:cx+R*Math.cos(a),y:cy+R*Math.sin(a)};});
  DATA.edges.forEach(function(e){var a=pos[e.source],b=pos[e.target];if(!a||!b)return;var ln=ns('line');ln.setAttribute('class','edge');ln.setAttribute('x1',a.x);ln.setAttribute('y1',a.y);ln.setAttribute('x2',b.x);ln.setAttribute('y2',b.y);svg.appendChild(ln);});
  DATA.nodes.forEach(function(nd){var p=pos[nd.id];var c=ns('circle');c.setAttribute('class','node');c.setAttribute('cx',p.x);c.setAttribute('cy',p.y);c.setAttribute('r',6+8*(nd.confidence||0));c.setAttribute('fill',nd.source==='seed'?'#f0a13a':'#6ea8fe');c.addEventListener('click',function(){showDetail(nd);});svg.appendChild(c);var t=ns('text');t.setAttribute('class','lbl');t.setAttribute('x',p.x+9);t.setAttribute('y',p.y+3);t.textContent=(nd.label||nd.id).slice(0,28);svg.appendChild(t);});
}
function showDetail(nd){var d=document.getElementById('detail');var url=nd.url?('<div><a href="'+esc(nd.url)+'" target="_blank">'+esc(nd.url)+'</a></div>'):'';d.innerHTML='<b>'+esc(nd.label||nd.id)+'</b><div class="src">'+esc(nd.source||'')+' | '+esc(nd.ntype||'')+' | conf '+esc(nd.confidence||0)+'</div>'+url;}
function timeline(){var ul=document.getElementById('timeline');DATA.timeline.forEach(function(ev){var li=document.createElement('li');var link=ev.url?('<a href="'+esc(ev.url)+'" target="_blank">'+esc(ev.label||ev.url)+'</a>'):esc(ev.label||'');li.innerHTML='<div class="src">'+esc(ev.when||'n/a')+' | '+esc(ev.source||'')+'</div>'+link;ul.appendChild(li);});}
layout();timeline();
</script>
</body></html>"""


def _esc(value: str) -> str:
    return str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def render_html(
    results: Iterable[Any],
    links: Iterable[Any] | None = None,
    *,
    case_name: str = "OSINT investigation",
    seed: str | None = None,
    seed_type: str = "entity",
) -> str:
    rows = list(results)
    nodes, edges = build_graph(rows, links, seed=seed, seed_type=seed_type)
    payload = {"nodes": nodes, "edges": edges, "timeline": _timeline(rows)}
    data_json = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    html = _TEMPLATE.replace("__TITLE__", _esc(case_name))
    html = html.replace("__SUBTITLE__", _esc(f"{len(nodes)} nodes / {len(edges)} edges"))
    return html.replace("__DATA__", data_json)


def write_report(path: str | Path, results: Iterable[Any], links=None, **kwargs: Any) -> str:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_html(results, links, **kwargs), encoding="utf-8")
    return str(output)
