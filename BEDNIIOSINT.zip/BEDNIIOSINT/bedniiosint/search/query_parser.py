from __future__ import annotations

from dataclasses import asdict, dataclass, field
import shlex
from typing import Any


@dataclass
class ParsedSearchQuery:
    raw: str
    entity: str
    scope_path: str = ""
    boost_terms: list[str] = field(default_factory=list)
    exclude_terms: list[str] = field(default_factory=list)
    source_hints: list[str] = field(default_factory=list)
    filters: dict[str, str] = field(default_factory=dict)
    free_terms: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _tokens(value: str) -> list[str]:
    lexer = shlex.shlex(value, posix=True)
    lexer.whitespace_split = True
    lexer.commenters = ""
    return list(lexer)


def _append_unique(items: list[str], value: str) -> None:
    clean = value.strip()
    if clean and clean not in items:
        items.append(clean)


def _normalize_source_hint(value: str) -> str:
    clean = value.strip().lstrip("@").strip()
    if clean.startswith("api:"):
        clean = clean[4:]
    return clean.lower().replace("-", "_")


CONTROL_FILTER_KEYS = {
    "depth",
    "entity_type",
    "kind",
    "limit",
    "max",
    "max_results",
    "mode",
    "platform",
    "platforms",
    "size",
    "type",
}


def parse_search_query(value: str) -> ParsedSearchQuery:
    raw = str(value or "").strip()
    entity_tokens: list[str] = []
    scope_path = ""
    boost_terms: list[str] = []
    exclude_terms: list[str] = []
    source_hints: list[str] = []
    filters: dict[str, str] = {}
    free_terms: list[str] = []

    for token in _tokens(raw):
        if not token:
            continue
        if token.startswith("/") and len(token) > 1:
            scope_path = token.strip()
            continue
        if token.startswith("+") and len(token) > 1:
            _append_unique(boost_terms, token[1:])
            continue
        if token.startswith("-") and len(token) > 1:
            _append_unique(exclude_terms, token[1:])
            continue
        if token.startswith("@") and len(token) > 1:
            _append_unique(source_hints, _normalize_source_hint(token))
            continue
        if ":" in token and not token.lower().startswith(("http://", "https://")):
            key, item = token.split(":", 1)
            clean_key = key.strip().lower().replace("-", "_")
            clean_value = item.strip()
            if clean_key and clean_value:
                filters[clean_key] = clean_value
                if clean_key in {"source", "sources"}:
                    for source in clean_value.split(","):
                        _append_unique(source_hints, _normalize_source_hint(source))
                elif clean_key in {"scope", "route"} and not scope_path:
                    scope_path = clean_value if clean_value.startswith("/") else f"/{clean_value}"
                elif clean_key not in CONTROL_FILTER_KEYS:
                    _append_unique(free_terms, clean_value)
                continue
        entity_tokens.append(token)

    entity = " ".join(entity_tokens).strip() or raw
    return ParsedSearchQuery(
        raw=raw,
        entity=entity,
        scope_path=scope_path,
        boost_terms=boost_terms,
        exclude_terms=exclude_terms,
        source_hints=source_hints,
        filters=filters,
        free_terms=free_terms,
    )
