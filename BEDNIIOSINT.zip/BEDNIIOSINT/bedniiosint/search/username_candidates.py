from __future__ import annotations

from dataclasses import asdict, dataclass
import re
from typing import Any
from urllib.parse import urlparse

from ..modules.username import validators
from ..modules.username.scanner import build_url, load_sites


@dataclass(frozen=True)
class UsernameSiteCandidate:
    site_name: str
    site_key: str
    category: str
    username: str
    display_url: str
    probe_url: str
    url_main: str
    status: str
    status_reason: str = ""
    error_type: str = ""
    error_code: str = ""
    regex_check: str = ""
    request_method: str = ""
    verification_method: str = "sherlock_catalog_regex"
    status_model: str = "candidate_url_not_probed"
    provenance: dict[str, Any] | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


PRIORITY_CATEGORIES: tuple[str, ...] = (
    "social",
    "coding",
    "video",
    "music",
    "blog",
    "business",
    "gaming",
    "images",
    "news",
    "art",
    "hobby",
    "shopping",
    "finance",
    "misc",
)


PRIORITY_SITE_KEYS: tuple[str, ...] = (
    "vk",
    "instagram",
    "telegram",
    "telegram_t",
    "tiktok",
    "youtube",
    "github",
    "githubgist",
    "gitlab",
    "x",
    "twitter",
    "reddit",
    "ok_ru",
    "boosty",
    "spotify",
    "soundcloud",
    "genius",
    "bandcamp",
    "yandexmusic",
    "applemusic",
    "deezer",
    "musicbrainz",
    "last_fm",
    "linktree",
    "bluesky",
    "pinterest",
    "twitch",
    "medium",
    "dev_to",
    "habr",
)


def normalize_platform_token(value: str) -> str:
    return re.sub(r"[^a-z0-9_]+", "_", str(value or "").strip().lower()).strip("_")


def _site_key(name: str) -> str:
    return normalize_platform_token(name).replace("__", "_")


def _site_host(site: dict[str, Any]) -> str:
    url = str(site.get("uri_pretty") or site.get("url") or site.get("urlMain") or "")
    parsed = urlparse(url if "://" in url else f"https://{url}")
    return (parsed.netloc or parsed.path).split("/", 1)[0].lower().removeprefix("www.")


def _site_tokens(name: str, site: dict[str, Any]) -> set[str]:
    category = str(site.get("cat") or site.get("category") or "misc")
    host = _site_host(site)
    provenance = site.get("provenance") if isinstance(site.get("provenance"), dict) else {}
    raw = {
        name,
        _site_key(name),
        category,
        host,
        host.split(".", 1)[0] if host else "",
        str(provenance.get("original_name") or ""),
        str(provenance.get("source") or ""),
    }
    tokens = {normalize_platform_token(item) for item in raw if str(item or "").strip()}
    for item in list(tokens):
        tokens.update(part for part in item.split("_") if part)
    return {token for token in tokens if token}


def _site_matches_platforms(name: str, site: dict[str, Any], platforms: set[str]) -> bool:
    if not platforms:
        return True
    return bool(_site_tokens(name, site) & {normalize_platform_token(item) for item in platforms})


def _site_priority_rank(
    name: str,
    site: dict[str, Any],
    site_rank_by_key: dict[str, int],
) -> int:
    provenance = site.get("provenance") if isinstance(site.get("provenance"), dict) else {}
    host = _site_host(site)
    exact_candidates = {
        _site_key(name),
        normalize_platform_token(str(provenance.get("original_name") or "")),
    }
    default = len(site_rank_by_key)
    exact_rank = min(
        (site_rank_by_key.get(candidate, default) for candidate in exact_candidates if candidate),
        default=default,
    )
    if exact_rank < default:
        return exact_rank

    host_key = normalize_platform_token(host.split(".", 1)[0] if host else "")
    if host_key in site_rank_by_key:
        return default + site_rank_by_key[host_key]
    return default


def _upstream_rank(site: dict[str, Any]) -> int:
    try:
        rank = int(str(site.get("rank") or "").strip())
    except (TypeError, ValueError):
        return 10_000_000
    return max(0, rank)


def _display_template(site: dict[str, Any]) -> str:
    return str(site.get("uri_pretty") or site.get("url") or site.get("uri_check") or "")


def _probe_template(site: dict[str, Any]) -> str:
    return str(site.get("uri_check") or site.get("urlProbe") or site.get("url") or "")


def _error_type_label(value: Any) -> str:
    if isinstance(value, list):
        return ",".join(str(item) for item in value if str(item or "").strip())
    return str(value or "status_code")


def _error_code_label(value: Any) -> str:
    if isinstance(value, list):
        return ",".join(str(item) for item in value if str(item or "").strip())
    return str(value or "")


def _ordered_site_items(
    sites: dict[str, dict[str, Any]],
    *,
    preferred_categories: set[str] | None = None,
    platforms: set[str] | None = None,
    include_disabled: bool = False,
) -> list[tuple[str, dict[str, Any]]]:
    platform_set = {normalize_platform_token(item) for item in (platforms or set()) if item}
    category_set = {str(item or "").strip().lower() for item in (preferred_categories or set()) if item}
    rows = [
        (name, site)
        for name, site in sites.items()
        if include_disabled or not site.get("disabled")
        if _site_matches_platforms(name, site, platform_set)
    ]

    site_rank_by_key = {key: index for index, key in enumerate(PRIORITY_SITE_KEYS)}

    def priority(item: tuple[str, dict[str, Any]]) -> tuple[int, int, int, int, int, str]:
        name, site = item
        category = str(site.get("cat") or site.get("category") or "misc").lower()
        if category_set and category in category_set:
            preferred_category_rank = 0
        elif category_set:
            preferred_category_rank = 1
        else:
            preferred_category_rank = 0
        site_rank = _site_priority_rank(name, site, site_rank_by_key)
        if category in PRIORITY_CATEGORIES:
            category_rank = PRIORITY_CATEGORIES.index(category) + 1
        else:
            category_rank = len(PRIORITY_CATEGORIES) + 1
        has_regex_rank = 0 if site.get("regexCheck") else 1
        return (
            preferred_category_rank,
            site_rank,
            category_rank,
            _upstream_rank(site),
            has_regex_rank,
            name.lower(),
        )

    return sorted(rows, key=priority)


def _expand_sherlock_placeholder_usernames(username: str) -> list[str]:
    clean = str(username or "").strip().lstrip("@")
    if not clean:
        return []
    if "{?}" not in clean:
        return [clean]
    rows: list[str] = []
    for replacement in ("_", "-", "."):
        value = clean.replace("{?}", replacement)
        if value and value not in rows:
            rows.append(value)
    return rows


def build_username_site_candidates(
    usernames: list[str],
    *,
    platforms: set[str] | None = None,
    preferred_categories: set[str] | None = None,
    include_illegal: bool = False,
    include_disabled: bool = False,
    per_site_limit: int | None = None,
    limit: int | None = None,
) -> list[UsernameSiteCandidate]:
    sites = load_sites()
    rows: list[UsernameSiteCandidate] = []
    seen: set[tuple[str, str, str]] = set()
    max_rows = max(0, int(limit)) if limit is not None else None
    max_per_site = max(1, int(per_site_limit)) if per_site_limit is not None else None
    clean_usernames: list[str] = []
    for username in usernames:
        for clean_username in _expand_sherlock_placeholder_usernames(username):
            if clean_username not in clean_usernames:
                clean_usernames.append(clean_username)
    ordered_sites = _ordered_site_items(
        sites,
        preferred_categories=preferred_categories,
        platforms=platforms,
        include_disabled=include_disabled,
    )
    for site_name, site in ordered_sites:
        emitted_for_site = 0
        for clean_username in clean_usernames:
            if max_per_site is not None and emitted_for_site >= max_per_site:
                break
            display_template = _display_template(site)
            probe_template = _probe_template(site)
            if not display_template:
                continue
            username_for_site = validators.strip_bad_chars(clean_username, site.get("strip_bad_char"))
            regex_check = str(site.get("regexCheck") or "")
            passes = validators.passes_regex(username_for_site, regex_check)
            status = "candidate" if passes else "illegal"
            if not passes and not include_illegal:
                continue
            display_url = build_url(display_template, username_for_site) if passes else ""
            probe_url = build_url(probe_template, username_for_site) if passes and probe_template else ""
            key = (_site_key(site_name), username_for_site, display_url or status)
            if key in seen:
                continue
            seen.add(key)
            provenance = site.get("provenance") if isinstance(site.get("provenance"), dict) else {}
            rows.append(
                UsernameSiteCandidate(
                    site_name=site_name,
                    site_key=_site_key(site_name),
                    category=str(site.get("cat") or site.get("category") or "misc").lower(),
                    username=username_for_site,
                    display_url=display_url,
                    probe_url=probe_url,
                    url_main=str(site.get("urlMain") or site.get("url_main") or ""),
                    status=status,
                    status_reason="" if passes else "username_failed_site_regex",
                    error_type=_error_type_label(site.get("errorType") or "status_code"),
                    error_code=_error_code_label(site.get("errorCode") or site.get("m_code") or ""),
                    regex_check=regex_check,
                    request_method=str(site.get("request_method") or ""),
                    provenance=dict(provenance),
                )
            )
            emitted_for_site += 1
            if max_rows is not None and len(rows) >= max_rows:
                return rows
    return rows
