from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .auto_pivot import run_recursive_investigation


@dataclass(frozen=True)
class Playbook:
    id: str
    name: str
    description: str
    entity_types: list[str]
    scope: str = "public_osint"
    max_depth: int = 2
    include_dorking: bool = False
    include_username_scan: bool = True
    source_ids: list[str] | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


PLAYBOOKS: dict[str, Playbook] = {
    "username_deep": Playbook(
        id="username_deep",
        name="Username deep profile",
        description="Username coverage plus auto-pivot into emails/domains and identity correlation.",
        entity_types=["username"],
        max_depth=2,
        include_username_scan=True,
    ),
    "email_to_identity": Playbook(
        id="email_to_identity",
        name="Email to identity",
        description="Pivot from email to username/domain signals and build a unified dossier.",
        entity_types=["email"],
        max_depth=2,
    ),
    "domain_footprint": Playbook(
        id="domain_footprint",
        name="Domain footprint",
        description="DNS/RDAP/CT/archive/contact discovery with bounded pivots.",
        entity_types=["domain"],
        max_depth=2,
        include_dorking=True,
        include_username_scan=False,
    ),
    "quick_triage": Playbook(
        id="quick_triage",
        name="Quick triage",
        description="Single-wave overview with no recursive pivots.",
        entity_types=["username", "email", "domain", "phone", "url"],
        max_depth=0,
        include_username_scan=True,
    ),
}


def list_playbooks() -> list[dict[str, Any]]:
    return [playbook.as_dict() for playbook in PLAYBOOKS.values()]


def get_playbook(playbook_id: str) -> Playbook | None:
    return PLAYBOOKS.get(playbook_id)


def run_playbook(
    playbook_id: str,
    entity_input: str,
    *,
    entity_type: str | None = None,
    save: bool = False,
    case_name: str | None = None,
    **overrides: Any,
) -> dict[str, Any]:
    playbook = get_playbook(playbook_id)
    if playbook is None:
        raise KeyError(f"unknown playbook: {playbook_id}")
    params: dict[str, Any] = {
        "entity_type": entity_type or (playbook.entity_types[0] if playbook.entity_types else None),
        "scope": playbook.scope,
        "max_depth": playbook.max_depth,
        "include_dorking": playbook.include_dorking,
        "include_username_scan": playbook.include_username_scan,
        "source_ids": playbook.source_ids,
        "save": save,
        "case_name": case_name,
    }
    params.update(overrides)
    result = run_recursive_investigation(entity_input, **params)
    result["playbook"] = playbook.as_dict()
    return result
