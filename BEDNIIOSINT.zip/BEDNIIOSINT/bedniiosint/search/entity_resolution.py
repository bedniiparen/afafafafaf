from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .correlation import CorrelationLink, build_correlations


SIGNAL_PROB = {
    "shared_avatar_hash": 0.97,
    "shared_email": 0.93,
    "cross_platform_username": 0.78,
    "same_display_name": 0.45,
    "shared_handle": 0.55,
    "shared_external_link": 0.40,
}


class _UnionFind:
    def __init__(self) -> None:
        self.parent: dict[str, str] = {}

    def find(self, x: str) -> str:
        self.parent.setdefault(x, x)
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: str, b: str) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[ra] = rb


@dataclass
class IdentityCluster:
    cluster_id: str
    member_ids: list[str]
    probability: float
    signals: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "cluster_id": self.cluster_id,
            "member_ids": sorted(self.member_ids),
            "probability": round(self.probability, 4),
            "signals": sorted(set(self.signals)),
        }


def _combine(probs: list[float]) -> float:
    inv = 1.0
    for p in probs:
        inv *= 1.0 - max(0.0, min(0.999, p))
    return 1.0 - inv


def resolve_identities(
    results: list[dict[str, Any]],
    *,
    min_probability: float = 0.5,
) -> list[IdentityCluster]:
    links: list[CorrelationLink] = build_correlations(results, min_members=2)

    uf = _UnionFind()
    pair_probs: dict[tuple[str, str], list[float]] = {}
    pair_signals: dict[tuple[str, str], list[str]] = {}

    for link in links:
        prob = SIGNAL_PROB.get(link.kind, 0.4)
        members = sorted(link.member_ids)
        for i in range(len(members)):
            for j in range(i + 1, len(members)):
                pair = (members[i], members[j])
                pair_probs.setdefault(pair, []).append(prob)
                pair_signals.setdefault(pair, []).append(link.kind)

    for pair, probs in pair_probs.items():
        if _combine(probs) >= min_probability:
            uf.union(pair[0], pair[1])

    clusters: dict[str, list[str]] = {}
    for node in list(uf.parent):
        clusters.setdefault(uf.find(node), []).append(node)

    out: list[IdentityCluster] = []
    for root, members in clusters.items():
        if len(members) < 2:
            continue
        member_set = set(members)
        probs: list[float] = []
        signals: list[str] = []
        for pair, plist in pair_probs.items():
            if pair[0] in member_set and pair[1] in member_set:
                probs.append(_combine(plist))
                signals.extend(pair_signals[pair])
        out.append(
            IdentityCluster(
                cluster_id=f"identity:{root}",
                member_ids=members,
                probability=_combine(probs) if probs else 0.0,
                signals=signals,
            )
        )
    out.sort(key=lambda c: (c.probability, len(c.member_ids)), reverse=True)
    return out
