from __future__ import annotations

"""Active liveness verification for unverified candidate URLs.

Dorking/profile candidate URLs are generated from templates and never fetched,
so many of them point at soft-404 pages. This module fetches each candidate
once, classifies presence with the shared negative-content markers, and drops
dead candidates before they are surfaced as search results.
"""

import logging
from concurrent.futures import (
    ThreadPoolExecutor,
    TimeoutError as FuturesTimeoutError,
    as_completed,
)

from ..config import settings
from ..core.http import request
from .host_throttle import HostThrottle, NegativeCache, throttled_request
from .models import SearchResult
from .presence import SOFT_NEGATIVE_MARKERS, STRONG_NEGATIVE_MARKERS

logger = logging.getLogger(__name__)

_THROTTLE = HostThrottle(default_rate=5.0, burst=5.0, min_rate=0.5, max_rate=20.0)
_NEGATIVE_CACHE = NegativeCache(ttl=3600.0)


def _append_unique(items: list[str], value: str) -> None:
    if value and value not in items:
        items.append(value)


def _is_candidate(result: SearchResult) -> bool:
    data = result.normalized_data if isinstance(result.normalized_data, dict) else {}
    if str(data.get("verification_status") or "").lower() == "unverified_candidate":
        return True
    return "candidate_url" in (result.tags or [])


def _looks_present(status_code: int | None, text: str) -> bool:
    lowered = (text or "").lower()
    if isinstance(status_code, int) and status_code in (404, 410):
        return False
    if any(marker in lowered for marker in STRONG_NEGATIVE_MARKERS):
        return False
    if any(marker in lowered for marker in SOFT_NEGATIVE_MARKERS) and len(lowered) <= 800:
        return False
    if isinstance(status_code, int):
        return status_code < 400
    return bool(lowered)


def _verify_one(url: str) -> tuple[str, str, int | None]:
    """Return (state, reason, status_code). state in {present, absent, uncertain}."""
    url = (url or "").strip()
    if not url:
        return "uncertain", "no url", None
    try:
        response = throttled_request(
            "GET",
            url,
            throttle=_THROTTLE,
            negative_cache=_NEGATIVE_CACHE,
            request_fn=request,
            headers={"User-Agent": getattr(settings, "user_agent", "bedniiosint-osint/1.0")},
            follow_redirects=True,
        )
    except Exception as exc:
        return "uncertain", f"fetch error: {type(exc).__name__}", None
    if response is None:
        return "absent", "negative cache / absent host", None
    status_code = int(getattr(response, "status_code", 0) or 0)
    try:
        text = str(response.text or "")
    except Exception:
        text = ""
    if _looks_present(status_code, text):
        return "present", f"reachable (status {status_code})", status_code
    return "absent", f"soft-404 / negative page (status {status_code})", status_code


def verify_candidate_results(results: list[SearchResult]) -> list[SearchResult]:
    """Fetch unverified candidate URLs and drop dead/soft-404 ones."""
    if not getattr(settings, "verify_candidate_urls", True):
        return results
    candidates = [result for result in results if _is_candidate(result) and (result.url or "").strip()]
    if not candidates:
        return results
    limit = max(0, int(getattr(settings, "verify_candidate_limit", 60)))
    if limit:
        candidates = candidates[:limit]
    budget = max(1.0, float(getattr(settings, "verify_candidate_timeout", 25.0)))
    drop_absent = bool(getattr(settings, "verify_candidate_drop_absent", True))
    workers = max(1, min(int(getattr(settings, "verify_candidate_workers", 16)), len(candidates)))

    verdicts: dict[int, tuple[str, str, int | None]] = {}
    executor = ThreadPoolExecutor(max_workers=workers)
    try:
        futures = {executor.submit(_verify_one, result.url): id(result) for result in candidates}
        try:
            for future in as_completed(futures, timeout=budget):
                rid = futures[future]
                try:
                    verdicts[rid] = future.result()
                except Exception:
                    logger.exception("candidate verification raised")
                    verdicts[rid] = ("uncertain", "verification raised", None)
        except FuturesTimeoutError:
            pass
        for future, rid in futures.items():
            if rid in verdicts:
                continue
            if future.done():
                try:
                    verdicts[rid] = future.result()
                    continue
                except Exception:
                    logger.exception("candidate verification raised")
                    verdicts[rid] = ("uncertain", "verification raised", None)
                    continue
            future.cancel()
    finally:
        executor.shutdown(wait=False, cancel_futures=True)

    kept: list[SearchResult] = []
    dropped = 0
    for result in results:
        rid = id(result)
        if rid not in verdicts:
            kept.append(result)
            continue
        state, reason, status_code = verdicts[rid]
        if isinstance(result.normalized_data, dict):
            result.normalized_data["candidate_verification"] = {
                "state": state,
                "reason": reason,
                "status_code": status_code,
            }
        if state == "absent":
            dropped += 1
            if drop_absent:
                continue
            _append_unique(result.risk_flags, "confirmed_absent")
            result.confidence_score = 0.0
            kept.append(result)
            continue
        if state == "present":
            _append_unique(result.tags, "reachable")
            if isinstance(result.normalized_data, dict):
                result.normalized_data["verification_status"] = "reachable_unconfirmed"
            result.confidence_score = max(float(result.confidence_score or 0.0), 0.35)
        kept.append(result)
    if dropped:
        logger.info("candidate verification dropped %d dead candidate URL(s)", dropped)
    return kept
