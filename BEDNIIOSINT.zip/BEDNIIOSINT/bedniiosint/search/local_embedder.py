from __future__ import annotations

"""Local embedding providers for semantic re-ranking.

The public entry point is ``embed_texts``. It prefers a real local model when
``fastembed`` or ``sentence-transformers`` is installed, then falls back to a
deterministic hashing embedder so ranking never silently disables semantic
signals after ``BEDNIIOSINT_EMBEDDING_RERANK=1`` is enabled.
"""

import hashlib
import math
import os
import re
import threading
from collections.abc import Sequence
from typing import Any

_TOKEN_RE = re.compile(r"[\w@.+-]+", re.UNICODE)
_MODEL_LOCK = threading.Lock()
_MODEL_CACHE: dict[tuple[str, str], Any] = {}

DEFAULT_FASTEMBED_MODEL = "BAAI/bge-small-en-v1.5"
DEFAULT_SENTENCE_TRANSFORMERS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
DEFAULT_HASH_DIMENSIONS = 384


def _env(name: str, default: str = "") -> str:
    return os.getenv(f"BEDNIIOSINT_{name}", os.getenv(name, default)).strip()


def _backend() -> str:
    return _env("EMBEDDING_BACKEND", _env("EMBEDDING_PROVIDER", "auto")).lower()


def _model_name(backend: str) -> str:
    configured = _env("EMBEDDING_MODEL")
    if configured:
        return configured
    if backend == "sentence-transformers":
        return DEFAULT_SENTENCE_TRANSFORMERS_MODEL
    return DEFAULT_FASTEMBED_MODEL


def _hash_dimensions() -> int:
    raw = _env("HASH_EMBEDDING_DIM", str(DEFAULT_HASH_DIMENSIONS))
    try:
        return max(16, min(4096, int(raw)))
    except ValueError:
        return DEFAULT_HASH_DIMENSIONS


def _tokens(text: str) -> list[str]:
    lowered = str(text or "").lower()
    tokens = _TOKEN_RE.findall(lowered)
    compact = "".join(char for char in lowered if char.isalnum())
    if len(compact) >= 4:
        tokens.extend(compact[index : index + 4] for index in range(len(compact) - 3))
    return tokens or [""]


def _hash_index(token: str, dimensions: int) -> tuple[int, float]:
    digest = hashlib.blake2b(token.encode("utf-8", "ignore"), digest_size=16).digest()
    bucket = int.from_bytes(digest[:8], "big") % dimensions
    sign = 1.0 if digest[8] & 1 else -1.0
    return bucket, sign


def hash_embed_texts(texts: Sequence[str], *, dimensions: int | None = None) -> list[list[float]]:
    """Return deterministic unit-normalized hashed bag-of-token vectors."""

    size = dimensions or _hash_dimensions()
    vectors: list[list[float]] = []
    for text in texts:
        vector = [0.0] * size
        for token in _tokens(str(text or "")):
            bucket, sign = _hash_index(token, size)
            weight = 1.0 + math.log1p(len(token))
            vector[bucket] += sign * weight
        norm = math.sqrt(sum(value * value for value in vector))
        if norm:
            vector = [round(value / norm, 8) for value in vector]
        vectors.append(vector)
    return vectors


def _fastembed_texts(texts: Sequence[str], model_name: str) -> list[list[float]]:
    from fastembed import TextEmbedding  # type: ignore

    key = ("fastembed", model_name)
    with _MODEL_LOCK:
        model = _MODEL_CACHE.get(key)
        if model is None:
            model = TextEmbedding(model_name=model_name)
            _MODEL_CACHE[key] = model
    return [[float(value) for value in vector] for vector in model.embed(list(texts))]


def _sentence_transformers_texts(texts: Sequence[str], model_name: str) -> list[list[float]]:
    from sentence_transformers import SentenceTransformer  # type: ignore

    key = ("sentence-transformers", model_name)
    with _MODEL_LOCK:
        model = _MODEL_CACHE.get(key)
        if model is None:
            model = SentenceTransformer(model_name)
            _MODEL_CACHE[key] = model
    vectors = model.encode(list(texts), normalize_embeddings=True)
    return [[float(value) for value in vector] for vector in vectors]


def embed_texts(texts: Sequence[str]) -> list[list[float]]:
    """Embed texts using a local model when available, otherwise hashing.

    ``BEDNIIOSINT_EMBEDDING_BACKEND`` can force ``fastembed``,
    ``sentence-transformers`` or ``hash``. With ``auto`` the first installed
    local model wins.
    """

    backend = _backend()
    if backend in {"hash", "hashed", "stdlib"}:
        return hash_embed_texts(texts)

    backends: tuple[str, ...]
    if backend in {"fastembed", "sentence-transformers"}:
        backends = (backend,)
    else:
        backends = ("fastembed", "sentence-transformers")

    for candidate in backends:
        try:
            model_name = _model_name(candidate)
            if candidate == "fastembed":
                return _fastembed_texts(texts, model_name)
            if candidate == "sentence-transformers":
                return _sentence_transformers_texts(texts, model_name)
        except Exception:
            continue
    return hash_embed_texts(texts)


def provider_label() -> str:
    """Return the effective local provider label for cache keys and diagnostics."""

    backend = _backend()
    if backend in {"hash", "hashed", "stdlib"}:
        return f"local-hash:{_hash_dimensions()}"
    return f"local-{backend}:{_model_name(backend)}"
