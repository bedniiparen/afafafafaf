from __future__ import annotations

"""Cross-identifier identity resolution.

This module has two compatible entry points behind one public function:

* ``build_identities(dict_results)`` keeps the original auto-pivot behavior and
  returns ``Identity`` dataclass objects.
* ``build_identities(search_results, links)`` collapses correlation links into
  persona components, calibrates confidence, and annotates each ``SearchResult``
  in place.
"""

import hashlib
import re
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable
from urllib.parse import urlparse

from .models import SearchResult


EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")


@dataclass
class Identity:
    key: str
    kind: str
    label: str
    usernames: list[str] = field(default_factory=list)
    emails: list[str] = field(default_factory=list)
    platforms: list[str] = field(default_factory=list)
    urls: list[str] = field(default_factory=list)
    result_ids: list[str] = field(default_factory=list)
    source_count: int = 0
    confidence: float = 0.0
    status: str = "weak"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _norm(value: Any) -> str:
    return str(value or "").strip().lower()


def _platform_of(result: dict[str, Any]) -> str:
    return _norm(result.get("detected_platform") or result.get("source_name") or result.get("source_id"))


def _host(url: str) -> str:
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ""


def _username_from_url(url: str) -> str:
    parsed = urlparse(url if "://" in url else f"https://{url}")
    parts = [part for part in parsed.path.split("/") if part]
    if not parts:
        return ""
    host = _host(url)
    if host.endswith("reddit.com") and len(parts) >= 2 and parts[-2].lower() in {"u", "user"}:
        return _norm(parts[-1])
    if host.endswith("bsky.app") and len(parts) >= 2 and parts[-2].lower() == "profile":
        return _norm(parts[-1].split(".", 1)[0])
    if len(parts) == 1:
        return _norm(parts[0].strip("@~"))
    return ""


def _add(seq: list[str], value: str) -> None:
    clean = str(value or "").strip()
    if clean and clean not in seq:
        seq.append(clean)


def _status_for(confidence: float, platform_count: int) -> str:
    if platform_count >= 2 and confidence >= 0.7:
        return "confirmed"
    if confidence >= 0.5:
        return "possible"
    return "weak"


def _find(parent: dict[str, str], item: str) -> str:
    parent.setdefault(item, item)
    while parent[item] != item:
        parent[item] = parent[parent[item]]
        item = parent[item]
    return item


def _union(parent: dict[str, str], left: str, right: str) -> None:
    left_root = _find(parent, left)
    right_root = _find(parent, right)
    if left_root != right_root:
        parent[right_root] = left_root


def _build_autopivot_identities(results: list[dict[str, Any]]) -> list[Identity]:
    records: list[dict[str, Any]] = []
    parent: dict[str, str] = {}

    for index, result in enumerate(results):
        if not isinstance(result, dict):
            continue
        entity_type = _norm(result.get("entity_type"))
        username = _norm(result.get("matched_entity") or result.get("matched_variant"))
        url = str(result.get("url") or "")
        if not username and url:
            username = _username_from_url(url)
        emails = sorted(
            {
                _norm(email)
                for email in EMAIL_RE.findall(
                    " ".join(
                        str(result.get(key) or "")
                        for key in ("matched_entity", "matched_variant", "title", "snippet", "url")
                    )
                )
            }
        )
        if EMAIL_RE.fullmatch(username):
            if username not in emails:
                emails.append(username)
            username = ""
        signals: list[str] = []

        if entity_type in {"username", "profile"} and username:
            signals.append(f"username:{username}")
        elif emails:
            signals.extend(f"email:{email}" for email in emails)
        elif username:
            signals.append(f"username:{username}")
        else:
            continue

        for email in emails:
            signal = f"email:{email}"
            if signal not in signals:
                signals.append(signal)
        if not signals:
            continue

        for signal in signals:
            parent.setdefault(signal, signal)
        first = signals[0]
        for signal in signals[1:]:
            _union(parent, first, signal)

        records.append(
            {
                "signals": signals,
                "username": username,
                "emails": emails,
                "platform": _platform_of(result),
                "url": str(result.get("url") or ""),
                "result_id": str(result.get("id") or f"result-{index}"),
                "confidence": result.get("confidence_score"),
            }
        )

    grouped: dict[str, list[dict[str, Any]]] = {}
    for record in records:
        root = _find(parent, record["signals"][0])
        grouped.setdefault(root, []).append(record)

    identities: dict[str, Identity] = {}
    confidences: dict[str, list[float]] = {}
    for _root, rows in grouped.items():
        signal_set = {signal for row in rows for signal in row["signals"]}
        usernames = sorted(signal.removeprefix("username:") for signal in signal_set if signal.startswith("username:"))
        emails = sorted(signal.removeprefix("email:") for signal in signal_set if signal.startswith("email:"))
        if usernames:
            key = f"username:{usernames[0]}"
            kind = "username"
            label = usernames[0]
        elif emails:
            key = f"email:{emails[0]}"
            kind = "email"
            label = emails[0]
        else:
            continue
        identity = Identity(key=key, kind=kind, label=label)
        identities[key] = identity
        confidences[key] = []

        for username_value in usernames:
            _add(identity.usernames, username_value)
        for email in emails:
            _add(identity.emails, email)
        for row in rows:
            _add(identity.platforms, row["platform"])
            _add(identity.urls, row["url"])
            _add(identity.result_ids, row["result_id"])
            try:
                confidences[key].append(float(row["confidence"] or 0.0))
            except (TypeError, ValueError):
                pass

    output: list[Identity] = []
    for key, identity in identities.items():
        scores = [score for score in confidences.get(key, []) if score > 0]
        average = round(sum(scores) / len(scores), 3) if scores else 0.0
        identity.platforms = [platform for platform in identity.platforms if platform]
        identity.urls = [url for url in identity.urls if url]
        identity.source_count = len(identity.platforms)
        identity.confidence = average
        identity.status = _status_for(average, identity.source_count)
        output.append(identity)

    output.sort(key=lambda item: (item.source_count, item.confidence), reverse=True)
    return output


def _sid(*parts: Any) -> str:
    text = "|".join(str(part or "") for part in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:14]


_HIGH_TRUST_API = (
    "hibp",
    "hunter",
    "github",
    "gitlab",
    "shodan",
    "censys",
    "virustotal",
    "securitytrails",
    "crtsh",
    "rdap",
    "gravatar",
    "emailrep",
    "opencorporates",
    "numverify",
    "veriphone",
    "twilio",
    "wikidata",
)


def default_source_reliability(result: SearchResult) -> float:
    source = str(result.source_id or "").lower()
    tags = {str(tag).lower() for tag in (result.tags or [])}
    flags = {str(flag).lower() for flag in (result.risk_flags or [])}
    data = result.normalized_data if isinstance(result.normalized_data, dict) else {}

    if "review_only" in tags or "review_only" in flags or data.get("review_only"):
        base = 0.2
    elif source.startswith("dorking:") or "candidate_url" in tags:
        base = 0.2
    elif source.startswith("api:") and any(name in source for name in _HIGH_TRUST_API):
        base = 0.85
    elif source.startswith("api:"):
        base = 0.65
    elif source.startswith("username_scan") or source.startswith("wmn") or "sherlock_style" in tags:
        base = 0.7
    elif "web_search" in source or "google_cse" in source:
        base = 0.5
    else:
        base = 0.5

    verification = data.get("candidate_verification")
    if isinstance(verification, dict) and verification.get("state") == "present":
        base = min(0.9, base + 0.1)
    if data.get("presence_verified") or "reachable" in tags:
        base = min(0.9, base + 0.05)
    return round(base, 3)


class _UnionFind:
    def __init__(self) -> None:
        self._parent: dict[str, str] = {}

    def find(self, item: str) -> str:
        self._parent.setdefault(item, item)
        root = item
        while self._parent[root] != root:
            root = self._parent[root]
        while self._parent[item] != root:
            self._parent[item], item = root, self._parent[item]
        return root

    def union(self, left: str, right: str) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root != right_root:
            self._parent[left_root] = right_root


def _band(score: float) -> str:
    if score >= 0.75:
        return "confirmed"
    if score >= 0.5:
        return "possible"
    if score > 0:
        return "weak"
    return "unconfirmed"


def _noisy_or(probabilities: Iterable[float]) -> float:
    product = 1.0
    for probability in probabilities:
        p = max(0.0, min(1.0, float(probability)))
        product *= 1.0 - p
    return 1.0 - product


def _identity_label(identifiers: list[dict[str, str]], members: list[SearchResult]) -> tuple[str, str, str]:
    if identifiers:
        first = identifiers[0]
        kind = first["entity_type"] or "identity"
        value = first["value"]
        return f"{kind}:{value}", kind, value
    member = members[0]
    value = str(member.matched_entity or member.entity_input or member.url or member.id)
    return f"identity:{value}", "identity", value


def _member_identifier(member: SearchResult) -> tuple[str, str] | None:
    value = str(member.matched_entity or member.entity_input or member.url or "").strip().lower()
    if not value:
        return None
    entity_type = str(member.entity_type or "unknown").strip().lower() or "unknown"
    return (entity_type, value)


def _build_persona_identities(
    results: list[SearchResult],
    links: list[dict[str, Any]],
    *,
    reliability_fn=default_source_reliability,
) -> list[dict[str, Any]]:
    by_id: dict[str, SearchResult] = {result.id: result for result in results if result.id}
    if not by_id:
        return []

    uf = _UnionFind()
    for result_id in by_id:
        uf.find(result_id)

    link_kinds: dict[str, list[tuple[str, float]]] = defaultdict(list)
    for link in links or []:
        raw_members = link.get("member_ids") if isinstance(link, dict) else []
        members = [str(member) for member in (raw_members or []) if str(member) in by_id]
        if len(members) < 2:
            continue
        kind = str(link.get("kind") or "link")
        try:
            confidence = float(link.get("confidence") or 0.0)
        except (TypeError, ValueError):
            confidence = 0.0
        anchor = members[0]
        for other in members[1:]:
            uf.union(anchor, other)
        for member in members:
            link_kinds[member].append((kind, confidence))

    components: dict[str, list[str]] = defaultdict(list)
    for result_id in by_id:
        components[uf.find(result_id)].append(result_id)

    personas: list[dict[str, Any]] = []
    for _root, member_ids in components.items():
        members = [by_id[member_id] for member_id in member_ids]
        per_source: dict[str, float] = {}
        identifiers: dict[tuple[str, str], None] = {}
        evidence_count = 0
        kinds: set[str] = set()
        merge_confs: list[float] = []

        for member in members:
            reliability = float(reliability_fn(member))
            probability = max(0.0, min(1.0, float(member.confidence_score or 0.0))) * reliability
            source = str(member.source_id or member.id)
            per_source[source] = max(per_source.get(source, 0.0), probability)
            identifier = _member_identifier(member)
            if identifier:
                identifiers[identifier] = None
            evidence_count += len(member.evidence or [])
            for kind, confidence in link_kinds.get(member.id, []):
                kinds.add(kind)
                merge_confs.append(confidence)

        link_strength = max(merge_confs) if merge_confs else 1.0
        identifier_list = [
            {"entity_type": entity_type, "value": value}
            for entity_type, value in sorted(identifiers)
        ]
        multi_identifier = len(identifiers) > 1
        base = _noisy_or(per_source.values())
        confidence = base * link_strength if multi_identifier else base
        confidence = round(max(0.0, min(1.0, confidence)), 3)
        band = _band(confidence)
        identity_id = "identity-" + _sid(*sorted(member_ids))
        key, kind, label = _identity_label(identifier_list, members)
        sources = sorted({str(member.source_id) for member in members if member.source_id})
        usernames = [
            row["value"]
            for row in identifier_list
            if row["entity_type"] in {"username", "profile"} and row["value"]
        ]
        emails = [row["value"] for row in identifier_list if row["entity_type"] == "email" and row["value"]]
        explanation_bits = [f"{len(sources)} source(s)"]
        if kinds:
            explanation_bits.append("linked by " + ", ".join(sorted(kinds)))
        if multi_identifier:
            explanation_bits.append(f"{len(identifier_list)} identifiers")

        persona = {
            "identity_id": identity_id,
            "key": key,
            "kind": kind,
            "label": label,
            "member_result_ids": sorted(member_ids),
            "result_ids": sorted(member_ids),
            "member_count": len(member_ids),
            "identifiers": identifier_list,
            "usernames": sorted(set(usernames)),
            "emails": sorted(set(emails)),
            "sources": sources,
            "source_count": len(sources),
            "linked_by": sorted(kinds),
            "evidence_count": evidence_count,
            "confidence": confidence,
            "band": band,
            "status": band,
            "explanation": band + ": " + "; ".join(explanation_bits) + ".",
        }
        personas.append(persona)

        for member in members:
            if isinstance(member.normalized_data, dict):
                member.normalized_data["identity"] = {
                    "identity_id": identity_id,
                    "identity_confidence": confidence,
                    "identity_band": band,
                    "member_count": len(member_ids),
                    "linked_by": sorted(kinds),
                }

    personas.sort(key=lambda row: (row["confidence"], row["source_count"]), reverse=True)
    return personas


def build_identities(
    results: list[Any],
    links: list[dict[str, Any]] | None = None,
    *,
    reliability_fn=default_source_reliability,
):
    if links is None:
        return _build_autopivot_identities([row for row in results if isinstance(row, dict)])
    search_results = [row for row in results if isinstance(row, SearchResult)]
    return _build_persona_identities(search_results, links, reliability_fn=reliability_fn)
