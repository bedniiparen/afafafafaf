"""Persistent embedding cache for the semantic re-ranker.

The semantic re-rank step in ``ranking.py`` previously recomputed embeddings on
every query, which is the main cost driver when ``embedding_rerank_enabled`` is
on. This module memoizes embeddings in a small SQLite table keyed by a hash of
the model name + text, so repeated documents (which are extremely common across
OSINT runs) are embedded only once.

It is dependency-free (stdlib only) and degrades gracefully: if no embedder
provider is configured (EMBEDDING_PROVIDER), callers simply skip semantic rerank.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import os
import sqlite3
import threading
from pathlib import Path
from typing import Callable, Sequence

from ..config import settings

_LOCK = threading.Lock()
_DB_CACHE: dict[str, sqlite3.Connection] = {}


def _resolve_default_embedder():
    # Optional, configurable embedder: set EMBEDDING_PROVIDER='module.path:function'
    # (or settings.embedding_provider). Returns None when no provider is configured,
    # so semantic rerank cleanly no-ops instead of importing a non-existent module.
    spec = (
        os.environ.get("BEDNIIOSINT_EMBEDDING_PROVIDER", "").strip()
        or os.environ.get("EMBEDDING_PROVIDER", "").strip()
        or str(getattr(settings, "embedding_provider", "") or "").strip()
    )
    rerank_requested = os.environ.get("BEDNIIOSINT_EMBEDDING_RERANK", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    } or bool(getattr(settings, "embedding_rerank_enabled", False))
    if not spec and rerank_requested:
        spec = "local"
    if spec.lower() in {
        "local",
        "auto",
        "hash",
        "hashed",
        "stdlib",
        "fastembed",
        "sentence-transformers",
        "sentence_transformers",
    }:
        try:
            from .local_embedder import embed_texts

            return embed_texts
        except Exception:
            return None
    if not spec or ":" not in spec:
        return None
    module_path, _, attr = spec.partition(":")
    if not module_path or not attr:
        return None
    try:
        module = importlib.import_module(module_path)
        candidate = getattr(module, attr, None)
    except Exception:
        return None
    return candidate if callable(candidate) else None


def _db_path() -> Path:
    base = getattr(settings, "db_dir", None) or Path(".bedniiosint")
    base = Path(base)
    base.mkdir(parents=True, exist_ok=True)
    return base / "_embedding_cache.sqlite"


def _conn() -> sqlite3.Connection:
    path = str(_db_path())
    conn = _DB_CACHE.get(path)
    if conn is None:
        conn = sqlite3.connect(path, check_same_thread=False)
        conn.execute(
            "CREATE TABLE IF NOT EXISTS embedding_cache (key TEXT PRIMARY KEY, vector TEXT NOT NULL)"
        )
        conn.commit()
        _DB_CACHE[path] = conn
    return conn


def _key(model: str, text: str) -> str:
    digest = hashlib.sha256((model + "\x00" + text).encode("utf-8")).hexdigest()
    return digest


def _get_many(keys: Sequence[str]) -> dict[str, list[float]]:
    if not keys:
        return {}
    placeholders = ",".join("?" for _ in keys)
    rows = _conn().execute(
        f"SELECT key, vector FROM embedding_cache WHERE key IN ({placeholders})",
        list(keys),
    ).fetchall()
    return {key: json.loads(vector) for key, vector in rows}


def _put_many(items: dict[str, list[float]]) -> None:
    if not items:
        return
    with _LOCK:
        conn = _conn()
        conn.executemany(
            "INSERT OR REPLACE INTO embedding_cache (key, vector) VALUES (?, ?)",
            [(key, json.dumps(vector)) for key, vector in items.items()],
        )
        conn.commit()


def embed_texts_cached(
    texts: Sequence[str],
    *,
    model: str | None = None,
    embedder: Callable[[list[str]], list[list[float]]] | None = None,
) -> list[list[float]] | None:
    """Return embeddings for ``texts`` using a persistent cache.

    Returns ``None`` if no embedder is available so callers can skip rerank.
    """

    if not texts:
        return []
    if embedder is None:
        embedder = _resolve_default_embedder()
        if embedder is None:
            return None
    configured_provider = (
        os.environ.get("BEDNIIOSINT_EMBEDDING_PROVIDER", "").strip()
        or os.environ.get("EMBEDDING_PROVIDER", "").strip()
        or str(getattr(settings, "embedding_provider", "") or "").strip()
    )
    rerank_requested = os.environ.get("BEDNIIOSINT_EMBEDDING_RERANK", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    } or bool(getattr(settings, "embedding_rerank_enabled", False))
    configured_provider = configured_provider or ("local" if rerank_requested else "default")
    configured_model = (
        os.environ.get("BEDNIIOSINT_EMBEDDING_MODEL", "").strip()
        or os.environ.get("EMBEDDING_MODEL", "").strip()
        or str(getattr(settings, "embedding_model", "") or "").strip()
    )
    if configured_provider.lower() in {
        "local",
        "auto",
        "hash",
        "hashed",
        "stdlib",
        "fastembed",
        "sentence-transformers",
        "sentence_transformers",
    }:
        try:
            from .local_embedder import provider_label

            configured_model = configured_model or provider_label()
        except Exception:
            pass
    model_name = model or configured_model or configured_provider

    keys = [_key(model_name, text) for text in texts]
    cached = _get_many(keys)

    missing_indexes = [index for index, key in enumerate(keys) if key not in cached]
    if missing_indexes:
        try:
            fresh = embedder([texts[index] for index in missing_indexes])
        except Exception:
            return None
        to_store: dict[str, list[float]] = {}
        for offset, index in enumerate(missing_indexes):
            if offset < len(fresh):
                vector = [float(value) for value in fresh[offset]]
                cached[keys[index]] = vector
                to_store[keys[index]] = vector
        _put_many(to_store)

    ordered: list[list[float]] = []
    for key in keys:
        vector = cached.get(key)
        if vector is None:
            return None
        ordered.append(vector)
    return ordered
