from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .query_parser import ParsedSearchQuery
from .scope_resolver import ResolvedScope


@dataclass
class ExpandedQuery:
    entity: str
    entity_type: str
    scope_path: str = ""
    terms: list[str] = field(default_factory=list)
    excludes: list[str] = field(default_factory=list)
    queries: list[str] = field(default_factory=list)
    source_queries: dict[str, list[str]] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _append_unique(items: list[str], value: str) -> None:
    clean = str(value or "").strip()
    if clean and clean not in items:
        items.append(clean)


def _quote(value: str) -> str:
    clean = str(value or "").strip()
    if not clean:
        return '""'
    escaped = clean.replace('"', '\\"')
    return f'"{escaped}"'


def _query_with_terms(entity: str, terms: list[str], excludes: list[str]) -> str:
    parts = [_quote(entity)]
    parts.extend(term for term in terms if term)
    parts.extend(f"-{term}" for term in excludes if term)
    return " ".join(parts).strip()


def _site_query(site: str, entity: str, excludes: list[str]) -> str:
    parts = [f"site:{site}", _quote(entity)]
    parts.extend(f"-{term}" for term in excludes if term)
    return " ".join(parts).strip()


def _extend_rows(rows: dict[str, list[str]], key: str, values: list[str]) -> None:
    target = rows.setdefault(key, [])
    for value in values:
        _append_unique(target, value)


def _social_site_queries(entity: str, excludes: list[str]) -> list[str]:
    sites = [
        "x.com",
        "twitter.com",
        "instagram.com",
        "linkedin.com/in",
        "linkedin.com/company",
        "facebook.com",
        "reddit.com",
        "tiktok.com",
        "youtube.com",
        "t.me",
        "github.com",
        "gitlab.com",
        "mastodon.social",
        "bsky.app/profile",
    ]
    return [_site_query(site, entity, excludes) for site in sites]


def _music_site_queries(entity: str, excludes: list[str]) -> list[str]:
    sites = [
        "vk.com",
        "instagram.com",
        "genius.com/artists",
        "youtube.com",
        "music.yandex.ru",
        "open.spotify.com",
        "soundcloud.com",
        "bandcamp.com",
        "last.fm/music",
        "music.apple.com",
        "deezer.com",
        "musicbrainz.org",
    ]
    return [_site_query(site, entity, excludes) for site in sites]


def _domain_dork_queries(entity: str, excludes: list[str]) -> list[str]:
    return [
        f"site:{entity}",
        _query_with_terms(entity, ["filetype:pdf"], excludes),
        _query_with_terms(entity, ["inurl:admin"], excludes),
        _query_with_terms(entity, ["inurl:login"], excludes),
        _query_with_terms(entity, ['"security.txt"'], excludes),
        _site_query("github.com", entity, excludes),
        _site_query("gitlab.com", entity, excludes),
        _site_query("crt.sh", entity, excludes),
        _site_query("urlscan.io", entity, excludes),
        _site_query("web.archive.org", entity, excludes),
    ]


def _company_dork_queries(entity: str, excludes: list[str]) -> list[str]:
    return [
        _site_query("linkedin.com/company", entity, excludes),
        _site_query("opencorporates.com", entity, excludes),
        _site_query("find-and-update.company-information.service.gov.uk", entity, excludes),
        _site_query("opensanctions.org", entity, excludes),
        _site_query("wikidata.org", entity, excludes),
        _site_query("github.com", entity, excludes),
        _query_with_terms(entity, ["press"], excludes),
        _query_with_terms(entity, ["filing"], excludes),
        _query_with_terms(entity, ["registry"], excludes),
    ]


def _archive_queries(entity: str, excludes: list[str]) -> list[str]:
    return [
        _site_query("web.archive.org", entity, excludes),
        _query_with_terms(entity, ["archive"], excludes),
        _query_with_terms(entity, ["cached"], excludes),
        _query_with_terms(entity, ["historical"], excludes),
    ]


def _contact_queries(entity: str, excludes: list[str]) -> list[str]:
    return [
        _query_with_terms(entity, ["email"], excludes),
        _query_with_terms(entity, ["contact"], excludes),
        _query_with_terms(entity, ["press contact"], excludes),
        _query_with_terms(entity, ["support email"], excludes),
    ]


def _scope_site_queries(scope: ResolvedScope, entity: str, excludes: list[str]) -> dict[str, list[str]]:
    path = scope.path
    registry_scope = scope.registry_scope
    rows: dict[str, list[str]] = {}

    if registry_scope == "developer_footprint" or path.startswith("/dev"):
        rows["public_code_search"] = [
            _site_query("github.com", entity, excludes),
            _site_query("gitlab.com", entity, excludes),
            _query_with_terms(entity, ["repository"], excludes),
        ]
        rows["github"] = [_site_query("github.com", entity, excludes)]
        rows["gitlab"] = [_site_query("gitlab.com", entity, excludes)]

    if registry_scope == "media" or path.startswith("/creator"):
        music_scope = "music" in path
        rows["creator_video_search"] = [
            _site_query("youtube.com", entity, excludes),
            _query_with_terms(entity, ["channel"], excludes),
            _query_with_terms(entity, ["video"], excludes),
        ]
        rows["public_social_intel"] = [
            _query_with_terms(entity, ["creator"], excludes),
            _query_with_terms(entity, ["social"], excludes),
        ]
        if music_scope:
            rows["creator_video_search"].extend(
                [
                    _query_with_terms(entity, ["music video"], excludes),
                    _query_with_terms(entity, ["official audio"], excludes),
                    _query_with_terms(entity, ["artist channel"], excludes),
                ]
            )
            rows["public_social_intel"].extend(
                [
                    _query_with_terms(entity, ["artist"], excludes),
                    _query_with_terms(entity, ["musician"], excludes),
                    _query_with_terms(entity, ["producer"], excludes),
                ]
            )
            rows["social_profiles"] = [
                _site_query("vk.com", entity, excludes),
                _site_query("instagram.com", entity, excludes),
                _site_query("youtube.com", entity, excludes),
                _site_query("tiktok.com", entity, excludes),
                _site_query("t.me", entity, excludes),
            ]
            rows["web_search"] = [
                *_music_site_queries(entity, excludes),
                _query_with_terms(entity, ["lyrics"], excludes),
                _query_with_terms(entity, ["discography"], excludes),
                _query_with_terms(entity, ["artist"], excludes),
            ]

    if registry_scope == "business":
        rows["news_mentions"] = [
            _query_with_terms(entity, ["company"], excludes),
            _query_with_terms(entity, ["funding"], excludes),
            _query_with_terms(entity, ["registry"], excludes),
        ]
        _extend_rows(rows, "web_search", _company_dork_queries(entity, excludes))
        rows["archive_discovery"] = _archive_queries(entity, excludes)
        rows["contact_discovery"] = _contact_queries(entity, excludes)
        rows["social_profiles"] = [
            _site_query("linkedin.com/company", entity, excludes),
            _site_query("x.com", entity, excludes),
            _site_query("twitter.com", entity, excludes),
            _site_query("instagram.com", entity, excludes),
            _site_query("facebook.com", entity, excludes),
            _site_query("youtube.com", entity, excludes),
        ]
        rows["github"] = [_site_query("github.com", entity, excludes)]
        rows["gitlab"] = [_site_query("gitlab.com", entity, excludes)]
        rows["public_social_intel"] = [
            _query_with_terms(entity, ["official social"], excludes),
            _query_with_terms(entity, ["profile"], excludes),
        ]
        rows["public_code_search"] = [
            _site_query("github.com", entity, excludes),
            _query_with_terms(entity, ["developer"], excludes),
        ]

    if registry_scope == "infrastructure":
        rows["public_code_search"] = [
            _site_query("github.com", entity, excludes),
            _query_with_terms(entity, ["filetype:pdf"], excludes),
        ]
        rows["web_search"] = [
            _query_with_terms(entity, ["dns"], excludes),
            _query_with_terms(entity, ["subdomain"], excludes),
            _query_with_terms(entity, ["certificate"], excludes),
        ]
        _extend_rows(rows, "web_search", _domain_dork_queries(entity, excludes))
        rows["archive_discovery"] = [
            *_archive_queries(entity, excludes),
            _site_query("index.commoncrawl.org", entity, excludes),
        ]
        rows["contact_discovery"] = _contact_queries(entity, excludes)

    if registry_scope == "threat_intel":
        rows["web_search"] = [
            _query_with_terms(entity, ["threat"], excludes),
            _query_with_terms(entity, ["reputation"], excludes),
            _query_with_terms(entity, ["ioc"], excludes),
        ]
        rows["open_threat_feeds"] = [_query_with_terms(entity, ["ioc"], excludes)]

    if registry_scope in {"identity_enrichment", "social_profiles"}:
        rows["web_search"] = [
            _query_with_terms(entity, ["profile"], excludes),
            _query_with_terms(entity, ["account"], excludes),
        ]
        rows["github"] = [_site_query("github.com", entity, excludes)]
        rows["social_profiles"] = [
            _query_with_terms(entity, ["profile"], excludes),
            *_social_site_queries(entity, excludes),
        ]

    if registry_scope == "archive":
        rows["archive_discovery"] = _archive_queries(entity, excludes)
        rows["wayback"] = [_query_with_terms(entity, ["archive"], excludes)]
        rows["web_search"] = [_query_with_terms(entity, ["history"], excludes)]

    return rows


def expand_search_queries(
    entity: str,
    entity_type: str,
    parsed: ParsedSearchQuery,
    scope: ResolvedScope,
) -> ExpandedQuery:
    clean_entity = str(entity or "").strip()
    terms: list[str] = []
    for term in [*scope.search_terms, *parsed.boost_terms, *parsed.free_terms]:
        _append_unique(terms, term)
    excludes: list[str] = []
    for term in parsed.exclude_terms:
        _append_unique(excludes, term)

    queries: list[str] = []
    if clean_entity:
        _append_unique(queries, clean_entity)
        _append_unique(queries, _quote(clean_entity))
        for term in terms[:8]:
            _append_unique(queries, _query_with_terms(clean_entity, [term], excludes))
        if terms:
            _append_unique(queries, _query_with_terms(clean_entity, terms[:4], excludes))

    source_queries = _scope_site_queries(scope, clean_entity, excludes) if clean_entity else {}
    for rows in source_queries.values():
        for query in rows:
            _append_unique(queries, query)

    return ExpandedQuery(
        entity=clean_entity,
        entity_type=str(entity_type or "").strip().lower(),
        scope_path=scope.path,
        terms=terms,
        excludes=excludes,
        queries=queries,
        source_queries={key: list(dict.fromkeys(value)) for key, value in source_queries.items()},
    )
