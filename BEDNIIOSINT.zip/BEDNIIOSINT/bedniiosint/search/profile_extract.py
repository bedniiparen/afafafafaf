from __future__ import annotations

"""Content-level profile verification and extraction."""

import html as html_lib
import logging
import re
from typing import Any, Callable

try:
    from bs4 import BeautifulSoup  # type: ignore

    _HAS_BS4 = True
except Exception:  # pragma: no cover - BeautifulSoup is optional
    _HAS_BS4 = False

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
HANDLE_RE = re.compile(r"(?<![\w@])@([A-Za-z0-9_.]{2,32})")
LINK_RE = re.compile(r'href=["\']([^"\']+)["\']', re.IGNORECASE)
TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
logger = logging.getLogger(__name__)


def _meta(html: str, prop: str) -> str:
    pattern = re.compile(
        r'<meta[^>]+(?:property|name)=["\']'
        + re.escape(prop)
        + r'["\'][^>]*content=["\']([^"\']*)["\']',
        re.IGNORECASE,
    )
    match = pattern.search(html)
    if match:
        return match.group(1).strip()
    pattern_rev = re.compile(
        r'<meta[^>]+content=["\']([^"\']*)["\'][^>]*(?:property|name)=["\']'
        + re.escape(prop)
        + r'["\']',
        re.IGNORECASE,
    )
    match = pattern_rev.search(html)
    return match.group(1).strip() if match else ""


def _clean(value: str) -> str:
    text = html_lib.unescape(value or "")
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def extract_profile(html: str, *, base_url: str = "") -> dict[str, Any]:
    """Parse a profile page into structured fields."""
    del base_url
    html = html or ""
    title = ""
    description = ""
    image = ""
    full_name = ""

    if _HAS_BS4:
        try:
            soup = BeautifulSoup(html, "html.parser")
            if soup.title and soup.title.string:
                title = _clean(soup.title.string)
            for prop in ("og:title", "twitter:title"):
                tag = soup.find("meta", attrs={"property": prop}) or soup.find("meta", attrs={"name": prop})
                if tag and tag.get("content"):
                    full_name = _clean(str(tag["content"]))
                    break
            for prop in ("og:description", "twitter:description", "description"):
                tag = soup.find("meta", attrs={"property": prop}) or soup.find("meta", attrs={"name": prop})
                if tag and tag.get("content"):
                    description = _clean(str(tag["content"]))
                    break
            tag = soup.find("meta", attrs={"property": "og:image"})
            if tag and tag.get("content"):
                image = str(tag["content"]).strip()
        except Exception as exc:
            logger.debug("profile_extract: meta parsing failed: %s", exc)

    if not title:
        match = TITLE_RE.search(html)
        title = _clean(match.group(1)) if match else ""
    if not full_name:
        full_name = _clean(_meta(html, "og:title") or _meta(html, "twitter:title"))
    if not description:
        description = _clean(
            _meta(html, "og:description")
            or _meta(html, "twitter:description")
            or _meta(html, "description")
        )
    if not image:
        image = _meta(html, "og:image")

    emails = sorted(set(EMAIL_RE.findall(html)))
    handles = sorted(set(HANDLE_RE.findall(html)))
    links = sorted({link for link in LINK_RE.findall(html) if link.startswith("http")})

    return {
        "title": title,
        "full_name": full_name or title,
        "description": description,
        "avatar_url": image,
        "emails": emails,
        "handles": handles,
        "links": links[:50],
        "verified_content": bool(title or full_name or description),
    }


def _default_fetch_text(url: str) -> tuple[int, str]:
    from ..core.http import request

    response = request("GET", url, headers={"User-Agent": "bedniiosint-osint/1.0"})
    status = int(getattr(response, "status_code", 0) or 0)
    try:
        return status, response.text or ""
    except Exception:
        return status, ""


def enrich_results(
    results: list[dict[str, Any]],
    *,
    fetch_text: Callable[[str], tuple[int, str]] | None = None,
    limit: int = 50,
    confidence_bonus: float = 0.05,
) -> int:
    """Fetch and extract content for found profile results."""
    fetcher = fetch_text or _default_fetch_text
    enriched = 0
    for result in results[: max(0, limit)]:
        if not isinstance(result, dict):
            continue
        url = str(result.get("url") or "")
        if not url.startswith("http"):
            continue
        normalized = result.setdefault("normalized_data", {})
        if not isinstance(normalized, dict) or normalized.get("profile"):
            continue
        status, html = fetcher(url)
        if status >= 400 or not html:
            continue
        profile = extract_profile(html, base_url=url)
        if not profile.get("verified_content"):
            continue
        normalized["profile"] = profile
        if profile.get("full_name"):
            normalized.setdefault("full_name", profile["full_name"])
        if profile.get("avatar_url"):
            normalized.setdefault("avatar_url", profile["avatar_url"])
        pivots = normalized.setdefault("pivots", [])
        if isinstance(pivots, list):
            for email in profile.get("emails", []):
                pivots.append({"type": "email", "value": email})
            for handle in profile.get("handles", []):
                pivots.append({"type": "username", "value": handle})
        try:
            result["confidence_score"] = round(
                min(0.98, float(result.get("confidence_score") or 0.0) + confidence_bonus),
                3,
            )
        except (TypeError, ValueError):
            pass
        enriched += 1
    return enriched
