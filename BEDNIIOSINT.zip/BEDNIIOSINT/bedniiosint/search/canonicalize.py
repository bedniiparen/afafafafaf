from __future__ import annotations

"""URL canonicalization + cross-source de-duplication."""

from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .models import SearchResult


_TRACKING_PREFIXES = ("utm_",)
_TRACKING_KEYS = frozenset(
    {
        "fbclid",
        "gclid",
        "yclid",
        "igshid",
        "ref",
        "ref_src",
        "ref_url",
        "source",
        "mc_cid",
        "mc_eid",
        "spm",
        "_ga",
    }
)
_HOST_PREFIXES = ("www.", "m.", "mobile.", "i.")


def canonical_url(url: str) -> str:
    raw = (url or "").strip()
    if not raw:
        return ""
    if "://" not in raw:
        raw = "https://" + raw
    try:
        parts = urlsplit(raw)
    except ValueError:
        return raw.lower().rstrip("/")
    scheme = "https"
    host = (parts.hostname or "").lower()
    for prefix in _HOST_PREFIXES:
        if host.startswith(prefix):
            host = host[len(prefix) :]
            break
    if parts.port and parts.port not in (80, 443):
        host = f"{host}:{parts.port}"
    query_pairs = [
        (key, value)
        for key, value in parse_qsl(parts.query, keep_blank_values=False)
        if key.lower() not in _TRACKING_KEYS
        and not any(key.lower().startswith(prefix) for prefix in _TRACKING_PREFIXES)
    ]
    query = urlencode(sorted(query_pairs))
    path = parts.path.rstrip("/") or ""
    return urlunsplit((scheme, host, path, query, "")).lower()


def _dedupe_key(result: SearchResult) -> str:
    canon = canonical_url(result.url)
    if canon:
        return f"url:{canon}"
    entity = (result.matched_entity or result.entity_input or "").lower()
    return f"id:{result.source_id}|{entity}|{(result.title or '').lower()}"


def _merge_unique(target: list[str], extra: list[str]) -> None:
    for value in extra:
        if value and value not in target:
            target.append(value)


def _is_review_only(result: SearchResult) -> bool:
    return (
        "review_only" in result.tags
        or "review_only" in result.risk_flags
        or bool(result.normalized_data.get("review_only"))
    )


def dedupe_and_merge(
    results: list[SearchResult],
    *,
    corroboration_step: float = 0.05,
    corroboration_cap: float = 0.2,
) -> list[SearchResult]:
    groups: dict[str, list[SearchResult]] = {}
    order: list[str] = []
    for result in results:
        key = _dedupe_key(result)
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(result)

    merged: list[SearchResult] = []
    for key in order:
        bucket = groups[key]
        if len(bucket) == 1:
            merged.append(bucket[0])
            continue
        bucket.sort(key=lambda item: float(item.confidence_score or 0.0), reverse=True)
        best = bucket[0]
        distinct_sources = {item.source_id for item in bucket if item.source_id}
        for other in bucket[1:]:
            _merge_unique(best.tags, other.tags)
            _merge_unique(best.risk_flags, [flag for flag in other.risk_flags if flag != "single_source"])
            best.evidence.extend(other.evidence)
        review_only_bucket = any(_is_review_only(item) for item in bucket)
        if len(distinct_sources) > 1 and not review_only_bucket:
            boost = min(corroboration_cap, corroboration_step * (len(distinct_sources) - 1))
            best.confidence_score = round(min(1.0, float(best.confidence_score or 0.0) + boost), 3)
            if "corroborated" not in best.tags:
                best.tags.append("corroborated")
            if "single_source" in best.risk_flags:
                best.risk_flags.remove("single_source")
        if isinstance(best.normalized_data, dict):
            best.normalized_data["canonical_url"] = canonical_url(best.url)
            best.normalized_data["merged_sources"] = sorted(distinct_sources)
            best.normalized_data["merged_count"] = len(bucket)
        merged.append(best)
    return merged
