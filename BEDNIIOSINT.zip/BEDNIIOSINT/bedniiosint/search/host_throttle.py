from __future__ import annotations

"""Per-host token-bucket rate limiting, adaptive backoff and negative cache."""

import threading
import time
from dataclasses import dataclass
from typing import Any, Callable
from urllib.parse import urlparse


def host_of(url: str) -> str:
    try:
        return (urlparse(url).netloc or "").lower()
    except Exception:
        return ""


@dataclass
class _Bucket:
    rate: float
    capacity: float
    tokens: float
    last: float


class HostThrottle:
    def __init__(
        self,
        *,
        default_rate: float = 5.0,
        burst: float = 5.0,
        min_rate: float = 0.5,
        max_rate: float = 20.0,
        recover_step: float = 0.5,
        clock: Callable[[], float] | None = None,
        sleep: Callable[[float], None] | None = None,
    ) -> None:
        self.default_rate = float(default_rate)
        self.burst = float(burst)
        self.min_rate = float(min_rate)
        self.max_rate = float(max_rate)
        self.recover_step = float(recover_step)
        self._clock = clock or time.monotonic
        self._sleep = sleep or time.sleep
        self._buckets: dict[str, _Bucket] = {}
        self._success: dict[str, int] = {}
        self._global_lock = threading.Lock()
        self._locks: dict[str, threading.Lock] = {}

    def _bucket(self, host: str) -> _Bucket:
        with self._global_lock:
            bucket = self._buckets.get(host)
            if bucket is None:
                now = self._clock()
                bucket = _Bucket(self.default_rate, self.burst, self.burst, now)
                self._buckets[host] = bucket
                self._locks[host] = threading.Lock()
            return bucket

    def _lock(self, host: str) -> threading.Lock:
        with self._global_lock:
            return self._locks.setdefault(host, threading.Lock())

    def acquire(self, url: str) -> float:
        """Block until a token is available for the URL host and return waited seconds."""
        host = host_of(url)
        if not host:
            return 0.0
        bucket = self._bucket(host)
        waited = 0.0
        while True:
            with self._lock(host):
                now = self._clock()
                elapsed = max(0.0, now - bucket.last)
                bucket.tokens = min(bucket.capacity, bucket.tokens + elapsed * bucket.rate)
                bucket.last = now
                if bucket.tokens >= 1.0:
                    bucket.tokens -= 1.0
                    return waited
                deficit = 1.0 - bucket.tokens
                delay = deficit / bucket.rate if bucket.rate > 0 else 0.1
            self._sleep(delay)
            waited += delay

    def record(self, url: str, status_code: int) -> None:
        """Feed response status back into the adaptive host rate."""
        host = host_of(url)
        if not host:
            return
        bucket = self._bucket(host)
        with self._lock(host):
            if status_code in {429, 503}:
                bucket.rate = max(self.min_rate, bucket.rate * 0.5)
                self._success[host] = 0
            elif 200 <= status_code < 400:
                count = self._success.get(host, 0) + 1
                self._success[host] = count
                if count >= 5:
                    bucket.rate = min(self.max_rate, bucket.rate + self.recover_step)
                    self._success[host] = 0

    def rate_for(self, url: str) -> float:
        return self._bucket(host_of(url)).rate


class NegativeCache:
    """Remember absent host/path pairs within a TTL."""

    def __init__(self, *, ttl: float = 3600.0, clock: Callable[[], float] | None = None) -> None:
        self.ttl = float(ttl)
        self._clock = clock or time.monotonic
        self._seen: dict[str, float] = {}
        self._lock = threading.Lock()

    @staticmethod
    def _key(url: str) -> str:
        parsed = urlparse(url)
        return f"{(parsed.netloc or '').lower()}{parsed.path or ''}"

    def is_absent(self, url: str) -> bool:
        key = self._key(url)
        with self._lock:
            expires = self._seen.get(key)
            if expires is None:
                return False
            if self._clock() >= expires:
                self._seen.pop(key, None)
                return False
            return True

    def mark_absent(self, url: str) -> None:
        with self._lock:
            self._seen[self._key(url)] = self._clock() + self.ttl


_ABSENT_STATUS = {404, 410}


def throttled_request(
    method: str,
    url: str,
    *,
    throttle: HostThrottle,
    negative_cache: NegativeCache | None = None,
    request_fn: Callable[..., Any] | None = None,
    **kwargs: Any,
) -> Any:
    """Acquire a host token, call request, adapt rate and update negative cache."""
    if negative_cache is not None and negative_cache.is_absent(url):
        return None
    if request_fn is None:
        from ..core.http import request as request_fn  # type: ignore

    throttle.acquire(url)
    response = request_fn(method, url, **kwargs)
    status = int(getattr(response, "status_code", 0) or 0)
    throttle.record(url, status)
    if negative_cache is not None and status in _ABSENT_STATUS:
        negative_cache.mark_absent(url)
    return response
