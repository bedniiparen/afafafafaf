from __future__ import annotations

"""Soft-404 / negative-content detection for search results."""

from dataclasses import dataclass, field
from typing import Any

from .models import SearchResult


STRONG_NEGATIVE_MARKERS: tuple[str, ...] = (
    "page not found",
    "404 not found",
    "error 404",
    "user not found",
    "account not found",
    "profile not found",
    "no such user",
    "this page isn't available",
    "this page isnt available",
    "this page is not available",
    "page no longer exists",
    "this account doesn't exist",
    "this account does not exist",
    "sorry, this page",
    "the page you requested",
    "account suspended",
    "account deleted",
    "content unavailable",
    "\u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u0430",
    "\u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d",
    "\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d",
    "\u0430\u043a\u043a\u0430\u0443\u043d\u0442 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d",
    "\u043f\u0440\u043e\u0444\u0438\u043b\u044c \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d",
    "\u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u0443\u0434\u0430\u043b\u0435\u043d\u0430",
    "\u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u0443\u0434\u0430\u043b\u0451\u043d\u0430",
    "\u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442",
    "\u043d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e",
    "\u043d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043d\u0430\u0448\u043b\u043e\u0441\u044c",
    "\u043d\u0435\u0442 \u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u043e\u0432",
)

SOFT_NEGATIVE_MARKERS: tuple[str, ...] = (
    "not found",
    "no results",
    "no result found",
    "nothing found",
    "0 results",
    "couldn't find",
    "could not find",
    "doesn't exist",
    "does not exist",
    "no longer available",
    "has been removed",
    "\u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d",
    "\u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u0430",
    "\u0443\u0434\u0430\u043b\u0435\u043d",
    "\u0443\u0434\u0430\u043b\u0451\u043d",
)

ABSENT_STATUS_CODES: frozenset[int] = frozenset({404, 410})


@dataclass
class PresenceVerdict:
    state: str
    reason: str = ""
    signals: list[str] = field(default_factory=list)

    @property
    def is_absent(self) -> bool:
        return self.state == "absent"


def _status_code(result: SearchResult) -> int | None:
    data = result.normalized_data or {}
    for key in ("status_code", "http_status", "code"):
        value = data.get(key)
        if isinstance(value, int):
            return value
        if isinstance(value, str) and value.isdigit():
            return int(value)
    raw = result.raw_data if isinstance(result.raw_data, dict) else {}
    value = raw.get("status_code")
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None


def _short_text(result: SearchResult) -> str:
    parts = [str(result.title or ""), str(result.snippet or "")]
    reason = str((result.normalized_data or {}).get("reject_reason") or "")
    if reason:
        parts.append(reason)
    return " - ".join(part for part in parts if part).lower()


def _body_text(result: SearchResult) -> str:
    raw = result.raw_data if isinstance(result.raw_data, dict) else {}
    chunks: list[str] = []
    for key in ("text", "body", "html", "error", "message", "description"):
        value = raw.get(key)
        if isinstance(value, str) and value:
            chunks.append(value)
    return " ".join(chunks).lower()


def _has_positive_signal(result: SearchResult, status: int | None) -> bool:
    data = result.normalized_data or {}
    if data.get("presence_verified") or data.get("username_in_url"):
        return True
    if str(data.get("status") or "").lower() == "exists":
        markers = data.get("markers")
        if isinstance(markers, list) and any(
            str(marker).startswith(("e_string", "e_code")) for marker in markers
        ):
            return True
    normalized = data.get("normalized_data")
    if isinstance(normalized, dict) and normalized:
        return True
    raw = result.raw_data if isinstance(result.raw_data, dict) else {}
    if isinstance(raw.get("normalized"), dict) and raw.get("normalized"):
        return True
    if status is not None and 200 <= status < 300 and data.get("structured_api_result"):
        return True
    return False


def classify_presence(result: SearchResult) -> PresenceVerdict:
    status = _status_code(result)
    short = _short_text(result)
    body = _body_text(result)
    signals: list[str] = []
    positive = _has_positive_signal(result, status)

    if status in ABSENT_STATUS_CODES:
        if positive:
            return PresenceVerdict(
                "uncertain",
                f"status {status} but positive signal",
                [f"status:{status}", "positive_signal"],
            )
        return PresenceVerdict("absent", f"http status {status}", [f"status:{status}"])

    strong_hit = next((marker for marker in STRONG_NEGATIVE_MARKERS if marker in short), None)
    if strong_hit and not positive:
        return PresenceVerdict(
            "absent",
            f"negative marker in title/snippet: {strong_hit!r}",
            [f"strong:{strong_hit}"],
        )
    if strong_hit:
        return PresenceVerdict(
            "uncertain",
            f"negative marker contradicted by positive signal: {strong_hit!r}",
            [f"strong:{strong_hit}", "positive_signal"],
        )

    soft_hit = next((marker for marker in SOFT_NEGATIVE_MARKERS if marker in short or marker in body), None)
    if soft_hit and not positive:
        bad_status = status is not None and status >= 400
        tiny_body = 0 < len(body) <= 600
        if bad_status or (soft_hit in short) or tiny_body:
            return PresenceVerdict("absent", f"soft negative marker: {soft_hit!r}", [f"soft:{soft_hit}"])
        signals.append(f"soft:{soft_hit}")

    if positive:
        signals.append("positive_signal")
        return PresenceVerdict("found", "positive existence signal", signals)

    return PresenceVerdict("found", "no negative signal", signals)


def apply_presence_filter(
    results: list[SearchResult],
    *,
    drop_absent: bool = True,
) -> list[SearchResult]:
    kept: list[SearchResult] = []
    dropped = 0
    for result in results:
        verdict = classify_presence(result)
        meta = {"state": verdict.state, "reason": verdict.reason, "signals": verdict.signals}
        if isinstance(result.normalized_data, dict):
            result.normalized_data["presence"] = meta
        if verdict.is_absent:
            dropped += 1
            if drop_absent:
                continue
            if "confirmed_absent" not in result.risk_flags:
                result.risk_flags.append("confirmed_absent")
            result.confidence_score = 0.0
            kept.append(result)
            continue
        if verdict.state == "uncertain":
            if "presence_uncertain" not in result.risk_flags:
                result.risk_flags.append("presence_uncertain")
            result.confidence_score = round(float(result.confidence_score or 0.0) * 0.5, 3)
        kept.append(result)
    if kept or dropped:
        for result in kept[:1]:
            if isinstance(result.normalized_data, dict):
                result.normalized_data.setdefault("presence_filter", {})["dropped_absent"] = dropped
    return kept
