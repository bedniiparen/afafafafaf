from __future__ import annotations

"""Breach / leak lookups (Dehashed, LeakCheck, IntelX) + local combolists."""

import base64
import hashlib
import json
import logging
import os
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

logger = logging.getLogger(__name__)

MAX_COMBOLIST_HITS = 50


def _http(
    method: str,
    url: str,
    *,
    headers: dict[str, str] | None = None,
    data: bytes | None = None,
    timeout: float = 20.0,
):
    try:
        from ..core.http import request

        resp = request(method, url, headers=headers or {}, content=data)
        return getattr(resp, "status_code", None), str(getattr(resp, "text", "") or "")
    except Exception:
        pass
    try:
        req = urllib.request.Request(
            url,
            data=data,
            method=method,
            headers=headers or {"User-Agent": "bedniiosint"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as handle:  # noqa: S310
            status = getattr(handle, "status", None) or handle.getcode()
            return status, handle.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, ""
    except Exception:
        return None, None


def _mask_password(password: str) -> str:
    if not password:
        return ""
    if len(password) <= 2:
        return "*" * len(password)
    return password[0] + "*" * (len(password) - 2) + password[-1]


def _pw_fingerprint(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8", "replace")).hexdigest()[:12] if password else ""


def _make_result(
    *,
    source: str,
    entity_value: str,
    entity_type: str,
    title: str,
    snippet: str,
    confidence: float,
    data: Any,
) -> Any:
    from .models import SearchResult

    rid = hashlib.sha1(f"{source}:{entity_value}:{title}".encode("utf-8")).hexdigest()[:14]
    return SearchResult(
        id=f"breach:{rid}",
        source_id=f"api:breach:{source}",
        source_name=f"Breach ({source})",
        entity_input=entity_value,
        entity_type=entity_type,
        matched_entity=entity_value,
        url="",
        title=title,
        snippet=snippet,
        confidence_score=confidence,
        tags=["breach", "leak", source],
        risk_flags=["exposed_credentials"],
        normalized_data={"breach": {"source": source, "detail": data}},
    )


def _dehashed(entity_value: str, entity_type: str, *, settings: Any) -> list[Any]:
    key = getattr(settings, "dehashed_api_key", "")
    email = getattr(settings, "dehashed_username", "")
    if not key or not email:
        return []
    field = {"email": "email", "username": "username", "phone": "phone"}.get(entity_type, "email")
    query = urllib.parse.quote(f"{field}:{entity_value}")
    url = f"https://api.dehashed.com/search?query={query}"
    token = base64.b64encode(f"{email}:{key}".encode()).decode()
    headers = {"Accept": "application/json", "Authorization": f"Basic {token}"}
    _status, text = _http("GET", url, headers=headers)
    if not text:
        return []
    out: list[Any] = []
    try:
        entries = json.loads(text).get("entries") or []
    except Exception:
        return []
    for entry in entries[:MAX_COMBOLIST_HITS]:
        db_name = entry.get("database_name") or "unknown"
        password = entry.get("password") or ""
        snippet = (
            f"db={db_name} user={entry.get('username')} "
            f"pass={_mask_password(password)} fp={_pw_fingerprint(password)}"
        )
        detail = {
            key: entry.get(key)
            for key in ("database_name", "username", "email", "phone")
            if entry.get(key)
        }
        out.append(
            _make_result(
                source="dehashed",
                entity_value=entity_value,
                entity_type=entity_type,
                title=f"Found in {db_name}",
                snippet=snippet,
                confidence=0.85,
                data=detail,
            )
        )
    return out


def _leakcheck(entity_value: str, entity_type: str, *, settings: Any) -> list[Any]:
    key = getattr(settings, "leakcheck_api_key", "")
    if not key:
        return []
    url = f"https://leakcheck.io/api/v2/query/{urllib.parse.quote(entity_value)}"
    headers = {"Accept": "application/json", "X-API-Key": key}
    _status, text = _http("GET", url, headers=headers)
    if not text:
        return []
    out: list[Any] = []
    try:
        payload = json.loads(text)
    except Exception:
        return []
    for item in (payload.get("result") or [])[:MAX_COMBOLIST_HITS]:
        source_value = item.get("source")
        source_name = source_value.get("name") if isinstance(source_value, dict) else source_value
        fields = ",".join(item.get("fields", []) or [])
        snippet = f"source={source_name} fields={fields}"
        out.append(
            _make_result(
                source="leakcheck",
                entity_value=entity_value,
                entity_type=entity_type,
                title=f"Found in {source_name}",
                snippet=snippet,
                confidence=0.8,
                data=item,
            )
        )
    return out


def _intelx(entity_value: str, entity_type: str, *, settings: Any) -> list[Any]:
    key = getattr(settings, "intelx_api_key", "")
    if not key:
        return []
    base = getattr(settings, "intelx_base_url", "") or "https://2.intelx.io"
    body = json.dumps({"term": entity_value, "maxresults": 20, "media": 0, "sort": 4}).encode()
    headers = {"x-key": key, "Content-Type": "application/json"}
    _status, text = _http("POST", f"{base}/intelligent/search", headers=headers, data=body)
    if not text:
        return []
    try:
        search_id = json.loads(text).get("id")
    except Exception:
        return []
    if not search_id:
        return []
    _status, text = _http(
        "GET",
        f"{base}/intelligent/search/result?id={search_id}",
        headers={"x-key": key},
    )
    if not text:
        return []
    out: list[Any] = []
    try:
        records = json.loads(text).get("records") or []
    except Exception:
        return []
    for record in records[:MAX_COMBOLIST_HITS]:
        snippet = f"bucket={record.get('bucket')} name={record.get('name')} date={record.get('date')}"
        detail = {
            key: record.get(key)
            for key in ("bucket", "name", "date", "media")
            if record.get(key)
        }
        out.append(
            _make_result(
                source="intelx",
                entity_value=entity_value,
                entity_type=entity_type,
                title=record.get("name") or "IntelX record",
                snippet=snippet,
                confidence=0.7,
                data=detail,
            )
        )
    return out


def _configured_paths(raw_paths: Any) -> list[str]:
    if isinstance(raw_paths, str):
        return [item.strip() for item in raw_paths.split(",") if item.strip()]
    return [str(item).strip() for item in (raw_paths or []) if str(item).strip()]


def _combolists(entity_value: str, entity_type: str, *, settings: Any) -> list[Any]:
    paths = _configured_paths(getattr(settings, "combolist_paths", ""))
    needle = entity_value.strip().lower()
    if not needle or not paths:
        return []
    out: list[Any] = []
    hits = 0
    for path in paths:
        if not path or not os.path.isfile(path):
            continue
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    if hits >= MAX_COMBOLIST_HITS:
                        break
                    if needle not in line.lower():
                        continue
                    login, separator, password = line.strip().partition(":")
                    if not separator:
                        login, separator, password = line.strip().partition(";")
                    if needle not in login.lower():
                        continue
                    snippet = (
                        f"file={os.path.basename(path)} login={login} "
                        f"pass={_mask_password(password)} fp={_pw_fingerprint(password)}"
                    )
                    out.append(
                        _make_result(
                            source="combolist",
                            entity_value=entity_value,
                            entity_type=entity_type,
                            title=f"Found in {os.path.basename(path)}",
                            snippet=snippet,
                            confidence=0.6,
                            data={
                                "file": os.path.basename(path),
                                "login": login,
                                "password_fingerprint": _pw_fingerprint(password),
                            },
                        )
                    )
                    hits += 1
        except Exception:
            logger.warning("cannot scan combolist: %s", path)
    return out


def check_breaches(entity_value: str, entity_type: str, *, settings: Any | None = None) -> list[Any]:
    if not entity_value or entity_type not in ("email", "username", "phone"):
        return []
    if settings is None or not getattr(settings, "breach_enabled", True):
        return []
    out: list[Any] = []
    for fn in (_dehashed, _leakcheck, _intelx, _combolists):
        try:
            out.extend(fn(entity_value, entity_type, settings=settings))
        except Exception:
            logger.exception("breach source failed: %s", getattr(fn, "__name__", fn))
    return out
