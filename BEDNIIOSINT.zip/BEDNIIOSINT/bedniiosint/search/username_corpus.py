from __future__ import annotations

"""Username site corpus loader with autosync (WhatsMyName + Maigret)."""

import json
import logging
import time
import urllib.request
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

WMN_DATA_URL = "https://raw.githubusercontent.com/WebBreacher/WhatsMyName/main/wmn-data.json"
MAIGRET_DATA_URL = "https://raw.githubusercontent.com/soxoj/maigret/main/maigret/resources/data.json"
DEFAULT_TTL_SECONDS = 7 * 24 * 3600


def _resolve_settings(settings: Any | None) -> Any | None:
    if settings is not None:
        return settings
    try:
        from ..config import settings as global_settings

        return global_settings
    except Exception:
        return None


def _cache_dir(settings: Any | None) -> Path:
    base = getattr(settings, "username_corpus_cache_dir", "") if settings else ""
    path = Path(base) if base else Path.home() / ".cache" / "bedniiosint" / "username_corpus"
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception:
        logger.warning("cannot create username corpus cache dir: %s", path)
    return path


def _http_get(url: str, *, timeout: float = 30.0) -> str | None:
    try:
        from ..core.http import request

        resp = request("GET", url)
        status = getattr(resp, "status_code", 0)
        if status and status < 400:
            return str(resp.text or "")
        return None
    except Exception:
        pass
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "bedniiosint-corpus"})
        with urllib.request.urlopen(req, timeout=timeout) as handle:  # noqa: S310
            return handle.read().decode("utf-8", "replace")
    except Exception:
        logger.warning("username corpus fetch failed: %s", url)
        return None


def _load_or_sync(path: Path, url: str, ttl: float, force_refresh: bool) -> Any | None:
    fresh = path.exists() and not force_refresh and (time.time() - path.stat().st_mtime) < ttl
    if fresh:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            logger.warning("corrupt corpus cache, refetching: %s", path)
    raw = _http_get(url)
    if raw is None:
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                return None
        return None
    try:
        data = json.loads(raw)
    except Exception:
        logger.warning("corpus payload is not valid JSON: %s", url)
        return None
    try:
        path.write_text(json.dumps(data), encoding="utf-8")
    except Exception:
        pass
    return data


def _wmn_sites(payload: Any) -> list[dict[str, Any]]:
    raw = payload.get("sites") if isinstance(payload, dict) else payload
    out: list[dict[str, Any]] = []
    for site in raw or []:
        if not isinstance(site, dict) or not site.get("uri_check"):
            continue
        out.append(
            {
                "name": site.get("name"),
                "uri_check": site.get("uri_check"),
                "e_code": site.get("e_code"),
                "e_string": site.get("e_string"),
                "m_code": site.get("m_code"),
                "m_string": site.get("m_string"),
                "cat": site.get("cat", "other"),
                "corpus_source": "wmn",
            }
        )
    return out


def _maigret_sites(payload: Any) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    placeholder = "{username}"
    target = "{account}"
    for name, site in (payload or {}).items():
        if not isinstance(site, dict):
            continue
        url = site.get("url") or site.get("urlMain")
        if not url or placeholder not in str(url):
            continue
        errors = site.get("errors") or {}
        check_type = site.get("checkType") or site.get("check_type")
        tags = site.get("tags") or ["other"]
        out.append(
            {
                "name": name,
                "uri_check": str(url).replace(placeholder, target),
                "e_code": 200 if check_type == "status_code" else None,
                "e_string": None,
                "m_code": None,
                "m_string": next(iter(errors), None),
                "cat": tags[0] if tags else "other",
                "corpus_source": "maigret",
            }
        )
    return out


def _bundled_path() -> Path:
    return Path(__file__).resolve().parents[1] / "data" / "wmn-data.json"


def _synced_sites(settings: Any | None, *, force_refresh: bool, ttl: float) -> list[dict[str, Any]]:
    if not bool(getattr(settings, "username_corpus_sync_enabled", True)):
        return []
    cache = _cache_dir(settings)
    sites: list[dict[str, Any]] = []
    for url, parser, filename in (
        (WMN_DATA_URL, _wmn_sites, "wmn-sync.json"),
        (MAIGRET_DATA_URL, _maigret_sites, "maigret-sync.json"),
    ):
        payload = _load_or_sync(cache / filename, url, ttl, force_refresh)
        if payload:
            sites.extend(parser(payload))
    return sites


def _dedupe(sites: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for site in sites:
        name = str(site.get("name") or "").strip().lower()
        uri = str(site.get("uri_check") or "").strip()
        if not name or not uri:
            continue
        merged.setdefault(name, site)
    return list(merged.values())


def load_username_sites(
    settings: Any | None = None,
    *,
    force_refresh: bool = False,
    ttl: float | None = None,
) -> list[dict[str, Any]]:
    settings = _resolve_settings(settings)
    if ttl is None:
        ttl = float(getattr(settings, "username_corpus_ttl", DEFAULT_TTL_SECONDS) or DEFAULT_TTL_SECONDS)
    sites: list[dict[str, Any]] = []
    bundled = _bundled_path()
    if bundled.exists():
        try:
            sites.extend(_wmn_sites(json.loads(bundled.read_text(encoding="utf-8"))))
        except Exception:
            logger.warning("cannot read bundled wmn-data.json")
    sites.extend(_synced_sites(settings, force_refresh=force_refresh, ttl=ttl))
    merged = _dedupe(sites)
    logger.info("username corpus loaded: %d sites", len(merged))
    return merged


def extend_wmn_sites(base_sites: list[dict[str, Any]], settings: Any | None = None) -> list[dict[str, Any]]:
    settings = _resolve_settings(settings)
    ttl = float(getattr(settings, "username_corpus_ttl", DEFAULT_TTL_SECONDS) or DEFAULT_TTL_SECONDS)
    extra = _synced_sites(settings, force_refresh=False, ttl=ttl)
    return _dedupe([*(base_sites or []), *extra])
