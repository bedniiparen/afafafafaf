from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Sequence
from typing import Any

from ..config import settings
from .connectors.base import BaseConnector
from .models import SearchResult
from .scoring import rank_and_score
from .source_health import GLOBAL_SOURCE_HEALTH


logger = logging.getLogger("bedniiosint.search.async_pipeline")


def _finish(connector: BaseConnector, raw: Any) -> list[SearchResult]:
    parsed = connector.parse(raw)
    normalized = connector.normalize(parsed)
    normalized = connector.score(normalized)
    return connector.explain(normalized)


async def _run_one(
    connector: BaseConnector,
    entity: dict[str, Any],
    scope: str,
    variants: list[str],
    semaphore: asyncio.Semaphore,
) -> list[SearchResult]:
    async with semaphore:
        started = time.time()
        source_id = str(getattr(connector, "source_id", "") or "")
        try:
            plan = connector.build_queries(entity, scope=scope, variants=variants)
            if getattr(connector, "supports_async", False):
                raw = await connector.arun(plan)
            else:
                raw = await asyncio.to_thread(connector.run, plan)
            output = await asyncio.to_thread(_finish, connector, raw)
        except Exception as exc:
            GLOBAL_SOURCE_HEALTH.record(
                source_id,
                ok=False,
                latency=time.time() - started,
                error=f"{type(exc).__name__}: {exc}",
            )
            logger.exception("connector %s failed", source_id or "?")
            return []
        status = raw.get("status") if isinstance(raw, dict) else None
        GLOBAL_SOURCE_HEALTH.record(
            source_id,
            ok=True,
            latency=time.time() - started,
            status=status,
            results=len(output),
        )
        return output


async def run_connectors_async(
    connectors: Sequence[BaseConnector],
    entity: dict[str, Any],
    *,
    scope: str = "public_osint",
    variants: list[str] | None = None,
    query: str | None = None,
    client: Any | None = None,
) -> list[SearchResult]:
    semaphore = asyncio.Semaphore(max(1, int(settings.max_concurrency or 1)))
    tasks = [
        asyncio.create_task(
            _run_one(connector, entity, scope, variants or [], semaphore)
        )
        for connector in connectors
    ]
    gathered = await asyncio.gather(*tasks)
    results: list[SearchResult] = []
    for batch in gathered:
        results.extend(batch)
    return rank_and_score(query or str(entity.get("value") or ""), results)


def run_connectors(
    connectors: Sequence[BaseConnector],
    entity: dict[str, Any],
    *,
    scope: str = "public_osint",
    variants: list[str] | None = None,
    query: str | None = None,
) -> list[SearchResult]:
    return asyncio.run(
        run_connectors_async(
            connectors,
            entity,
            scope=scope,
            variants=variants,
            query=query,
        )
    )
