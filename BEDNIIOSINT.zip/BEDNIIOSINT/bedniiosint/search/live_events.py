from __future__ import annotations

"""Live streaming helpers for investigation waves."""

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable


Emit = Callable[[dict[str, Any]], None]
logger = logging.getLogger(__name__)


@dataclass
class WaveEmitter:
    emit: Emit | None = None
    job_id: int | None = None
    buffer: list[dict[str, Any]] = field(default_factory=list)

    def _publish(self, kind: str, **data: Any) -> dict[str, Any]:
        event = {"kind": kind, "ts": round(time.time(), 3), **data}
        if self.job_id is not None:
            event.setdefault("job_id", self.job_id)
        self.buffer.append(event)
        if self.emit is not None:
            try:
                self.emit(event)
            except Exception as exc:
                logger.debug("live_events: emit callback failed: %s", exc)
        return event

    def wave_started(self, depth: int, queued: int) -> dict[str, Any]:
        return self._publish("wave_started", depth=depth, queued=queued)

    def result_found(self, result: Any) -> dict[str, Any]:
        as_dict = result.as_dict() if hasattr(result, "as_dict") else dict(result)
        return self._publish(
            "result",
            source_id=as_dict.get("source_id"),
            url=as_dict.get("url"),
            title=as_dict.get("title"),
            confidence=as_dict.get("confidence_score"),
        )

    def pivot(self, pivot: Any) -> dict[str, Any]:
        as_dict = pivot.as_dict() if hasattr(pivot, "as_dict") else dict(pivot)
        return self._publish(
            "pivot",
            pivot_type=as_dict.get("pivot_type"),
            value=as_dict.get("value"),
            confidence=as_dict.get("confidence"),
        )

    def identity(self, identity: Any) -> dict[str, Any]:
        as_dict = identity.as_dict() if hasattr(identity, "as_dict") else dict(identity)
        return self._publish(
            "identity",
            label=as_dict.get("label"),
            status=as_dict.get("status"),
            confidence=as_dict.get("confidence"),
        )

    def wave_completed(self, depth: int, **stats: Any) -> dict[str, Any]:
        return self._publish("wave_completed", depth=depth, **stats)

    def done(self, **summary: Any) -> dict[str, Any]:
        return self._publish("done", **summary)


def sse_format(event: dict[str, Any]) -> str:
    name = str(event.get("kind") or "message")
    return f"event: {name}\ndata: {json.dumps(event, ensure_ascii=False)}\n\n"
