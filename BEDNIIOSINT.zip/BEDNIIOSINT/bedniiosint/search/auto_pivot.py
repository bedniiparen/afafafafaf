from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Iterable

from ..config import settings
from ..core.target import detect_module
from .avatar_hash import avatar_correlations
from .correlation import build_correlations
from .correlation_rules import apply_rules, load_rules
from .identity import build_identities
from .pipeline import run_planned_search_pipeline


logger = logging.getLogger("bedniiosint.search.auto_pivot")

_PIVOT_TYPE_TO_ENTITY = {
    "username": "username",
    "profile": "username",
    "email": "email",
    "domain": "domain",
    "url": "url",
    "phone": "phone",
    "company": "company",
    "music": "username",
}


@dataclass(frozen=True)
class FrontierNode:
    entity_type: str
    value: str
    depth: int
    parent: str | None = None
    reason: str = "seed"

    def key(self) -> tuple[str, str]:
        return (self.entity_type.strip().lower(), self.value.strip().lower())


def _pivot_as_dict(pivot: Any) -> dict[str, Any]:
    if isinstance(pivot, dict):
        return pivot
    if hasattr(pivot, "as_dict"):
        return pivot.as_dict()
    return {}


def _iter_pivots(payload: dict[str, Any]) -> Iterable[dict[str, Any]]:
    raw = payload.get("result_pivots") or []
    if isinstance(raw, dict):
        rows = raw.get("items") or raw.get("pivots") or []
    else:
        rows = raw
    for pivot in rows:
        info = _pivot_as_dict(pivot)
        if info:
            yield info


def _link_dict(link: Any) -> dict[str, Any]:
    if isinstance(link, dict):
        return dict(link)
    if hasattr(link, "as_dict"):
        return link.as_dict()
    return {}


def _build_enhanced_correlations(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    links: list[dict[str, Any]] = [_link_dict(link) for link in build_correlations(results)]
    try:
        rules = load_rules(settings.correlation_rules_path or None)
        links.extend(_link_dict(link) for link in apply_rules(results, rules))
    except Exception:
        logger.exception("declarative correlation rules failed")
    try:
        links.extend(_link_dict(link) for link in avatar_correlations(results))
    except Exception:
        logger.exception("avatar correlation rules failed")

    by_key: dict[tuple[str, str, tuple[str, ...]], dict[str, Any]] = {}
    for link in links:
        if not link:
            continue
        member_ids = tuple(sorted(str(item) for item in (link.get("member_ids") or [])))
        key = (str(link.get("kind") or ""), str(link.get("key") or ""), member_ids)
        existing = by_key.get(key)
        if existing is None or float(link.get("confidence") or 0.0) > float(existing.get("confidence") or 0.0):
            by_key[key] = link
    return sorted(
        by_key.values(),
        key=lambda item: (float(item.get("confidence") or 0.0), len(item.get("member_ids") or [])),
        reverse=True,
    )


def run_recursive_investigation(
    entity_input: str,
    *,
    entity_type: str | None = None,
    scope: str | None = None,
    max_depth: int | None = None,
    max_nodes: int | None = None,
    min_pivot_confidence: float | None = None,
    per_type_cap: int | None = None,
    save: bool = False,
    case_name: str | None = None,
    concurrent: bool = True,
    max_workers: int = 4,
    include_dorking: bool = False,
    include_username_scan: bool = True,
    emitter: Any | None = None,
    **pipeline_kwargs: Any,
) -> dict[str, Any]:
    max_depth = settings.autopivot_max_depth if max_depth is None else max_depth
    max_nodes = settings.autopivot_max_nodes if max_nodes is None else max_nodes
    if min_pivot_confidence is None:
        min_pivot_confidence = settings.autopivot_min_confidence
    per_type_cap = settings.autopivot_per_type_cap if per_type_cap is None else per_type_cap

    seed_type = (entity_type or detect_module(entity_input) or "").strip().lower() or "username"
    frontier: list[FrontierNode] = [FrontierNode(seed_type, entity_input, 0, None, "seed")]
    visited: set[tuple[str, str]] = set()
    type_counts: dict[str, int] = {}

    nodes: list[dict[str, Any]] = []
    waves: dict[int, list[str]] = {}
    merged: dict[str, dict[str, Any]] = {}
    started_depths: set[int] = set()
    deadline_seconds = float(getattr(settings, "investigation_deadline_seconds", 180.0))
    deadline = time.monotonic() + deadline_seconds if deadline_seconds > 0 else None

    while frontier and len(nodes) < max_nodes:
        if deadline is not None and time.monotonic() > deadline:
            logger.warning(
                "investigation deadline of %.0fs reached; returning %d partial node(s)",
                deadline_seconds,
                len(nodes),
            )
            break
        node = frontier.pop(0)
        key = node.key()
        if not node.value.strip() or key in visited:
            continue
        visited.add(key)
        type_counts[node.entity_type] = type_counts.get(node.entity_type, 0) + 1
        if per_type_cap and type_counts[node.entity_type] > per_type_cap:
            continue
        if emitter is not None and node.depth not in started_depths:
            started_depths.add(node.depth)
            queued = 1 + sum(1 for item in frontier if item.depth == node.depth)
            emitter.wave_started(node.depth, queued)

        try:
            payload = run_planned_search_pipeline(
                node.value,
                entity_type=node.entity_type,
                scope=scope,
                save=save,
                case_name=case_name,
                concurrent=concurrent,
                max_workers=max_workers,
                include_dorking=include_dorking,
                include_username_scan=include_username_scan,
                **pipeline_kwargs,
            )
        except Exception:
            logger.exception("auto-pivot node failed: %s/%s", node.entity_type, node.value)
            continue

        node_results = payload.get("search_results") or []
        for row in node_results:
            if not isinstance(row, dict):
                continue
            row["autopivot"] = {
                "depth": node.depth,
                "parent": node.parent,
                "via": node.value,
                "reason": node.reason,
            }
            if emitter is not None:
                emitter.result_found(row)
            result_id = str(row.get("id") or "")
            if result_id and result_id not in merged:
                merged[result_id] = row
            elif not result_id:
                merged[f"_{len(merged)}"] = row

        nodes.append(
            {
                "entity_type": node.entity_type,
                "value": node.value,
                "depth": node.depth,
                "parent": node.parent,
                "reason": node.reason,
                "result_count": len(node_results),
            }
        )
        waves.setdefault(node.depth, []).append(node.value)

        if node.depth >= max_depth:
            if emitter is not None:
                emitter.wave_completed(
                    node.depth,
                    value=node.value,
                    result_count=len(node_results),
                    frontier=len(frontier),
                )
            continue

        for info in _iter_pivots(payload):
            value = str(info.get("value") or "").strip()
            pivot_type = str(info.get("pivot_type") or "").strip().lower()
            confidence = float(info.get("confidence") or 0.0)
            if not value or confidence < float(min_pivot_confidence):
                continue
            next_type = _PIVOT_TYPE_TO_ENTITY.get(pivot_type, pivot_type or "username")
            next_node = FrontierNode(next_type, value, node.depth + 1, node.value, f"pivot:{pivot_type}")
            if next_node.key() in visited:
                continue
            frontier.append(next_node)
            if emitter is not None:
                emitter.pivot(info)
        if emitter is not None:
            emitter.wave_completed(
                node.depth,
                value=node.value,
                result_count=len(node_results),
                frontier=len(frontier),
            )

    results = list(merged.values())
    correlations = _build_enhanced_correlations(results)
    identities = build_identities(results)
    if emitter is not None:
        for identity in identities:
            emitter.identity(identity)
        emitter.done(nodes=len(nodes), results=len(results), correlations=len(correlations))

    output = {
        "module": "auto_pivot",
        "seed": {"entity_type": seed_type, "value": entity_input},
        "params": {
            "max_depth": max_depth,
            "max_nodes": max_nodes,
            "min_pivot_confidence": min_pivot_confidence,
            "per_type_cap": per_type_cap,
        },
        "nodes": nodes,
        "waves": {str(depth): values for depth, values in sorted(waves.items())},
        "node_count": len(nodes),
        "frontier_remaining": len(frontier),
        "truncated": bool(frontier) and len(nodes) >= max_nodes,
        "result_count": len(results),
        "search_results": results,
        "correlations": correlations,
        "identities": [identity.as_dict() for identity in identities],
    }
    if emitter is not None:
        output["live_events"] = list(emitter.buffer)
    return output
