from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Any, Callable, Iterable
from urllib.parse import urlparse


EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
URL_RE = re.compile(r"https?://[^\s\"'<>]+")
HANDLE_RE = re.compile(r"(?<![\w@])@([A-Za-z0-9_.\-]{2,32})")
HASH_KEYS = (
    "avatar_sha256",
    "body_sha256",
    "image_sha256",
    "avatar_hash",
    "avatar_phash",
    "phash",
    "image_phash",
    "sha256",
)
NAME_KEYS = ("display_name", "full_name", "name", "real_name")


@dataclass(frozen=True)
class CorrelationLink:
    kind: str
    key: str
    member_ids: list[str]
    sources: list[str]
    confidence: float
    explanation: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _norm(value: Any) -> str:
    return str(value or "").strip().lower()


def _rid(result: dict[str, Any], index: int) -> str:
    return str(result.get("id") or f"result-{index}")


def _source_of(result: dict[str, Any]) -> str:
    return _norm(result.get("source_id") or result.get("detected_platform") or result.get("source_name"))


def _blob(result: dict[str, Any]) -> str:
    parts = [result.get("title"), result.get("snippet"), result.get("url")]
    normalized = result.get("normalized_data")
    if isinstance(normalized, dict):
        parts.extend(str(value) for value in normalized.values())
    return " ".join(str(part) for part in parts if part)


def _registrable(host: str) -> str:
    host = host.lower().strip().lstrip(".")
    if host.startswith("www."):
        host = host[4:]
    labels = [label for label in host.split(".") if label]
    return ".".join(labels[-2:]) if len(labels) >= 2 else host


def _domain_of_url(url: str) -> str:
    try:
        return _registrable(urlparse(url).netloc)
    except Exception:
        return ""


def _nd(result: dict[str, Any]) -> dict[str, Any]:
    normalized = result.get("normalized_data")
    return normalized if isinstance(normalized, dict) else {}


def _rule_cross_platform_username(result: dict[str, Any]) -> Iterable[tuple[str, str]]:
    if _norm(result.get("entity_type")) in {"username", "profile"}:
        handle = _norm(result.get("matched_entity") or result.get("matched_variant"))
        if handle:
            yield ("cross_platform_username", handle)


def _rule_shared_email(result: dict[str, Any]) -> Iterable[tuple[str, str]]:
    for email in set(EMAIL_RE.findall(_blob(result))):
        yield ("shared_email", _norm(email))


def _rule_shared_avatar_hash(result: dict[str, Any]) -> Iterable[tuple[str, str]]:
    normalized = _nd(result)
    for hash_key in HASH_KEYS:
        value = _norm(normalized.get(hash_key))
        if value:
            yield ("shared_avatar_hash", value)


def _rule_same_display_name(result: dict[str, Any]) -> Iterable[tuple[str, str]]:
    normalized = _nd(result)
    for name_key in NAME_KEYS:
        value = _norm(normalized.get(name_key))
        if value and " " in value:
            yield ("same_display_name", value)


def _rule_shared_external_link(result: dict[str, Any]) -> Iterable[tuple[str, str]]:
    for url in set(URL_RE.findall(_blob(result))):
        domain = _domain_of_url(url)
        if domain:
            yield ("shared_external_link", domain)


def _rule_shared_handle(result: dict[str, Any]) -> Iterable[tuple[str, str]]:
    for handle in set(HANDLE_RE.findall(_blob(result))):
        yield ("shared_handle", _norm(handle))


RULES: list[Callable[[dict[str, Any]], Iterable[tuple[str, str]]]] = [
    _rule_cross_platform_username,
    _rule_shared_email,
    _rule_shared_avatar_hash,
    _rule_same_display_name,
    _rule_shared_external_link,
    _rule_shared_handle,
]

KIND_CONFIDENCE = {
    "shared_avatar_hash": 0.95,
    "shared_email": 0.9,
    "cross_platform_username": 0.8,
    "same_display_name": 0.6,
    "shared_handle": 0.6,
    "shared_external_link": 0.5,
}

KIND_EXPLANATION = {
    "shared_avatar_hash": "Same avatar or content hash appears across independent sources.",
    "shared_email": "Same email appears across independent sources.",
    "cross_platform_username": "Same username appears across independent platforms.",
    "same_display_name": "Same display name appears across independent sources.",
    "shared_handle": "Same @handle is mentioned across independent sources.",
    "shared_external_link": "Results point to the same external registrable domain.",
}


def build_correlations(
    results: list[dict[str, Any]],
    *,
    min_members: int = 2,
) -> list[CorrelationLink]:
    buckets: dict[tuple[str, str], dict[str, set[str]]] = {}
    for index, result in enumerate(results):
        if not isinstance(result, dict):
            continue
        result_id = _rid(result, index)
        source = _source_of(result)
        for rule in RULES:
            try:
                signals = list(rule(result))
            except Exception:
                signals = []
            for kind, signal_key in signals:
                if not signal_key:
                    continue
                bucket = buckets.setdefault((kind, signal_key), {"ids": set(), "sources": set()})
                bucket["ids"].add(result_id)
                if source:
                    bucket["sources"].add(source)

    links: list[CorrelationLink] = []
    for (kind, signal_key), bucket in buckets.items():
        ids = sorted(bucket["ids"])
        sources = sorted(bucket["sources"])
        if len(ids) < min_members or len(sources) < 2:
            continue
        confidence = KIND_CONFIDENCE.get(kind, 0.5)
        confidence = min(0.99, confidence + 0.03 * max(0, len(sources) - 2))
        links.append(
            CorrelationLink(
                kind=kind,
                key=signal_key,
                member_ids=ids,
                sources=sources,
                confidence=round(confidence, 3),
                explanation=KIND_EXPLANATION.get(kind, kind),
            )
        )

    links.sort(key=lambda link: (link.confidence, len(link.member_ids)), reverse=True)
    return links
