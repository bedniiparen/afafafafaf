from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
from typing import Any

from .planner import SearchPlan


ENTITY_EVENT_TYPES: dict[str, str] = {
    "username": "USERNAME",
    "profile": "PROFILE_URL",
    "email": "EMAILADDR",
    "domain": "DOMAIN_NAME",
    "url": "URL",
    "ip": "IP_ADDRESS",
    "phone": "PHONE_NUMBER",
    "wallet": "CRYPTO_ADDRESS",
    "company": "ORGANIZATION",
    "query": "SEARCH_QUERY",
    "fediverse_account": "FEDIVERSE_ACCOUNT",
    "image_url": "IMAGE_URL",
}

EVENT_RESULT_GROUPS: dict[str, str] = {
    "USERNAME": "profiles",
    "PROFILE_URL": "profiles",
    "PROFILE_CANDIDATE_URL": "profiles",
    "MUSIC_PROFILE": "music_platforms",
    "MUSIC_PROFILE_CANDIDATE": "music_platforms",
    "PLATFORM_SEARCH_URL": "music_platforms",
    "EMAILADDR": "emails",
    "EMAIL_LOCALPART": "emails",
    "PHONE_NUMBER": "phones",
    "DOMAIN_NAME": "domains",
    "SUBDOMAIN": "domains",
    "DNS_RECORD": "domains",
    "IP_ADDRESS": "domains",
    "URL": "mentions",
    "SEARCH_RESULT_URL": "mentions",
    "REVIEW_SEARCH_URL": "review_search",
    "MENTION": "mentions",
}

SOURCE_EVENT_IO: dict[str, dict[str, tuple[str, ...]]] = {
    "web_search": {
        "consumes": ("USERNAME", "EMAILADDR", "DOMAIN_NAME", "IP_ADDRESS", "PHONE_NUMBER", "ORGANIZATION", "URL", "SEARCH_QUERY"),
        "produces": ("SEARCH_RESULT_URL", "DOMAIN_NAME", "EMAILADDR", "PHONE_NUMBER", "MENTION"),
    },
    "github": {
        "consumes": ("USERNAME", "EMAILADDR", "DOMAIN_NAME", "ORGANIZATION"),
        "produces": ("PROFILE_URL", "USERNAME", "REPOSITORY", "EMAILADDR", "URL"),
    },
    "gitlab": {
        "consumes": ("USERNAME", "EMAILADDR", "DOMAIN_NAME", "ORGANIZATION"),
        "produces": ("PROFILE_URL", "USERNAME", "REPOSITORY", "URL"),
    },
    "public_code_search": {
        "consumes": ("EMAILADDR", "DOMAIN_NAME", "ORGANIZATION", "SEARCH_QUERY"),
        "produces": ("REPOSITORY", "USERNAME", "EMAILADDR", "DOMAIN_NAME", "URL", "MENTION"),
    },
    "social_profiles": {
        "consumes": ("USERNAME", "EMAILADDR", "ORGANIZATION"),
        "produces": ("PROFILE_URL", "USERNAME", "DISPLAY_NAME", "URL"),
    },
    "fediverse_profiles": {
        "consumes": ("FEDIVERSE_ACCOUNT", "USERNAME"),
        "produces": ("PROFILE_URL", "USERNAME", "DISPLAY_NAME", "URL"),
    },
    "public_social_intel": {
        "consumes": ("USERNAME", "DOMAIN_NAME", "ORGANIZATION", "SEARCH_QUERY"),
        "produces": ("SOCIAL_POST", "PROFILE_URL", "USERNAME", "URL", "MENTION"),
    },
    "creator_video_search": {
        "consumes": ("USERNAME", "DOMAIN_NAME", "ORGANIZATION", "SEARCH_QUERY"),
        "produces": ("MUSIC_PROFILE", "VIDEO_CHANNEL", "VIDEO", "PROFILE_URL", "URL", "MENTION"),
    },
    "email_enrichment": {
        "consumes": ("EMAILADDR",),
        "produces": ("PROFILE_URL", "USERNAME", "AVATAR", "DISPLAY_NAME"),
    },
    "email_reputation": {
        "consumes": ("EMAILADDR", "DOMAIN_NAME"),
        "produces": ("EMAILADDR", "BREACH_CONTEXT", "DOMAIN_NAME", "MENTION"),
    },
    "contact_discovery": {
        "consumes": ("DOMAIN_NAME", "EMAILADDR", "ORGANIZATION"),
        "produces": ("EMAILADDR", "PHONE_NUMBER", "HUMAN_NAME", "ORGANIZATION", "URL"),
    },
    "rdap": {
        "consumes": ("DOMAIN_NAME", "IP_ADDRESS"),
        "produces": ("DOMAIN_NAME", "EMAILADDR", "REGISTRAR", "NAMESERVER", "ASN"),
    },
    "dns": {
        "consumes": ("DOMAIN_NAME",),
        "produces": ("DNS_RECORD", "IP_ADDRESS", "DOMAIN_NAME"),
    },
    "crtsh": {
        "consumes": ("DOMAIN_NAME",),
        "produces": ("SUBDOMAIN", "DOMAIN_NAME", "SSL_CERTIFICATE"),
    },
    "wayback": {
        "consumes": ("DOMAIN_NAME", "URL", "SEARCH_QUERY"),
        "produces": ("URL", "HISTORICAL_URL", "MENTION"),
    },
    "archive_discovery": {
        "consumes": ("DOMAIN_NAME", "URL", "ORGANIZATION", "SEARCH_QUERY"),
        "produces": ("URL", "HISTORICAL_URL", "DOMAIN_NAME", "EMAILADDR", "MENTION"),
    },
    "urlscan": {
        "consumes": ("DOMAIN_NAME", "URL", "IP_ADDRESS"),
        "produces": ("URL", "DOMAIN_NAME", "IP_ADDRESS", "ASN", "WEBSERVER_BANNER"),
    },
    "passive_dns_enrichment": {
        "consumes": ("DOMAIN_NAME", "IP_ADDRESS"),
        "produces": ("DOMAIN_NAME", "SUBDOMAIN", "IP_ADDRESS", "DNS_RECORD"),
    },
    "attack_surface": {
        "consumes": ("DOMAIN_NAME", "IP_ADDRESS"),
        "produces": ("IP_ADDRESS", "OPEN_PORT", "SOFTWARE", "VULNERABILITY", "DOMAIN_NAME"),
    },
    "technology_fingerprint": {
        "consumes": ("DOMAIN_NAME", "URL"),
        "produces": ("SOFTWARE", "WEBSERVER_BANNER", "URL"),
    },
    "phone_lookup": {
        "consumes": ("PHONE_NUMBER",),
        "produces": ("PHONE_NUMBER", "CARRIER", "GEOINFO"),
    },
    "news_mentions": {
        "consumes": ("ORGANIZATION", "DOMAIN_NAME", "USERNAME", "SEARCH_QUERY"),
        "produces": ("URL", "MENTION", "PUBLICATION", "HUMAN_NAME"),
    },
    "business_knowledge_graph": {
        "consumes": ("ORGANIZATION", "DOMAIN_NAME"),
        "produces": ("ORGANIZATION", "DOMAIN_NAME", "HUMAN_NAME", "REGISTRY_RECORD"),
    },
    "open_threat_feeds": {
        "consumes": ("DOMAIN_NAME", "IP_ADDRESS", "URL", "HASH"),
        "produces": ("MALICIOUS_INDICATOR", "URL", "DOMAIN_NAME", "IP_ADDRESS"),
    },
    "ip_enrichment": {
        "consumes": ("IP_ADDRESS", "DOMAIN_NAME"),
        "produces": ("IP_ADDRESS", "ASN", "GEOINFO", "NETBLOCK"),
    },
    "ip_behavior_reputation": {
        "consumes": ("IP_ADDRESS",),
        "produces": ("IP_REPUTATION", "SCANNER_CONTEXT", "MALICIOUS_INDICATOR"),
    },
}


@dataclass(frozen=True)
class SearchEvent:
    id: str
    event_type: str
    value: str
    entity_type: str
    origin: str
    confidence: float = 1.0
    variant_kind: str = ""
    result_group: str = "other"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _stable_id(*parts: Any) -> str:
    text = "|".join(str(part or "") for part in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:14]


def _event_type_for_entity(entity_type: str) -> str:
    return ENTITY_EVENT_TYPES.get(str(entity_type or "").strip().lower(), "SEARCH_QUERY")


def _event_group(event_type: str) -> str:
    return EVENT_RESULT_GROUPS.get(str(event_type or "").strip().upper(), "other")


def _append_unique(items: list[str], value: str) -> None:
    clean = str(value or "").strip()
    if clean and clean not in items:
        items.append(clean)


def _music_scope(plan: SearchPlan) -> bool:
    resolved = getattr(plan, "resolved_scope", {}) or {}
    path = str(resolved.get("path") if isinstance(resolved, dict) else "").lower()
    scope = str(plan.scope or "").lower()
    return "music" in path or "music" in scope or "beatmaking" in path


def _target_events(plan: SearchPlan, *, limit: int = 32) -> list[SearchEvent]:
    events: list[SearchEvent] = []
    seen: set[tuple[str, str]] = set()

    def add(value: str, entity_type: str, origin: str, confidence: float, variant_kind: str = "") -> None:
        event_type = _event_type_for_entity(entity_type)
        key = (event_type, str(value or "").strip().lower())
        if not key[1] or key in seen:
            return
        seen.add(key)
        events.append(
            SearchEvent(
                id="event:" + _stable_id(event_type, value, origin),
                event_type=event_type,
                value=str(value),
                entity_type=str(entity_type or ""),
                origin=origin,
                confidence=float(confidence or 0.0),
                variant_kind=variant_kind,
                result_group=_event_group(event_type),
            )
        )

    add(plan.entity_input, plan.entity_type, "target", 1.0, "canonical")
    for variant in getattr(plan, "variant_details", [])[:limit]:
        add(
            variant.value,
            variant.entity_type,
            "planner_variant",
            variant.confidence,
            variant.kind,
        )
    if any(event.event_type == "SEARCH_QUERY" for event in events):
        return events[:limit]
    add(plan.entity_input, "query", "search_query", 0.72, "query_text")
    return events[:limit]


def _source_event_io(source: dict[str, Any]) -> tuple[list[str], list[str]]:
    source_id = str(source.get("id") or "")
    configured = SOURCE_EVENT_IO.get(source_id)
    if configured:
        return list(configured["consumes"]), list(configured["produces"])
    consumes: list[str] = []
    for entity_type in source.get("supported_entity_types") or []:
        _append_unique(consumes, _event_type_for_entity(str(entity_type)))
    produces: list[str] = []
    category = str(source.get("category") or "").lower()
    tags = {str(tag or "").lower() for tag in source.get("tags") or []}
    if "profile" in category or "profiles" in tags or "social" in tags:
        produces.extend(["PROFILE_URL", "USERNAME"])
    if "email" in category or "email" in tags:
        produces.append("EMAILADDR")
    if "domain" in tags or "dns" in tags or "infrastructure" in category:
        produces.extend(["DOMAIN_NAME", "IP_ADDRESS"])
    if "search" in category or "lead" in tags:
        produces.extend(["SEARCH_RESULT_URL", "MENTION"])
    if not produces:
        produces.append("MENTION")
    return consumes or ["SEARCH_QUERY"], list(dict.fromkeys(produces))


def _route_status(
    source_id: str,
    catalog_source_ids_by_search_id: dict[str, list[str]],
    skipped_catalog_sources: list[dict[str, Any]],
) -> str:
    mapped = catalog_source_ids_by_search_id.get(source_id, [])
    if not mapped:
        return "planned_no_catalog_adapter"
    skipped = {str(row.get("source_id") or "") for row in skipped_catalog_sources}
    if mapped and all(source_id in skipped for source_id in mapped):
        return "all_catalog_adapters_skipped"
    if any(source_id in skipped for source_id in mapped):
        return "partially_runnable"
    return "will_run"


def _synthetic_routes(plan: SearchPlan, target_event_types: set[str]) -> list[dict[str, Any]]:
    routes: list[dict[str, Any]] = []
    if "USERNAME" in target_event_types:
        routes.append(
            {
                "source_id": "dorking:sherlock_username_candidates",
                "name": "Sherlock-style username candidates",
                "kind": "synthetic",
                "run_status": "candidate_generation",
                "consumes": ["USERNAME"],
                "produces": ["PROFILE_CANDIDATE_URL"],
                "result_groups": ["profiles"],
                "catalog_source_ids": [],
                "reason": "Generate only direct profile URL candidates after per-site regex filtering.",
            }
        )
    if _music_scope(plan):
        routes.append(
            {
                "source_id": "dorking:music_platform_candidates",
                "name": "Music platform candidates",
                "kind": "synthetic",
                "run_status": "candidate_generation",
                "consumes": ["USERNAME", "SEARCH_QUERY"],
                "produces": ["MUSIC_PROFILE_CANDIDATE", "PLATFORM_SEARCH_URL"],
                "result_groups": ["music_platforms"],
                "catalog_source_ids": [],
                "reason": "Prioritize artist/profile platforms before generic search review links.",
            }
        )
    routes.append(
        {
            "source_id": "dorking:search_engine_review",
            "name": "Review-only search engine leads",
            "kind": "synthetic",
            "run_status": "review_only",
            "consumes": ["SEARCH_QUERY"],
            "produces": ["REVIEW_SEARCH_URL", "MENTION"],
            "result_groups": ["review_search", "mentions"],
            "catalog_source_ids": [],
            "reason": "Keep Google/Bing dorks separate from direct profiles and other data groups.",
        }
    )
    return routes


def _correlation_hints(plan: SearchPlan, target_events: list[SearchEvent]) -> list[dict[str, Any]]:
    event_types = {event.event_type for event in target_events}
    hints: list[dict[str, Any]] = []
    if "USERNAME" in event_types:
        hints.append(
            {
                "id": "username_to_profiles",
                "from_event": "USERNAME",
                "to_event": "PROFILE_CANDIDATE_URL",
                "priority": 90,
                "result_group": "profiles",
                "action": "Generate platform-valid profile candidates and verify only after regex/platform filters.",
            }
        )
    if _music_scope(plan):
        hints.append(
            {
                "id": "artist_to_music_platforms",
                "from_event": "USERNAME",
                "to_event": "MUSIC_PROFILE_CANDIDATE",
                "priority": 98,
                "result_group": "music_platforms",
                "action": "Check VK, Instagram, YouTube, Genius, Yandex Music and other artist platforms first.",
            }
        )
    if "EMAILADDR" in event_types:
        hints.extend(
            [
                {
                    "id": "email_localpart_to_username",
                    "from_event": "EMAILADDR",
                    "to_event": "USERNAME",
                    "priority": 72,
                    "result_group": "profiles",
                    "action": "Use the email localpart as a weak username pivot.",
                },
                {
                    "id": "email_domain_to_domain",
                    "from_event": "EMAILADDR",
                    "to_event": "DOMAIN_NAME",
                    "priority": 78,
                    "result_group": "domains",
                    "action": "Pivot the email domain into DNS, RDAP, CT and archive sources.",
                },
            ]
        )
    if "DOMAIN_NAME" in event_types:
        hints.extend(
            [
                {
                    "id": "domain_to_infrastructure",
                    "from_event": "DOMAIN_NAME",
                    "to_event": "SUBDOMAIN",
                    "priority": 86,
                    "result_group": "domains",
                    "action": "Fan out to DNS, CT, passive DNS, archives and attack-surface sources.",
                },
                {
                    "id": "domain_to_contacts",
                    "from_event": "DOMAIN_NAME",
                    "to_event": "EMAILADDR",
                    "priority": 68,
                    "result_group": "emails",
                    "action": "Extract public contact emails from registry, archive and contact providers.",
                },
            ]
        )
    if "PHONE_NUMBER" in event_types:
        hints.append(
            {
                "id": "phone_to_mentions",
                "from_event": "PHONE_NUMBER",
                "to_event": "MENTION",
                "priority": 60,
                "result_group": "phones",
                "action": "Keep phone enrichment and mention search separate from profile attribution.",
            }
        )
    return hints


def build_search_event_plan(
    plan: SearchPlan,
    *,
    catalog_source_ids_by_search_id: dict[str, list[str]] | None = None,
    skipped_catalog_sources: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    catalog_map = catalog_source_ids_by_search_id or {}
    skipped = skipped_catalog_sources or []
    target_events = _target_events(plan)
    target_event_types = {event.event_type for event in target_events}
    routes: list[dict[str, Any]] = []
    produced_counts: dict[str, int] = {}

    for source in getattr(plan, "sources", []):
        source_id = str(source.get("id") or "")
        consumes, produces = _source_event_io(source)
        consumed_target_events = [event.event_type for event in target_events if event.event_type in set(consumes)]
        for event_type in produces:
            produced_counts[event_type] = produced_counts.get(event_type, 0) + 1
        result_groups = sorted({_event_group(event_type) for event_type in produces if _event_group(event_type) != "other"})
        routes.append(
            {
                "source_id": source_id,
                "name": source.get("name") or source_id,
                "kind": "registry_source",
                "category": source.get("category") or "",
                "run_status": _route_status(source_id, catalog_map, skipped),
                "consumes": consumes,
                "consumed_target_events": consumed_target_events,
                "produces": produces,
                "result_groups": result_groups,
                "catalog_source_ids": list(catalog_map.get(source_id, [])),
                "auth_required": bool(source.get("auth_required")),
            }
        )

    for route in _synthetic_routes(plan, target_event_types):
        for event_type in route.get("produces", []):
            produced_counts[event_type] = produced_counts.get(event_type, 0) + 1
        routes.append(route)

    result_groups = sorted(
        {
            group
            for route in routes
            for group in route.get("result_groups", [])
            if group and group != "other"
        }
    )
    return {
        "style": "spiderfoot_event_fanout",
        "root_event": {
            "event_type": "ROOT",
            "value": plan.entity_input,
            "entity_type": plan.entity_type,
        },
        "target_events": [event.as_dict() for event in target_events],
        "routes": routes,
        "event_frontier": [
            {
                "event_type": event_type,
                "producers": count,
                "result_group": _event_group(event_type),
            }
            for event_type, count in sorted(produced_counts.items())
        ],
        "correlation_hints": _correlation_hints(plan, target_events),
        "result_groups_targeted": result_groups,
        "counts": {
            "target_events": len(target_events),
            "routes": len(routes),
            "correlation_hints": len(_correlation_hints(plan, target_events)),
            "produced_event_types": len(produced_counts),
        },
    }
