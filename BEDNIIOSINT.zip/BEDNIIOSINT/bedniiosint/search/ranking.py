from __future__ import annotations

import math
import re
from collections import Counter
from collections.abc import Sequence

from ..config import settings
from .models import SearchResult

try:
    from rank_bm25 import BM25Okapi

    _HAS_BM25 = True
except Exception:  # pragma: no cover - optional dependency
    _HAS_BM25 = False


_TOKEN_RE = re.compile(r"[\w]+", re.UNICODE)


def _tokenize(text: str) -> list[str]:
    return [token.lower() for token in _TOKEN_RE.findall(text or "")]


def _doc_text(result: SearchResult) -> str:
    parts = [
        result.title,
        result.snippet,
        result.url,
        result.matched_entity,
        result.detected_platform,
    ]
    return " ".join(part for part in parts if part)


def _bm25_scores(query: str, docs: list[list[str]]) -> list[float]:
    query_tokens = _tokenize(query)
    count = len(docs)
    if count == 0:
        return []
    if _HAS_BM25 and any(docs):
        bm25 = BM25Okapi(docs)
        return [float(score) for score in bm25.get_scores(query_tokens)]

    df: Counter[str] = Counter()
    for doc in docs:
        df.update(set(doc))
    scores: list[float] = []
    for doc in docs:
        tf = Counter(doc)
        score = 0.0
        for term in query_tokens:
            if term not in tf:
                continue
            idf = math.log(1.0 + count / (1.0 + df[term]))
            score += (tf[term] / (len(doc) or 1)) * idf
        scores.append(score)
    return scores


def _cosine(left: Sequence[float], right: Sequence[float]) -> float:
    numerator = sum(a * b for a, b in zip(left, right))
    left_norm = math.sqrt(sum(a * a for a in left))
    right_norm = math.sqrt(sum(b * b for b in right))
    return numerator / (left_norm * right_norm) if left_norm and right_norm else 0.0


def _embedding_rerank(query: str, results: list[SearchResult]) -> None:
    # Use the persistent embedding cache so repeated documents are embedded once.
    try:
        from .embedding_cache import embed_texts_cached
    except Exception:
        embed_texts_cached = None  # type: ignore
    vectors = None
    if embed_texts_cached is not None:
        vectors = embed_texts_cached([query] + [_doc_text(result) for result in results])
    if not vectors:
        # No embedder available -> keep the lexical (BM25) ordering unchanged.
        return
    query_vector = vectors[0]
    for result, doc_vector in zip(results, vectors[1:]):
        semantic = max(0.0, _cosine(query_vector, doc_vector))
        lexical = float(result.normalized_data.get("relevance_score") or 0.0)
        result.normalized_data["semantic_score"] = round(semantic, 4)
        result.normalized_data["relevance_score"] = round(0.5 * lexical + 0.5 * semantic, 4)


def rank_results(query: str, results: list[SearchResult]) -> list[SearchResult]:
    if not results:
        return results
    docs = [_tokenize(_doc_text(result)) for result in results]
    raw_scores = _bm25_scores(query, docs)
    top_score = max(raw_scores) if raw_scores else 0.0
    for result, score in zip(results, raw_scores):
        result.normalized_data["relevance_score"] = round(score / top_score, 4) if top_score > 0 else 0.0
    if settings.embedding_rerank_enabled:
        _embedding_rerank(query, results)
    results.sort(
        key=lambda result: float(result.normalized_data.get("relevance_score") or 0.0),
        reverse=True,
    )
    return results
