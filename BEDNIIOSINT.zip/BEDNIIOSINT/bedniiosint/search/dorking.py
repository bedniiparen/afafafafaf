from __future__ import annotations

from dataclasses import dataclass
import hashlib
import re
from typing import Any
from urllib.parse import quote_plus

from ..core.text_variants import ascii_slug
from .models import SearchResult
from .planner import SearchPlan
from .search_only_catalog import SearchOnlySite, load_search_only_sites, safe_site_key
from .username_candidates import build_username_site_candidates


MAX_QUERY_DORKS = 48
MAX_VARIANTS = 16
SEARCH_ONLY_CAPS: dict[str, int] = {"fast": 20, "standard": 60, "deep": 250}
REVIEW_ONLY_LEGAL_NOTE = "public_search_query_review_only_no_automated_scraping"
REVIEW_ONLY_SNIPPET = (
    "Review-only search lead. Open manually and corroborate before treating it as a finding."
)


@dataclass(frozen=True)
class DorkingStrategy:
    mode: str
    query_limit: int
    total_limit: int
    variant_limit: int
    search_engine_ids: tuple[str, ...]


STRATEGY_DEFAULTS: dict[str, DorkingStrategy] = {
    "fast": DorkingStrategy(
        mode="fast",
        query_limit=8,
        total_limit=90,
        variant_limit=8,
        search_engine_ids=("google",),
    ),
    "standard": DorkingStrategy(
        mode="standard",
        query_limit=18,
        total_limit=220,
        variant_limit=12,
        search_engine_ids=("google", "bing"),
    ),
    "deep": DorkingStrategy(
        mode="deep",
        query_limit=MAX_QUERY_DORKS,
        total_limit=700,
        variant_limit=MAX_VARIANTS,
        search_engine_ids=("google", "bing", "brave", "duckduckgo"),
    ),
}


PLATFORM_FILTER_ALIASES: dict[str, tuple[str, ...]] = {
    "ig": ("instagram",),
    "inst": ("instagram",),
    "instagram": ("instagram",),
    "vk": ("vk",),
    "vkontakte": ("vk",),
    "yt": ("youtube", "youtube_search", "youtube_music"),
    "youtube": ("youtube", "youtube_search", "youtube_music"),
    "youtube_music": ("youtube", "youtube_search", "youtube_music"),
    "ym": ("yandex_music",),
    "yandex": ("yandex_music",),
    "yandex_music": ("yandex_music",),
    "ya_music": ("yandex_music",),
    "genius": ("genius", "genius_search"),
    "spotify": ("spotify", "spotify_search"),
    "soundcloud": ("soundcloud", "soundcloud_search"),
    "bandcamp": ("bandcamp", "bandcamp_search"),
    "lastfm": ("lastfm", "lastfm_search"),
    "last_fm": ("lastfm", "lastfm_search"),
    "apple": ("apple_music",),
    "apple_music": ("apple_music",),
    "deezer": ("deezer", "deezer_search"),
    "musicbrainz": ("musicbrainz", "musicbrainz_search"),
    "telegram": ("telegram",),
    "tg": ("telegram",),
    "github": ("github",),
    "gitlab": ("gitlab",),
    "habr": ("habr",),
    "pikabu": ("pikabu",),
    "boosty": ("boosty",),
    "tiktok": ("tiktok",),
    "x": ("x", "twitter"),
    "twitter": ("twitter", "x"),
}


SEARCH_ENGINES: tuple[tuple[str, str, str], ...] = (
    ("google", "Google", "https://www.google.com/search?q={query}"),
    ("bing", "Bing", "https://www.bing.com/search?q={query}"),
    ("brave", "Brave Search", "https://search.brave.com/search?q={query}"),
    ("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q={query}"),
)

SOCIAL_DORKS: tuple[tuple[str, str, str], ...] = (
    ("x", "X", 'site:x.com "{value}"'),
    ("twitter", "Twitter", 'site:twitter.com "{value}"'),
    ("threads", "Threads", 'site:threads.net "{value}"'),
    ("instagram", "Instagram", 'site:instagram.com "{value}"'),
    ("linkedin_people", "LinkedIn People", 'site:linkedin.com/in "{value}"'),
    ("linkedin_company", "LinkedIn Company", 'site:linkedin.com/company "{value}"'),
    ("facebook", "Facebook", 'site:facebook.com "{value}"'),
    ("reddit", "Reddit", 'site:reddit.com "{value}"'),
    ("tiktok", "TikTok", 'site:tiktok.com "{value}"'),
    ("youtube", "YouTube", 'site:youtube.com "{value}"'),
    ("twitch", "Twitch", 'site:twitch.tv "{value}"'),
    ("medium", "Medium", 'site:medium.com "{value}"'),
    ("pinterest", "Pinterest", 'site:pinterest.com "{value}"'),
    ("telegram", "Telegram", 'site:t.me "{value}"'),
    ("vk", "VK", 'site:vk.com "{value}"'),
    ("github", "GitHub", 'site:github.com "{value}"'),
    ("gitlab", "GitLab", 'site:gitlab.com "{value}"'),
    ("stackoverflow", "Stack Overflow", 'site:stackoverflow.com/users "{value}"'),
    ("devto", "DEV Community", 'site:dev.to "{value}"'),
    ("npm", "npm", 'site:npmjs.com "~{value}" OR site:npmjs.com/package "{value}"'),
    ("pypi", "PyPI", 'site:pypi.org/user "{value}"'),
    ("mastodon", "Mastodon", 'site:mastodon.social "{value}"'),
    ("bluesky", "Bluesky", 'site:bsky.app/profile "{value}"'),
)

USERNAME_PROFILE_URLS: tuple[tuple[str, str, str], ...] = (
    ("x", "X profile candidate", "https://x.com/{username}"),
    ("twitter", "Twitter profile candidate", "https://twitter.com/{username}"),
    ("instagram", "Instagram profile candidate", "https://www.instagram.com/{username}/"),
    ("threads", "Threads profile candidate", "https://www.threads.net/@{username}"),
    ("facebook", "Facebook profile candidate", "https://www.facebook.com/{username}"),
    ("tiktok", "TikTok profile candidate", "https://www.tiktok.com/@{username}"),
    ("youtube", "YouTube handle candidate", "https://www.youtube.com/@{username}"),
    ("twitch", "Twitch profile candidate", "https://www.twitch.tv/{username}"),
    ("medium", "Medium profile candidate", "https://medium.com/@{username}"),
    ("devto", "DEV profile candidate", "https://dev.to/{username}"),
    ("telegram", "Telegram profile candidate", "https://t.me/{username}"),
    ("vk", "VK profile candidate", "https://vk.com/{username}"),
    ("boosty", "Boosty profile candidate", "https://boosty.to/{username}"),
    ("github", "GitHub profile candidate", "https://github.com/{username}"),
    ("gitlab", "GitLab profile candidate", "https://gitlab.com/{username}"),
    ("npm", "npm profile candidate", "https://www.npmjs.com/~{username}"),
    ("pypi", "PyPI profile candidate", "https://pypi.org/user/{username}/"),
    ("reddit", "Reddit profile candidate", "https://www.reddit.com/user/{username}/"),
    ("pinterest", "Pinterest profile candidate", "https://www.pinterest.com/{username}/"),
    ("habr", "Habr profile candidate", "https://habr.com/ru/users/{username}/"),
    ("pikabu", "Pikabu profile candidate", "https://pikabu.ru/@{username}"),
    ("bluesky", "Bluesky profile candidate", "https://bsky.app/profile/{username}.bsky.social"),
)

COMPANY_PROFILE_URLS: tuple[tuple[str, str, str], ...] = (
    ("linkedin", "LinkedIn company candidate", "https://www.linkedin.com/company/{slug}/"),
    ("crunchbase", "Crunchbase organization candidate", "https://www.crunchbase.com/organization/{slug}"),
    ("instagram", "Instagram company candidate", "https://www.instagram.com/{slug}/"),
    ("facebook", "Facebook company candidate", "https://www.facebook.com/{slug}/"),
    ("youtube", "YouTube company handle candidate", "https://www.youtube.com/@{slug}"),
    ("github", "GitHub organization candidate", "https://github.com/{slug}"),
    ("gitlab", "GitLab group candidate", "https://gitlab.com/{slug}"),
)

MUSIC_PROFILE_URLS: tuple[tuple[str, str, str], ...] = (
    ("vk", "VK artist/profile candidate", "https://vk.com/{alias}"),
    ("instagram", "Instagram artist/profile candidate", "https://www.instagram.com/{alias}/"),
    ("youtube", "YouTube artist handle candidate", "https://www.youtube.com/@{alias}"),
    ("genius", "Genius artist candidate", "https://genius.com/artists/{alias}"),
    ("soundcloud", "SoundCloud artist candidate", "https://soundcloud.com/{alias}"),
    ("bandcamp", "Bandcamp artist candidate", "https://{alias}.bandcamp.com"),
)

MUSIC_SEARCH_URLS: tuple[tuple[str, str, str], ...] = (
    ("vk", "VK music search", "https://vk.com/search?c%5Bq%5D={query}&c%5Bsection%5D=audio"),
    ("yandex_music", "Yandex Music search", "https://music.yandex.ru/search?text={query}"),
    ("youtube_music", "YouTube Music search", "https://music.youtube.com/search?q={query}"),
    ("youtube_search", "YouTube music search", "https://www.youtube.com/results?search_query={query}"),
    ("genius_search", "Genius search", "https://genius.com/search?q={query}"),
    ("spotify_search", "Spotify search", "https://open.spotify.com/search/{query}"),
    ("apple_music", "Apple Music search", "https://music.apple.com/search?term={query}"),
    ("soundcloud_search", "SoundCloud search", "https://soundcloud.com/search?q={query}"),
    ("bandcamp_search", "Bandcamp search", "https://bandcamp.com/search?q={query}"),
    ("lastfm_search", "Last.fm search", "https://www.last.fm/search?q={query}"),
    ("deezer_search", "Deezer search", "https://www.deezer.com/search/{query}"),
    ("musicbrainz_search", "MusicBrainz artist search", "https://musicbrainz.org/search?query={query}&type=artist&method=indexed"),
)

DOMAIN_DIRECT_URLS: tuple[tuple[str, str, str], ...] = (
    ("security_txt", "security.txt candidate", "https://{domain}/.well-known/security.txt"),
    ("robots", "robots.txt candidate", "https://{domain}/robots.txt"),
    ("sitemap", "sitemap.xml candidate", "https://{domain}/sitemap.xml"),
    ("humans", "humans.txt candidate", "https://{domain}/humans.txt"),
    ("about", "About page candidate", "https://{domain}/about"),
    ("contact", "Contact page candidate", "https://{domain}/contact"),
)

DOMAIN_DORKS: tuple[tuple[str, str, str], ...] = (
    ("site", "Indexed pages", "site:{value}"),
    ("pdf", "Public PDFs", '"{value}" filetype:pdf'),
    ("docs", "Public documents", '"{value}" (filetype:doc OR filetype:docx OR filetype:xls OR filetype:xlsx)'),
    ("slides", "Public slides", '"{value}" (filetype:ppt OR filetype:pptx)'),
    ("emails", "Public email mentions", '"@{value}"'),
    ("admin", "Admin paths", '"{value}" inurl:admin'),
    ("login", "Login paths", '"{value}" inurl:login'),
    ("api_docs", "API/docs mentions", '"{value}" (api OR swagger OR openapi OR docs)'),
    ("security_txt", "Security contact", '"{value}" "security.txt"'),
    ("github", "Code mentions", 'site:github.com "{value}"'),
    ("gitlab", "GitLab mentions", 'site:gitlab.com "{value}"'),
    ("stackoverflow", "Stack Overflow mentions", 'site:stackoverflow.com "{value}"'),
    ("pastebin", "Pastebin mentions", 'site:pastebin.com "{value}"'),
    ("reddit", "Reddit mentions", 'site:reddit.com "{value}"'),
    ("crtsh", "Certificate Transparency mentions", 'site:crt.sh "{value}"'),
    ("urlscan", "urlscan mentions", 'site:urlscan.io "{value}"'),
    ("wayback", "Wayback mentions", 'site:web.archive.org "{value}"'),
    ("commoncrawl", "Common Crawl index mentions", 'site:index.commoncrawl.org "{value}"'),
)

COMPANY_DORKS: tuple[tuple[str, str, str], ...] = (
    ("linkedin_company", "LinkedIn company pages", 'site:linkedin.com/company "{value}"'),
    ("opencorporates", "OpenCorporates mentions", 'site:opencorporates.com "{value}"'),
    ("companies_house", "Companies House mentions", 'site:find-and-update.company-information.service.gov.uk "{value}"'),
    ("opensanctions", "OpenSanctions mentions", 'site:opensanctions.org "{value}"'),
    ("wikidata", "Wikidata mentions", 'site:wikidata.org "{value}"'),
    ("crunchbase", "Crunchbase mentions", 'site:crunchbase.com/organization "{value}"'),
    ("bloomberg", "Bloomberg mentions", 'site:bloomberg.com/profile/company "{value}"'),
    ("sec", "SEC mentions", 'site:sec.gov "{value}"'),
    ("github", "Code/repo mentions", 'site:github.com "{value}"'),
    ("gitlab", "GitLab mentions", 'site:gitlab.com "{value}"'),
    ("reddit", "Reddit mentions", 'site:reddit.com "{value}"'),
    ("glassdoor", "Glassdoor mentions", 'site:glassdoor.com "{value}"'),
    ("trustpilot", "Trustpilot mentions", 'site:trustpilot.com "{value}"'),
    ("news", "News and press mentions", '"{value}" (press OR news OR interview)'),
    ("filings", "Filing mentions", '"{value}" (filing OR registry OR incorporation)'),
    ("contacts", "Public contact mentions", '"{value}" (email OR contact OR support)'),
)

MUSIC_DORKS: tuple[tuple[str, str, str], ...] = (
    ("vk", "VK music/profile pages", 'site:vk.com "{value}"'),
    ("instagram", "Instagram artist profiles", 'site:instagram.com "{value}"'),
    ("genius", "Genius artist/lyrics pages", 'site:genius.com "{value}"'),
    ("youtube", "YouTube artist/music videos", 'site:youtube.com "{value}"'),
    ("yandex_music", "Yandex Music pages", 'site:music.yandex.ru "{value}"'),
    ("spotify", "Spotify artist/search pages", 'site:open.spotify.com "{value}"'),
    ("soundcloud", "SoundCloud artist pages", 'site:soundcloud.com "{value}"'),
    ("bandcamp", "Bandcamp artist pages", 'site:bandcamp.com "{value}"'),
    ("lastfm", "Last.fm artist pages", 'site:last.fm/music "{value}"'),
    ("apple_music", "Apple Music pages", 'site:music.apple.com "{value}"'),
    ("deezer", "Deezer artist pages", 'site:deezer.com "{value}"'),
    ("musicbrainz", "MusicBrainz artist pages", 'site:musicbrainz.org "{value}"'),
    ("lyrics", "Lyrics mentions", '"{value}" lyrics'),
    ("discography", "Discography mentions", '"{value}" discography'),
)

EMAIL_DORKS: tuple[tuple[str, str, str], ...] = (
    ("exact", "Exact email mentions", '"{value}"'),
    ("github", "GitHub email mentions", 'site:github.com "{value}"'),
    ("gitlab", "GitLab email mentions", 'site:gitlab.com "{value}"'),
    ("reddit", "Reddit email mentions", 'site:reddit.com "{value}"'),
    ("pastebin", "Pastebin email mentions", 'site:pastebin.com "{value}"'),
    ("documents", "Document email mentions", '"{value}" (filetype:pdf OR filetype:doc OR filetype:docx)'),
)


def _stable_id(*parts: Any) -> str:
    text = "|".join(str(part or "") for part in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]


def _append_unique(items: list[str], value: str) -> None:
    clean = re.sub(r"\s+", " ", str(value or "").strip())
    if clean and clean not in items:
        items.append(clean)


def _clamp_int(value: Any, *, minimum: int, maximum: int, default: int) -> int:
    try:
        parsed = int(str(value).strip())
    except (TypeError, ValueError):
        return default
    return max(minimum, min(maximum, parsed))


def _parsed_filters(plan: SearchPlan) -> dict[str, str]:
    parsed = getattr(plan, "parsed_query", {}) or {}
    filters = parsed.get("filters") if isinstance(parsed, dict) else {}
    if not isinstance(filters, dict):
        return {}
    return {str(key).lower(): str(value) for key, value in filters.items() if str(value).strip()}


def _strategy(plan: SearchPlan) -> DorkingStrategy:
    filters = _parsed_filters(plan)
    raw_mode = (filters.get("mode") or filters.get("depth") or filters.get("size") or "").strip().lower()
    if raw_mode in {"quick", "small", "light"}:
        raw_mode = "fast"
    elif raw_mode in {"large", "full", "wide", "big"}:
        raw_mode = "deep"
    mode = raw_mode if raw_mode in STRATEGY_DEFAULTS else "standard"
    base = STRATEGY_DEFAULTS[mode]
    explicit_limit = filters.get("limit") or filters.get("max") or filters.get("max_results")
    total_limit = _clamp_int(explicit_limit, minimum=20, maximum=1200, default=base.total_limit)
    query_limit = min(base.query_limit, max(4, total_limit // max(1, len(base.search_engine_ids) * 3)))
    variant_limit = min(base.variant_limit, max(4, total_limit // 20))
    return DorkingStrategy(
        mode=base.mode,
        query_limit=query_limit,
        total_limit=total_limit,
        variant_limit=variant_limit,
        search_engine_ids=base.search_engine_ids,
    )


def _normalize_platform_token(value: str) -> str:
    return re.sub(r"[^a-z0-9_]+", "_", str(value or "").strip().lower()).strip("_")


def _selected_platforms(plan: SearchPlan) -> set[str]:
    filters = _parsed_filters(plan)
    raw = filters.get("platform") or filters.get("platforms") or ""
    selected: set[str] = set()
    for item in re.split(r"[,|/]+", raw):
        token = _normalize_platform_token(item)
        if not token:
            continue
        selected.add(token)
        selected.update(PLATFORM_FILTER_ALIASES.get(token, ()))
    return selected


def _platform_allowed(key: str, label: str, selected: set[str]) -> bool:
    if not selected:
        return True
    tokens = {
        _normalize_platform_token(key),
        _normalize_platform_token(label),
        *re.split(r"[_\s:/-]+", _normalize_platform_token(key)),
        *re.split(r"[_\s:/-]+", _normalize_platform_token(label)),
    }
    expanded = set(tokens)
    for token in list(tokens):
        expanded.update(PLATFORM_FILTER_ALIASES.get(token, ()))
    return bool(expanded & selected)


def _search_url(engine_id: str, query: str) -> str:
    for candidate_id, _, template in SEARCH_ENGINES:
        if candidate_id == engine_id:
            return template.format(query=quote_plus(query))
    return SEARCH_ENGINES[0][2].format(query=quote_plus(query))


def _search_engine_rows(strategy: DorkingStrategy) -> tuple[tuple[str, str, str], ...]:
    selected = set(strategy.search_engine_ids)
    return tuple(row for row in SEARCH_ENGINES if row[0] in selected)


def _search_only_limit(strategy: DorkingStrategy, selected_platforms: set[str]) -> int:
    if selected_platforms:
        return 0
    return min(SEARCH_ONLY_CAPS.get(strategy.mode, SEARCH_ONLY_CAPS["standard"]), strategy.total_limit)


def _direct_result_url(value: str) -> str:
    return str(value or "").strip()


def _catalog_profile_limit(strategy: DorkingStrategy, *, music_scope: bool, selected_platforms: set[str]) -> int:
    if selected_platforms:
        return min(strategy.total_limit, max(20, strategy.total_limit // 2))
    if music_scope:
        return min(max(20, strategy.total_limit // 4), 90)
    return min(max(40, strategy.total_limit // 2), 260)


def _safe_username(value: str) -> str:
    clean = str(value or "").strip().lstrip("@")
    if "{?}" in clean and re.fullmatch(r"[A-Za-z0-9_.{}?-]{2,70}", clean):
        return clean
    if re.fullmatch(r"[A-Za-z0-9_.-]{2,64}", clean):
        return clean
    for separator in ("_", "-", "."):
        candidate = ascii_slug(clean, separator=separator)
        if re.fullmatch(r"[A-Za-z0-9_.-]{2,64}", candidate):
            return candidate
    compact = ascii_slug(clean, separator="")
    if re.fullmatch(r"[A-Za-z0-9_.-]{2,64}", compact):
        return compact
    return ""


def _safe_slug(value: str) -> str:
    clean = ascii_slug(value, separator="-")
    if re.fullmatch(r"[a-z0-9][a-z0-9-]{1,79}", clean):
        return clean
    return ""


def _music_scope(plan: SearchPlan) -> bool:
    scope = str(plan.scope or "").lower()
    resolved = getattr(plan, "resolved_scope", {}) or {}
    path = str(resolved.get("path") if isinstance(resolved, dict) else "").lower()
    terms = " ".join(str(item or "").lower() for item in (resolved.get("search_terms", []) if isinstance(resolved, dict) else []))
    return "music" in scope or "music" in path or "music" in terms or "beatmaking" in path


def _music_aliases(values: list[str]) -> list[str]:
    aliases: list[str] = []
    for value in values:
        if "." in str(value or "") or "/" in str(value or ""):
            continue
        slug = _safe_slug(value)
        if not slug:
            continue
        _append_unique(aliases, slug)
        compact = slug.replace("-", "")
        if compact != slug:
            _append_unique(aliases, compact)
    return aliases


def _safe_domain(value: str) -> str:
    clean = str(value or "").strip().lower()
    clean = clean.removeprefix("http://").removeprefix("https://").split("/", 1)[0]
    clean = clean.split("@")[-1].split(":")[0].strip(".")
    if re.fullmatch(r"(?:[a-z0-9-]{1,63}\.)+[a-z]{2,63}", clean):
        return clean
    return ""


def _search_only_values(plan: SearchPlan, values: list[str]) -> list[str]:
    rows: list[str] = []
    entity_type = str(plan.entity_type or "").lower()
    if entity_type in {"username", "company", "query"}:
        for value in values:
            if len(str(value or "").strip()) >= 2:
                _append_unique(rows, value)
    elif entity_type == "email":
        _append_unique(rows, plan.entity_input)
        if "@" in plan.entity_input:
            _append_unique(rows, plan.entity_input.split("@", 1)[0])
    return rows[:3]


def _quote_dork_value(value: str) -> str:
    return f'"{str(value).replace(chr(34), chr(92) + chr(34))}"'


def _search_only_query(host: str, dork_values: list[str]) -> str:
    quoted = [_quote_dork_value(value) for value in dork_values if str(value or "").strip()]
    if not quoted:
        return ""
    if len(quoted) == 1:
        return f"site:{host} {quoted[0]}"
    return f"site:{host} (" + " OR ".join(quoted) + ")"


def _search_only_rows(
    plan: SearchPlan,
    values: list[str],
    strategy: DorkingStrategy,
    selected_platforms: set[str],
) -> list[tuple[SearchOnlySite, str, str]]:
    limit = _search_only_limit(strategy, selected_platforms)
    if limit <= 0:
        return []
    dork_values = _search_only_values(plan, values)
    if not dork_values:
        return []
    rows: list[tuple[SearchOnlySite, str, str]] = []
    seen: set[str] = set()
    for site in load_search_only_sites():
        if site.overlap_username_catalog:
            continue
        if site.host in seen:
            continue
        query = _search_only_query(site.host, dork_values)
        if not query:
            continue
        seen.add(site.host)
        rows.append((site, dork_values[0], query))
        if len(rows) >= limit:
            return rows
    return rows


def _variant_values(plan: SearchPlan, strategy: DorkingStrategy) -> list[str]:
    values: list[str] = []
    _append_unique(values, plan.entity_input)
    for variant in plan.variant_details:
        if variant.entity_type in {"username", "domain", "company", "email", "query"}:
            _append_unique(values, variant.value)
    return values[: strategy.variant_limit]


def _plan_queries(plan: SearchPlan, strategy: DorkingStrategy) -> list[str]:
    queries: list[str] = []
    for query_plan in plan.queries:
        for query in query_plan.queries:
            _append_unique(queries, query)
    if not queries:
        _append_unique(queries, plan.entity_input)
        _append_unique(queries, f'"{plan.entity_input}"')
    return queries[: strategy.query_limit]


def _format_templates(
    templates: tuple[tuple[str, str, str], ...],
    values: list[str],
) -> list[tuple[str, str, str]]:
    rows: list[tuple[str, str, str]] = []
    seen: set[str] = set()
    for value in values:
        for key, label, template in templates:
            query = template.format(value=value.replace('"', '\\"'))
            if query in seen:
                continue
            seen.add(query)
            rows.append((key, label, query))
    return rows


def _entity_dork_templates(plan: SearchPlan, values: list[str]) -> list[tuple[str, str, str, list[str]]]:
    entity_type = plan.entity_type
    rows: list[tuple[str, str, str, list[str]]] = []
    music_scope = _music_scope(plan)

    for key, label, query in _format_templates(SOCIAL_DORKS, values):
        rows.append((f"social:{key}", label, query, ["social", "profile"]))

    if music_scope:
        for key, label, query in _format_templates(MUSIC_DORKS, values):
            rows.append((f"music:{key}", label, query, ["music", "artist", "platform"]))
    elif entity_type in {"domain", "url"}:
        for key, label, query in _format_templates(DOMAIN_DORKS, values):
            rows.append((f"domain:{key}", label, query, ["domain", "infrastructure"]))
    elif entity_type == "company":
        for key, label, query in _format_templates(COMPANY_DORKS, values):
            rows.append((f"company:{key}", label, query, ["company", "registry"]))
    elif entity_type == "email":
        for key, label, query in _format_templates(EMAIL_DORKS, values[:3]):
            rows.append((f"email:{key}", label, query, ["email", "mention"]))
        local = plan.entity_input.split("@", 1)[0] if "@" in plan.entity_input else ""
        if local:
            for key, label, query in _format_templates(SOCIAL_DORKS, [local]):
                rows.append((f"email_social:{key}", label, query, ["email", "social"]))
    elif entity_type == "username":
        for key, label, query in _format_templates(EMAIL_DORKS[:1], values[:3]):
            rows.append((f"username:exact:{key}", label, query, ["username", "mention"]))

    return rows


def _make_result(
    *,
    plan: SearchPlan,
    source_id: str,
    source_name: str,
    title: str,
    url: str,
    query: str,
    platform: str,
    tags: list[str],
    direct_candidate: bool = False,
    lead_kind: str = "search_engine_query",
    result_group: str = "review_search",
    pivot_entity_type: str = "",
    pivot_value: str = "",
    candidate_rank: int = 0,
    extra_data: dict[str, Any] | None = None,
) -> SearchResult:
    result_id = "dorking:" + _stable_id(source_id, plan.entity_type, plan.entity_input, query, url)
    raw = {
        "query": query,
        "url": url,
        "platform": platform,
        "review_only": True,
        "manual_verification_required": True,
        "direct_candidate": direct_candidate,
        "lead_kind": lead_kind,
        "result_group": result_group,
        "pivot_entity_type": pivot_entity_type,
        "pivot_value": pivot_value,
        "candidate_rank": candidate_rank,
    }
    if extra_data:
        raw.update(extra_data)
    normalized = {
        "dorking": raw,
        "review_only": True,
        "manual_verification_required": True,
        "direct_candidate": direct_candidate,
        "lead_kind": lead_kind,
        "result_group": result_group,
        "pivot_entity_type": pivot_entity_type,
        "pivot_value": pivot_value,
        "candidate_rank": candidate_rank,
    }
    if extra_data:
        normalized.update(extra_data)
    return SearchResult(
        id=result_id,
        source_id=source_id,
        source_name=source_name,
        entity_input=plan.entity_input,
        entity_type=plan.entity_type,
        matched_entity=plan.entity_input,
        matched_variant=query,
        scope=plan.scope,
        title=title,
        url=url,
        snippet=REVIEW_ONLY_SNIPPET,
        raw_data=raw,
        normalized_data=normalized,
        detected_platform=platform,
        tags=["dorking", "review_only", "manual_verification_required", lead_kind, *tags],
        confidence_score=0.0,
        risk_flags=["review_only", "manual_verification_required", "unverified_search_lead"],
        legal_notes=REVIEW_ONLY_LEGAL_NOTE,
        explanation=(
            "Offline dorking lead generated from the target and search query expansion. "
            "It is not a finding until an analyst opens and corroborates it."
        ),
    )


def build_dorking_results(plan: SearchPlan) -> list[SearchResult]:
    strategy = _strategy(plan)
    values = _variant_values(plan, strategy)
    selected_platforms = _selected_platforms(plan)
    results: list[SearchResult] = []
    seen: set[tuple[str, str]] = set()
    candidate_rank = 0

    def add_result(
        *,
        source_id: str,
        source_name: str,
        title: str,
        url: str,
        query: str,
        platform: str,
        tags: list[str],
        direct_candidate: bool,
        lead_kind: str,
        result_group: str,
        pivot_entity_type: str,
        pivot_value: str,
        extra_data: dict[str, Any] | None = None,
    ) -> None:
        nonlocal candidate_rank
        if len(results) >= strategy.total_limit:
            return
        dedup_key = (source_id, url)
        if dedup_key in seen:
            return
        seen.add(dedup_key)
        candidate_rank += 1
        results.append(
            _make_result(
                plan=plan,
                source_id=source_id,
                source_name=source_name,
                title=title,
                url=url,
                query=query,
                platform=platform,
                tags=tags,
                direct_candidate=direct_candidate,
                lead_kind=lead_kind,
                result_group=result_group,
                pivot_entity_type=pivot_entity_type,
                pivot_value=pivot_value,
                candidate_rank=candidate_rank,
                extra_data=extra_data,
            )
        )

    music_scope = _music_scope(plan)

    if music_scope:
        aliases = _music_aliases(values)
        for alias in aliases[:8]:
            for key, label, template in MUSIC_PROFILE_URLS:
                url = _direct_result_url(template.format(alias=alias))
                source_id = f"dorking:music_profile:{key}"
                if not _platform_allowed(key, label, selected_platforms):
                    continue
                add_result(
                    source_id=source_id,
                    source_name=label,
                    title=f"{label}: {alias}",
                    url=url,
                    query=alias,
                    platform=label,
                    tags=["music", "artist", "profile", "candidate_url"],
                    direct_candidate=True,
                    lead_kind="direct_profile_candidate",
                    result_group="music_platforms",
                    pivot_entity_type="username",
                    pivot_value=alias,
                    extra_data={
                        "candidate_status": "candidate",
                        "verification_status": "unverified_candidate",
                        "verification_method": "music_platform_url_generation",
                        "site_category": "music",
                        "produced_event_type": "MUSIC_PROFILE_CANDIDATE",
                    },
                )
        query = quote_plus(plan.entity_input)
        for key, label, template in MUSIC_SEARCH_URLS:
            url = _direct_result_url(template.format(query=query))
            source_id = f"dorking:music_search:{key}"
            if not _platform_allowed(key, label, selected_platforms):
                continue
            add_result(
                source_id=source_id,
                source_name=label,
                title=f"{label}: {plan.entity_input}",
                url=url,
                query=plan.entity_input,
                platform=label,
                tags=["music", "artist", "platform", "candidate_url"],
                direct_candidate=True,
                lead_kind="direct_platform_search",
                result_group="music_platforms",
                pivot_entity_type="query",
                pivot_value=plan.entity_input,
                extra_data={
                    "candidate_status": "candidate",
                    "verification_status": "unverified_candidate",
                    "verification_method": "music_platform_search_url_generation",
                    "site_category": "music",
                    "produced_event_type": "PLATFORM_SEARCH_URL",
                },
            )

    has_username_variants = any(
        variant.entity_type == "username" for variant in getattr(plan, "variant_details", [])
    )
    if plan.entity_type in {"username", "email"} or has_username_variants:
        username_candidates = values
        if plan.entity_type == "email" and "@" in plan.entity_input:
            username_candidates = [plan.entity_input.split("@", 1)[0], *values]
        usernames: list[str] = []
        for value in username_candidates:
            username = _safe_username(value)
            if username:
                _append_unique(usernames, username)
        preferred_categories = {"music", "social", "video"} if music_scope else set()
        catalog_limit = _catalog_profile_limit(
            strategy,
            music_scope=music_scope,
            selected_platforms=selected_platforms,
        )
        for candidate in build_username_site_candidates(
            usernames[: strategy.variant_limit],
            platforms=selected_platforms,
            preferred_categories=preferred_categories,
            include_illegal=False,
            per_site_limit=4 if selected_platforms else 2,
            limit=catalog_limit,
        ):
            label = f"{candidate.site_name} profile candidate"
            source_id = f"dorking:profile:{candidate.site_key}"
            if not candidate.display_url:
                continue
            add_result(
                source_id=source_id,
                source_name=label,
                title=f"{label}: {candidate.username}",
                url=candidate.display_url,
                query=candidate.username,
                platform=candidate.site_name,
                tags=["social", "profile", "candidate_url", "sherlock_style"],
                direct_candidate=True,
                lead_kind="direct_profile_candidate",
                result_group="profiles",
                pivot_entity_type="username",
                pivot_value=candidate.username,
                extra_data={
                    "candidate_status": candidate.status,
                    "site_category": candidate.category,
                    "regex_check": candidate.regex_check,
                    "probe_url": candidate.probe_url,
                    "url_main": candidate.url_main,
                    "status_reason": candidate.status_reason,
                    "sherlock_style": True,
                    "sherlock_status": "ILLEGAL" if candidate.status == "illegal" else "CANDIDATE",
                    "verification_status": "unverified_candidate",
                    "verification_method": candidate.verification_method,
                    "status_model": candidate.status_model,
                    "error_type": candidate.error_type,
                    "error_code": candidate.error_code,
                    "request_method": candidate.request_method,
                    "produced_event_type": "PROFILE_CANDIDATE_URL",
                },
            )
        if not results:
            for username in usernames[:6]:
                for key, label, template in USERNAME_PROFILE_URLS:
                    url = _direct_result_url(template.format(username=username))
                    source_id = f"dorking:profile:{key}"
                    if not _platform_allowed(key, label, selected_platforms):
                        continue
                    add_result(
                        source_id=source_id,
                        source_name=label,
                        title=f"{label}: {username}",
                        url=url,
                        query=username,
                        platform=label,
                        tags=["social", "profile", "candidate_url"],
                        direct_candidate=True,
                        lead_kind="direct_profile_candidate",
                        result_group="profiles",
                        pivot_entity_type="username",
                        pivot_value=username,
                        extra_data={"candidate_status": "candidate"},
                    )

    if plan.entity_type == "company":
        slugs: list[str] = []
        for value in values:
            slug = _safe_slug(value)
            if slug:
                _append_unique(slugs, slug)
        for slug in slugs[:5]:
            for key, label, template in COMPANY_PROFILE_URLS:
                url = _direct_result_url(template.format(slug=slug))
                source_id = f"dorking:company_profile:{key}"
                if not _platform_allowed(key, label, selected_platforms):
                    continue
                add_result(
                    source_id=source_id,
                    source_name=label,
                    title=f"{label}: {slug}",
                    url=url,
                    query=slug,
                    platform=label,
                    tags=["company", "profile", "candidate_url"],
                    direct_candidate=True,
                    lead_kind="direct_profile_candidate",
                    result_group="profiles",
                    pivot_entity_type="company",
                    pivot_value=slug,
                    extra_data={"candidate_status": "candidate"},
                )

    if plan.entity_type in {"domain", "url"}:
        domains: list[str] = []
        for value in values:
            domain = _safe_domain(value)
            if domain:
                _append_unique(domains, domain)
        for domain in domains[:5]:
            for key, label, template in DOMAIN_DIRECT_URLS:
                url = _direct_result_url(template.format(domain=domain))
                source_id = f"dorking:domain_url:{key}"
                add_result(
                    source_id=source_id,
                    source_name=label,
                    title=f"{label}: {domain}",
                    url=url,
                    query=domain,
                    platform=label,
                    tags=["domain", "infrastructure", "candidate_url"],
                    direct_candidate=True,
                    lead_kind="direct_domain_pivot",
                    result_group="domains",
                    pivot_entity_type="domain",
                    pivot_value=domain,
                )

    for query in _plan_queries(plan, strategy):
        for engine_id, engine_name, _ in _search_engine_rows(strategy):
            url = _search_url(engine_id, query)
            add_result(
                source_id=f"dorking:{engine_id}",
                source_name=f"{engine_name} Dork",
                title=f"{engine_name} dork: {query}",
                url=url,
                query=query,
                platform=engine_name,
                tags=["search_engine"],
                direct_candidate=False,
                lead_kind="search_engine_query",
                result_group="review_search",
                pivot_entity_type=plan.entity_type,
                pivot_value=plan.entity_input,
            )

    for site, value, query in _search_only_rows(plan, values, strategy, selected_platforms):
        url = _search_url("google", query)
        source_key = safe_site_key(f"{site.source}_{site.host}")
        add_result(
            source_id=f"dorking:search_only:{source_key}",
            source_name=f"Search-only domain dork: {site.name}",
            title=f"{site.name}: {query}",
            url=url,
            query=query,
            platform=site.name,
            tags=[
                "search_only",
                "domain_dork",
                site.source,
                "manual_verification_required",
            ],
            direct_candidate=False,
            lead_kind="search_only_domain_dork",
            result_group="review_search",
            pivot_entity_type=plan.entity_type,
            pivot_value=str(value),
            extra_data={
                "search_only_domain": site.host,
                "search_only_source": site.source,
                "source_category": site.category,
                "source_license_note": site.license_note,
                "review_only": True,
                "manual_verification_required": True,
                "verification_status": "manual_search_required",
                "verification_method": "search_engine_site_dork",
                "produced_event_type": "SEARCH_ONLY_DOMAIN_DORK",
            },
        )

    for key, label, query, tags in _entity_dork_templates(plan, values):
        platform_key = key.split(":", 1)[-1]
        if not _platform_allowed(platform_key, label, selected_platforms):
            continue
        url = _search_url("google", query)
        add_result(
            source_id=f"dorking:{key}",
            source_name=f"Dork: {label}",
            title=f"{label}: {query}",
            url=url,
            query=query,
            platform=label,
            tags=tags,
            direct_candidate=False,
            lead_kind="search_engine_query",
            result_group="review_search",
            pivot_entity_type=plan.entity_type,
            pivot_value=plan.entity_input,
        )

    music_scope = _music_scope(plan)
    music_alias_order = {value: index for index, value in enumerate(_music_aliases(values))}

    def result_priority(result: SearchResult) -> tuple[int, int]:
        source = str(result.source_id or "")
        lead_kind = str(result.normalized_data.get("lead_kind") or "")
        pivot_value = str(result.normalized_data.get("pivot_value") or "")
        original_rank = int(result.normalized_data.get("candidate_rank") or 0)
        if music_scope and source.startswith("dorking:music_profile:"):
            alias_index = music_alias_order.get(pivot_value, 99)
            return (0 if alias_index <= 1 else 2, original_rank)
        if music_scope and source.startswith("dorking:music_search:"):
            return (1, original_rank)
        if lead_kind == "direct_profile_candidate":
            return (3, original_rank)
        if lead_kind.startswith("direct_"):
            return (4, original_rank)
        if source.startswith("dorking:google"):
            return (8, original_rank)
        if lead_kind == "search_only_domain_dork":
            return (10, original_rank)
        return (9, original_rank)

    results.sort(key=result_priority)
    for index, result in enumerate(results, start=1):
        if isinstance(result.raw_data, dict):
            result.raw_data["candidate_rank"] = index
        if isinstance(result.normalized_data, dict):
            result.normalized_data["candidate_rank"] = index
            dorking = result.normalized_data.get("dorking")
            if isinstance(dorking, dict):
                dorking["candidate_rank"] = index
    return results
