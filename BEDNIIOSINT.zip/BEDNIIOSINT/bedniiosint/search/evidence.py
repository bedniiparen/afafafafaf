from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import hashlib
import json
import logging
import time
import urllib.request
from collections import Counter, defaultdict
from typing import Any, Iterable

from .. import __version__
from .models import SearchResult


SEARCH_RUN_EVIDENCE_SCHEMA_VERSION = "1.0"
SEARCH_RUN_CONNECTOR_VERSION = f"bedniiosint.search/1.0 bedniiosint/{__version__}"
SEARCH_RUN_PARSER_VERSION = f"bedniiosint.catalog.parsers/1.0 bedniiosint/{__version__}"
EXCERPT_LEN = 400

logger = logging.getLogger(__name__)


@dataclass
class SearchRunEvidence:
    run_id: str
    query: dict[str, Any]
    entity_type: str
    scope: str
    planned_sources: list[dict[str, Any]]
    executed_sources: list[dict[str, Any]]
    skipped_sources: list[dict[str, Any]]
    started_at: str
    finished_at: str
    connector_version: str
    parser_version: str
    raw_hashes: list[dict[str, Any]]
    evidence_hash: str
    result_count: int
    repro_command: str
    legal_notes: list[str]
    summary: dict[str, Any] = field(default_factory=dict)
    schema_version: str = SEARCH_RUN_EVIDENCE_SCHEMA_VERSION

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _stable_id(*parts: Any) -> str:
    text = "|".join(str(part or "") for part in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]


def _stable_json(value: Any) -> str:
    try:
        return json.dumps(value, sort_keys=True, ensure_ascii=False, default=str)
    except TypeError:
        return repr(value)


def _raw_hash(value: Any) -> str:
    return hashlib.sha256(_stable_json(value).encode("utf-8")).hexdigest()


def _hash_row(kind: str, source_id: str, value: Any) -> dict[str, Any] | None:
    if value in (None, "", {}, []):
        return None
    return {
        "kind": kind,
        "source_id": source_id,
        "algorithm": "sha256",
        "hash": _raw_hash(value),
        "value_type": type(value).__name__,
    }


def _append_evidence(items: list[dict[str, Any]], kind: str, **payload: Any) -> None:
    row = {"kind": kind, **payload}
    row["id"] = _stable_id(
        kind,
        row.get("source_id"),
        row.get("entity_type"),
        row.get("entity_value"),
        row.get("url"),
        row.get("relation"),
        row.get("description"),
        row.get("hash"),
    )
    if row not in items:
        items.append(row)


def _existing_evidence_urls(result: Any) -> set[str]:
    urls: set[str] = set()
    for item in getattr(result, "evidence", None) or []:
        if isinstance(item, dict) and item.get("url"):
            urls.add(str(item["url"]))
    return urls


def _static_result_evidence(result: Any) -> dict[str, Any]:
    normalized = getattr(result, "normalized_data", None) or {}
    verification = {}
    if isinstance(normalized, dict):
        raw_verification = normalized.get("candidate_verification") or normalized.get("verification") or {}
        verification = raw_verification if isinstance(raw_verification, dict) else {}
    url = str(getattr(result, "url", "") or "")
    return {
        "kind": "source_record",
        "id": _stable_id(
            "source_record",
            getattr(result, "source_id", ""),
            getattr(result, "id", ""),
            url,
        ),
        "source_id": getattr(result, "source_id", ""),
        "source_name": getattr(result, "source_name", ""),
        "result_id": getattr(result, "id", ""),
        "url": url,
        "matched_entity": getattr(result, "matched_entity", ""),
        "excerpt": str(getattr(result, "snippet", "") or "")[:EXCERPT_LEN],
        "verification_state": verification.get("state"),
        "status_code": normalized.get("status_code") if isinstance(normalized, dict) else None,
        "confidence": getattr(result, "confidence_score", None),
        "captured_at": _utc_now_iso(),
    }


def _live_capture(url: str, *, timeout: float) -> dict[str, Any] | None:
    try:
        from .host_throttle import HostThrottle, throttled_request

        from ..core.http import HttpPolicy, request

        response = throttled_request(
            "GET",
            url,
            throttle=HostThrottle(),
            request_fn=lambda method, target, **kwargs: request(
                method,
                target,
                policy=HttpPolicy(timeout=timeout),
                **kwargs,
            ),
            follow_redirects=True,
        )
        if response is None:
            return None
        text = str(getattr(response, "text", "") or "")
        return {
            "kind": "live_snapshot",
            "id": _stable_id("live_snapshot", url, _raw_hash(text)),
            "url": url,
            "status_code": getattr(response, "status_code", None),
            "content_sha256": _raw_hash(text),
            "content_length": len(text),
            "excerpt": text[:EXCERPT_LEN],
            "captured_at": _utc_now_iso(),
        }
    except Exception:
        pass
    try:
        request_obj = urllib.request.Request(url, headers={"User-Agent": "bedniiosint-evidence"})
        with urllib.request.urlopen(request_obj, timeout=timeout) as handle:  # noqa: S310
            raw = handle.read().decode("utf-8", "replace")
            status = getattr(handle, "status", None) or handle.getcode()
        return {
            "kind": "live_snapshot",
            "id": _stable_id("live_snapshot", url, _raw_hash(raw)),
            "url": url,
            "status_code": status,
            "content_sha256": _raw_hash(raw),
            "content_length": len(raw),
            "excerpt": raw[:EXCERPT_LEN],
            "captured_at": _utc_now_iso(),
        }
    except Exception:
        logger.debug("evidence live capture failed: %s", url)
        return None


def attach_evidence(
    results: Iterable[Any],
    *,
    settings: Any | None = None,
    capture_live: bool | None = None,
    live_limit: int | None = None,
    timeout: float = 20.0,
) -> list[Any]:
    """Attach structured evidence to each result in place; returns the list."""
    rows = list(results)
    if capture_live is None:
        capture_live = bool(getattr(settings, "evidence_capture_live", False))
    if live_limit is None:
        live_limit = int(getattr(settings, "evidence_capture_limit", 25) or 25)

    for result in rows:
        try:
            evidence = getattr(result, "evidence", None)
            if evidence is None:
                evidence = []
                result.evidence = evidence
            seen = _existing_evidence_urls(result)
            record = _static_result_evidence(result)
            if record.get("url") not in seen:
                evidence.append(record)
            normalized = getattr(result, "normalized_data", None)
            if isinstance(normalized, dict):
                normalized["evidence_count"] = len(evidence)
        except Exception:
            logger.debug("static evidence failed for a result", exc_info=True)

    if capture_live:
        ranked = sorted(
            (row for row in rows if getattr(row, "url", None)),
            key=lambda row: getattr(row, "confidence_score", 0.0) or 0.0,
            reverse=True,
        )
        for result in ranked[: max(0, live_limit)]:
            snapshot = _live_capture(str(result.url), timeout=timeout)
            if snapshot:
                try:
                    result.evidence.append(snapshot)
                    if isinstance(result.normalized_data, dict):
                        result.normalized_data["evidence_count"] = len(result.evidence)
                except Exception:
                    pass
    return rows


def build_search_evidence(
    record: dict[str, Any],
    *,
    source: dict[str, Any] | None = None,
    scope: str = "public_osint",
) -> list[dict[str, Any]]:
    source = source or {}
    source_id = str(record.get("source_id") or source.get("id") or "")
    source_name = str(source.get("name") or source_id)
    entity_type = str(record.get("input_type") or "")
    entity_value = str(record.get("target") or "")
    confidence = float(record.get("confidence") or 0.0)
    items: list[dict[str, Any]] = []

    _append_evidence(
        items,
        "source_observation",
        source_id=source_id,
        source_name=source_name,
        scope=scope,
        entity_type=entity_type,
        entity_value=entity_value,
        status=str(record.get("status") or ""),
        confidence=round(confidence, 3),
        url=str(record.get("url") or ""),
        status_code=record.get("status_code"),
        title=str(record.get("title") or ""),
        legal_status=str(source.get("legal_status") or ""),
    )

    if record.get("url"):
        _append_evidence(
            items,
            "source_url",
            source_id=source_id,
            entity_type=entity_type,
            entity_value=entity_value,
            url=str(record.get("url") or ""),
            method=str(record.get("method") or "GET"),
            status_code=record.get("status_code"),
            confidence=round(confidence, 3),
        )

    for entity in record.get("entities") or []:
        if not isinstance(entity, dict) or not entity.get("type") or not entity.get("value"):
            continue
        _append_evidence(
            items,
            "normalized_entity",
            source_id=source_id,
            entity_type=str(entity.get("type") or ""),
            entity_value=str(entity.get("value") or ""),
            confidence=round(confidence, 3),
        )

    for relation in record.get("relations") or []:
        if not isinstance(relation, dict):
            continue
        if not all(relation.get(key) for key in ("src_type", "src_value", "rel", "dst_type", "dst_value")):
            continue
        _append_evidence(
            items,
            "normalized_relation",
            source_id=source_id,
            entity_type=str(relation.get("src_type") or ""),
            entity_value=str(relation.get("src_value") or ""),
            relation=str(relation.get("rel") or ""),
            dst_type=str(relation.get("dst_type") or ""),
            dst_value=str(relation.get("dst_value") or ""),
            confidence=round(confidence, 3),
        )

    for event in record.get("timeline") or []:
        if not isinstance(event, dict):
            continue
        _append_evidence(
            items,
            "timeline_event",
            source_id=source_id,
            entity_type=str(event.get("entity_type") or entity_type),
            entity_value=str(event.get("entity_value") or entity_value),
            event_kind=str(event.get("kind") or "adapter_observed"),
            event_source=str(event.get("source") or source_id),
            confidence=round(float(event.get("confidence") or confidence), 3),
            description=str(event.get("description") or ""),
        )

    raw = record.get("raw")
    if raw not in (None, "", {}, []):
        _append_evidence(
            items,
            "raw_hash",
            source_id=source_id,
            entity_type=entity_type,
            entity_value=entity_value,
            algorithm="sha256",
            hash=_raw_hash(raw),
            raw_type=type(raw).__name__,
        )

    return items


def _source_id(source: dict[str, Any]) -> str:
    return str(source.get("id") or source.get("source_id") or "")


def _planned_source_rows(
    plan: dict[str, Any],
    *,
    catalog_source_ids_by_search_id: dict[str, list[str]] | None = None,
) -> list[dict[str, Any]]:
    catalog_source_ids_by_search_id = catalog_source_ids_by_search_id or {}
    rows: list[dict[str, Any]] = []
    raw_sources = plan.get("sources") or []
    if not raw_sources and plan.get("source_ids"):
        raw_sources = [{"id": source_id} for source_id in plan.get("source_ids") or []]
    for source in raw_sources:
        if not isinstance(source, dict):
            continue
        source_id = _source_id(source)
        if not source_id:
            continue
        rows.append(
            {
                "source_id": source_id,
                "source_name": str(source.get("name") or source_id),
                "category": str(source.get("category") or ""),
                "auth_required": bool(source.get("auth_required")),
                "legal_status": str(source.get("legal_status") or ""),
                "tos_notes": str(source.get("tos_notes") or ""),
                "parser_type": str(source.get("parser_type") or ""),
                "output_schema": str(source.get("output_schema") or ""),
                "scopes": list(source.get("scopes") or []),
                "tags": list(source.get("tags") or []),
                "catalog_source_ids": list(catalog_source_ids_by_search_id.get(source_id, [])),
            }
        )
    return rows


def _executed_source_rows(pipeline: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for result in pipeline.get("results") or []:
        if not isinstance(result, dict):
            continue
        source_id = str(result.get("source_id") or "")
        raw_material = {
            "data": result.get("data"),
            "text": result.get("text"),
            "normalized": result.get("normalized"),
        }
        raw_digest = _hash_row("adapter_raw", source_id, raw_material)
        rows.append(
            {
                "source_id": source_id,
                "status": str(result.get("status") or ""),
                "input_type": str(result.get("input_type") or ""),
                "method": str(result.get("method") or ""),
                "url": str(result.get("url") or ""),
                "status_code": result.get("status_code"),
                "cache_hit": bool(result.get("cache_hit")),
                "missing_env_vars": list(result.get("missing_env") or []),
                "error": str(result.get("error") or ""),
                "raw_hash": raw_digest["hash"] if raw_digest else "",
            }
        )
    return rows


def _skipped_source_rows(
    *,
    skipped_catalog_sources: list[dict[str, Any]] | None,
    pipeline: dict[str, Any],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for skipped in skipped_catalog_sources or []:
        if not isinstance(skipped, dict):
            continue
        rows.append(
            {
                "source_id": str(skipped.get("source_id") or ""),
                "stage": "catalog_filter",
                "reason": str(skipped.get("reason") or "skipped"),
                "missing_env_vars": list(skipped.get("missing_env_vars") or []),
            }
        )
    for result in pipeline.get("results") or []:
        if not isinstance(result, dict):
            continue
        status = str(result.get("status") or "")
        if status not in {"missing_keys", "blocked_by_scope", "rate_limited"}:
            continue
        rows.append(
            {
                "source_id": str(result.get("source_id") or ""),
                "stage": "adapter_run",
                "reason": status,
                "missing_env_vars": list(result.get("missing_env") or []),
                "error": str(result.get("error") or ""),
            }
        )
    unique: dict[tuple[str, str, str], dict[str, Any]] = {}
    for row in rows:
        unique[(row["source_id"], row["stage"], row["reason"])] = row
    return list(unique.values())


def _result_raw_hashes(results: list[SearchResult]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for result in results:
        row = _hash_row("search_result_raw", result.source_id, result.raw_data)
        if row is None:
            continue
        row["result_id"] = result.id
        rows.append(row)
    unique = {(row["kind"], row["source_id"], row["hash"]): row for row in rows}
    return list(unique.values())


def _pipeline_raw_hashes(pipeline: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for result in pipeline.get("results") or []:
        if not isinstance(result, dict):
            continue
        source_id = str(result.get("source_id") or "")
        raw_material = {
            "data": result.get("data"),
            "text": result.get("text"),
            "normalized": result.get("normalized"),
        }
        row = _hash_row("adapter_raw", source_id, raw_material)
        if row:
            rows.append(row)
    unique = {(row["kind"], row["source_id"], row["hash"]): row for row in rows}
    return list(unique.values())


def _confidence_band(score: float) -> str:
    if score >= 0.75:
        return "high"
    if score >= 0.5:
        return "medium"
    if score > 0:
        return "weak"
    return "rejected_or_unconfirmed"


def _quote_cli_arg(value: str) -> str:
    clean = str(value)
    if not clean:
        return '""'
    if all(char not in clean for char in (' ', '"', "\t", "\n")):
        return clean
    return '"' + clean.replace('"', '\\"') + '"'


def _repro_command(
    *,
    entity_input: str,
    entity_type: str,
    scope: str,
    planned_sources: list[dict[str, Any]],
    include_auth_required: bool,
    configured_only: bool,
) -> str:
    parts = [
        "bedniiosint",
        "search-run",
        _quote_cli_arg(entity_input),
        "--entity-type",
        _quote_cli_arg(entity_type),
        "--scope",
        _quote_cli_arg(scope),
    ]
    for source in planned_sources:
        source_id = str(source.get("source_id") or "")
        if source_id:
            parts.extend(["--source", _quote_cli_arg(source_id)])
    if include_auth_required:
        parts.append("--include-auth-required")
    if configured_only:
        parts.append("--configured-only")
    return " ".join(parts)


def _evidence_items(results: list[SearchResult]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for result in results:
        for item in result.evidence:
            if isinstance(item, dict):
                rows.append(item)
    return rows


def summarize_search_run(
    results: list[SearchResult],
    *,
    run_evidence: SearchRunEvidence | None = None,
) -> dict[str, Any]:
    bands: Counter[str] = Counter()
    for result in results:
        bands[_confidence_band(float(result.confidence_score or 0.0))] += 1
    for key in ("high", "medium", "weak", "rejected_or_unconfirmed"):
        bands.setdefault(key, 0)

    missing_key_sources: list[str] = []
    skipped_sources: list[str] = []
    evidence_hashes: list[dict[str, Any]] = []
    evidence_hash = ""
    planned_count = 0
    executed_count = 0
    if run_evidence is not None:
        planned_count = len(run_evidence.planned_sources)
        executed_count = len(run_evidence.executed_sources)
        skipped_sources = sorted(
            {
                str(row.get("source_id") or "")
                for row in run_evidence.skipped_sources
                if row.get("source_id")
            }
        )
        missing_key_sources = sorted(
            {
                str(row.get("source_id") or "")
                for row in [*run_evidence.skipped_sources, *run_evidence.executed_sources]
                if row.get("source_id")
                and (
                    row.get("reason") == "missing_keys"
                    or row.get("status") == "missing_keys"
                    or bool(row.get("missing_env_vars"))
                )
            }
        )
        evidence_hashes = list(run_evidence.raw_hashes)
        evidence_hash = run_evidence.evidence_hash

    evidence_ids = sorted(
        {
            str(item.get("id") or "")
            for item in _evidence_items(results)
            if item.get("id")
        }
    )
    source_ids = sorted({result.source_id for result in results if result.source_id})
    return {
        "counts": {
            "planned_sources": planned_count,
            "executed_sources": executed_count,
            "skipped_sources": len(skipped_sources),
            "missing_key_sources": len(missing_key_sources),
            "results": len(results),
            "evidence_items": len(evidence_ids),
            "raw_hashes": len(evidence_hashes),
        },
        "confidence_bands": dict(sorted(bands.items())),
        "source_ids": source_ids,
        "skipped_sources": skipped_sources,
        "missing_key_sources": missing_key_sources,
        "evidence_ids": evidence_ids,
        "evidence_hash": evidence_hash,
        "evidence_hashes": evidence_hashes,
    }


def build_search_run_evidence(
    *,
    entity_input: str,
    entity_type: str,
    scope: str,
    plan: dict[str, Any],
    pipeline: dict[str, Any] | None = None,
    results: list[SearchResult] | None = None,
    skipped_catalog_sources: list[dict[str, Any]] | None = None,
    catalog_source_ids_by_search_id: dict[str, list[str]] | None = None,
    started_at: str | None = None,
    finished_at: str | None = None,
    include_auth_required: bool = False,
    configured_only: bool = False,
) -> SearchRunEvidence:
    pipeline = pipeline or {}
    results = results or []
    started = started_at or _utc_now_iso()
    finished = finished_at or _utc_now_iso()
    planned_sources = _planned_source_rows(
        plan,
        catalog_source_ids_by_search_id=catalog_source_ids_by_search_id,
    )
    executed_sources = _executed_source_rows(pipeline)
    skipped_sources = _skipped_source_rows(
        skipped_catalog_sources=skipped_catalog_sources,
        pipeline=pipeline,
    )
    raw_hashes = [*_pipeline_raw_hashes(pipeline), *_result_raw_hashes(results)]
    raw_hashes = list(
        {
            (row["kind"], row["source_id"], row["hash"], row.get("result_id", "")): row
            for row in raw_hashes
        }.values()
    )
    query = {
        "entity_input": entity_input,
        "entity_type": entity_type,
        "scope": scope,
        "variants": list(plan.get("variant_details") or []),
    }
    legal_notes = sorted(
        {
            note
            for note in [
                *[
                    str(source.get("legal_status") or "")
                    for source in planned_sources
                    if isinstance(source, dict)
                ],
                *[str(result.legal_notes or "") for result in results],
            ]
            if note
        }
    )
    evidence_material = {
        "query": query,
        "planned_sources": planned_sources,
        "executed_sources": executed_sources,
        "skipped_sources": skipped_sources,
        "raw_hashes": raw_hashes,
        "result_ids": [result.id for result in results],
        "evidence_items": _evidence_items(results),
    }
    evidence_hash = _raw_hash(evidence_material)
    run_id = "search-" + _stable_id(entity_input, entity_type, scope, started, evidence_hash)
    envelope = SearchRunEvidence(
        run_id=run_id,
        query=query,
        entity_type=entity_type,
        scope=scope,
        planned_sources=planned_sources,
        executed_sources=executed_sources,
        skipped_sources=skipped_sources,
        started_at=started,
        finished_at=finished,
        connector_version=SEARCH_RUN_CONNECTOR_VERSION,
        parser_version=SEARCH_RUN_PARSER_VERSION,
        raw_hashes=raw_hashes,
        evidence_hash=evidence_hash,
        result_count=len(results),
        repro_command=_repro_command(
            entity_input=entity_input,
            entity_type=entity_type,
            scope=scope,
            planned_sources=planned_sources,
            include_auth_required=include_auth_required,
            configured_only=configured_only,
        ),
        legal_notes=legal_notes,
    )
    envelope.summary = summarize_search_run(results, run_evidence=envelope)
    return envelope


def summarize_search_results(results: list[SearchResult]) -> dict[str, Any]:
    evidence_kinds: Counter[str] = Counter()
    risk_flags: Counter[str] = Counter()
    entities: dict[tuple[str, str], dict[str, Any]] = {}
    legal_notes: list[str] = []
    sources: set[str] = set()

    for result in results:
        if result.source_id:
            sources.add(result.source_id)
        for note in [result.legal_notes]:
            if note and note not in legal_notes:
                legal_notes.append(note)
        risk_flags.update(result.risk_flags)
        for evidence in result.evidence:
            evidence_kinds[str(evidence.get("kind") or "unknown")] += 1
            entity_type = str(evidence.get("entity_type") or result.entity_type)
            entity_value = str(evidence.get("entity_value") or result.matched_entity)
            if not entity_type or not entity_value:
                continue
            key = (entity_type, entity_value)
            row = entities.setdefault(
                key,
                {
                    "entity_type": entity_type,
                    "entity_value": entity_value,
                    "sources": set(),
                    "evidence_count": 0,
                    "max_confidence": 0.0,
                },
            )
            if result.source_id:
                row["sources"].add(result.source_id)
            row["evidence_count"] += 1
            row["max_confidence"] = max(float(row["max_confidence"]), float(result.confidence_score or 0.0))

    entity_rows = []
    for row in entities.values():
        source_list = sorted(row["sources"])
        entity_rows.append(
            {
                "entity_type": row["entity_type"],
                "entity_value": row["entity_value"],
                "sources": source_list,
                "source_count": len(source_list),
                "evidence_count": int(row["evidence_count"]),
                "max_confidence": round(float(row["max_confidence"]), 3),
                "corroborated": len(source_list) > 1,
            }
        )
    entity_rows.sort(
        key=lambda row: (
            -int(row["source_count"]),
            -float(row["max_confidence"]),
            str(row["entity_type"]),
            str(row["entity_value"]),
        )
    )

    return {
        "total_results": len(results),
        "sources": sorted(sources),
        "source_count": len(sources),
        "evidence_items": sum(evidence_kinds.values()),
        "evidence_kinds": dict(sorted(evidence_kinds.items())),
        "entities": entity_rows,
        "corroborated_entities": sum(1 for row in entity_rows if row["corroborated"]),
        "risk_flags": dict(sorted(risk_flags.items())),
        "legal_notes": legal_notes,
    }
