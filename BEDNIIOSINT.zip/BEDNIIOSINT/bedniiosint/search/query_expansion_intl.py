from __future__ import annotations

"""International and regional query expansion."""

import re
import unicodedata


_RU_LAT = {
    "\u0430": "a",
    "\u0431": "b",
    "\u0432": "v",
    "\u0433": "g",
    "\u0434": "d",
    "\u0435": "e",
    "\u0451": "e",
    "\u0436": "zh",
    "\u0437": "z",
    "\u0438": "i",
    "\u0439": "y",
    "\u043a": "k",
    "\u043b": "l",
    "\u043c": "m",
    "\u043d": "n",
    "\u043e": "o",
    "\u043f": "p",
    "\u0440": "r",
    "\u0441": "s",
    "\u0442": "t",
    "\u0443": "u",
    "\u0444": "f",
    "\u0445": "kh",
    "\u0446": "ts",
    "\u0447": "ch",
    "\u0448": "sh",
    "\u0449": "shch",
    "\u044a": "",
    "\u044b": "y",
    "\u044c": "",
    "\u044d": "e",
    "\u044e": "yu",
    "\u044f": "ya",
}
_RU_LAT_ALT = {
    "\u0439": "i",
    "\u0445": "h",
    "\u0446": "c",
    "\u044e": "iu",
    "\u044f": "ia",
    "\u0436": "j",
}


def has_cyrillic(value: str) -> bool:
    return any("\u0400" <= char <= "\u04ff" for char in value or "")


def transliterate_ru(value: str, *, alt: bool = False) -> str:
    table = dict(_RU_LAT)
    if alt:
        table.update(_RU_LAT_ALT)
    out: list[str] = []
    for char in value or "":
        lower = char.lower()
        mapped = table.get(lower)
        if mapped is None:
            out.append(char)
        elif char.isupper() and mapped:
            out.append(mapped[0].upper() + mapped[1:])
        else:
            out.append(mapped)
    return "".join(out)


def fold_diacritics(value: str) -> str:
    decomposed = unicodedata.normalize("NFKD", value or "")
    return "".join(char for char in decomposed if not unicodedata.combining(char))


def _norm(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").strip())


def _separator_variants(token: str) -> list[str]:
    base = re.sub(r"[\s._-]+", " ", token).strip()
    words = [word for word in base.split(" ") if word]
    if len(words) < 2:
        return [token]
    joined = "".join(words)
    rows = [
        token,
        joined,
        ".".join(words),
        "_".join(words),
        "-".join(words),
        words[0],
        f"{words[0]}{words[-1]}",
        f"{words[0]}.{words[-1]}",
    ]
    if words[0]:
        rows.append(f"{words[0][0]}{words[-1]}")
    return rows


def expand_variants(value: str, *, entity_type: str = "username", limit: int = 40) -> list[str]:
    clean = _norm(value)
    if not clean:
        return []
    seeds: list[str] = [clean]
    folded = fold_diacritics(clean)
    if folded and folded != clean:
        seeds.append(folded)
    if has_cyrillic(clean):
        transliterated = transliterate_ru(clean)
        alternative = transliterate_ru(clean, alt=True)
        if transliterated:
            seeds.append(transliterated)
        if alternative and alternative != transliterated:
            seeds.append(alternative)
    variants: list[str] = []
    seen: set[str] = set()
    for seed in seeds:
        for variant in _separator_variants(seed):
            for cased in (variant, variant.lower()):
                key = cased.strip()
                if key and key not in seen:
                    seen.add(key)
                    variants.append(key)
                if len(variants) >= limit:
                    return variants
    if entity_type in {"email", "domain", "url", "ip", "wallet"}:
        return variants[: max(1, min(limit, 8))]
    return variants
