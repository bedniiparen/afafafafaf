from __future__ import annotations

import logging
from concurrent.futures import (
    ThreadPoolExecutor,
    TimeoutError as FuturesTimeoutError,
    as_completed,
)
from pathlib import Path
from typing import Any

from ..catalog import run_source
from ..config import settings
from ..core.normalizer import normalize_adapter_result
from ..core.source_context import SourceRunContext
from ..core.source_pipeline import PipelineResult, persist_pipeline_result

logger = logging.getLogger(__name__)


def run_catalog_sources_concurrently(
    target: str,
    *,
    input_type: str,
    source_ids: list[str],
    plugin_dir: Path | None = None,
    context: SourceRunContext | None = None,
    max_workers: int = 4,
    save: bool = False,
    case_name: str | None = None,
) -> PipelineResult:
    workers = max(1, min(int(max_workers or 1), max(1, len(source_ids))))
    out = PipelineResult(target=target, input_type=input_type, sources=list(source_ids))
    if not source_ids:
        return out

    indexed_results: dict[int, Any] = {}
    hard_budget = max(1.0, float(getattr(settings, "search_source_timeout", 30.0)))
    executor = ThreadPoolExecutor(max_workers=workers)
    try:
        futures = {
            executor.submit(
                run_source,
                source_id,
                target,
                plugin_dir=plugin_dir,
                input_type=input_type,
                context=context,
            ): index
            for index, source_id in enumerate(source_ids)
        }
        try:
            for future in as_completed(futures, timeout=hard_budget):
                index = futures[future]
                try:
                    indexed_results[index] = future.result()
                except Exception:
                    logger.exception("source failed: %s", source_ids[index])
                    indexed_results[index] = None
        except FuturesTimeoutError:
            pass
        for future, index in futures.items():
            if index in indexed_results:
                continue
            if future.done():
                try:
                    indexed_results[index] = future.result()
                    continue
                except Exception:
                    logger.exception("source failed: %s", source_ids[index])
                    indexed_results[index] = None
                    continue
            if index not in indexed_results:
                future.cancel()
                logger.warning(
                    "source timed out after %.0fs and was skipped: %s",
                    hard_budget,
                    source_ids[index],
                )
    finally:
        executor.shutdown(wait=False, cancel_futures=True)

    for index in range(len(source_ids)):
        result = indexed_results.get(index)
        if result is None:
            continue
        result_dict = result.as_dict()
        out.results.append(result_dict)
        out.normalized.append(normalize_adapter_result(result).as_dict())

    if save:
        out.persisted_case = persist_pipeline_result(
            out,
            case_name=case_name or f"{input_type}-pipeline",
        )
        out.persisted.append(out.persisted_case)
    return out
