from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class ResolvedScope:
    path: str
    registry_scope: str
    route_name: str
    source_ids: list[str] = field(default_factory=list)
    search_terms: list[str] = field(default_factory=list)
    entity_type_hint: str = ""
    include_auth_required_suggested: bool = False
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class _ScopeTemplate:
    path: str
    registry_scope: str
    route_name: str
    source_ids: tuple[str, ...] = ()
    search_terms: tuple[str, ...] = ()
    entity_type_hint: str = ""
    include_auth_required_suggested: bool = False
    notes: tuple[str, ...] = ()

    def resolve(self) -> ResolvedScope:
        return ResolvedScope(
            path=self.path,
            registry_scope=self.registry_scope,
            route_name=self.route_name,
            source_ids=list(self.source_ids),
            search_terms=list(self.search_terms),
            entity_type_hint=self.entity_type_hint,
            include_auth_required_suggested=self.include_auth_required_suggested,
            notes=list(self.notes),
        )


SCOPE_TEMPLATES: dict[str, _ScopeTemplate] = {
    "/public/osint": _ScopeTemplate(
        path="/public/osint",
        registry_scope="public_osint",
        route_name="Public OSINT",
        search_terms=("public", "profile", "record"),
    ),
    "/infra/domain": _ScopeTemplate(
        path="/infra/domain",
        registry_scope="infrastructure",
        route_name="Domain infrastructure",
        source_ids=(
            "rdap",
            "dns",
            "crtsh",
            "passive_dns_enrichment",
            "archive_discovery",
            "wayback",
            "urlscan",
            "technology_fingerprint",
            "attack_surface",
            "web_search",
        ),
        search_terms=("dns", "certificate", "subdomain", "whois", "technology"),
        entity_type_hint="domain",
        include_auth_required_suggested=True,
    ),
    "/infra/ip": _ScopeTemplate(
        path="/infra/ip",
        registry_scope="infrastructure",
        route_name="IP infrastructure",
        source_ids=(
            "rdap",
            "ip_enrichment",
            "ip_behavior_reputation",
            "urlscan",
            "open_threat_feeds",
            "abuseipdb",
            "attack_surface",
        ),
        search_terms=("asn", "rdap", "reputation", "scanner", "infrastructure"),
        entity_type_hint="ip",
        include_auth_required_suggested=True,
    ),
    "/cyber/threatintel": _ScopeTemplate(
        path="/cyber/threatintel",
        registry_scope="threat_intel",
        route_name="Threat intelligence",
        source_ids=(
            "urlscan",
            "open_threat_feeds",
            "ip_behavior_reputation",
            "virustotal",
            "abuseipdb",
            "attack_surface",
        ),
        search_terms=("threat", "reputation", "ioc", "malware", "abuse"),
        include_auth_required_suggested=True,
    ),
    "/identity/email": _ScopeTemplate(
        path="/identity/email",
        registry_scope="identity_enrichment",
        route_name="Email identity enrichment",
        source_ids=(
            "email_enrichment",
            "email_reputation",
            "contact_discovery",
            "github",
            "web_search",
            "osint_aggregator",
        ),
        search_terms=("email", "profile", "avatar", "account"),
        entity_type_hint="email",
        include_auth_required_suggested=True,
    ),
    "/identity/username": _ScopeTemplate(
        path="/identity/username",
        registry_scope="social_profiles",
        route_name="Username identity discovery",
        source_ids=(
            "social_profiles",
            "github",
            "gitlab",
            "creator_video_search",
            "public_social_intel",
            "osint_aggregator",
        ),
        search_terms=("profile", "username", "account", "creator"),
        entity_type_hint="username",
        include_auth_required_suggested=True,
    ),
    "/identity/phone": _ScopeTemplate(
        path="/identity/phone",
        registry_scope="identity_enrichment",
        route_name="Phone enrichment",
        source_ids=("phone_lookup", "osint_aggregator", "web_search"),
        search_terms=("phone", "carrier", "contact"),
        entity_type_hint="phone",
        include_auth_required_suggested=True,
    ),
    "/dev/github/profile": _ScopeTemplate(
        path="/dev/github/profile",
        registry_scope="developer_footprint",
        route_name="Developer footprint",
        source_ids=("github", "gitlab", "public_code_search", "social_profiles"),
        search_terms=("github", "gitlab", "repository", "commit", "developer"),
        include_auth_required_suggested=True,
    ),
    "/creator/video/youtube": _ScopeTemplate(
        path="/creator/video/youtube",
        registry_scope="media",
        route_name="Creator video footprint",
        source_ids=(
            "creator_video_search",
            "public_social_intel",
            "web_search",
            "news_mentions",
        ),
        search_terms=("youtube", "video", "creator", "channel"),
        include_auth_required_suggested=True,
    ),
    "/creator/music/beatmaking": _ScopeTemplate(
        path="/creator/music/beatmaking",
        registry_scope="media",
        route_name="Creator music footprint",
        source_ids=(
            "creator_video_search",
            "public_social_intel",
            "social_profiles",
            "web_search",
            "news_mentions",
        ),
        search_terms=(
            "artist",
            "musician",
            "producer",
            "beats",
            "music",
            "genius",
            "vk",
            "instagram",
            "youtube",
            "yandex music",
            "spotify",
        ),
        entity_type_hint="username",
        include_auth_required_suggested=True,
    ),
    "/business/company": _ScopeTemplate(
        path="/business/company",
        registry_scope="business",
        route_name="Company and business registry",
        source_ids=(
            "opencorporates",
            "business_knowledge_graph",
            "social_profiles",
            "github",
            "gitlab",
            "news_mentions",
            "archive_discovery",
            "contact_discovery",
            "public_code_search",
            "public_social_intel",
            "web_search",
            "creator_video_search",
            "osint_aggregator",
        ),
        search_terms=("company", "registry", "filing", "news", "developer"),
        entity_type_hint="company",
        include_auth_required_suggested=True,
    ),
    "/crypto/address": _ScopeTemplate(
        path="/crypto/address",
        registry_scope="crypto",
        route_name="Crypto address review",
        source_ids=("blockchain_explorer", "osint_aggregator", "web_search"),
        search_terms=("wallet", "blockchain", "address", "transaction"),
        entity_type_hint="wallet",
        include_auth_required_suggested=True,
    ),
    "/media/reverse_image": _ScopeTemplate(
        path="/media/reverse_image",
        registry_scope="media_verification",
        route_name="Reverse image review",
        source_ids=("media_reverse_search",),
        search_terms=("reverse image", "visual match", "media verification"),
        entity_type_hint="image_url",
        include_auth_required_suggested=True,
    ),
    "/archive": _ScopeTemplate(
        path="/archive",
        registry_scope="archive",
        route_name="Archive and historical web",
        source_ids=("archive_discovery", "wayback", "urlscan", "news_mentions", "web_search"),
        search_terms=("archive", "history", "snapshot"),
    ),
    "/news": _ScopeTemplate(
        path="/news",
        registry_scope="news",
        route_name="News mentions",
        source_ids=("news_mentions", "web_search"),
        search_terms=("news", "mentions", "events"),
    ),
    "/geodata": _ScopeTemplate(
        path="/geodata",
        registry_scope="geodata",
        route_name="Geodata",
        source_ids=("geocode_public", "business_knowledge_graph"),
        search_terms=("address", "place", "geodata"),
    ),
}


SCOPE_ALIASES = {
    "": "/public/osint",
    "/": "/public/osint",
    "public_osint": "/public/osint",
    "/public": "/public/osint",
    "/osint": "/public/osint",
    "/infra": "/infra/domain",
    "/infrastructure": "/infra/domain",
    "/domain": "/infra/domain",
    "/ip": "/infra/ip",
    "/cyber": "/cyber/threatintel",
    "/threat": "/cyber/threatintel",
    "/threatintel": "/cyber/threatintel",
    "/threat_intel": "/cyber/threatintel",
    "/email": "/identity/email",
    "/identity": "/identity/username",
    "/username": "/identity/username",
    "/social": "/identity/username",
    "/phone": "/identity/phone",
    "/dev": "/dev/github/profile",
    "/developer": "/dev/github/profile",
    "/github": "/dev/github/profile",
    "/creator": "/creator/video/youtube",
    "/youtube": "/creator/video/youtube",
    "/video": "/creator/video/youtube",
    "/music": "/creator/music/beatmaking",
    "/artist": "/creator/music/beatmaking",
    "/musician": "/creator/music/beatmaking",
    "/beatmaking": "/creator/music/beatmaking",
    "/business": "/business/company",
    "/company": "/business/company",
    "/crypto": "/crypto/address",
    "/wallet": "/crypto/address",
    "/media": "/creator/video/youtube",
    "/image": "/media/reverse_image",
    "/reverse_image": "/media/reverse_image",
    "/reverse-image": "/media/reverse_image",
}


ENTITY_SCOPE_DEFAULTS = {
    "domain": "/infra/domain",
    "url": "/infra/domain",
    "ip": "/infra/ip",
    "email": "/identity/email",
    "username": "/identity/username",
    "phone": "/identity/phone",
    "wallet": "/crypto/address",
    "company": "/business/company",
    "image_url": "/media/reverse_image",
    "image": "/media/reverse_image",
    "fediverse_account": "/identity/username",
}


def _normalize_scope_path(value: str | None) -> str:
    clean = str(value or "").strip().lower().replace("\\", "/")
    if not clean:
        return ""
    clean = clean.replace(" ", "_").replace("-", "_")
    if clean.startswith("scope:"):
        clean = clean.split(":", 1)[1].strip()
    if clean in {"public_osint", "broad_discovery", "social_profiles", "developer_footprint"}:
        return clean
    if not clean.startswith("/"):
        clean = f"/{clean}"
    while "//" in clean:
        clean = clean.replace("//", "/")
    return clean.rstrip("/") or "/"


def _entity_default_scope(entity_type: str | None) -> str:
    selected = str(entity_type or "").strip().lower()
    return ENTITY_SCOPE_DEFAULTS.get(selected, "/public/osint")


def resolve_scope(scope_path: str | None, entity_type: str | None = None) -> ResolvedScope:
    normalized = _normalize_scope_path(scope_path)
    if not normalized:
        normalized = _entity_default_scope(entity_type)
    if normalized == "/infra" and str(entity_type or "").strip().lower() == "ip":
        normalized = "/infra/ip"
    if normalized == "/media" and str(entity_type or "").strip().lower() in {"image", "image_url"}:
        normalized = "/media/reverse_image"
    if normalized in {"public_osint", "broad_discovery", "social_profiles", "developer_footprint"}:
        return ResolvedScope(
            path="" if normalized == "public_osint" else f"/{normalized}",
            registry_scope=normalized,
            route_name=normalized.replace("_", " ").title(),
            source_ids=[],
            search_terms=[],
            entity_type_hint="",
            include_auth_required_suggested=False,
            notes=["registry_scope_passthrough"],
        )
    alias_target = SCOPE_ALIASES.get(normalized)
    if alias_target:
        normalized = alias_target
    template = SCOPE_TEMPLATES.get(normalized)
    if template:
        return template.resolve()

    fallback_path = _entity_default_scope(entity_type)
    fallback = SCOPE_TEMPLATES[fallback_path].resolve()
    return ResolvedScope(
        path=normalized,
        registry_scope=fallback.registry_scope,
        route_name=f"Custom scope routed as {fallback.route_name}",
        source_ids=fallback.source_ids,
        search_terms=fallback.search_terms,
        entity_type_hint=fallback.entity_type_hint,
        include_auth_required_suggested=fallback.include_auth_required_suggested,
        notes=[*fallback.notes, f"unknown_scope:{normalized}"],
    )
