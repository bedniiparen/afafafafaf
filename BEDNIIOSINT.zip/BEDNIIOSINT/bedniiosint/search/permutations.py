from __future__ import annotations

import re

_CYR = {
    "\u0430": "a",
    "\u0431": "b",
    "\u0432": "v",
    "\u0433": "g",
    "\u0434": "d",
    "\u0435": "e",
    "\u0451": "e",
    "\u0436": "zh",
    "\u0437": "z",
    "\u0438": "i",
    "\u0439": "y",
    "\u043a": "k",
    "\u043b": "l",
    "\u043c": "m",
    "\u043d": "n",
    "\u043e": "o",
    "\u043f": "p",
    "\u0440": "r",
    "\u0441": "s",
    "\u0442": "t",
    "\u0443": "u",
    "\u0444": "f",
    "\u0445": "kh",
    "\u0446": "ts",
    "\u0447": "ch",
    "\u0448": "sh",
    "\u0449": "shch",
    "\u044a": "",
    "\u044b": "y",
    "\u044c": "",
    "\u044d": "e",
    "\u044e": "yu",
    "\u044f": "ya",
}
_LEET = {"a": "4", "e": "3", "i": "1", "o": "0", "s": "5", "t": "7", "l": "1", "b": "8"}
_SEPARATORS = ("", ".", "_", "-")


def transliterate(text: str) -> str:
    return "".join(_CYR.get(ch, ch) for ch in (text or "").lower())


def _clean(token: str) -> str:
    return re.sub(r"[^a-z0-9]", "", transliterate(token).lower())


def leetify(value: str) -> str:
    return "".join(_LEET.get(ch, ch) for ch in value)


def _variant_sort_key(value: str) -> tuple[int, int, int, int, str]:
    digit_count = sum(ch.isdigit() for ch in value)
    synthetic_suffix = int(value.endswith(("_", "x")))
    separator_bonus = 0 if any(sep and sep in value for sep in _SEPARATORS) else 1
    return (digit_count, synthetic_suffix, separator_bonus, len(value), value)


def name_permutations(
    first: str,
    last: str = "",
    *,
    years: tuple[int, ...] = (),
    include_leet: bool = False,
    limit: int = 200,
) -> list[str]:
    f = _clean(first)
    l = _clean(last)
    out: set[str] = set()
    if f:
        out.add(f)
    if l:
        out.add(l)
    if f and l:
        fi, li = f[0], l[0]
        for sep in _SEPARATORS:
            out.add(f"{f}{sep}{l}")
            out.add(f"{l}{sep}{f}")
            out.add(f"{fi}{sep}{l}")
            out.add(f"{f}{sep}{li}")
        out.add(f"{fi}{l}")
        out.add(f"{l}{fi}")
    for value in list(out):
        for year in years:
            out.add(f"{value}{year}")
            out.add(f"{value}{str(year)[-2:]}")
        for suffix in ("", "1", "01", "007", "123", "x", "_"):
            out.add(f"{value}{suffix}")
    if include_leet:
        for value in list(out):
            out.add(leetify(value))
    cleaned = [v for v in out if 2 <= len(v) <= 64]
    cleaned.sort(key=_variant_sort_key)
    return cleaned[:limit]


def username_variants(handle: str, *, include_leet: bool = True, limit: int = 100) -> list[str]:
    base = _clean(handle)
    out: set[str] = {base} if base else set()
    parts = [
        re.sub(r"[^a-z0-9]", "", p)
        for p in re.split(r"[._\-\s]+", transliterate(handle).lower())
    ]
    parts = [p for p in parts if p]
    if len(parts) >= 2:
        out.update(name_permutations(parts[0], parts[-1], include_leet=False, limit=limit))
        for sep in _SEPARATORS:
            out.add(sep.join(parts))
    if include_leet and base:
        out.add(leetify(base))
    cleaned = [v for v in out if 2 <= len(v) <= 64]
    cleaned.sort(key=_variant_sort_key)
    return cleaned[:limit]
