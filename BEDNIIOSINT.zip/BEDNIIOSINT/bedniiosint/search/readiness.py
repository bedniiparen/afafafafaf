from __future__ import annotations

from typing import Any

from ..catalog import registry_entries
from .pipeline import SEARCH_TO_CATALOG_SOURCE_IDS
from .source_registry import list_sources


TERMS_RISK_ORDER = {"": 0, "low": 1, "medium": 2, "high": 3}

TARGET_ENTITY_TYPES = (
    "username",
    "email",
    "domain",
    "ip",
    "phone",
    "url",
    "wallet",
    "company",
)


def search_source_readiness() -> list[dict[str, Any]]:
    catalog = {entry.id: entry.as_dict() for entry in registry_entries()}
    rows: list[dict[str, Any]] = []
    for source in list_sources():
        source_id = str(source.get("id") or "")
        catalog_ids = SEARCH_TO_CATALOG_SOURCE_IDS.get(source_id, [])
        mapped = [catalog.get(catalog_id) for catalog_id in catalog_ids]
        mapped = [row for row in mapped if row]
        rows.append(
            {
                "source_id": source_id,
                "name": source.get("name"),
                "category": source.get("category"),
                "auth_required": bool(source.get("auth_required")),
                "supported_entity_types": source.get("supported_entity_types", []),
                "scopes": source.get("scopes", []),
                "catalog_source_ids": catalog_ids,
                "mapped_catalog_sources": mapped,
                "implemented": bool(mapped),
                "configured": all(bool(row.get("configured")) for row in mapped) if mapped else False,
                "runnable": any(bool(row.get("runnable")) for row in mapped),
                "legal_status": source.get("legal_status"),
                "tos_notes": source.get("tos_notes"),
            }
        )
    return rows


def compact_search_source_readiness(row: dict[str, Any]) -> dict[str, Any]:
    mapped = [
        dict(source)
        for source in row.get("mapped_catalog_sources", [])
        if isinstance(source, dict)
    ]
    missing_env_vars = sorted(
        {
            str(env_var)
            for source in mapped
            if not bool(source.get("configured"))
            for env_var in source.get("env_vars", [])
            if env_var
        }
    )
    terms_risks = [str(source.get("terms_risk") or "") for source in mapped]
    max_terms_risk = max(
        terms_risks or [""],
        key=lambda value: TERMS_RISK_ORDER.get(value, 0),
    )
    return {
        "source_id": row.get("source_id"),
        "name": row.get("name"),
        "category": row.get("category"),
        "supported_entity_types": row.get("supported_entity_types", []),
        "scopes": row.get("scopes", []),
        "catalog_source_ids": row.get("catalog_source_ids", []),
        "implemented": bool(row.get("implemented")),
        "configured": bool(row.get("configured")),
        "runnable": bool(row.get("runnable")),
        "auth_required": bool(row.get("auth_required")),
        "missing_env_vars": missing_env_vars,
        "mapped_count": len(mapped),
        "configured_count": sum(1 for source in mapped if bool(source.get("configured"))),
        "runnable_count": sum(1 for source in mapped if bool(source.get("runnable"))),
        "max_terms_risk": max_terms_risk,
        "legal_status": row.get("legal_status"),
    }


def compact_search_source_readiness_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [compact_search_source_readiness(row) for row in rows]


def search_readiness_summary(rows: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    rows = rows if rows is not None else search_source_readiness()
    return {
        "sources": len(rows),
        "implemented": sum(1 for row in rows if row["implemented"]),
        "configured": sum(1 for row in rows if row["configured"]),
        "auth_required": sum(1 for row in rows if row["auth_required"]),
        "unmapped": [row["source_id"] for row in rows if not row["implemented"]],
    }


def source_coverage_by_target_type(rows: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    rows = rows if rows is not None else search_source_readiness()
    coverage: list[dict[str, Any]] = []
    for target_type in TARGET_ENTITY_TYPES:
        scoped = [
            row
            for row in rows
            if target_type in {str(item).lower() for item in row.get("supported_entity_types", [])}
        ]
        configured = sum(1 for row in scoped if bool(row.get("configured")))
        implemented = sum(1 for row in scoped if bool(row.get("implemented")))
        runnable = sum(1 for row in scoped if bool(row.get("runnable")))
        missing_env_vars = sorted(
            {
                str(env_var)
                for row in scoped
                for source in row.get("mapped_catalog_sources", [])
                if isinstance(source, dict) and not bool(source.get("configured"))
                for env_var in source.get("env_vars", [])
                if env_var
            }
        )
        total = len(scoped)
        coverage.append(
            {
                "target_type": target_type,
                "sources": total,
                "implemented": implemented,
                "configured": configured,
                "runnable": runnable,
                "auth_required": sum(1 for row in scoped if bool(row.get("auth_required"))),
                "configuration_gap": max(0, implemented - configured),
                "configured_ratio": round(configured / implemented, 3) if implemented else 0.0,
                "configured_label": f"{configured}/{implemented}",
                "missing_env_vars": missing_env_vars,
            }
        )
    return coverage


def search_sources_status(*, compact: bool = False) -> dict[str, Any]:
    rows = search_source_readiness()
    selected_rows = compact_search_source_readiness_rows(rows) if compact else rows
    return {
        "summary": {
            **search_readiness_summary(rows),
            "coverage_by_target_type": source_coverage_by_target_type(rows),
            "compact": compact,
        },
        "sources": selected_rows,
    }
