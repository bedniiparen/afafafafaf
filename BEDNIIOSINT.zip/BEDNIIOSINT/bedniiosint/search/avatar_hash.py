from __future__ import annotations

"""Perceptual avatar hashing and cross-source identity linking."""

import io
from typing import Any, Callable

try:
    from PIL import Image  # type: ignore

    _HAS_PIL = True
except Exception:  # pragma: no cover - Pillow is optional
    _HAS_PIL = False

try:
    from .correlation import CorrelationLink
except Exception:  # pragma: no cover - keep module importable standalone
    CorrelationLink = None  # type: ignore

_AVATAR_KEYS = ("avatar_url", "avatar", "image", "icon_img", "profile_image", "picture")


def _to_gray(image_bytes: bytes, size: tuple[int, int]) -> list[int] | None:
    if not _HAS_PIL or not image_bytes:
        return None
    try:
        image = Image.open(io.BytesIO(image_bytes)).convert("L").resize(size)
    except Exception:
        return None
    return list(image.getdata())


def _bits_to_hex(bits: str) -> str:
    width = (len(bits) + 3) // 4
    return format(int(bits or "0", 2), f"0{width}x")


def average_hash(image_bytes: bytes, hash_size: int = 8) -> str | None:
    pixels = _to_gray(image_bytes, (hash_size, hash_size))
    if not pixels:
        return None
    average = sum(pixels) / len(pixels)
    return _bits_to_hex("".join("1" if pixel > average else "0" for pixel in pixels))


def dhash(image_bytes: bytes, hash_size: int = 8) -> str | None:
    width = hash_size + 1
    pixels = _to_gray(image_bytes, (width, hash_size))
    if not pixels:
        return None
    bits: list[str] = []
    for row in range(hash_size):
        for col in range(hash_size):
            left = pixels[row * width + col]
            right = pixels[row * width + col + 1]
            bits.append("1" if left > right else "0")
    return _bits_to_hex("".join(bits))


def hamming_distance(hex_a: str | None, hex_b: str | None) -> int:
    if not hex_a or not hex_b:
        return 64
    try:
        return bin(int(hex_a, 16) ^ int(hex_b, 16)).count("1")
    except ValueError:
        return 64


def hashes_match(hex_a: str | None, hex_b: str | None, *, max_distance: int = 10) -> bool:
    return bool(hex_a) and bool(hex_b) and hamming_distance(hex_a, hex_b) <= max_distance


def avatar_url_of(result: dict[str, Any]) -> str:
    for container in (result.get("normalized_data"), result.get("raw_data")):
        if not isinstance(container, dict):
            continue
        for key in _AVATAR_KEYS:
            value = container.get(key)
            if isinstance(value, str) and value.startswith("http"):
                return value
    return ""


def _default_fetch_bytes(url: str) -> bytes:
    from ..core.http import request

    response = request("GET", url, headers={"User-Agent": "bedniiosint-osint/1.0"})
    try:
        return response.content or b""
    except Exception:
        return b""


def attach_avatar_hashes(
    results: list[dict[str, Any]],
    *,
    fetch_bytes: Callable[[str], bytes] | None = None,
    limit: int = 200,
    hash_size: int = 8,
) -> int:
    """Download avatars and store perceptual hashes on result dictionaries."""
    if not _HAS_PIL:
        return 0
    fetcher = fetch_bytes or _default_fetch_bytes
    hashed = 0
    for result in results[: max(0, limit)]:
        if not isinstance(result, dict):
            continue
        normalized = result.setdefault("normalized_data", {})
        if not isinstance(normalized, dict) or normalized.get("avatar_phash"):
            continue
        avatar_url = avatar_url_of(result)
        if not avatar_url:
            continue
        digest = dhash(fetcher(avatar_url), hash_size=hash_size)
        if not digest:
            continue
        normalized["avatar_phash"] = digest
        normalized.setdefault("avatar_hash", digest)
        hashed += 1
    return hashed


def _rid(result: dict[str, Any], index: int) -> str:
    return str(result.get("id") or f"result-{index}")


def _source_of(result: dict[str, Any]) -> str:
    return str(
        result.get("source_id")
        or result.get("detected_platform")
        or result.get("source_name")
        or ""
    ).strip().lower()


def avatar_correlations(
    results: list[dict[str, Any]],
    *,
    max_distance: int = 10,
    min_sources: int = 2,
):
    """Return links for results whose avatar perceptual hashes are near-identical."""
    items: list[tuple[int, dict[str, Any], str]] = []
    for index, result in enumerate(results):
        if not isinstance(result, dict):
            continue
        normalized = result.get("normalized_data")
        digest = normalized.get("avatar_phash") if isinstance(normalized, dict) else None
        if digest:
            items.append((index, result, str(digest)))

    parent = list(range(len(items)))

    def find(value: int) -> int:
        while parent[value] != value:
            parent[value] = parent[parent[value]]
            value = parent[value]
        return value

    def union(left: int, right: int) -> None:
        parent[find(left)] = find(right)

    for left in range(len(items)):
        for right in range(left + 1, len(items)):
            if hashes_match(items[left][2], items[right][2], max_distance=max_distance):
                union(left, right)

    groups: dict[int, list[int]] = {}
    for index in range(len(items)):
        groups.setdefault(find(index), []).append(index)

    links = []
    for members in groups.values():
        if len(members) < 2:
            continue
        ids = sorted(_rid(items[member][1], items[member][0]) for member in members)
        sources = sorted({_source_of(items[member][1]) for member in members if _source_of(items[member][1])})
        if len(sources) < min_sources:
            continue
        confidence = min(0.99, 0.9 + 0.03 * max(0, len(sources) - 2))
        key = items[members[0]][2]
        explanation = (
            f"Visually identical avatar (perceptual hash distance <= {max_distance}) "
            f"across {len(sources)} sources."
        )
        payload = {
            "kind": "shared_avatar_hash",
            "key": key,
            "member_ids": ids,
            "sources": sources,
            "confidence": round(confidence, 3),
            "explanation": explanation,
        }
        links.append(CorrelationLink(**payload) if CorrelationLink else payload)
    return links
