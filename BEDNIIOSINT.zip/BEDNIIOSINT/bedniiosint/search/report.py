from __future__ import annotations

from typing import Any


def _status_counts(clusters: list[dict[str, Any]]) -> dict[str, int]:
    counts = {"confirmed": 0, "possible": 0, "weak": 0, "unconfirmed": 0}
    for cluster in clusters:
        status = str(cluster.get("status") or "unconfirmed")
        counts[status] = counts.get(status, 0) + 1
    return counts


def _top_clusters(clusters: list[dict[str, Any]], status: str, limit: int = 10) -> list[dict[str, Any]]:
    rows = [cluster for cluster in clusters if str(cluster.get("status")) == status]
    rows.sort(
        key=lambda row: (
            -float(row.get("max_confidence") or 0.0),
            -int(row.get("source_count") or 0),
            str(row.get("entity_type") or ""),
            str(row.get("entity_value") or ""),
        )
    )
    return rows[:limit]


def build_search_report_summary(payload: dict[str, Any]) -> dict[str, Any]:
    clusters = list(payload.get("result_clusters") or [])
    run_summary = dict(payload.get("run_summary") or {})
    counts = dict(payload.get("counts") or {})
    skipped = list(payload.get("skipped_catalog_sources") or [])
    missing_key_sources = list(run_summary.get("missing_key_sources") or [])
    status_counts = _status_counts(clusters)
    result_count = int(counts.get("search_results") or len(payload.get("search_results") or []))
    dorking_count = int(counts.get("dorking_results") or 0)
    executed = int(run_summary.get("counts", {}).get("executed_sources") or len(payload.get("catalog_source_ids") or []))
    planned = int(run_summary.get("counts", {}).get("planned_sources") or len(payload.get("search_source_ids") or []))

    if result_count == 0:
        headline = "No normalized findings returned by executed sources."
    elif status_counts.get("confirmed", 0):
        headline = f"{status_counts['confirmed']} confirmed cluster(s) found."
    elif status_counts.get("possible", 0):
        headline = f"{status_counts['possible']} possible cluster(s) found."
    else:
        headline = f"{result_count} weak or unconfirmed result(s) found."

    next_steps: list[str] = []
    if missing_key_sources:
        next_steps.append("Configure missing API keys or rerun with --configured-only to avoid keyed-source noise.")
    if skipped:
        next_steps.append("Review skipped sources before treating coverage as complete.")
    if dorking_count:
        next_steps.append("Open review-only dorking and social leads manually, then promote only corroborated matches.")
    if status_counts.get("weak", 0) or status_counts.get("unconfirmed", 0):
        next_steps.append("Corroborate weak/unconfirmed clusters with independent public sources.")
    if not clusters and planned:
        next_steps.append("Run without --dry-run or add configured sources for this entity type.")
    if not next_steps:
        next_steps.append("Inspect raw evidence hashes and source explanations before reporting externally.")

    return {
        "headline": headline,
        "target": payload.get("entity_input") or payload.get("target") or "",
        "entity_type": payload.get("entity_type") or "",
        "scope": payload.get("scope") or "",
        "coverage": {
            "planned_sources": planned,
            "executed_sources": executed,
            "skipped_sources": len(skipped),
            "missing_key_sources": len(missing_key_sources),
            "results": result_count,
            "dorking_results": dorking_count,
        },
        "cluster_status_counts": status_counts,
        "confirmed": _top_clusters(clusters, "confirmed"),
        "possible": _top_clusters(clusters, "possible"),
        "weak": _top_clusters(clusters, "weak"),
        "unconfirmed": _top_clusters(clusters, "unconfirmed"),
        "missing_key_sources": missing_key_sources,
        "skipped_sources": skipped,
        "next_steps": next_steps,
        "evidence_hash": run_summary.get("evidence_hash") or "",
        "repro_command": (payload.get("run_evidence") or {}).get("repro_command", ""),
    }


def render_search_markdown(payload: dict[str, Any]) -> str:
    summary = dict(payload.get("report_summary") or build_search_report_summary(payload))
    lines = [
        f"# Search Report: {summary.get('target', '')}",
        "",
        str(summary.get("headline") or ""),
        "",
        "## Coverage",
    ]
    coverage = summary.get("coverage") or {}
    for key in (
        "planned_sources",
        "executed_sources",
        "skipped_sources",
        "missing_key_sources",
        "results",
        "dorking_results",
    ):
        lines.append(f"- {key}: {coverage.get(key, 0)}")
    lines.extend(["", "## Clusters"])
    for section in ("confirmed", "possible", "weak", "unconfirmed"):
        rows = summary.get(section) or []
        if not rows:
            continue
        lines.append(f"### {section.title()}")
        for row in rows:
            lines.append(
                "- "
                f"{row.get('entity_type')}={row.get('entity_value')} "
                f"confidence={row.get('max_confidence')} "
                f"sources={row.get('source_count')} "
                f"evidence={row.get('evidence_count')}"
            )
    lines.extend(["", "## Next Steps"])
    for item in summary.get("next_steps") or []:
        lines.append(f"- {item}")
    if summary.get("evidence_hash"):
        lines.extend(["", f"Evidence hash: `{summary['evidence_hash']}`"])
    if summary.get("repro_command"):
        lines.extend(["", "## Reproduce", "", f"```bash\n{summary['repro_command']}\n```"])
    return "\n".join(lines).strip() + "\n"
