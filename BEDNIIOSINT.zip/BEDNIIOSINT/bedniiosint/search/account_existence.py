from __future__ import annotations

"""Email / phone account-existence checks (Holehe-style, extensible)."""

import concurrent.futures
import hashlib
import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

logger = logging.getLogger(__name__)

EMAIL_SPECS: list[dict[str, Any]] = [
    {
        "name": "Gravatar",
        "platform": "gravatar",
        "method": "GET",
        "url": "https://en.gravatar.com/{md5}.json",
        "present_status": [200],
        "absent_status": [404],
        "confidence": 0.8,
    },
    {
        "name": "Libravatar",
        "platform": "libravatar",
        "method": "GET",
        "url": "https://seccdn.libravatar.org/avatar/{md5}?d=404",
        "present_status": [200],
        "absent_status": [404],
        "confidence": 0.72,
    },
    {
        "name": "GitHub",
        "platform": "github",
        "method": "GET",
        "url": "https://api.github.com/search/users?q={email_q}+in:email",
        "present_json_nonzero": "total_count",
        "confidence": 0.75,
    },
]


def _md5(text: str) -> str:
    return hashlib.md5(text.strip().lower().encode("utf-8")).hexdigest()


def _http(method: str, url: str, *, headers: dict[str, str] | None = None, timeout: float = 15.0):
    try:
        from ..core.http import request

        resp = request(method, url, headers=headers or {})
        return getattr(resp, "status_code", None), str(getattr(resp, "text", "") or "")
    except Exception:
        pass
    try:
        req = urllib.request.Request(url, method=method, headers=headers or {"User-Agent": "bedniiosint"})
        with urllib.request.urlopen(req, timeout=timeout) as handle:  # noqa: S310
            status = getattr(handle, "status", None) or handle.getcode()
            return status, handle.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, ""
    except Exception:
        return None, None


def _make_result(
    *,
    platform: str,
    email: str,
    url: str,
    present: bool,
    confidence: float,
    detail: str,
) -> Any:
    from .models import SearchResult

    state = "present" if present else "absent"
    return SearchResult(
        id=f"acctexist:{platform}:{_md5(email)[:10]}",
        source_id=f"api:account_existence:{platform}",
        source_name=f"Account existence ({platform})",
        entity_input=email,
        entity_type="email",
        matched_entity=email,
        url=url,
        title=f"{platform}: account {state}",
        snippet=detail,
        confidence_score=confidence if present else 0.0,
        tags=["account_existence", state],
        normalized_data={
            "account_existence": {
                "platform": platform,
                "state": state,
                "detail": detail,
            }
        },
    )


def _run_email_spec(spec: dict[str, Any], email: str, *, github_token: str | None) -> Any | None:
    url = str(spec["url"]).replace("{md5}", _md5(email)).replace("{email_q}", urllib.parse.quote(email))
    headers = {"User-Agent": "bedniiosint"}
    if spec.get("platform") == "github" and github_token:
        headers["Authorization"] = f"Bearer {github_token}"
    status, text = _http(str(spec.get("method", "GET")), url, headers=headers)
    if status is None:
        return None
    present: bool | None = None
    if "present_status" in spec and status in spec["present_status"]:
        present = True
    if "absent_status" in spec and status in spec["absent_status"]:
        present = False
    key = spec.get("present_json_nonzero")
    if key and text:
        try:
            present = bool(json.loads(text).get(str(key)))
        except Exception:
            pass
    if present is None:
        return None
    return _make_result(
        platform=str(spec.get("platform", str(spec["name"]).lower())),
        email=email,
        url=url,
        present=present,
        confidence=float(spec.get("confidence", 0.6)),
        detail=f"HTTP {status}",
    )


def check_email_accounts(email: str, *, settings: Any | None = None, max_workers: int = 12) -> list[Any]:
    if not email or "@" not in email:
        return []
    github_token = getattr(settings, "github_token", "") if settings else ""
    out: list[Any] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, max_workers)) as pool:
        futures = {
            pool.submit(_run_email_spec, spec, email, github_token=github_token): spec
            for spec in EMAIL_SPECS
        }
        try:
            for future in concurrent.futures.as_completed(futures, timeout=60):
                try:
                    result = future.result()
                except Exception:
                    result = None
                if result is not None:
                    out.append(result)
        except concurrent.futures.TimeoutError:
            logger.warning("account existence: some email checks timed out")
    return out


def _phone_result(platform: str, phone: str, valid: bool, snippet: str, data: Any) -> Any:
    from .models import SearchResult

    digits = "".join(char for char in phone if char.isdigit())
    state = "present" if valid else "absent"
    return SearchResult(
        id=f"acctexist:{platform}:{digits[-6:]}",
        source_id=f"api:account_existence:{platform}",
        source_name=f"Account existence ({platform})",
        entity_input=phone,
        entity_type="phone",
        matched_entity=phone,
        url="",
        title=f"{platform}: {'valid' if valid else 'invalid'}",
        snippet=snippet,
        confidence_score=0.7 if valid else 0.0,
        tags=["account_existence", state],
        normalized_data={"account_existence": {"platform": platform, "state": state, "detail": data}},
    )


def check_phone_account(phone: str, *, settings: Any | None = None) -> list[Any]:
    if not phone:
        return []
    numverify_key = getattr(settings, "numverify_api_key", "") if settings else ""
    veriphone_key = getattr(settings, "veriphone_api_key", "") if settings else ""
    out: list[Any] = []
    query = urllib.parse.quote(phone)
    if numverify_key:
        url = f"http://apilayer.net/api/validate?access_key={numverify_key}&number={query}"
        _status, text = _http("GET", url)
        if text:
            try:
                data = json.loads(text)
                valid = bool(data.get("valid"))
                snippet = f"carrier={data.get('carrier')} line={data.get('line_type')} country={data.get('country_name')}"
                out.append(_phone_result("numverify", phone, valid, snippet, data))
            except Exception:
                pass
    if veriphone_key:
        url = f"https://api.veriphone.io/v2/verify?phone={query}&key={veriphone_key}"
        _status, text = _http("GET", url)
        if text:
            try:
                data = json.loads(text)
                valid = bool(data.get("phone_valid"))
                snippet = f"carrier={data.get('carrier')} type={data.get('phone_type')} region={data.get('phone_region')}"
                out.append(_phone_result("veriphone", phone, valid, snippet, data))
            except Exception:
                pass
    return out


def build_account_existence_results(
    entity_value: str,
    entity_type: str,
    *,
    settings: Any | None = None,
) -> list[Any]:
    try:
        if entity_type == "email":
            return check_email_accounts(entity_value, settings=settings)
        if entity_type == "phone":
            return check_phone_account(entity_value, settings=settings)
    except Exception:
        logger.exception("account existence check failed")
    return []
