from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class SearchResult:
    id: str
    source_id: str
    source_name: str
    entity_input: str
    entity_type: str
    matched_entity: str
    matched_variant: str = ""
    scope: str = "public_osint"
    title: str = ""
    url: str = ""
    snippet: str = ""
    raw_data: Any = field(default_factory=dict)
    normalized_data: dict[str, Any] = field(default_factory=dict)
    detected_platform: str = ""
    found_at: str = field(default_factory=_utc_now_iso)
    first_seen: str | None = None
    last_seen: str | None = None
    tags: list[str] = field(default_factory=list)
    evidence: list[dict[str, Any]] = field(default_factory=list)
    confidence_score: float = 0.0
    context_match_score: float = 0.0
    risk_flags: list[str] = field(default_factory=list)
    legal_notes: str = ""
    explanation: str = ""

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_dict(self) -> dict[str, Any]:
        return self.as_dict()

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "SearchResult":
        return cls(**payload)

