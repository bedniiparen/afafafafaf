from __future__ import annotations

"""Declarative YAML/JSON correlation rule engine."""

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore

    _HAS_YAML = True
except Exception:  # pragma: no cover - PyYAML is optional
    _HAS_YAML = False

try:
    from .correlation import CorrelationLink
except Exception:  # pragma: no cover
    CorrelationLink = None  # type: ignore


@dataclass
class CorrelationRule:
    id: str
    kind: str
    group_by: str
    name: str = ""
    where: list[dict[str, Any]] = field(default_factory=list)
    min_members: int = 2
    min_sources: int = 2
    confidence: float = 0.6
    explanation: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CorrelationRule":
        return cls(
            id=str(data.get("id") or data.get("kind") or "rule"),
            kind=str(data.get("kind") or data.get("id") or "correlation"),
            group_by=str(data.get("group_by") or ""),
            name=str(data.get("name") or ""),
            where=list(data.get("where") or []),
            min_members=int(data.get("min_members") or 2),
            min_sources=int(data.get("min_sources") or 2),
            confidence=float(data.get("confidence") or 0.6),
            explanation=str(data.get("explanation") or ""),
        )


BUILTIN_RULES: list[dict[str, Any]] = [
    {
        "id": "cross_platform_username",
        "name": "Same username across platforms",
        "kind": "cross_platform_username",
        "group_by": "matched_entity",
        "where": [{"field": "entity_type", "op": "in", "value": ["username", "profile"]}],
        "min_members": 2,
        "min_sources": 2,
        "confidence": 0.8,
        "explanation": "Same username appears across independent platforms.",
    },
    {
        "id": "shared_email",
        "name": "Same email across sources",
        "kind": "shared_email",
        "group_by": "normalized_data.email",
        "min_members": 2,
        "min_sources": 2,
        "confidence": 0.9,
        "explanation": "Same email appears across independent sources.",
    },
    {
        "id": "shared_avatar",
        "name": "Shared avatar hash",
        "kind": "shared_avatar_hash",
        "group_by": "normalized_data.avatar_phash",
        "min_members": 2,
        "min_sources": 2,
        "confidence": 0.95,
        "explanation": "Same avatar perceptual hash across independent sources.",
    },
    {
        "id": "same_display_name",
        "name": "Same display name",
        "kind": "same_display_name",
        "group_by": "normalized_data.full_name",
        "where": [{"field": "normalized_data.full_name", "op": "contains", "value": " "}],
        "min_members": 2,
        "min_sources": 2,
        "confidence": 0.6,
        "explanation": "Same display name appears across independent sources.",
    },
]


def load_rules(path: str | Path | None = None) -> list[CorrelationRule]:
    if path is None:
        return [CorrelationRule.from_dict(item) for item in BUILTIN_RULES]
    raw = _parse(Path(path).read_text(encoding="utf-8"))
    return [CorrelationRule.from_dict(item) for item in raw if isinstance(item, dict)]


def _parse(text: str) -> list[dict[str, Any]]:
    if _HAS_YAML:
        data = yaml.safe_load(text)
    else:
        data = json.loads(text)
    if isinstance(data, dict):
        data = data.get("rules") or []
    return list(data or [])


def _get_field(result: dict[str, Any], path: str) -> Any:
    if not path:
        return None
    current: Any = result
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _resolve(result: dict[str, Any], path: str) -> Any:
    value = _get_field(result, path)
    if value is None and "." not in path:
        normalized = result.get("normalized_data")
        if isinstance(normalized, dict):
            return normalized.get(path)
    return value


def _check(value: Any, op: str, expected: Any) -> bool:
    op = (op or "eq").lower()
    if op == "exists":
        return value is not None and value != ""
    if op == "eq":
        return value == expected
    if op == "ne":
        return value != expected
    if op == "in":
        return value in (expected or [])
    if op == "not_in":
        return value not in (expected or [])
    if op == "contains":
        return bool(value) and str(expected) in str(value)
    if op == "icontains":
        return bool(value) and str(expected).lower() in str(value).lower()
    if op == "regex":
        try:
            return bool(value) and re.search(str(expected), str(value)) is not None
        except re.error:
            return False
    if op in {"gte", "lte"}:
        try:
            left = float(value)
            right = float(expected)
        except (TypeError, ValueError):
            return False
        return left >= right if op == "gte" else left <= right
    return False


def _passes_where(result: dict[str, Any], where: list[dict[str, Any]]) -> bool:
    for condition in where or []:
        value = _resolve(result, str(condition.get("field") or ""))
        if not _check(value, str(condition.get("op") or "eq"), condition.get("value")):
            return False
    return True


def _rid(result: dict[str, Any], index: int) -> str:
    return str(result.get("id") or f"result-{index}")


def _source_of(result: dict[str, Any]) -> str:
    return str(
        result.get("source_id")
        or result.get("detected_platform")
        or result.get("source_name")
        or ""
    ).strip().lower()


def apply_rules(results: list[dict[str, Any]], rules: list[CorrelationRule] | None = None):
    """Run declarative rules over result dictionaries."""
    selected_rules = rules if rules is not None else load_rules()
    links = []
    for rule in selected_rules:
        buckets: dict[str, dict[str, set[str]]] = {}
        for index, result in enumerate(results):
            if not isinstance(result, dict) or not _passes_where(result, rule.where):
                continue
            value = _resolve(result, rule.group_by)
            key = str(value).strip().lower() if value is not None else ""
            if not key:
                continue
            bucket = buckets.setdefault(key, {"ids": set(), "sources": set()})
            bucket["ids"].add(_rid(result, index))
            source = _source_of(result)
            if source:
                bucket["sources"].add(source)
        for key, bucket in buckets.items():
            ids = sorted(bucket["ids"])
            sources = sorted(bucket["sources"])
            if len(ids) < rule.min_members or len(sources) < rule.min_sources:
                continue
            confidence = min(0.99, rule.confidence + 0.03 * max(0, len(sources) - 2))
            payload = {
                "kind": rule.kind,
                "key": key,
                "member_ids": ids,
                "sources": sources,
                "confidence": round(confidence, 3),
                "explanation": rule.explanation or rule.name or rule.kind,
            }
            links.append(CorrelationLink(**payload) if CorrelationLink else payload)
    return links
