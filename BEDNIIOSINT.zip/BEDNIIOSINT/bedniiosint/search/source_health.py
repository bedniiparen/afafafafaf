from __future__ import annotations

"""Per-connector health and success-rate observability."""

import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Iterator


@dataclass
class _Stat:
    attempts: int = 0
    successes: int = 0
    failures: int = 0
    total_latency: float = 0.0
    results: int = 0
    last_status: Any = None
    last_error: str = ""
    last_ts: float = 0.0


class SourceHealth:
    def __init__(self, *, clock=None) -> None:
        self._clock = clock or time.time
        self._stats: dict[str, _Stat] = {}
        self._lock = threading.Lock()

    def record(
        self,
        source_id: str,
        *,
        ok: bool,
        latency: float = 0.0,
        status: Any = None,
        results: int = 0,
        error: str = "",
    ) -> None:
        if not source_id:
            return
        with self._lock:
            stat = self._stats.setdefault(source_id, _Stat())
            stat.attempts += 1
            if ok:
                stat.successes += 1
            else:
                stat.failures += 1
                if error:
                    stat.last_error = error
            stat.total_latency += max(0.0, float(latency))
            stat.results += max(0, int(results))
            stat.last_status = status
            stat.last_ts = self._clock()

    @contextmanager
    def track(self, source_id: str, *, status: Any = None) -> Iterator[None]:
        start = self._clock()
        ok = True
        error = ""
        try:
            yield
        except Exception as exc:
            ok = False
            error = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            self.record(source_id, ok=ok, latency=self._clock() - start, status=status, error=error)

    def snapshot(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = []
            for source_id, stat in self._stats.items():
                attempts = stat.attempts or 1
                success_rate = stat.successes / attempts
                rows.append(
                    {
                        "source_id": source_id,
                        "requests": stat.attempts,
                        "attempts": stat.attempts,
                        "successes": stat.successes,
                        "failures": stat.failures,
                        "success_rate": round(success_rate, 3),
                        "avg_latency": round(stat.total_latency / attempts, 3),
                        "results": stat.results,
                        "last_status": stat.last_status,
                        "last_error": stat.last_error,
                        "last_ts": stat.last_ts,
                        "health": self._grade(success_rate),
                    }
                )
        rows.sort(key=lambda row: (row["success_rate"], row["attempts"]))
        return rows

    @staticmethod
    def _grade(rate: float) -> str:
        if rate >= 0.9:
            return "healthy"
        if rate >= 0.6:
            return "degraded"
        return "failing"

    def report_markdown(self) -> str:
        rows = self.snapshot()
        if not rows:
            return "No connector activity recorded."
        lines = [
            "Source health report",
            "--------------------",
            "{:<18} {:>8} {:>8} {:>9} {:>9}  {}".format(
                "source", "attempts", "ok_rate", "avg_lat", "results", "health"
            ),
        ]
        for row in rows:
            lines.append(
                "{:<18} {:>8} {:>8} {:>9} {:>9}  {}".format(
                    row["source_id"][:18],
                    row["attempts"],
                    row["success_rate"],
                    row["avg_latency"],
                    row["results"],
                    row["health"],
                )
            )
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        return {"sources": self.snapshot(), "generated_at": self._clock()}

    def clear(self) -> None:
        with self._lock:
            self._stats.clear()


GLOBAL_SOURCE_HEALTH = SourceHealth()
