from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from ..config import PACKAGE_DIR
from ..modules.username.scanner import load_sites


DEFAULT_SEARCH_ONLY_FILE = PACKAGE_DIR / "data" / "search_only_sites.json"

MARKDOWN_LINK_RE = re.compile(r"\[([^\]]{1,220})\]\((https?://[^)\s]+)\)")
BARE_URL_RE = re.compile(r"(?<!\()https?://[^\s<>)\"']+")


@dataclass(frozen=True)
class SearchOnlySite:
    name: str
    host: str
    url: str
    source: str
    category: str = "misc"
    license_note: str = ""
    overlap_username_catalog: bool = False

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def normalize_host(value: str) -> str:
    clean = str(value or "").strip()
    if not clean:
        return ""
    if "://" not in clean:
        clean = f"https://{clean}"
    parsed = urlparse(clean)
    host = (parsed.hostname or parsed.netloc or parsed.path.split("/", 1)[0]).strip().lower()
    if not host:
        return ""
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError:
        return ""
    host = host.removeprefix("www.").strip(".")
    if not re.fullmatch(r"(?:[a-z0-9-]{1,63}\.)+[a-z0-9-]{2,63}", host):
        return ""
    return host


def safe_site_key(value: str) -> str:
    clean = re.sub(r"[^a-z0-9]+", "_", str(value or "").lower()).strip("_")
    return clean[:80] or "site"


def username_catalog_hosts(*, include_disabled: bool = True) -> set[str]:
    hosts: set[str] = set()
    try:
        sites = load_sites()
    except (OSError, json.JSONDecodeError, KeyError):
        return hosts
    for site in sites.values():
        if not isinstance(site, dict):
            continue
        if not include_disabled and site.get("disabled"):
            continue
        for field in ("uri_pretty", "uri_check", "url", "urlMain", "urlProbe"):
            host = normalize_host(str(site.get(field) or ""))
            if host:
                hosts.add(host)
    return hosts


def username_catalog_disabled_search_sites() -> list[SearchOnlySite]:
    try:
        sites = load_sites()
    except (OSError, json.JSONDecodeError, KeyError):
        return []
    active_hosts = username_catalog_hosts(include_disabled=False)
    rows: list[SearchOnlySite] = []
    seen: set[str] = set()
    for name, site in sites.items():
        if not isinstance(site, dict) or not site.get("disabled"):
            continue
        host = ""
        for field in ("uri_pretty", "uri_check", "url", "urlMain", "urlProbe"):
            host = normalize_host(str(site.get(field) or ""))
            if host:
                break
        if not host or host in active_hosts or host in seen:
            continue
        seen.add(host)
        rows.append(
            SearchOnlySite(
                name=str(name or host).strip()[:160] or host,
                host=host,
                url=f"https://{host}/",
                source="username_catalog_disabled",
                category=str(site.get("cat") or site.get("category") or "misc"),
                license_note=(
                    "Derived from packaged username catalog rows disabled upstream; "
                    "used only for manual search-engine dorks."
                ),
                overlap_username_catalog=False,
            )
        )
    return rows


def parse_markdown_sites(
    text: str,
    *,
    source: str,
    category: str = "misc",
    license_note: str = "",
    existing_hosts: set[str] | None = None,
    skip_existing: bool = False,
) -> list[SearchOnlySite]:
    existing = existing_hosts or set()
    rows: list[SearchOnlySite] = []
    seen: set[str] = set()

    def add(name: str, url: str) -> None:
        clean_url = str(url or "").strip().rstrip(".,;")
        host = normalize_host(clean_url)
        if not host or host in seen:
            return
        overlap = host in existing
        if skip_existing and overlap:
            return
        seen.add(host)
        clean_name = re.sub(r"\s+", " ", str(name or "").strip()) or host
        rows.append(
            SearchOnlySite(
                name=clean_name[:160],
                host=host,
                url=f"https://{host}/",
                source=source,
                category=category,
                license_note=license_note,
                overlap_username_catalog=overlap,
            )
        )

    markdown_url_spans: list[tuple[int, int]] = []
    for match in MARKDOWN_LINK_RE.finditer(text or ""):
        markdown_url_spans.append((match.start(2), match.end(2)))
        add(match.group(1), match.group(2))

    for match in BARE_URL_RE.finditer(text or ""):
        url = match.group(0)
        if any(start <= match.start() and match.end() <= end for start, end in markdown_url_spans):
            continue
        add(normalize_host(url), url)

    return rows


def dedupe_sites(rows: list[SearchOnlySite]) -> list[SearchOnlySite]:
    unique: dict[str, SearchOnlySite] = {}
    for row in rows:
        if row.host and row.host not in unique:
            unique[row.host] = row
    return sorted(unique.values(), key=lambda row: (row.source, row.host))


def write_catalog(path: Path, rows: list[SearchOnlySite], *, source_notes: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": 1,
        "kind": "search_only_domain_catalog",
        "notes": [
            "Search-only domains are used for manual search-engine dorks.",
            "They are not treated as verified username profile templates.",
            *(source_notes or []),
        ],
        "count": len(rows),
        "sites": [row.as_dict() for row in rows],
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_search_only_sites(path: Path | None = None) -> list[SearchOnlySite]:
    src = Path(path or DEFAULT_SEARCH_ONLY_FILE)
    if not src.exists():
        return []
    try:
        payload = json.loads(src.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return []
    raw_sites = payload.get("sites") if isinstance(payload, dict) else payload
    if not isinstance(raw_sites, list):
        return []

    rows: list[SearchOnlySite] = []
    seen: set[str] = set()
    for item in raw_sites:
        if not isinstance(item, dict):
            continue
        host = normalize_host(str(item.get("host") or item.get("url") or ""))
        if not host or host in seen:
            continue
        seen.add(host)
        rows.append(
            SearchOnlySite(
                name=str(item.get("name") or host).strip()[:160] or host,
                host=host,
                url=str(item.get("url") or f"https://{host}/").strip() or f"https://{host}/",
                source=str(item.get("source") or "search_only").strip() or "search_only",
                category=str(item.get("category") or "misc").strip() or "misc",
                license_note=str(item.get("license_note") or "").strip(),
                overlap_username_catalog=bool(item.get("overlap_username_catalog")),
            )
        )
    return rows
