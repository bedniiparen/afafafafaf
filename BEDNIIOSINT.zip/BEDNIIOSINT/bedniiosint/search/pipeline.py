from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from ..catalog import registry_entries
from ..config import settings
from ..core.artifacts import capture_raw_result
from ..core.persist import add_entity_once
from ..core.source_record import record_source
from ..core.source_context import SourceRunContext
from ..core.source_pipeline import PipelineResult, run_source_pipeline
from ..core.target import detect_module
from ..storage.models import Case, Finding, TimelineEvent
from ..storage.sqlite import Storage
from .clustering import annotate_result_clusters, cluster_search_results
from .async_pipeline import run_connectors as run_standalone_connectors
from .candidate_verify import verify_candidate_results
from .concurrent import run_catalog_sources_concurrently
from .connectors import CONNECTOR_CLASSES
from .dorking import build_dorking_results
from .evidence import build_search_run_evidence, summarize_search_results
from .event_graph import build_search_event_plan
from .models import SearchResult
from .pivots import build_result_pivots
from .planner import SearchPlan, plan_search
from .presence import apply_presence_filter
from .report import build_search_report_summary, render_search_markdown
from .results import search_result_from_normalized_record
from .scoring import rank_and_score
from .source_registry import get_source
from .username_scan import build_username_scan_results


logger = logging.getLogger("bedniiosint.search.pipeline")

SEARCH_TO_CATALOG_SOURCE_IDS: dict[str, list[str]] = {
    "web_search": ["api:google_cse"],
    "github": ["api:github", "api:github_search"],
    "gitlab": ["api:gitlab"],
    "public_code_search": ["api:github_search"],
    "archive_discovery": ["api:wayback_cdx", "api:common_crawl"],
    "contact_discovery": ["api:hunter"],
    "social_profiles": [
        "api:hackernews",
        "api:codeforces",
        "api:bluesky",
        "api:dockerhub",
        "api:cratesio",
        "api:lichess",
        "api:duolingo",
        "api:reddit_about",
    ],
    "fediverse_profiles": ["api:mastodon_lookup"],
    "public_social_intel": ["api:open_measures"],
    "creator_video_search": ["api:youtube"],
    "email_enrichment": ["api:gravatar"],
    "email_reputation": ["api:emailrep", "api:hibp", "api:hunter"],
    "rdap": ["api:rdap"],
    "dns": ["api:google_dns", "api:cloudflare_dns"],
    "ip_enrichment": ["api:ipwhois", "api:ipinfo", "api:bgpview"],
    "ip_behavior_reputation": ["api:greynoise"],
    "crtsh": ["api:crtsh"],
    "wayback": ["api:wayback_cdx"],
    "urlscan": ["api:urlscan"],
    "passive_dns_enrichment": ["api:hackertarget"],
    "news_mentions": ["api:gdelt"],
    "media_reverse_search": ["api:tineye"],
    "opencorporates": ["api:opencorporates"],
    "business_knowledge_graph": ["api:wikidata", "api:companies_house", "api:peeringdb"],
    "geocode_public": ["api:nominatim"],
    "blockchain_explorer": ["api:blockchain_info", "api:blockstream", "api:blockchair"],
    "open_threat_feeds": ["api:alienvault_otx", "api:urlhaus", "api:threatfox", "api:malwarebazaar"],
    "phone_lookup": ["api:numverify", "api:veriphone", "api:twilio_lookup"],
    "attack_surface": ["api:shodan", "api:censys", "api:securitytrails"],
    "technology_fingerprint": ["api:builtwith", "api:wappalyzer"],
    "osint_aggregator": ["api:osintly_api"],
    "virustotal": ["api:virustotal"],
    "abuseipdb": ["api:abuseipdb"],
    "shodan": ["api:shodan"],
    "censys": ["api:censys"],
    "hibp": ["api:hibp"],
    "hunter": ["api:hunter"],
    "holehe": [],
}


QUERY_FANOUT_CATALOG_SOURCE_IDS = {
    "api:gdelt",
    "api:github_search",
    "api:google_cse",
    "api:open_measures",
    "api:youtube",
}

QUERY_FANOUT_SEARCH_SOURCE_IDS = {
    "creator_video_search",
    "news_mentions",
    "public_code_search",
    "public_social_intel",
    "web_search",
}

VARIANT_FANOUT_SEARCH_SOURCE_IDS = {
    "archive_discovery": {"domain", "url"},
    "contact_discovery": {"domain", "email"},
}

MAX_QUERY_FANOUT_PER_SOURCE = 10
MAX_VARIANT_FANOUT_PER_SOURCE = 6

SEARCH_RESULT_GROUP_ORDER: tuple[str, ...] = (
    "profiles",
    "music_platforms",
    "emails",
    "phones",
    "domains",
    "mentions",
    "review_search",
    "other",
)

SEARCH_ENGINE_HOSTS = {
    "www.google.com",
    "google.com",
    "www.bing.com",
    "bing.com",
    "search.brave.com",
    "duckduckgo.com",
    "www.duckduckgo.com",
}


def catalog_source_ids_for_search_sources(source_ids: list[str]) -> list[str]:
    selected: list[str] = []
    for source_id in source_ids:
        for catalog_id in SEARCH_TO_CATALOG_SOURCE_IDS.get(source_id, []):
            if catalog_id not in selected:
                selected.append(catalog_id)
    return selected


def standalone_connector_ids_for_search_sources(source_ids: list[str]) -> list[str]:
    selected: list[str] = []
    for source_id in source_ids:
        clean = str(source_id or "").strip()
        if clean in CONNECTOR_CLASSES and clean not in selected and not SEARCH_TO_CATALOG_SOURCE_IDS.get(clean):
            selected.append(clean)
    return selected


def catalog_source_ids_by_search_source(source_ids: list[str]) -> dict[str, list[str]]:
    return {
        source_id: list(SEARCH_TO_CATALOG_SOURCE_IDS.get(source_id, []))
        for source_id in source_ids
    }


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def filter_catalog_source_ids(
    catalog_source_ids: list[str],
    *,
    available_only: bool = False,
) -> tuple[list[str], list[dict[str, Any]]]:
    if not available_only:
        return list(catalog_source_ids), []
    catalog = {entry.id: entry.as_dict() for entry in registry_entries()}
    selected: list[str] = []
    skipped: list[dict[str, Any]] = []
    for source_id in catalog_source_ids:
        entry = catalog.get(source_id)
        if entry and bool(entry.get("configured")):
            selected.append(source_id)
            continue
        skipped.append(
            {
                "source_id": source_id,
                "reason": "not_configured" if entry else "unknown_catalog_source",
                "missing_env_vars": list(entry.get("env_vars") or []) if entry else [],
            }
        )
    return selected, skipped


def _source_by_catalog_id(search_sources: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    mapping: dict[str, dict[str, Any]] = {}
    for source in search_sources:
        for catalog_id in SEARCH_TO_CATALOG_SOURCE_IDS.get(str(source.get("id") or ""), []):
            mapping[catalog_id] = source
    return mapping


def _append_unique(items: list[str], value: str) -> None:
    clean = str(value or "").strip()
    if clean and clean not in items:
        items.append(clean)


def _query_fanout_targets(queries: list[str], *, limit: int = MAX_QUERY_FANOUT_PER_SOURCE) -> list[str]:
    candidates: list[str] = []
    for query in queries:
        clean = " ".join(str(query or "").split())
        if clean:
            _append_unique(candidates, clean)
    if not candidates:
        return []

    def priority(value: str) -> tuple[int, int, str]:
        lowered = value.lower()
        if "site:" in lowered:
            rank = 0
        elif any(marker in lowered for marker in ("filetype:", "inurl:", "intitle:", "ext:")):
            rank = 1
        elif any(marker in lowered for marker in (" OR ", " archive", " registry", " profile", " contact")):
            rank = 2
        elif '"' in value:
            rank = 3
        else:
            rank = 4
        return (rank, len(value), value)

    ordered = [candidates[0]]
    for query in sorted(candidates[1:], key=priority):
        _append_unique(ordered, query)
        if len(ordered) >= limit:
            break
    return ordered[:limit]


def _variant_fanout_targets(
    query_metadata: dict[str, Any],
    allowed_types: set[str],
    *,
    limit: int = MAX_VARIANT_FANOUT_PER_SOURCE,
) -> list[tuple[str, str]]:
    targets: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for variant in query_metadata.get("variant_details") or []:
        if not isinstance(variant, dict):
            continue
        entity_type = str(variant.get("entity_type") or "").strip().lower()
        value = str(variant.get("value") or "").strip()
        if not value or entity_type not in allowed_types:
            continue
        key = (entity_type, value)
        if key in seen:
            continue
        seen.add(key)
        targets.append(key)
        if len(targets) >= limit:
            break
    return targets


def _run_catalog_pipeline_segment(
    *,
    target: str,
    input_type: str,
    source_ids: list[str],
    save: bool,
    case_name: str | None,
    plugin_dir: Path | None,
    context: SourceRunContext | None,
    concurrent: bool,
    max_workers: int,
) -> PipelineResult:
    if not source_ids:
        return PipelineResult(target=target, input_type=input_type, sources=[])
    if concurrent and len(source_ids) > 1:
        return run_catalog_sources_concurrently(
            target,
            input_type=input_type,
            source_ids=source_ids,
            save=save,
            case_name=case_name,
            plugin_dir=plugin_dir,
            context=context,
            max_workers=max_workers,
        )
    return run_source_pipeline(
        target,
        input_type=input_type,
        source_ids=source_ids,
        available_only=False,
        save=save,
        case_name=case_name,
        plugin_dir=plugin_dir,
        context=context,
    )


def _merge_pipeline_segment(target: PipelineResult, segment: PipelineResult) -> None:
    target.results.extend(segment.results)
    target.normalized.extend(segment.normalized)
    target.persisted.extend(getattr(segment, "persisted", []))
    persisted_case = getattr(segment, "persisted_case", {})
    if persisted_case and not target.persisted_case:
        target.persisted_case = persisted_case


def _run_planned_catalog_pipeline(
    *,
    run_target: str,
    input_type: str,
    plan: SearchPlan,
    catalog_source_ids: list[str],
    save: bool,
    case_name: str | None,
    plugin_dir: Path | None,
    context: SourceRunContext | None,
    concurrent: bool,
    max_workers: int,
) -> PipelineResult:
    selected_catalog = set(catalog_source_ids)
    fanout_tasks: list[tuple[str, str, str, str]] = []
    fanout_catalog_ids: set[str] = set()

    for query in plan.queries:
        search_source_id = str(query.source_id or "")
        mapped_catalog_ids = [
            catalog_id
            for catalog_id in SEARCH_TO_CATALOG_SOURCE_IDS.get(search_source_id, [])
            if catalog_id in selected_catalog
        ]
        for catalog_id in mapped_catalog_ids:
            if (
                catalog_id in QUERY_FANOUT_CATALOG_SOURCE_IDS
                or search_source_id in QUERY_FANOUT_SEARCH_SOURCE_IDS
            ):
                for target_query in _query_fanout_targets(query.queries):
                    fanout_tasks.append((catalog_id, target_query, "query", search_source_id))
                fanout_catalog_ids.add(catalog_id)
                continue
            allowed_variant_types = VARIANT_FANOUT_SEARCH_SOURCE_IDS.get(search_source_id)
            if allowed_variant_types:
                variant_targets = _variant_fanout_targets(query.metadata, allowed_variant_types)
                for variant_type, variant_value in variant_targets:
                    fanout_tasks.append((catalog_id, variant_value, variant_type, search_source_id))
                if variant_targets:
                    fanout_catalog_ids.add(catalog_id)

    unique_tasks: list[tuple[str, str, str, str]] = []
    seen_tasks: set[tuple[str, str, str]] = set()
    for catalog_id, task_target, task_input_type, search_source_id in fanout_tasks:
        key = (catalog_id, task_target, task_input_type)
        if key in seen_tasks:
            continue
        seen_tasks.add(key)
        unique_tasks.append((catalog_id, task_target, task_input_type, search_source_id))

    exact_catalog_source_ids = [
        source_id for source_id in catalog_source_ids if source_id not in fanout_catalog_ids
    ]
    combined = PipelineResult(target=run_target, input_type=input_type, sources=list(catalog_source_ids))
    exact_segment = _run_catalog_pipeline_segment(
        target=run_target,
        input_type=input_type,
        source_ids=exact_catalog_source_ids,
        save=save,
        case_name=case_name,
        plugin_dir=plugin_dir,
        context=context,
        concurrent=concurrent,
        max_workers=max_workers,
    )
    _merge_pipeline_segment(combined, exact_segment)

    for catalog_id, task_target, task_input_type, search_source_id in unique_tasks:
        segment = _run_catalog_pipeline_segment(
            target=task_target,
            input_type=task_input_type,
            source_ids=[catalog_id],
            save=save,
            case_name=case_name,
            plugin_dir=plugin_dir,
            context=context,
            concurrent=False,
            max_workers=1,
        )
        fanout_meta = {
            "original_target": run_target,
            "search_source_id": search_source_id,
            "fanout_input_type": task_input_type,
            "fanout_target": task_target,
        }
        for result in segment.results:
            result["search_fanout"] = dict(fanout_meta)
        for normalized in segment.normalized:
            normalized["search_fanout"] = dict(fanout_meta)
        _merge_pipeline_segment(combined, segment)

    return combined


def _search_results_from_pipeline(
    normalized: list[dict[str, Any]],
    source_map: dict[str, dict[str, Any]],
    *,
    scope: str,
) -> list[SearchResult]:
    results: list[SearchResult] = []
    for record in normalized:
        results.append(
            search_result_from_normalized_record(
                record,
                source=source_map.get(str(record.get("source_id") or ""), {}),
                scope=scope,
            )
        )
    return results


def _result_dicts(results: list[SearchResult]) -> list[dict[str, Any]]:
    return [result.as_dict() for result in results]


def _sync_result_dicts(results: list[SearchResult], payloads: list[dict[str, Any]]) -> None:
    for result, payload in zip(results, payloads):
        normalized = payload.get("normalized_data")
        if isinstance(normalized, dict):
            result.normalized_data = normalized
        raw_data = payload.get("raw_data")
        if raw_data is not None:
            result.raw_data = raw_data
        try:
            result.confidence_score = float(payload.get("confidence_score"))
        except (TypeError, ValueError):
            pass


def _link_dict(link: Any) -> dict[str, Any]:
    if isinstance(link, dict):
        return dict(link)
    if hasattr(link, "as_dict"):
        data = link.as_dict()
        if isinstance(data, dict):
            return data
    return {}


def _dedupe_links(links: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_key: dict[tuple[str, str, tuple[str, ...]], dict[str, Any]] = {}
    for link in links:
        if not link:
            continue
        members = tuple(sorted(str(item) for item in (link.get("member_ids") or [])))
        key = (str(link.get("kind") or ""), str(link.get("key") or ""), members)
        existing = by_key.get(key)
        if existing is None or float(link.get("confidence") or 0.0) > float(existing.get("confidence") or 0.0):
            by_key[key] = link
    return sorted(
        by_key.values(),
        key=lambda row: (float(row.get("confidence") or 0.0), len(row.get("member_ids") or [])),
        reverse=True,
    )


def _cluster_links(clusters: list[dict[str, Any]]) -> list[dict[str, Any]]:
    links: list[dict[str, Any]] = []
    for cluster in clusters:
        members = [str(item) for item in (cluster.get("member_ids") or []) if item]
        if len(members) < 2:
            continue
        probability = float(cluster.get("probability") or 0.0)
        links.append(
            {
                "kind": "probabilistic_identity_cluster",
                "key": str(cluster.get("cluster_id") or ""),
                "member_ids": members,
                "sources": [],
                "confidence": round(probability, 3),
                "explanation": "Probabilistic identity cluster from combined correlation signals.",
            }
        )
    return links


def _build_search_correlations(result_dicts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    links: list[dict[str, Any]] = []
    try:
        from .correlation import build_correlations

        links.extend(_link_dict(link) for link in build_correlations(result_dicts))
    except Exception:
        logger.exception("built-in correlation rules failed")
    try:
        from .avatar_hash import avatar_correlations

        links.extend(_link_dict(link) for link in avatar_correlations(result_dicts))
    except Exception:
        logger.exception("avatar correlations failed")
    try:
        from .correlation_rules import apply_rules, load_rules

        links.extend(_link_dict(link) for link in apply_rules(result_dicts, load_rules(settings.correlation_rules_path or None)))
    except Exception:
        logger.exception("declarative correlation rules failed")
    return _dedupe_links(links)


def _safe_artifact_name(value: str) -> str:
    return "".join(char if char.isalnum() or char in "-_" else "_" for char in value).strip("_") or "case"


def _build_visual_artifacts(
    result_dicts: list[dict[str, Any]],
    links: list[dict[str, Any]],
    *,
    seed: str,
    seed_type: str,
    case_name: str | None = None,
    save: bool = False,
) -> dict[str, Any]:
    try:
        from .graphml_export import to_graphml, write_graphml
        from .html_report import render_html, write_report

        graphml = to_graphml(result_dicts, links, seed=seed, seed_type=seed_type)
        html = render_html(
            result_dicts,
            links,
            case_name=case_name or f"BEDNIIOSINT search: {seed}",
            seed=seed,
            seed_type=seed_type,
        )
        artifacts: dict[str, Any] = {
            "graphml": graphml,
            "html_report": html,
            "graphml_size": len(graphml),
            "html_report_size": len(html),
        }
        if save and case_name:
            out_dir = settings.db_dir.parent / "reports_out"
            safe = _safe_artifact_name(case_name)
            artifacts["graphml_path"] = write_graphml(
                out_dir / f"{safe}-search.graphml",
                result_dicts,
                links,
                seed=seed,
                seed_type=seed_type,
            )
            artifacts["html_report_path"] = write_report(
                out_dir / f"{safe}-interactive.html",
                result_dicts,
                links,
                case_name=case_name,
                seed=seed,
                seed_type=seed_type,
            )
        return artifacts
    except Exception:
        logger.exception("visual artifact generation failed")
        return {}


def _index_saved_search_results(
    *,
    case_name: str | None,
    result_dicts: list[dict[str, Any]],
) -> dict[str, Any]:
    if not case_name or not result_dicts:
        return {"enabled": False, "indexed": 0}
    try:
        from ..storage.fts import SearchResultFtsIndex

        db_path = settings.db_path(case_name)
        index = SearchResultFtsIndex(db_path)
        keys = index.index_results(result_dicts, case_name=case_name)
        return {
            "enabled": True,
            "case": case_name,
            "db_path": str(db_path),
            "fts_enabled": index.fts_enabled,
            "indexed": len(keys),
        }
    except Exception as exc:
        logger.exception("search FTS indexing failed")
        return {"enabled": False, "indexed": 0, "error": str(exc)}


def _apply_profile_extraction(results: list[SearchResult]) -> None:
    if not settings.search_profile_extract_enabled or not results:
        return
    try:
        from .profile_extract import enrich_results

        payloads = _result_dicts(results)
        enrich_results(payloads, limit=settings.search_profile_extract_limit)
        _sync_result_dicts(results, payloads)
    except Exception:
        logger.exception("profile extraction enrichment failed")


def _apply_avatar_hashing(results: list[SearchResult]) -> None:
    if not settings.search_avatar_hash_enabled or not results:
        return
    try:
        from .avatar_hash import attach_avatar_hashes

        payloads = _result_dicts(results)
        attach_avatar_hashes(payloads, limit=settings.search_avatar_hash_limit)
        _sync_result_dicts(results, payloads)
    except Exception:
        logger.exception("avatar hash enrichment failed")


def _is_search_engine_url(value: str) -> bool:
    raw = str(value or "").strip()
    if not raw:
        return False
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = (parsed.netloc or "").split("@")[-1].split(":")[0].lower()
    path = parsed.path.lower()
    query = parsed.query.lower()
    return host in SEARCH_ENGINE_HOSTS and (
        path.startswith("/search")
        or bool(query)
        or host in {"duckduckgo.com", "www.duckduckgo.com"}
    )


def _looks_like_email(value: str) -> bool:
    text = str(value or "").strip()
    return "@" in text and "." in text.rsplit("@", 1)[-1] and " " not in text


def _looks_like_phone(value: str) -> bool:
    text = str(value or "").strip()
    digits = "".join(char for char in text if char.isdigit())
    return len(digits) >= 7 and all(char.isdigit() or char in "+ ().-" for char in text)


def _looks_like_domain(value: str) -> bool:
    text = str(value or "").strip().lower()
    if "://" in text:
        text = urlparse(text).netloc
    text = text.split("/", 1)[0].split("@")[-1].split(":")[0].strip(".")
    return "." in text and " " not in text and all(part for part in text.split("."))


def _result_group_for(result: SearchResult) -> str:
    normalized = result.normalized_data if isinstance(result.normalized_data, dict) else {}
    explicit = str(normalized.get("result_group") or "").strip().lower()
    url = str(result.url or "").strip()
    entity_type = str(result.entity_type or "").strip().lower()
    matched = str(result.matched_entity or result.matched_variant or "").strip()
    tags = {str(tag or "").strip().lower() for tag in (result.tags or [])}
    source_id = str(result.source_id or "").strip().lower()

    if _is_search_engine_url(url):
        return "review_search"
    if explicit in SEARCH_RESULT_GROUP_ORDER:
        return explicit
    if "profile" in tags or "username_scan" in tags or "direct_profile_candidate" in tags:
        return "profiles"
    if "music" in tags or source_id.startswith("dorking:music_"):
        return "music_platforms"
    if entity_type == "email" or _looks_like_email(matched):
        return "emails"
    if entity_type == "phone" or _looks_like_phone(matched):
        return "phones"
    if entity_type == "domain" or _looks_like_domain(matched):
        return "domains"
    if entity_type in {"url", "query"} or url:
        return "mentions"
    return "other"


def _compact_group_item(result: SearchResult) -> dict[str, Any]:
    normalized = result.normalized_data if isinstance(result.normalized_data, dict) else {}
    return {
        "id": result.id,
        "source_id": result.source_id,
        "source_name": result.source_name,
        "title": result.title,
        "url": result.url,
        "entity_type": result.entity_type,
        "matched_entity": result.matched_entity,
        "matched_variant": result.matched_variant,
        "platform": result.detected_platform,
        "lead_kind": normalized.get("lead_kind") or "",
        "candidate_status": normalized.get("candidate_status") or "",
        "site_category": normalized.get("site_category") or "",
        "confidence_score": result.confidence_score,
        "tags": list(result.tags or []),
    }


def group_search_results_by_data_type(results: list[SearchResult]) -> dict[str, dict[str, Any]]:
    grouped: dict[str, list[SearchResult]] = {key: [] for key in SEARCH_RESULT_GROUP_ORDER}
    for result in results:
        group = _result_group_for(result)
        grouped.setdefault(group, []).append(result)
    return {
        key: {
            "count": len(rows),
            "result_ids": [row.id for row in rows],
            "items": [_compact_group_item(row) for row in rows],
        }
        for key, rows in grouped.items()
        if rows or key in SEARCH_RESULT_GROUP_ORDER
    }


PROFILE_STRICT_ENTITY_TYPES = {"username", "profile", "fediverse_account"}


def _is_profile_search(plan: SearchPlan, input_type: str) -> bool:
    selected = str(input_type or plan.entity_type or "").strip().lower()
    if selected in PROFILE_STRICT_ENTITY_TYPES:
        return True
    scope = str(plan.scope or "").strip().lower()
    resolved = getattr(plan, "resolved_scope", {}) or {}
    path = str(resolved.get("path") if isinstance(resolved, dict) else "").strip().lower()
    return "profile" in scope or "profile" in path or "identity/username" in path


def _candidate_state(result: SearchResult) -> str:
    data = result.normalized_data if isinstance(result.normalized_data, dict) else {}
    verification = data.get("candidate_verification")
    if isinstance(verification, dict):
        return str(verification.get("state") or "").strip().lower()
    return ""


def _strict_profile_keep(result: SearchResult) -> bool:
    source_id = str(result.source_id or "").strip().lower()
    data = result.normalized_data if isinstance(result.normalized_data, dict) else {}
    tags = {str(tag or "").strip().lower() for tag in (result.tags or [])}

    if source_id.startswith("username_scan:"):
        return str(data.get("status") or "").strip().lower() == "exists"
    if source_id.startswith("dorking:"):
        lead_kind = str(data.get("lead_kind") or "").strip().lower()
        if lead_kind == "search_only_domain_dork":
            return False
        if lead_kind == "search_engine_query" or _is_search_engine_url(str(result.url or "")):
            return False
        if lead_kind in {"direct_profile_candidate", "direct_platform_search"} or "candidate_url" in tags:
            return _candidate_state(result) == "present" or "reachable" in tags
        return False
    return True


def _apply_strict_profile_results(
    results: list[SearchResult],
    *,
    plan: SearchPlan,
    input_type: str,
) -> list[SearchResult]:
    if not getattr(settings, "strict_profile_results", True):
        return results
    if not _is_profile_search(plan, input_type):
        return results
    return [result for result in results if _strict_profile_keep(result)]


def _persist_review_only_search_results(
    *,
    case_name: str,
    target: str,
    entity_type: str,
    results: list[SearchResult],
) -> dict[str, Any]:
    review_results = [
        result
        for result in results
        if str(result.source_id or "").startswith("dorking:")
    ]
    counts = {
        "case_created": 0,
        "sources": 0,
        "findings": 0,
        "entities": 0,
        "timeline": 0,
        "evidence": 0,
    }
    if not review_results:
        return {"meta": {"case": case_name, "module": "search_dorking", "target": target}, "counts": counts}

    storage = Storage(settings.db_path(case_name))
    finding_refs: list[tuple[int, SearchResult]] = []
    with storage.session() as session:
        case = Case(name=case_name, target=target, module="search_dorking")
        session.add(case)
        session.commit()
        session.refresh(case)
        if case.id is None:
            raise RuntimeError("search dorking case was not persisted")
        counts["case_created"] = 1

        source_ids_seen: set[str] = set()
        for result in review_results:
            source_id = str(result.source_id or "dorking")
            raw_dorking = result.normalized_data.get("dorking") if isinstance(result.normalized_data, dict) else {}
            if not isinstance(raw_dorking, dict):
                raw_dorking = {}
            result_markers = ["review_only", "dorking", "manual_verification_required"]
            if result.raw_data.get("direct_candidate") or raw_dorking.get("direct_candidate") or "candidate_url" in result.tags:
                result_markers.append("candidate_url")
            lead_kind = str(result.normalized_data.get("lead_kind") or raw_dorking.get("lead_kind") or "").strip()
            if lead_kind:
                result_markers.append(f"lead_kind:{lead_kind}")
            candidate_status = str(result.normalized_data.get("candidate_status") or "").strip()
            if candidate_status:
                result_markers.append(f"candidate_status:{candidate_status}")
            site_category = str(result.normalized_data.get("site_category") or "").strip()
            if site_category:
                result_markers.append(f"site_category:{site_category}")
            if result.normalized_data.get("sherlock_style"):
                result_markers.append("sherlock_style")
            if result.normalized_data.get("regex_check"):
                result_markers.append("site_regex_checked")
            if "candidate_url" not in result_markers:
                result_markers.append("no_confirmation_signals")
            if source_id not in source_ids_seen:
                record_source(
                    session,
                    case_id=case.id,
                    name=result.source_name or source_id,
                    source_id=source_id,
                    url_main=result.url,
                    category="search_dorking",
                    rejected=False,
                    success_count=1,
                    error_count=0,
                    notes="review_only dorking lead; manual verification required",
                )
                source_ids_seen.add(source_id)
                counts["sources"] += 1

            entity_value = result.url or result.matched_variant or result.matched_entity or target
            entity_type_for_finding = "url" if result.url else (result.entity_type or entity_type)
            add_entity_once(
                session,
                case_id=case.id,
                type=entity_type_for_finding,
                value=entity_value,
            )
            counts["entities"] += 1
            finding = Finding(
                case_id=case.id,
                source_name=result.source_name or source_id,
                source_id=source_id,
                source_reliability=0.25,
                entity_type=entity_type_for_finding,
                entity_value=entity_value,
                finding_type="dorking_lead",
                profile_url=result.url,
                status="candidate" if "candidate_url" in result_markers else "unknown",
                page_title=result.title,
                matched_markers=",".join(result_markers),
                confidence=0.0,
                confidence_reason="Review-only dorking lead; no source confirmation was collected.",
                rejected=False,
                reject_reason="",
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("search dorking finding was not persisted")
            finding_refs.append((finding.id, result))
            counts["findings"] += 1

            session.add(
                TimelineEvent(
                    case_id=case.id,
                    finding_id=finding.id,
                    kind="dorking_lead_generated",
                    entity_type=entity_type_for_finding,
                    entity_value=entity_value,
                    source_name=source_id,
                    confidence=0.0,
                    description="Review-only dorking/social lead generated for manual verification.",
                )
            )
            counts["timeline"] += 1
        session.commit()
        case_id = case.id

    for finding_id, result in finding_refs:
        capture_raw_result(
            storage,
            case_name=case_name,
            case_id=case_id,
            finding_id=finding_id,
            source_module="search_dorking",
            payload=result.as_dict(),
            url=result.url,
            final_url=result.url,
            http_status=None,
            confidence=0.0,
            name_hint=result.source_id,
            method="GET",
            adapter_version="bedniiosint.search.dorking/1.0",
        )
        counts["evidence"] += 1

    return {
        "meta": {
            "case": case_name,
            "module": "search_dorking",
            "target": target,
            "input_type": entity_type,
        },
        "counts": counts,
    }


def run_planned_search_pipeline(
    entity_input: str,
    *,
    entity_type: str | None = None,
    scope: str | None = None,
    max_sources: int | None = None,
    include_auth_required: bool = False,
    source_ids: list[str] | None = None,
    available_only: bool = False,
    save: bool = False,
    case_name: str | None = None,
    plugin_dir: Path | None = None,
    context: SourceRunContext | None = None,
    search_plan: SearchPlan | None = None,
    concurrent: bool = False,
    max_workers: int = 4,
    include_dorking: bool = False,
    include_username_scan: bool = False,
) -> dict[str, Any]:
    started_at = _utc_now_iso()
    plan = search_plan or plan_search(
        entity_input,
        entity_type=entity_type,
        scope=scope,
        max_sources=max_sources,
        include_auth_required=include_auth_required,
        source_ids=source_ids,
    )
    run_target = plan.entity_input
    if context is not None:
        context.scope = plan.scope
    search_source_ids = [str(source.get("id") or "") for source in plan.sources]
    planned_catalog_source_ids = catalog_source_ids_for_search_sources(search_source_ids)
    standalone_connector_ids = standalone_connector_ids_for_search_sources(search_source_ids)
    catalog_source_ids, skipped_catalog_sources = filter_catalog_source_ids(
        planned_catalog_source_ids,
        available_only=available_only,
    )
    input_type = entity_type or plan.entity_type or detect_module(run_target)
    pipeline = _run_planned_catalog_pipeline(
        run_target=run_target,
        input_type=input_type,
        plan=plan,
        catalog_source_ids=catalog_source_ids,
        save=save,
        case_name=case_name,
        plugin_dir=plugin_dir,
        context=context,
        concurrent=concurrent,
        max_workers=max_workers,
    )
    source_map = _source_by_catalog_id(plan.sources)
    search_results = _search_results_from_pipeline(
        pipeline.normalized,
        source_map,
        scope=plan.scope,
    )
    standalone_results: list[SearchResult] = []
    if standalone_connector_ids:
        variant_values = [
            variant.value
            for variant in plan.variant_details
            if variant.value and variant.value != run_target
        ][:MAX_VARIANT_FANOUT_PER_SOURCE]
        standalone_results = run_standalone_connectors(
            [CONNECTOR_CLASSES[source_id]() for source_id in standalone_connector_ids],
            {"type": input_type, "value": run_target},
            scope=plan.scope,
            variants=variant_values,
            query=run_target,
        )
        search_results = [*search_results, *standalone_results]
    username_scan_results: list[SearchResult] = []
    if include_username_scan:
        username_scan_results = build_username_scan_results(plan, context=context)
        search_results = [*search_results, *username_scan_results]
    dorking_results: list[SearchResult] = []
    if include_dorking:
        dorking_results = build_dorking_results(plan)
        search_results = [*search_results, *dorking_results]
    enrichment_type = input_type or plan.entity_type
    if getattr(settings, "account_existence_enabled", True):
        try:
            from .account_existence import build_account_existence_results

            search_results = [
                *search_results,
                *build_account_existence_results(
                    run_target,
                    enrichment_type,
                    settings=settings,
                ),
            ]
        except Exception:
            logger.exception("account existence enrichment failed")
    if getattr(settings, "breach_enabled", True):
        try:
            from .breach import check_breaches

            search_results = [
                *search_results,
                *check_breaches(run_target, enrichment_type, settings=settings),
            ]
        except Exception:
            logger.exception("breach enrichment failed")
    # Actively verify unverified candidate URLs (dorking/profile guesses) so
    # dead soft-404 links are dropped instead of being surfaced as results.
    search_results = verify_candidate_results(search_results)
    # Global soft-404/negative-content filter as a safety net for fetched
    # results that slipped past per-source presence checks.
    if settings.presence_filter_enabled:
        search_results = apply_presence_filter(
            search_results, drop_absent=settings.presence_drop_absent
        )
    search_results = _apply_strict_profile_results(
        search_results,
        plan=plan,
        input_type=input_type,
    )
    _apply_profile_extraction(search_results)
    search_results = annotate_result_clusters(
        rank_and_score(run_target, search_results, apply_presence=False)
    )
    _apply_avatar_hashing(search_results)
    result_dicts_for_artifacts = _result_dicts(search_results)
    search_correlations = _build_search_correlations(result_dicts_for_artifacts)
    identities: list[dict[str, Any]] = []
    identity_clusters: list[dict[str, Any]] = []
    if getattr(settings, "identity_resolution_enabled", True):
        try:
            from .identity import build_identities

            identities = build_identities(search_results, search_correlations)
            result_dicts_for_artifacts = _result_dicts(search_results)
        except Exception:
            logger.exception("identity resolution failed")
        try:
            from .entity_resolution import resolve_identities

            identity_clusters = [
                cluster.as_dict()
                for cluster in resolve_identities(
                    result_dicts_for_artifacts,
                    min_probability=0.6,
                )
            ]
        except Exception:
            logger.exception("probabilistic identity clustering failed")
    if getattr(settings, "evidence_capture_enabled", True):
        try:
            from .evidence import attach_evidence

            attach_evidence(search_results, settings=settings)
            result_dicts_for_artifacts = _result_dicts(search_results)
        except Exception:
            logger.exception("evidence capture failed")
    final_standalone_results = [
        result for result in search_results if result.source_id in standalone_connector_ids
    ]
    final_username_scan_results = [
        result for result in search_results if result.source_id.startswith("username_scan")
    ]
    final_dorking_results = [
        result for result in search_results if result.source_id.startswith("dorking:")
    ]
    persisted_review_only: dict[str, Any] = {}
    if save and case_name and final_dorking_results:
        persisted_review_only = _persist_review_only_search_results(
            case_name=case_name,
            target=run_target,
            entity_type=entity_type or plan.entity_type,
            results=final_dorking_results,
        )
    finished_at = _utc_now_iso()
    run_evidence = build_search_run_evidence(
        entity_input=run_target,
        entity_type=entity_type or plan.entity_type,
        scope=plan.scope,
        plan=plan.as_dict(),
        pipeline=pipeline.as_dict(),
        results=search_results,
        skipped_catalog_sources=skipped_catalog_sources,
        catalog_source_ids_by_search_id=catalog_source_ids_by_search_source(search_source_ids),
        started_at=started_at,
        finished_at=finished_at,
        include_auth_required=include_auth_required,
        configured_only=available_only,
    )
    result_clusters = cluster_search_results(search_results)
    result_groups = group_search_results_by_data_type(search_results)
    source_event_plan = build_search_event_plan(
        plan,
        catalog_source_ids_by_search_id=catalog_source_ids_by_search_source(search_source_ids),
        skipped_catalog_sources=skipped_catalog_sources,
    )
    result_pivots = build_result_pivots(plan, search_results, result_groups)
    graph_links = _dedupe_links([*search_correlations, *_cluster_links(identity_clusters)])
    visual_artifacts = _build_visual_artifacts(
        result_dicts_for_artifacts,
        graph_links,
        seed=run_target,
        seed_type=entity_type or plan.entity_type,
        case_name=case_name,
        save=save,
    )
    search_fts = (
        _index_saved_search_results(
            case_name=case_name,
            result_dicts=result_dicts_for_artifacts,
        )
        if save
        else {"enabled": False, "indexed": 0}
    )
    try:
        from .source_health import GLOBAL_SOURCE_HEALTH

        source_health = GLOBAL_SOURCE_HEALTH.to_dict()
        source_health_markdown = GLOBAL_SOURCE_HEALTH.report_markdown()
    except Exception:
        source_health = {"sources": []}
        source_health_markdown = "No connector activity recorded."
    payload = {
        "target": entity_input,
        "entity_input": run_target,
        "resolved_target": run_target,
        "entity_type": entity_type or plan.entity_type,
        "scope": plan.scope,
        "execution": {
            "mode": "concurrent" if concurrent else "sequential",
            "max_workers": max_workers if concurrent else 1,
        },
        "search_source_ids": search_source_ids,
        "catalog_source_ids": catalog_source_ids,
        "planned_catalog_source_ids": planned_catalog_source_ids,
        "standalone_connector_ids": standalone_connector_ids,
        "skipped_catalog_sources": skipped_catalog_sources,
        "plan": plan.as_dict(),
        "pipeline": pipeline.as_dict(),
        "search_results": result_dicts_for_artifacts,
        "correlations": search_correlations,
        "identities": identities,
        "identity_clusters": identity_clusters,
        "visual_artifacts": visual_artifacts,
        "search_fts": search_fts,
        "source_health": source_health,
        "source_health_markdown": source_health_markdown,
        "result_groups": result_groups,
        "result_group_counts": {
            key: int(group.get("count") or 0)
            for key, group in result_groups.items()
        },
        "source_event_plan": source_event_plan,
        "result_pivots": result_pivots,
        "result_clusters": result_clusters,
        "dedup_summary": {
            "clusters": len(result_clusters),
            "confirmed": sum(1 for row in result_clusters if row.get("status") == "confirmed"),
            "possible": sum(1 for row in result_clusters if row.get("status") == "possible"),
            "weak": sum(1 for row in result_clusters if row.get("status") == "weak"),
            "unconfirmed": sum(1 for row in result_clusters if row.get("status") == "unconfirmed"),
        },
        "evidence_summary": summarize_search_results(search_results),
        "run_evidence": run_evidence.as_dict(),
        "run_summary": run_evidence.summary,
        "persisted_review_only": persisted_review_only,
        "counts": {
            "search_sources": len(search_source_ids),
            "catalog_sources": len(catalog_source_ids),
            "planned_catalog_sources": len(planned_catalog_source_ids),
            "standalone_connectors": len(standalone_connector_ids),
            "standalone_results": len(final_standalone_results),
            "skipped_catalog_sources": len(skipped_catalog_sources),
            "search_results": len(search_results),
            "dorking_results": len(final_dorking_results),
            "username_scan_results": len(final_username_scan_results),
            "ok": sum(1 for row in pipeline.results if row.get("status") == "ok"),
            "missing_keys": sum(1 for row in pipeline.results if row.get("status") == "missing_keys"),
        },
    }
    payload["report_summary"] = build_search_report_summary(payload)
    payload["report_markdown"] = render_search_markdown(payload)
    return payload


def get_search_source(source_id: str) -> dict[str, Any]:
    return get_source(source_id)
