from __future__ import annotations

"""Export search/investigation results to GraphML."""

from pathlib import Path
from typing import Any, Iterable
from xml.sax.saxutils import escape, quoteattr

_ATTRS = [
    ("label", "string", "node"),
    ("ntype", "string", "node"),
    ("source", "string", "node"),
    ("url", "string", "node"),
    ("confidence", "double", "node"),
    ("etype", "string", "edge"),
    ("weight", "double", "edge"),
]


def _as_dict(result: Any) -> dict[str, Any]:
    if isinstance(result, dict):
        return result
    for attr in ("as_dict", "to_dict"):
        method = getattr(result, attr, None)
        if callable(method):
            try:
                value = method()
            except Exception:
                continue
            if isinstance(value, dict):
                return value
    return {}


def _link_dict(link: Any) -> dict[str, Any]:
    if isinstance(link, dict):
        return dict(link)
    method = getattr(link, "as_dict", None)
    if callable(method):
        try:
            value = method()
        except Exception:
            value = None
        if isinstance(value, dict):
            return value
    return {
        "kind": getattr(link, "kind", ""),
        "member_ids": list(getattr(link, "member_ids", []) or []),
        "confidence": getattr(link, "confidence", 0.0),
    }


def _rid(result: dict[str, Any], index: int) -> str:
    return str(result.get("id") or f"result-{index}")


def build_graph(
    results: Iterable[Any],
    links: Iterable[Any] | None = None,
    *,
    seed: str | None = None,
    seed_type: str = "entity",
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    seen_nodes: set[str] = set()

    def add_node(node_id: str, **data: Any) -> None:
        if node_id and node_id not in seen_nodes:
            seen_nodes.add(node_id)
            nodes.append({"id": node_id, **data})

    if seed:
        add_node(f"seed:{seed}", label=seed, ntype=seed_type, source="seed", url="", confidence=1.0)

    for index, raw in enumerate(results):
        result = _as_dict(raw)
        if not result:
            continue
        node_id = _rid(result, index)
        add_node(
            node_id,
            label=str(result.get("title") or result.get("matched_entity") or node_id),
            ntype=str(result.get("entity_type") or "result"),
            source=str(result.get("source_id") or result.get("source_name") or ""),
            url=str(result.get("url") or ""),
            confidence=float(result.get("confidence_score") or 0.0),
        )
        if seed:
            edges.append({"source": node_id, "target": f"seed:{seed}", "etype": "found_for", "weight": 1.0})

    for link in links or []:
        data = _link_dict(link)
        members = [str(member) for member in (data.get("member_ids") or [])]
        weight = float(data.get("confidence") or 0.5)
        kind = str(data.get("kind") or "correlated")
        for left in range(len(members)):
            for right in range(left + 1, len(members)):
                if members[left] in seen_nodes and members[right] in seen_nodes:
                    edges.append(
                        {
                            "source": members[left],
                            "target": members[right],
                            "etype": kind,
                            "weight": weight,
                        }
                    )
    return nodes, edges


def to_graphml(
    results: Iterable[Any],
    links: Iterable[Any] | None = None,
    *,
    seed: str | None = None,
    seed_type: str = "entity",
) -> str:
    nodes, edges = build_graph(results, links, seed=seed, seed_type=seed_type)
    out: list[str] = ['<?xml version="1.0" encoding="UTF-8"?>']
    out.append('<graphml xmlns="http://graphml.graphdrawing.org/xmlns">')
    for name, graph_type, domain in _ATTRS:
        out.append(
            f'  <key id={quoteattr(name)} for="{domain}" attr.name="{name}" attr.type="{graph_type}"/>'
        )
    out.append('  <graph edgedefault="directed">')
    for node in nodes:
        out.append(f'    <node id={quoteattr(node["id"])}>')
        for name, _graph_type, domain in _ATTRS:
            if domain == "node" and name in node:
                out.append(f'      <data key={quoteattr(name)}>{escape(str(node[name]))}</data>')
        out.append("    </node>")
    for index, edge in enumerate(edges):
        out.append(
            f'    <edge id={quoteattr(f"e{index}")} '
            f'source={quoteattr(edge["source"])} target={quoteattr(edge["target"])}>'
        )
        for name, _graph_type, domain in _ATTRS:
            if domain == "edge" and name in edge:
                out.append(f'      <data key={quoteattr(name)}>{escape(str(edge[name]))}</data>')
        out.append("    </edge>")
    out.append("  </graph>")
    out.append("</graphml>")
    return "\n".join(out)


def write_graphml(
    path: str | Path,
    results: Iterable[Any],
    links: Iterable[Any] | None = None,
    *,
    seed: str | None = None,
    seed_type: str = "entity",
) -> str:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(to_graphml(results, links, seed=seed, seed_type=seed_type), encoding="utf-8")
    return str(output)
