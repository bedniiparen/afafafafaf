from __future__ import annotations

"""Active presence verification via control selectors."""

import random
import string
from dataclasses import dataclass, field
from typing import Any, Callable

from .presence import SOFT_NEGATIVE_MARKERS, STRONG_NEGATIVE_MARKERS


Fetch = Callable[[str], dict[str, Any]]
BuildUrl = Callable[[str], str]
_ALPHANUM = string.ascii_lowercase + string.digits


def _random_token(length: int = 16) -> str:
    return "".join(random.choice(_ALPHANUM) for _ in range(length))


def make_control_selectors(entity_type: str, count: int = 2) -> list[str]:
    selected = (entity_type or "username").lower()
    selectors: list[str] = []
    for _ in range(max(1, count)):
        token = "zz" + _random_token(14)
        if selected == "email":
            selectors.append(f"{token}@example-not-real-{_random_token(6)}.com")
        elif selected == "domain":
            selectors.append(f"{token}-not-real.com")
        else:
            selectors.append(token)
    return selectors


def _looks_present(payload: dict[str, Any]) -> bool:
    status = payload.get("status_code")
    text = str(payload.get("text") or "").lower()
    if isinstance(status, int) and status in (404, 410):
        return False
    if any(marker in text for marker in STRONG_NEGATIVE_MARKERS):
        return False
    if any(marker in text for marker in SOFT_NEGATIVE_MARKERS) and len(text) <= 600:
        return False
    if isinstance(status, int):
        return status < 400
    return bool(text)


@dataclass
class ControlProbeResult:
    false_positive_prone: bool
    positives: int
    samples: int
    reason: str = ""
    signals: list[str] = field(default_factory=list)


def probe_control(
    fetch: Fetch,
    build_url: BuildUrl,
    entity_type: str,
    *,
    samples: int = 2,
) -> ControlProbeResult:
    selectors = make_control_selectors(entity_type, samples)
    positives = 0
    signals: list[str] = []
    for selector in selectors:
        try:
            payload = fetch(build_url(selector))
        except Exception as exc:  # noqa: BLE001
            signals.append(f"control_error:{type(exc).__name__}")
            continue
        if _looks_present(payload):
            positives += 1
            signals.append(f"control_positive:{selector[:8]}")
    prone = positives > 0
    reason = (
        f"{positives}/{len(selectors)} control selectors returned a positive"
        if prone
        else "control selectors correctly returned absent"
    )
    return ControlProbeResult(prone, positives, len(selectors), reason, signals)


@dataclass
class PresenceCheck:
    state: str
    reason: str = ""


def verify_presence(
    fetch: Fetch,
    build_url: BuildUrl,
    target: str,
    entity_type: str,
    *,
    control_samples: int = 2,
) -> PresenceCheck:
    control = probe_control(fetch, build_url, entity_type, samples=control_samples)
    try:
        payload = fetch(build_url(target))
    except Exception as exc:  # noqa: BLE001
        return PresenceCheck("uncertain", f"fetch error: {type(exc).__name__}")
    present = _looks_present(payload)
    if not present:
        return PresenceCheck("absent", "target returned a negative/soft-404 page")
    if control.false_positive_prone:
        return PresenceCheck("uncertain", "site also matched control selector; manual review")
    return PresenceCheck("found", "target present and control absent")
