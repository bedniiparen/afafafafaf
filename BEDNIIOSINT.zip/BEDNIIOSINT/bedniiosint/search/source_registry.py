from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


DEFAULT_REGISTRY_PATH = Path(__file__).resolve().parents[2] / "data" / "source_registry.json"

REQUIRED_SOURCE_FIELDS = {
    "id",
    "name",
    "category",
    "supported_entity_types",
    "scopes",
    "base_url",
    "api_type",
    "auth_required",
    "legal_status",
    "tos_notes",
    "rate_limit",
    "timeout",
    "retry_policy",
    "confidence_weight",
    "reliability_score",
    "freshness_weight",
    "parser_type",
    "output_schema",
    "tags",
    "examples",
}


class SourceRegistryError(ValueError):
    """Raised when the source registry is missing or invalid."""


class UnknownSourceError(SourceRegistryError):
    """Raised when a caller asks for a source id not present in the registry."""


@dataclass
class SourceRegistry:
    path: Path
    sources: list[dict[str, Any]]
    version: int = 1

    def by_id(self) -> dict[str, dict[str, Any]]:
        return {str(source.get("id")): source for source in self.sources}


_DEFAULT_REGISTRY: SourceRegistry | None = None


def load_source_registry(path: str | Path | None = None) -> SourceRegistry:
    registry_path = Path(path) if path is not None else DEFAULT_REGISTRY_PATH
    if not registry_path.exists():
        raise SourceRegistryError(f"source registry not found: {registry_path}")
    try:
        payload = json.loads(registry_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SourceRegistryError(f"source registry JSON is invalid: {exc}") from exc
    sources = payload.get("sources")
    if not isinstance(sources, list):
        raise SourceRegistryError("source registry must contain a list field: sources")
    registry = SourceRegistry(
        path=registry_path,
        version=int(payload.get("version") or 1),
        sources=[dict(source) for source in sources],
    )
    validate_source_registry(registry)
    return registry


def _default_registry() -> SourceRegistry:
    global _DEFAULT_REGISTRY
    if _DEFAULT_REGISTRY is None:
        _DEFAULT_REGISTRY = load_source_registry()
    return _DEFAULT_REGISTRY


def get_source(source_id: str, registry: SourceRegistry | None = None) -> dict[str, Any]:
    selected = registry or _default_registry()
    source = selected.by_id().get(source_id)
    if source is None:
        known = ", ".join(sorted(selected.by_id()))
        raise UnknownSourceError(f"unknown source_id '{source_id}'. Known sources: {known}")
    return dict(source)


def list_sources(registry: SourceRegistry | None = None) -> list[dict[str, Any]]:
    return [dict(source) for source in (registry or _default_registry()).sources]


def filter_sources(
    entity_type: str | None = None,
    scope: str | None = None,
    category: str | None = None,
    *,
    registry: SourceRegistry | None = None,
) -> list[dict[str, Any]]:
    rows = list_sources(registry)
    if entity_type:
        selected = entity_type.strip().lower()
        rows = [
            source
            for source in rows
            if selected in {str(item).lower() for item in source.get("supported_entity_types", [])}
        ]
    if scope:
        selected_scope = scope.strip().lower()
        rows = [
            source
            for source in rows
            if selected_scope in {str(item).lower() for item in source.get("scopes", [])}
        ]
    if category:
        selected_category = category.strip().lower()
        rows = [
            source
            for source in rows
            if selected_category == str(source.get("category") or "").lower()
        ]
    return rows


def validate_source_registry(registry: SourceRegistry | None = None) -> dict[str, Any]:
    selected = registry or _default_registry()
    errors: list[str] = []
    seen: set[str] = set()
    for index, source in enumerate(selected.sources):
        source_id = str(source.get("id") or f"<index:{index}>")
        missing = sorted(REQUIRED_SOURCE_FIELDS - set(source))
        if missing:
            errors.append(f"{source_id}: missing fields: {', '.join(missing)}")
        if source_id in seen:
            errors.append(f"{source_id}: duplicate source id")
        seen.add(source_id)
        for list_field in ("supported_entity_types", "scopes", "tags", "examples"):
            if not isinstance(source.get(list_field), list):
                errors.append(f"{source_id}: {list_field} must be a list")
        for score_field in ("confidence_weight", "reliability_score", "freshness_weight"):
            try:
                score = float(source.get(score_field))
            except (TypeError, ValueError):
                errors.append(f"{source_id}: {score_field} must be numeric")
                continue
            if score < 0 or score > 1:
                errors.append(f"{source_id}: {score_field} must be between 0 and 1")
    if errors:
        raise SourceRegistryError("; ".join(errors))
    return {
        "path": str(selected.path),
        "version": selected.version,
        "sources": len(selected.sources),
        "required_fields": sorted(REQUIRED_SOURCE_FIELDS),
    }

