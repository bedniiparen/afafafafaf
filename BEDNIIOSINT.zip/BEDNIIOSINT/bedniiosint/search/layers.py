from __future__ import annotations

"""IntelOwl-style layered orchestration."""

from dataclasses import dataclass, field
from typing import Any, Callable, Protocol


class Stage(Protocol):
    name: str

    def run(self, context: "RunContext") -> Any: ...


@dataclass
class RunContext:
    entity: str
    entity_type: str = "username"
    options: dict[str, Any] = field(default_factory=dict)
    results: list[Any] = field(default_factory=list)
    links: list[Any] = field(default_factory=list)
    artifacts: dict[str, Any] = field(default_factory=dict)
    log: list[str] = field(default_factory=list)


@dataclass
class Analyzer:
    name: str
    fn: Callable[[RunContext], Any]

    def run(self, context: RunContext) -> Any:
        output = self.fn(context)
        if isinstance(output, list):
            context.results.extend(output)
        elif isinstance(output, dict) and isinstance(output.get("search_results"), list):
            context.results.extend(output["search_results"])
            context.artifacts.setdefault(f"{self.name}:payload", output)
        elif output is not None:
            context.results.append(output)
        context.log.append(f"analyzer:{self.name}")
        return output


@dataclass
class Connector:
    name: str
    fn: Callable[[RunContext], Any]

    def run(self, context: RunContext) -> Any:
        output = self.fn(context)
        if isinstance(output, list):
            context.links.extend(output)
        context.log.append(f"connector:{self.name}")
        return output


@dataclass
class Visualizer:
    name: str
    fn: Callable[[RunContext], Any]

    def run(self, context: RunContext) -> Any:
        artifact = self.fn(context)
        context.artifacts[self.name] = artifact
        context.log.append(f"visualizer:{self.name}")
        return artifact


@dataclass
class Playbook:
    name: str
    analyzers: list[str] = field(default_factory=list)
    connectors: list[str] = field(default_factory=list)
    visualizers: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Playbook":
        return cls(
            name=str(data.get("name") or "playbook"),
            analyzers=list(data.get("analyzers") or []),
            connectors=list(data.get("connectors") or []),
            visualizers=list(data.get("visualizers") or []),
        )


class Registry:
    def __init__(self) -> None:
        self.analyzers: dict[str, Analyzer] = {}
        self.connectors: dict[str, Connector] = {}
        self.visualizers: dict[str, Visualizer] = {}
        self.playbooks: dict[str, Playbook] = {}

    def analyzer(self, name: str) -> Callable[[Callable], Callable]:
        def deco(fn: Callable) -> Callable:
            self.analyzers[name] = Analyzer(name, fn)
            return fn

        return deco

    def connector(self, name: str) -> Callable[[Callable], Callable]:
        def deco(fn: Callable) -> Callable:
            self.connectors[name] = Connector(name, fn)
            return fn

        return deco

    def visualizer(self, name: str) -> Callable[[Callable], Callable]:
        def deco(fn: Callable) -> Callable:
            self.visualizers[name] = Visualizer(name, fn)
            return fn

        return deco

    def register_playbook(self, playbook: Playbook | dict[str, Any]) -> None:
        selected = Playbook.from_dict(playbook) if isinstance(playbook, dict) else playbook
        self.playbooks[selected.name] = selected

    def run_playbook(
        self,
        name: str,
        entity: str,
        *,
        entity_type: str = "username",
        options: dict[str, Any] | None = None,
        strict: bool = False,
    ) -> RunContext:
        playbook = self.playbooks.get(name)
        if playbook is None:
            raise KeyError(f"unknown playbook: {name}")
        context = RunContext(entity=entity, entity_type=entity_type, options=options or {})
        for group, store in (
            (playbook.analyzers, self.analyzers),
            (playbook.connectors, self.connectors),
            (playbook.visualizers, self.visualizers),
        ):
            for stage_name in group:
                stage = store.get(stage_name)
                if stage is None:
                    if strict:
                        raise KeyError(f"unknown stage: {stage_name}")
                    context.log.append(f"skip:{stage_name}")
                    continue
                try:
                    stage.run(context)
                except Exception as exc:
                    if strict:
                        raise
                    context.log.append(f"error:{stage_name}:{type(exc).__name__}")
        return context


def build_default_registry() -> Registry:
    registry = Registry()

    @registry.analyzer("search_pipeline")
    def _search(context: RunContext) -> Any:
        from .pipeline import run_planned_search_pipeline

        return run_planned_search_pipeline(
            context.entity,
            entity_type=context.entity_type,
            **dict(context.options.get("pipeline") or {}),
        )

    @registry.connector("correlate")
    def _correlate(context: RunContext) -> list[Any]:
        from .avatar_hash import avatar_correlations
        from .correlation import build_correlations
        from .correlation_rules import apply_rules, load_rules

        rows = [row.as_dict() if hasattr(row, "as_dict") else row for row in context.results]
        return [*build_correlations(rows), *avatar_correlations(rows), *apply_rules(rows, load_rules())]

    @registry.visualizer("graphml")
    def _graphml(context: RunContext) -> str:
        from .graphml_export import to_graphml

        return to_graphml(context.results, context.links, seed=context.entity, seed_type=context.entity_type)

    @registry.visualizer("html")
    def _html(context: RunContext) -> str:
        from .html_report import render_html

        return render_html(
            context.results,
            context.links,
            case_name=context.options.get("case_name") or "OSINT investigation",
            seed=context.entity,
            seed_type=context.entity_type,
        )

    registry.register_playbook(
        {
            "name": "username_full",
            "analyzers": ["search_pipeline"],
            "connectors": ["correlate"],
            "visualizers": ["graphml", "html"],
        }
    )
    return registry
