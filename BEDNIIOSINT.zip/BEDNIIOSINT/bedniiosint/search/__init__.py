"""Unified search planning and normalized search result layer."""

