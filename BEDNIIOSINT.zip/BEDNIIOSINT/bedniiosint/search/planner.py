from __future__ import annotations

from dataclasses import asdict, dataclass, field
import ipaddress
import re
from typing import Any
from urllib.parse import urlparse

from ..core.target import detect_module
from ..core.text_variants import (
    ascii_slug,
    is_probable_cyrillic_person_name,
    transliterate_cyrillic,
)
from .connectors.base import QueryPlan
from .query_expansion import ExpandedQuery, expand_search_queries
from .query_expansion_intl import expand_variants as expand_intl_variants
from .query_parser import ParsedSearchQuery, parse_search_query
from .scope_resolver import ResolvedScope, resolve_scope
from .source_registry import filter_sources, get_source, list_sources


@dataclass
class EntityVariant:
    value: str
    kind: str
    entity_type: str
    confidence: float = 1.0
    notes: str = ""

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class SearchPlan:
    entity_input: str
    entity_type: str
    scope: str
    sources: list[dict[str, Any]]
    queries: list[QueryPlan] = field(default_factory=list)
    variant_details: list[EntityVariant] = field(default_factory=list)
    planner_version: str = "3.0"
    warnings: list[str] = field(default_factory=list)
    fallback_sources: list[str] = field(default_factory=list)
    parsed_query: dict[str, Any] = field(default_factory=dict)
    resolved_scope: dict[str, Any] = field(default_factory=dict)
    source_routing: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "entity_input": self.entity_input,
            "entity_type": self.entity_type,
            "scope": self.scope,
            "sources": self.sources,
            "queries": [query.as_dict() for query in self.queries],
            "variant_details": [variant.as_dict() for variant in self.variant_details],
            "planner_version": self.planner_version,
            "warnings": self.warnings,
            "fallback_sources": self.fallback_sources,
            "parsed_query": self.parsed_query,
            "resolved_scope": self.resolved_scope,
            "source_routing": self.source_routing,
        }


COMPANY_SUFFIX_RE = re.compile(
    r"\b("
    r"incorporated|inc|llc|ltd|limited|corp|corporation|company|co|gmbh|sa|sas|sarl|plc|"
    r"ооо|оао|пао|зао|ао|ип|нко|фгуп|муп|тоо|тов|одоо|общество|компания"
    r")\b\.?",
    re.I,
)
USERNAME_SPLIT_RE = re.compile(r"[._\-\s]+")


def _domain_from_url(value: str) -> str:
    parsed = urlparse(value if "://" in value else f"https://{value}")
    host = parsed.netloc or parsed.path
    return host.split("@")[-1].split(":")[0].strip().lower()


def _path_username_from_url(value: str) -> str:
    parsed = urlparse(value if "://" in value else f"https://{value}")
    parts = [part for part in parsed.path.split("/") if part]
    if not parts:
        return ""
    candidate = parts[-1].strip().strip("@")
    if candidate and re.fullmatch(r"[A-Za-z0-9_.-]{2,64}", candidate):
        return candidate
    return ""


def _root_domain_variant(domain: str) -> str:
    labels = [label for label in domain.split(".") if label]
    if len(labels) <= 2:
        return domain
    if labels[0] == "www":
        return ".".join(labels[1:])
    return ".".join(labels[-2:])


def _append_variant(
    variants: list[EntityVariant],
    value: str,
    kind: str,
    entity_type: str,
    confidence: float,
    notes: str = "",
) -> None:
    clean = str(value or "").strip()
    if clean:
        variants.append(EntityVariant(clean, kind, entity_type, confidence, notes))


def _append_joined_username_forms(
    variants: list[EntityVariant],
    parts: list[str],
    kind_prefix: str,
    confidence: float,
) -> None:
    clean_parts = [part.strip().lower() for part in parts if part and part.strip()]
    if len(clean_parts) <= 1:
        return
    _append_variant(variants, "_".join(clean_parts), f"{kind_prefix}_underscore", "username", confidence)
    _append_variant(variants, "-".join(clean_parts), f"{kind_prefix}_hyphen", "username", confidence)
    _append_variant(variants, ".".join(clean_parts), f"{kind_prefix}_dot", "username", confidence)
    _append_variant(
        variants,
        "".join(clean_parts),
        f"{kind_prefix}_collapsed",
        "username",
        max(0.1, confidence - 0.04),
    )


def _ascii_username_parts(parts: list[str]) -> list[str]:
    return [slug for slug in (ascii_slug(part, separator="") for part in parts) if slug]


def _username_alias_variants(value: str) -> list[EntityVariant]:
    clean = value.strip().lstrip("@")
    lowered = clean.lower()
    parts = [part for part in USERNAME_SPLIT_RE.split(clean) if part]
    variants: list[EntityVariant] = []
    _append_variant(variants, clean, "username_without_at", "username", 0.96)
    _append_variant(variants, lowered, "username_lowercase", "username", 0.94)

    transliterated = transliterate_cyrillic(clean).strip().lower()
    if transliterated and transliterated != lowered:
        _append_variant(variants, transliterated, "username_transliterated", "username", 0.82)
        translit_parts = _ascii_username_parts(parts)
        _append_joined_username_forms(variants, translit_parts, "username_translit", 0.78)
        if len(translit_parts) == 2:
            _append_joined_username_forms(
                variants,
                [translit_parts[1], translit_parts[0]],
                "username_translit_reversed",
                0.7,
            )

    if len(parts) > 1:
        _append_joined_username_forms(variants, parts, "username", 0.72)
        if len(parts) == 2:
            _append_joined_username_forms(variants, [parts[1], parts[0]], "username_reversed", 0.66)
    return variants


def _company_variants(value: str) -> list[EntityVariant]:
    normalized = COMPANY_SUFFIX_RE.sub("", value).strip(" ,.-").strip()
    slug = ascii_slug(normalized, separator="")
    domain_guess = f"{slug}.com" if len(slug) >= 3 else ""
    variants: list[EntityVariant] = []
    _append_variant(variants, normalized, "company_without_suffix", "company", 0.82)
    _append_variant(variants, slug, "company_slug", "query", 0.58)
    _append_variant(variants, domain_guess, "company_domain_guess", "domain", 0.48)
    if is_probable_cyrillic_person_name(value):
        variants.extend(_username_alias_variants(value))
    return variants


def _phone_variants(value: str) -> list[EntityVariant]:
    digits = re.sub(r"\D+", "", value)
    variants: list[EntityVariant] = []
    _append_variant(variants, digits, "phone_digits", "phone", 0.82)
    if digits:
        _append_variant(variants, f"+{digits}", "phone_e164_like", "phone", 0.78)
    return variants


def _ip_warnings(value: str) -> list[str]:
    try:
        ip = ipaddress.ip_address(value.strip())
    except ValueError:
        return []
    warnings: list[str] = []
    if not ip.is_global:
        warnings.append("non_global_ip_external_sources_limited")
    if ip.is_private:
        warnings.append("private_ip_no_public_osint_lookup")
    if ip.is_loopback:
        warnings.append("loopback_ip_no_public_osint_lookup")
    if ip.is_link_local:
        warnings.append("link_local_ip_no_public_osint_lookup")
    return list(dict.fromkeys(warnings))


def build_entity_variant_details(entity_input: str, entity_type: str | None = None) -> list[EntityVariant]:
    value = str(entity_input or "").strip()
    selected_type = (entity_type or detect_module(value)).strip().lower()
    variants: list[EntityVariant] = [
        EntityVariant(value=value, kind="canonical", entity_type=selected_type, confidence=1.0)
    ]
    lowered = value.lower()
    if lowered and lowered != value:
        variants.append(
            EntityVariant(
                value=lowered,
                kind="lowercase",
                entity_type=selected_type,
                confidence=0.95,
                notes="case-normalized variant",
            )
        )
    if selected_type == "email" and "@" in value:
        local, domain = value.rsplit("@", 1)
        variants.extend(
            [
                EntityVariant(local, "email_localpart", "username", 0.7),
                EntityVariant(local.lower(), "email_localpart_lowercase", "username", 0.68),
                EntityVariant(domain.lower(), "email_domain", "domain", 0.8),
                EntityVariant(value.lower(), "email_lowercase", "email", 0.96),
            ]
        )
        variants.extend(_username_alias_variants(local))
    elif selected_type == "url":
        domain = _domain_from_url(value)
        if domain:
            variants.append(EntityVariant(domain, "url_domain", "domain", 0.85))
            root = _root_domain_variant(domain)
            if root and root != domain:
                variants.append(EntityVariant(root, "url_root_domain", "domain", 0.72))
        username = _path_username_from_url(value)
        if username:
            variants.append(EntityVariant(username, "url_profile_username", "username", 0.74))
            variants.extend(_username_alias_variants(username))
    elif selected_type == "domain":
        domain = _domain_from_url(value)
        if domain and domain != value:
            variants.append(EntityVariant(domain, "domain_host", "domain", 0.9))
        root = _root_domain_variant(domain or value.lower())
        if root and root != value.lower() and root != domain:
            variants.append(EntityVariant(root, "domain_root", "domain", 0.76))
    elif selected_type == "username":
        variants.extend(_username_alias_variants(value))
    elif selected_type == "company":
        variants.extend(_company_variants(value))
    elif selected_type == "phone":
        variants.extend(_phone_variants(value))
    elif selected_type == "wallet" and lowered.startswith("0x"):
        variants.append(EntityVariant(lowered, "ethereum_lowercase", "wallet", 0.96))
    unique: dict[tuple[str, str, str], EntityVariant] = {}
    for variant in variants:
        if variant.value:
            unique[(variant.value, variant.kind, variant.entity_type)] = variant
    return list(unique.values())


def build_entity_variants(entity_input: str, entity_type: str | None = None) -> list[str]:
    return [variant.value for variant in build_entity_variant_details(entity_input, entity_type)]


def source_priority_score(source: dict[str, Any]) -> float:
    confidence = float(source.get("confidence_weight") or 0.0)
    reliability = float(source.get("reliability_score") or 0.0)
    freshness = float(source.get("freshness_weight") or 0.0)
    auth_penalty = 0.08 if source.get("auth_required") else 0.0
    return round(max(0.0, confidence * 0.45 + reliability * 0.4 + freshness * 0.15 - auth_penalty), 4)


SOURCE_MATCH_ALIASES: dict[str, set[str]] = {
    "web_search": {"google", "google_cse", "search"},
    "creator_video_search": {"youtube", "video", "creator"},
    "news_mentions": {"gdelt", "news"},
    "public_social_intel": {"open_measures", "social_monitoring"},
    "public_code_search": {"github_search", "code_search", "repo_search"},
    "archive_discovery": {"archive", "wayback", "commoncrawl", "common_crawl", "crawl"},
    "contact_discovery": {"hunter", "contacts", "contact", "email_finder", "email_discovery"},
    "fediverse_profiles": {"mastodon", "fediverse"},
    "media_reverse_search": {"tineye", "reverse_image", "reverse_search"},
    "passive_dns_enrichment": {"hackertarget", "passive_dns"},
    "ip_behavior_reputation": {"greynoise", "ip_reputation"},
    "osint_aggregator": {"osintly", "osintly_api"},
    "open_threat_feeds": {"alienvault", "otx", "urlhaus", "threatfox", "malwarebazaar"},
    "attack_surface": {"shodan", "censys", "securitytrails"},
    "technology_fingerprint": {"builtwith", "wappalyzer"},
    "business_knowledge_graph": {"wikidata", "companies_house", "peeringdb"},
    "email_reputation": {"emailrep", "hibp", "hunter"},
    "phone_lookup": {"numverify", "veriphone", "twilio"},
}


def _normalize_match_token(value: str) -> str:
    clean = str(value or "").strip().lower()
    if clean.startswith("api:"):
        clean = clean[4:]
    if clean.startswith("module:"):
        clean = clean[7:]
    return re.sub(r"[^a-z0-9_]+", "_", clean).strip("_")


def _source_match_tokens(source: dict[str, Any]) -> set[str]:
    source_id = str(source.get("id") or "")
    tokens = {
        _normalize_match_token(source_id),
        _normalize_match_token(str(source.get("name") or "")),
        _normalize_match_token(str(source.get("category") or "")),
    }
    for field_name in ("supported_entity_types", "scopes", "tags"):
        tokens.update(_normalize_match_token(str(item)) for item in source.get(field_name, []))
    tokens.update(SOURCE_MATCH_ALIASES.get(source_id, set()))
    return {token for token in tokens if token}


def _source_matches_term(source: dict[str, Any], term: str) -> bool:
    normalized = _normalize_match_token(term)
    if not normalized:
        return False
    tokens = _source_match_tokens(source)
    return normalized in tokens or any(normalized in token or token in normalized for token in tokens)


def _source_supports_selected(
    source: dict[str, Any],
    selected_type: str,
    variants: list[EntityVariant],
) -> bool:
    supported = {str(item).lower() for item in source.get("supported_entity_types", [])}
    if selected_type in supported:
        return True
    if "query" in supported:
        return True
    variant_types = {variant.entity_type for variant in variants}
    return bool(supported & variant_types)


def _sources_from_requested_ids(
    requested: list[str],
    *,
    selected_type: str,
    variants: list[EntityVariant],
    strict: bool,
) -> tuple[list[dict[str, Any]], list[str]]:
    known = {str(source.get("id") or ""): source for source in list_sources()}
    selected: dict[str, dict[str, Any]] = {}
    unknown: list[str] = []
    for item in requested:
        clean = str(item or "").strip()
        if not clean:
            continue
        if clean in known:
            selected[clean] = known[clean]
            continue
        normalized = _normalize_match_token(clean)
        matches = [
            source
            for source in known.values()
            if _source_matches_term(source, normalized)
            and (strict or _source_supports_selected(source, selected_type, variants))
        ]
        if matches:
            for source in matches:
                selected[str(source.get("id") or "")] = source
            continue
        if strict:
            selected[clean] = get_source(clean)
        else:
            unknown.append(clean)
    return list(selected.values()), unknown


def _recommended_sources(
    resolved_scope: ResolvedScope,
    selected_type: str,
    variants: list[EntityVariant],
) -> list[dict[str, Any]]:
    known = {str(source.get("id") or ""): source for source in list_sources()}
    rows: list[dict[str, Any]] = []
    for source_id in resolved_scope.source_ids:
        source = known.get(source_id)
        if source and _source_supports_selected(source, selected_type, variants):
            rows.append(source)
    return rows


def _source_query_score(
    source: dict[str, Any],
    parsed_query: ParsedSearchQuery,
    resolved_scope: ResolvedScope,
) -> float:
    score = source_priority_score(source)
    if str(source.get("id") or "") in resolved_scope.source_ids:
        score += 0.04
    for term in parsed_query.boost_terms:
        if _source_matches_term(source, term):
            score += 0.08
    return round(min(1.0, max(0.0, score)), 4)


def _scope_argument(scope: str | None, parsed_query: ParsedSearchQuery) -> str | None:
    clean_scope = str(scope or "").strip()
    if parsed_query.scope_path and clean_scope in {"", "public_osint"}:
        return parsed_query.scope_path
    return clean_scope or parsed_query.scope_path or None


def _query_expansions_for_source(
    source: dict[str, Any],
    expansion: ExpandedQuery,
) -> list[str]:
    source_id = str(source.get("id") or "")
    rows = list(expansion.source_queries.get(source_id, []))
    supported = {str(item).lower() for item in source.get("supported_entity_types", [])}
    query_like = "query" in supported or str(source.get("category") or "") in {
        "search",
        "news",
        "media",
        "social_profiles",
    }
    if query_like:
        rows.extend(expansion.queries)
    return list(dict.fromkeys(row for row in rows if row))


def _source_query_variants(
    source: dict[str, Any],
    variants: list[EntityVariant],
    primary_type: str,
    expansion: ExpandedQuery | None = None,
) -> list[str]:
    supported = {str(item).lower() for item in source.get("supported_entity_types", [])}
    selected = [variant.value for variant in variants if variant.entity_type in supported]
    if not selected:
        selected = [variant.value for variant in variants if variant.entity_type == primary_type]
    if expansion is not None:
        selected.extend(_query_expansions_for_source(source, expansion))
    return list(dict.fromkeys(selected))


def plan_search(
    entity_input: str,
    *,
    entity_type: str | None = None,
    scope: str | None = None,
    max_sources: int | None = None,
    include_auth_required: bool = False,
    source_ids: list[str] | None = None,
) -> SearchPlan:
    parsed_query = parse_search_query(entity_input)
    clean_entity = parsed_query.entity or str(entity_input or "").strip()
    preliminary_type = (entity_type or detect_module(clean_entity)).strip().lower()
    resolved_scope = resolve_scope(_scope_argument(scope, parsed_query), preliminary_type)
    selected_type = (entity_type or resolved_scope.entity_type_hint or preliminary_type).strip().lower()
    if selected_type != preliminary_type and entity_type is None:
        resolved_scope = resolve_scope(_scope_argument(scope, parsed_query), selected_type)
    selected_scope = resolved_scope.registry_scope or "public_osint"
    variants = build_entity_variant_details(clean_entity, selected_type)
    existing_variant_values = {variant.value.lower() for variant in variants}
    for value in expand_intl_variants(clean_entity, entity_type=selected_type, limit=40):
        lowered = value.lower()
        if lowered in existing_variant_values:
            continue
        existing_variant_values.add(lowered)
        variants.append(
            EntityVariant(
                value=value,
                kind="intl_expansion",
                entity_type=selected_type,
                confidence=0.74,
                notes="international transliteration/diacritic/separator variant",
            )
        )
    expansion = expand_search_queries(clean_entity, selected_type, parsed_query, resolved_scope)
    warnings = _ip_warnings(clean_entity) if selected_type == "ip" else []
    unknown_source_hints: list[str] = []
    excluded_source_ids: list[str] = []
    selection_mode = "entity_scope"
    if source_ids:
        sources, _ = _sources_from_requested_ids(
            source_ids,
            selected_type=selected_type,
            variants=variants,
            strict=True,
        )
        selection_mode = "explicit_sources"
    elif parsed_query.source_hints:
        sources, unknown_source_hints = _sources_from_requested_ids(
            parsed_query.source_hints,
            selected_type=selected_type,
            variants=variants,
            strict=False,
        )
        selection_mode = "source_hints"
    else:
        if "private_ip_no_public_osint_lookup" in warnings:
            sources = []
        else:
            direct = filter_sources(entity_type=selected_type, scope=selected_scope)
            variant_types = {variant.entity_type for variant in variants if variant.entity_type != selected_type}
            expanded = [
                source
                for variant_type in variant_types
                for source in filter_sources(entity_type=variant_type, scope=selected_scope)
            ]
            recommended = _recommended_sources(resolved_scope, selected_type, variants)
            by_id = {source["id"]: source for source in [*direct, *expanded, *recommended]}
            sources = list(by_id.values())
            if recommended:
                selection_mode = "scope_recommended"
    fallback_sources: list[str] = []
    if not sources and not source_ids and not warnings:
        fallback_candidates = filter_sources(entity_type="query", scope=selected_scope) or filter_sources(
            entity_type="url",
            scope=selected_scope,
        )
        for source in fallback_candidates:
            fallback_sources.append(str(source.get("id") or ""))
        sources = fallback_candidates
    if not include_auth_required:
        sources = [source for source in sources if not bool(source.get("auth_required"))]
    if parsed_query.exclude_terms:
        kept_sources: list[dict[str, Any]] = []
        for source in sources:
            if any(_source_matches_term(source, term) for term in parsed_query.exclude_terms):
                excluded_source_ids.append(str(source.get("id") or ""))
                continue
            kept_sources.append(source)
        sources = kept_sources
    if unknown_source_hints:
        warnings.extend(f"unknown_source_hint:{hint}" for hint in unknown_source_hints)
    if (
        resolved_scope.include_auth_required_suggested
        and not include_auth_required
        and any(bool(get_source(source_id).get("auth_required")) for source_id in resolved_scope.source_ids if source_id)
    ):
        warnings.append("scope_has_keyed_sources_consider_include_auth_required")
    sources.sort(key=lambda source: _source_query_score(source, parsed_query, resolved_scope), reverse=True)
    if max_sources:
        sources = sources[:max_sources]
    source_routing = {
        "selection_mode": selection_mode,
        "requested_scope": scope or "",
        "scope_path": parsed_query.scope_path,
        "registry_scope": selected_scope,
        "source_hints": parsed_query.source_hints,
        "unknown_source_hints": unknown_source_hints,
        "boost_terms": parsed_query.boost_terms,
        "exclude_terms": parsed_query.exclude_terms,
        "excluded_source_ids": excluded_source_ids,
        "recommended_source_ids": resolved_scope.source_ids,
    }
    queries: list[QueryPlan] = []
    for source in sources:
        source_variants = _source_query_variants(source, variants, selected_type, expansion)
        priority_score = _source_query_score(source, parsed_query, resolved_scope)
        queries.append(
            QueryPlan(
                source_id=str(source["id"]),
                source_name=str(source["name"]),
                entity_input=str(clean_entity),
                entity_type=selected_type,
                queries=source_variants,
                scope=selected_scope,
                variants=source_variants,
                metadata={
                    "source_priority_score": priority_score,
                    "base_priority_score": source_priority_score(source),
                    "source": source,
                    "planner_version": "3.0",
                    "warnings": warnings,
                    "fallback_source": str(source.get("id") or "") in fallback_sources,
                    "parsed_query": parsed_query.as_dict(),
                    "resolved_scope": resolved_scope.as_dict(),
                    "query_expansion": expansion.as_dict(),
                    "source_routing": source_routing,
                    "selected_variant_kinds": [
                        variant.kind for variant in variants if variant.value in source_variants
                    ],
                    "variant_details": [
                        variant.as_dict() for variant in variants if variant.value in source_variants
                    ],
                },
            )
        )
    return SearchPlan(
        entity_input=str(clean_entity),
        entity_type=selected_type,
        scope=selected_scope,
        sources=sources,
        queries=queries,
        variant_details=variants,
        planner_version="3.0",
        warnings=warnings,
        fallback_sources=fallback_sources,
        parsed_query=parsed_query.as_dict(),
        resolved_scope=resolved_scope.as_dict(),
        source_routing=source_routing,
    )


def searchable_entity_types() -> list[str]:
    types: set[str] = set()
    for source in list_sources():
        types.update(str(item) for item in source.get("supported_entity_types", []))
    return sorted(types)
