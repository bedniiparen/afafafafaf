from __future__ import annotations

import hashlib
from typing import Any

from .evidence import build_search_evidence
from .models import SearchResult


def _stable_id(*parts: Any) -> str:
    text = "|".join(str(part or "") for part in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]


def _snippet(record: dict[str, Any]) -> str:
    if record.get("reject_reason"):
        return str(record["reject_reason"])
    raw = record.get("raw")
    if isinstance(raw, dict):
        for key in ("text", "error"):
            value = str(raw.get(key) or "").strip()
            if value:
                return value[:300]
    return str(record.get("status") or "")


def search_result_from_normalized_record(
    record: dict[str, Any],
    *,
    source: dict[str, Any] | None = None,
    scope: str = "public_osint",
    matched_variant: str = "",
) -> SearchResult:
    source = source or {}
    source_id = str(record.get("source_id") or source.get("id") or "")
    target = str(record.get("target") or "")
    entity_type = str(record.get("input_type") or "")
    confidence = float(record.get("confidence") or 0.0)
    title = str(record.get("title") or source.get("name") or source_id)
    timeline = record.get("timeline") if isinstance(record.get("timeline"), list) else []
    evidence = build_search_evidence(record, source=source, scope=scope)
    return SearchResult(
        id=_stable_id(source_id, entity_type, target, record.get("url"), title),
        source_id=source_id,
        source_name=str(source.get("name") or source_id),
        entity_input=target,
        entity_type=entity_type,
        matched_entity=target,
        matched_variant=matched_variant or target,
        scope=scope,
        title=title,
        url=str(record.get("url") or ""),
        snippet=_snippet(record),
        raw_data=record.get("raw") or {},
        normalized_data=dict(record),
        detected_platform=source_id.split(":", 1)[-1],
        first_seen=str(timeline[0].get("description") or "") if timeline else None,
        last_seen=str(timeline[-1].get("description") or "") if timeline else None,
        tags=[str(source.get("category") or ""), *[str(item) for item in source.get("tags", [])]],
        evidence=evidence,
        confidence_score=round(confidence, 3),
        context_match_score=1.0 if target else 0.0,
        risk_flags=[] if confidence > 0 else ["rejected_or_unconfirmed"],
        legal_notes="; ".join(
            item
            for item in (
                str(source.get("legal_status") or ""),
                str(source.get("tos_notes") or ""),
            )
            if item
        ),
        explanation=f"Normalized catalog record from {source_id} converted to SearchResult.",
    )


def search_results_from_records(
    records: list[dict[str, Any]],
    *,
    source_by_catalog_id: dict[str, dict[str, Any]] | None = None,
    scope: str = "public_osint",
) -> list[SearchResult]:
    source_by_catalog_id = source_by_catalog_id or {}
    return [
        search_result_from_normalized_record(
            record,
            source=source_by_catalog_id.get(str(record.get("source_id") or ""), {}),
            scope=scope,
        )
        for record in records
    ]
