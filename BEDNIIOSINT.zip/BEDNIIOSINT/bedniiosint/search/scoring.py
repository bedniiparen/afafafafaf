from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from ..config import settings
from .canonicalize import dedupe_and_merge
from .calibration import IsotonicCalibrator, calibrate_results
from .models import SearchResult
from .presence import apply_presence_filter
from .ranking import rank_results


def _append_unique(items: list[str], value: str) -> None:
    if value and value not in items:
        items.append(value)


def _is_review_only(result: SearchResult) -> bool:
    return (
        "review_only" in result.tags
        or "review_only" in result.risk_flags
        or bool(result.normalized_data.get("review_only"))
    )


PRIORITY_PLATFORM_ALIASES = {
    "telegram": ("telegram", "t.me", "tg"),
    "vk": ("vk", "vkontakte", "vk.com"),
    "instagram": ("instagram", "instagr.am", " ig "),
    "youtube": ("youtube", "youtu.be"),
}
PRIORITY_ORDER = ("telegram", "vk", "instagram", "youtube")


def _priority_boost(result: SearchResult) -> float:
    hay = " ".join(
        [
            result.detected_platform or "",
            result.source_id or "",
            result.source_name or "",
            result.url or "",
        ]
    ).lower()
    for index, key in enumerate(PRIORITY_ORDER):
        if any(alias in hay for alias in PRIORITY_PLATFORM_ALIASES[key]):
            return round(0.05 - 0.01 * index, 3)
    return 0.0


def score_search_results(results: list[SearchResult]) -> list[SearchResult]:
    sources_by_entity: dict[tuple[str, str], set[str]] = defaultdict(set)
    for result in results:
        if _is_review_only(result):
            continue
        key = (result.entity_type, result.matched_entity or result.entity_input)
        if result.confidence_score > 0:
            sources_by_entity[key].add(result.source_id)

    for result in results:
        key = (result.entity_type, result.matched_entity or result.entity_input)
        review_only = _is_review_only(result)
        independent_sources = 0 if review_only else len(sources_by_entity.get(key, set()))
        base_confidence = float(result.confidence_score or 0.0)
        priority = 0.0 if review_only else _priority_boost(result)
        boost = (0.0 if review_only else min(0.2, 0.05 * max(0, independent_sources - 1))) + priority
        if priority > 0:
            _append_unique(result.tags, "priority_platform")
        context = 1.0 if (result.matched_entity or result.entity_input) else 0.0
        final = round(min(1.0, base_confidence + boost), 3)
        result.context_match_score = context
        result.confidence_score = final
        if review_only:
            _append_unique(result.risk_flags, "manual_verification_required")
        elif independent_sources > 1:
            _append_unique(result.tags, "corroborated")
        else:
            _append_unique(result.risk_flags, "single_source")
        if final < 0.5:
            _append_unique(result.risk_flags, "low_confidence")
        result.normalized_data.setdefault("search_scoring", {})
        result.normalized_data["search_scoring"] = {
            "base_confidence": round(base_confidence, 3),
            "final_confidence": final,
            "independent_sources": independent_sources,
            "context_match_score": context,
        }
        if review_only:
            result.explanation = "Review-only lead."
        elif independent_sources > 1:
            result.explanation = f"Corroborated by {independent_sources} sources."
        else:
            result.explanation = "Single source."
    return results


def _apply_optional_calibration(results: list[SearchResult]) -> None:
    configured = str(settings.search_calibration_model or "").strip()
    if not configured:
        return
    model_path = Path(configured)
    if not model_path.exists():
        return
    calibrate_results(
        results,
        IsotonicCalibrator.load(model_path),
        overwrite_confidence=settings.search_calibration_overwrite,
    )


def rank_and_score(
    query: str,
    results: list[SearchResult],
    *,
    apply_presence: bool = True,
) -> list[SearchResult]:
    if apply_presence and settings.presence_filter_enabled:
        results = apply_presence_filter(results, drop_absent=settings.presence_drop_absent)
    results = dedupe_and_merge(results)
    score_search_results(results)
    rank_results(query, results)
    _apply_optional_calibration(results)
    for result in results:
        relevance = float(result.normalized_data.get("relevance_score") or 0.0)
        confidence = float(result.confidence_score or 0.0)
        result.normalized_data["ranking_score"] = round(
            settings.rank_confidence_weight * confidence
            + settings.rank_relevance_weight * relevance,
            4,
        )
    results.sort(
        key=lambda result: float(result.normalized_data.get("ranking_score") or 0.0),
        reverse=True,
    )
    return results
