from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import re
from typing import Any
from urllib.parse import urlparse

from ..core.target import detect_module
from .models import SearchResult
from .planner import SearchPlan


PROFILE_HOSTS = {
    "bsky.app",
    "boosty.to",
    "facebook.com",
    "github.com",
    "gitlab.com",
    "instagram.com",
    "linkedin.com",
    "medium.com",
    "ok.ru",
    "pinterest.com",
    "reddit.com",
    "soundcloud.com",
    "t.me",
    "threads.net",
    "tiktok.com",
    "twitter.com",
    "vk.com",
    "x.com",
    "youtube.com",
}

MUSIC_HOSTS = {
    "bandcamp.com",
    "deezer.com",
    "genius.com",
    "last.fm",
    "music.apple.com",
    "music.yandex.ru",
    "musicbrainz.org",
    "open.spotify.com",
    "soundcloud.com",
    "youtube.com",
}

SOURCE_SUGGESTIONS: dict[str, list[str]] = {
    "username": ["social_profiles", "web_search"],
    "profile": ["social_profiles", "web_search"],
    "email": ["email_enrichment", "email_reputation", "web_search"],
    "domain": ["dns", "rdap", "crtsh", "archive_discovery", "contact_discovery", "web_search"],
    "url": ["urlscan", "archive_discovery", "web_search"],
    "phone": ["phone_lookup", "web_search"],
    "company": ["business_knowledge_graph", "contact_discovery", "news_mentions", "web_search"],
    "music": ["creator_video_search", "social_profiles", "public_social_intel", "web_search"],
}


@dataclass(frozen=True)
class ResultPivot:
    id: str
    pivot_type: str
    value: str
    source_result_id: str
    source_group: str
    priority: int
    confidence: float
    suggested_sources: list[str]
    suggested_scope: str
    suggested_query: str
    reason: str
    relation: str
    verification_status: str = "candidate"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _stable_id(*parts: Any) -> str:
    text = "|".join(str(part or "") for part in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:14]


def _host(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = (parsed.netloc or parsed.path).split("@")[-1].split(":")[0].lower()
    return host.removeprefix("www.")


def _path_parts(value: str) -> list[str]:
    parsed = urlparse(str(value or "") if "://" in str(value or "") else f"https://{value}")
    return [part for part in parsed.path.split("/") if part]


def _username_from_profile_url(value: str) -> str:
    host = _host(value)
    parts = _path_parts(value)
    if not host or not parts:
        return ""
    if host in {"youtube.com", "tiktok.com", "threads.net"} and parts[-1].startswith("@"):
        return parts[-1].strip("@")
    if host == "reddit.com" and len(parts) >= 2 and parts[-2].lower() in {"user", "u"}:
        return parts[-1]
    if host == "linkedin.com" and len(parts) >= 2 and parts[-2].lower() in {"in", "company"}:
        return parts[-1]
    if host == "genius.com" and len(parts) >= 2 and parts[-2].lower() == "artists":
        return parts[-1]
    if host == "bsky.app" and len(parts) >= 2 and parts[-2].lower() == "profile":
        return parts[-1].split(".", 1)[0]
    if len(parts) == 1:
        return parts[0].strip("@~")
    return ""


def _clean_domain(value: str) -> str:
    host = _host(value)
    if not host or "." not in host:
        return ""
    if host in {"github.com", "gitlab.com", "youtube.com", "instagram.com", "vk.com"}:
        return ""
    return host


def _clean_email(value: str) -> str:
    clean = str(value or "").strip().lower().strip(".,;:()[]{}<>")
    if re.fullmatch(r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}", clean):
        return clean
    return ""


def _clean_phone(value: str) -> str:
    text = str(value or "").strip()
    digits = re.sub(r"\D+", "", text)
    if len(digits) < 7:
        return ""
    return f"+{digits}" if text.startswith("+") else digits


def _result_group_by_id(result_groups: dict[str, dict[str, Any]]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for group_name, group in (result_groups or {}).items():
        for result_id in group.get("result_ids") or []:
            mapping[str(result_id)] = str(group_name)
    return mapping


def _append_pivot(
    pivots: list[ResultPivot],
    seen: set[tuple[str, str, str]],
    *,
    pivot_type: str,
    value: str,
    result: SearchResult,
    source_group: str,
    priority: int,
    confidence: float,
    reason: str,
    relation: str,
    suggested_scope: str = "",
    verification_status: str = "candidate",
) -> None:
    clean_value = str(value or "").strip()
    if not clean_value:
        return
    key = (pivot_type, clean_value.lower(), relation)
    if key in seen:
        return
    seen.add(key)
    suggested_sources = SOURCE_SUGGESTIONS.get(pivot_type, ["web_search"])
    scope = suggested_scope or {
        "domain": "/infra/domain",
        "url": "/archive",
        "email": "/identity/email",
        "phone": "/identity/phone",
        "username": "/identity/username",
        "profile": "/identity/username",
        "company": "/business",
        "music": "/music",
    }.get(pivot_type, "")
    pivots.append(
        ResultPivot(
            id="pivot:" + _stable_id(pivot_type, clean_value, result.id, relation),
            pivot_type=pivot_type,
            value=clean_value,
            source_result_id=result.id,
            source_group=source_group,
            priority=priority,
            confidence=round(float(confidence or 0.0), 3),
            suggested_sources=suggested_sources,
            suggested_scope=scope,
            suggested_query=f"{clean_value} {scope}".strip(),
            reason=reason,
            relation=relation,
            verification_status=verification_status,
        )
    )


def _values_from_result(result: SearchResult) -> list[str]:
    values: list[str] = []
    for value in (result.matched_entity, result.matched_variant, result.url, result.title):
        clean = str(value or "").strip()
        if clean and clean not in values:
            values.append(clean)
    normalized = result.normalized_data if isinstance(result.normalized_data, dict) else {}
    for field in ("url", "profile_url", "email", "domain", "phone", "entity_value", "pivot_value"):
        clean = str(normalized.get(field) or "").strip()
        if clean and clean not in values:
            values.append(clean)
    for entity in normalized.get("entities") or []:
        if not isinstance(entity, dict):
            continue
        clean = str(entity.get("value") or "").strip()
        if clean and clean not in values:
            values.append(clean)
    return values


def _pivot_confidence(result: SearchResult, base: float) -> float:
    score = float(result.confidence_score or 0.0)
    if score > 0:
        return min(1.0, max(base, score))
    normalized = result.normalized_data if isinstance(result.normalized_data, dict) else {}
    if normalized.get("direct_candidate"):
        return max(0.25, base)
    return base


def build_result_pivots(
    plan: SearchPlan,
    results: list[SearchResult],
    result_groups: dict[str, dict[str, Any]] | None = None,
    *,
    limit: int = 160,
) -> dict[str, Any]:
    group_by_id = _result_group_by_id(result_groups or {})
    pivots: list[ResultPivot] = []
    seen: set[tuple[str, str, str]] = set()

    for result in results:
        source_group = group_by_id.get(result.id, "other")
        normalized = result.normalized_data if isinstance(result.normalized_data, dict) else {}
        lead_kind = str(normalized.get("lead_kind") or "")
        verification_status = str(normalized.get("verification_status") or "")

        if result.url:
            host = _host(result.url)
            username = _username_from_profile_url(result.url)
            if username and host in PROFILE_HOSTS:
                pivot_type = "music" if host in MUSIC_HOSTS or source_group == "music_platforms" else "username"
                _append_pivot(
                    pivots,
                    seen,
                    pivot_type=pivot_type,
                    value=username,
                    result=result,
                    source_group=source_group,
                    priority=95 if pivot_type == "music" else 88,
                    confidence=_pivot_confidence(result, 0.28),
                    reason="Profile URL exposes a reusable username/artist handle.",
                    relation="profile_url_to_username",
                    suggested_scope="/music" if pivot_type == "music" else "/identity/username",
                    verification_status=verification_status or "candidate",
                )
            domain = _clean_domain(result.url)
            if domain:
                _append_pivot(
                    pivots,
                    seen,
                    pivot_type="domain",
                    value=domain,
                    result=result,
                    source_group=source_group,
                    priority=72 if source_group != "review_search" else 48,
                    confidence=_pivot_confidence(result, 0.22),
                    reason="URL host can be pivoted into DNS, RDAP, CT and archive coverage.",
                    relation="url_to_domain",
                    suggested_scope="/infra/domain",
                    verification_status=verification_status or "candidate",
                )

        for value in _values_from_result(result):
            email = _clean_email(value)
            if email:
                _append_pivot(
                    pivots,
                    seen,
                    pivot_type="email",
                    value=email,
                    result=result,
                    source_group=source_group,
                    priority=82,
                    confidence=_pivot_confidence(result, 0.38),
                    reason="Email can fan out to enrichment, reputation and localpart username checks.",
                    relation="result_to_email",
                    suggested_scope="/identity/email",
                    verification_status=verification_status or "candidate",
                )
                local, domain = email.rsplit("@", 1)
                _append_pivot(
                    pivots,
                    seen,
                    pivot_type="username",
                    value=local,
                    result=result,
                    source_group=source_group,
                    priority=62,
                    confidence=_pivot_confidence(result, 0.2),
                    reason="Email localpart is a weak username pivot.",
                    relation="email_to_localpart",
                    suggested_scope="/identity/username",
                    verification_status="weak_candidate",
                )
                _append_pivot(
                    pivots,
                    seen,
                    pivot_type="domain",
                    value=domain,
                    result=result,
                    source_group=source_group,
                    priority=78,
                    confidence=_pivot_confidence(result, 0.32),
                    reason="Email domain can be pivoted into organization and infrastructure coverage.",
                    relation="email_to_domain",
                    suggested_scope="/infra/domain",
                    verification_status=verification_status or "candidate",
                )

            phone = _clean_phone(value)
            if phone:
                _append_pivot(
                    pivots,
                    seen,
                    pivot_type="phone",
                    value=phone,
                    result=result,
                    source_group=source_group,
                    priority=58,
                    confidence=_pivot_confidence(result, 0.24),
                    reason="Phone-like value can be checked in phone enrichment and public mentions.",
                    relation="result_to_phone",
                    suggested_scope="/identity/phone",
                    verification_status=verification_status or "candidate",
                )

            if detect_module(value) == "domain":
                domain = _clean_domain(value)
                if domain:
                    _append_pivot(
                        pivots,
                        seen,
                        pivot_type="domain",
                        value=domain,
                        result=result,
                        source_group=source_group,
                        priority=70,
                        confidence=_pivot_confidence(result, 0.3),
                        reason="Domain-like value can fan out to infrastructure and contact sources.",
                        relation="result_to_domain",
                        suggested_scope="/infra/domain",
                        verification_status=verification_status or "candidate",
                    )

        if lead_kind == "direct_profile_candidate" and result.url:
            _append_pivot(
                pivots,
                seen,
                pivot_type="profile",
                value=result.url,
                result=result,
                source_group=source_group,
                priority=92,
                confidence=0.24,
                reason="Direct candidate should be verified before attribution.",
                relation="candidate_profile_to_verification",
                suggested_scope="/identity/username",
                verification_status=verification_status or "unverified_candidate",
            )

    pivots.sort(key=lambda row: (-row.priority, -row.confidence, row.pivot_type, row.value))
    selected = pivots[: max(0, int(limit))]
    counts_by_type: dict[str, int] = {}
    counts_by_group: dict[str, int] = {}
    for pivot in selected:
        counts_by_type[pivot.pivot_type] = counts_by_type.get(pivot.pivot_type, 0) + 1
        counts_by_group[pivot.source_group] = counts_by_group.get(pivot.source_group, 0) + 1
    return {
        "style": "spiderfoot_result_pivots",
        "items": [pivot.as_dict() for pivot in selected],
        "counts": {
            "total": len(selected),
            "available": len(pivots),
            "by_type": dict(sorted(counts_by_type.items())),
            "by_source_group": dict(sorted(counts_by_group.items())),
        },
        "next_actions": _next_actions(plan, selected),
    }


def _next_actions(plan: SearchPlan, pivots: list[ResultPivot]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for pivot in pivots[:12]:
        source_arg = ",".join(pivot.suggested_sources)
        rows.append(
            {
                "pivot_id": pivot.id,
                "label": f"{pivot.pivot_type}: {pivot.value}",
                "priority": pivot.priority,
                "query": pivot.suggested_query,
                "source_ids": pivot.suggested_sources,
                "command": (
                    "bedniiosint search-run "
                    f"{pivot.value} --source {source_arg} --include-dorking"
                ),
                "why": pivot.reason,
            }
        )
    if not rows and plan.entity_input:
        rows.append(
            {
                "pivot_id": "",
                "label": f"review: {plan.entity_input}",
                "priority": 10,
                "query": plan.entity_input,
                "source_ids": ["web_search"],
                "command": f"bedniiosint search-run {plan.entity_input} --include-dorking",
                "why": "No high-value pivots were extracted; broaden review search only if needed.",
            }
        )
    return rows
