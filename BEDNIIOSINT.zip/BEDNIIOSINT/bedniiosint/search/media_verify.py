from __future__ import annotations

import io
from dataclasses import dataclass


@dataclass
class ImageSignature:
    phash: str
    width: int
    height: int
    exif: dict


def _deps():
    try:
        import imagehash  # type: ignore
        from PIL import Image  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("Pillow and imagehash are required for media verification") from exc
    return imagehash, Image


def signature_from_bytes(data: bytes) -> ImageSignature:
    imagehash, Image = _deps()
    img = Image.open(io.BytesIO(data))
    exif = {}
    try:
        raw = img._getexif() or {}
        exif = {str(k): str(v) for k, v in raw.items()}
    except Exception:
        pass
    return ImageSignature(
        phash=str(imagehash.phash(img)),
        width=img.width,
        height=img.height,
        exif=exif,
    )


def similar(a: str, b: str, *, max_distance: int = 8) -> bool:
    imagehash, _Image = _deps()
    return (imagehash.hex_to_hash(a) - imagehash.hex_to_hash(b)) <= max_distance
