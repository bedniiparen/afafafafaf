from __future__ import annotations

import hashlib
import re
from collections import defaultdict
from typing import Any
from urllib.parse import urlparse

from .models import SearchResult


def _stable_id(*parts: Any) -> str:
    text = "|".join(str(part or "") for part in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]


def _clean_value(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def _normalize_url(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = (parsed.netloc or parsed.path).split("@")[-1].split(":")[0].lower()
    path = parsed.path.rstrip("/")
    return f"{host}{path}".strip("/")


def _normalize_entity(entity_type: str, value: str) -> str:
    kind = str(entity_type or "").strip().lower()
    clean = _clean_value(value)
    if kind in {"domain", "url", "profile_url"}:
        return _normalize_url(clean)
    if kind == "email":
        return clean
    if kind == "phone":
        digits = re.sub(r"\D+", "", clean)
        return f"+{digits}" if digits else clean
    if kind == "wallet" and clean.startswith("0x"):
        return clean.lower()
    return clean


def result_dedup_key(result: SearchResult) -> str:
    entity_type = result.entity_type or "unknown"
    entity_value = result.matched_entity or result.entity_input or result.url
    normalized = _normalize_entity(entity_type, entity_value)
    url_key = _normalize_url(result.url)
    return "|".join(
        [
            str(entity_type).lower(),
            normalized,
            str(result.source_id or "").lower(),
            url_key,
        ]
    )


def entity_resolution_key(result: SearchResult) -> str:
    entity_type = result.entity_type or "unknown"
    entity_value = result.matched_entity or result.entity_input or result.url
    return "|".join([str(entity_type).lower(), _normalize_entity(entity_type, entity_value)])


def _confidence_band(score: float) -> str:
    if score >= 0.75:
        return "confirmed"
    if score >= 0.5:
        return "possible"
    if score > 0:
        return "weak"
    return "unconfirmed"


def _cluster_status(source_count: int, max_confidence: float, evidence_count: int) -> str:
    if source_count >= 2 and max_confidence >= 0.7:
        return "confirmed"
    if max_confidence >= 0.5 or (evidence_count >= 2 and max_confidence > 0):
        return "possible"
    if max_confidence > 0:
        return "weak"
    return "unconfirmed"


def cluster_search_results(results: list[SearchResult]) -> list[dict[str, Any]]:
    groups: dict[str, list[SearchResult]] = defaultdict(list)
    for result in results:
        groups[entity_resolution_key(result)].append(result)

    clusters: list[dict[str, Any]] = []
    for key, rows in groups.items():
        entity_type, normalized_value = key.split("|", 1)
        sources = sorted({row.source_id for row in rows if row.source_id})
        result_ids = sorted({row.id for row in rows if row.id})
        evidence_count = sum(len(row.evidence) for row in rows)
        max_confidence = round(max((float(row.confidence_score or 0.0) for row in rows), default=0.0), 3)
        status = _cluster_status(len(sources), max_confidence, evidence_count)
        clusters.append(
            {
                "cluster_id": "cluster-" + _stable_id(entity_type, normalized_value),
                "entity_type": entity_type,
                "entity_value": normalized_value,
                "result_count": len(rows),
                "result_ids": result_ids,
                "source_ids": sources,
                "source_count": len(sources),
                "evidence_count": evidence_count,
                "max_confidence": max_confidence,
                "confidence_band": _confidence_band(max_confidence),
                "status": status,
                "dedup_keys": sorted({result_dedup_key(row) for row in rows}),
                "explanation": (
                    f"{status}: {len(rows)} result(s), {len(sources)} source(s), "
                    f"{evidence_count} evidence item(s)."
                ),
            }
        )
    clusters.sort(
        key=lambda row: (
            {"confirmed": 0, "possible": 1, "weak": 2, "unconfirmed": 3}.get(str(row["status"]), 9),
            -float(row["max_confidence"]),
            -int(row["source_count"]),
            str(row["entity_type"]),
            str(row["entity_value"]),
        )
    )
    return clusters


def annotate_result_clusters(results: list[SearchResult]) -> list[SearchResult]:
    clusters = cluster_search_results(results)
    by_result_id = {
        result_id: cluster
        for cluster in clusters
        for result_id in cluster.get("result_ids", [])
    }
    for result in results:
        cluster = by_result_id.get(result.id)
        result.normalized_data.setdefault("search_dedup", {})
        result.normalized_data["search_dedup"] = {
            "dedup_key": result_dedup_key(result),
            "entity_resolution_key": entity_resolution_key(result),
            "cluster_id": str(cluster.get("cluster_id") or "") if cluster else "",
            "cluster_status": str(cluster.get("status") or "") if cluster else "",
        }
        if cluster and str(cluster.get("status")) not in result.tags:
            result.tags.append(str(cluster["status"]))
    return results
