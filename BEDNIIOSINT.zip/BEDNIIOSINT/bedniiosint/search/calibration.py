from __future__ import annotations

"""Dependency-free isotonic confidence calibration."""

import json
from pathlib import Path
from typing import Any, Sequence

from .models import SearchResult


def _pav(scores: list[float], labels: list[float], weights: list[float]) -> list[float]:
    blocks: list[list[float]] = []
    for idx, label in enumerate(labels):
        blocks.append([label, weights[idx], 1.0])
        while len(blocks) > 1 and blocks[-2][0] >= blocks[-1][0]:
            v2, w2, l2 = blocks.pop()
            v1, w1, l1 = blocks.pop()
            total_weight = w1 + w2
            merged = (v1 * w1 + v2 * w2) / total_weight if total_weight else 0.0
            blocks.append([merged, total_weight, l1 + l2])
    out: list[float] = []
    for value, _weight, length in blocks:
        out.extend([value] * int(length))
    return out


class IsotonicCalibrator:
    def __init__(
        self,
        thresholds: list[float] | None = None,
        calibrated: list[float] | None = None,
    ) -> None:
        self.thresholds = thresholds or []
        self.calibrated = calibrated or []

    @property
    def fitted(self) -> bool:
        return len(self.thresholds) >= 1

    def fit(self, scores: Sequence[float], labels: Sequence[int | float]) -> "IsotonicCalibrator":
        pairs = sorted(
            zip([float(score) for score in scores], [float(label) for label in labels]),
            key=lambda pair: pair[0],
        )
        if not pairs:
            return self
        xs = [pair[0] for pair in pairs]
        ys = [pair[1] for pair in pairs]
        fitted = _pav(xs, ys, [1.0] * len(xs))
        thresholds: list[float] = []
        calibrated: list[float] = []
        for x_value, y_value in zip(xs, fitted):
            if thresholds and abs(thresholds[-1] - x_value) < 1e-12:
                calibrated[-1] = y_value
            else:
                thresholds.append(x_value)
                calibrated.append(y_value)
        self.thresholds = thresholds
        self.calibrated = calibrated
        return self

    def predict(self, score: float) -> float:
        if not self.fitted:
            return float(score)
        score = float(score)
        xs = self.thresholds
        ys = self.calibrated
        if score <= xs[0]:
            return round(ys[0], 4)
        if score >= xs[-1]:
            return round(ys[-1], 4)
        lo = 0
        hi = len(xs) - 1
        while lo + 1 < hi:
            mid = (lo + hi) // 2
            if xs[mid] <= score:
                lo = mid
            else:
                hi = mid
        x0, x1 = xs[lo], xs[hi]
        y0, y1 = ys[lo], ys[hi]
        if x1 == x0:
            return round(y1, 4)
        ratio = (score - x0) / (x1 - x0)
        return round(y0 + ratio * (y1 - y0), 4)

    def to_dict(self) -> dict[str, Any]:
        return {"thresholds": self.thresholds, "calibrated": self.calibrated}

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "IsotonicCalibrator":
        return cls(list(payload.get("thresholds") or []), list(payload.get("calibrated") or []))

    def save(self, path: str | Path) -> Path:
        out = Path(path)
        out.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        return out

    @classmethod
    def load(cls, path: str | Path) -> "IsotonicCalibrator":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))


def calibrate_results(
    results: list[SearchResult],
    calibrator: IsotonicCalibrator,
    *,
    overwrite_confidence: bool = False,
) -> list[SearchResult]:
    if not calibrator.fitted:
        return results
    for result in results:
        raw = float(result.confidence_score or 0.0)
        calibrated = calibrator.predict(raw)
        if isinstance(result.normalized_data, dict):
            result.normalized_data["calibrated_confidence"] = calibrated
            result.normalized_data["raw_confidence"] = round(raw, 4)
        if overwrite_confidence:
            result.confidence_score = calibrated
    return results
