from __future__ import annotations

import asyncio
import hashlib
from typing import Any

from ..core.source_context import SourceRunContext
from ..modules.username.scanner import SiteResult, load_sites, scan_username
from .models import SearchResult
from .planner import SearchPlan


def _stable_id(*parts: Any) -> str:
    text = "|".join(str(part or "") for part in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]


def _scope_categories(plan: SearchPlan) -> list[str] | None:
    resolved = getattr(plan, "resolved_scope", {}) or {}
    path = str(resolved.get("path") if isinstance(resolved, dict) else "").lower()
    if "music" in path:
        return ["music", "social", "video"]
    return None


def _scan_limit(plan: SearchPlan) -> int:
    parsed = getattr(plan, "parsed_query", {}) or {}
    filters = parsed.get("filters") if isinstance(parsed, dict) else {}
    if not isinstance(filters, dict):
        filters = {}
    raw = filters.get("scan_limit") or filters.get("verify_limit") or filters.get("limit")
    try:
        limit = int(str(raw).strip())
    except (TypeError, ValueError):
        limit = 80
    return max(5, min(500, limit))


def _sherlock_status(status: str) -> str:
    mapping = {
        "exists": "CLAIMED",
        "not_exists": "AVAILABLE",
        "unknown": "UNKNOWN",
        "illegal": "ILLEGAL",
        "waf": "WAF",
    }
    return mapping.get(str(status or "").strip().lower(), "UNKNOWN")


def _site_result_to_search_result(plan: SearchPlan, result: SiteResult) -> SearchResult:
    raw = {
        "site_name": result.site_name,
        "url_main": result.url_main,
        "category": result.category,
        "probe_url": result.probe_url,
        "display_url": result.display_url,
        "status": result.status,
        "status_code": result.status_code,
        "final_url": result.final_url,
        "redirected": result.redirected,
        "page_title": result.page_title,
        "matched_markers": result.matched_markers,
        "control_passed": result.control_passed,
        "source_reliability": result.source_reliability,
        "reliability_note": result.reliability_note,
        "body_sha256": result.body_sha256,
        "body_len": result.body_len,
        "lead_kind": "verified_profile" if result.status == "exists" else "username_site_check",
        "result_group": "profiles",
        "sherlock_style": True,
        "sherlock_status": _sherlock_status(result.status),
        "verification_method": "sherlock_parallel_http_probe_with_controls",
        "produced_event_type": "PROFILE_URL" if result.status == "exists" else "USERNAME_SITE_STATUS",
    }
    confidence = float(result.confidence or 0.0) if result.status == "exists" else 0.0
    tags = [
        "username_scan",
        "sherlock_style",
        "profile",
        str(result.status or "unknown"),
    ]
    risk_flags = []
    if result.status != "exists":
        risk_flags.append("not_confirmed")
    return SearchResult(
        id="username_scan:" + _stable_id(plan.entity_input, result.site_name, result.display_url, result.status),
        source_id="username_scan:" + result.site_name.lower().replace(" ", "_"),
        source_name=f"{result.site_name} username check",
        entity_input=plan.entity_input,
        entity_type="username",
        matched_entity=plan.entity_input,
        matched_variant=result.display_url,
        scope=plan.scope,
        title=result.page_title or f"{result.site_name}: {result.status}",
        url=result.display_url if result.status == "exists" else "",
        snippet=result.reliability_note,
        raw_data=raw,
        normalized_data={
            **raw,
            "review_only": False,
            "direct_candidate": False,
            "lead_kind": raw["lead_kind"],
            "result_group": "profiles",
            "pivot_entity_type": "username",
            "pivot_value": plan.entity_input,
        },
        detected_platform=result.site_name,
        tags=tags,
        confidence_score=confidence,
        context_match_score=confidence,
        risk_flags=risk_flags,
        legal_notes="public_username_profile_check_with_control_usernames",
        explanation=(
            "Sherlock-style username site check: the username passed the site's regex, "
            "the site was probed in the async scanner, and the response was classified "
            "with per-site status rules and control username false-positive checks."
        ),
    )


def build_username_scan_results(
    plan: SearchPlan,
    *,
    context: SourceRunContext | None = None,
    limit: int | None = None,
) -> list[SearchResult]:
    if plan.entity_type != "username":
        return []
    if "social_profiles" not in {str(source.get("id") or "") for source in plan.sources}:
        return []
    sites = load_sites()
    selected_limit = limit if limit is not None else _scan_limit(plan)
    results = asyncio.run(
        scan_username(
            plan.entity_input,
            sites,
            categories=_scope_categories(plan),
            include_protected=False,
            limit=selected_limit,
            policy=context.http_policy() if context is not None else None,
        )
    )
    return [_site_result_to_search_result(plan, result) for result in results]
