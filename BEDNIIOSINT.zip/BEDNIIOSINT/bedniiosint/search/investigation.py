from __future__ import annotations

from typing import Any

from ..core.target import detect_module
from .query_parser import parse_search_query
from .scope_resolver import resolve_scope
from .source_registry import list_sources


ROUTES_BY_ENTITY_TYPE: dict[str, list[str]] = {
    "username": [
        "/identity/username",
        "/dev/github/profile",
        "/creator/video/youtube",
        "/creator/music/beatmaking",
        "/news",
    ],
    "email": [
        "/identity/email",
        "/dev/github/profile",
        "/identity/username",
        "/business/company",
    ],
    "domain": [
        "/infra/domain",
        "/cyber/threatintel",
        "/archive",
        "/business/company",
        "/news",
    ],
    "url": [
        "/infra/domain",
        "/cyber/threatintel",
        "/archive",
    ],
    "ip": [
        "/infra/ip",
        "/cyber/threatintel",
    ],
    "phone": [
        "/identity/phone",
        "/identity/username",
    ],
    "wallet": [
        "/crypto/address",
        "/cyber/threatintel",
    ],
    "company": [
        "/business/company",
        "/news",
        "/dev/github/profile",
        "/creator/video/youtube",
    ],
    "image_url": [
        "/media/reverse_image",
        "/news",
    ],
    "image": [
        "/media/reverse_image",
    ],
}


def _quote_cli_arg(value: str) -> str:
    clean = str(value or "")
    if not clean:
        return '""'
    if all(char not in clean for char in (' ', '"', "\t", "\n")):
        return clean
    return '"' + clean.replace('"', '\\"') + '"'


def _known_source_ids() -> set[str]:
    return {str(source.get("id") or "") for source in list_sources()}


def _source_count(source_ids: list[str]) -> int:
    known = _known_source_ids()
    return sum(1 for source_id in source_ids if source_id in known)


def _route_command(entity: str, route: str, entity_type: str, *, dry_run: bool) -> str:
    target = f"{entity} {route}".strip()
    parts = [
        "bedniiosint",
        "search-run" if dry_run else "search-plan",
        _quote_cli_arg(target),
        "--entity-type",
        _quote_cli_arg(entity_type),
    ]
    if dry_run:
        parts.append("--dry-run")
    return " ".join(parts)


def _candidate_routes(entity_type: str, requested_scope: str) -> list[str]:
    routes = list(ROUTES_BY_ENTITY_TYPE.get(entity_type, []))
    if requested_scope:
        resolved = resolve_scope(requested_scope, entity_type)
        if resolved.path and resolved.path not in routes:
            routes.insert(0, resolved.path)
    if not routes:
        routes = ["/public/osint", "/news", "/dev/github/profile"]
    return list(dict.fromkeys(routes))


def build_investigation_plan(target: str, *, entity_type: str | None = None) -> dict[str, Any]:
    parsed = parse_search_query(target)
    entity = parsed.entity or str(target or "").strip()
    detected_type = (entity_type or detect_module(entity)).strip().lower()
    routes: list[dict[str, Any]] = []

    for route in _candidate_routes(detected_type, parsed.scope_path):
        resolved = resolve_scope(route, detected_type)
        route_entity_type = resolved.entity_type_hint or detected_type
        routes.append(
            {
                "scope_path": resolved.path or route,
                "registry_scope": resolved.registry_scope,
                "route_name": resolved.route_name,
                "entity_type": route_entity_type,
                "recommended_source_ids": resolved.source_ids,
                "recommended_source_count": _source_count(resolved.source_ids),
                "include_auth_required_suggested": resolved.include_auth_required_suggested,
                "search_terms": resolved.search_terms,
                "commands": {
                    "plan": _route_command(entity, resolved.path or route, route_entity_type, dry_run=False),
                    "dry_run": _route_command(entity, resolved.path or route, route_entity_type, dry_run=True),
                },
                "notes": resolved.notes,
            }
        )

    return {
        "target": str(target or "").strip(),
        "entity_input": entity,
        "entity_type": detected_type,
        "parsed_query": parsed.as_dict(),
        "routes": routes,
        "counts": {
            "routes": len(routes),
            "recommended_sources": len(
                {
                    source_id
                    for route in routes
                    for source_id in route.get("recommended_source_ids", [])
                }
            ),
        },
    }
