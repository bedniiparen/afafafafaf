from __future__ import annotations

from typing import Any

from ..core.target import detect_module
from .evidence import build_search_run_evidence
from .event_graph import build_search_event_plan
from .pipeline import (
    SEARCH_TO_CATALOG_SOURCE_IDS,
    catalog_source_ids_for_search_sources,
    catalog_source_ids_by_search_source,
    filter_catalog_source_ids,
)
from .planner import SearchPlan, build_entity_variant_details, plan_search, source_priority_score
from .readiness import compact_search_source_readiness, search_source_readiness
from .report import build_search_report_summary, render_search_markdown
from .source_registry import filter_sources, get_source


def _candidate_sources(
    entity_input: str,
    *,
    entity_type: str | None = None,
    scope: str | None = None,
    source_ids: list[str] | None = None,
) -> list[dict[str, Any]]:
    if source_ids:
        return [get_source(source_id) for source_id in source_ids]
    selected_type = (entity_type or detect_module(entity_input)).strip().lower()
    selected_scope = scope or "public_osint"
    variants = build_entity_variant_details(entity_input, selected_type)
    rows = filter_sources(entity_type=selected_type, scope=selected_scope)
    for variant_type in {variant.entity_type for variant in variants if variant.entity_type != selected_type}:
        rows.extend(filter_sources(entity_type=variant_type, scope=selected_scope))
    return list({str(row.get("id") or ""): row for row in rows}.values())


def _catalog_adapter_rows(readiness_row: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for adapter in readiness_row.get("mapped_catalog_sources", []):
        if not isinstance(adapter, dict):
            continue
        configured = bool(adapter.get("configured"))
        rows.append(
            {
                "source_id": adapter.get("id"),
                "name": adapter.get("name"),
                "configured": configured,
                "runnable": bool(adapter.get("runnable")),
                "auth": adapter.get("auth"),
                "env_vars": adapter.get("env_vars", []),
                "missing_env_vars": [] if configured else list(adapter.get("env_vars") or []),
                "terms_risk": adapter.get("terms_risk"),
                "requires_opt_in": bool(adapter.get("requires_opt_in")),
                "setup_hint": adapter.get("setup_hint"),
            }
        )
    return rows


def _source_explain_rows(
    plan: SearchPlan,
    *,
    selected_catalog_source_ids: list[str],
    skipped_catalog_sources: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    readiness = {row["source_id"]: row for row in search_source_readiness()}
    skipped_catalog_by_id = {
        str(row.get("source_id") or ""): row for row in skipped_catalog_sources
    }
    selected_catalog = set(selected_catalog_source_ids)
    rows: list[dict[str, Any]] = []
    for query in plan.queries:
        row = readiness.get(query.source_id, {})
        compact = compact_search_source_readiness(row) if row else {}
        adapters = _catalog_adapter_rows(row)
        selected_adapters = [
            adapter["source_id"]
            for adapter in adapters
            if str(adapter.get("source_id") or "") in selected_catalog
        ]
        skipped_adapters = [
            skipped_catalog_by_id[adapter["source_id"]]
            for adapter in adapters
            if str(adapter.get("source_id") or "") in skipped_catalog_by_id
        ]
        if selected_adapters:
            run_status = "will_run"
        elif adapters:
            run_status = "all_catalog_adapters_skipped"
        else:
            run_status = "no_catalog_mapping"
        rows.append(
            {
                **compact,
                "run_status": run_status,
                "priority_score": query.metadata.get("source_priority_score"),
                "queries": query.queries,
                "variant_details": query.metadata.get("variant_details", []),
                "catalog_adapters": adapters,
                "selected_catalog_source_ids": selected_adapters,
                "skipped_catalog_sources": skipped_adapters,
                "explanation": (
                    f"Selected because it supports {query.entity_type} in scope {query.scope}; "
                    f"priority score {query.metadata.get('source_priority_score')}."
                ),
            }
        )
    return rows


def _compact_source_explain_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    compact_rows: list[dict[str, Any]] = []
    for row in rows:
        compact_rows.append(
            {
                "source_id": row.get("source_id"),
                "name": row.get("name"),
                "category": row.get("category"),
                "run_status": row.get("run_status"),
                "priority_score": row.get("priority_score"),
                "queries": row.get("queries", []),
                "catalog_source_ids": row.get("catalog_source_ids", []),
                "selected_catalog_source_ids": row.get("selected_catalog_source_ids", []),
                "skipped_catalog_sources": row.get("skipped_catalog_sources", []),
                "configured": bool(row.get("configured")),
                "runnable": bool(row.get("runnable")),
                "auth_required": bool(row.get("auth_required")),
                "missing_env_vars": row.get("missing_env_vars", []),
                "max_terms_risk": row.get("max_terms_risk"),
                "explanation": row.get("explanation"),
            }
        )
    return compact_rows


def _compact_plan(plan: SearchPlan) -> dict[str, Any]:
    return {
        "entity_input": plan.entity_input,
        "entity_type": plan.entity_type,
        "scope": plan.scope,
        "source_ids": [str(source.get("id") or "") for source in plan.sources],
        "queries": [
            {
                "source_id": query.source_id,
                "source_name": query.source_name,
                "queries": query.queries,
                "priority_score": query.metadata.get("source_priority_score"),
                "variant_details": query.metadata.get("variant_details", []),
            }
            for query in plan.queries
        ],
        "variant_details": [variant.as_dict() for variant in plan.variant_details],
        "parsed_query": plan.parsed_query,
        "resolved_scope": plan.resolved_scope,
        "source_routing": plan.source_routing,
    }


def _skipped_search_sources(
    entity_input: str,
    *,
    entity_type: str | None,
    scope: str | None,
    source_ids: list[str] | None,
    include_auth_required: bool,
    plan: SearchPlan,
) -> list[dict[str, Any]]:
    selected_ids = {str(source.get("id") or "") for source in plan.sources}
    rows: list[dict[str, Any]] = []
    candidates = _candidate_sources(
        entity_input,
        entity_type=entity_type,
        scope=scope,
        source_ids=source_ids,
    )
    candidate_by_id = {str(source.get("id") or ""): source for source in candidates}
    for recommended_id in (plan.source_routing or {}).get("recommended_source_ids", []):
        source_id = str(recommended_id or "")
        if source_id and source_id not in candidate_by_id:
            try:
                candidate_by_id[source_id] = get_source(source_id)
            except Exception:
                continue
    for source in candidate_by_id.values():
        source_id = str(source.get("id") or "")
        if source_id in selected_ids:
            continue
        reasons: list[str] = []
        if bool(source.get("auth_required")) and not include_auth_required:
            reasons.append("auth_required_excluded")
        if source_ids and source_id not in selected_ids and not reasons:
            reasons.append("filtered_by_planner")
        if not SEARCH_TO_CATALOG_SOURCE_IDS.get(source_id):
            reasons.append("no_catalog_mapping")
        rows.append(
            {
                "source_id": source_id,
                "name": source.get("name"),
                "category": source.get("category"),
                "auth_required": bool(source.get("auth_required")),
                "priority_score": source_priority_score(source),
                "reasons": reasons or ["not_selected"],
            }
        )
    return rows


def explain_search_run(
    entity_input: str,
    *,
    entity_type: str | None = None,
    scope: str | None = None,
    max_sources: int | None = None,
    include_auth_required: bool = False,
    source_ids: list[str] | None = None,
    configured_only: bool = False,
    search_plan: SearchPlan | None = None,
    compact: bool = False,
) -> dict[str, Any]:
    plan = search_plan or plan_search(
        entity_input,
        entity_type=entity_type,
        scope=scope,
        max_sources=max_sources,
        include_auth_required=include_auth_required,
        source_ids=source_ids,
    )
    run_target = plan.entity_input
    search_source_ids = [str(source.get("id") or "") for source in plan.sources]
    planned_catalog_source_ids = catalog_source_ids_for_search_sources(search_source_ids)
    catalog_source_ids, skipped_catalog_sources = filter_catalog_source_ids(
        planned_catalog_source_ids,
        available_only=configured_only,
    )
    source_rows = _source_explain_rows(
        plan,
        selected_catalog_source_ids=catalog_source_ids,
        skipped_catalog_sources=skipped_catalog_sources,
    )
    skipped_search_sources = _skipped_search_sources(
        run_target,
        entity_type=entity_type,
        scope=plan.scope,
        source_ids=source_ids,
        include_auth_required=include_auth_required,
        plan=plan,
    )
    run_evidence = build_search_run_evidence(
        entity_input=run_target,
        entity_type=entity_type or plan.entity_type,
        scope=plan.scope,
        plan=plan.as_dict(),
        pipeline={},
        results=[],
        skipped_catalog_sources=skipped_catalog_sources,
        catalog_source_ids_by_search_id=catalog_source_ids_by_search_source(search_source_ids),
        include_auth_required=include_auth_required,
        configured_only=configured_only,
    )
    source_event_plan = build_search_event_plan(
        plan,
        catalog_source_ids_by_search_id=catalog_source_ids_by_search_source(search_source_ids),
        skipped_catalog_sources=skipped_catalog_sources,
    )
    payload = {
        "dry_run": True,
        "compact": compact,
        "target": entity_input,
        "entity_input": run_target,
        "resolved_target": run_target,
        "entity_type": entity_type or plan.entity_type,
        "scope": plan.scope,
        "execution": {"mode": "dry_run", "max_workers": 0},
        "configured_only": configured_only,
        "include_auth_required": include_auth_required,
        "search_source_ids": search_source_ids,
        "planned_catalog_source_ids": planned_catalog_source_ids,
        "catalog_source_ids": catalog_source_ids,
        "skipped_catalog_sources": skipped_catalog_sources,
        "skipped_search_sources": skipped_search_sources,
        "sources": _compact_source_explain_rows(source_rows) if compact else source_rows,
        "plan": _compact_plan(plan) if compact else plan.as_dict(),
        "pipeline": {},
        "search_results": [],
        "result_groups": {},
        "result_group_counts": {},
        "source_event_plan": source_event_plan,
        "result_pivots": {
            "style": "spiderfoot_result_pivots",
            "items": [],
            "counts": {"total": 0, "available": 0, "by_type": {}, "by_source_group": {}},
            "next_actions": [],
        },
        "result_clusters": [],
        "dedup_summary": {"clusters": 0, "confirmed": 0, "possible": 0, "weak": 0, "unconfirmed": 0},
        "evidence_summary": {},
        "run_evidence": run_evidence.as_dict(),
        "run_summary": run_evidence.summary,
        "counts": {
            "search_sources": len(search_source_ids),
            "planned_catalog_sources": len(planned_catalog_source_ids),
            "catalog_sources": len(catalog_source_ids),
            "skipped_catalog_sources": len(skipped_catalog_sources),
            "skipped_search_sources": len(skipped_search_sources),
        },
    }
    payload["report_summary"] = build_search_report_summary(payload)
    payload["report_markdown"] = render_search_markdown(payload)
    return payload
