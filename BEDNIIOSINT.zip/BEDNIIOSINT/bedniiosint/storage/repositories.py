from __future__ import annotations

from pathlib import Path
from collections.abc import Iterable
from typing import Any, Generic, TypeVar

from sqlalchemy import delete as sa_delete
from sqlalchemy import func, insert, select
from sqlalchemy import update as sa_update

from .models import Case, Model
from .sqlalchemy_schema import STORAGE_METADATA
from .sqlite import _from_db, _to_db, sqlalchemy_engine


TModel = TypeVar("TModel", bound=Model)


class ModelRepository(Generic[TModel]):
    def __init__(self, db_path: Path, model: type[TModel]):
        self.db_path = db_path
        self.model = model
        self.engine = sqlalchemy_engine(db_path)
        self.table = STORAGE_METADATA.tables[model.table_name()]

    def _hydrate(self, values: dict[str, Any]) -> TModel:
        hydrated = {
            column: _from_db(self.model, column, values.get(column))
            for column in self.model.__columns__
        }
        return self.model(**hydrated)

    def _validate_column(self, column: str) -> None:
        if column not in self.model.__columns__:
            raise KeyError(f"unknown column for {self.model.table_name()}: {column}")

    def _write_values(self, obj: TModel) -> dict[str, Any]:
        return {
            column: _to_db(getattr(obj, column))
            for column in self.model.__columns__
            if column != "id"
        }

    def list_all(self) -> list[TModel]:
        statement = select(self.table)
        with self.engine.connect() as conn:
            rows = conn.execute(statement).mappings().all()
        return [self._hydrate(dict(row)) for row in rows]

    def list_by(self, **filters: Any) -> list[TModel]:
        statement = select(self.table)
        for key, value in filters.items():
            self._validate_column(key)
            statement = statement.where(self.table.c[key] == _to_db(value))
        with self.engine.connect() as conn:
            rows = conn.execute(statement).mappings().all()
        return [self._hydrate(dict(row)) for row in rows]

    def list_by_values(self, column: str, values: Iterable[Any]) -> list[TModel]:
        self._validate_column(column)
        db_values = [_to_db(value) for value in values]
        if not db_values:
            return []
        statement = select(self.table).where(self.table.c[column].in_(db_values))
        if "id" in self.model.__columns__:
            statement = statement.order_by(self.table.c.id)
        with self.engine.connect() as conn:
            rows = conn.execute(statement).mappings().all()
        return [self._hydrate(dict(row)) for row in rows]

    def first_by(self, **filters: Any) -> TModel | None:
        rows = self.list_by(**filters)
        return rows[0] if rows else None

    def get(self, obj_id: Any) -> TModel | None:
        self._validate_column("id")
        statement = select(self.table).where(self.table.c.id == _to_db(obj_id))
        with self.engine.connect() as conn:
            row = conn.execute(statement).mappings().first()
        return self._hydrate(dict(row)) if row is not None else None

    def count_by(self, **filters: Any) -> int:
        statement = select(func.count()).select_from(self.table)
        for key, value in filters.items():
            self._validate_column(key)
            statement = statement.where(self.table.c[key] == _to_db(value))
        with self.engine.connect() as conn:
            return int(conn.execute(statement).scalar_one())

    def add(self, obj: TModel) -> TModel:
        statement = insert(self.table).values(**self._write_values(obj))
        with self.engine.begin() as conn:
            result = conn.execute(statement)
        if getattr(obj, "id", None) is None:
            obj.id = result.inserted_primary_key[0]
        return obj

    def update(self, obj: TModel) -> TModel:
        obj_id = getattr(obj, "id", None)
        if obj_id is None:
            raise ValueError("cannot update object without id")
        statement = (
            sa_update(self.table)
            .where(self.table.c.id == _to_db(obj_id))
            .values(**self._write_values(obj))
        )
        with self.engine.begin() as conn:
            conn.execute(statement)
        return obj

    def delete(self, obj: TModel) -> bool:
        obj_id = getattr(obj, "id", None)
        if obj_id is None:
            raise ValueError("cannot delete object without id")
        statement = sa_delete(self.table).where(self.table.c.id == _to_db(obj_id))
        with self.engine.begin() as conn:
            result = conn.execute(statement)
        return bool(result.rowcount)


class CaseRepository(ModelRepository[Case]):
    def __init__(self, db_path: Path):
        super().__init__(db_path, Case)

    def list_by_name(self, name: str) -> list[Case]:
        return self.list_by(name=name)

    def ids_by_name(self, name: str) -> list[int]:
        return [row.id for row in self.list_by_name(name) if row.id is not None]
