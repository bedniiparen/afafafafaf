from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
import types
from typing import Any, Optional, TypeVar

from sqlalchemy import func, select

from .models import ALL_MODELS, Model
from .sqlalchemy_schema import BOOLEAN_COLUMNS, sqlalchemy_column_for
from .sqlite import _from_db, _to_db, sqlalchemy_engine

try:
    from sqlmodel import Field, Session as SQLModelSession, SQLModel
except Exception:  # pragma: no cover
    Field = None
    SQLModel = None
    SQLModelSession = None


DATETIME_COLUMNS = {
    "created_at",
    "captured_at",
    "when",
    "first_seen",
    "last_seen",
    "recheck_at",
    "health_checked_at",
    "updated_at",
    "finished_at",
    "claimed_at",
    "heartbeat_at",
    "applied_at",
    "recorded_at",
}


def sqlmodel_available() -> bool:
    return SQLModel is not None and Field is not None and SQLModelSession is not None


def _python_type_for(model: type[Model], column_name: str) -> type:
    if column_name in DATETIME_COLUMNS:
        return str
    if column_name in BOOLEAN_COLUMNS:
        return bool
    sqlite_type = model.__types__[column_name].split()[0].upper()
    if sqlite_type == "INTEGER":
        return int
    if sqlite_type == "REAL":
        return float
    return str


def _default_factory(factory):
    return lambda: _to_db(factory())


def _field_for(model: type[Model], column_name: str):
    if Field is None:
        raise RuntimeError("sqlmodel is required for SQLModel storage classes")
    kwargs: dict[str, Any] = {"sa_column": sqlalchemy_column_for(model, column_name)}
    if column_name in model.__factories__:
        kwargs["default_factory"] = _default_factory(model.__factories__[column_name])
    else:
        kwargs["default"] = model.__defaults__.get(column_name)
    return Field(**kwargs)


def sqlmodel_for_model(model: type[Model]) -> type:
    if SQLModel is None:
        raise RuntimeError("sqlmodel is required for SQLModel storage classes")

    def exec_body(namespace: dict[str, Any]) -> None:
        namespace["__module__"] = __name__
        namespace["__tablename__"] = model.table_name()
        annotations: dict[str, Any] = {}
        for column_name in model.__columns__:
            annotations[column_name] = Optional[_python_type_for(model, column_name)]
            namespace[column_name] = _field_for(model, column_name)
        namespace["__annotations__"] = annotations

    return types.new_class(
        f"{model.__name__}SQLModel",
        (SQLModel,),
        {"table": True},
        exec_body,
    )


def _build_sqlmodel_map(models: Iterable[type[Model]] = ALL_MODELS) -> dict[type[Model], type]:
    if not sqlmodel_available():
        return {}
    return {model: sqlmodel_for_model(model) for model in models}


SQLMODEL_BY_LEGACY: dict[type[Model], type] = _build_sqlmodel_map()
SQLMODEL_BY_TABLE: dict[str, type] = {
    model.table_name(): sql_model for model, sql_model in SQLMODEL_BY_LEGACY.items()
}

TModel = TypeVar("TModel", bound=Model)


class SQLModelRepository:
    def __init__(self, db_path: Path, model: type[TModel]):
        if SQLModelSession is None:
            raise RuntimeError("sqlmodel is required for SQLModelRepository")
        self.db_path = db_path
        self.model = model
        self.sql_model = SQLMODEL_BY_LEGACY[model]
        self.engine = sqlalchemy_engine(db_path)

    def _to_sqlmodel(self, obj: TModel):
        values = {
            column: _to_db(getattr(obj, column))
            for column in self.model.__columns__
            if not (column == "id" and getattr(obj, "id", None) is None)
        }
        return self.sql_model(**values)

    def _to_legacy(self, row) -> TModel:
        values = {
            column: _from_db(self.model, column, getattr(row, column))
            for column in self.model.__columns__
        }
        return self.model(**values)

    def list_by(self, **filters: Any) -> list[TModel]:
        statement = select(self.sql_model)
        for key, value in filters.items():
            if key not in self.model.__columns__:
                raise KeyError(f"unknown column for {self.model.table_name()}: {key}")
            statement = statement.where(getattr(self.sql_model, key) == _to_db(value))
        with SQLModelSession(self.engine) as session:
            rows = session.exec(statement).all()
        return [self._to_legacy(row) for row in rows]

    def first_by(self, **filters: Any) -> TModel | None:
        rows = self.list_by(**filters)
        return rows[0] if rows else None

    def get(self, obj_id: Any) -> TModel | None:
        with SQLModelSession(self.engine) as session:
            row = session.get(self.sql_model, _to_db(obj_id))
        return self._to_legacy(row) if row is not None else None

    def count_by(self, **filters: Any) -> int:
        statement = select(func.count()).select_from(self.sql_model)
        for key, value in filters.items():
            if key not in self.model.__columns__:
                raise KeyError(f"unknown column for {self.model.table_name()}: {key}")
            statement = statement.where(getattr(self.sql_model, key) == _to_db(value))
        with SQLModelSession(self.engine) as session:
            return int(session.exec(statement).one())

    def add(self, obj: TModel) -> TModel:
        row = self._to_sqlmodel(obj)
        with SQLModelSession(self.engine) as session:
            session.add(row)
            session.commit()
            session.refresh(row)
        for column in self.model.__columns__:
            setattr(obj, column, _from_db(self.model, column, getattr(row, column)))
        return obj

    def update(self, obj: TModel) -> TModel:
        obj_id = getattr(obj, "id", None)
        if obj_id is None:
            raise ValueError("cannot update object without id")
        with SQLModelSession(self.engine) as session:
            row = session.get(self.sql_model, _to_db(obj_id))
            if row is None:
                raise KeyError(f"{self.model.table_name()} row not found: {obj_id}")
            for column in self.model.__columns__:
                if column != "id":
                    setattr(row, column, _to_db(getattr(obj, column)))
            session.add(row)
            session.commit()
        return obj

    def delete(self, obj: TModel) -> bool:
        obj_id = getattr(obj, "id", None)
        if obj_id is None:
            raise ValueError("cannot delete object without id")
        with SQLModelSession(self.engine) as session:
            row = session.get(self.sql_model, _to_db(obj_id))
            if row is None:
                return False
            session.delete(row)
            session.commit()
        return True
