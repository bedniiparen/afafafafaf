from __future__ import annotations

"""SQLite FTS index for stored or in-memory search results."""

import json
import re
import sqlite3
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

_TOKEN_RE = re.compile(r"[\w@.+-]+", re.UNICODE)


@dataclass
class SearchFtsHit:
    result_id: str
    case_name: str
    source_id: str
    entity_type: str
    matched_entity: str
    title: str
    url: str
    snippet: str
    confidence_score: float
    rank: float
    payload: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "result_id": self.result_id,
            "case_name": self.case_name,
            "source_id": self.source_id,
            "entity_type": self.entity_type,
            "matched_entity": self.matched_entity,
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "confidence_score": self.confidence_score,
            "rank": self.rank,
            "payload": self.payload,
        }


def _connect(db_path: str | Path) -> sqlite3.Connection:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def _payload(result: Any) -> dict[str, Any]:
    if hasattr(result, "as_dict"):
        data = result.as_dict()
    elif hasattr(result, "to_dict"):
        data = result.to_dict()
    else:
        data = dict(result)
    return dict(data)


def _text_parts(payload: dict[str, Any]) -> tuple[str, str, str, str, str, str]:
    normalized = payload.get("normalized_data")
    if not isinstance(normalized, dict):
        normalized = {}
    raw = payload.get("raw_data")
    raw_text = json.dumps(raw, ensure_ascii=False, sort_keys=True, default=str) if raw else ""
    return (
        str(payload.get("source_id") or ""),
        str(payload.get("entity_type") or ""),
        str(payload.get("matched_entity") or payload.get("entity_input") or ""),
        str(payload.get("title") or ""),
        str(payload.get("url") or ""),
        " ".join(
            part
            for part in (
                str(payload.get("snippet") or ""),
                json.dumps(normalized, ensure_ascii=False, sort_keys=True, default=str),
                raw_text,
            )
            if part
        ),
    )


def _doc_key(case_name: str, result_id: str) -> str:
    return f"{case_name}\x1f{result_id}"


def _query_for_fts(query: str) -> str:
    tokens = _TOKEN_RE.findall(str(query or "").lower())
    tokens = [token.replace('"', '""') for token in tokens if token]
    return " OR ".join(f'"{token}"' for token in tokens[:24])


class SearchResultFtsIndex:
    """Additive full-text index for result pivots and offline re-search."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self._fts_enabled: bool | None = None
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        with _connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS search_result_index (
                    doc_key TEXT PRIMARY KEY,
                    result_id TEXT NOT NULL,
                    case_name TEXT NOT NULL DEFAULT '',
                    source_id TEXT NOT NULL DEFAULT '',
                    source_name TEXT NOT NULL DEFAULT '',
                    entity_type TEXT NOT NULL DEFAULT '',
                    matched_entity TEXT NOT NULL DEFAULT '',
                    title TEXT NOT NULL DEFAULT '',
                    url TEXT NOT NULL DEFAULT '',
                    snippet TEXT NOT NULL DEFAULT '',
                    confidence_score REAL NOT NULL DEFAULT 0.0,
                    found_at TEXT NOT NULL DEFAULT '',
                    payload_json TEXT NOT NULL
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_search_result_index_case "
                "ON search_result_index(case_name)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_search_result_index_source "
                "ON search_result_index(source_id)"
            )
            try:
                conn.execute(
                    """
                    CREATE VIRTUAL TABLE IF NOT EXISTS search_result_fts USING fts5(
                        doc_key UNINDEXED,
                        case_name UNINDEXED,
                        source_id,
                        entity_type,
                        matched_entity,
                        title,
                        url,
                        snippet
                    )
                    """
                )
                self._fts_enabled = True
            except sqlite3.OperationalError:
                self._fts_enabled = False
            conn.commit()

    @property
    def fts_enabled(self) -> bool:
        if self._fts_enabled is None:
            self._ensure_schema()
        return bool(self._fts_enabled)

    def index_result(self, result: Any, *, case_name: str = "") -> str:
        payload = _payload(result)
        result_id = str(payload.get("id") or payload.get("result_id") or "")
        if not result_id:
            result_id = str(payload.get("url") or payload.get("matched_entity") or payload.get("title") or "")
        if not result_id:
            raise ValueError("result must contain id, result_id, url, matched_entity or title")
        source_id, entity_type, matched_entity, title, url, snippet = _text_parts(payload)
        key = _doc_key(case_name, result_id)
        confidence = float(payload.get("confidence_score") or 0.0)
        with _connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO search_result_index (
                    doc_key, result_id, case_name, source_id, source_name, entity_type,
                    matched_entity, title, url, snippet, confidence_score, found_at, payload_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    key,
                    result_id,
                    case_name,
                    source_id,
                    str(payload.get("source_name") or ""),
                    entity_type,
                    matched_entity,
                    title,
                    url,
                    snippet,
                    confidence,
                    str(payload.get("found_at") or ""),
                    json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str),
                ),
            )
            if self.fts_enabled:
                conn.execute("DELETE FROM search_result_fts WHERE doc_key = ?", (key,))
                conn.execute(
                    """
                    INSERT INTO search_result_fts (
                        doc_key, case_name, source_id, entity_type,
                        matched_entity, title, url, snippet
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (key, case_name, source_id, entity_type, matched_entity, title, url, snippet),
                )
            conn.commit()
        return key

    def index_results(self, results: Iterable[Any], *, case_name: str = "") -> list[str]:
        return [self.index_result(result, case_name=case_name) for result in results]

    def delete_result(self, result_id: str, *, case_name: str = "") -> bool:
        key = _doc_key(case_name, str(result_id))
        with _connect(self.db_path) as conn:
            if self.fts_enabled:
                conn.execute("DELETE FROM search_result_fts WHERE doc_key = ?", (key,))
            deleted = conn.execute(
                "DELETE FROM search_result_index WHERE doc_key = ?",
                (key,),
            ).rowcount
            conn.commit()
        return bool(deleted)

    def clear(self, *, case_name: str | None = None) -> int:
        with _connect(self.db_path) as conn:
            if case_name is None:
                count = int(conn.execute("SELECT COUNT(*) FROM search_result_index").fetchone()[0])
                conn.execute("DELETE FROM search_result_index")
                if self.fts_enabled:
                    conn.execute("DELETE FROM search_result_fts")
            else:
                count = int(
                    conn.execute(
                        "SELECT COUNT(*) FROM search_result_index WHERE case_name = ?",
                        (case_name,),
                    ).fetchone()[0]
                )
                keys = [
                    str(row["doc_key"])
                    for row in conn.execute(
                        "SELECT doc_key FROM search_result_index WHERE case_name = ?",
                        (case_name,),
                    ).fetchall()
                ]
                conn.execute("DELETE FROM search_result_index WHERE case_name = ?", (case_name,))
                if self.fts_enabled:
                    for key in keys:
                        conn.execute("DELETE FROM search_result_fts WHERE doc_key = ?", (key,))
            conn.commit()
        return count

    def search(
        self,
        query: str,
        *,
        case_name: str | None = None,
        source_ids: Sequence[str] | None = None,
        limit: int = 25,
    ) -> list[SearchFtsHit]:
        clean_limit = max(1, int(limit))
        source_filter = {str(source_id) for source_id in (source_ids or []) if source_id}
        fts_query = _query_for_fts(query)
        with _connect(self.db_path) as conn:
            if self.fts_enabled and fts_query:
                rows = self._search_fts(conn, fts_query, case_name=case_name, limit=clean_limit * 4)
            else:
                rows = self._search_like(conn, query, case_name=case_name, limit=clean_limit * 4)
        hits: list[SearchFtsHit] = []
        for row in rows:
            if source_filter and str(row["source_id"]) not in source_filter:
                continue
            payload = json.loads(str(row["payload_json"] or "{}"))
            hits.append(
                SearchFtsHit(
                    result_id=str(row["result_id"] or ""),
                    case_name=str(row["case_name"] or ""),
                    source_id=str(row["source_id"] or ""),
                    entity_type=str(row["entity_type"] or ""),
                    matched_entity=str(row["matched_entity"] or ""),
                    title=str(row["title"] or ""),
                    url=str(row["url"] or ""),
                    snippet=str(row["snippet"] or ""),
                    confidence_score=float(row["confidence_score"] or 0.0),
                    rank=float(row["rank"] or 0.0),
                    payload=payload,
                )
            )
            if len(hits) >= clean_limit:
                break
        return hits

    def _search_fts(
        self,
        conn: sqlite3.Connection,
        query: str,
        *,
        case_name: str | None,
        limit: int,
    ) -> list[sqlite3.Row]:
        where = ["search_result_fts MATCH ?"]
        params: list[Any] = [query]
        if case_name is not None:
            where.append("i.case_name = ?")
            params.append(case_name)
        params.append(limit)
        return conn.execute(
            f"""
            SELECT i.*, bm25(search_result_fts) AS rank
            FROM search_result_fts
            JOIN search_result_index AS i ON i.doc_key = search_result_fts.doc_key
            WHERE {' AND '.join(where)}
            ORDER BY rank ASC, i.confidence_score DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def _search_like(
        self,
        conn: sqlite3.Connection,
        query: str,
        *,
        case_name: str | None,
        limit: int,
    ) -> list[sqlite3.Row]:
        tokens = _TOKEN_RE.findall(str(query or "").lower())
        where: list[str] = []
        params: list[Any] = []
        for token in tokens[:8]:
            where.append(
                "lower(source_id || ' ' || entity_type || ' ' || matched_entity || ' ' || "
                "title || ' ' || url || ' ' || snippet) LIKE ?"
            )
            params.append(f"%{token}%")
        if case_name is not None:
            where.append("case_name = ?")
            params.append(case_name)
        if not where:
            where.append("1 = 1")
        params.append(limit)
        return conn.execute(
            f"""
            SELECT *, confidence_score * -1.0 AS rank
            FROM search_result_index
            WHERE {' AND '.join(where)}
            ORDER BY confidence_score DESC
            LIMIT ?
            """,
            params,
        ).fetchall()


def index_search_results(
    db_path: str | Path,
    results: Iterable[Any],
    *,
    case_name: str = "",
) -> list[str]:
    return SearchResultFtsIndex(db_path).index_results(results, case_name=case_name)


def search_index(
    db_path: str | Path,
    query: str,
    *,
    case_name: str | None = None,
    source_ids: Sequence[str] | None = None,
    limit: int = 25,
) -> list[dict[str, Any]]:
    return [
        hit.as_dict()
        for hit in SearchResultFtsIndex(db_path).search(
            query,
            case_name=case_name,
            source_ids=source_ids,
            limit=limit,
        )
    ]
