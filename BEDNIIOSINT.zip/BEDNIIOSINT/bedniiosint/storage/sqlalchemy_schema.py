from __future__ import annotations

from typing import Iterable

from sqlalchemy import Boolean, Column, Float, Integer, MetaData, Table, Text
from sqlalchemy.sql.elements import quoted_name

from .models import ALL_MODELS, Model


SQLITE_TYPE_MAP = {
    "INTEGER": Integer,
    "TEXT": Text,
    "REAL": Float,
}

BOOLEAN_COLUMNS = {
    "calibrated",
    "redirected",
    "rejected",
    "cancel_requested",
    "resume",
    "network_required",
    "allow_opt_in",
    "redacted",
    "dry_run",
    "applied",
    "secrets_returned",
}


def sqlalchemy_type_for(model: type[Model], column_name: str):
    sqlite_type = model.__types__[column_name].split()[0].upper()
    if sqlite_type == "INTEGER" and column_name in BOOLEAN_COLUMNS:
        return Boolean
    try:
        return SQLITE_TYPE_MAP[sqlite_type]
    except KeyError as exc:
        raise ValueError(
            f"unsupported SQLite type for {model.table_name()}.{column_name}: "
            f"{model.__types__[column_name]}"
        ) from exc


def sqlalchemy_column_for(model: type[Model], column_name: str) -> Column:
    column_type = sqlalchemy_type_for(model, column_name)
    raw_type = model.__types__[column_name].upper()
    is_primary_key = "PRIMARY KEY" in raw_type
    return Column(
        quoted_name(column_name, True),
        column_type,
        primary_key=is_primary_key,
        autoincrement=is_primary_key and column_type is Integer,
    )


def table_for_model(model: type[Model], metadata: MetaData) -> Table:
    return Table(
        quoted_name(model.table_name(), True),
        metadata,
        *(sqlalchemy_column_for(model, column_name) for column_name in model.__columns__),
    )


def metadata_for_models(models: Iterable[type[Model]] = ALL_MODELS) -> MetaData:
    metadata = MetaData()
    for model in models:
        table_for_model(model, metadata)
    return metadata


STORAGE_METADATA = metadata_for_models()
