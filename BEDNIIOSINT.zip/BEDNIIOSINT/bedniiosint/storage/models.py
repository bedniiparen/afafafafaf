from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, ClassVar, Optional

from sqlalchemy import Boolean, Float, Integer, Text
from sqlalchemy.orm import DeclarativeBase, mapped_column
from sqlalchemy.sql.elements import quoted_name
from sqlalchemy.types import TypeDecorator


def _now() -> datetime:
    return datetime.now(timezone.utc)


BOOLEAN_COLUMNS = {
    "calibrated",
    "redirected",
    "rejected",
    "cancel_requested",
    "resume",
    "network_required",
    "allow_opt_in",
    "redacted",
    "dry_run",
    "applied",
    "secrets_returned",
}

DATETIME_COLUMNS = {
    "created_at",
    "captured_at",
    "when",
    "first_seen",
    "last_seen",
    "recheck_at",
    "health_checked_at",
    "updated_at",
    "finished_at",
    "claimed_at",
    "heartbeat_at",
    "applied_at",
    "recorded_at",
}


class DateTimeText(TypeDecorator):
    impl = Text
    cache_ok = True

    def process_bind_param(self, value, dialect):  # noqa: ARG002
        if isinstance(value, datetime):
            return value.isoformat()
        return value

    def process_result_value(self, value, dialect):  # noqa: ARG002
        if value is None or isinstance(value, datetime):
            return value
        try:
            return datetime.fromisoformat(value)
        except (TypeError, ValueError):
            return value


class StorageBase(DeclarativeBase):
    pass


def _mapped_type_for(model: type["Model"], column_name: str):
    sqlite_type = model.__types__[column_name].split()[0].upper()
    if column_name in DATETIME_COLUMNS:
        return DateTimeText()
    if sqlite_type == "INTEGER" and column_name in BOOLEAN_COLUMNS:
        return Boolean
    if sqlite_type == "INTEGER":
        return Integer
    if sqlite_type == "REAL":
        return Float
    if sqlite_type == "TEXT":
        return Text
    raise ValueError(
        f"unsupported SQLite type for {model.table_name()}.{column_name}: "
        f"{model.__types__[column_name]}"
    )


class Model(StorageBase):
    __abstract__ = True
    __allow_unmapped__ = True
    __columns__: ClassVar[tuple[str, ...]] = ()
    __types__: ClassVar[dict[str, str]] = {}
    __defaults__: ClassVar[dict[str, Any]] = {}
    __factories__: ClassVar[dict[str, Any]] = {}

    def __init_subclass__(cls) -> None:
        cls.__tablename__ = quoted_name(cls.table_name(), True)
        for name in cls.__columns__:
            raw_type = cls.__types__[name].upper()
            is_primary_key = "PRIMARY KEY" in raw_type
            setattr(
                cls,
                name,
                mapped_column(
                    quoted_name(name, True),
                    _mapped_type_for(cls, name),
                    primary_key=is_primary_key,
                    autoincrement=(
                        is_primary_key
                        and cls.__types__[name].split()[0].upper() == "INTEGER"
                    ),
                    nullable=not is_primary_key,
                ),
            )
        super().__init_subclass__()

    def __init__(self, **kwargs) -> None:
        for name in self.__columns__:
            if name in kwargs:
                value = kwargs[name]
            elif name in self.__factories__:
                value = self.__factories__[name]()
            else:
                value = self.__defaults__.get(name)
            setattr(self, name, value)

    @classmethod
    def table_name(cls) -> str:
        return cls.__name__.lower()

    def as_dict(self) -> dict[str, Any]:
        return {name: getattr(self, name) for name in self.__columns__}


class Case(Model):
    __columns__ = ("id", "name", "target", "module", "created_at")
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "name": "TEXT",
        "target": "TEXT",
        "module": "TEXT",
        "created_at": "TEXT",
    }
    __defaults__ = {"id": None}
    __factories__ = {"created_at": _now}

    id: Optional[int]
    name: str
    target: str
    module: str
    created_at: datetime


class Entity(Model):
    __columns__ = ("id", "case_id", "type", "value", "created_at")
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "case_id": "INTEGER",
        "type": "TEXT",
        "value": "TEXT",
        "created_at": "TEXT",
    }
    __defaults__ = {"id": None}
    __factories__ = {"created_at": _now}

    id: Optional[int]
    case_id: int
    type: str
    value: str
    created_at: datetime


class Source(Model):
    __columns__ = (
        "id",
        "case_id",
        "name",
        "source_id",
        "url_main",
        "category",
        "adapter",
        "auth",
        "reliability",
        "calibrated",
        "success_count",
        "error_count",
        "health_status",
        "health_checked_at",
        "last_error",
        "version",
        "notes",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "case_id": "INTEGER",
        "name": "TEXT",
        "source_id": "TEXT",
        "url_main": "TEXT",
        "category": "TEXT",
        "adapter": "TEXT",
        "auth": "TEXT",
        "reliability": "REAL",
        "calibrated": "INTEGER",
        "success_count": "INTEGER",
        "error_count": "INTEGER",
        "health_status": "TEXT",
        "health_checked_at": "TEXT",
        "last_error": "TEXT",
        "version": "TEXT",
        "notes": "TEXT",
    }
    __defaults__ = {
        "id": None,
        "source_id": "",
        "category": "misc",
        "adapter": "",
        "auth": "none",
        "reliability": 1.0,
        "calibrated": False,
        "success_count": 0,
        "error_count": 0,
        "health_status": "unknown",
        "health_checked_at": None,
        "last_error": "",
        "version": "",
        "notes": "",
    }

    id: Optional[int]
    case_id: int
    name: str
    source_id: str
    url_main: str
    category: str
    adapter: str
    auth: str
    reliability: float
    calibrated: bool
    success_count: int
    error_count: int
    health_status: str
    health_checked_at: Optional[datetime]
    last_error: str
    version: str
    notes: str


class Finding(Model):
    __columns__ = (
        "id",
        "case_id",
        "source_name",
        "source_id",
        "source_reliability",
        "entity_value",
        "entity_type",
        "finding_type",
        "profile_url",
        "status",
        "status_code",
        "final_url",
        "redirected",
        "page_title",
        "matched_markers",
        "confidence",
        "confidence_reason",
        "rejected",
        "reject_reason",
        "first_seen",
        "last_seen",
        "recheck_at",
        "captured_at",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "case_id": "INTEGER",
        "source_name": "TEXT",
        "source_id": "TEXT",
        "source_reliability": "REAL",
        "entity_value": "TEXT",
        "entity_type": "TEXT",
        "finding_type": "TEXT",
        "profile_url": "TEXT",
        "status": "TEXT",
        "status_code": "INTEGER",
        "final_url": "TEXT",
        "redirected": "INTEGER",
        "page_title": "TEXT",
        "matched_markers": "TEXT",
        "confidence": "REAL",
        "confidence_reason": "TEXT",
        "rejected": "INTEGER",
        "reject_reason": "TEXT",
        "first_seen": "TEXT",
        "last_seen": "TEXT",
        "recheck_at": "TEXT",
        "captured_at": "TEXT",
    }
    __defaults__ = {
        "id": None,
        "source_id": "",
        "source_reliability": 0.0,
        "entity_type": "",
        "finding_type": "observation",
        "status_code": None,
        "final_url": "",
        "redirected": False,
        "page_title": "",
        "matched_markers": "",
        "confidence": 0.0,
        "confidence_reason": "",
        "rejected": False,
        "reject_reason": "",
        "first_seen": None,
        "last_seen": None,
        "recheck_at": None,
    }
    __factories__ = {"captured_at": _now}

    id: Optional[int]
    case_id: int
    source_name: str
    source_id: str
    source_reliability: float
    entity_value: str
    entity_type: str
    finding_type: str
    profile_url: str
    status: str
    status_code: Optional[int]
    final_url: str
    redirected: bool
    page_title: str
    matched_markers: str
    confidence: float
    confidence_reason: str
    rejected: bool
    reject_reason: str
    first_seen: Optional[datetime]
    last_seen: Optional[datetime]
    recheck_at: Optional[datetime]
    captured_at: datetime


class Evidence(Model):
    __columns__ = (
        "id",
        "case_id",
        "finding_id",
        "url",
        "final_url",
        "http_status",
        "sha256",
        "body_len",
        "source_module",
        "adapter_version",
        "content_type",
        "headers_json",
        "query_params_json",
        "method",
        "artifact_path",
        "confidence_at_capture",
        "captured_at",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "case_id": "INTEGER",
        "finding_id": "INTEGER",
        "url": "TEXT",
        "final_url": "TEXT",
        "http_status": "INTEGER",
        "sha256": "TEXT",
        "body_len": "INTEGER",
        "source_module": "TEXT",
        "adapter_version": "TEXT",
        "content_type": "TEXT",
        "headers_json": "TEXT",
        "query_params_json": "TEXT",
        "method": "TEXT",
        "artifact_path": "TEXT",
        "confidence_at_capture": "REAL",
        "captured_at": "TEXT",
    }
    __defaults__ = {
        "id": None,
        "http_status": None,
        "body_len": 0,
        "source_module": "username",
        "adapter_version": "",
        "content_type": "",
        "headers_json": "{}",
        "query_params_json": "{}",
        "method": "GET",
        "artifact_path": "",
        "confidence_at_capture": 0.0,
    }
    __factories__ = {"captured_at": _now}

    id: Optional[int]
    case_id: int
    finding_id: int
    url: str
    final_url: str
    http_status: Optional[int]
    sha256: str
    body_len: int
    source_module: str
    adapter_version: str
    content_type: str
    headers_json: str
    query_params_json: str
    method: str
    artifact_path: str
    confidence_at_capture: float
    captured_at: datetime


class Relation(Model):
    __columns__ = (
        "id",
        "case_id",
        "src_type",
        "src_value",
        "rel",
        "dst_type",
        "dst_value",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "case_id": "INTEGER",
        "src_type": "TEXT",
        "src_value": "TEXT",
        "rel": "TEXT",
        "dst_type": "TEXT",
        "dst_value": "TEXT",
    }
    __defaults__ = {"id": None}

    id: Optional[int]
    case_id: int
    src_type: str
    src_value: str
    rel: str
    dst_type: str
    dst_value: str


class TimelineEvent(Model):
    __columns__ = (
        "id",
        "case_id",
        "finding_id",
        "when",
        "when_precision",
        "kind",
        "entity_type",
        "entity_value",
        "source_name",
        "confidence",
        "description",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "case_id": "INTEGER",
        "finding_id": "INTEGER",
        "when": "TEXT",
        "when_precision": "TEXT",
        "kind": "TEXT",
        "entity_type": "TEXT",
        "entity_value": "TEXT",
        "source_name": "TEXT",
        "confidence": "REAL",
        "description": "TEXT",
    }
    __defaults__ = {
        "id": None,
        "finding_id": None,
        "when": None,
        "when_precision": "exact",
        "source_name": "",
        "confidence": 0.0,
        "description": "",
    }

    id: Optional[int]
    case_id: int
    finding_id: Optional[int]
    when: Optional[datetime]
    when_precision: str
    kind: str
    entity_type: str
    entity_value: str
    source_name: str
    confidence: float
    description: str


class Attachment(Model):
    __columns__ = (
        "id",
        "case_id",
        "finding_id",
        "kind",
        "path",
        "sha256",
        "mime",
        "source_adapter_version",
        "metadata_json",
        "captured_at",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "case_id": "INTEGER",
        "finding_id": "INTEGER",
        "kind": "TEXT",
        "path": "TEXT",
        "sha256": "TEXT",
        "mime": "TEXT",
        "source_adapter_version": "TEXT",
        "metadata_json": "TEXT",
        "captured_at": "TEXT",
    }
    __defaults__ = {
        "id": None,
        "finding_id": None,
        "mime": "",
        "source_adapter_version": "",
        "metadata_json": "{}",
    }
    __factories__ = {"captured_at": _now}

    id: Optional[int]
    case_id: int
    finding_id: Optional[int]
    kind: str
    path: str
    sha256: str
    mime: str
    source_adapter_version: str
    metadata_json: str
    captured_at: datetime


class SchemaMigration(Model):
    __columns__ = ("id", "version", "name", "applied_at")
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "version": "INTEGER",
        "name": "TEXT",
        "applied_at": "TEXT",
    }
    __defaults__ = {"id": None}
    __factories__ = {"applied_at": _now}

    id: Optional[int]
    version: int
    name: str
    applied_at: datetime


class ScanJob(Model):
    __columns__ = (
        "id",
        "case_name",
        "target",
        "module",
        "status",
        "total_sources",
        "completed_sources",
        "current_source",
        "claimed_by",
        "claimed_at",
        "heartbeat_at",
        "progress",
        "cancel_requested",
        "max_retries",
        "rate_limit_budget_json",
        "resume",
        "error",
        "created_at",
        "updated_at",
        "finished_at",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "case_name": "TEXT",
        "target": "TEXT",
        "module": "TEXT",
        "status": "TEXT",
        "total_sources": "INTEGER",
        "completed_sources": "INTEGER",
        "current_source": "TEXT",
        "claimed_by": "TEXT",
        "claimed_at": "TEXT",
        "heartbeat_at": "TEXT",
        "progress": "REAL",
        "cancel_requested": "INTEGER",
        "max_retries": "INTEGER",
        "rate_limit_budget_json": "TEXT",
        "resume": "INTEGER",
        "error": "TEXT",
        "created_at": "TEXT",
        "updated_at": "TEXT",
        "finished_at": "TEXT",
    }
    __defaults__ = {
        "id": None,
        "status": "queued",
        "total_sources": 0,
        "completed_sources": 0,
        "current_source": "",
        "claimed_by": "",
        "claimed_at": None,
        "heartbeat_at": None,
        "progress": 0.0,
        "cancel_requested": False,
        "max_retries": 1,
        "rate_limit_budget_json": "{}",
        "resume": False,
        "error": "",
        "finished_at": None,
    }
    __factories__ = {"created_at": _now, "updated_at": _now}

    id: Optional[int]
    case_name: str
    target: str
    module: str
    status: str
    total_sources: int
    completed_sources: int
    current_source: str
    claimed_by: str
    claimed_at: Optional[datetime]
    heartbeat_at: Optional[datetime]
    progress: float
    cancel_requested: bool
    max_retries: int
    rate_limit_budget_json: str
    resume: bool
    error: str
    created_at: datetime
    updated_at: datetime
    finished_at: Optional[datetime]


class ScanJobEvent(Model):
    __columns__ = (
        "id",
        "job_id",
        "kind",
        "source",
        "status",
        "message",
        "progress",
        "attempt",
        "budget_remaining",
        "created_at",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "job_id": "INTEGER",
        "kind": "TEXT",
        "source": "TEXT",
        "status": "TEXT",
        "message": "TEXT",
        "progress": "REAL",
        "attempt": "INTEGER",
        "budget_remaining": "INTEGER",
        "created_at": "TEXT",
    }
    __defaults__ = {
        "id": None,
        "source": "",
        "status": "",
        "message": "",
        "progress": 0.0,
        "attempt": 0,
        "budget_remaining": None,
    }
    __factories__ = {"created_at": _now}

    id: Optional[int]
    job_id: int
    kind: str
    source: str
    status: str
    message: str
    progress: float
    attempt: int
    budget_remaining: Optional[int]
    created_at: datetime


class AnalystNote(Model):
    __columns__ = (
        "id",
        "case_id",
        "entity_type",
        "entity_value",
        "note",
        "created_at",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "case_id": "INTEGER",
        "entity_type": "TEXT",
        "entity_value": "TEXT",
        "note": "TEXT",
        "created_at": "TEXT",
    }
    __defaults__ = {"id": None}
    __factories__ = {"created_at": _now}

    id: Optional[int]
    case_id: int
    entity_type: str
    entity_value: str
    note: str
    created_at: datetime


class LiveValidationResult(Model):
    __columns__ = (
        "id",
        "run_id",
        "source_id",
        "name",
        "mode",
        "target",
        "status",
        "reason",
        "verification_status",
        "health_status",
        "network_required",
        "allow_opt_in",
        "checks_json",
        "errors_json",
        "live_health_json",
        "redacted",
        "recorded_at",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "run_id": "TEXT",
        "source_id": "TEXT",
        "name": "TEXT",
        "mode": "TEXT",
        "target": "TEXT",
        "status": "TEXT",
        "reason": "TEXT",
        "verification_status": "TEXT",
        "health_status": "TEXT",
        "network_required": "INTEGER",
        "allow_opt_in": "INTEGER",
        "checks_json": "TEXT",
        "errors_json": "TEXT",
        "live_health_json": "TEXT",
        "redacted": "INTEGER",
        "recorded_at": "TEXT",
    }
    __defaults__ = {
        "id": None,
        "target": "",
        "reason": "",
        "verification_status": "",
        "health_status": "",
        "network_required": False,
        "allow_opt_in": False,
        "checks_json": "[]",
        "errors_json": "[]",
        "live_health_json": "{}",
        "redacted": False,
    }
    __factories__ = {"recorded_at": _now}

    id: Optional[int]
    run_id: str
    source_id: str
    name: str
    mode: str
    target: str
    status: str
    reason: str
    verification_status: str
    health_status: str
    network_required: bool
    allow_opt_in: bool
    checks_json: str
    errors_json: str
    live_health_json: str
    redacted: bool
    recorded_at: datetime


class LiveValidationAuditEvent(Model):
    __columns__ = (
        "id",
        "action",
        "channel",
        "source_id",
        "run_id",
        "filters_json",
        "export_format",
        "matched",
        "affected",
        "dry_run",
        "applied",
        "output_path",
        "output_sha256",
        "output_bytes",
        "manifest_path",
        "secrets_returned",
        "created_at",
    )
    __types__ = {
        "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
        "action": "TEXT",
        "channel": "TEXT",
        "source_id": "TEXT",
        "run_id": "TEXT",
        "filters_json": "TEXT",
        "export_format": "TEXT",
        "matched": "INTEGER",
        "affected": "INTEGER",
        "dry_run": "INTEGER",
        "applied": "INTEGER",
        "output_path": "TEXT",
        "output_sha256": "TEXT",
        "output_bytes": "INTEGER",
        "manifest_path": "TEXT",
        "secrets_returned": "INTEGER",
        "created_at": "TEXT",
    }
    __defaults__ = {
        "id": None,
        "channel": "core",
        "source_id": "",
        "run_id": "",
        "filters_json": "{}",
        "export_format": "",
        "matched": 0,
        "affected": 0,
        "dry_run": False,
        "applied": False,
        "output_path": "",
        "output_sha256": "",
        "output_bytes": 0,
        "manifest_path": "",
        "secrets_returned": False,
    }
    __factories__ = {"created_at": _now}

    id: Optional[int]
    action: str
    channel: str
    source_id: str
    run_id: str
    filters_json: str
    export_format: str
    matched: int
    affected: int
    dry_run: bool
    applied: bool
    output_path: str
    output_sha256: str
    output_bytes: int
    manifest_path: str
    secrets_returned: bool
    created_at: datetime


ALL_MODELS = (
    Case,
    Entity,
    Source,
    Finding,
    Evidence,
    Relation,
    TimelineEvent,
    Attachment,
    SchemaMigration,
    ScanJob,
    ScanJobEvent,
    AnalystNote,
    LiveValidationResult,
    LiveValidationAuditEvent,
)
