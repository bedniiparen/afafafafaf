from __future__ import annotations

from pathlib import Path

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from ..config import settings


def _sqlite_url(path: Path) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{path.as_posix()}"


def database_url_for_case(case_name: str | None = None) -> str:
    if settings.database_url:
        return settings.database_url
    db_path = settings.db_path(case_name) if case_name else settings.db_dir / "bedniiosint.db"
    return _sqlite_url(db_path)


def _configure_sqlite(engine: Engine) -> None:
    @event.listens_for(engine, "connect")
    def _set_sqlite_pragmas(dbapi_connection, _connection_record) -> None:
        cursor = dbapi_connection.cursor()
        try:
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA busy_timeout=5000")
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.execute("PRAGMA temp_store=MEMORY")
        finally:
            cursor.close()


def get_engine(database_url: str | None = None, *, case_name: str | None = None) -> Engine:
    url = database_url or database_url_for_case(case_name)
    kwargs = {"future": True}
    if url.startswith("sqlite:///"):
        kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30.0}
    engine = create_engine(url, **kwargs)
    if url.startswith("sqlite:///"):
        _configure_sqlite(engine)
    return engine


def get_sessionmaker(
    database_url: str | None = None,
    *,
    case_name: str | None = None,
) -> sessionmaker[Session]:
    engine = get_engine(database_url, case_name=case_name)
    return sessionmaker(engine, expire_on_commit=False, future=True)
