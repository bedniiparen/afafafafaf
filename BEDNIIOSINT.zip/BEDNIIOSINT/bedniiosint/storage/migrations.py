from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from .models import (
    ALL_MODELS,
    AnalystNote,
    Attachment,
    Case,
    Entity,
    Evidence,
    Finding,
    LiveValidationAuditEvent,
    LiveValidationResult,
    Relation,
    ScanJob,
    ScanJobEvent,
    SchemaMigration,
    Source,
    TimelineEvent,
)


LATEST_SCHEMA_VERSION = 8


@dataclass(frozen=True)
class Migration:
    version: int
    name: str
    apply: Callable[[sqlite3.Connection, tuple], None]


def quote(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute(
        "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?",
        (table,),
    ).fetchone()
    return row is not None


def _table_columns(conn: sqlite3.Connection, table: str) -> set[str]:
    if not _table_exists(conn, table):
        return set()
    return {row["name"] for row in conn.execute(f"PRAGMA table_info({quote(table)})")}


def ensure_table(conn: sqlite3.Connection, model) -> None:
    columns = [
        f"{quote(name)} {model.__types__[name]}" for name in model.__columns__
    ]
    table = model.table_name()
    conn.execute(
        f"CREATE TABLE IF NOT EXISTS {quote(table)} "
        f"({', '.join(columns)})"
    )
    existing = _table_columns(conn, table)
    for name in model.__columns__:
        if name in existing or name == "id":
            continue
        conn.execute(
            f"ALTER TABLE {quote(table)} ADD COLUMN {quote(name)} "
            f"{model.__types__[name]}"
        )


def ensure_models(conn: sqlite3.Connection, models: tuple) -> None:
    for model in models:
        ensure_table(conn, model)


def ensure_indexes(conn: sqlite3.Connection, indexes: tuple) -> None:
    for name, table, columns in indexes:
        if not _table_exists(conn, table):
            continue
        conn.execute(
            f"CREATE INDEX IF NOT EXISTS {quote(name)} ON {quote(table)} "
            f"({', '.join(quote(column) for column in columns)})"
        )


def ensure_schema_migration_table(conn: sqlite3.Connection) -> None:
    ensure_table(conn, SchemaMigration)


def _applied_versions(conn: sqlite3.Connection) -> set[int]:
    ensure_schema_migration_table(conn)
    rows = conn.execute(
        f"SELECT version FROM {quote(SchemaMigration.table_name())}"
    ).fetchall()
    return {int(row["version"]) for row in rows}


def _record(conn: sqlite3.Connection, migration: Migration) -> None:
    exists = conn.execute(
        f"SELECT id FROM {quote(SchemaMigration.table_name())} WHERE version = ?",
        (migration.version,),
    ).fetchone()
    if exists:
        return
    conn.execute(
        f"INSERT INTO {quote(SchemaMigration.table_name())} "
        "(version, name, applied_at) VALUES (?, ?, ?)",
        (migration.version, migration.name, datetime.now(timezone.utc).isoformat()),
    )


def _migration_1(conn: sqlite3.Connection, indexes: tuple) -> None:
    ensure_models(
        conn,
        (
            Case,
            Entity,
            Source,
            Finding,
            Evidence,
            Relation,
            TimelineEvent,
            Attachment,
        ),
    )
    ensure_indexes(conn, indexes)


def _migration_2(conn: sqlite3.Connection, indexes: tuple) -> None:
    ensure_models(conn, (Source, Finding, Evidence, Attachment))
    ensure_indexes(conn, indexes)


def _migration_3(conn: sqlite3.Connection, indexes: tuple) -> None:
    ensure_models(conn, (Relation, TimelineEvent, AnalystNote))
    ensure_indexes(conn, indexes)


def _migration_4(conn: sqlite3.Connection, indexes: tuple) -> None:
    ensure_models(conn, ALL_MODELS)
    ensure_indexes(conn, indexes)


def _migration_5(conn: sqlite3.Connection, indexes: tuple) -> None:
    ensure_models(conn, (ScanJob,))
    ensure_indexes(conn, indexes)


def _migration_6(conn: sqlite3.Connection, indexes: tuple) -> None:
    ensure_models(conn, (LiveValidationResult,))
    ensure_indexes(conn, indexes)


def _migration_7(conn: sqlite3.Connection, indexes: tuple) -> None:
    ensure_models(conn, (LiveValidationAuditEvent,))
    ensure_indexes(conn, indexes)


def _migration_8(conn: sqlite3.Connection, indexes: tuple) -> None:
    ensure_models(conn, (LiveValidationAuditEvent,))
    ensure_indexes(conn, indexes)


MIGRATIONS: tuple[Migration, ...] = (
    Migration(1, "initial case graph storage", _migration_1),
    Migration(2, "forensic evidence and source reliability fields", _migration_2),
    Migration(3, "case workspace notes, timeline and manual graph workflow", _migration_3),
    Migration(4, "job queue, plugin state and pipeline evidence fields", _migration_4),
    Migration(5, "job worker heartbeat and stale claim recovery", _migration_5),
    Migration(6, "live validation result persistence", _migration_6),
    Migration(7, "live validation audit events", _migration_7),
    Migration(8, "live validation export hash manifests", _migration_8),
)


def apply_migrations(conn: sqlite3.Connection, indexes: tuple) -> list[Migration]:
    conn.row_factory = sqlite3.Row
    ensure_schema_migration_table(conn)
    applied = _applied_versions(conn)
    executed: list[Migration] = []
    for migration in MIGRATIONS:
        if migration.version in applied:
            continue
        migration.apply(conn, indexes)
        _record(conn, migration)
        executed.append(migration)
    ensure_models(conn, ALL_MODELS)
    ensure_indexes(conn, indexes)
    return executed


def migration_status(conn: sqlite3.Connection) -> dict:
    conn.row_factory = sqlite3.Row
    ensure_schema_migration_table(conn)
    rows = conn.execute(
        f"SELECT version, name, applied_at FROM {quote(SchemaMigration.table_name())} "
        "ORDER BY version"
    ).fetchall()
    applied_versions = {int(row["version"]) for row in rows}
    return {
        "current_version": max(applied_versions) if applied_versions else 0,
        "latest_version": LATEST_SCHEMA_VERSION,
        "applied": [
            {
                "version": int(row["version"]),
                "name": row["name"],
                "applied_at": row["applied_at"],
            }
            for row in rows
        ],
        "pending": [
            {"version": migration.version, "name": migration.name}
            for migration in MIGRATIONS
            if migration.version not in applied_versions
        ],
    }
