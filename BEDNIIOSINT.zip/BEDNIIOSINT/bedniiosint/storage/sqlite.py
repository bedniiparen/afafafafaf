from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.exc import InvalidRequestError
from sqlalchemy.orm import Session as ORMSession

from .models import BOOLEAN_COLUMNS, DATETIME_COLUMNS, Model
from .migrations import LATEST_SCHEMA_VERSION, apply_migrations
from .sqlalchemy_schema import STORAGE_METADATA


SCHEMA_VERSION = LATEST_SCHEMA_VERSION

INDEXES = (
    ("idx_case_name", "case", ("name",)),
    ("idx_entity_case_type_value", "entity", ("case_id", "type", "value")),
    ("idx_source_case_source_id", "source", ("case_id", "source_id")),
    ("idx_finding_case_source", "finding", ("case_id", "source_name")),
    ("idx_finding_case_source_id", "finding", ("case_id", "source_id")),
    ("idx_finding_case_entity", "finding", ("case_id", "entity_type", "entity_value")),
    ("idx_finding_case_status_confidence", "finding", ("case_id", "status", "confidence")),
    ("idx_evidence_case_finding", "evidence", ("case_id", "finding_id")),
    ("idx_relation_case_src_dst", "relation", ("case_id", "src_type", "src_value", "dst_type", "dst_value")),
    ("idx_timeline_case_when", "timelineevent", ("case_id", "when")),
    ("idx_timeline_case_kind", "timelineevent", ("case_id", "kind")),
    ("idx_attachment_case_finding", "attachment", ("case_id", "finding_id")),
    ("idx_scanjob_status", "scanjob", ("status",)),
    ("idx_scanjob_case", "scanjob", ("case_name",)),
    ("idx_scanjobevent_job", "scanjobevent", ("job_id", "created_at")),
    ("idx_note_case_entity", "analystnote", ("case_id", "entity_type", "entity_value")),
    ("idx_livevalidation_source", "livevalidationresult", ("source_id", "recorded_at")),
    ("idx_livevalidation_run", "livevalidationresult", ("run_id", "status")),
    ("idx_livevalidationaudit_action", "livevalidationauditevent", ("action", "created_at")),
    ("idx_livevalidationaudit_run", "livevalidationauditevent", ("run_id", "source_id")),
)


def _connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, check_same_thread=False, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA temp_store=MEMORY")
    return conn


def sqlalchemy_engine(db_path: Path) -> Engine:
    engine = create_engine(
        f"sqlite:///{db_path.as_posix()}",
        connect_args={"check_same_thread": False, "timeout": 30.0},
        future=True,
    )

    @event.listens_for(engine, "connect")
    def _configure_sqlite(dbapi_connection, _connection_record) -> None:
        cursor = dbapi_connection.cursor()
        try:
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA busy_timeout=5000")
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.execute("PRAGMA temp_store=MEMORY")
        finally:
            cursor.close()

    return engine


def _table(model: type[Model]):
    return STORAGE_METADATA.tables[model.table_name()]


def _to_db(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, bool):
        return int(value)
    return value


def _from_db(model: type[Model], name: str, value: Any) -> Any:
    if value is None:
        return None
    default = model.__defaults__.get(name)
    factory = model.__factories__.get(name)
    sample = default if default is not None else factory() if factory else None
    if isinstance(sample, datetime) or name in DATETIME_COLUMNS:
        try:
            return datetime.fromisoformat(value)
        except (TypeError, ValueError):
            return value
    if isinstance(sample, bool) or name in BOOLEAN_COLUMNS:
        return bool(value)
    return value


class Session:
    def __init__(self, db_path: Path):
        self.engine = sqlalchemy_engine(db_path)
        self._session = ORMSession(self.engine, expire_on_commit=False, future=True)
        self.conn = self._session.connection().connection.driver_connection

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        try:
            if exc_type is None:
                self.commit()
            else:
                self._session.rollback()
        finally:
            self._session.close()
            self.engine.dispose()

    def add(self, obj: Model) -> None:
        self._session.add(obj)
        self._session.flush()

    def update(self, obj: Model) -> None:
        obj_id = getattr(obj, "id", None)
        if obj_id is None:
            raise ValueError("cannot update object without id")
        self._session.merge(obj)
        self._session.flush()

    def delete(self, obj: Model) -> None:
        obj_id = getattr(obj, "id", None)
        if obj_id is None:
            raise ValueError("cannot delete object without id")
        attached = self._session.merge(obj)
        self._session.delete(attached)
        self._session.flush()

    def commit(self) -> None:
        self._session.commit()

    def refresh(self, obj: Model) -> None:
        obj_id = getattr(obj, "id", None)
        if obj_id is None:
            return
        try:
            self._session.refresh(obj)
            return
        except InvalidRequestError:
            row = self._session.get(obj.__class__, obj_id)
        if row is None:
            return
        for name in obj.__columns__:
            setattr(obj, name, getattr(row, name))

    def query(self, model: type[Model]):
        return self._session.query(model)


class Storage:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = _connect(self.db_path)
        try:
            apply_migrations(conn, INDEXES)
            conn.commit()
        finally:
            conn.close()

    def session(self) -> Session:
        return Session(self.db_path)
