from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable

CATALOG_PATH = Path(__file__).with_name("osint_sources.json")


@lru_cache(maxsize=1)
def load_catalog(path: str | Path | None = None) -> dict[str, Any]:
    catalog_path = Path(path) if path else CATALOG_PATH
    return json.loads(catalog_path.read_text(encoding="utf-8"))


def _matches(values: Iterable[str], expected: str | None) -> bool:
    if expected is None:
        return True
    expected = expected.lower()
    return any(str(value).lower() == expected for value in values)


def iter_apis(
    catalog: dict[str, Any] | None = None,
    *,
    input_type: str | None = None,
    category: str | None = None,
    auth: str | None = None,
) -> list[dict[str, Any]]:
    data = catalog or load_catalog()
    rows = []
    for api in data.get("api_sources", []):
        if not _matches(api.get("inputs", []), input_type):
            continue
        if not _matches(api.get("category", []), category):
            continue
        if auth is not None and str(api.get("auth", "")).lower() != auth.lower():
            continue
        rows.append(api)
    return rows


def endpoint_index(catalog: dict[str, Any] | None = None) -> list[dict[str, str]]:
    data = catalog or load_catalog()
    endpoints: list[dict[str, str]] = []
    for api in data.get("api_sources", []):
        for endpoint in api.get("endpoints", []):
            endpoints.append(
                {
                    "source": api["id"],
                    "name": api["name"],
                    "method": endpoint.get("method", "GET"),
                    "url": api.get("base_url", "").rstrip("/")
                    + endpoint.get("path", ""),
                    "auth": api.get("auth", ""),
                    "inputs": ",".join(api.get("inputs", [])),
                }
            )
    return endpoints


def catalog_summary(catalog: dict[str, Any] | None = None) -> dict[str, Any]:
    data = catalog or load_catalog()
    apis = data.get("api_sources", [])
    projects = data.get("project_patterns", [])
    categories = sorted({cat for api in apis for cat in api.get("category", [])})
    inputs = sorted({item for api in apis for item in api.get("inputs", [])})
    auth_modes = sorted({api.get("auth", "unknown") for api in apis})
    return {
        "api_sources": len(apis),
        "endpoints": len(endpoint_index(data)),
        "projects_studied": len(projects),
        "categories": categories,
        "inputs": inputs,
        "auth_modes": auth_modes,
    }
