from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .adapters import AdapterResult, CatalogResponseParser
from .health import SourceHealth, adapter_health, source_health
from .policy import policy_for_source
from .parsers import parse_specialized
from .registry import SourceEntry, filter_registry, registry_entries
from .source_catalog import load_catalog


PASSED_LIVE_STATUSES = {"available", "degraded"}
QUALITY_VARIANTS = ("ok", "rate_limited", "http_error", "schema_changed", "not_found")


@dataclass(frozen=True)
class SourceVerification:
    source_id: str
    name: str
    mode: str
    status: str
    reason: str
    checks: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    health_status: str = ""
    verification_status: str = ""
    contract_gaps: list[str] = field(default_factory=list)
    fixture_path: str = ""
    fixture_variant: str = ""
    normalized_counts: dict[str, int] = field(default_factory=dict)
    live_health: dict[str, Any] = field(default_factory=dict)
    target: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "name": self.name,
            "mode": self.mode,
            "status": self.status,
            "reason": self.reason,
            "checks": self.checks,
            "errors": self.errors,
            "health_status": self.health_status,
            "verification_status": self.verification_status,
            "contract_gaps": self.contract_gaps,
            "fixture_path": self.fixture_path,
            "fixture_variant": self.fixture_variant,
            "normalized_counts": self.normalized_counts,
            "live_health": self.live_health,
            "target": self.target,
        }


def verify_sources(
    *,
    mode: str = "contract",
    source_id: str | None = None,
    input_type: str | None = None,
    kind: str | None = None,
    runnable: bool | None = None,
    target: str | None = None,
    fixture_dir: Path | None = None,
    fixture_name: str = "ok",
    plugin_dir=None,
    allow_opt_in: bool = False,
    entries: list[SourceEntry] | None = None,
) -> dict[str, Any]:
    """Verify source registry readiness without requiring network by default."""
    mode = mode.lower().strip().replace("-", "_")
    if mode not in {"contract", "fixture", "live_plan", "live"}:
        raise ValueError("mode must be one of: contract, fixture, live-plan, live")

    rows = filter_registry(
        entries or registry_entries(plugin_dir=plugin_dir),
        input_type=input_type,
        kind=kind,
        runnable=runnable,
    )
    if source_id:
        needle = _normalize_source_id(source_id)
        rows = [row for row in rows if _normalize_source_id(row.id) == needle]
    health_by_id = {row.source_id: row for row in source_health(rows)}
    api_by_id = {
        f"api:{api['id']}": api
        for api in load_catalog().get("api_sources", [])
    }

    results = []
    for row in rows:
        health = health_by_id[row.id]
        if mode == "contract":
            results.append(_verify_contract(row, health))
        elif mode == "fixture":
            results.append(_verify_fixture(row, health, api_by_id.get(row.id), fixture_dir, fixture_name))
        elif mode == "live_plan":
            results.append(_verify_live_plan(row, health))
        else:
            results.append(_verify_live(row, health, target=target, plugin_dir=plugin_dir, allow_opt_in=allow_opt_in))

    payload = [row.as_dict() for row in results]
    summary = verification_summary(payload)
    if mode == "fixture":
        summary["fixture_coverage"] = fixture_coverage(
            fixture_dir=fixture_dir,
            entries=rows,
            fixture_name=fixture_name,
        )
    return {"summary": summary, "results": payload}


def verification_summary(results: list[dict[str, Any]]) -> dict[str, Any]:
    statuses: dict[str, int] = {}
    for row in results:
        status = str(row.get("status") or "unknown")
        statuses[status] = statuses.get(status, 0) + 1
    return {
        "sources": len(results),
        "passed": statuses.get("passed", 0),
        "failed": statuses.get("failed", 0),
        "skipped": statuses.get("skipped", 0),
        "statuses": dict(sorted(statuses.items())),
    }


def fixture_coverage(
    *,
    fixture_dir: Path | None,
    entries: list[SourceEntry] | None = None,
    fixture_name: str = "ok",
) -> dict[str, Any]:
    rows = [row for row in (entries or registry_entries()) if row.kind == "api"]
    fixture_ids = _fixture_ids(fixture_dir, fixture_name=fixture_name)
    covered = []
    missing = []
    typed_missing = []
    for row in rows:
        short_id = _short_source_id(row.id)
        if short_id in fixture_ids:
            covered.append(row.id)
        else:
            missing.append(row.id)
            if row.source_maturity == "typed_parser":
                typed_missing.append(row.id)
    total = len(rows)
    return {
        "api_sources": total,
        "fixture_name": fixture_name,
        "fixture_sources": len(covered),
        "coverage": round(len(covered) / total, 3) if total else 0.0,
        "covered": sorted(covered),
        "missing": sorted(missing),
        "typed_missing": sorted(typed_missing),
    }


def source_quality_gate(
    *,
    fixture_dir: Path | None,
    source_id: str | None = None,
    priority: str | None = None,
    strict: bool = False,
    entries: list[SourceEntry] | None = None,
) -> dict[str, Any]:
    rows = [row for row in (entries or registry_entries()) if row.kind == "api"]
    if source_id:
        needle = _normalize_source_id(source_id)
        rows = [row for row in rows if _normalize_source_id(row.id) == needle]
    if priority:
        wanted = priority.strip().upper()
        rows = [row for row in rows if str(row.priority or "").upper() == wanted]

    health_by_id = {row.source_id: row for row in source_health(rows)}
    results = [
        _quality_gate_row(row, health_by_id[row.id], fixture_dir=fixture_dir, strict=strict)
        for row in rows
    ]
    statuses: dict[str, int] = {}
    for row in results:
        status = str(row["status"])
        statuses[status] = statuses.get(status, 0) + 1
    return {
        "summary": {
            "sources": len(results),
            "passed": statuses.get("passed", 0),
            "warning": statuses.get("warning", 0),
            "failed": statuses.get("failed", 0),
            "strict": strict,
            "statuses": dict(sorted(statuses.items())),
        },
        "results": results,
    }


def _quality_gate_row(
    row: SourceEntry,
    health: SourceHealth,
    *,
    fixture_dir: Path | None,
    strict: bool,
) -> dict[str, Any]:
    short_id = _short_source_id(row.id)
    policy = policy_for_source(short_id, name=row.name)
    fixture_variants = _available_fixture_variants(fixture_dir, short_id)
    required_failures: list[str] = []
    warnings_: list[str] = []
    checks = {
        "docs_url": bool(row.docs_url),
        "policy": policy is not None,
        "legal_risk": bool(row.terms_risk),
        "cache_policy": bool(row.cache_policy),
        "quota_policy": bool(row.quota_policy),
        "env_mapping": bool(row.env_vars) or row.auth.lower() in {"none", "", "optional"},
        "typed_or_explicit_generic": row.source_maturity in {"typed_parser", "generic_http", "catalog_only"},
        "ok_fixture": "ok" in fixture_variants,
        "error_variant_fixture": bool({"rate_limited", "http_error", "schema_changed", "not_found"} & set(fixture_variants)),
    }

    if health.contract_gaps:
        required_failures.extend(health.contract_gaps)
    if not checks["docs_url"]:
        required_failures.append("missing docs_url")
    if not checks["policy"]:
        warnings_.append("missing policy catalog entry")
    if not checks["legal_risk"]:
        required_failures.append("missing legal risk")
    if not checks["cache_policy"]:
        required_failures.append("missing cache policy")
    if not checks["quota_policy"]:
        required_failures.append("missing quota policy")
    if row.auth.lower() not in {"none", "", "optional"} and not row.env_vars:
        required_failures.append("missing env var mapping")
    if not checks["ok_fixture"]:
        required_failures.append("missing ok fixture")
    if row.runnable and row.source_maturity != "typed_parser":
        warnings_.append(f"runnable source is {row.source_maturity}, not typed_parser")
    if not checks["error_variant_fixture"]:
        warnings_.append("missing error/rate-limit/schema fixture variant")

    status = "failed" if required_failures or (strict and warnings_) else "warning" if warnings_ else "passed"
    return {
        "source_id": row.id,
        "name": row.name,
        "priority": row.priority,
        "status": status,
        "checks": checks,
        "required_failures": required_failures,
        "warnings": warnings_,
        "fixture_variants": fixture_variants,
        "docs_url": row.docs_url,
        "terms_risk": row.terms_risk,
        "cache_policy": row.cache_policy,
        "quota_policy": row.quota_policy,
        "source_maturity": row.source_maturity,
        "verification_status": health.verification_status,
    }


def _verify_contract(row: SourceEntry, health: SourceHealth) -> SourceVerification:
    errors = list(health.contract_gaps)
    checks = [
        "registry entry loaded",
        "input types present" if row.inputs else "input types missing",
        "output schema present" if row.output_schema else "output schema missing",
    ]
    if row.kind == "api":
        checks.append("official docs URL present" if row.docs_url else "official docs URL missing")
        checks.append("endpoint metadata present" if row.endpoints else "endpoint metadata missing")
    status = "failed" if errors else "passed"
    reason = "contract gaps found" if errors else "source contract metadata is complete"
    return SourceVerification(
        source_id=row.id,
        name=row.name,
        mode="contract",
        status=status,
        reason=reason,
        checks=checks,
        errors=errors,
        health_status=health.status,
        verification_status=health.verification_status,
        contract_gaps=health.contract_gaps,
    )


def _verify_fixture(
    row: SourceEntry,
    health: SourceHealth,
    source: dict[str, Any] | None,
    fixture_dir: Path | None,
    fixture_name: str,
) -> SourceVerification:
    if row.kind != "api" or source is None:
        return _skipped(row, health, "fixtures are only defined for API catalog sources", "fixture")
    if health.contract_gaps:
        return SourceVerification(
            source_id=row.id,
            name=row.name,
            mode="fixture",
            status="failed",
            reason="contract gaps must be fixed before fixture verification",
            errors=list(health.contract_gaps),
            health_status=health.status,
            verification_status=health.verification_status,
            contract_gaps=health.contract_gaps,
        )
    if fixture_dir is None:
        return _skipped(row, health, "fixture directory was not provided", "fixture")
    path = fixture_dir / _short_source_id(row.id) / f"{fixture_name}.json"
    if not path.exists():
        return _skipped(row, health, "fixture file is missing", "fixture", fixture_path=str(path))
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        fixture_text = ""
        status_code = 200
        fixture_status = "ok"
        expected = "ok"
        fixture_input_type = ""
        fixture_target = ""
        if isinstance(data, dict) and "__text" in data:
            fixture_input_type = str(data.get("__input_type") or "")
            fixture_target = str(data.get("__target") or "")
            fixture_text = str(data.get("__text") or "")
            status_code = int(data.get("__status_code") or 200)
            fixture_status = str(data.get("__status") or ("error" if status_code >= 400 else "ok"))
            expected = str(data.get("__expect") or expected)
            data = data.get("__data")
        elif isinstance(data, dict) and any(key in data for key in ("__data", "__status_code", "__status", "__expect")):
            fixture_input_type = str(data.get("__input_type") or "")
            fixture_target = str(data.get("__target") or "")
            status_code = int(data.get("__status_code") or 200)
            fixture_status = str(data.get("__status") or ("error" if status_code >= 400 else "ok"))
            expected = str(data.get("__expect") or expected)
            data = data.get("__data")
        input_type = fixture_input_type or (row.inputs[0] if row.inputs else "target")
        result = AdapterResult(
            source_id=row.id,
            target=fixture_target or _probe_target(input_type),
            status=fixture_status,
            input_type=input_type,
            status_code=status_code,
            data=data,
            text=fixture_text,
        )
        normalized = parse_specialized(source, result)
        if normalized is None:
            normalized = CatalogResponseParser(source).parse(result).as_dict()
        counts = {
            key: len(normalized.get(key, []))
            for key in ("entities", "relations", "findings", "timeline")
        }
        errors = []
        if expected == "ok" and not any(counts.values()):
            errors.append("fixture parser produced no normalized rows")
        if expected in {"http_error", "rate_limited", "schema_changed"}:
            high_confidence = [
                row
                for row in normalized.get("findings", [])
                if float(row.get("confidence") or 0.0) > 0
            ]
            if high_confidence:
                errors.append(f"{expected} fixture produced positive-confidence findings")
        return SourceVerification(
            source_id=row.id,
            name=row.name,
            mode="fixture",
            status="failed" if errors else "passed",
            reason="fixture parsed successfully" if not errors else "fixture parser produced empty output",
            checks=["fixture file loaded", "parser executed", "normalized output counted"],
            errors=errors,
            health_status=health.status,
            verification_status=health.verification_status,
            contract_gaps=health.contract_gaps,
            fixture_path=str(path),
            fixture_variant=fixture_name,
            normalized_counts=counts,
        )
    except Exception as exc:
        return SourceVerification(
            source_id=row.id,
            name=row.name,
            mode="fixture",
            status="failed",
            reason="fixture verification failed",
            checks=["fixture file loaded"],
            errors=[str(exc)],
            health_status=health.status,
            verification_status=health.verification_status,
            contract_gaps=health.contract_gaps,
            fixture_path=str(path),
            fixture_variant=fixture_name,
        )


def _verify_live_plan(row: SourceEntry, health: SourceHealth) -> SourceVerification:
    errors = []
    reason = "source is ready for live adapter health probe"
    status = "passed"
    checks = ["no network call performed", "live prerequisites evaluated"]
    if health.contract_gaps:
        status = "failed"
        reason = "contract gaps must be fixed before live verification"
        errors = list(health.contract_gaps)
    elif not row.runnable:
        status = "skipped"
        reason = "source is not runnable"
    elif health.missing_env and health.auth_required:
        status = "skipped"
        reason = "required API keys are missing"
    elif row.requires_opt_in:
        status = "skipped"
        reason = "source requires explicit legal/privacy opt-in"
    return SourceVerification(
        source_id=row.id,
        name=row.name,
        mode="live_plan",
        status=status,
        reason=reason,
        checks=checks,
        errors=errors,
        health_status=health.status,
        verification_status=health.verification_status,
        contract_gaps=health.contract_gaps,
    )


def _verify_live(
    row: SourceEntry,
    health: SourceHealth,
    *,
    target: str | None,
    plugin_dir=None,
    allow_opt_in: bool,
) -> SourceVerification:
    if health.contract_gaps:
        return _skipped(row, health, "contract gaps must be fixed before live verification", "live")
    if not row.runnable:
        return _skipped(row, health, "source is not runnable", "live")
    if health.missing_env and health.auth_required:
        return _skipped(row, health, "required API keys are missing", "live")
    if row.requires_opt_in and not allow_opt_in:
        return _skipped(row, health, "source requires explicit legal/privacy opt-in", "live")
    probe = target or _probe_target(row.inputs[0] if row.inputs else "target")
    try:
        live = adapter_health(row.id, target=probe, plugin_dir=plugin_dir)
        status = str(live.get("status") or "")
        passed = status in PASSED_LIVE_STATUSES
        return SourceVerification(
            source_id=row.id,
            name=row.name,
            mode="live",
            status="passed" if passed else "failed",
            reason="live adapter health check passed" if passed else "live adapter health check failed",
            checks=["adapter health_check executed"],
            errors=[] if passed else [str(live.get("error") or status)],
            health_status=health.status,
            verification_status=health.verification_status,
            contract_gaps=health.contract_gaps,
            live_health=live,
            target=probe,
        )
    except Exception as exc:
        return SourceVerification(
            source_id=row.id,
            name=row.name,
            mode="live",
            status="failed",
            reason="live verification raised an exception",
            checks=["adapter health_check attempted"],
            errors=[str(exc)],
            health_status=health.status,
            verification_status=health.verification_status,
            contract_gaps=health.contract_gaps,
            target=probe,
        )


def _skipped(
    row: SourceEntry,
    health: SourceHealth,
    reason: str,
    mode: str,
    *,
    fixture_path: str = "",
) -> SourceVerification:
    return SourceVerification(
        source_id=row.id,
        name=row.name,
        mode=mode,
        status="skipped",
        reason=reason,
        health_status=health.status,
        verification_status=health.verification_status,
        contract_gaps=health.contract_gaps,
        fixture_path=fixture_path,
    )


def _normalize_source_id(source_id: str) -> str:
    return source_id.lower().removeprefix("api:").removeprefix("module:").removeprefix("plugin:")


def _short_source_id(source_id: str) -> str:
    return source_id.split(":", 1)[-1]


def _fixture_ids(fixture_dir: Path | None, *, fixture_name: str = "ok") -> set[str]:
    if fixture_dir is None or not fixture_dir.exists():
        return set()
    return {
        path.name
        for path in fixture_dir.iterdir()
        if path.is_dir() and (path / f"{fixture_name}.json").exists()
    }


def _available_fixture_variants(fixture_dir: Path | None, short_id: str) -> list[str]:
    if fixture_dir is None:
        return []
    root = fixture_dir / short_id
    if not root.exists() or not root.is_dir():
        return []
    return sorted(path.stem for path in root.glob("*.json") if path.is_file())


def _probe_target(input_type: str) -> str:
    return {
        "address": "1600 Amphitheatre Parkway, Mountain View, CA",
        "asn": "AS15169",
        "company": "Example Inc",
        "document": "example.pdf",
        "domain": "example.com",
        "email": "alice@example.com",
        "hash": "a" * 64,
        "image": "example.jpg",
        "ip": "8.8.8.8",
        "password_hash": "5f4dcc3b5aa765d61d8327deb882cf99",
        "person": "Alice Example",
        "phone": "+15551234567",
        "place": "Berlin",
        "query": "Example Inc",
        "url": "https://example.com/",
        "username": "alice",
        "wallet": "1BoatSLRHtKNngkdXEeobR76b53LETtpyT",
    }.get(input_type, "example.com")
