from __future__ import annotations

import importlib.util
import hashlib
import json
import mimetypes
import string
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlparse

import httpx

from ..core.http import request
from ..core.plugins import PluginManifest, get_plugin_config, get as get_builtin_plugin
from ..core.redaction import redact_value
from ..core.secret_store import missing_secret_names, secret_configured, secret_value, secret_values
from ..core.source_context import SourceBudgetExceeded, SourceRunContext
from .parsers import parse_specialized
from .policy import policy_for_source, risk_for_source
from .source_catalog import load_catalog


AUTH_ENV_HINTS = {
    "abuseipdb": "ABUSEIPDB_API_KEY",
    "alienvault_otx": "ALIENVAULT_OTX_API_KEY",
    "blockchair": "BLOCKCHAIR_API_KEY",
    "companies_house": "COMPANIES_HOUSE_API_KEY",
    "hibp": "HIBP_API_KEY",
    "emailrep": "EMAILREP_API_KEY",
    "greynoise": "GREYNOISE_API_KEY",
    "ipinfo": "IPINFO_TOKEN",
    "numverify": "NUMVERIFY_API_KEY",
    "opencorporates": "OPENCORPORATES_API_TOKEN",
    "securitytrails": "SECURITYTRAILS_API_KEY",
    "shodan": "SHODAN_API_KEY",
    "censys": "CENSYS_API_ID,CENSYS_API_SECRET",
    "twilio_lookup": "TWILIO_ACCOUNT_SID,TWILIO_AUTH_TOKEN",
    "tineye": "TINEYE_API_KEY",
    "urlscan": "URLSCAN_API_KEY",
    "veriphone": "VERIPHONE_API_KEY",
    "virustotal": "VIRUSTOTAL_API_KEY",
    "hunter": "HUNTER_API_KEY",
    "github": "GITHUB_TOKEN",
    "github_search": "GITHUB_TOKEN",
    "google_cse": "GOOGLE_CSE_API_KEY,GOOGLE_CSE_CX",
    "open_measures": "OPEN_MEASURES_API_KEY",
    "osintly_api": "OSINTLY_API_KEY",
    "youtube": "YOUTUBE_API_KEY",
}

OPTIONAL_AUTH_MODES = {
    "none",
    "",
    "optional",
    "none_or_api_key",
    "api_key_or_community",
    "optional_api_key",
    "optional_api_token",
    "optional_token",
    "api_key_for_scan",
}

MEDIUM_TERMS_RISK_SOURCE_IDS = {
    "companies_house",
    "emailrep",
    "hibp",
    "hunter",
    "nominatim",
    "open_measures",
    "osintly_api",
    "reddit_about",
    "shodan",
    "twilio_lookup",
    "tineye",
    "urlscan",
}
MAX_DIRECT_UPLOAD_BYTES = 32 * 1024 * 1024


@dataclass
class NormalizedAdapterOutput:
    entities: list[dict[str, Any]] = field(default_factory=list)
    relations: list[dict[str, Any]] = field(default_factory=list)
    findings: list[dict[str, Any]] = field(default_factory=list)
    timeline: list[dict[str, Any]] = field(default_factory=list)
    raw: Any = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "entities": self.entities,
            "relations": self.relations,
            "findings": self.findings,
            "timeline": self.timeline,
            "raw": self.raw,
        }


@dataclass
class AdapterHealth:
    source_id: str
    status: str
    checked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    status_code: int | None = None
    latency_ms: int | None = None
    error: str = ""
    missing_env: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "status": self.status,
            "checked_at": self.checked_at,
            "status_code": self.status_code,
            "latency_ms": self.latency_ms,
            "error": self.error,
            "missing_env": self.missing_env,
        }


class AdapterParser(Protocol):
    def parse(self, result: "AdapterResult") -> NormalizedAdapterOutput:
        ...


class ExecutableAdapter(Protocol):
    source_id: str

    def schema(self) -> dict[str, Any]:
        ...

    def run(self, target: str, **kwargs: Any) -> "AdapterResult":
        ...

    def health_check(self, **kwargs: Any) -> AdapterHealth:
        ...


@dataclass
class AdapterResult:
    source_id: str
    target: str
    status: str
    input_type: str = ""
    method: str = "GET"
    url: str = ""
    status_code: int | None = None
    data: Any = None
    text: str = ""
    error: str = ""
    headers: dict[str, Any] = field(default_factory=dict)
    missing_env: list[str] = field(default_factory=list)
    normalized: dict[str, Any] | None = None
    cache_hit: bool = False

    def as_dict(self) -> dict[str, Any]:
        return redact_value({
            "source_id": self.source_id,
            "target": self.target,
            "status": self.status,
            "input_type": self.input_type,
            "method": self.method,
            "url": self.url,
            "status_code": self.status_code,
            "data": self.data,
            "text": self.text,
            "error": self.error,
            "headers": self.headers,
            "missing_env": self.missing_env,
            "normalized": self.normalized,
            "cache_hit": self.cache_hit,
        })


def auth_env_vars(source_id: str, auth: str) -> list[str]:
    if auth in {"none", "", None}:
        return []
    direct = AUTH_ENV_HINTS.get(source_id.lower())
    if direct:
        return [item.strip() for item in direct.split(",") if item.strip()]
    normalized = source_id.upper().replace("-", "_")
    return [f"{normalized}_API_KEY"]


def configured(env_vars: list[str]) -> bool:
    return not env_vars or all(secret_configured(name) for name in env_vars)


def _terms_risk(source: dict[str, Any]) -> str:
    source_id = str(source.get("id", "")).lower()
    policy_risk = risk_for_source(source_id, fallback="", name=str(source.get("name", "")))
    if policy_risk:
        return policy_risk
    if source_id in MEDIUM_TERMS_RISK_SOURCE_IDS:
        return "medium"
    auth = str(source.get("auth", "none")).lower()
    if auth not in {"none", "", "optional"}:
        return "medium"
    return "low"


def _auth_missing(env_vars: list[str], auth: str) -> list[str]:
    missing = missing_secret_names(env_vars)
    return [] if auth.lower() in OPTIONAL_AUTH_MODES else missing


def _auth_values(env_vars: list[str]) -> list[str]:
    return secret_values(env_vars)


def _select_endpoint(
    source_id: str,
    endpoints: list[dict[str, Any]],
    selected: str,
) -> dict[str, Any]:
    for endpoint in endpoints:
        if selected in _format_fields(str(endpoint.get("path", ""))):
            return endpoint
    if source_id == "osintly_api":
        for endpoint in endpoints:
            if str(endpoint.get("path", "")).rstrip("/") == "/search":
                return endpoint
    for endpoint in endpoints:
        fields = _format_fields(str(endpoint.get("path", "")))
        if "query" in fields or "q" in fields:
            return endpoint
    for endpoint in endpoints:
        if str(endpoint.get("method", "GET")).upper() in {"POST", "PUT", "PATCH"}:
            return endpoint
    return endpoints[0]


def _auth_request_kwargs(
    source_id: str,
    auth: str,
    env_vars: list[str],
) -> dict[str, Any]:
    values = _auth_values(env_vars)
    key = values[0] if values else ""
    secret = values[1] if len(values) > 1 else ""
    if not key:
        return {}

    headers: dict[str, str] = {}
    params: dict[str, str] = {}
    request_kwargs: dict[str, Any] = {}
    sid = source_id.lower()
    auth_mode = auth.lower()

    if sid == "securitytrails":
        headers["APIKEY"] = key
    elif sid == "google_cse":
        params["key"] = key
        if secret:
            params["cx"] = secret
    elif sid == "youtube":
        params["key"] = key
    elif sid == "virustotal":
        headers["x-apikey"] = key
    elif sid == "abuseipdb":
        headers["Key"] = key
        headers["Accept"] = "application/json"
    elif sid == "alienvault_otx":
        headers["X-OTX-API-KEY"] = key
    elif sid == "greynoise":
        headers["key"] = key
    elif sid == "hibp":
        headers["hibp-api-key"] = key
    elif sid == "emailrep":
        headers["Key"] = key
    elif sid == "urlscan":
        headers["API-Key"] = key
    elif sid == "tineye":
        headers["x-api-key"] = key
    elif sid == "ipinfo":
        params["token"] = key
    elif sid in {"github", "github_search"} or auth_mode in {"bearer_token", "optional_token"}:
        headers["Authorization"] = f"Bearer {key}"
    elif sid == "companies_house":
        request_kwargs["auth"] = (key, "")
    elif auth_mode == "api_key_secret":
        request_kwargs["auth"] = (key, secret)
    elif auth_mode in {"api_key", "optional_api_key", "none_or_api_key", "api_key_or_community"}:
        params["api_key"] = key
    elif auth_mode == "optional_api_token":
        params["api_token"] = key
    elif auth_mode == "api_key_or_account":
        headers["Authorization"] = f"Bearer {key}"

    if headers:
        request_kwargs["headers"] = headers
    if params:
        request_kwargs["params"] = params
    return request_kwargs


def _post_request_kwargs(
    source_id: str,
    method: str,
    selected: str,
    target: str,
    kwargs: dict[str, Any],
) -> dict[str, Any]:
    if method.upper() not in {"POST", "PUT", "PATCH"}:
        return {}
    if any(key in kwargs for key in ("json", "data", "content", "files")):
        return {key: kwargs[key] for key in ("json", "data", "content", "files") if key in kwargs}
    if source_id == "urlhaus":
        field = "url" if selected == "url" else "host"
        return {"data": {field: target}}
    if source_id == "urlscan":
        return {"json": {"url": target, "visibility": kwargs.get("visibility", "unlisted")}}
    if source_id == "virustotal" and selected in {"file", "image", "document"}:
        return _file_upload_request_kwargs(target, provider="VirusTotal")
    if source_id == "tineye" and selected == "image":
        return _image_upload_request_kwargs(target, provider="TinEye", field_name="image_upload")
    if source_id == "osintly_api":
        return {"json": {"target": target, "type": selected}}
    return {"data": {selected: target}}


def _requires_upload_opt_in(source_id: str, method: str, url: str) -> bool:
    sid = source_id.lower()
    if method.upper() not in {"POST", "PUT", "PATCH"}:
        return False
    if sid in {"urlscan", "virustotal", "tineye"}:
        return True
    lowered = url.lower()
    return any(marker in lowered for marker in ("/scan", "/submit", "/upload"))


def _file_upload_request_kwargs(target: str, *, provider: str) -> dict[str, Any]:
    path = Path(target).expanduser()
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"upload file not found: {target}")
    size = path.stat().st_size
    if size > MAX_DIRECT_UPLOAD_BYTES:
        raise ValueError(
            f"{provider} direct upload limit is {MAX_DIRECT_UPLOAD_BYTES} bytes; "
            "use hash lookup or a provider-specific large-file workflow"
        )
    content = path.read_bytes()
    sha256 = hashlib.sha256(content).hexdigest()
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return {
        "files": {"file": (path.name, content, mime)},
        "_bedniiosint_upload": {
            "filename": path.name,
            "size": size,
            "sha256": sha256,
            "mime": mime,
            "privacy_warning": f"file content submitted to third-party provider: {provider}",
        },
    }


def _image_upload_request_kwargs(target: str, *, provider: str, field_name: str) -> dict[str, Any]:
    payload = _file_upload_request_kwargs(target, provider=provider)
    filename, content, mime = payload["files"]["file"]
    payload["files"] = {field_name: (filename, content, mime)}
    return payload


def _requires_sensitive_opt_in(policy, source: dict[str, Any], selected: str) -> bool:
    risk = _terms_risk(source)
    if risk == "high":
        return True
    if not policy or not policy.requires_opt_in:
        return False
    source_id = str(source.get("id", "")).lower()
    if source_id in {"urlscan", "virustotal"}:
        return False
    if selected in {"phone", "person", "image"}:
        return True
    return policy.requires_opt_in


def _merge_request_kwargs(*items: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    for item in items:
        for key, value in item.items():
            if key in {"headers", "params"} and key in merged and isinstance(value, dict):
                merged[key] = {**merged[key], **value}
            else:
                merged[key] = value
    return merged


def _request_with_policy(method: str, url: str, policy=None, **kwargs: Any):
    if policy is None:
        return request(method, url, **kwargs)
    return request(method, url, policy=policy, **kwargs)


def source_schema(source: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    inputs = list(source.get("inputs", []))
    auth = str(source.get("auth", "none"))
    env_vars = auth_env_vars(str(source.get("id", "")), auth)
    input_schema = {
        "target": {"type": "string", "required": True},
        "input_types": inputs,
        "auth": auth,
        "env_vars": env_vars,
        "endpoint_fields": sorted(
            {
                field
                for endpoint in source.get("endpoints", [])
                for field in _format_fields(endpoint.get("path", ""))
            }
        ),
    }
    output_schema = {
        "status": "ok|error|missing_keys",
        "status_code": "integer|null",
        "url": "string",
        "data": "json|null",
        "text": "string",
        "normalized": {
            "entities": "list",
            "relations": "list",
            "findings": "list",
            "timeline": "list",
            "raw": "json|null",
        },
        "categories": list(source.get("category", [])),
    }
    return input_schema, output_schema


def _format_fields(template: str) -> set[str]:
    return {
        field_name
        for _, field_name, _, _ in string.Formatter().parse(template)
        if field_name
    }


def _find_api(source_id: str, catalog: dict[str, Any] | None = None) -> dict[str, Any]:
    source_id = source_id.replace("api:", "").strip().lower()
    data = catalog or load_catalog()
    for api in data.get("api_sources", []):
        if str(api.get("id", "")).lower() == source_id:
            return api
    raise KeyError(f"catalog API source not found: {source_id}")


def _values(target: str, input_type: str, kwargs: dict[str, Any], env_vars: list[str]) -> dict[str, Any]:
    values_from_env = _auth_values(env_vars)
    key = next((value for value in values_from_env if value), "")
    secret = values_from_env[1] if len(values_from_env) > 1 else ""
    instance = kwargs.get("instance", "")
    if not instance and "@" in target and not target.startswith("@"):
        instance = target.rsplit("@", 1)[-1]
    values: dict[str, Any] = {
        "target": target,
        "query": target,
        "q": target,
        "sparql": kwargs.get("sparql", target),
        "domain": target,
        "ip": target,
        "email": target,
        "username": target,
        "handle": target,
        "acct": target,
        "phone": target,
        "wallet": target,
        "image": target,
        "image_url": target,
        "file": target,
        "video": target,
        "btc_address": target,
        "eth_address": target,
        "hash": target,
        "asn": target,
        "company": target,
        "address": target,
        "place": target,
        "instance": instance,
        "record_type": kwargs.get("record_type", "A"),
        "api_key": key,
        "api_token": key,
        "access_key": key,
        "token": key,
        "api_secret": secret,
        "secret": secret,
    }
    values[input_type] = target
    values.update({k: v for k, v in kwargs.items() if v is not None})
    return values


def _probe_target(input_type: str) -> str:
    return {
        "asn": "AS15169",
        "company": "Example Inc",
        "domain": "example.com",
        "email": "test@example.com",
        "hash": "0" * 64,
        "image": "sample.jpg",
        "image_url": "https://example.com/image.jpg",
        "ip": "8.8.8.8",
        "phone": "+15551234567",
        "query": "example",
        "fediverse_account": "alice@example.social",
        "url": "https://example.com/",
        "username": "torvalds",
        "wallet": "1BoatSLRHtKNngkdXEeobR76b53LETtpyT",
    }.get(input_type, "example.com")


def _health_status(status_code: int | None) -> str:
    if status_code is None:
        return "error"
    if status_code == 429:
        return "degraded"
    if status_code in {401, 403}:
        return "missing_keys"
    if status_code >= 500:
        return "error"
    return "available"


def _walk_strings(value: Any) -> list[str]:
    out: list[str] = []
    if isinstance(value, str):
        out.append(value)
    elif isinstance(value, dict):
        for item in value.values():
            out.extend(_walk_strings(item))
    elif isinstance(value, list | tuple | set):
        for item in value:
            out.extend(_walk_strings(item))
    return out


def _entity_mentions(value: Any) -> list[dict[str, str]]:
    import re

    found: dict[tuple[str, str], dict[str, str]] = {}
    text = "\n".join(_walk_strings(value))
    patterns = (
        (re.compile(r"https?://[^\s\"'<>]+"), "url"),
        (re.compile(r"(?<![\w.+-])[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}(?![\w.-])"), "email"),
        (re.compile(r"0x[a-fA-F0-9]{40}"), "wallet"),
        (re.compile(r"\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b", re.I), "domain"),
    )
    for regex, entity_type in patterns:
        for match in regex.findall(text):
            clean = str(match).rstrip(".,;)")
            found[(entity_type, clean)] = {"type": entity_type, "value": clean}
    return list(found.values())


class CatalogResponseParser:
    def __init__(self, source: dict[str, Any]):
        self.source = source

    def parse(self, result: AdapterResult) -> NormalizedAdapterOutput:
        target_type = result.input_type or (self.source.get("inputs") or ["target"])[0]
        target_entity = {"type": target_type, "value": result.target}
        source_entity = {"type": "source", "value": result.source_id}
        entities = [target_entity, source_entity]
        for entity in _entity_mentions([result.url, result.data, result.text]):
            if entity not in entities:
                entities.append(entity)

        relations = [
            {
                "src_type": target_entity["type"],
                "src_value": target_entity["value"],
                "rel": "queried_in",
                "dst_type": "source",
                "dst_value": result.source_id,
            }
        ]
        for entity in entities[2:]:
            relations.append(
                {
                    "src_type": target_entity["type"],
                    "src_value": target_entity["value"],
                    "rel": f"mentions_{entity['type']}",
                    "dst_type": entity["type"],
                    "dst_value": entity["value"],
                }
            )

        exists = result.status == "ok" and (
            result.status_code is None or result.status_code < 400
        )
        confidence = 0.15
        if exists:
            confidence += 0.35
        if result.data:
            confidence += 0.25
        if entities[2:]:
            confidence += 0.15
        if result.status_code and result.status_code < 400:
            confidence += 0.1
        finding = {
            "source_id": result.source_id,
            "source_name": self.source.get("name", result.source_id),
            "entity_type": target_entity["type"],
            "entity_value": target_entity["value"],
            "finding_type": "adapter_result",
            "profile_url": result.url,
            "status": "exists" if exists else result.status,
            "status_code": result.status_code,
            "confidence": round(min(confidence, 1.0), 3) if exists else 0.0,
            "reject_reason": result.error if not exists else "",
        }
        timeline = []
        if exists:
            timeline.append(
                {
                    "kind": "adapter_observed",
                    "entity_type": target_entity["type"],
                    "entity_value": target_entity["value"],
                    "source": result.source_id,
                    "confidence": finding["confidence"],
                    "description": f"{result.source_id} returned adapter data",
                }
            )
        return NormalizedAdapterOutput(
            entities=entities,
            relations=relations,
            findings=[finding],
            timeline=timeline,
            raw=result.as_dict(),
        )


class CatalogHttpAdapter:
    adapter_name = "catalog-http"

    def __init__(self, source: dict[str, Any]):
        self.source = source
        self.source_id = f"api:{source['id']}"
        self.inputs = list(source.get("inputs", []))
        self.env_vars = auth_env_vars(source["id"], str(source.get("auth", "none")))
        self.parser = CatalogResponseParser(source)

    def schema(self) -> dict[str, Any]:
        input_schema, output_schema = source_schema(self.source)
        input_schema["context"] = {
            "scope": "public_osint",
            "cache_enabled": "bool",
            "cache_ttl_seconds": "integer",
            "request_budget": "dict[source_id,int]",
        }
        return {
            "source_id": self.source_id,
            "adapter": self.adapter_name,
            "input_schema": input_schema,
            "output_schema": output_schema,
            "normalized_schema": {
                "entities": "list[{type,value}]",
                "relations": "list[{src_type,src_value,rel,dst_type,dst_value}]",
                "findings": "list[{source_id,entity,status,confidence}]",
                "timeline": "list[{kind,entity,source,confidence}]",
                "raw": "adapter result",
            },
        }

    def prepare(
        self,
        target: str,
        *,
        input_type: str | None = None,
        **kwargs: Any,
    ) -> tuple[str, str, str]:
        selected = input_type or (self.inputs[0] if self.inputs else "target")
        endpoints = self.source.get("endpoints", [])
        if not endpoints:
            raise ValueError("source has no endpoint templates")
        endpoint = _select_endpoint(str(self.source.get("id", "")), endpoints, selected)
        values = _values(target, selected, kwargs, self.env_vars)
        base_url = str(self.source.get("base_url", "")).rstrip("/").format(**values)
        path = str(endpoint.get("path", "")).format(**values)
        url = path if path.startswith("http://") or path.startswith("https://") else base_url + path
        return endpoint.get("method", "GET").upper(), url, selected

    def run(
        self,
        target: str,
        *,
        input_type: str | None = None,
        context: SourceRunContext | None = None,
        **kwargs: Any,
    ) -> AdapterResult:
        auth = str(self.source.get("auth", "none"))
        policy = policy_for_source(
            str(self.source.get("id", "")),
            name=str(self.source.get("name", "")),
        )
        if context:
            if policy and policy.blocked:
                result = AdapterResult(
                    source_id=self.source_id,
                    target=target,
                    status="blocked_by_scope",
                    input_type=input_type or "",
                    error=f"source rejected by policy catalog: {policy.name}",
                )
                result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
                return result
            allowed, reason = context.source_allowed(
                self.source_id,
                terms_risk=_terms_risk(self.source),
            )
            if not allowed:
                result = AdapterResult(
                    source_id=self.source_id,
                    target=target,
                    status="blocked_by_scope",
                    input_type=input_type or "",
                    error=reason,
                )
                result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
                return result
        try:
            method, url, selected = self.prepare(target, input_type=input_type, **kwargs)
            upload_required = _requires_upload_opt_in(
                str(self.source.get("id", "")),
                method,
                url,
            )
            if upload_required and not (context and context.legal_flags.get("allow_uploads")):
                result = AdapterResult(
                    source_id=self.source_id,
                    target=target,
                    status="blocked_by_scope",
                    input_type=selected,
                    method=method,
                    url=url,
                    error=f"source submission/upload requires explicit opt-in: {self.source.get('name', self.source_id)}",
                )
                result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
                return result
            if context and _requires_sensitive_opt_in(
                policy,
                self.source,
                selected,
            ) and not context.legal_flags.get("allow_sensitive_sources"):
                result = AdapterResult(
                    source_id=self.source_id,
                    target=target,
                    status="blocked_by_scope",
                    input_type=selected,
                    method=method,
                    url=url,
                    error=f"source requires explicit opt-in: {self.source.get('name', self.source_id)}",
                )
                result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
                return result
            missing = _auth_missing(self.env_vars, auth)
            if missing or (
                auth.lower() == "api_key_for_scan"
                and method in {"POST", "PUT", "PATCH"}
                and not configured(self.env_vars)
            ):
                return AdapterResult(
                    source_id=self.source_id,
                    target=target,
                    status="missing_keys",
                    input_type=selected,
                    method=method,
                    url=url,
                    missing_env=missing or self.env_vars,
                )
            request_kwargs = _merge_request_kwargs(
                _auth_request_kwargs(str(self.source.get("id", "")), auth, self.env_vars),
                _post_request_kwargs(str(self.source.get("id", "")), method, selected, target, kwargs),
            )
            upload_meta = request_kwargs.pop("_bedniiosint_upload", {})
            cached = (
                context.read_cache(self.source_id, method, url, request_kwargs)
                if context and not upload_required
                else None
            )
            if cached:
                result = AdapterResult(
                    source_id=self.source_id,
                    target=target,
                    status=str(cached.get("status") or "ok"),
                    input_type=selected,
                    method=method,
                    url=str(cached.get("url") or url),
                    status_code=cached.get("status_code"),
                    data=cached.get("data"),
                    text=str(cached.get("text") or ""),
                    headers=dict(cached.get("headers") or {}),
                    cache_hit=True,
                )
                result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
                return result
            if context:
                context.consume_budget(self.source_id)
            policy = context.http_policy() if context else None
            response = _request_with_policy(method, url, policy, **request_kwargs)
            content_type = response.headers.get("content-type", "")
            is_json = "json" in content_type.lower()
            data = response.json() if is_json else None
            if upload_meta and isinstance(data, dict):
                data["_bedniiosint_upload"] = upload_meta
            text = "" if is_json else response.text[:5000]
            result = AdapterResult(
                source_id=self.source_id,
                target=target,
                status="ok" if response.status_code < 400 else "error",
                input_type=selected,
                method=method,
                url=str(response.url),
                status_code=response.status_code,
                data=data,
                text=text,
                headers=dict(response.headers),
            )
            if context and not upload_required:
                context.write_cache(
                    self.source_id,
                    method,
                    url,
                    request_kwargs,
                    {
                        "status": result.status,
                        "input_type": selected,
                        "status_code": response.status_code,
                        "headers": dict(response.headers),
                        "data": data,
                        "text": text,
                    },
                )
            result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
            return result
        except SourceBudgetExceeded as exc:
            result = AdapterResult(
                source_id=self.source_id,
                target=target,
                status="rate_limited",
                input_type=input_type or "",
                error=str(exc),
            )
            result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
            return result
        except (OSError, ValueError, KeyError, httpx.HTTPError) as exc:
            result = AdapterResult(
                source_id=self.source_id,
                target=target,
                status="error",
                input_type=input_type or "",
                error=str(exc),
            )
            result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
            return result

    def health_check(self, **kwargs: Any) -> AdapterHealth:
        context = kwargs.pop("context", None)
        auth = str(self.source.get("auth", "none"))
        missing = _auth_missing(self.env_vars, auth)
        if missing:
            return AdapterHealth(self.source_id, "missing_keys", missing_env=missing)
        selected = kwargs.get("input_type") or (self.inputs[0] if self.inputs else "target")
        probe = kwargs.get("target") or kwargs.get("probe") or _probe_target(str(selected))
        try:
            method, url, _selected = self.prepare(
                str(probe),
                input_type=str(selected),
                **{k: v for k, v in kwargs.items() if k not in {"target", "probe", "input_type"}},
            )
            started = time.perf_counter()
            request_kwargs = _merge_request_kwargs(
                _auth_request_kwargs(str(self.source.get("id", "")), auth, self.env_vars),
                _post_request_kwargs(str(self.source.get("id", "")), method, _selected, str(probe), kwargs),
            )
            policy = context.http_policy() if isinstance(context, SourceRunContext) else None
            response = _request_with_policy(method, url, policy, **request_kwargs)
            latency_ms = int((time.perf_counter() - started) * 1000)
            status = _health_status(response.status_code)
            missing_env = missing if status == "missing_keys" else []
            return AdapterHealth(
                self.source_id,
                status,
                status_code=response.status_code,
                latency_ms=latency_ms,
                error="" if status in {"available", "degraded"} else f"HTTP {response.status_code}",
                missing_env=missing_env,
            )
        except Exception as exc:
            return AdapterHealth(self.source_id, "error", error=str(exc))


class SourceSpecificCatalogAdapter(CatalogHttpAdapter):
    adapter_name = "catalog-http-source-specific"


class CrtshAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "crtsh-adapter"


class RdapAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "rdap-adapter"


class GoogleDnsAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "google-dns-adapter"


class IpGeoAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "ip-geo-adapter"


class AttackSurfaceAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "attack-surface-adapter"


class NetworkRegistryAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "network-registry-adapter"


class DnsIntelAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "dns-intel-adapter"


class EmailIntelAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "email-intel-adapter"


class CompanyRegistryAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "company-registry-adapter"


class KnowledgeGraphAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "knowledge-graph-adapter"


class UsernameProfileAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "username-profile-adapter"


class LocationAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "location-geocoding-adapter"


class SocialIntelAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "social-intel-adapter"


class CryptoWalletAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "crypto-wallet-adapter"


class PhoneLookupAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "phone-lookup-adapter"


class UrlIntelAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "url-intel-adapter"


def _common_crawl_pattern(target: str, input_type: str | None) -> str:
    raw = str(target or "").strip()
    selected = str(input_type or "").strip().lower()
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = (parsed.netloc or parsed.path).split("@")[-1].split(":")[0].strip().lower()
    path = parsed.path.strip()
    if selected == "url" or (path and path != "/"):
        return raw if "://" in raw else f"https://{raw}"
    if host:
        return f"*.{host}/*"
    return raw


def _json_lines(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in str(text or "").splitlines():
        clean = line.strip()
        if not clean:
            continue
        try:
            item = json.loads(clean)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict):
            rows.append(item)
    return rows


class CommonCrawlAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "common-crawl-adapter"

    def run(
        self,
        target: str,
        *,
        input_type: str | None = None,
        context: SourceRunContext | None = None,
        **kwargs: Any,
    ) -> AdapterResult:
        selected = input_type or (self.inputs[0] if self.inputs else "domain")
        policy = policy_for_source(
            str(self.source.get("id", "")),
            name=str(self.source.get("name", "")),
        )
        if context:
            if policy and policy.blocked:
                result = AdapterResult(
                    source_id=self.source_id,
                    target=target,
                    status="blocked_by_scope",
                    input_type=selected,
                    error=f"source rejected by policy catalog: {policy.name}",
                )
                result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
                return result
            allowed, reason = context.source_allowed(
                self.source_id,
                terms_risk=_terms_risk(self.source),
            )
            if not allowed:
                result = AdapterResult(
                    source_id=self.source_id,
                    target=target,
                    status="blocked_by_scope",
                    input_type=selected,
                    error=reason,
                )
                result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
                return result
        try:
            if context:
                context.consume_budget(self.source_id)
            policy_obj = context.http_policy() if context else None
            collinfo_url = str(self.source.get("base_url", "")).rstrip("/") + "/collinfo.json"
            collinfo_response = _request_with_policy("GET", collinfo_url, policy_obj)
            collinfo = collinfo_response.json()
            if not isinstance(collinfo, list):
                raise ValueError("Common Crawl collinfo response is not a list")
            selected_index = next(
                (
                    row
                    for row in collinfo
                    if isinstance(row, dict) and str(row.get("cdx-api") or "").startswith("http")
                ),
                None,
            )
            if not selected_index:
                raise ValueError("Common Crawl collinfo did not include a cdx-api endpoint")
            cdx_url = str(selected_index["cdx-api"]).rstrip("?")
            limit = int(kwargs.get("limit") or 50)
            params = {
                "url": _common_crawl_pattern(target, selected),
                "output": "json",
                "fl": "url,status,timestamp,digest,mime",
                "filter": "status:200",
                "limit": str(max(1, min(limit, 100))),
            }
            cdx_response = _request_with_policy("GET", cdx_url, policy_obj, params=params)
            data = cdx_response.json() if "json" in cdx_response.headers.get("content-type", "").lower() else None
            if not isinstance(data, list):
                data = _json_lines(cdx_response.text)
            result = AdapterResult(
                source_id=self.source_id,
                target=target,
                status="ok" if cdx_response.status_code < 400 else "error",
                input_type=selected,
                method="GET",
                url=str(cdx_response.url),
                status_code=cdx_response.status_code,
                data=data,
                text="" if data else cdx_response.text[:5000],
                headers=dict(cdx_response.headers),
            )
            result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
            return result
        except SourceBudgetExceeded as exc:
            result = AdapterResult(
                source_id=self.source_id,
                target=target,
                status="rate_limited",
                input_type=selected,
                error=str(exc),
            )
            result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
            return result
        except (OSError, ValueError, KeyError, json.JSONDecodeError, httpx.HTTPError) as exc:
            result = AdapterResult(
                source_id=self.source_id,
                target=target,
                status="error",
                input_type=selected,
                error=str(exc),
            )
            result.normalized = parse_specialized(self.source, result) or self.parser.parse(result).as_dict()
            return result


class ThreatIntelAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "threat-intel-adapter"


class AggregatorAdapter(SourceSpecificCatalogAdapter):
    adapter_name = "aggregator-adapter"


_SPECIALIZED_ADAPTERS = {
    "crtsh": CrtshAdapter,
    "rdap": RdapAdapter,
    "google_dns": GoogleDnsAdapter,
    "cloudflare_dns": GoogleDnsAdapter,
    "bgpview": NetworkRegistryAdapter,
    "peeringdb": NetworkRegistryAdapter,
    "ipwhois": IpGeoAdapter,
    "ipinfo": IpGeoAdapter,
    "shodan": AttackSurfaceAdapter,
    "censys": AttackSurfaceAdapter,
    "securitytrails": DnsIntelAdapter,
    "hunter": EmailIntelAdapter,
    "hibp": EmailIntelAdapter,
    "gravatar": EmailIntelAdapter,
    "emailrep": EmailIntelAdapter,
    "opencorporates": CompanyRegistryAdapter,
    "companies_house": CompanyRegistryAdapter,
    "wikidata": KnowledgeGraphAdapter,
    "github": UsernameProfileAdapter,
    "github_search": UsernameProfileAdapter,
    "gitlab": UsernameProfileAdapter,
    "hackernews": UsernameProfileAdapter,
    "codeforces": UsernameProfileAdapter,
    "bluesky": UsernameProfileAdapter,
    "mastodon_lookup": UsernameProfileAdapter,
    "dockerhub": UsernameProfileAdapter,
    "cratesio": UsernameProfileAdapter,
    "lichess": UsernameProfileAdapter,
    "duolingo": UsernameProfileAdapter,
    "reddit_about": UsernameProfileAdapter,
    "blockchain_info": CryptoWalletAdapter,
    "blockstream": CryptoWalletAdapter,
    "blockchair": CryptoWalletAdapter,
    "numverify": PhoneLookupAdapter,
    "veriphone": PhoneLookupAdapter,
    "twilio_lookup": PhoneLookupAdapter,
    "nominatim": LocationAdapter,
    "open_measures": SocialIntelAdapter,
    "urlscan": UrlIntelAdapter,
    "wayback_cdx": UrlIntelAdapter,
    "common_crawl": CommonCrawlAdapter,
    "virustotal": ThreatIntelAdapter,
    "alienvault_otx": ThreatIntelAdapter,
    "abuseipdb": ThreatIntelAdapter,
    "greynoise": ThreatIntelAdapter,
    "urlhaus": ThreatIntelAdapter,
    "osintly_api": AggregatorAdapter,
    "google_cse": AggregatorAdapter,
    "youtube": SocialIntelAdapter,
}


class BuiltinModuleAdapter:
    def __init__(self, name: str):
        plugin = get_builtin_plugin(name.replace("module:", ""))
        if plugin is None:
            raise KeyError(f"built-in plugin not found: {name}")
        self.plugin = plugin
        self.source_id = f"module:{plugin.name}"

    def schema(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "adapter": "builtin-module",
            "input_schema": {
                "target": {"type": "string", "required": True},
                "input_types": self.plugin.consumes,
            },
            "output_schema": {"produces": self.plugin.produces, "type": "case_summary"},
            "normalized_schema": {"raw": "case_summary"},
        }

    def run(self, target: str, *, case: str = "adapter-run", **kwargs: Any) -> AdapterResult:
        kwargs.pop("context", None)
        try:
            data = self.plugin.runner(case, target, **kwargs)
            return AdapterResult(
                source_id=self.source_id,
                target=target,
                status="ok",
                input_type=self.plugin.consumes[0] if self.plugin.consumes else "",
                data=data,
            )
        except Exception as exc:
            return AdapterResult(
                source_id=self.source_id,
                target=target,
                status="error",
                error=str(exc),
            )

    def health_check(self, **kwargs: Any) -> AdapterHealth:
        return AdapterHealth(self.source_id, "available")


class LocalPluginAdapter:
    def __init__(self, manifest: PluginManifest):
        self.manifest = manifest
        self.source_id = f"plugin:{manifest.name}"

    def schema(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "adapter": self.manifest.entrypoint,
            "input_schema": {
                "target": {"type": "string", "required": True},
                "input_types": self.manifest.consumes,
                "auth": self.manifest.auth,
                "env_vars": self.manifest.env_vars,
            },
            "output_schema": {"produces": self.manifest.produces, "type": "plugin_result"},
            "normalized_schema": {"raw": "plugin_result"},
        }

    def _load_module(self):
        module_name, func_name = self.manifest.entrypoint.split(":", 1)
        manifest_path = Path(self.manifest.path)
        module_path = manifest_path.parent / f"{module_name}.py"
        if not module_path.exists():
            raise FileNotFoundError(module_path)
        spec = importlib.util.spec_from_file_location(
            f"bedniiosint_local_plugin_{self.manifest.name}_{module_name}",
            module_path,
        )
        if spec is None or spec.loader is None:
            raise ImportError(f"cannot load plugin module: {module_path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def _load_callable(self):
        module_name, func_name = self.manifest.entrypoint.split(":", 1)
        module = self._load_module()
        return getattr(module, func_name)

    def run(self, target: str, **kwargs: Any) -> AdapterResult:
        kwargs.pop("context", None)
        missing = missing_secret_names(self.manifest.env_vars)
        if missing and self.manifest.auth not in {"none", "", "optional"}:
            return AdapterResult(
                source_id=self.source_id,
                target=target,
                status="missing_keys",
                missing_env=missing,
            )
        try:
            module = self._load_module()
            _module_name, func_name = self.manifest.entrypoint.split(":", 1)
            config = get_plugin_config(self.manifest.name)
            result = getattr(module, func_name)(target, **{**config, **kwargs})
            normalized = None
            parser = getattr(module, "parse", None)
            if callable(parser):
                normalized = parser(result, target)
            return AdapterResult(
                source_id=self.source_id,
                target=target,
                status="ok",
                input_type=self.manifest.consumes[0] if self.manifest.consumes else "",
                data=result,
                normalized=normalized,
            )
        except Exception as exc:
            return AdapterResult(
                source_id=self.source_id,
                target=target,
                status="error",
                error=str(exc),
            )

    def health_check(self, **kwargs: Any) -> AdapterHealth:
        kwargs.pop("context", None)
        missing = missing_secret_names(self.manifest.env_vars)
        if missing and self.manifest.auth not in {"none", "", "optional"}:
            return AdapterHealth(self.source_id, "missing_keys", missing_env=missing)
        try:
            module = self._load_module()
            checker = getattr(module, "health_check", None)
            if callable(checker):
                config = get_plugin_config(self.manifest.name)
                checked = checker(**{**config, **kwargs})
                return AdapterHealth(
                    self.source_id,
                    str(checked.get("status") or "available"),
                    status_code=checked.get("status_code"),
                    error=str(checked.get("error") or ""),
                    missing_env=list(checked.get("missing_env") or []),
                )
            return AdapterHealth(self.source_id, "available")
        except Exception as exc:
            return AdapterHealth(self.source_id, "error", error=str(exc))


def adapter_for(source_id: str, *, plugin_dir: Path | None = None):
    from ..core.plugins import discover_plugin_manifests

    normalized = source_id.strip()
    if normalized.startswith("module:"):
        return BuiltinModuleAdapter(normalized)
    if normalized.startswith("plugin:"):
        name = normalized.replace("plugin:", "", 1)
        for manifest in discover_plugin_manifests(plugin_dir):
            if manifest.name == name:
                return LocalPluginAdapter(manifest)
        raise KeyError(f"plugin adapter not found: {source_id}")
    api = _find_api(normalized)
    adapter_cls = _SPECIALIZED_ADAPTERS.get(str(api.get("id", "")).lower(), CatalogHttpAdapter)
    return adapter_cls(api)


def run_source(
    source_id: str,
    target: str,
    *,
    plugin_dir: Path | None = None,
    **kwargs: Any,
) -> AdapterResult:
    return adapter_for(source_id, plugin_dir=plugin_dir).run(target, **kwargs)
