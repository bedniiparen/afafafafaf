from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from ..core.secret_store import secret_configured
from .health import ApiKeyStatus, SourceHealth, api_key_status, source_health
from .registry import SourceEntry, registry_entries


def api_key_env_template(
    *,
    source: str | None = None,
    missing_only: bool = False,
    include_optional: bool = True,
) -> str:
    """Return a safe .env template with blank values only."""
    keys = _filtered_keys(source=source, missing_only=missing_only, include_optional=include_optional)
    health_by_source = {row.source_id: row for row in source_health()}
    lines = [
        "# BEDNIIOSINT API key template",
        f"# Generated: {datetime.now(timezone.utc).isoformat()}",
        "# Values are intentionally blank. Do not commit a filled secrets file.",
        "",
    ]
    for key in keys:
        details = [_source_detail(health_by_source[src]) for src in key.sources if src in health_by_source]
        lines.extend(
            [
                f"# {key.name}",
                f"# Required: {'yes' if key.required else 'no'}",
                f"# Configured via env or encrypted store: {'yes' if key.configured else 'no'}",
                f"# Sources: {', '.join(key.sources)}",
            ]
        )
        for detail in details:
            lines.append(f"# - {detail}")
        lines.append(f"{key.name}=")
        lines.append("")
    if not keys:
        lines.append("# No API key variables match the selected filters.")
        lines.append("")
    return "\n".join(lines)


def api_key_setup_plan(
    *,
    priorities: tuple[str, ...] = ("P1",),
    missing_only: bool = True,
    include_optional: bool = True,
    entries: list[SourceEntry] | None = None,
) -> dict:
    """Return a safe setup plan for keyed sources without secret values."""
    rows = entries or registry_entries()
    selected_priorities = {item.upper() for item in priorities if item and item.lower() != "all"}
    health_by_source = {row.source_id: row for row in source_health(rows)}
    key_by_name = {row.name: row for row in api_key_status(rows)}
    sources = []
    missing_key_names: set[str] = set()
    configured_key_names: set[str] = set()

    for source in rows:
        if source.kind != "api" or not source.env_vars:
            continue
        if selected_priorities and source.priority.upper() not in selected_priorities:
            continue
        health = health_by_source.get(source.id)
        auth_required = health.auth_required if health else _key_required(source, key_by_name)
        if auth_required is False and not include_optional:
            continue

        key_rows = []
        for name in source.env_vars:
            key_status = key_by_name.get(name)
            configured = secret_configured(name)
            if configured:
                configured_key_names.add(name)
            else:
                missing_key_names.add(name)
            key_rows.append(
                {
                    "name": name,
                    "configured": configured,
                    "required": bool(key_status.required) if key_status else auth_required,
                }
            )
        configured = all(row["configured"] for row in key_rows)
        if missing_only and configured:
            continue

        missing_env = [row["name"] for row in key_rows if not row["configured"]]
        sources.append(
            {
                "source_id": source.id,
                "name": source.name,
                "priority": source.priority,
                "inputs": source.inputs,
                "auth": source.auth,
                "env_vars": list(source.env_vars),
                "missing_env": missing_env,
                "configured": configured,
                "required": auth_required,
                "terms_risk": source.terms_risk,
                "requires_opt_in": source.requires_opt_in,
                "docs_url": source.docs_url,
                "setup_hint": source.setup_hint,
                "verification_status": health.verification_status if health else "",
                "remediation": health.remediation if health else "",
                "keys": key_rows,
                "safe_env_lines": [f"{name}=" for name in missing_env],
            }
        )

    sources.sort(
        key=lambda row: (
            row["configured"],
            _priority_rank(str(row["priority"])),
            not row["required"],
            row["source_id"],
        )
    )
    return {
        "summary": {
            "priorities": sorted(selected_priorities) if selected_priorities else ["all"],
            "sources": len(sources),
            "missing_sources": sum(1 for row in sources if not row["configured"]),
            "configured_sources": sum(1 for row in sources if row["configured"]),
            "missing_keys": len(missing_key_names),
            "configured_keys": len(configured_key_names),
            "missing_only": missing_only,
            "include_optional": include_optional,
        },
        "sources": sources,
        "safe_env_template": "\n".join(f"{name}=" for name in sorted(missing_key_names)),
    }


def write_api_key_env_template(
    out: Path,
    *,
    source: str | None = None,
    missing_only: bool = False,
    include_optional: bool = True,
    overwrite: bool = False,
) -> Path:
    if out.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite existing template: {out}")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        api_key_env_template(
            source=source,
            missing_only=missing_only,
            include_optional=include_optional,
        ),
        encoding="utf-8",
    )
    return out


def _filtered_keys(
    *,
    source: str | None,
    missing_only: bool,
    include_optional: bool,
) -> list[ApiKeyStatus]:
    keys = api_key_status()
    if source:
        needle = _normalize_source_id(source)
        keys = [
            key
            for key in keys
            if any(_normalize_source_id(source_id) == needle for source_id in key.sources)
        ]
    if missing_only:
        keys = [key for key in keys if not key.configured]
    if not include_optional:
        keys = [key for key in keys if key.required]
    return keys


def _key_required(source: SourceEntry, key_by_name: dict[str, ApiKeyStatus]) -> bool:
    for name in source.env_vars:
        key = key_by_name.get(name)
        if key and key.required:
            return True
    auth = source.auth.lower()
    return bool(auth and auth not in {"none", "optional", "none_or_api_key", "api_key_optional"})


def _priority_rank(priority: str) -> int:
    order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3, "REJECT": 9}
    return order.get(priority.upper(), 5)


def _source_detail(row: SourceHealth) -> str:
    parts: list[str] = [row.source_id]
    if row.priority:
        parts.append(f"priority {row.priority}")
    parts.append(f"risk {row.terms_risk}")
    if row.docs_url:
        parts.append(f"docs {row.docs_url}")
    if row.requires_opt_in:
        parts.append("requires explicit opt-in")
    return " | ".join(parts)


def _normalize_source_id(source_id: str) -> str:
    return source_id.lower().removeprefix("api:").removeprefix("module:").removeprefix("plugin:")
