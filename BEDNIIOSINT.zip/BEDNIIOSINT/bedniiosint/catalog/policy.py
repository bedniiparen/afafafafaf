from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any


POLICY_CATALOG_PATH = Path(__file__).resolve().parents[2] / "data" / "osint_sources_catalog.json"

PRIORITY_TO_MIN_RISK = {
    "reject": "reject",
}


@dataclass(frozen=True)
class SourcePolicy:
    source_id: str
    name: str
    priority: str = ""
    tos_privacy_risk: str = "low"
    cache_policy: str = "ttl_cache_allowed"
    quota_policy: str = "public_rate_limited"
    requires_opt_in: bool = False
    product_value: str = ""
    implementation_complexity: str = ""
    auth: str = ""
    docs_url: str = ""
    setup_hint: str = ""
    verification_notes: str = ""
    sources: tuple[str, ...] = ()
    collection_mode: str = "lookup"
    sensitive_data: bool = False
    labels: tuple[str, ...] = ()

    @property
    def blocked(self) -> bool:
        return self.priority.lower() == "reject" or self.tos_privacy_risk.lower() == "reject"

    @property
    def passive_only(self) -> bool:
        return "passive_only" in self.labels


PASSIVE_SOURCE_IDS = {
    "amass_passive_source_study",
    "censys",
    "domain_passive_tools",
    "shodan",
    "subfinder_passive_source_study",
}

SENSITIVE_CATEGORY_MARKERS = (
    "breach exposure",
    "phone intelligence",
    "public social media footprint",
    "sanctions",
)

SENSITIVE_INPUT_TYPES = {
    "google account",
    "password",
    "password_hash_prefix",
    "phone",
}

SENSITIVE_NOTE_MARKERS = (
    "breach",
    "consent",
    "password",
    "private",
    "privacy",
    "sensitive",
)


def _append_unique(items: list[str], value: str) -> None:
    if value and value not in items:
        items.append(value)


def _policy_labels(
    *,
    source_id: str,
    category: str,
    input_types: list[str],
    integration_notes: str,
    priority: str,
    requires_opt_in: bool,
) -> tuple[str, ...]:
    normalized_id = _normalize_id(source_id)
    category_text = category.lower()
    notes_text = integration_notes.lower()
    input_values = {str(item).strip().lower() for item in input_types}
    labels: list[str] = []

    if (
        normalized_id in PASSIVE_SOURCE_IDS
        or "exposed services" in category_text
        or "internet scan data" in category_text
        or "passive" in notes_text
    ):
        _append_unique(labels, "passive_only")

    if (
        any(marker in category_text for marker in SENSITIVE_CATEGORY_MARKERS)
        or bool(input_values.intersection(SENSITIVE_INPUT_TYPES))
        or any(marker in notes_text for marker in SENSITIVE_NOTE_MARKERS)
    ):
        _append_unique(labels, "sensitive_data")

    if requires_opt_in:
        _append_unique(labels, "requires_opt_in")
    if priority.lower() == "reject":
        _append_unique(labels, "reject")
    return tuple(labels)


def _normalize_id(value: str) -> str:
    text = value.strip().lower().replace("api:", "")
    return text.replace("-", "_").replace(" ", "_")


def _policy_id(row: dict[str, Any]) -> str:
    module_name = str(row.get("recommended_module_name") or "")
    if module_name.startswith("api_"):
        return module_name[4:]
    if module_name.startswith("local_"):
        return module_name[6:]
    if module_name.startswith("reject_"):
        return module_name[7:]
    return _normalize_id(str(row.get("name") or ""))


@lru_cache(maxsize=1)
def load_policy_catalog(path: str | Path | None = None) -> dict[str, SourcePolicy]:
    catalog_path = Path(path) if path else POLICY_CATALOG_PATH
    if not catalog_path.exists():
        return {}
    rows = json.loads(catalog_path.read_text(encoding="utf-8"))
    policies: dict[str, SourcePolicy] = {}
    for row in rows:
        source_id = _policy_id(row)
        risk = str(row.get("tos_privacy_risk") or "low").lower()
        priority = str(row.get("priority") or "").lower()
        if priority in PRIORITY_TO_MIN_RISK:
            risk = PRIORITY_TO_MIN_RISK[priority]
        integration_notes = str(row.get("integration_notes") or "").lower()
        category = str(row.get("category") or "")
        input_types = [str(item) for item in row.get("input_types") or []]
        auth = str(row.get("auth") or "")
        docs_url = str(row.get("docs_url") or row.get("official_url") or "")
        requires_opt_in = any(
            marker in integration_notes
            for marker in (
                "opt-in",
                "authorized",
                "consent",
                "do not upload",
                "submission",
                "sensitive",
            )
        )
        labels = _policy_labels(
            source_id=source_id,
            category=category,
            input_types=input_types,
            integration_notes=integration_notes,
            priority=priority,
            requires_opt_in=requires_opt_in,
        )
        env_hint = "no API key required"
        if "api key" in auth.lower() or "oauth" in auth.lower() or "credentials" in auth.lower():
            env_hint = "configure the documented environment variable(s)"
        policy = SourcePolicy(
            source_id=source_id,
            name=str(row.get("name") or source_id),
            priority=str(row.get("priority") or ""),
            tos_privacy_risk=risk,
            requires_opt_in=requires_opt_in,
            product_value=str(row.get("product_value") or ""),
            implementation_complexity=str(row.get("implementation_complexity") or ""),
            auth=auth,
            docs_url=docs_url,
            setup_hint=f"{env_hint}; see {docs_url}" if docs_url else env_hint,
            verification_notes=str(row.get("verification_notes") or ""),
            sources=tuple(str(item) for item in row.get("sources") or []),
            collection_mode="passive_lookup" if "passive_only" in labels else "lookup",
            sensitive_data="sensitive_data" in labels,
            labels=labels,
        )
        policies[source_id] = policy
    return policies


def policy_for_source(source_id: str, *, name: str = "") -> SourcePolicy | None:
    policies = load_policy_catalog()
    normalized = _normalize_id(source_id)
    if normalized in policies:
        return policies[normalized]
    if name:
        name_normalized = _normalize_id(name)
        if name_normalized in policies:
            return policies[name_normalized]
    return None


def risk_for_source(source_id: str, *, fallback: str = "low", name: str = "") -> str:
    policy = policy_for_source(source_id, name=name)
    return policy.tos_privacy_risk if policy else fallback


def source_policy_context(
    source_id: str,
    *,
    name: str = "",
    category: str = "",
    notes: str = "",
    input_types: list[str] | tuple[str, ...] = (),
) -> dict[str, Any]:
    policy = policy_for_source(source_id, name=name)
    if policy:
        labels = list(policy.labels)
        return {
            "terms_risk": policy.tos_privacy_risk,
            "collection_mode": policy.collection_mode,
            "sensitivity": "sensitive_data" if policy.sensitive_data else "standard",
            "requires_opt_in": policy.requires_opt_in,
            "policy_labels": labels,
        }

    labels = list(
        _policy_labels(
            source_id=source_id or name,
            category=category,
            input_types=[str(item) for item in input_types],
            integration_notes=notes,
            priority="",
            requires_opt_in=False,
        )
    )
    return {
        "terms_risk": "not confirmed",
        "collection_mode": "passive_lookup" if "passive_only" in labels else "lookup",
        "sensitivity": "sensitive_data" if "sensitive_data" in labels else "standard",
        "requires_opt_in": False,
        "policy_labels": labels,
    }


def format_policy_note(context: dict[str, Any]) -> str:
    labels = ",".join(context.get("policy_labels") or [])
    parts = []
    if labels:
        parts.append(f"policy_labels={labels}")
    for key in ("collection_mode", "sensitivity", "terms_risk"):
        value = context.get(key)
        if value:
            parts.append(f"{key}={value}")
    if context.get("requires_opt_in"):
        parts.append("requires_opt_in=true")
    return "; ".join(parts)
