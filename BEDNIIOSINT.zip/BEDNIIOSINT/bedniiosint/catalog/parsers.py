from __future__ import annotations

from ipaddress import ip_address
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _source_id(source: dict[str, Any]) -> str:
    return f"api:{source.get('id', 'source')}"


def _target_type(source: dict[str, Any], result) -> str:
    return result.input_type or (source.get("inputs") or ["target"])[0]


def _entity(entities: list[dict[str, str]], entity_type: str, value: Any) -> None:
    text = str(value or "").strip()
    if not text:
        return
    row = {"type": entity_type, "value": text}
    if row not in entities:
        entities.append(row)


def _relation(
    relations: list[dict[str, str]],
    src_type: str,
    src_value: str,
    rel: str,
    dst_type: str,
    dst_value: Any,
) -> None:
    text = str(dst_value or "").strip()
    if not text:
        return
    row = {
        "src_type": src_type,
        "src_value": src_value,
        "rel": rel,
        "dst_type": dst_type,
        "dst_value": text,
    }
    if row not in relations:
        relations.append(row)


def _base(source: dict[str, Any], result) -> tuple[list[dict], list[dict], str, str, str]:
    target_type = _target_type(source, result)
    target = str(result.target)
    source_id = _source_id(source)
    entities: list[dict] = []
    relations: list[dict] = []
    _entity(entities, target_type, target)
    _entity(entities, "source", source_id)
    _relation(relations, target_type, target, "queried_in", "source", source_id)
    return entities, relations, target_type, target, source_id


def _finding(
    source: dict[str, Any],
    result,
    *,
    status: str = "exists",
    confidence: float = 0.7,
    finding_type: str = "adapter_result",
    reject_reason: str = "",
    profile_url: str = "",
) -> dict:
    target_type = _target_type(source, result)
    return {
        "source_id": _source_id(source),
        "source_name": source.get("name", _source_id(source)),
        "entity_type": target_type,
        "entity_value": result.target,
        "finding_type": finding_type,
        "profile_url": profile_url or result.url,
        "status": status,
        "status_code": result.status_code,
        "confidence": round(max(0.0, min(1.0, confidence)), 3),
        "reject_reason": reject_reason,
    }


def _timeline(
    source_id: str,
    target_type: str,
    target: str,
    *,
    kind: str = "adapter_observed",
    confidence: float = 0.7,
    description: str = "",
    when: str | None = None,
) -> dict:
    row = {
        "kind": kind,
        "entity_type": target_type,
        "entity_value": target,
        "source": source_id,
        "confidence": round(max(0.0, min(1.0, confidence)), 3),
        "description": description,
    }
    if when:
        row["when"] = when
    return row


def _host_suffix(host: str, domain: str) -> bool:
    host = host.lower().strip(".")
    domain = domain.lower().strip(".")
    return host == domain or host.endswith("." + domain)


def _as_list(value: Any) -> list:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _confidence(result, *, data_weight: float = 0.2, item_count: int = 0) -> float:
    if result.status != "ok" or (result.status_code is not None and result.status_code >= 400):
        return 0.0
    value = 0.45 + data_weight
    if item_count:
        value += min(0.25, item_count * 0.04)
    if result.status_code and result.status_code < 400:
        value += 0.1
    return round(min(1.0, value), 3)


def parse_specialized(source: dict[str, Any], result) -> dict[str, Any] | None:
    source_id = str(source.get("id", "")).lower()
    parsers = {
        "crtsh": _parse_crtsh,
        "rdap": _parse_rdap,
        "google_dns": _parse_google_dns,
        "cloudflare_dns": _parse_google_dns,
        "hackertarget": _parse_hackertarget,
        "bgpview": _parse_bgpview,
        "peeringdb": _parse_peeringdb,
        "ipwhois": _parse_ip_geo,
        "ipinfo": _parse_ip_geo,
        "shodan": _parse_attack_surface,
        "censys": _parse_attack_surface,
        "securitytrails": _parse_securitytrails,
        "hunter": _parse_hunter,
        "hibp": _parse_hibp,
        "gravatar": _parse_profile_source,
        "emailrep": _parse_emailrep,
        "opencorporates": _parse_company,
        "companies_house": _parse_company,
        "wikidata": _parse_wikidata,
        "github": _parse_username_profile,
        "github_search": _parse_github_search,
        "gitlab": _parse_username_profile,
        "google_cse": _parse_google_cse,
        "hackernews": _parse_username_profile,
        "codeforces": _parse_username_profile,
        "bluesky": _parse_username_profile,
        "mastodon_lookup": _parse_mastodon_profile,
        "dockerhub": _parse_username_profile,
        "cratesio": _parse_username_profile,
        "lichess": _parse_username_profile,
        "duolingo": _parse_username_profile,
        "reddit_about": _parse_username_profile,
        "youtube": _parse_youtube,
        "blockchain_info": _parse_wallet,
        "blockstream": _parse_wallet,
        "blockchair": _parse_wallet,
        "numverify": _parse_phone,
        "veriphone": _parse_phone,
        "twilio_lookup": _parse_phone,
        "nominatim": _parse_nominatim,
        "open_measures": _parse_open_measures,
        "urlscan": _parse_urlscan,
        "tineye": _parse_tineye,
        "virustotal": _parse_virustotal,
        "alienvault_otx": _parse_alienvault_otx,
        "abuseipdb": _parse_abuseipdb,
        "greynoise": _parse_greynoise,
        "urlhaus": _parse_urlhaus,
        "threatfox": _parse_threatfox,
        "malwarebazaar": _parse_malwarebazaar,
        "wayback_cdx": _parse_wayback,
        "gdelt": _parse_gdelt,
        "common_crawl": _parse_common_crawl,
        "builtwith": _parse_technology,
        "wappalyzer": _parse_technology,
        "osintly_api": _parse_aggregator,
    }
    parser = parsers.get(source_id)
    return parser(source, result) if parser else None


def _finish(
    source: dict[str, Any],
    result,
    entities: list[dict],
    relations: list[dict],
    *,
    confidence: float,
    status: str = "exists",
    finding_type: str = "adapter_result",
    timeline: list[dict] | None = None,
    reject_reason: str = "",
    profile_url: str = "",
) -> dict[str, Any]:
    _entities, _relations, target_type, target, source_id = _base(source, result)
    for entity in _entities:
        _entity(entities, entity["type"], entity["value"])
    for relation in _relations:
        _relation(
            relations,
            relation["src_type"],
            relation["src_value"],
            relation["rel"],
            relation["dst_type"],
            relation["dst_value"],
        )
    return {
        "entities": entities,
        "relations": relations,
        "findings": [
            _finding(
                source,
                result,
                status=status,
                confidence=confidence,
                finding_type=finding_type,
                reject_reason=reject_reason,
                profile_url=profile_url,
            )
        ],
        "timeline": timeline
        if timeline is not None
        else [
            _timeline(
                source_id,
                target_type,
                target,
                confidence=confidence,
                description=f"{source_id} returned normalized data",
            )
        ],
        "raw": result.as_dict(),
    }


def _parse_crtsh(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    rows = result.data if isinstance(result.data, list) else []
    count = 0
    for row in rows:
        for name in str(row.get("name_value") or row.get("common_name") or "").splitlines():
            host = name.strip().lower().lstrip("*.").strip(".")
            if not host or "@" in host or not _host_suffix(host, target):
                continue
            _entity(entities, "domain", host)
            _relation(relations, target_type, target, "has_subdomain", "domain", host)
            count += 1
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, item_count=count),
        finding_type="certificate_transparency",
    )


def _parse_rdap(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    registrar = ""
    for item in data.get("entities", []) or []:
        roles = item.get("roles", []) or []
        if "registrar" in roles:
            registrar = item.get("handle") or item.get("fn") or item.get("name") or ""
            _entity(entities, "company", registrar)
            _relation(relations, target_type, target, "registered_by", "company", registrar)
    handle = data.get("handle") or data.get("ldhName") or data.get("objectClassName")
    if handle:
        _entity(entities, "registry_id", handle)
        _relation(relations, target_type, target, "has_registry_id", "registry_id", handle)
    timeline = []
    for event in data.get("events", []) or []:
        action = str(event.get("eventAction") or "rdap_event")
        when = event.get("eventDate")
        timeline.append(
            _timeline(
                source_id,
                target_type,
                target,
                kind=action,
                confidence=0.85,
                description=f"RDAP event {action}",
                when=when,
            )
        )
    confidence = _confidence(result, item_count=len(timeline) + int(bool(handle)))
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=confidence,
        finding_type="rdap_record",
        timeline=timeline or None,
    )


def _parse_google_dns(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    answers = data.get("Answer", []) or []
    for answer in answers:
        value = str(answer.get("data") or "").strip().strip(".")
        rr_type = str(answer.get("type") or "")
        if not value:
            continue
        try:
            ip_address(value)
            entity_type = "ip"
            entity_value = value
        except ValueError:
            entity_type = "domain" if "." in value and " " not in value else "dns_record"
            entity_value = value if entity_type == "domain" else f"{rr_type}:{value}"
        if entity_type in {"domain", "ip"}:
            _entity(entities, entity_type, entity_value)
            _relation(relations, target_type, target, "dns_answer", entity_type, entity_value)
        else:
            _entity(entities, entity_type, entity_value)
            _relation(relations, target_type, target, "dns_answer", entity_type, entity_value)
    confidence = _confidence(result, item_count=len(answers))
    return _finish(source, result, entities, relations, confidence=confidence, finding_type="dns_record")


def _parse_hackertarget(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    count = 0
    for line in str(result.text or "").splitlines():
        parts = [part.strip() for part in line.split(",") if part.strip()]
        if not parts:
            continue
        host = parts[0].lower().strip(".")
        if _host_suffix(host, target):
            _entity(entities, "domain", host)
            _relation(relations, target_type, target, "has_subdomain", "domain", host)
            count += 1
        if len(parts) > 1:
            _entity(entities, "ip", parts[1])
            _relation(relations, "domain", host, "resolves_to", "ip", parts[1])
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=count), finding_type="dns_enrichment")


def _parse_bgpview(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    body = data.get("data", data)
    asn = body.get("asn") or body.get("asn_id") or body.get("id")
    if asn and not str(asn).upper().startswith("AS"):
        asn = f"AS{asn}"
    name = body.get("name") or body.get("description_short") or body.get("owner")
    _entity(entities, "asn", asn)
    _relation(relations, target_type, target, "announced_by", "asn", asn)
    _entity(entities, "company", name)
    _relation(relations, "asn", asn or target, "operated_by", "company", name)
    count = int(bool(asn)) + int(bool(name))
    prefixes = body.get("prefixes") or body.get("ipv4_prefixes") or body.get("ipv6_prefixes") or []
    if isinstance(prefixes, dict):
        prefixes = (prefixes.get("ipv4_prefixes") or []) + (prefixes.get("ipv6_prefixes") or [])
    for item in prefixes[:50]:
        prefix = item.get("prefix") if isinstance(item, dict) else item
        _entity(entities, "cidr", prefix)
        _relation(relations, "asn", asn or target, "announces_prefix", "cidr", prefix)
        count += int(bool(prefix))
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=count), finding_type="network_routing")


def _parse_peeringdb(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("data") or []
    if isinstance(rows, dict):
        rows = [rows]
    count = 0
    for row in rows[:25]:
        asn = row.get("asn")
        if asn and not str(asn).upper().startswith("AS"):
            asn = f"AS{asn}"
        name = row.get("name") or row.get("aka") or row.get("name_long")
        website = row.get("website")
        _entity(entities, "asn", asn)
        _relation(relations, target_type, target, "matches_asn", "asn", asn)
        _entity(entities, "company", name)
        _relation(relations, "asn", asn or target, "operated_by", "company", name)
        _entity(entities, "url", website)
        _relation(relations, "company", name or target, "has_website", "url", website)
        count += sum(bool(v) for v in (asn, name, website))
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=count), finding_type="network_registry")


def _parse_ip_geo(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    connection = data.get("connection") or {}
    org = connection.get("org") or data.get("org") or data.get("company", {}).get("name")
    asn = connection.get("asn") or data.get("asn") or ""
    if asn and not str(asn).upper().startswith("AS"):
        asn = f"AS{asn}"
    country = data.get("country") or data.get("country_name")
    for entity_type, value, rel in (
        ("asn", asn, "announced_by"),
        ("company", org, "operated_by"),
        ("geo", country, "located_in"),
    ):
        _entity(entities, entity_type, value)
        _relation(relations, target_type, target, rel, entity_type, value)
    confidence = _confidence(result, item_count=sum(bool(v) for v in (org, asn, country)))
    return _finish(source, result, entities, relations, confidence=confidence, finding_type="ip_enrichment")


def _parse_attack_surface(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    services = data.get("data") or data.get("services") or data.get("result", {}).get("hits") or []
    if isinstance(services, dict):
        services = [services]
    count = 0
    for item in services[:50]:
        port = item.get("port") or item.get("observed_port")
        hostname_values = item.get("hostnames") or item.get("names") or []
        if port:
            service_id = f"{target}:{port}"
            _entity(entities, "service", service_id)
            _relation(relations, target_type, target, "exposes_service", "service", service_id)
            count += 1
        for host in _as_list(hostname_values):
            _entity(entities, "domain", host)
            _relation(relations, target_type, target, "has_hostname", "domain", host)
    confidence = _confidence(result, item_count=count)
    return _finish(source, result, entities, relations, confidence=confidence, finding_type="attack_surface")


def _parse_securitytrails(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    count = 0
    for label in data.get("subdomains", []) or []:
        host = str(label).strip(".")
        if "." not in host:
            host = f"{host}.{target}"
        host = host.lower().strip(".")
        if _host_suffix(host, target):
            _entity(entities, "domain", host)
            _relation(relations, target_type, target, "has_subdomain", "domain", host)
            count += 1
    records = data.get("records") or data.get("current_dns") or {}
    if isinstance(records, dict):
        items = records.items()
    else:
        items = []
    for record_type, values in items:
        for item in _as_list(values):
            value = item.get("value") if isinstance(item, dict) else item
            entity_type = "ip" if str(record_type).upper() in {"A", "AAAA"} else "dns_record"
            _entity(entities, entity_type, value)
            _relation(relations, target_type, target, f"dns_{str(record_type).lower()}", entity_type, value)
            count += int(bool(value))
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=count), finding_type="dns_subdomain")


def _parse_hunter(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = (result.data or {}).get("data", {}) if isinstance(result.data, dict) else {}
    emails = data.get("emails") or []
    if isinstance(emails, dict):
        emails = [emails]
    count = 0
    for item in emails:
        email = item.get("value") or item.get("email")
        confidence = item.get("confidence")
        _entity(entities, "email", email)
        _relation(relations, target_type, target, "uses_email", "email", email)
        if confidence is not None:
            _entity(entities, "confidence", f"hunter:{email}:{confidence}")
        for src in item.get("sources", []) or []:
            _entity(entities, "url", src.get("uri"))
            _relation(relations, "email", email, "evidenced_by", "url", src.get("uri"))
        count += int(bool(email))
    confidence = _confidence(result, item_count=count)
    return _finish(source, result, entities, relations, confidence=confidence, finding_type="email_discovery")


def _parse_hibp(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    breaches = result.data if isinstance(result.data, list) else []
    timeline = []
    for breach in breaches:
        name = breach.get("Name") or breach.get("Title")
        domain = breach.get("Domain")
        date = breach.get("BreachDate")
        _entity(entities, "breach", name)
        _relation(relations, target_type, target, "appeared_in_breach", "breach", name)
        _entity(entities, "domain", domain)
        _relation(relations, "breach", name, "breach_domain", "domain", domain)
        timeline.append(
            _timeline(
                source_id,
                target_type,
                target,
                kind="breached",
                confidence=0.75,
                description=f"HIBP breach {name}",
                when=date,
            )
        )
    if result.status_code == 404:
        return _finish(source, result, entities, relations, confidence=0.0, status="not_exists", reject_reason="no breach found", timeline=[])
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=len(breaches)), finding_type="breach_record", timeline=timeline)


def _parse_profile_source(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    entries = data.get("entry") or data.get("profile") or []
    for entry in _as_list(entries):
        display = entry.get("displayName") or entry.get("preferredUsername")
        _entity(entities, "profile", display)
        _relation(relations, target_type, target, "has_profile", "profile", display)
        for url in entry.get("urls", []) or []:
            value = url.get("value") if isinstance(url, dict) else url
            _entity(entities, "url", value)
            _relation(relations, "profile", display, "links_to", "url", value)
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=len(_as_list(entries))), finding_type="profile_record")


def _parse_emailrep(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    reputation = data.get("reputation")
    references = data.get("references") or data.get("details", {}).get("references")
    _entity(entities, "reputation", reputation)
    _relation(relations, target_type, target, "has_reputation", "reputation", reputation)
    confidence = _confidence(result, data_weight=0.1, item_count=int(bool(references)))
    return _finish(source, result, entities, relations, confidence=confidence, finding_type="email_reputation")


def _parse_company(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    companies = data.get("results", {}).get("companies") or data.get("items") or []
    count = 0
    for item in companies[:25]:
        company = item.get("company", item)
        name = company.get("name") or company.get("title")
        number = company.get("company_number") or company.get("number")
        status = company.get("current_status") or company.get("company_status")
        _entity(entities, "company", name)
        _relation(relations, target_type, target, "matches_company", "company", name)
        _entity(entities, "registry_id", number)
        _relation(relations, "company", name, "has_registry_id", "registry_id", number)
        _entity(entities, "status", status)
        count += int(bool(name))
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=count), finding_type="company_registry")


def _binding_value(binding: dict[str, Any], key: str) -> str:
    value = binding.get(key)
    if isinstance(value, dict):
        return str(value.get("value") or "")
    return str(value or "")


def _parse_wikidata(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("results", {}).get("bindings") or data.get("bindings") or []
    count = 0
    for row in rows[:25]:
        item = _binding_value(row, "item") or _binding_value(row, "entity")
        label = _binding_value(row, "itemLabel") or _binding_value(row, "label")
        website = _binding_value(row, "website") or _binding_value(row, "officialWebsite")
        qid = item.rsplit("/", 1)[-1] if item else ""
        _entity(entities, "wikidata_id", qid)
        _relation(relations, target_type, target, "matches_wikidata", "wikidata_id", qid)
        _entity(entities, "company" if target_type == "company" else "entity", label)
        _relation(relations, "wikidata_id", qid or target, "has_label", "entity", label)
        _entity(entities, "url", website)
        _relation(relations, "wikidata_id", qid or target, "has_website", "url", website)
        count += sum(bool(v) for v in (qid, label, website))
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=count), finding_type="knowledge_graph")


def _parse_username_profile(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data
    records: list[Any]
    if isinstance(data, dict) and "items" in data:
        records = data.get("items") or []
    elif isinstance(data, dict) and "users" in data:
        records = data.get("users") or []
    elif isinstance(data, dict) and "result" in data and isinstance(data["result"], list):
        records = data["result"]
    elif isinstance(data, list):
        records = data
    elif data:
        records = [data]
    else:
        records = []
    count = 0
    profile_urls: list[str] = []
    for record in records[:10]:
        if not isinstance(record, dict):
            continue
        login = (
            record.get("login")
            or record.get("username")
            or record.get("handle")
            or record.get("name")
            or record.get("id")
        )
        url = record.get("html_url") or record.get("web_url")
        if not url and str(source.get("id") or "").lower() == "github" and login:
            url = "https://github.com/" + str(login).lstrip("@")
        if not url:
            url = record.get("url")
        if login:
            _entity(entities, "username", login)
            _relation(relations, target_type, target, "same_username", "username", login)
        if url:
            count += 1
            profile_urls.append(str(url))
        elif login:
            count += 1
        _entity(entities, "profile", url)
        _relation(relations, "username", login or target, "has_profile", "profile", url)
    status = "exists" if count else "not_exists" if result.status_code == 404 else "unknown"
    confidence = _confidence(result, item_count=count) if count else 0.0
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=confidence,
        status=status,
        finding_type="username_profile",
        reject_reason="" if count else "no profile record",
        profile_url=profile_urls[0] if profile_urls else "",
    )


def _parse_github_search(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    items = data.get("items") or []
    count = 0
    for item in items[:25]:
        if not isinstance(item, dict):
            continue
        html_url = item.get("html_url") or item.get("url")
        path = item.get("path") or item.get("name")
        repo = item.get("repository") if isinstance(item.get("repository"), dict) else {}
        repo_name = repo.get("full_name") or repo.get("name")
        repo_url = repo.get("html_url")
        owner = repo.get("owner") if isinstance(repo.get("owner"), dict) else {}
        login = item.get("login") or owner.get("login")
        profile_url = item.get("html_url") if item.get("type") in {"User", "Organization"} else owner.get("html_url")
        _entity(entities, "url", html_url)
        _relation(relations, target_type, target, "matched_github_url", "url", html_url)
        _entity(entities, "repository", repo_name)
        _relation(relations, "url", html_url or target, "belongs_to_repository", "repository", repo_name)
        _entity(entities, "url", repo_url)
        _relation(relations, "repository", repo_name or target, "has_url", "url", repo_url)
        _entity(entities, "file_path", path)
        _relation(relations, "repository", repo_name or target, "contains_path", "file_path", path)
        _entity(entities, "username", login)
        _relation(relations, "repository", repo_name or target, "owned_by", "username", login)
        _entity(entities, "profile", profile_url)
        _relation(relations, "username", login or target, "has_profile", "profile", profile_url)
        count += sum(bool(value) for value in (html_url, repo_name, path, login))
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.1, item_count=count) if count else 0.0,
        status="exists" if count else "unknown",
        finding_type="developer_search_result",
        reject_reason="" if count else "no GitHub search result",
    )


def _parse_youtube(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    items = data.get("items") or []
    timeline = []
    count = 0
    primary_url = ""
    for item in items[:25]:
        if not isinstance(item, dict):
            continue
        item_id = item.get("id") if isinstance(item.get("id"), dict) else {}
        snippet = item.get("snippet") if isinstance(item.get("snippet"), dict) else {}
        video_id = item_id.get("videoId")
        channel_id = item_id.get("channelId") or snippet.get("channelId")
        title = snippet.get("title")
        channel_title = snippet.get("channelTitle")
        published_at = snippet.get("publishedAt")
        video_url = f"https://www.youtube.com/watch?v={video_id}" if video_id else ""
        channel_url = f"https://www.youtube.com/channel/{channel_id}" if channel_id else ""
        if not primary_url:
            primary_url = video_url or channel_url
        _entity(entities, "youtube_video", video_id)
        _relation(relations, target_type, target, "matched_video", "youtube_video", video_id)
        _entity(entities, "youtube_channel", channel_id)
        _relation(relations, target_type, target, "matched_channel", "youtube_channel", channel_id)
        _entity(entities, "title", title)
        _relation(relations, "youtube_video", video_id or target, "has_title", "title", title)
        _entity(entities, "display_name", channel_title)
        _relation(relations, "youtube_channel", channel_id or target, "has_display_name", "display_name", channel_title)
        _entity(entities, "url", video_url)
        _relation(relations, "youtube_video", video_id or target, "has_url", "url", video_url)
        _entity(entities, "url", channel_url)
        _relation(relations, "youtube_channel", channel_id or target, "has_url", "url", channel_url)
        if published_at:
            timeline.append(
                _timeline(
                    source_id,
                    target_type,
                    target,
                    kind="published",
                    confidence=0.68,
                    description="YouTube search result publication timestamp",
                    when=published_at,
                )
            )
        count += sum(bool(value) for value in (video_id, channel_id, title, channel_title))
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.1, item_count=count) if count else 0.0,
        status="exists" if count else "unknown",
        finding_type="media_search_result",
        timeline=timeline or None,
        reject_reason="" if count else "no YouTube search result",
        profile_url=primary_url,
    )


def _parse_google_cse(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    items = data.get("items") or []
    count = 0
    primary_url = ""
    for item in items[:25]:
        if not isinstance(item, dict):
            continue
        link = item.get("link")
        if link and not primary_url:
            primary_url = str(link)
        title = item.get("title")
        display = item.get("displayLink") or (urlparse(str(link)).netloc if link else "")
        snippet = item.get("snippet")
        _entity(entities, "url", link)
        _relation(relations, target_type, target, "matched_search_result", "url", link)
        _entity(entities, "domain", display)
        _relation(relations, "url", link or target, "hosted_on", "domain", display)
        _entity(entities, "title", title)
        _relation(relations, "url", link or target, "has_title", "title", title)
        _entity(entities, "search_snippet", snippet)
        _relation(relations, "url", link or target, "has_snippet", "search_snippet", snippet)
        count += sum(bool(value) for value in (link, display, title, snippet))
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.1, item_count=count) if count else 0.0,
        status="exists" if count else "unknown",
        finding_type="web_search_result",
        reject_reason="" if count else "no search result",
        profile_url=primary_url,
    )


def _parse_mastodon_profile(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    acct = data.get("acct") or data.get("username") or data.get("account")
    username = data.get("username") or acct
    profile_url = data.get("url")
    stable_id = data.get("id")
    display = data.get("display_name") or data.get("displayName")
    created_at = data.get("created_at") or data.get("createdAt")
    if acct and "@" not in str(acct) and result.url:
        from urllib.parse import urlparse

        host = urlparse(result.url).netloc
        acct = f"{acct}@{host}" if host else acct
    _entity(entities, "username", acct or username)
    _relation(relations, target_type, target, "same_username", "username", acct or username)
    _entity(entities, "profile", profile_url)
    _relation(relations, "username", acct or username or target, "has_profile", "profile", profile_url)
    _entity(entities, "stable_id", stable_id)
    _relation(relations, "username", acct or username or target, "same_stable_id", "stable_id", stable_id)
    _entity(entities, "display_name", display)
    _relation(relations, "username", acct or username or target, "has_display_name", "display_name", display)
    count = sum(bool(value) for value in (acct or username, profile_url, stable_id, display))
    timeline = []
    if created_at:
        timeline.append(
            _timeline(
                source_id,
                "username",
                str(acct or username or target),
                kind="profile_created",
                confidence=0.72,
                description="Mastodon profile creation timestamp",
                when=created_at,
            )
        )
    status = "exists" if count else "not_exists" if result.status_code == 404 else "unknown"
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, item_count=count) if count else 0.0,
        status=status,
        finding_type="fediverse_profile",
        timeline=timeline or None,
        reject_reason="" if count else "no Mastodon account record",
        profile_url=str(profile_url or ""),
    )


def _parse_wallet(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    nested = data.get("data", {})
    address_data = {}
    if isinstance(nested, dict):
        address_data = nested.get(target.lower()) or nested.get(target) or next(iter(nested.values()), {})
    stats = address_data.get("address") if isinstance(address_data, dict) else {}
    if not isinstance(stats, dict):
        stats = {}
    tx_count = (
        data.get("n_tx")
        or data.get("chain_stats", {}).get("tx_count")
        or stats.get("transaction_count")
        or stats.get("transactions")
    )
    balance = data.get("final_balance") or stats.get("balance") if isinstance(stats, dict) else None
    _entity(entities, "wallet", target)
    _entity(entities, "transaction_count", tx_count)
    _relation(relations, "wallet", target, "has_transaction_count", "transaction_count", tx_count)
    _entity(entities, "balance", balance)
    _relation(relations, "wallet", target, "has_balance", "balance", balance)
    confidence = _confidence(result, item_count=sum(bool(v) for v in (tx_count, balance)))
    return _finish(source, result, entities, relations, confidence=confidence, finding_type="wallet_activity")


def _parse_phone(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    valid = data.get("valid") if "valid" in data else data.get("phone_valid")
    number = data.get("international_format") or data.get("phone_number") or data.get("phone") or target
    carrier = data.get("carrier")
    country = data.get("country_name") or data.get("country") or data.get("country_code")
    line_type = data.get("line_type") or data.get("phone_type")
    _entity(entities, "phone", number)
    _relation(relations, target_type, target, "normalized_as", "phone", number)
    for entity_type, value, rel in (
        ("carrier", carrier, "uses_carrier"),
        ("geo", country, "located_in"),
        ("phone_type", line_type, "has_line_type"),
    ):
        _entity(entities, entity_type, value)
        _relation(relations, "phone", number, rel, entity_type, value)
    status = "exists" if valid else "not_exists" if valid is False else "unknown"
    confidence = _confidence(result, item_count=sum(bool(v) for v in (valid, carrier, country, line_type))) if valid else 0.0
    return _finish(source, result, entities, relations, confidence=confidence, status=status, finding_type="phone_lookup", reject_reason="" if valid else "phone validation failed")


def _parse_nominatim(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    rows = result.data if isinstance(result.data, list) else []
    count = 0
    for row in rows[:10]:
        if not isinstance(row, dict):
            continue
        display = row.get("display_name") or row.get("name")
        osm_type = row.get("osm_type")
        osm_id = row.get("osm_id")
        stable_id = f"{osm_type}/{osm_id}" if osm_type and osm_id else row.get("place_id")
        lat = row.get("lat")
        lon = row.get("lon")
        class_name = row.get("class")
        place_type = row.get("type")
        bbox = ",".join(str(item) for item in row.get("boundingbox", []) or [])
        _entity(entities, "location", display)
        _relation(relations, target_type, target, "matches_location", "location", display)
        _entity(entities, "osm_id", stable_id)
        _relation(relations, "location", display or target, "has_osm_id", "osm_id", stable_id)
        if lat and lon:
            point = f"{lat},{lon}"
            _entity(entities, "geo", point)
            _relation(relations, "location", display or target, "located_at", "geo", point)
        _entity(entities, "place_type", f"{class_name}:{place_type}" if class_name or place_type else "")
        _relation(relations, "location", display or target, "has_place_type", "place_type", f"{class_name}:{place_type}" if class_name or place_type else "")
        _entity(entities, "bounding_box", bbox)
        _relation(relations, "location", display or target, "has_bounding_box", "bounding_box", bbox)
        count += sum(bool(value) for value in (display, stable_id, lat and lon, class_name or place_type))
    status = "exists" if count else "not_exists" if result.status_code == 404 else "unknown"
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.15, item_count=count) if count else 0.0,
        status=status,
        finding_type="geocoding_result",
        reject_reason="" if count else "no geocoding candidates",
    )


def _parse_open_measures(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("results") or data.get("items") or data.get("data") or data.get("posts") or []
    if isinstance(rows, dict):
        rows = rows.get("results") or rows.get("items") or [rows]
    count = 0
    timeline = []
    for row in rows[:50]:
        if not isinstance(row, dict):
            continue
        platform = row.get("platform") or row.get("source") or row.get("network")
        author = row.get("author") or row.get("username") or row.get("handle") or row.get("account")
        post_id = row.get("id") or row.get("post_id") or row.get("url")
        url = row.get("url") or row.get("permalink")
        text = row.get("text") or row.get("content") or row.get("title") or row.get("body")
        narrative = row.get("narrative") or row.get("topic") or row.get("label")
        when = row.get("created_at") or row.get("published_at") or row.get("timestamp") or row.get("date")
        post_key = f"{platform}:{post_id}" if platform and post_id else post_id
        _entity(entities, "social_platform", platform)
        _entity(entities, "username", author)
        _entity(entities, "social_post", post_key)
        _entity(entities, "url", url)
        _entity(entities, "narrative", narrative)
        _relation(relations, target_type, target, "matches_social_post", "social_post", post_key)
        _relation(relations, "social_post", post_key or target, "published_on", "social_platform", platform)
        _relation(relations, "social_post", post_key or target, "authored_by", "username", author)
        _relation(relations, "social_post", post_key or target, "evidenced_by", "url", url)
        _relation(relations, "social_post", post_key or target, "has_narrative", "narrative", narrative)
        if text:
            snippet = str(text).strip()[:160]
            _entity(entities, "text_snippet", snippet)
            _relation(relations, "social_post", post_key or target, "has_text_snippet", "text_snippet", snippet)
        if when:
            timeline.append(
                _timeline(
                    source_id,
                    "social_post",
                    str(post_key or target),
                    kind="social_post_observed",
                    confidence=0.62,
                    description=f"Open Measures observation on {platform or 'unknown platform'}",
                    when=when,
                )
            )
        count += sum(bool(value) for value in (platform, author, post_key, url, text, narrative))
    status = "exists" if count else "unknown"
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.1, item_count=count) if count else 0.0,
        status=status,
        finding_type="social_intel_observation",
        timeline=timeline or None,
        reject_reason="" if count else "no social intelligence records",
    )


def _parse_urlscan(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("results") or [data.get("page", {})]
    count = 0
    timeline = []
    for row in rows[:25]:
        page = row.get("page", row)
        task = row.get("task", {})
        url = page.get("url") or task.get("url")
        domain = page.get("domain")
        ip = page.get("ip")
        date = task.get("time") or row.get("indexedAt")
        _entity(entities, "url", url)
        _relation(relations, target_type, target, "observed_urlscan_url", "url", url)
        _entity(entities, "domain", domain)
        _relation(relations, "url", url or target, "hosted_on_domain", "domain", domain)
        _entity(entities, "ip", ip)
        _relation(relations, "url", url or target, "resolved_to", "ip", ip)
        if date:
            timeline.append(_timeline(source_id, target_type, target, kind="url_scanned", confidence=0.7, description="urlscan observation", when=date))
        count += int(bool(url or domain or ip))
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=count), finding_type="urlscan_observation", timeline=timeline or None)


def _parse_tineye(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("results") or data.get("matches") or data.get("data") or []
    if isinstance(rows, dict):
        rows = rows.get("results") or rows.get("matches") or [rows]
    count = 0
    for row in rows[:50]:
        if not isinstance(row, dict):
            continue
        match_url = row.get("image_url") or row.get("image") or row.get("match_url") or row.get("url")
        score = row.get("score") or row.get("similarity")
        _entity(entities, "image_match", match_url)
        _relation(relations, target_type, target, "visually_matches", "image_match", match_url)
        if score not in {None, ""}:
            score_text = str(score)
            _entity(entities, "match_score", score_text)
            _relation(relations, "image_match", match_url or target, "has_score", "match_score", score_text)
        backlinks = row.get("backlinks") or row.get("source_pages") or []
        if isinstance(backlinks, dict):
            backlinks = [backlinks]
        for backlink in backlinks[:10]:
            page_url = backlink.get("url") or backlink.get("backlink") if isinstance(backlink, dict) else backlink
            _entity(entities, "url", page_url)
            _relation(relations, "image_match", match_url or target, "found_on", "url", page_url)
            count += int(bool(page_url))
        count += sum(bool(value) for value in (match_url, score))
    status = "exists" if count else "unknown"
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.08, item_count=count) if count else 0.0,
        status=status,
        finding_type="reverse_image_match",
        timeline=[
            _timeline(
                source_id,
                target_type,
                target,
                kind="reverse_image_searched",
                confidence=0.58 if count else 0.0,
                description="TinEye reverse image search result; matches require analyst review",
            )
        ],
        reject_reason="" if count else "no reverse image matches",
    )


def _parse_threat_intel(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    attrs = data.get("data", {}).get("attributes", {}) if isinstance(data.get("data"), dict) else data
    verdict = (
        attrs.get("reputation")
        or attrs.get("classification")
        or attrs.get("threat_score")
        or attrs.get("abuseConfidenceScore")
        or data.get("query_status")
    )
    _entity(entities, "threat_verdict", verdict)
    _relation(relations, target_type, target, "has_threat_verdict", "threat_verdict", verdict)
    pulses = data.get("pulse_info", {}).get("count") or attrs.get("last_analysis_stats")
    count = int(bool(verdict)) + int(bool(pulses))
    confidence = _confidence(result, data_weight=0.1, item_count=count)
    return _finish(source, result, entities, relations, confidence=confidence, finding_type="threat_intel")


def _parse_virustotal(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    obj = data.get("data", data)
    attrs = obj.get("attributes", {}) if isinstance(obj, dict) else {}
    upload = data.get("_bedniiosint_upload") if isinstance(data.get("_bedniiosint_upload"), dict) else {}
    vt_id = obj.get("id") if isinstance(obj, dict) else ""
    vt_type = obj.get("type") if isinstance(obj, dict) else ""
    if target_type in {"file", "image", "document"} or upload:
        meta = data.get("meta") if isinstance(data.get("meta"), dict) else {}
        file_info = meta.get("file_info") if isinstance(meta.get("file_info"), dict) else {}
        analysis_id = str(vt_id or "")
        sha256 = str(
            upload.get("sha256")
            or file_info.get("sha256")
            or attrs.get("sha256")
            or ""
        )
        filename = str(upload.get("filename") or target)
        warning = str(upload.get("privacy_warning") or "file content submitted to third-party provider")
        _entity(entities, "analysis", analysis_id)
        _relation(relations, target_type, target, "submitted_for_analysis", "analysis", analysis_id)
        _entity(entities, "hash", sha256)
        _relation(relations, target_type, target, "has_sha256", "hash", sha256)
        _entity(entities, "filename", filename)
        _relation(relations, target_type, target, "has_filename", "filename", filename)
        _entity(entities, "privacy_warning", warning)
        _relation(relations, target_type, target, "has_privacy_warning", "privacy_warning", warning)
        count = sum(bool(value) for value in (analysis_id, sha256, filename, warning, vt_type))
        timeline = [
            _timeline(
                source_id,
                target_type,
                target,
                kind="file_submitted",
                confidence=0.62,
                description="VirusTotal accepted a file submission for analysis",
            )
        ]
        return _finish(
            source,
            result,
            entities,
            relations,
            confidence=_confidence(result, data_weight=0.05, item_count=count),
            status="submitted" if result.status == "ok" else result.status,
            finding_type="file_upload_virustotal",
            timeline=timeline,
        )
    stats = attrs.get("last_analysis_stats") or {}
    reputation = attrs.get("reputation")
    malicious = stats.get("malicious") or 0
    suspicious = stats.get("suspicious") or 0
    verdict = f"malicious={malicious} suspicious={suspicious} reputation={reputation}"
    _entity(entities, "threat_verdict", verdict)
    _relation(relations, target_type, target, "has_threat_verdict", "threat_verdict", verdict)
    _entity(entities, target_type, vt_id)
    _relation(relations, target_type, target, "provider_id", target_type, vt_id)
    count = int(bool(vt_id)) + int(bool(stats)) + int(bool(reputation))
    for record in attrs.get("last_dns_records", []) or []:
        value = record.get("value")
        record_type = record.get("type", "dns").lower()
        entity_type = "ip" if record_type in {"a", "aaaa"} else "domain"
        _entity(entities, entity_type, value)
        _relation(relations, target_type, target, f"vt_dns_{record_type}", entity_type, value)
        count += int(bool(value))
    return _finish(source, result, entities, relations, confidence=_confidence(result, data_weight=0.1, item_count=count), finding_type="threat_intel_virustotal")


def _parse_alienvault_otx(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    pulse_count = data.get("pulse_info", {}).get("count")
    validation = data.get("validation") or []
    verdict = f"pulses={pulse_count or 0}"
    _entity(entities, "threat_verdict", verdict)
    _relation(relations, target_type, target, "has_threat_verdict", "threat_verdict", verdict)
    count = int(bool(pulse_count))
    for item in _as_list(validation):
        name = item.get("name") if isinstance(item, dict) else item
        _entity(entities, "validation", name)
        _relation(relations, target_type, target, "validated_by", "validation", name)
        count += int(bool(name))
    for section in ("passive_dns", "url_list"):
        rows = data.get(section, [])
        if isinstance(rows, dict):
            rows = rows.get("passive_dns") or rows.get("url_list") or rows.get("data") or []
        for row in rows[:25]:
            value = row.get("hostname") or row.get("address") or row.get("url") if isinstance(row, dict) else row
            entity_type = "url" if str(value).startswith("http") else "domain"
            _entity(entities, entity_type, value)
            _relation(relations, target_type, target, f"otx_related_{entity_type}", entity_type, value)
            count += int(bool(value))
    return _finish(source, result, entities, relations, confidence=_confidence(result, data_weight=0.1, item_count=count), finding_type="threat_intel_otx")


def _parse_abuseipdb(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data.get("data", result.data) if isinstance(result.data, dict) else {}
    score = data.get("abuseConfidenceScore")
    total_reports = data.get("totalReports")
    isp = data.get("isp")
    domain = data.get("domain")
    country = data.get("countryCode")
    verdict = f"abuse_score={score} reports={total_reports}"
    _entity(entities, "threat_verdict", verdict)
    _relation(relations, target_type, target, "has_threat_verdict", "threat_verdict", verdict)
    for entity_type, value, rel in (
        ("company", isp, "operated_by"),
        ("domain", domain, "has_hostname"),
        ("geo", country, "located_in"),
    ):
        _entity(entities, entity_type, value)
        _relation(relations, target_type, target, rel, entity_type, value)
    count = sum(bool(v) for v in (score, total_reports, isp, domain, country))
    return _finish(source, result, entities, relations, confidence=_confidence(result, data_weight=0.1, item_count=count), finding_type="ip_reputation")


def _parse_greynoise(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    classification = data.get("classification")
    name = data.get("name")
    last_seen = data.get("last_seen")
    verdict = f"classification={classification} noise={data.get('noise')} riot={data.get('riot')}"
    _entity(entities, "threat_verdict", verdict)
    _relation(relations, target_type, target, "has_threat_verdict", "threat_verdict", verdict)
    _entity(entities, "actor", name)
    _relation(relations, target_type, target, "associated_with", "actor", name)
    timeline = []
    if last_seen:
        timeline.append(_timeline(source_id, target_type, target, kind="last_seen", confidence=0.6, description="GreyNoise last seen", when=last_seen))
    count = sum(bool(v) for v in (classification, name, last_seen))
    return _finish(source, result, entities, relations, confidence=_confidence(result, data_weight=0.1, item_count=count), finding_type="ip_behavior", timeline=timeline or None)


def _parse_urlhaus(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("urls") or data.get("payloads") or []
    if not rows and data.get("url"):
        rows = [data]
    count = 0
    timeline = []
    for row in rows[:50]:
        url = row.get("url") or row.get("urlhaus_reference")
        status = row.get("url_status") or row.get("query_status")
        threat = row.get("threat") or row.get("tags")
        when = row.get("date_added") or row.get("firstseen")
        _entity(entities, "url", url)
        _relation(relations, target_type, target, "urlhaus_related_url", "url", url)
        _entity(entities, "threat_verdict", f"{status}:{threat}")
        _relation(relations, "url", url or target, "has_threat_verdict", "threat_verdict", f"{status}:{threat}")
        if when:
            timeline.append(_timeline(source_id, "url", url or target, kind="urlhaus_observed", confidence=0.65, description="URLhaus observation", when=when))
        count += sum(bool(v) for v in (url, status, threat))
    status = "exists" if count else "not_exists" if data.get("query_status") == "no_results" else "unknown"
    reject = "" if count else "no URLhaus records"
    return _finish(source, result, entities, relations, confidence=_confidence(result, data_weight=0.1, item_count=count), status=status, finding_type="url_reputation", timeline=timeline or None, reject_reason=reject)


def _parse_threatfox(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("data") or data.get("iocs") or []
    if isinstance(rows, dict):
        rows = [rows]
    count = 0
    timeline = []
    for row in rows[:50]:
        if not isinstance(row, dict):
            continue
        ioc = row.get("ioc") or row.get("indicator") or row.get("value")
        ioc_type = row.get("ioc_type") or row.get("type") or "ioc"
        malware = row.get("malware") or row.get("malware_printable") or row.get("threat_type")
        first_seen = row.get("first_seen") or row.get("last_seen")
        _entity(entities, str(ioc_type), ioc)
        _relation(relations, target_type, target, "threatfox_related_ioc", str(ioc_type), ioc)
        _entity(entities, "malware_family", malware)
        _relation(relations, str(ioc_type), str(ioc or target), "associated_with_malware", "malware_family", malware)
        if first_seen:
            timeline.append(_timeline(source_id, str(ioc_type), str(ioc or target), kind="ioc_first_seen", confidence=0.68, description="ThreatFox IOC observation", when=first_seen))
        count += sum(bool(value) for value in (ioc, malware, first_seen))
    status = "exists" if count else "not_exists" if data.get("query_status") == "no_result" else "unknown"
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.1, item_count=count) if count else 0.0,
        status=status,
        finding_type="threatfox_ioc",
        timeline=timeline or None,
        reject_reason="" if count else "no ThreatFox IOC records",
    )


def _parse_malwarebazaar(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("data") or []
    if isinstance(rows, dict):
        rows = [rows]
    count = 0
    timeline = []
    for row in rows[:25]:
        if not isinstance(row, dict):
            continue
        sha256 = row.get("sha256_hash") or row.get("sha256") or row.get("hash")
        signature = row.get("signature")
        file_type = row.get("file_type") or row.get("file_type_mime")
        first_seen = row.get("first_seen")
        _entity(entities, "hash", sha256)
        _relation(relations, target_type, target, "matches_malware_hash", "hash", sha256)
        _entity(entities, "malware_family", signature)
        _relation(relations, "hash", sha256 or target, "classified_as", "malware_family", signature)
        _entity(entities, "file_type", file_type)
        _relation(relations, "hash", sha256 or target, "has_file_type", "file_type", file_type)
        if first_seen:
            timeline.append(_timeline(source_id, "hash", str(sha256 or target), kind="malware_first_seen", confidence=0.7, description="MalwareBazaar sample observation", when=first_seen))
        count += sum(bool(value) for value in (sha256, signature, file_type, first_seen))
    status = "exists" if count else "not_exists" if data.get("query_status") == "hash_not_found" else "unknown"
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.1, item_count=count) if count else 0.0,
        status=status,
        finding_type="malware_hash_reputation",
        timeline=timeline or None,
        reject_reason="" if count else "no MalwareBazaar hash records",
    )


def _parse_gdelt(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("articles") or data.get("results") or []
    count = 0
    timeline = []
    for row in rows[:50]:
        if not isinstance(row, dict):
            continue
        url = row.get("url")
        title = row.get("title")
        domain = row.get("domain") or row.get("sourceDomain")
        when = row.get("seendate") or row.get("date")
        _entity(entities, "url", url)
        _relation(relations, target_type, target, "mentioned_by_article", "url", url)
        _entity(entities, "title", title)
        _relation(relations, "url", url or target, "has_title", "title", title)
        _entity(entities, "domain", domain)
        _relation(relations, "url", url or target, "published_by_domain", "domain", domain)
        if when:
            timeline.append(_timeline(source_id, "url", str(url or target), kind="news_seen", confidence=0.55, description="GDELT article observation", when=when))
        count += sum(bool(value) for value in (url, title, domain, when))
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.05, item_count=count) if count else 0.0,
        status="exists" if count else "unknown",
        finding_type="media_mention",
        timeline=timeline or None,
        reject_reason="" if count else "no GDELT articles",
    )


def _parse_common_crawl(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    rows = result.data if isinstance(result.data, list) else []
    count = 0
    timeline = []
    for row in rows[:50]:
        if not isinstance(row, dict):
            continue
        url = row.get("url") or row.get("cdx-api") or row.get("api")
        crawl_id = row.get("id") or row.get("name")
        when = row.get("timegate") or row.get("from")
        _entity(entities, "url", url)
        _relation(relations, target_type, target, "seen_in_common_crawl", "url", url)
        _entity(entities, "crawl_id", crawl_id)
        _relation(relations, "url", url or target, "in_crawl_index", "crawl_id", crawl_id)
        if when:
            timeline.append(_timeline(source_id, target_type, target, kind="crawl_index_seen", confidence=0.5, description="Common Crawl index observation", when=when))
        count += sum(bool(value) for value in (url, crawl_id, when))
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.05, item_count=count) if count else 0.0,
        status="exists" if count else "unknown",
        finding_type="crawl_index",
        timeline=timeline or None,
        reject_reason="" if count else "no Common Crawl records",
    )


def _parse_technology(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict | list) else {}
    rows: list[Any] = []
    if isinstance(data, list):
        rows = data
    elif isinstance(data, dict):
        rows = data.get("technologies") or data.get("Results") or data.get("results") or []
        if isinstance(rows, dict):
            rows = rows.get("technologies") or rows.get("Result") or [rows]
    count = 0
    for row in rows[:100]:
        if not isinstance(row, dict):
            continue
        name = row.get("name") or row.get("Name") or row.get("tag") or row.get("technology")
        version = row.get("version") or row.get("Version")
        category = row.get("category") or row.get("Category") or row.get("categories")
        tech_id = f"{name} {version}".strip() if version else name
        _entity(entities, "technology", tech_id)
        _relation(relations, target_type, target, "uses_technology", "technology", tech_id)
        _entity(entities, "technology_category", category)
        _relation(relations, "technology", tech_id or target, "has_category", "technology_category", category)
        count += sum(bool(value) for value in (name, version, category))
    return _finish(
        source,
        result,
        entities,
        relations,
        confidence=_confidence(result, data_weight=0.05, item_count=count) if count else 0.0,
        status="exists" if count else "unknown",
        finding_type="technology_fingerprint",
        reject_reason="" if count else "no technology records",
    )


def _parse_aggregator(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    data = result.data if isinstance(result.data, dict) else {}
    rows = data.get("results") or data.get("items") or data.get("data") or []
    if isinstance(rows, dict):
        rows = rows.get("results") or rows.get("items") or [rows]
    count = 0
    for row in rows[:100]:
        if not isinstance(row, dict):
            continue
        entity_type = row.get("type") or row.get("entity_type") or row.get("kind") or "artifact"
        value = row.get("value") or row.get("entity_value") or row.get("url") or row.get("id")
        rel = row.get("relation") or row.get("rel") or f"aggregator_{entity_type}"
        _entity(entities, str(entity_type), value)
        _relation(relations, target_type, target, str(rel), str(entity_type), value)
        count += int(bool(value))
    return _finish(source, result, entities, relations, confidence=_confidence(result, item_count=count), finding_type="aggregator_result", status="exists" if count else "unknown", reject_reason="" if count else "no aggregator records")


def _parse_wayback(source: dict[str, Any], result) -> dict[str, Any]:
    entities, relations, target_type, target, source_id = _base(source, result)
    rows = result.data if isinstance(result.data, list) else []
    header = rows[0] if rows and isinstance(rows[0], list) else []
    timeline = []
    count = 0
    for row in rows[1:50]:
        if not isinstance(row, list):
            continue
        data = dict(zip(header, row))
        url = data.get("original")
        timestamp = data.get("timestamp", "")
        when = ""
        if len(timestamp) >= 8:
            when = f"{timestamp[:4]}-{timestamp[4:6]}-{timestamp[6:8]}T00:00:00+00:00"
        _entity(entities, "url", url)
        _relation(relations, target_type, target, "archived_url", "url", url)
        timeline.append(_timeline(source_id, target_type, target, kind="archived", confidence=0.6, description="Wayback CDX capture", when=when))
        count += 1
    return _finish(source, result, entities, relations, confidence=_confidence(result, data_weight=0.1, item_count=count), finding_type="archive_record", timeline=timeline)
