from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any

from ..core.plugins import all_plugins, discover_plugin_manifests
from .adapters import auth_env_vars, configured, source_schema
from .policy import policy_for_source, risk_for_source
from .source_catalog import load_catalog


TYPED_PARSER_API_IDS = {
    "abuseipdb",
    "alienvault_otx",
    "bgpview",
    "blockchair",
    "blockchain_info",
    "blockstream",
    "bluesky",
    "censys",
    "builtwith",
    "codeforces",
    "cloudflare_dns",
    "common_crawl",
    "companies_house",
    "cratesio",
    "crtsh",
    "dockerhub",
    "duolingo",
    "emailrep",
    "gdelt",
    "github",
    "github_search",
    "gitlab",
    "google_cse",
    "google_dns",
    "gravatar",
    "greynoise",
    "hackertarget",
    "hackernews",
    "hibp",
    "hunter",
    "ipinfo",
    "ipwhois",
    "lichess",
    "mastodon_lookup",
    "malwarebazaar",
    "nominatim",
    "numverify",
    "opencorporates",
    "open_measures",
    "osintly_api",
    "peeringdb",
    "rdap",
    "reddit_about",
    "securitytrails",
    "shodan",
    "twilio_lookup",
    "threatfox",
    "tineye",
    "urlhaus",
    "urlscan",
    "veriphone",
    "virustotal",
    "wayback_cdx",
    "wappalyzer",
    "wikidata",
    "youtube",
}

MEDIUM_TERMS_RISK_IDS = {
    "companies_house",
    "emailrep",
    "hibp",
    "hunter",
    "nominatim",
    "open_measures",
    "osintly_api",
    "reddit_about",
    "shodan",
    "twilio_lookup",
    "tineye",
    "builtwith",
    "wappalyzer",
    "urlscan",
}


@dataclass
class SourceEntry:
    id: str
    name: str
    kind: str
    inputs: list[str] = field(default_factory=list)
    outputs: list[str] = field(default_factory=list)
    categories: list[str] = field(default_factory=list)
    auth: str = "none"
    env_vars: list[str] = field(default_factory=list)
    runnable: bool = False
    configured: bool = True
    endpoints: int = 0
    docs_url: str = ""
    notes: str = ""
    adapter: str = ""
    source_maturity: str = "catalog_only"
    terms_risk: str = "low"
    cache_policy: str = "ttl_cache_allowed"
    quota_policy: str = "public_rate_limited"
    priority: str = ""
    product_value: str = ""
    setup_hint: str = ""
    requires_opt_in: bool = False
    input_schema: dict[str, Any] = field(default_factory=dict)
    output_schema: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "kind": self.kind,
            "inputs": self.inputs,
            "outputs": self.outputs,
            "categories": self.categories,
            "auth": self.auth,
            "env_vars": self.env_vars,
            "runnable": self.runnable,
            "configured": self.configured,
            "endpoints": self.endpoints,
            "docs_url": self.docs_url,
            "notes": self.notes,
            "adapter": self.adapter,
            "source_maturity": self.source_maturity,
            "terms_risk": self.terms_risk,
            "cache_policy": self.cache_policy,
            "quota_policy": self.quota_policy,
            "priority": self.priority,
            "product_value": self.product_value,
            "setup_hint": self.setup_hint,
            "requires_opt_in": self.requires_opt_in,
            "input_schema": self.input_schema,
            "output_schema": self.output_schema,
        }


def _env_hints(source_id: str, auth: str) -> list[str]:
    return auth_env_vars(source_id, auth)


def _configured(env_vars: list[str]) -> bool:
    return configured(env_vars)


def _api_maturity(api: dict[str, Any]) -> str:
    if not api.get("endpoints"):
        return "catalog_only"
    if str(api.get("id", "")).lower() in TYPED_PARSER_API_IDS:
        return "typed_parser"
    return "generic_http"


def _api_terms_risk(api: dict[str, Any]) -> str:
    source_id = str(api.get("id", "")).lower()
    policy_risk = risk_for_source(source_id, fallback="", name=str(api.get("name", "")))
    if policy_risk:
        return policy_risk
    if source_id in MEDIUM_TERMS_RISK_IDS:
        return "medium"
    if str(api.get("auth", "none")).lower() not in {"none", "", "optional"}:
        return "medium"
    return "low"


def _api_quota_policy(auth: str) -> str:
    if auth.lower() in {"none", ""}:
        return "public_rate_limited"
    if "optional" in auth.lower() or auth.lower().startswith("none_"):
        return "optional_key_quota"
    return "keyed_quota"


def registry_entries(
    catalog: dict[str, Any] | None = None,
    *,
    plugin_dir=None,
) -> list[SourceEntry]:
    data = catalog or load_catalog()
    rows: list[SourceEntry] = []

    for plugin in all_plugins():
        rows.append(
            SourceEntry(
                id=f"module:{plugin.name}",
                name=plugin.name,
                kind="module",
                inputs=plugin.consumes,
                outputs=plugin.produces,
                categories=["builtin"],
                runnable=True,
                configured=True,
                adapter=f"builtin:{plugin.name}",
                source_maturity="tested_builtin",
                terms_risk="low",
                quota_policy="local_budget",
                priority="P0",
                product_value="high",
                setup_hint="built-in module; no API key setup required",
                input_schema={
                    "target": {"type": "string", "required": True},
                    "input_types": plugin.consumes,
                },
                output_schema={"produces": plugin.produces, "type": "case_summary"},
                notes="Built-in runnable BEDNIIOSINT module.",
            )
        )

    for manifest in discover_plugin_manifests(plugin_dir):
        rows.append(
            SourceEntry(
                id=f"plugin:{manifest.name}",
                name=manifest.name,
                kind="plugin",
                inputs=manifest.consumes,
                outputs=manifest.produces,
                categories=["local"],
                auth=manifest.auth,
                env_vars=manifest.env_vars,
                runnable=bool(manifest.entrypoint),
                configured=_configured(manifest.env_vars),
                adapter=manifest.entrypoint,
                source_maturity="plugin_manifest",
                terms_risk="medium" if manifest.auth not in {"none", "", "optional"} else "low",
                quota_policy=_api_quota_policy(manifest.auth),
                setup_hint=(
                    "set " + ", ".join(manifest.env_vars)
                    if manifest.env_vars
                    else "plugin does not require API key setup"
                ),
                input_schema={
                    "target": {"type": "string", "required": True},
                    "input_types": manifest.consumes,
                    "auth": manifest.auth,
                    "env_vars": manifest.env_vars,
                },
                output_schema={"produces": manifest.produces, "type": "plugin_result"},
                notes=manifest.description or "Local BEDNIIOSINT plugin manifest.",
            )
        )

    for api in data.get("api_sources", []):
        auth = api.get("auth", "none")
        env_vars = _env_hints(api["id"], auth)
        input_schema, output_schema = source_schema(api)
        maturity = _api_maturity(api)
        policy = policy_for_source(api["id"], name=str(api.get("name", "")))
        rows.append(
            SourceEntry(
                id=f"api:{api['id']}",
                name=api.get("name", api["id"]),
                kind="api",
                inputs=list(api.get("inputs", [])),
                categories=list(api.get("category", [])),
                auth=auth,
                env_vars=env_vars,
                runnable=bool(api.get("endpoints")),
                configured=_configured(env_vars),
                endpoints=len(api.get("endpoints", [])),
                docs_url=api.get("docs_url", ""),
                adapter="catalog-http",
                source_maturity=maturity,
                terms_risk=_api_terms_risk(api),
                cache_policy=policy.cache_policy if policy else "ttl_cache_allowed",
                quota_policy=_api_quota_policy(str(auth)),
                priority=policy.priority if policy else "",
                product_value=policy.product_value if policy else "",
                setup_hint=(
                    f"set {', '.join(env_vars)}; see {api.get('docs_url', '')}"
                    if env_vars
                    else (policy.setup_hint if policy else "no API key setup required")
                ),
                requires_opt_in=bool(policy.requires_opt_in) if policy else False,
                input_schema=input_schema,
                output_schema=output_schema,
                notes=(
                    "Catalog API with typed parser; raw parser output is preserved."
                    if maturity == "typed_parser"
                    else "Catalog API with generic HTTP adapter; raw parser output is preserved."
                ),
            )
        )

    return sorted(rows, key=lambda item: (item.kind, item.id))


def filter_registry(
    entries: list[SourceEntry] | None = None,
    *,
    input_type: str | None = None,
    kind: str | None = None,
    auth: str | None = None,
    runnable: bool | None = None,
) -> list[SourceEntry]:
    rows = entries or registry_entries()
    out: list[SourceEntry] = []
    for row in rows:
        if input_type and input_type.lower() not in {item.lower() for item in row.inputs}:
            continue
        if kind and row.kind.lower() != kind.lower():
            continue
        if auth and row.auth.lower() != auth.lower():
            continue
        if runnable is not None and row.runnable != runnable:
            continue
        out.append(row)
    return out


def registry_summary(entries: list[SourceEntry] | None = None) -> dict[str, Any]:
    rows = entries or registry_entries()
    return {
        "sources": len(rows),
        "runnable": sum(1 for row in rows if row.runnable),
        "configured": sum(1 for row in rows if row.configured),
        "modules": sum(1 for row in rows if row.kind == "module"),
        "apis": sum(1 for row in rows if row.kind == "api"),
        "plugins": sum(1 for row in rows if row.kind == "plugin"),
        "auth_required": sum(1 for row in rows if row.auth not in {"none", ""}),
        "typed_parsers": sum(1 for row in rows if row.source_maturity == "typed_parser"),
        "terms_risk": {
            risk: sum(1 for row in rows if row.terms_risk == risk)
            for risk in sorted({row.terms_risk for row in rows})
        },
        "inputs": sorted({item for row in rows for item in row.inputs}),
    }
