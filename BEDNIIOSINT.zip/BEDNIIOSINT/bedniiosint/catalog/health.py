from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..core.secret_store import missing_secret_names, secret_configured
from .adapters import adapter_for
from .registry import SourceEntry, registry_entries


MAINTENANCE_ERROR_VARIANTS = {"rate_limited", "http_error", "schema_changed", "not_found"}


@dataclass(frozen=True)
class ApiKeyStatus:
    name: str
    configured: bool
    required: bool
    sources: list[str]

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "configured": self.configured,
            "required": self.required,
            "sources": self.sources,
        }


@dataclass(frozen=True)
class SourceHealth:
    source_id: str
    name: str
    status: str
    reason: str
    configured: bool
    runnable: bool
    missing_env: list[str]
    inputs: list[str]
    auth_required: bool
    docs_url: str
    source_maturity: str
    terms_risk: str
    cache_policy: str
    quota_policy: str
    priority: str
    product_value: str
    setup_hint: str
    requires_opt_in: bool
    remediation: str
    verification_status: str
    contract_gaps: list[str]

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "name": self.name,
            "status": self.status,
            "reason": self.reason,
            "configured": self.configured,
            "runnable": self.runnable,
            "missing_env": self.missing_env,
            "inputs": self.inputs,
            "auth_required": self.auth_required,
            "docs_url": self.docs_url,
            "source_maturity": self.source_maturity,
            "terms_risk": self.terms_risk,
            "cache_policy": self.cache_policy,
            "quota_policy": self.quota_policy,
            "priority": self.priority,
            "product_value": self.product_value,
            "setup_hint": self.setup_hint,
            "requires_opt_in": self.requires_opt_in,
            "remediation": self.remediation,
            "verification_status": self.verification_status,
            "contract_gaps": self.contract_gaps,
        }


@dataclass(frozen=True)
class SourceMaintenance:
    source_id: str
    name: str
    priority: str
    maintenance_status: str
    readiness_score: int
    live_readiness: str
    next_action: str
    blockers: list[str]
    warnings: list[str]
    fixture_variants: list[str]
    missing_env: list[str]
    verification_status: str
    docs_url: str
    terms_risk: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "name": self.name,
            "priority": self.priority,
            "maintenance_status": self.maintenance_status,
            "readiness_score": self.readiness_score,
            "live_readiness": self.live_readiness,
            "next_action": self.next_action,
            "blockers": self.blockers,
            "warnings": self.warnings,
            "fixture_variants": self.fixture_variants,
            "missing_env": self.missing_env,
            "verification_status": self.verification_status,
            "docs_url": self.docs_url,
            "terms_risk": self.terms_risk,
        }


def _optional_auth(auth: str) -> bool:
    value = auth.lower()
    return (
        "optional" in value
        or value in {"none", "", "none_or_api_key", "api_key_or_community"}
        or value.startswith("none_")
    )


def api_key_status(entries: list[SourceEntry] | None = None) -> list[ApiKeyStatus]:
    rows = entries or registry_entries()
    by_key: dict[str, dict[str, Any]] = {}
    for source in rows:
        for env_var in source.env_vars:
            item = by_key.setdefault(
                env_var,
                {
                    "configured": secret_configured(env_var),
                    "required": False,
                    "sources": [],
                },
            )
            item["required"] = item["required"] or not _optional_auth(source.auth)
            item["sources"].append(source.id)

    return [
        ApiKeyStatus(
            name=name,
            configured=bool(data["configured"]),
            required=bool(data["required"]),
            sources=sorted(data["sources"]),
        )
        for name, data in sorted(by_key.items())
    ]


def source_health(entries: list[SourceEntry] | None = None) -> list[SourceHealth]:
    rows = entries or registry_entries()
    health: list[SourceHealth] = []
    for source in rows:
        missing = missing_secret_names(source.env_vars)
        if source.kind == "module":
            status = "available"
            reason = "built-in module registered"
        elif missing and not _optional_auth(source.auth):
            status = "missing_keys"
            reason = "required API key environment variables are missing"
        elif not source.runnable:
            status = "catalog_only"
            reason = "catalog entry has no BEDNIIOSINT adapter yet"
        elif missing:
            status = "degraded"
            reason = "optional API key environment variables are missing"
        else:
            status = "available"
            reason = "source is configured"
        remediation = _source_remediation(source, status, missing)
        contract_gaps = _contract_gaps(source)
        verification_status = _verification_status(source, status, missing, contract_gaps)

        health.append(
            SourceHealth(
                source_id=source.id,
                name=source.name,
                status=status,
                reason=reason,
                configured=source.configured,
                runnable=source.runnable,
                missing_env=missing,
                inputs=source.inputs,
                auth_required=not _optional_auth(source.auth),
                docs_url=source.docs_url,
                source_maturity=source.source_maturity,
                terms_risk=source.terms_risk,
                cache_policy=source.cache_policy,
                quota_policy=source.quota_policy,
                priority=source.priority,
                product_value=source.product_value,
                setup_hint=source.setup_hint,
                requires_opt_in=source.requires_opt_in,
                remediation=remediation,
                verification_status=verification_status,
                contract_gaps=contract_gaps,
            )
        )
    return sorted(health, key=lambda item: (item.status, item.source_id))


def _source_remediation(source: SourceEntry, status: str, missing: list[str]) -> str:
    if status == "missing_keys":
        action = f"Set required environment variables: {', '.join(missing)}."
    elif status == "degraded":
        action = f"Set optional environment variables for fuller results or higher quota: {', '.join(missing)}."
    elif status == "catalog_only":
        action = "Add an adapter endpoint/parser before enabling this source in pipelines."
    else:
        action = "Ready to run from source-run or pipeline-run."
    if source.requires_opt_in:
        action += " Requires explicit legal/privacy opt-in before use."
    if source.setup_hint and source.setup_hint not in action:
        action += f" Setup hint: {source.setup_hint}"
    return action


def _contract_gaps(source: SourceEntry) -> list[str]:
    gaps = []
    if not source.inputs:
        gaps.append("missing input types")
    if source.kind == "api" and source.runnable and source.endpoints <= 0:
        gaps.append("missing endpoint metadata")
    if source.kind == "api" and not source.docs_url:
        gaps.append("missing official docs URL")
    if source.kind == "api" and source.auth not in {"none", "", "optional"} and not source.env_vars:
        gaps.append("missing API key env var mapping")
    if not source.output_schema:
        gaps.append("missing normalized output schema")
    return gaps


def _verification_status(
    source: SourceEntry,
    status: str,
    missing: list[str],
    contract_gaps: list[str],
) -> str:
    if contract_gaps:
        return "contract_gaps"
    if status == "catalog_only":
        return "needs_adapter"
    if missing and not _optional_auth(source.auth):
        return "needs_api_key"
    if source.requires_opt_in:
        return "needs_opt_in"
    if source.source_maturity in {"typed_parser", "tested_builtin"}:
        return "fixture_ready"
    if source.runnable:
        return "live_probe_ready"
    return "not_ready"


def source_health_summary(entries: list[SourceEntry] | None = None) -> dict[str, Any]:
    rows = source_health(entries)
    keys = api_key_status(entries)
    statuses = {status: 0 for status in ("available", "degraded", "missing_keys", "catalog_only")}
    verification_statuses: dict[str, int] = {}
    for row in rows:
        statuses[row.status] = statuses.get(row.status, 0) + 1
        verification_statuses[row.verification_status] = (
            verification_statuses.get(row.verification_status, 0) + 1
        )
    return {
        "sources": len(rows),
        "api_keys": len(keys),
        "configured_keys": sum(1 for key in keys if key.configured),
        "missing_required_keys": sum(
            1 for key in keys if key.required and not key.configured
        ),
        "statuses": statuses,
        "verification_statuses": dict(sorted(verification_statuses.items())),
        "contract_gaps": sum(1 for row in rows if row.contract_gaps),
        "typed_parsers": sum(1 for row in rows if row.source_maturity == "typed_parser"),
        "terms_risk": {
            risk: sum(1 for row in rows if row.terms_risk == risk)
            for risk in sorted({row.terms_risk for row in rows})
        },
    }


def source_maintenance_report(
    *,
    fixture_dir: Path | None = None,
    entries: list[SourceEntry] | None = None,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    rows = entries or registry_entries()
    health_by_id = {row.source_id: row for row in source_health(rows)}
    maintenance = [
        _source_maintenance_row(row, health_by_id[row.id], fixture_dir=fixture_dir)
        for row in rows
    ]
    maintenance_dicts = [row.as_dict() for row in maintenance]
    status_counts: dict[str, int] = {}
    live_counts: dict[str, int] = {}
    for row in maintenance:
        status_counts[row.maintenance_status] = status_counts.get(row.maintenance_status, 0) + 1
        live_counts[row.live_readiness] = live_counts.get(row.live_readiness, 0) + 1
    scores = [row.readiness_score for row in maintenance]
    try:
        from ..core.live_plan import live_validation_plan

        live_plan = live_validation_plan(env)
    except Exception:
        live_plan = {
            "network_required": True,
            "secrets_returned": False,
            "summary": {"ready": 0, "blocked": 0, "disabled": 0},
        }
    return {
        "summary": {
            "sources": len(maintenance),
            "average_readiness_score": round(sum(scores) / len(scores), 1) if scores else 0.0,
            "maintenance_statuses": dict(sorted(status_counts.items())),
            "live_readiness": dict(sorted(live_counts.items())),
            "action_required": status_counts.get("action_required", 0),
            "watch": status_counts.get("watch", 0),
            "ok": status_counts.get("ok", 0),
            "fixture_coverage": _fixture_coverage_summary(rows, fixture_dir),
            "live_validation": live_plan.get("summary", {}),
            "network_called": False,
            "secrets_returned": False,
        },
        "top_actions": [
            row
            for row in sorted(
                maintenance_dicts,
                key=lambda item: (
                    _maintenance_status_rank(str(item["maintenance_status"])),
                    int(item["readiness_score"]),
                    _priority_rank(str(item["priority"])),
                    str(item["source_id"]),
                ),
            )
            if row["maintenance_status"] != "ok"
        ][:15],
        "sources": sorted(
            maintenance_dicts,
            key=lambda item: (
                _maintenance_status_rank(str(item["maintenance_status"])),
                int(item["readiness_score"]),
                _priority_rank(str(item["priority"])),
                str(item["source_id"]),
            ),
        ),
    }


def _source_maintenance_row(
    source: SourceEntry,
    health: SourceHealth,
    *,
    fixture_dir: Path | None,
) -> SourceMaintenance:
    blockers: list[str] = []
    warnings: list[str] = []
    fixture_variants = _fixture_variants(fixture_dir, _short_source_id(source.id))

    blockers.extend(health.contract_gaps)
    if source.terms_risk == "reject":
        blockers.append("source is rejected by policy")
    if health.status == "missing_keys":
        blockers.append(f"missing required keys: {', '.join(health.missing_env)}")
    elif health.status == "catalog_only":
        blockers.append("adapter is not implemented")
    elif health.status == "degraded":
        warnings.append(f"missing optional keys: {', '.join(health.missing_env)}")

    if source.kind == "api":
        if "ok" not in fixture_variants:
            blockers.append("missing ok fixture")
        if not (MAINTENANCE_ERROR_VARIANTS & set(fixture_variants)):
            warnings.append("missing error/rate-limit/schema fixture variant")
        if source.runnable and source.source_maturity != "typed_parser":
            warnings.append(f"runnable source is {source.source_maturity}, not typed_parser")
    if source.requires_opt_in:
        warnings.append("requires explicit legal/privacy opt-in")
    if source.terms_risk in {"medium", "high"}:
        warnings.append(f"terms/privacy risk is {source.terms_risk}")

    status = "action_required" if blockers else "watch" if warnings else "ok"
    score = max(0, min(100, 100 - (len(blockers) * 25) - (len(warnings) * 8)))
    return SourceMaintenance(
        source_id=source.id,
        name=source.name,
        priority=source.priority,
        maintenance_status=status,
        readiness_score=score,
        live_readiness=_live_readiness(health),
        next_action=_next_action(blockers, warnings),
        blockers=blockers,
        warnings=warnings,
        fixture_variants=fixture_variants,
        missing_env=health.missing_env,
        verification_status=health.verification_status,
        docs_url=source.docs_url,
        terms_risk=source.terms_risk,
    )


def _live_readiness(health: SourceHealth) -> str:
    if health.contract_gaps:
        return "blocked_contract"
    if health.verification_status == "needs_adapter":
        return "needs_adapter"
    if health.verification_status == "needs_api_key":
        return "needs_api_key"
    if health.verification_status == "needs_opt_in":
        return "needs_opt_in"
    if health.runnable and health.status in {"available", "degraded"}:
        return "ready"
    return "not_ready"


def _next_action(blockers: list[str], warnings: list[str]) -> str:
    if blockers:
        return blockers[0]
    if warnings:
        return warnings[0]
    return "no action required"


def _fixture_coverage_summary(
    rows: list[SourceEntry],
    fixture_dir: Path | None,
) -> dict[str, Any]:
    apis = [row for row in rows if row.kind == "api"]
    if fixture_dir is None:
        return {
            "api_sources": len(apis),
            "with_ok_fixture": 0,
            "with_error_fixture": 0,
            "ok_coverage": 0.0,
            "error_coverage": 0.0,
            "fixture_dir": "",
        }
    ok_count = 0
    error_count = 0
    for row in apis:
        variants = set(_fixture_variants(fixture_dir, _short_source_id(row.id)))
        if "ok" in variants:
            ok_count += 1
        if variants & MAINTENANCE_ERROR_VARIANTS:
            error_count += 1
    total = len(apis)
    return {
        "api_sources": total,
        "with_ok_fixture": ok_count,
        "with_error_fixture": error_count,
        "ok_coverage": round(ok_count / total, 3) if total else 0.0,
        "error_coverage": round(error_count / total, 3) if total else 0.0,
        "fixture_dir": str(fixture_dir),
    }


def _fixture_variants(fixture_dir: Path | None, short_id: str) -> list[str]:
    if fixture_dir is None:
        return []
    root = fixture_dir / short_id
    if not root.exists() or not root.is_dir():
        return []
    return sorted(path.stem for path in root.glob("*.json") if path.is_file())


def _short_source_id(source_id: str) -> str:
    return source_id.split(":", 1)[-1]


def _maintenance_status_rank(status: str) -> int:
    return {"action_required": 0, "watch": 1, "ok": 2}.get(status, 3)


def _priority_rank(priority: str) -> int:
    return {"P0": 0, "P1": 1, "P2": 2, "P3": 3, "REJECT": 9}.get(priority.upper(), 5)


def adapter_health(
    source_id: str,
    *,
    target: str = "example.com",
    plugin_dir=None,
) -> dict[str, Any]:
    """Execute the selected adapter's own health check."""
    adapter = adapter_for(source_id, plugin_dir=plugin_dir)
    return adapter.health_check(target=target).as_dict()
