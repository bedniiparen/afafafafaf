# OSINT Source Study

This catalog records source metadata and design patterns that can be safely reused
in BEDNIIOSINT.

## What Was Copied

- Public API names, public documentation URLs and endpoint templates.
- Config-field ideas from MIT/CC data projects such as Sherlock, Maigret,
  WhatsMyName, API-s-for-OSINT and public-apis.
- Architecture ideas: event-driven modules, workspaces, source reliability,
  graph exports, module marketplaces and report formats.

## What Was Not Copied

- No API keys, tokens, cookies, credentials or private endpoints.
- No GPL/AGPL source implementation from Recon-ng, theHarvester, GHunt,
  Holehe, PhoneInfoga or Social Analyzer.
- No bulk third-party site databases copied verbatim.

## Immediate Integration Ideas

- Add a generic API adapter contract using the catalog entries.
- Add CSV and GEXF exports for easier SpiderFoot/Gephi-style exchange.
- Add source health checks that run claimed and impossible controls.
- Add a local API key registry backed by environment variables first.
- Extend graph edges with evidence URL, observed timestamp and SHA-256.
