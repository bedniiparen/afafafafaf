from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

reports_app = typer.Typer(help="Case report export and verification commands")
console = Console()


@reports_app.command("write")
def report(
    case: str = typer.Argument(...),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
    pdf: bool = typer.Option(False, "--pdf"),
    csv_out: bool = typer.Option(False, "--csv", help="Write CSV exports"),
    stix: bool = typer.Option(False, "--stix", help="Write STIX 2.1 JSON bundle"),
    opencti: bool = typer.Option(False, "--opencti", help="Write OpenCTI import envelope JSON"),
    misp: bool = typer.Option(False, "--misp", help="Write MISP event JSON"),
    bundle: bool = typer.Option(False, "--bundle", help="Write a ZIP case bundle"),
    evidence_bundle: bool = typer.Option(
        False, "--evidence-bundle", help="Write a ZIP evidence vault bundle"
    ),
    sign_key: str | None = typer.Option(
        None, "--sign-key", help="HMAC key for evidence bundle manifest signature"
    ),
):
    """Write a unified report bundle for all modules in a case."""
    from .config import settings
    from .core.case_lookup import case_ids
    from .core.case_summary import build_case_summary
    from .evidence.bundle import write_evidence_bundle
    from .evidence.manifest import write_evidence_manifest
    from .reports.case_html import write_case_html
    from .reports.csv import write_case_csv
    from .reports.json import write_json
    from .reports.markdown import write_case_markdown
    from .reports.manifest import write_case_bundle, write_report_manifest
    from .reports.misp import write_misp_event
    from .reports.opencti import write_opencti_envelope
    from .reports.pdf import html_to_pdf, pdf_unavailable_reason
    from .reports.stix import write_stix
    from .reports.view_model import build_report_view_model
    from .storage.sqlite import Storage

    summary = build_case_summary(case)
    if not summary.get("meta", {}).get("found"):
        console.print("[red]case not found[/]")
        raise typer.Exit(1)
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = write_json(summary, out_dir / f"{case}-case.json")
    technical_json_path = write_json(build_report_view_model(summary), out_dir / f"{case}-technical.json")
    html_path = write_case_html(summary, out_dir / f"{case}-case.html")
    markdown_path = write_case_markdown(summary, out_dir / f"{case}-case.md")
    console.print(f"[dim]JSON ->[/] {json_path}")
    console.print(f"[dim]Technical JSON ->[/] {technical_json_path}")
    console.print(f"[dim]HTML ->[/] {html_path}")
    console.print(f"[dim]Markdown ->[/] {markdown_path}")
    if pdf:
        pdf_path = html_to_pdf(html_path, out_dir / f"{case}-case.pdf")
        if pdf_path is None:
            reason = pdf_unavailable_reason() or "PDF export failed."
            console.print(f"[yellow]{reason}[/]")
        else:
            console.print(f"[dim]PDF ->[/] {pdf_path}")
    if csv_out:
        csv_paths = write_case_csv(summary, out_dir, case)
        for name, path in csv_paths.items():
            console.print(f"[dim]CSV {name} ->[/] {path}")
    if stix:
        stix_path = write_stix(summary, out_dir / f"{case}-stix.json")
        console.print(f"[dim]STIX ->[/] {stix_path}")
    if opencti:
        opencti_path = write_opencti_envelope(summary, out_dir / f"{case}-opencti.json")
        console.print(f"[dim]OpenCTI ->[/] {opencti_path}")
    if misp:
        misp_path = write_misp_event(summary, out_dir / f"{case}-misp.json")
        console.print(f"[dim]MISP ->[/] {misp_path}")
    ids = case_ids(Storage(settings.db_path(case)), case)
    if ids:
        evidence_path = write_evidence_manifest(
            Storage(settings.db_path(case)),
            ids,
            out_dir / f"{case}-evidence-manifest.json",
        )
        console.print(f"[dim]Evidence manifest ->[/] {evidence_path}")
        if evidence_bundle:
            evidence_bundle_path = write_evidence_bundle(
                Storage(settings.db_path(case)),
                ids,
                out_dir / f"{case}-evidence-bundle.zip",
                signing_key=sign_key,
            )
            console.print(f"[dim]Evidence bundle ->[/] {evidence_bundle_path}")
    manifest_path = write_report_manifest(out_dir)
    console.print(f"[dim]Manifest ->[/] {manifest_path}")
    if bundle:
        bundle_path = write_case_bundle(out_dir, case)
        console.print(f"[dim]Bundle ->[/] {bundle_path}")


@reports_app.command("verify")
def reports_verify(
    manifest: Path = typer.Argument(Path("runtime/reports_out/reports-manifest.json"), help="Report manifest JSON"),
    reports_dir: Path | None = typer.Option(None, "--reports-dir", help="Directory containing report artifacts"),
    case: str | None = typer.Option(None, "--case", help="Limit verification to one case"),
    json_out: bool = typer.Option(False, "--json", help="Print verification result as JSON"),
):
    """Verify generated report artifacts against reports-manifest.json."""
    from .reports.manifest import verify_report_manifest

    result = verify_report_manifest(
        manifest,
        reports_dir=reports_dir,
        case_name=case,
    )
    if json_out:
        console.print(
            json.dumps(result, indent=2, ensure_ascii=False, default=str),
            markup=False,
            soft_wrap=True,
        )
        if not result["valid"]:
            raise typer.Exit(1)
        return

    summary = result["summary"]
    table = Table(
        title=(
            "Report artifact verification: "
            f"{'valid' if result['valid'] else 'invalid'}; "
            f"{summary['present']}/{summary['files']} present"
        )
    )
    table.add_column("File")
    table.add_column("Present")
    table.add_column("Size")
    table.add_column("SHA-256")
    for row in result["files"]:
        table.add_row(
            str(row.get("name") or ""),
            "yes" if row.get("present") else "no",
            "yes" if row.get("size_ok") else "no",
            "yes" if row.get("sha256_ok") else "no",
        )
    console.print(table)
    if result["errors"]:
        for error in result["errors"]:
            console.print(f"[red]{error}[/]")
    if not result["valid"]:
        raise typer.Exit(1)
