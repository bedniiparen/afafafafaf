from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console


console = Console()
search_app = typer.Typer(add_completion=False, help="Search and source pipeline commands")


@search_app.command("pipeline-run")
def pipeline_run(
    target: str = typer.Argument(...),
    input_type: str | None = typer.Option(None, "--input"),
    sources: str | None = typer.Option(None, "--sources", help="Comma-separated source ids"),
    limit: int | None = typer.Option(None, "--limit", min=1),
    configured_only: bool = typer.Option(False, "--configured-only"),
    save: bool = typer.Option(False, "--save"),
    case: str | None = typer.Option(None, "--case"),
    cache_ttl: int = typer.Option(0, "--cache-ttl", min=0, help="Enable source response cache for N seconds"),
    cache_ttl_source: list[str] | None = typer.Option(
        None,
        "--cache-ttl-source",
        help="Per-source cache TTL as source=seconds, repeatable or comma-separated",
    ),
    request_budget: str | None = typer.Option(None, "--request-budget", help="JSON or source=limit pairs, e.g. *=2,api:crtsh=1"),
    budget_preset: str = typer.Option("none", "--budget-preset", help="Budget preset: none, smoke, conservative, standard"),
    timeout: float | None = typer.Option(None, "--timeout", min=0.1, help="HTTP timeout override"),
    rate_limit_delay: float | None = typer.Option(None, "--rate-limit-delay", min=0.0, help="Per-host delay override"),
    scope: str = typer.Option("public_osint", "--scope", help="Legal/privacy scope label recorded in run context"),
    public_only: bool = typer.Option(False, "--public-only", help="Block medium/high terms-risk sources"),
    max_terms_risk: str | None = typer.Option(None, "--max-terms-risk", help="Maximum allowed terms risk: low, medium, high"),
    allow_sensitive_sources: bool = typer.Option(False, "--allow-sensitive-sources", help="Allow phone/sanctions/social/high-risk sources that require explicit opt-in"),
    allow_uploads: bool = typer.Option(False, "--allow-uploads", help="Allow third-party upload/submission workflows"),
    allow_active_checks: bool = typer.Option(False, "--allow-active-checks", help="Allow active checks when a source requires them"),
):
    """Run the catalog source pipeline for a target type."""
    from .config import settings
    from .core.cache_policy import merge_cache_ttl_presets
    from .core.jobs import resolve_rate_limit_budget
    from .core.source_context import SourceRunContext, parse_cache_ttl_by_source
    from .core.source_pipeline import run_source_pipeline

    source_ids = [item.strip() for item in sources.split(",") if item.strip()] if sources else None
    try:
        budget = resolve_rate_limit_budget(request_budget, preset=budget_preset)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    try:
        cache_ttls = merge_cache_ttl_presets(
            parse_cache_ttl_by_source(cache_ttl_source),
            source_ids=source_ids,
        )
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    context = SourceRunContext(
        scope=scope,
        timeout=timeout if timeout is not None else settings.timeout,
        rate_limit_delay=rate_limit_delay if rate_limit_delay is not None else settings.http_rate_limit_delay,
        cache_enabled=cache_ttl > 0 or bool(cache_ttls),
        cache_ttl_seconds=cache_ttl,
        cache_ttl_by_source=cache_ttls,
        request_budget=budget,
        legal_flags={
            "public_only": public_only,
            "max_terms_risk": max_terms_risk,
            "allow_sensitive_sources": allow_sensitive_sources,
            "allow_uploads": allow_uploads,
            "allow_active_checks": allow_active_checks,
        },
    )
    result = run_source_pipeline(
        target,
        input_type=input_type,
        source_ids=source_ids,
        limit=limit,
        available_only=configured_only,
        save=save,
        case_name=case,
        context=context,
    )
    console.print(json.dumps(result.as_dict(), indent=2, ensure_ascii=False, default=str))


@search_app.command("plan")
def search_plan_command(
    target: str = typer.Argument(...),
    entity_type: str | None = typer.Option(None, "--entity-type", "--input"),
    scope: str | None = typer.Option(None, "--scope"),
    max_sources: int | None = typer.Option(None, "--max-sources", min=1),
    include_auth_required: bool = typer.Option(False, "--include-auth-required"),
    source: list[str] | None = typer.Option(None, "--source", help="Search registry source id"),
):
    """Plan unified OSINT search sources without running network adapters."""
    from .search.planner import plan_search

    plan = plan_search(
        target,
        entity_type=entity_type,
        scope=scope,
        max_sources=max_sources,
        include_auth_required=include_auth_required,
        source_ids=source,
    )
    console.print(json.dumps(plan.as_dict(), indent=2, ensure_ascii=False, default=str))


@search_app.command("run")
def search_run_command(
    target: str = typer.Argument(...),
    entity_type: str | None = typer.Option(None, "--entity-type", "--input"),
    scope: str | None = typer.Option(None, "--scope"),
    max_sources: int | None = typer.Option(None, "--max-sources", min=1),
    include_auth_required: bool = typer.Option(False, "--include-auth-required"),
    source: list[str] | None = typer.Option(None, "--source", help="Search registry source id"),
    configured_only: bool = typer.Option(False, "--configured-only"),
    save: bool = typer.Option(False, "--save"),
    case: str | None = typer.Option(None, "--case"),
    cache_ttl: int = typer.Option(0, "--cache-ttl", min=0),
    cache_ttl_source: list[str] | None = typer.Option(
        None,
        "--cache-ttl-source",
        help="Per-source cache TTL as source=seconds, repeatable or comma-separated",
    ),
    request_budget: str | None = typer.Option(None, "--request-budget"),
    budget_preset: str = typer.Option("none", "--budget-preset"),
    timeout: float | None = typer.Option(None, "--timeout", min=0.1),
    rate_limit_delay: float | None = typer.Option(None, "--rate-limit-delay", min=0.0),
    concurrent: bool = typer.Option(False, "--concurrent", help="Run mapped catalog adapters concurrently"),
    max_workers: int = typer.Option(4, "--max-workers", min=1, help="Concurrent adapter worker count"),
    include_dorking: bool = typer.Option(True, "--dorking/--no-dorking", help="Include offline review-only dorking leads"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Explain planned sources without running adapters"),
    explain: bool = typer.Option(False, "--explain", help="Alias for --dry-run"),
    compact: bool = typer.Option(True, "--compact/--full", help="Return compact dry-run explanation by default"),
    summary: bool = typer.Option(False, "--summary", help="Print report_summary instead of full JSON"),
    markdown: bool = typer.Option(False, "--markdown", help="Print Markdown search report instead of JSON"),
):
    """Run unified search through mapped catalog adapters and return SearchResult rows."""
    from .config import settings
    from .core.cache_policy import merge_cache_ttl_presets
    from .core.jobs import resolve_rate_limit_budget
    from .core.source_context import SourceRunContext, parse_cache_ttl_by_source
    from .search.explain import explain_search_run
    from .search.pipeline import run_planned_search_pipeline

    if dry_run or explain:
        result = explain_search_run(
            target,
            entity_type=entity_type,
            scope=scope,
            max_sources=max_sources,
            include_auth_required=include_auth_required,
            source_ids=source,
            configured_only=configured_only,
            compact=compact,
        )
        if markdown:
            console.print(result["report_markdown"], markup=False, soft_wrap=True)
            return
        if summary:
            console.print(json.dumps(result["report_summary"], indent=2, ensure_ascii=False, default=str))
            return
        console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        return

    try:
        budget = resolve_rate_limit_budget(request_budget, preset=budget_preset)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    try:
        cache_ttls = merge_cache_ttl_presets(parse_cache_ttl_by_source(cache_ttl_source))
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    context = SourceRunContext(
        scope=scope or "public_osint",
        timeout=timeout if timeout is not None else settings.timeout,
        rate_limit_delay=rate_limit_delay if rate_limit_delay is not None else settings.http_rate_limit_delay,
        cache_enabled=cache_ttl > 0 or bool(cache_ttls),
        cache_ttl_seconds=cache_ttl,
        cache_ttl_by_source=cache_ttls,
        request_budget=budget,
    )
    result = run_planned_search_pipeline(
        target,
        entity_type=entity_type,
        scope=scope,
        max_sources=max_sources,
        include_auth_required=include_auth_required,
        source_ids=source,
        available_only=configured_only,
        save=save,
        case_name=case,
        context=context,
        concurrent=concurrent,
        max_workers=max_workers,
        include_dorking=include_dorking,
    )
    if markdown:
        console.print(result["report_markdown"], markup=False, soft_wrap=True)
        if not settings.embedding_rerank_enabled:
            console.print(
                "[dim]Tip: enable semantic re-ranking with "
                "BEDNIIOSINT_EMBEDDING_PROVIDER=<provider> and "
                "BEDNIIOSINT_EMBEDDING_RERANK=1[/dim]"
            )
        return
    if summary:
        console.print(json.dumps(result["report_summary"], indent=2, ensure_ascii=False, default=str))
        if not settings.embedding_rerank_enabled:
            console.print(
                "[dim]Tip: enable semantic re-ranking with "
                "BEDNIIOSINT_EMBEDDING_PROVIDER=<provider> and "
                "BEDNIIOSINT_EMBEDDING_RERANK=1[/dim]"
            )
        return
    console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    if not settings.embedding_rerank_enabled:
        console.print(
            "[dim]Tip: enable semantic re-ranking with "
            "BEDNIIOSINT_EMBEDDING_PROVIDER=<provider> and "
            "BEDNIIOSINT_EMBEDDING_RERANK=1[/dim]"
        )


@search_app.command("investigate")
def search_investigate_command(
    target: str = typer.Argument(...),
    entity_type: str | None = typer.Option(None, "--entity-type", "--input"),
    scope: str | None = typer.Option(None, "--scope"),
    max_depth: int | None = typer.Option(None, "--max-depth", min=0, max=4),
    max_nodes: int | None = typer.Option(None, "--max-nodes", min=1, max=100),
    min_pivot_confidence: float | None = typer.Option(None, "--min-pivot-confidence", min=0.0, max=1.0),
    include_dorking: bool = typer.Option(False, "--dorking/--no-dorking"),
    include_username_scan: bool = typer.Option(True, "--username-scan/--no-username-scan"),
    concurrent: bool = typer.Option(True, "--concurrent/--serial"),
    save: bool = typer.Option(False, "--save"),
    case: str | None = typer.Option(None, "--case"),
    graph_out: Path | None = typer.Option(None, "--graph-out", dir_okay=False, help="Write an HTML investigation graph"),
):
    """Run recursive search pivots and optionally write an investigation graph."""
    from .graph.investigation_graph import investigation_graph_html
    from .search.auto_pivot import run_recursive_investigation

    result = run_recursive_investigation(
        target,
        entity_type=entity_type,
        scope=scope,
        max_depth=max_depth,
        max_nodes=max_nodes,
        min_pivot_confidence=min_pivot_confidence,
        include_dorking=include_dorking,
        include_username_scan=include_username_scan,
        concurrent=concurrent,
        save=save,
        case_name=case,
    )
    if graph_out is not None:
        graph_out.parent.mkdir(parents=True, exist_ok=True)
        graph_out.write_text(investigation_graph_html(result), encoding="utf-8")
    console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


@search_app.command("investigation-plan")
def investigation_plan_command(
    target: str = typer.Argument(...),
    entity_type: str | None = typer.Option(None, "--entity-type", "--input"),
):
    """Build an offline investigation route plan for a target."""
    from .search.investigation import build_investigation_plan

    result = build_investigation_plan(target, entity_type=entity_type)
    console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


@search_app.command("benchmark")
def search_benchmark_command(
    dataset: Path = typer.Argument(..., exists=True, dir_okay=False, help="JSON ground-truth dataset"),
    max_sources: int | None = typer.Option(None, "--max-sources", min=1),
    include_auth_required: bool = typer.Option(False, "--include-auth-required"),
    include_dorking: bool = typer.Option(False, "--dorking/--no-dorking"),
    markdown: bool = typer.Option(False, "--markdown", help="Print Markdown report"),
):
    """Run precision/recall/F1/MRR benchmark for unified search."""
    from .eval.benchmark import load_dataset, report_markdown, run_benchmark
    from .search.pipeline import run_planned_search_pipeline

    def search_fn(target: str, entity_type: str):
        payload = run_planned_search_pipeline(
            target,
            entity_type=entity_type,
            max_sources=max_sources,
            include_auth_required=include_auth_required,
            include_dorking=include_dorking,
        )
        return payload.get("search_results") or []

    report = run_benchmark(load_dataset(dataset), search_fn)
    if markdown:
        console.print(report_markdown(report), markup=False, soft_wrap=True)
        return
    console.print(json.dumps(report.to_dict(), indent=2, ensure_ascii=False, default=str))


@search_app.command("index-search")
def search_index_command(
    query: str = typer.Argument(..., help="Full-text query over indexed search results"),
    case: str | None = typer.Option(None, "--case", help="Case name; defaults to --db without case filter"),
    db: Path | None = typer.Option(None, "--db", exists=True, dir_okay=False, help="Case database path"),
    source: list[str] | None = typer.Option(None, "--source", help="Filter by source_id; repeatable"),
    limit: int = typer.Option(25, "--limit", min=1, max=500),
):
    """Search the local FTS5 index created by search run --save --case."""
    from .config import settings
    from .storage.fts import search_index

    if db is None and not case:
        raise typer.BadParameter("--case is required when --db is not provided")
    db_path = db if db is not None else settings.db_path(str(case))
    rows = search_index(
        db_path,
        query,
        case_name=case,
        source_ids=source,
        limit=limit,
    )
    console.print(
        json.dumps(
            {
                "query": query,
                "case": case,
                "db_path": str(db_path),
                "count": len(rows),
                "results": rows,
            },
            indent=2,
            ensure_ascii=False,
            default=str,
        )
    )


@search_app.command("sources")
def search_sources_command(
    entity_type: str | None = typer.Option(None, "--entity-type", "--input"),
    scope: str | None = typer.Option(None, "--scope"),
    category: str | None = typer.Option(None, "--category"),
    compact: bool = typer.Option(True, "--compact/--full", help="Return compact readiness rows by default"),
):
    """List unified search registry sources and mapped catalog adapter readiness."""
    from .search.readiness import search_source_readiness, search_sources_status
    from .search.source_registry import filter_sources

    filtered = filter_sources(entity_type=entity_type, scope=scope, category=category)
    allowed_ids = {str(source.get("id") or "") for source in filtered}
    if compact:
        status = search_sources_status(compact=True)
        status["sources"] = [
            row for row in status["sources"] if str(row.get("source_id") or "") in allowed_ids
        ]
        status["summary"] = {
            **status["summary"],
            "filtered": len(status["sources"]),
        }
        console.print(json.dumps(status, indent=2, ensure_ascii=False, default=str))
        return

    status_by_id = {row["source_id"]: row for row in search_source_readiness()}
    rows = []
    for source in filtered:
        row = dict(source)
        row["readiness"] = status_by_id.get(str(source.get("id") or ""), {})
        rows.append(row)
    console.print(json.dumps({"sources": rows, "count": len(rows)}, indent=2, ensure_ascii=False, default=str))
