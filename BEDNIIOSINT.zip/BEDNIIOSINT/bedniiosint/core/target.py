from __future__ import annotations

import ipaddress
import re
from pathlib import Path
from urllib.parse import urlparse

from .text_variants import is_probable_cyrillic_person_name


SUPPORTED_MODULES = (
    "auto",
    "username",
    "email",
    "domain",
    "metadata",
    "ip",
    "url",
    "phone",
    "wallet",
    "company",
)


def safe_case_name(value: str) -> str:
    value = value.strip() or "default-case"
    return "".join(ch for ch in value if ch.isalnum() or ch in "-_") or "case"


def detect_module(target: str) -> str:
    value = target.strip()
    if Path(value).exists():
        return "metadata"
    try:
        ipaddress.ip_address(value)
        return "ip"
    except ValueError:
        pass
    if re.fullmatch(r"0x[a-fA-F0-9]{40}", value) or re.fullmatch(
        r"(bc1[a-z0-9]{25,62}|[13][a-km-zA-HJ-NP-Z1-9]{25,39})", value
    ):
        return "wallet"
    if value.startswith("+") and re.fullmatch(r"\+[\d\s().-]{7,25}", value):
        return "phone"
    if "@" in value and " " not in value:
        return "email"
    if urlparse(value).scheme in {"http", "https"}:
        return "url"
    if " " in value:
        if is_probable_cyrillic_person_name(value):
            return "username"
        return "company"
    parsed = urlparse(value if "://" in value else f"//{value}")
    host = (parsed.netloc or parsed.path).split("/")[0]
    if "." in host and " " not in host and "\\" not in host:
        return "domain"
    return "username"


def auto_case_name(module: str, target: str) -> str:
    value = target.strip()
    if module == "metadata":
        path = Path(value)
        value = path.stem or path.name
    elif module == "domain":
        parsed = urlparse(value if "://" in value else f"//{value}")
        value = (parsed.netloc or parsed.path).split("/")[0]
    elif module == "url":
        parsed = urlparse(value if "://" in value else f"https://{value}")
        value = parsed.netloc or parsed.path
    value = value.lower().replace("@", "_at_")
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in value)
    safe = "-".join(part for part in safe.split("-") if part)
    return safe_case_name(f"{module}-{safe[:80] or 'search'}")
