from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
from typing import Any

from ..config import settings
from .case_diff import diff_case_summaries
from .case_summary import build_case_summary
from .jobs import create_job, job_as_dict, run_job
from .notifications import notify_monitor_alert
from .target import auto_case_name, detect_module, safe_case_name


MONITORING_STATE_VERSION = "0.1"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).replace(microsecond=0).isoformat()


def _parse_time(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def monitoring_state_path(path: Path | None = None) -> Path:
    if path is not None:
        return path
    settings.db_dir.mkdir(parents=True, exist_ok=True)
    return settings.db_dir / "monitoring.json"


def _empty_state() -> dict[str, Any]:
    return {
        "schema_version": MONITORING_STATE_VERSION,
        "schedules": [],
        "alerts": [],
    }


def _load_state(path: Path | None = None) -> dict[str, Any]:
    state_path = monitoring_state_path(path)
    if not state_path.exists():
        return _empty_state()
    data = json.loads(state_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return _empty_state()
    data.setdefault("schema_version", MONITORING_STATE_VERSION)
    data.setdefault("schedules", [])
    data.setdefault("alerts", [])
    return data


def _write_state(state: dict[str, Any], path: Path | None = None) -> None:
    state_path = monitoring_state_path(path)
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(
        json.dumps(state, indent=2, ensure_ascii=False, sort_keys=True),
        encoding="utf-8",
    )


def _schedule_id(target: str, module: str, case_prefix: str) -> str:
    digest = hashlib.sha256(f"{module}\0{target}\0{case_prefix}".encode("utf-8")).hexdigest()
    return digest[:16]


def _default_case_prefix(target: str, module: str) -> str:
    selected = detect_module(target) if module == "auto" else module
    return safe_case_name("monitor-" + auto_case_name(selected, target))


def _next_case_name(schedule: dict[str, Any], now: datetime) -> str:
    stamp = now.astimezone(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return safe_case_name(f"{schedule['case_prefix']}-{stamp}")


def add_monitor_schedule(
    target: str,
    *,
    module: str = "auto",
    case_prefix: str | None = None,
    interval_minutes: int = 1440,
    enabled: bool = True,
    path: Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = now or _now()
    clean_module = (module or "auto").strip().lower()
    prefix = safe_case_name(case_prefix or _default_case_prefix(target, clean_module))
    interval = max(1, int(interval_minutes))
    schedule_id = _schedule_id(target, clean_module, prefix)
    state = _load_state(path)
    schedules = list(state.get("schedules") or [])
    existing = next((row for row in schedules if row.get("id") == schedule_id), None)
    row = {
        "id": schedule_id,
        "target": target,
        "module": clean_module,
        "case_prefix": prefix,
        "interval_minutes": interval,
        "enabled": bool(enabled),
        "created_at": existing.get("created_at") if existing else _iso(current),
        "updated_at": _iso(current),
        "last_run_at": existing.get("last_run_at") if existing else None,
        "last_case": existing.get("last_case") if existing else None,
        "last_job_id": existing.get("last_job_id") if existing else None,
        "next_run_at": existing.get("next_run_at") if existing else _iso(current),
        "last_diff": existing.get("last_diff") if existing else None,
        "last_alert": existing.get("last_alert") if existing else None,
    }
    if existing:
        schedules = [row if item.get("id") == schedule_id else item for item in schedules]
        created = False
    else:
        schedules.append(row)
        created = True
    state["schedules"] = sorted(schedules, key=lambda item: str(item.get("id") or ""))
    _write_state(state, path)
    return {"created": created, "schedule": row}


def list_monitor_schedules(*, path: Path | None = None) -> dict[str, Any]:
    state = _load_state(path)
    schedules = list(state.get("schedules") or [])
    return {
        "summary": {
            "schedules": len(schedules),
            "enabled": sum(1 for row in schedules if bool(row.get("enabled"))),
            "alerts": len(state.get("alerts") or []),
        },
        "schedules": schedules,
        "alerts": list(state.get("alerts") or []),
    }


def due_monitor_schedules(
    *,
    path: Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = now or _now()
    schedules = list(_load_state(path).get("schedules") or [])
    due = []
    for schedule in schedules:
        if not bool(schedule.get("enabled")):
            continue
        next_run = _parse_time(schedule.get("next_run_at"))
        if next_run is None or next_run <= current:
            due.append(schedule)
    return {
        "summary": {
            "schedules": len(schedules),
            "due": len(due),
            "now": _iso(current),
        },
        "schedules": due,
    }


def _diff_alert(schedule: dict[str, Any], previous: str | None, current: str, diff: dict[str, Any] | None) -> dict[str, Any] | None:
    if not previous or not diff:
        return None
    summary = diff.get("summary") or {}
    changed = {
        key: int(summary.get(key) or 0)
        for key in ("new_entities", "new_findings", "new_relations", "removed_entities", "removed_findings", "removed_relations")
    }
    if not any(changed.values()):
        return None
    return {
        "schedule_id": schedule.get("id"),
        "target": schedule.get("target"),
        "previous_case": previous,
        "current_case": current,
        "changed": changed,
        "message": (
            f"Monitor detected changes for {schedule.get('target')}: "
            f"{changed['new_findings']} new finding(s), "
            f"{changed['new_entities']} new entity/entities, "
            f"{changed['new_relations']} new relation(s)."
        ),
    }


def run_due_monitor_schedules(
    *,
    path: Path | None = None,
    now: datetime | None = None,
    max_runs: int | None = None,
    execute: bool = True,
) -> dict[str, Any]:
    current = now or _now()
    state = _load_state(path)
    schedules = list(state.get("schedules") or [])
    due_ids = {row["id"] for row in due_monitor_schedules(path=path, now=current)["schedules"]}
    results = []
    alerts = list(state.get("alerts") or [])
    runs = 0
    for schedule in schedules:
        if schedule.get("id") not in due_ids:
            continue
        if max_runs is not None and runs >= max_runs:
            break
        runs += 1
        previous_case = schedule.get("last_case")
        next_case = _next_case_name(schedule, current)
        result: dict[str, Any] = {
            "schedule_id": schedule.get("id"),
            "target": schedule.get("target"),
            "case": next_case,
            "previous_case": previous_case,
            "executed": execute,
        }
        if execute:
            job = create_job(
                str(schedule.get("target") or ""),
                module=str(schedule.get("module") or "auto"),
                case_name=next_case,
                resume=False,
            )
            run_result = run_job(job.id, raise_on_error=False) if job.id is not None else {"status": "failed"}
            refreshed = job_as_dict(job)
            if job.id is not None:
                from .jobs import get_job

                latest_job = get_job(job.id)
                if latest_job is not None:
                    refreshed = job_as_dict(latest_job)
            diff = None
            if previous_case:
                previous_summary = build_case_summary(str(previous_case))
                current_summary = build_case_summary(next_case)
                if previous_summary.get("meta", {}).get("found") and current_summary.get("meta", {}).get("found"):
                    diff = diff_case_summaries(previous_summary, current_summary)
            alert = _diff_alert(schedule, str(previous_case) if previous_case else None, next_case, diff)
            if alert:
                alert["created_at"] = _iso(current)
                alert["notification"] = notify_monitor_alert(
                    alert,
                    notifications_path=monitoring_state_path(path).with_name("monitor_notifications.jsonl"),
                )
                alerts.append(alert)
            schedule["last_case"] = next_case
            schedule["last_job_id"] = job.id
            schedule["last_run_at"] = _iso(current)
            schedule["last_diff"] = diff
            schedule["last_alert"] = alert
            result.update(
                {
                    "job": refreshed,
                    "run": run_result,
                    "diff": diff,
                    "alert": alert,
                }
            )
        schedule["next_run_at"] = _iso(current + timedelta(minutes=int(schedule.get("interval_minutes") or 1440)))
        schedule["updated_at"] = _iso(current)
        results.append(result)
    state["schedules"] = schedules
    state["alerts"] = alerts[-200:]
    _write_state(state, path)
    return {
        "summary": {
            "due": len(due_ids),
            "processed": len(results),
            "executed": sum(1 for row in results if row.get("executed")),
            "alerts": sum(1 for row in results if row.get("alert")),
        },
        "results": results,
    }
