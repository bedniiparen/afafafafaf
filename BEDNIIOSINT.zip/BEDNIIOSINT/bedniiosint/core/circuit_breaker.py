from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field

from ..config import settings
from ..observability import get_logger

log = get_logger("circuit_breaker")


@dataclass
class _State:
    failures: int = 0
    opened_at: float = 0.0
    lock: threading.Lock = field(default_factory=threading.Lock)


class CircuitBreaker:
    def __init__(self) -> None:
        self._states: dict[str, _State] = {}
        self._guard = threading.Lock()

    def _state(self, key: str) -> _State:
        with self._guard:
            return self._states.setdefault(key, _State())

    def is_open(self, source: str) -> bool:
        st = self._state(source)
        with st.lock:
            if st.opened_at and (time.monotonic() - st.opened_at) < settings.breaker_reset:
                return True
            if st.opened_at:
                st.opened_at = 0.0
                st.failures = 0
            return False

    def record_success(self, source: str) -> None:
        st = self._state(source)
        with st.lock:
            st.failures = 0
            st.opened_at = 0.0

    def record_failure(self, source: str) -> None:
        st = self._state(source)
        with st.lock:
            st.failures += 1
            if st.failures >= settings.breaker_failures and not st.opened_at:
                st.opened_at = time.monotonic()
                log.warning("circuit opened", extra={"source": source, "failures": st.failures})

    def reset(self, source: str | None = None) -> None:
        with self._guard:
            if source is None:
                self._states.clear()
                return
            self._states.pop(source, None)


breaker = CircuitBreaker()
