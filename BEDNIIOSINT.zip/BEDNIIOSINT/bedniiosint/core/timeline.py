from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime

from ..storage.models import TimelineEvent
from ..storage.sqlite import Storage


def add_event(
    storage: Storage,
    case_id: int,
    *,
    kind: str,
    entity_type: str,
    entity_value: str,
    when: datetime | None = None,
    precision: str = "exact",
    source: str = "",
    confidence: float = 0.0,
    description: str = "",
) -> None:
    with storage.session() as session:
        session.add(
            TimelineEvent(
                case_id=case_id,
                when=when,
                when_precision=precision,
                kind=kind,
                entity_type=entity_type,
                entity_value=entity_value,
                source_name=source,
                confidence=confidence,
                description=description,
            )
        )
        session.commit()


def _ids(case_id: int | Iterable[int]) -> list[int]:
    if isinstance(case_id, int):
        return [case_id]
    return list(case_id)


def get_timeline(storage: Storage, case_id: int | Iterable[int]) -> list[dict]:
    with storage.session() as session:
        events = []
        for cid in _ids(case_id):
            events.extend(
                session.query(TimelineEvent)
                .filter(TimelineEvent.case_id == cid)
                .all()
            )
    rows = [
        {
            "id": event.id,
            "case_id": event.case_id,
            "finding_id": event.finding_id,
            "when": event.when.isoformat() if event.when else None,
            "precision": event.when_precision,
            "kind": event.kind,
            "entity_type": event.entity_type,
            "entity_value": event.entity_value,
            "entity": f"{event.entity_type}:{event.entity_value}",
            "source": event.source_name,
            "confidence": event.confidence,
            "description": event.description,
        }
        for event in events
    ]
    rows.sort(key=lambda row: (row["when"] is None, row["when"] or ""))
    return rows
