from __future__ import annotations

from ..storage.models import Entity, Relation


def add_entity_once(session, *, case_id: int, type: str, value: str) -> Entity:
    value = str(value).strip()
    existing = (
        session.query(Entity)
        .filter(Entity.case_id == case_id)
        .filter(Entity.type == type)
        .filter(Entity.value == value)
        .first()
    )
    if existing is not None:
        return existing
    entity = Entity(case_id=case_id, type=type, value=value)
    session.add(entity)
    return entity


def add_relation_once(
    session,
    *,
    case_id: int,
    src_type: str,
    src_value: str,
    rel: str,
    dst_type: str,
    dst_value: str,
) -> Relation:
    existing = (
        session.query(Relation)
        .filter(Relation.case_id == case_id)
        .filter(Relation.src_type == src_type)
        .filter(Relation.src_value == src_value)
        .filter(Relation.rel == rel)
        .filter(Relation.dst_type == dst_type)
        .filter(Relation.dst_value == dst_value)
        .first()
    )
    if existing is not None:
        return existing
    relation = Relation(
        case_id=case_id,
        src_type=src_type,
        src_value=src_value,
        rel=rel,
        dst_type=dst_type,
        dst_value=dst_value,
    )
    session.add(relation)
    return relation
