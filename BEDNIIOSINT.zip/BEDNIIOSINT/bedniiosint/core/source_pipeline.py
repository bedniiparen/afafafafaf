from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..catalog import registry_entries, run_source
from ..config import settings
from ..monitoring import alerts
from ..monitoring.metrics import metrics
from ..storage.models import Case, Entity, Finding, Relation, TimelineEvent
from ..storage.sqlite import Storage
from .artifacts import capture_html_result, capture_raw_result
from .circuit_breaker import breaker
from .normalizer import NormalizedRecord, normalize_adapter_result
from .persist import add_entity_once, add_relation_once
from .source_context import SourceRunContext
from .source_record import record_source
from .target import detect_module


PIPELINE_SOURCES: dict[str, list[str]] = {
    "username": [
        "api:github",
        "api:gitlab",
        "api:hackernews",
        "api:codeforces",
        "api:bluesky",
        "api:dockerhub",
        "api:cratesio",
        "api:lichess",
        "api:duolingo",
        "api:reddit_about",
        "api:osintly_api",
    ],
    "email": [
        "api:gravatar",
        "api:emailrep",
        "api:hibp",
        "api:hunter",
        "api:github",
        "api:osintly_api",
    ],
    "domain": [
        "api:crtsh",
        "api:rdap",
        "api:google_dns",
        "api:cloudflare_dns",
        "api:hackertarget",
        "api:securitytrails",
        "api:hunter",
        "api:urlscan",
        "api:virustotal",
        "api:alienvault_otx",
        "api:wayback_cdx",
        "api:common_crawl",
        "api:gdelt",
        "api:osintly_api",
    ],
    "ip": [
        "api:rdap",
        "api:ipwhois",
        "api:ipinfo",
        "api:bgpview",
        "api:shodan",
        "api:censys",
        "api:abuseipdb",
        "api:greynoise",
        "api:virustotal",
        "api:alienvault_otx",
        "api:osintly_api",
    ],
    "phone": [
        "api:numverify",
        "api:veriphone",
        "api:twilio_lookup",
        "api:osintly_api",
    ],
    "wallet": [
        "api:blockchain_info",
        "api:blockstream",
        "api:blockchair",
        "api:osintly_api",
    ],
    "company": [
        "api:opencorporates",
        "api:companies_house",
        "api:wikidata",
        "api:peeringdb",
        "api:hunter",
        "api:gdelt",
    ],
    "url": [
        "api:urlscan",
        "api:wayback_cdx",
        "api:common_crawl",
        "api:virustotal",
        "api:alienvault_otx",
        "api:urlhaus",
    ],
    "address": [
        "api:nominatim",
        "api:osintly_api",
    ],
    "place": [
        "api:nominatim",
        "api:osintly_api",
    ],
    "query": [
        "api:gdelt",
        "api:github_search",
        "api:youtube",
        "api:google_cse",
        "api:open_measures",
        "api:osintly_api",
    ],
    "image_url": [
        "api:tineye",
    ],
    "image": [
        "api:tineye",
    ],
    "fediverse_account": [
        "api:mastodon_lookup",
    ],
}


@dataclass
class PipelineResult:
    target: str
    input_type: str
    sources: list[str]
    results: list[dict[str, Any]] = field(default_factory=list)
    normalized: list[dict[str, Any]] = field(default_factory=list)
    persisted: list[dict[str, Any]] = field(default_factory=list)
    persisted_case: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "input_type": self.input_type,
            "sources": self.sources,
            "results": self.results,
            "normalized": self.normalized,
            "persisted": self.persisted,
            "persisted_case": self.persisted_case,
            "counts": {
                "sources": len(self.sources),
                "results": len(self.results),
                "ok": sum(1 for row in self.results if row.get("status") == "ok"),
                "missing_keys": sum(
                    1 for row in self.results if row.get("status") == "missing_keys"
                ),
                "entities": sum(len(row.get("entities", [])) for row in self.normalized),
                "relations": sum(len(row.get("relations", [])) for row in self.normalized),
                "timeline": sum(len(row.get("timeline", [])) for row in self.normalized),
            },
        }


def pipeline_sources(
    input_type: str,
    *,
    available_only: bool = False,
    limit: int | None = None,
) -> list[str]:
    configured = {row.id: row for row in registry_entries() if row.kind == "api"}
    selected = [
        source_id
        for source_id in PIPELINE_SOURCES.get(input_type, [])
        if source_id in configured
    ]
    if available_only:
        selected = [source_id for source_id in selected if configured[source_id].configured]
    return selected[:limit] if limit else selected


def _event_key(event: dict[str, Any]) -> tuple[str, str, str, str]:
    return (
        str(event.get("kind") or ""),
        str(event.get("entity_type") or ""),
        str(event.get("entity_value") or ""),
        str(event.get("source") or ""),
    )


def _adapter_html(record: NormalizedRecord) -> str:
    raw = record.raw if isinstance(record.raw, dict) else {}
    text = str(raw.get("text") or "")
    if not text:
        return ""
    content_type = ""
    headers = raw.get("headers") if isinstance(raw.get("headers"), dict) else {}
    for key, value in headers.items():
        if str(key).lower() == "content-type":
            content_type = str(value).lower()
            break
    lowered = text[:200].lower()
    if "html" in content_type or "<html" in lowered or "<!doctype html" in lowered:
        return text
    return ""


def _append_unique(rows: list[dict[str, Any]], row: dict[str, Any]) -> None:
    if row not in rows:
        rows.append(row)


def _pipeline_error_result(
    source_id: str,
    target: str,
    input_type: str,
    status: str,
    error: str,
) -> dict[str, Any]:
    return {
        "source_id": source_id,
        "target": target,
        "status": status,
        "input_type": input_type,
        "method": "GET",
        "url": "",
        "status_code": None,
        "data": None,
        "text": "",
        "error": error,
        "headers": {},
        "missing_env": [],
        "normalized": {
            "entities": [{"type": input_type, "value": target}],
            "relations": [
                {
                    "src_type": input_type,
                    "src_value": target,
                    "rel": "not_checked_by",
                    "dst_type": "source",
                    "dst_value": source_id,
                }
            ],
            "findings": [
                {
                    "source_id": source_id,
                    "entity_type": input_type,
                    "entity_value": target,
                    "status": status,
                    "confidence": 0.0,
                    "reject_reason": error,
                }
            ],
            "timeline": [],
            "raw": {"error": error},
        },
        "cache_hit": False,
    }


def _source_failed(result: dict[str, Any]) -> bool:
    status = str(result.get("status") or "")
    status_code = result.get("status_code")
    if status == "error":
        return True
    try:
        return int(status_code) in {429, 500, 502, 503, 504}
    except (TypeError, ValueError):
        return False


def _dns_answers(row: dict[str, Any]) -> dict[str, str]:
    answers: dict[str, str] = {}
    if float(row.get("confidence") or 0.0) <= 0:
        return answers
    if str(row.get("status") or "") not in {"exists", "ok"}:
        return answers
    for relation in row.get("relations", []) or []:
        if str(relation.get("rel") or "") != "dns_answer":
            continue
        value = str(relation.get("dst_value") or "").strip()
        if value:
            answers[value] = str(relation.get("dst_type") or "dns_record")
    return answers


def _annotate_dns_resolver_corroboration(result: PipelineResult) -> None:
    if result.input_type != "domain":
        return
    by_source = {
        str(row.get("source_id") or ""): row
        for row in result.normalized
        if str(row.get("source_id") or "") in {"api:google_dns", "api:cloudflare_dns"}
    }
    if set(by_source) != {"api:google_dns", "api:cloudflare_dns"}:
        return
    google_answers = _dns_answers(by_source["api:google_dns"])
    cloudflare_answers = _dns_answers(by_source["api:cloudflare_dns"])
    matching = sorted(set(google_answers) & set(cloudflare_answers))
    if not matching:
        return
    resolver_pair = f"google_dns+cloudflare_dns:{len(matching)}"
    for normalized_row, result_row in zip(result.normalized, result.results, strict=False):
        if str(normalized_row.get("source_id") or "") not in by_source:
            continue
        entities = normalized_row.setdefault("entities", [])
        relations = normalized_row.setdefault("relations", [])
        timeline = normalized_row.setdefault("timeline", [])
        _append_unique(entities, {"type": "dns_corroboration", "value": resolver_pair})
        _append_unique(
            relations,
            {
                "src_type": "domain",
                "src_value": result.target,
                "rel": "dns_answer_corroborated_by",
                "dst_type": "dns_corroboration",
                "dst_value": resolver_pair,
            },
        )
        for answer in matching:
            _append_unique(
                relations,
                {
                    "src_type": "dns_corroboration",
                    "src_value": resolver_pair,
                    "rel": "matches_dns_answer",
                    "dst_type": google_answers.get(answer) or cloudflare_answers.get(answer) or "dns_record",
                    "dst_value": answer,
                },
            )
        _append_unique(
            timeline,
            {
                "kind": "dns_resolver_corroborated",
                "entity_type": "domain",
                "entity_value": result.target,
                "source": str(normalized_row.get("source_id") or ""),
                "confidence": min(0.9, float(normalized_row.get("confidence") or 0.0) + 0.05),
                "description": "Google DNS and Cloudflare DNS returned matching DNS answers",
            },
        )
        if not isinstance(result_row.get("normalized"), dict):
            result_row["normalized"] = {}
        normalized_payload = result_row["normalized"]
        normalized_payload["entities"] = entities
        normalized_payload["relations"] = relations
        normalized_payload["timeline"] = timeline


def persist_pipeline_result(
    result: PipelineResult,
    *,
    case_name: str,
) -> dict[str, Any]:
    storage = Storage(settings.db_path(case_name))
    records = [
        normalize_adapter_result(row)
        for row in result.results
    ]
    independent_counts: dict[tuple[str, str], set[str]] = {}
    for record in records:
        if record.confidence <= 0 or record.reject_reason:
            continue
        independent_counts.setdefault((record.input_type, record.target), set()).add(
            record.source_id
        )
    module = f"{result.input_type}_pipeline"
    finding_refs: list[tuple[int, NormalizedRecord]] = []
    seen_events: set[tuple[str, str, str, str]] = set()
    counts = {
        "entities": 0,
        "relations": 0,
        "sources": 0,
        "findings": 0,
        "timeline": 0,
        "evidence": 0,
    }
    with storage.session() as session:
        case = Case(name=case_name, target=result.target, module=module)
        session.add(case)
        session.commit()
        session.refresh(case)
        if case.id is None:
            raise RuntimeError("pipeline case was not persisted")

        for record in records:
            for entity in record.entities:
                add_entity_once(
                    session,
                    case_id=case.id,
                    type=entity["type"],
                    value=entity["value"],
                )
            add_entity_once(
                session,
                case_id=case.id,
                type="source",
                value=record.source_id,
            )

            for relation in record.relations:
                add_relation_once(session, case_id=case.id, **relation)

            rejected = bool(record.reject_reason) or record.status in {
                "missing_keys",
                "error",
                "not_exists",
            }
            independent = len(
                independent_counts.get((record.input_type, record.target), set())
            )
            boost = min(0.20, 0.05 * max(0, independent - 1)) if not rejected else 0.0
            confidence = round(min(1.0, record.confidence + boost), 3)
            confidence_markers = ["pipeline:normalized"]
            if boost:
                confidence_markers.append(
                    f"universal:independent_sources:+{boost:.2f}:{independent}"
                )
            record.confidence = confidence
            record_source(
                session,
                case_id=case.id,
                name=record.source_id,
                url_main=record.url,
                category=module,
                rejected=rejected,
                success_count=0 if rejected else 1,
                error_count=1 if record.status == "error" else 0,
                notes=record.reject_reason or "pipeline adapter output",
            )
            counts["sources"] += 1

            finding = Finding(
                case_id=case.id,
                source_name=record.source_id,
                source_id=record.source_id,
                entity_type=record.input_type,
                entity_value=record.target,
                finding_type="pipeline_adapter_result",
                profile_url=record.profile_url or record.url,
                status=record.status,
                status_code=record.status_code,
                page_title=record.title,
                matched_markers=",".join(confidence_markers),
                confidence=confidence,
                rejected=rejected,
                reject_reason=record.reject_reason,
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("pipeline finding was not persisted")
            finding_refs.append((finding.id, record))
            counts["findings"] += 1

            for event in record.timeline:
                key = _event_key(event)
                if key in seen_events:
                    continue
                seen_events.add(key)
                session.add(
                    TimelineEvent(
                        case_id=case.id,
                        finding_id=finding.id,
                        kind=event.get("kind", "adapter_observed"),
                        entity_type=event.get("entity_type", record.input_type),
                        entity_value=event.get("entity_value", record.target),
                        source_name=event.get("source", record.source_id),
                        confidence=float(event.get("confidence") or record.confidence),
                        description=event.get("description", ""),
                    )
                )
                counts["timeline"] += 1
            session.commit()

        case_id = case.id
        counts["entities"] = len(
            session.query(Entity).filter(Entity.case_id == case_id).all()
        )
        counts["relations"] = len(
            session.query(Relation).filter(Relation.case_id == case_id).all()
        )

    for finding_id, record in finding_refs:
        capture_raw_result(
            storage,
            case_name=case_name,
            case_id=case_id,
            finding_id=finding_id,
            source_module=module,
            payload=record.as_dict(),
            url=record.url,
            final_url=record.url,
            http_status=record.status_code,
            confidence=record.confidence,
            name_hint=record.source_id,
            headers=record.headers,
            method=record.method,
        )
        counts["evidence"] += 1
        html = _adapter_html(record)
        if html:
            capture_html_result(
                storage,
                case_name=case_name,
                case_id=case_id,
                finding_id=finding_id,
                source_module=module,
                html=html,
                url=record.url,
                final_url=record.url,
                http_status=record.status_code,
                confidence=record.confidence,
                name_hint=record.source_id,
                headers=record.headers,
                method=record.method,
            )
            counts["evidence"] += 1

    return {
        "meta": {
            "case": case_name,
            "module": module,
            "target": result.target,
            "input_type": result.input_type,
        },
        "counts": counts,
    }


def run_source_pipeline(
    target: str,
    *,
    input_type: str | None = None,
    source_ids: list[str] | None = None,
    limit: int | None = None,
    available_only: bool = False,
    save: bool = False,
    case_name: str | None = None,
    plugin_dir: Path | None = None,
    context: SourceRunContext | None = None,
) -> PipelineResult:
    selected_type = (input_type or detect_module(target)).strip().lower()
    sources = source_ids or pipeline_sources(
        selected_type,
        available_only=available_only,
        limit=limit,
    )
    if limit and source_ids:
        sources = source_ids[:limit]
    out = PipelineResult(target=target, input_type=selected_type, sources=sources)
    for source_id in sources:
        if breaker.is_open(source_id):
            result_dict = _pipeline_error_result(
                source_id,
                target,
                selected_type,
                "skipped",
                "source circuit breaker is open",
            )
            metrics.inc("source_skipped_total", source=source_id, reason="circuit_open")
        else:
            try:
                with metrics.timer("source_run_seconds"):
                    result = run_source(
                        source_id,
                        target,
                        plugin_dir=plugin_dir,
                        input_type=selected_type,
                        context=context,
                    )
                result_dict = result.as_dict()
            except Exception as exc:
                breaker.record_failure(source_id)
                alerts.notify("warning", "Source adapter failed", f"{source_id}: {exc}")
                result_dict = _pipeline_error_result(
                    source_id,
                    target,
                    selected_type,
                    "error",
                    str(exc),
                )
            else:
                if _source_failed(result_dict):
                    breaker.record_failure(source_id)
                    metrics.inc("source_failures_total", source=source_id)
                else:
                    breaker.record_success(source_id)
                    metrics.inc("source_success_total", source=source_id)
        out.results.append(result_dict)
        normalized = normalize_adapter_result(result_dict)
        normalized_dict = normalized.as_dict()
        out.normalized.append(normalized_dict)
    _annotate_dns_resolver_corroboration(out)
    if save:
        out.persisted_case = persist_pipeline_result(
            out,
            case_name=case_name or f"{selected_type}-pipeline",
        )
        out.persisted.append(out.persisted_case)
    return out
