from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
from typing import Any


ENCRYPTION_PASSPHRASE_ENV = "BEDNIIOSINT_ENCRYPTION_PASSPHRASE"
ENCRYPTION_SALT_ENV = "BEDNIIOSINT_ENCRYPTION_SALT"
ENVELOPE_PREFIX = "bedniiosint-field-v1:"
FIELD_KDF_ITERATIONS = 210_000
FIELD_ALGORITHM = "pbkdf2-sha256-hmac-stream-v1"


def field_encryption_enabled() -> bool:
    return bool(_configured_passphrase())


def field_encryption_status() -> dict[str, Any]:
    return {
        "enabled": field_encryption_enabled(),
        "algorithm": FIELD_ALGORITHM,
        "kdf": "pbkdf2-sha256",
        "iterations": FIELD_KDF_ITERATIONS,
        "passphrase_env": ENCRYPTION_PASSPHRASE_ENV,
        "salt_env": ENCRYPTION_SALT_ENV,
        "salt_env_set": bool(_configured_deployment_salt()),
        "secrets_returned": False,
    }


def is_encrypted_field(value: Any) -> bool:
    return isinstance(value, str) and value.startswith(ENVELOPE_PREFIX)


def encrypt_json_field(value: Any, *, passphrase: str | None = None, deployment_salt: str | None = None) -> str:
    secret = passphrase if passphrase is not None else _configured_passphrase()
    if not secret:
        raise RuntimeError(f"set {ENCRYPTION_PASSPHRASE_ENV} before encrypting fields")
    record_salt = secrets.token_bytes(16)
    nonce = secrets.token_bytes(16)
    key = _derive_key(secret, record_salt, _salt_bytes(deployment_salt))
    enc_key, mac_key = key[:32], key[32:]
    plaintext = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ciphertext = _xor_bytes(plaintext, _keystream(enc_key, nonce, len(plaintext)))
    tag = hmac.new(mac_key, b"bedniiosint-field-v1" + nonce + ciphertext, hashlib.sha256).digest()
    envelope = {
        "version": 1,
        "algorithm": FIELD_ALGORITHM,
        "kdf": "pbkdf2-sha256",
        "iterations": FIELD_KDF_ITERATIONS,
        "salt": _b64(record_salt),
        "nonce": _b64(nonce),
        "ciphertext": _b64(ciphertext),
        "tag": _b64(tag),
    }
    return ENVELOPE_PREFIX + _b64_json(envelope)


def decrypt_json_field(value: str, *, passphrase: str | None = None, deployment_salt: str | None = None) -> Any:
    if not is_encrypted_field(value):
        return json.loads(value or "")
    secret = passphrase if passphrase is not None else _configured_passphrase()
    if not secret:
        raise RuntimeError(f"set {ENCRYPTION_PASSPHRASE_ENV} before decrypting fields")
    envelope = _unb64_json(value[len(ENVELOPE_PREFIX) :])
    if envelope.get("version") != 1 or envelope.get("algorithm") != FIELD_ALGORITHM:
        raise ValueError("unsupported encrypted field envelope")
    record_salt = _unb64(str(envelope["salt"]))
    nonce = _unb64(str(envelope["nonce"]))
    ciphertext = _unb64(str(envelope["ciphertext"]))
    tag = _unb64(str(envelope["tag"]))
    key = _derive_key(secret, record_salt, _salt_bytes(deployment_salt), int(envelope.get("iterations") or 0))
    enc_key, mac_key = key[:32], key[32:]
    expected = hmac.new(mac_key, b"bedniiosint-field-v1" + nonce + ciphertext, hashlib.sha256).digest()
    if not hmac.compare_digest(expected, tag):
        raise ValueError("encrypted field authentication failed")
    plaintext = _xor_bytes(ciphertext, _keystream(enc_key, nonce, len(ciphertext)))
    return json.loads(plaintext.decode("utf-8"))


def encrypt_json_field_if_configured(value: Any) -> str:
    if not field_encryption_enabled():
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return encrypt_json_field(value)


def decrypt_json_field_if_needed(value: str, fallback: Any) -> Any:
    try:
        return decrypt_json_field(value)
    except (TypeError, ValueError, RuntimeError, json.JSONDecodeError):
        return fallback


def _configured_passphrase() -> str:
    return os.getenv(ENCRYPTION_PASSPHRASE_ENV, "").strip()


def _configured_deployment_salt() -> str:
    return os.getenv(ENCRYPTION_SALT_ENV, "").strip()


def _salt_bytes(explicit: str | None = None) -> bytes:
    value = explicit if explicit is not None else _configured_deployment_salt()
    return str(value or "").encode("utf-8")


def _derive_key(
    passphrase: str,
    record_salt: bytes,
    deployment_salt: bytes,
    iterations: int = FIELD_KDF_ITERATIONS,
) -> bytes:
    if iterations <= 0:
        raise ValueError("invalid encrypted field KDF iterations")
    salt = hashlib.sha256(deployment_salt + b"\0" + record_salt).digest()
    return hashlib.pbkdf2_hmac(
        "sha256",
        passphrase.encode("utf-8"),
        salt,
        iterations,
        dklen=64,
    )


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        out.extend(hmac.new(key, nonce + counter.to_bytes(8, "big"), hashlib.sha256).digest())
        counter += 1
    return bytes(out[:length])


def _xor_bytes(left: bytes, right: bytes) -> bytes:
    return bytes(a ^ b for a, b in zip(left, right))


def _b64(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii")


def _unb64(value: str) -> bytes:
    return base64.urlsafe_b64decode(value.encode("ascii"))


def _b64_json(value: dict[str, Any]) -> str:
    data = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return _b64(data)


def _unb64_json(value: str) -> dict[str, Any]:
    data = json.loads(_unb64(value).decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("encrypted field envelope must be a JSON object")
    return data
