from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Any

from ..catalog.registry import filter_registry


OPTIONAL_AUTH_MODES = {
    "none",
    "",
    "optional",
    "none_or_api_key",
    "api_key_or_community",
    "optional_api_key",
    "optional_api_token",
    "optional_token",
    "api_key_for_scan",
}


RUNBOOK_NOTES = {
    "source_live": [
        "Set BEDNIIOSINT_SOURCE_LIVE_TARGET for the selected source when its live test needs a target.",
        "Set BEDNIIOSINT_SOURCE_LIVE_ALLOW_OPT_IN=1 only after legal/privacy review for opt-in sources.",
    ],
    "tineye_image_url_live": [
        "Use a public test image URL that the analyst is allowed to submit to TinEye.",
        "Reverse-image matches are review signals, not identity proof.",
    ],
    "tineye_image_upload_live": [
        "Local image upload sends the file to TinEye and requires explicit upload and sensitive-source opt-in.",
        "Use image URL lookup for private media unless an analyst approves upload.",
    ],
    "opencti_preflight_live": [
        "Preflight checks endpoint/token compatibility without sending case payloads.",
    ],
    "misp_preflight_live": [
        "Preflight checks MISP endpoint/key compatibility without sending case payloads.",
    ],
    "opencti_send_live": [
        "Send tests require BEDNIIOSINT_CTI_LIVE_SEND=1 because they POST to a real OpenCTI endpoint.",
        "Use BEDNIIOSINT_CTI_LIVE_READ_BACK=1 when the instance returns a remote object id.",
    ],
    "opencti_patch_map_live": [
        "Use OPENCTI_PATCH_MAP when schema introspection is disabled or custom entity mutations differ.",
        "Use BEDNIIOSINT_CTI_LIVE_CLEANUP=1 only when the test object may be deleted after validation.",
    ],
    "misp_send_live": [
        "Send tests create an unpublished review event by default.",
        "Use BEDNIIOSINT_CTI_LIVE_CLEANUP=1 only when the created event may be deleted after validation.",
    ],
}


def live_validation_plan(env: Mapping[str, str] | None = None) -> dict[str, Any]:
    values = env or os.environ
    sections = [
        _source_live_plan(values),
        _tineye_url_plan(values),
        _tineye_upload_plan(values),
        _cti_opencti_preflight_plan(values),
        _cti_misp_preflight_plan(values),
        _cti_opencti_send_plan(values),
        _cti_opencti_patch_map_plan(values),
        _cti_misp_send_plan(values),
    ]
    return {
        "network_required": True,
        "secrets_returned": False,
        "ready": [row for row in sections if row["status"] == "ready"],
        "blocked": [row for row in sections if row["status"] == "blocked"],
        "disabled": [row for row in sections if row["status"] == "disabled"],
        "sections": sections,
        "summary": {
            "ready": len([row for row in sections if row["status"] == "ready"]),
            "blocked": len([row for row in sections if row["status"] == "blocked"]),
            "disabled": len([row for row in sections if row["status"] == "disabled"]),
        },
    }


def live_validation_runbook(plan: Mapping[str, Any] | None = None) -> str:
    data = dict(plan or live_validation_plan())
    summary = data.get("summary") or {}
    sections = list(data.get("sections") or [])
    lines = [
        "# BEDNIIOSINT Live Validation Runbook",
        "",
        "This runbook lists environment variable names and commands only. It does not print secret values.",
        "",
        "## Summary",
        "",
        f"- Network required: {_yes_no(data.get('network_required'))}",
        f"- Secrets returned: {_yes_no(data.get('secrets_returned'))}",
        f"- Ready sections: {int(summary.get('ready') or 0)}",
        f"- Blocked sections: {int(summary.get('blocked') or 0)}",
        f"- Disabled sections: {int(summary.get('disabled') or 0)}",
        "",
        "## Safety Notes",
        "",
        "- Run live checks only with user-provided credentials and approved network access.",
        "- Keep uploads disabled unless the media/file owner and investigation scope allow third-party submission.",
        "- Treat source matches as evidence candidates until corroborated by independent sources.",
        "",
        "## Validation Sections",
        "",
    ]
    for row in sections:
        name = str(row.get("name") or "unnamed")
        required_env = [str(item) for item in row.get("required_env") or []]
        missing_env = [str(item) for item in row.get("missing_env") or []]
        command = str(row.get("command") or "")
        lines.extend(
            [
                f"### {name}",
                "",
                f"- Status: `{row.get('status') or 'unknown'}`",
                f"- Enabled: `{_yes_no(row.get('enabled'))}`",
                f"- Required env: {_env_list(required_env)}",
                f"- Missing env: {_env_list(missing_env) if missing_env else 'none'}",
                f"- Command: `{command}`" if command else "- Command: none",
                f"- Next action: {_next_action(row)}",
            ]
        )
        notes = RUNBOOK_NOTES.get(name, [])
        if notes:
            lines.append("- Notes:")
            for note in notes:
                lines.append(f"  - {note}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def live_account_validation_runbook(
    env: Mapping[str, str] | None = None,
    *,
    priorities: tuple[str, ...] = ("P0", "P1"),
) -> str:
    values = env or os.environ
    wanted = {item.upper() for item in priorities if item}
    rows = [
        row
        for row in filter_registry(kind="api", runnable=True)
        if row.env_vars and (not wanted or str(row.priority or "").upper() in wanted)
    ]
    sections = [_account_row(row, values) for row in rows]
    ready = sum(1 for row in sections if row["status"] == "ready")
    blocked = sum(1 for row in sections if row["status"] == "blocked")
    optional_missing = sum(1 for row in sections if row["status"] == "optional_missing")
    lines = [
        "# BEDNIIOSINT Live Account Validation Runbook",
        "",
        "This runbook is offline. It lists provider account readiness, environment variable names and commands only; it never prints secret values.",
        "",
        "## Summary",
        "",
        f"- Priorities: {', '.join(sorted(wanted)) if wanted else 'all'}",
        f"- Keyed runnable sources: {len(sections)}",
        f"- Ready: {ready}",
        f"- Blocked: {blocked}",
        f"- Optional keys missing: {optional_missing}",
        "",
        "## Safety Notes",
        "",
        "- Run live checks only with user-provided accounts, approved targets and network permission.",
        "- Use `--allow-opt-in` only after legal/privacy review for opt-in sources.",
        "- Treat successful live account checks as provider connectivity proof, not as evidence about a target.",
        "",
        "## Account Checks",
        "",
    ]
    for row in sections:
        lines.extend(
            [
                f"### {row['source_id']}",
                "",
                f"- Name: {row['name']}",
                f"- Priority: `{row['priority']}`",
                f"- Status: `{row['status']}`",
                f"- Terms/privacy risk: `{row['terms_risk']}`",
                f"- Required key vars: {_env_list(row['required_env'])}",
                f"- Missing key vars: {_env_list(row['missing_env']) if row['missing_env'] else 'none'}",
                f"- Legal/privacy opt-in required: `{_yes_no(row['requires_opt_in'])}`",
                f"- Suggested target placeholder: `{row['target']}`",
                f"- CLI check: `{row['command']}`",
                f"- Pytest opt-in env: `BEDNIIOSINT_SOURCE_LIVE_TESTS=1`, `BEDNIIOSINT_SOURCE_LIVE_ID={row['source_id']}`",
                f"- Next action: {row['next_action']}",
                "",
            ]
        )
    return "\n".join(lines).rstrip() + "\n"


def _source_live_plan(env: Mapping[str, str]) -> dict[str, Any]:
    required = ["BEDNIIOSINT_SOURCE_LIVE_TESTS", "BEDNIIOSINT_SOURCE_LIVE_ID"]
    source_id = _env(env, "BEDNIIOSINT_SOURCE_LIVE_ID")
    missing = _missing(env, required)
    extra_missing: list[str] = []
    if source_id:
        rows = filter_registry(runnable=True)
        needle = _normalize_source_id(source_id)
        selected = [row for row in rows if _normalize_source_id(row.id) == needle]
        if selected:
            row = selected[0]
            if row.env_vars and str(row.auth or "").lower() not in OPTIONAL_AUTH_MODES:
                extra_missing = _missing(env, row.env_vars)
        else:
            extra_missing = [f"unknown source id: {source_id}"]
    return _plan_row(
        "source_live",
        enabled=_env(env, "BEDNIIOSINT_SOURCE_LIVE_TESTS") == "1",
        required=required,
        missing=[*missing, *extra_missing],
        command="pytest -q tests/test_source_live.py",
    )


def _tineye_url_plan(env: Mapping[str, str]) -> dict[str, Any]:
    required = ["BEDNIIOSINT_MEDIA_LIVE_TESTS", "TINEYE_API_KEY", "TINEYE_LIVE_IMAGE_URL"]
    return _plan_row(
        "tineye_image_url_live",
        enabled=_env(env, "BEDNIIOSINT_MEDIA_LIVE_TESTS") == "1",
        required=required,
        missing=_missing(env, required),
        command="pytest -q tests/test_source_live.py",
    )


def _tineye_upload_plan(env: Mapping[str, str]) -> dict[str, Any]:
    required = [
        "BEDNIIOSINT_MEDIA_LIVE_TESTS",
        "BEDNIIOSINT_MEDIA_LIVE_UPLOAD",
        "TINEYE_API_KEY",
        "TINEYE_LIVE_IMAGE_PATH",
    ]
    return _plan_row(
        "tineye_image_upload_live",
        enabled=_env(env, "BEDNIIOSINT_MEDIA_LIVE_TESTS") == "1"
        and _env(env, "BEDNIIOSINT_MEDIA_LIVE_UPLOAD") == "1",
        required=required,
        missing=_missing(env, required),
        command="pytest -q tests/test_source_live.py",
    )


def _cti_opencti_preflight_plan(env: Mapping[str, str]) -> dict[str, Any]:
    required = ["BEDNIIOSINT_CTI_LIVE_TESTS", "OPENCTI_URL", "OPENCTI_TOKEN"]
    return _plan_row(
        "opencti_preflight_live",
        enabled=_env(env, "BEDNIIOSINT_CTI_LIVE_TESTS") == "1",
        required=required,
        missing=_missing(env, required),
        command="pytest -q tests/test_cti_live.py",
    )


def _cti_misp_preflight_plan(env: Mapping[str, str]) -> dict[str, Any]:
    required = ["BEDNIIOSINT_CTI_LIVE_TESTS", "MISP_URL", "MISP_API_KEY"]
    return _plan_row(
        "misp_preflight_live",
        enabled=_env(env, "BEDNIIOSINT_CTI_LIVE_TESTS") == "1",
        required=required,
        missing=_missing(env, required),
        command="pytest -q tests/test_cti_live.py",
    )


def _cti_opencti_send_plan(env: Mapping[str, str]) -> dict[str, Any]:
    required = [
        "BEDNIIOSINT_CTI_LIVE_TESTS",
        "BEDNIIOSINT_CTI_LIVE_SEND",
        "OPENCTI_SYNC_URL",
        "OPENCTI_TOKEN",
    ]
    return _plan_row(
        "opencti_send_live",
        enabled=_env(env, "BEDNIIOSINT_CTI_LIVE_TESTS") == "1"
        and _env(env, "BEDNIIOSINT_CTI_LIVE_SEND") == "1",
        required=required,
        missing=_missing(env, required),
        command="pytest -q tests/test_cti_live.py",
    )


def _cti_opencti_patch_map_plan(env: Mapping[str, str]) -> dict[str, Any]:
    required = [
        "BEDNIIOSINT_CTI_LIVE_TESTS",
        "BEDNIIOSINT_CTI_LIVE_SEND",
        "BEDNIIOSINT_CTI_LIVE_PATCH",
        "OPENCTI_SYNC_URL",
        "OPENCTI_TOKEN",
        "OPENCTI_PATCH_FIELD",
        "OPENCTI_PATCH_MAP",
    ]
    return _plan_row(
        "opencti_patch_map_live",
        enabled=_env(env, "BEDNIIOSINT_CTI_LIVE_TESTS") == "1"
        and _env(env, "BEDNIIOSINT_CTI_LIVE_SEND") == "1"
        and _env(env, "BEDNIIOSINT_CTI_LIVE_PATCH") == "1",
        required=required,
        missing=_missing(env, required),
        command="pytest -q tests/test_cti_live.py",
    )


def _cti_misp_send_plan(env: Mapping[str, str]) -> dict[str, Any]:
    required = [
        "BEDNIIOSINT_CTI_LIVE_TESTS",
        "BEDNIIOSINT_CTI_LIVE_SEND",
        "MISP_URL",
        "MISP_API_KEY",
    ]
    return _plan_row(
        "misp_send_live",
        enabled=_env(env, "BEDNIIOSINT_CTI_LIVE_TESTS") == "1"
        and _env(env, "BEDNIIOSINT_CTI_LIVE_SEND") == "1",
        required=required,
        missing=_missing(env, required),
        command="pytest -q tests/test_cti_live.py",
    )


def _account_row(row: Any, env: Mapping[str, str]) -> dict[str, Any]:
    required = str(row.auth or "").lower() not in OPTIONAL_AUTH_MODES
    missing = _missing(env, list(row.env_vars))
    if required and missing:
        status = "blocked"
    elif missing:
        status = "optional_missing"
    else:
        status = "ready"
    target = _sample_target(row.inputs[0] if row.inputs else "target")
    allow_opt_in = " --allow-opt-in" if row.requires_opt_in else ""
    command = f"bedniiosint source-verify --mode live --source {row.id} --target {target}{allow_opt_in}"
    return {
        "source_id": row.id,
        "name": row.name,
        "priority": row.priority,
        "status": status,
        "terms_risk": row.terms_risk,
        "required_env": list(row.env_vars),
        "missing_env": missing,
        "requires_opt_in": row.requires_opt_in,
        "target": target,
        "command": command,
        "next_action": _account_next_action(status, missing, row.requires_opt_in),
    }


def _account_next_action(status: str, missing: list[str], requires_opt_in: bool) -> str:
    if status == "blocked":
        return f"set missing key vars: {_env_list(missing)}"
    if status == "optional_missing":
        return f"set optional key vars for fuller validation: {_env_list(missing)}"
    if requires_opt_in:
        return "confirm legal/privacy scope, then run the command with opt-in"
    return "run the command when network access and provider account use are approved"


def _plan_row(
    name: str,
    *,
    enabled: bool,
    required: list[str],
    missing: list[str],
    command: str,
) -> dict[str, Any]:
    missing = sorted(set(missing))
    status = "ready" if enabled and not missing else "blocked" if enabled else "disabled"
    return {
        "name": name,
        "status": status,
        "enabled": enabled,
        "required_env": required,
        "missing_env": missing,
        "command": command,
    }


def _missing(env: Mapping[str, str], names: list[str]) -> list[str]:
    return [name for name in names if not _env(env, name)]


def _env(env: Mapping[str, str], name: str) -> str:
    return str(env.get(name) or "").strip()


def _normalize_source_id(source_id: str) -> str:
    return source_id.lower().removeprefix("api:").removeprefix("module:").removeprefix("plugin:")


def _env_list(names: list[str]) -> str:
    if not names:
        return "none"
    return ", ".join(f"`{name}`" for name in names)


def _next_action(row: Mapping[str, Any]) -> str:
    status = str(row.get("status") or "")
    missing = [str(item) for item in row.get("missing_env") or []]
    if status == "ready":
        return "run the command when network access and provider accounts are approved"
    if status == "blocked" and missing:
        return f"set missing env vars: {_env_list(missing)}"
    if status == "disabled":
        return "enable the relevant live-test opt-in env vars, then re-run live-plan"
    return "review the section status"


def _yes_no(value: Any) -> str:
    return "yes" if bool(value) else "no"


def _sample_target(input_type: str) -> str:
    return {
        "address": "1600 Amphitheatre Parkway, Mountain View, CA",
        "asn": "AS15169",
        "company": "Example Inc",
        "domain": "example.com",
        "email": "alice@example.com",
        "hash": "a" * 64,
        "image": "https://example.com/image.jpg",
        "ip": "8.8.8.8",
        "phone": "+15551234567",
        "query": "Example Inc",
        "url": "https://example.com/",
        "username": "octocat",
    }.get(input_type, "example.com")
