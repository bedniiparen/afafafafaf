from __future__ import annotations

import logging
from datetime import datetime
from urllib.parse import urlparse

from ..config import settings
from ..modules.company.analyzer import analyze_company
from ..modules.ip.analyzer import analyze_ip
from ..modules.phone.analyzer import analyze_phone
from ..modules.url.analyzer import fetch_and_parse, score_url_profile
from ..modules.wallet.analyzer import analyze_wallet
from ..storage.models import Case, Entity, Finding, Relation
from ..storage.sqlite import Storage
from .artifacts import capture_html_result, capture_raw_result
from .confidence import markers_to_text
from .source_record import record_source
from .timeline import add_event

logger = logging.getLogger(__name__)


class _Base:
    module = "base"

    def __init__(self, case_name: str):
        self.case_name = case_name
        self.storage = Storage(settings.db_path(case_name))

    def _new_case(self, target: str) -> int:
        with self.storage.session() as session:
            case = Case(name=self.case_name, target=target, module=self.module)
            session.add(case)
            session.commit()
            session.refresh(case)
            if case.id is None:
                raise RuntimeError("case was not persisted")
            return case.id


class PhoneCase(_Base):
    module = "phone"

    def __init__(self, case_name: str, number: str, region: str | None = None):
        super().__init__(case_name)
        self.number = number
        self.region = region

    def run(self) -> dict:
        result = analyze_phone(self.number, self.region)
        entity_value = result.e164 or self.number
        case_id = self._new_case(entity_value)
        with self.storage.session() as session:
            session.add(Entity(case_id=case_id, type="phone", value=entity_value))
            rejected = bool(result.reject_reason)
            source = record_source(
                session,
                case_id=case_id,
                name="phone-analyzer",
                category="phone",
                rejected=rejected,
                notes=result.reject_reason or "scored phone validation signals",
            )
            finding = Finding(
                case_id=case_id,
                source_name="phone-analyzer",
                source_reliability=source.reliability,
                entity_value=entity_value,
                profile_url=f"tel:{result.e164}",
                status="exists" if result.valid else "not_exists",
                page_title=f"{result.country} {result.carrier} {result.line_type}",
                matched_markers=markers_to_text(result.matched_markers),
                confidence=result.confidence,
                rejected=rejected,
                reject_reason=result.reject_reason,
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("finding was not persisted")
            capture_raw_result(
                self.storage,
                case_name=self.case_name,
                case_id=case_id,
                finding_id=finding.id,
                source_module="phone",
                payload=result.__dict__,
                url=f"tel:{result.e164 or self.number}",
                confidence=result.confidence,
                name_hint="phone-analyzer",
            )
        return {
            "meta": {"case": self.case_name, "module": "phone"},
            "result": result.__dict__,
        }


class URLCase(_Base):
    module = "url"

    def __init__(self, case_name: str, url: str):
        super().__init__(case_name)
        self.url = url

    def run(self) -> dict:
        url = self.url.strip()
        if not urlparse(url).scheme:
            url = f"https://{url}"
        profile, html, status_code = fetch_and_parse(url)
        case_id = self._new_case(url)
        with self.storage.session() as session:
            session.add(Entity(case_id=case_id, type="url", value=url))
            title = profile.title if profile else ""
            scoring = score_url_profile(profile, status_code)
            rejected = bool(scoring.reject_reason)
            source = record_source(
                session,
                case_id=case_id,
                name="url-analyzer",
                url_main=url,
                category="url",
                rejected=rejected,
                success_count=1 if status_code and status_code < 400 else 0,
                error_count=0 if status_code and status_code < 400 else 1,
                notes=scoring.reject_reason or "scored HTTP/profile extraction signals",
            )
            finding = Finding(
                case_id=case_id,
                source_name="url-analyzer",
                source_reliability=source.reliability,
                entity_value=url,
                profile_url=url,
                status="exists" if status_code and status_code < 400 else "unknown",
                status_code=status_code,
                page_title=title,
                matched_markers=markers_to_text(scoring.matched_markers),
                confidence=scoring.confidence,
                rejected=rejected,
                reject_reason=scoring.reject_reason,
            )
            session.add(finding)
            if profile:
                for link in profile.outbound_links:
                    session.add(Entity(case_id=case_id, type="url", value=link))
                    session.add(
                        Relation(
                            case_id=case_id,
                            src_type="url",
                            src_value=url,
                            rel="links_to",
                            dst_type="url",
                            dst_value=link,
                        )
                    )
                for social, links in profile.social_links.items():
                    for link in links:
                        session.add(
                            Relation(
                                case_id=case_id,
                                src_type="url",
                                src_value=url,
                                rel=f"links_to_{social}",
                                dst_type="url",
                                dst_value=link,
                            )
                        )
                for email in profile.emails:
                    session.add(Entity(case_id=case_id, type="email", value=email))
                    session.add(
                        Relation(
                            case_id=case_id,
                            src_type="url",
                            src_value=url,
                            rel="mentions_email",
                            dst_type="email",
                            dst_value=email,
                        )
                    )
                for chain, wallets in profile.wallets.items():
                    for wallet in wallets:
                        session.add(Entity(case_id=case_id, type="wallet", value=wallet))
                        session.add(
                            Relation(
                                case_id=case_id,
                                src_type="url",
                                src_value=url,
                                rel=f"mentions_{chain}_wallet",
                                dst_type="wallet",
                                dst_value=wallet,
                            )
                        )
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("finding was not persisted")
            capture_html_result(
                self.storage,
                case_name=self.case_name,
                case_id=case_id,
                finding_id=finding.id,
                source_module="url",
                html=html,
                url=url,
                final_url=url,
                http_status=status_code,
                confidence=scoring.confidence,
                name_hint="url-analyzer",
            )
            capture_raw_result(
                self.storage,
                case_name=self.case_name,
                case_id=case_id,
                finding_id=finding.id,
                source_module="url",
                payload={
                    "url": url,
                    "status_code": status_code,
                    "html_bytes": len(html),
                    "profile": profile.__dict__ if profile else None,
                    "confidence": scoring.confidence,
                    "matched_markers": scoring.matched_markers,
                    "reject_reason": scoring.reject_reason,
                },
                url=url,
                final_url=url,
                http_status=status_code,
                confidence=scoring.confidence,
                name_hint="url-profile",
            )
        return {
            "meta": {"case": self.case_name, "module": "url", "url": url},
            "result": {
                "url": url,
                "status_code": status_code,
                "html_bytes": len(html),
                "profile": profile.__dict__ if profile else None,
                "confidence": scoring.confidence,
                "matched_markers": scoring.matched_markers,
                "reject_reason": scoring.reject_reason,
            },
        }


class WalletCase(_Base):
    module = "wallet"

    def __init__(self, case_name: str, address: str):
        super().__init__(case_name)
        self.address = address

    def run(self) -> dict:
        result = analyze_wallet(self.address)
        case_id = self._new_case(result.address)
        with self.storage.session() as session:
            session.add(Entity(case_id=case_id, type="wallet", value=result.address))
            source_name = f"{result.chain}-explorer"
            rejected = bool(result.reject_reason)
            source = record_source(
                session,
                case_id=case_id,
                name=source_name,
                category="wallet",
                rejected=rejected,
                success_count=1 if result.found else 0,
                error_count=1 if result.note and not result.found else 0,
                notes=result.reject_reason or "scored wallet explorer signals",
            )
            finding = Finding(
                case_id=case_id,
                source_name=source_name,
                source_reliability=source.reliability,
                entity_value=result.address,
                profile_url=result.address,
                status="exists" if result.found else "unknown",
                page_title=(
                    f"chain={result.chain} bal={result.balance} tx={result.tx_count}"
                ),
                matched_markers=markers_to_text(result.matched_markers),
                confidence=result.confidence,
                rejected=rejected,
                reject_reason=result.reject_reason,
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("finding was not persisted")
            capture_raw_result(
                self.storage,
                case_name=self.case_name,
                case_id=case_id,
                finding_id=finding.id,
                source_module="wallet",
                payload=result.__dict__,
                url=result.address,
                confidence=result.confidence,
                name_hint=source_name,
            )
        if result.first_seen:
            try:
                add_event(
                    self.storage,
                    case_id,
                    kind="first_seen",
                    entity_type="wallet",
                    entity_value=result.address,
                    when=datetime.fromisoformat(result.first_seen.replace("Z", "+00:00")),
                    source=result.chain,
                    description="First on-chain activity",
                )
            except Exception as exc:
                logger.debug("case_extra: failed to build wallet timeline entry: %s", exc)
        return {
            "meta": {"case": self.case_name, "module": "wallet"},
            "result": result.__dict__,
        }


class IPCase(_Base):
    module = "ip"

    def __init__(self, case_name: str, ip: str):
        super().__init__(case_name)
        self.ip = ip

    def run(self) -> dict:
        result = analyze_ip(self.ip)
        case_id = self._new_case(result.ip)
        with self.storage.session() as session:
            session.add(Entity(case_id=case_id, type="ip", value=result.ip))
            for host in result.reverse_dns:
                clean_host = host.rstrip(".")
                session.add(Entity(case_id=case_id, type="domain", value=clean_host))
                session.add(
                    Relation(
                        case_id=case_id,
                        src_type="ip",
                        src_value=result.ip,
                        rel="links_to",
                        dst_type="domain",
                        dst_value=clean_host,
                    )
                )
            rejected = bool(result.reject_reason)
            source = record_source(
                session,
                case_id=case_id,
                name="ip-analyzer",
                url_main=f"https://ipwho.is/{result.ip}",
                category="ip",
                rejected=rejected,
                success_count=0 if result.note and result.valid and not result.is_private else 1,
                error_count=1 if result.note and result.valid and not result.is_private else 0,
                notes=result.reject_reason or "scored IP validation/geolocation signals",
            )
            finding = Finding(
                case_id=case_id,
                source_name="ip-analyzer",
                source_reliability=source.reliability,
                entity_value=result.ip,
                profile_url=f"https://ipwho.is/{result.ip}",
                status="exists" if result.valid else "not_exists",
                page_title=f"{result.city} {result.country} {result.asn}",
                matched_markers=markers_to_text(result.matched_markers),
                confidence=result.confidence,
                rejected=rejected,
                reject_reason=result.reject_reason,
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("finding was not persisted")
            capture_raw_result(
                self.storage,
                case_name=self.case_name,
                case_id=case_id,
                finding_id=finding.id,
                source_module="ip",
                payload=result.__dict__,
                url=f"https://ipwho.is/{result.ip}",
                confidence=result.confidence,
                name_hint="ip-analyzer",
            )
        return {
            "meta": {"case": self.case_name, "module": "ip"},
            "result": result.__dict__,
        }


class CompanyCase(_Base):
    module = "company"

    def __init__(self, case_name: str, name: str, domain: str | None = None):
        super().__init__(case_name)
        self.name = name
        self.domain = domain

    def run(self) -> dict:
        result = analyze_company(self.name, self.domain)
        case_id = self._new_case(result.name)
        with self.storage.session() as session:
            session.add(Entity(case_id=case_id, type="company", value=result.name))
            if result.guessed_domain:
                session.add(Entity(case_id=case_id, type="domain", value=result.guessed_domain))
                session.add(
                    Relation(
                        case_id=case_id,
                        src_type="company",
                        src_value=result.name,
                        rel="owns_domain",
                        dst_type="domain",
                        dst_value=result.guessed_domain,
                    )
                )
            rejected = bool(result.reject_reason)
            source = record_source(
                session,
                case_id=case_id,
                name="company-analyzer",
                url_main=f"https://{result.guessed_domain}" if result.guessed_domain else "",
                category="company",
                rejected=rejected,
                success_count=0 if result.note else 1,
                error_count=1 if result.note else 0,
                notes=result.reject_reason or "scored company/domain/registry signals",
            )
            finding = Finding(
                case_id=case_id,
                source_name="company-analyzer",
                source_reliability=source.reliability,
                entity_value=result.name,
                profile_url=f"https://{result.guessed_domain}",
                status="exists" if result.confidence > 0.4 else "unknown",
                page_title=f"registry_matches={len(result.registry_matches)}",
                matched_markers=markers_to_text(result.matched_markers),
                confidence=result.confidence,
                rejected=rejected,
                reject_reason=result.reject_reason,
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("finding was not persisted")
            capture_raw_result(
                self.storage,
                case_name=self.case_name,
                case_id=case_id,
                finding_id=finding.id,
                source_module="company",
                payload=result.__dict__,
                url=f"https://{result.guessed_domain}" if result.guessed_domain else "",
                confidence=result.confidence,
                name_hint="company-analyzer",
            )
        return {
            "meta": {"case": self.case_name, "module": "company"},
            "result": result.__dict__,
        }
