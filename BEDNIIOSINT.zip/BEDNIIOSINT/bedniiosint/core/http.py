from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any
from threading import Lock
from urllib.parse import urlparse

import httpx

from ..config import settings
from ..monitoring.metrics import metrics
from .netpolicy import (
    apply_jitter,
    cache_ttl_from_headers,
    response_cache,
    select_proxy,
    select_user_agent,
)


@dataclass(frozen=True)
class HttpPolicy:
    timeout: float = settings.timeout
    max_retries: int = settings.http_max_retries
    backoff: float = settings.http_backoff
    rate_limit_delay: float = settings.http_rate_limit_delay
    user_agent: str = settings.user_agent
    retry_statuses: tuple[int, ...] = (429, 500, 502, 503, 504)


_last_request_by_host: dict[str, float] = {}
_rate_lock = Lock()
_async_rate_locks: dict[int, asyncio.Lock] = {}
_async_rate_locks_guard = Lock()


def _host(url: str) -> str:
    return urlparse(url).netloc.lower()


def _retry_delay(response: httpx.Response | None, attempt: int, policy: HttpPolicy) -> float:
    if response is not None:
        retry_after = response.headers.get("Retry-After")
        if retry_after:
            try:
                return min(float(retry_after), 30.0)
            except ValueError:
                pass
    return min(policy.backoff * (2**attempt), 30.0)


def _request_headers(kwargs: dict[str, Any]) -> dict[str, str]:
    headers = kwargs.get("headers") or {}
    return {str(key).lower(): str(value) for key, value in dict(headers).items()}


def _has_secret_headers(kwargs: dict[str, Any]) -> bool:
    headers = _request_headers(kwargs)
    secret_markers = ("authorization", "cookie", "x-api-key", "x-apikey", "api-key")
    return any(name in headers for name in secret_markers)


def _cache_key(method: str, url: str, kwargs: dict[str, Any]) -> str:
    material = {
        "params": kwargs.get("params"),
        "json": kwargs.get("json"),
        "data": kwargs.get("data"),
        "content": kwargs.get("content"),
    }
    return response_cache.key(method, url, params=material)


def _cache_allowed(
    method: str,
    kwargs: dict[str, Any],
    *,
    owns_client: bool,
) -> bool:
    return (
        method.upper() in {"GET", "HEAD"}
        and owns_client
        and not kwargs.get("stream")
        and not _has_secret_headers(kwargs)
    )


def _cached_response(method: str, url: str, cache_key: str) -> httpx.Response | None:
    cached = response_cache.get(cache_key)
    if not isinstance(cached, dict):
        return None
    request_obj = httpx.Request(method.upper(), url)
    response = httpx.Response(
        int(cached.get("status_code") or 200),
        headers=dict(cached.get("headers") or {}),
        content=bytes(cached.get("content") or b""),
        request=request_obj,
    )
    response.extensions["bedniiosint_cache_hit"] = True
    return response


def _store_cached_response(cache_key: str, response: httpx.Response) -> None:
    if response.status_code >= 400:
        return
    ttl = cache_ttl_from_headers(response.headers)
    response_cache.set(
        cache_key,
        {
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "content": response.content,
        },
        ttl=ttl,
    )


def _client_kwargs(policy: HttpPolicy) -> dict[str, Any]:
    headers = {
        "User-Agent": select_user_agent() if settings.rotate_user_agents else policy.user_agent
    }
    kwargs: dict[str, Any] = {
        "follow_redirects": True,
        "timeout": policy.timeout,
        "headers": headers,
    }
    proxy = select_proxy()
    if proxy:
        kwargs["proxy"] = proxy
    return kwargs


def _wait_rate_limit(url: str, policy: HttpPolicy) -> None:
    if policy.rate_limit_delay <= 0:
        return
    host = _host(url)
    if not host:
        return
    with _rate_lock:
        now = time.monotonic()
        wait = policy.rate_limit_delay - (now - _last_request_by_host.get(host, 0.0))
        if wait > 0:
            time.sleep(wait)
        _last_request_by_host[host] = time.monotonic()


async def _async_wait_rate_limit(url: str, policy: HttpPolicy) -> None:
    if policy.rate_limit_delay <= 0:
        return
    host = _host(url)
    if not host:
        return
    loop_id = id(asyncio.get_running_loop())
    with _async_rate_locks_guard:
        loop_lock = _async_rate_locks.get(loop_id)
        if loop_lock is None:
            loop_lock = asyncio.Lock()
            _async_rate_locks[loop_id] = loop_lock
    async with loop_lock:
        while True:
            with _rate_lock:
                now = time.monotonic()
                wait = policy.rate_limit_delay - (
                    now - _last_request_by_host.get(host, 0.0)
                )
                if wait <= 0:
                    _last_request_by_host[host] = time.monotonic()
                    return
            await asyncio.sleep(wait)


def request(
    method: str,
    url: str,
    *,
    client: httpx.Client | None = None,
    policy: HttpPolicy | None = None,
    **kwargs,
) -> httpx.Response:
    policy = policy or HttpPolicy()
    owns_client = client is None
    cache_key = _cache_key(method, url, kwargs)
    use_cache = _cache_allowed(method, kwargs, owns_client=owns_client)
    if use_cache:
        cached = _cached_response(method, url, cache_key)
        if cached is not None:
            metrics.inc("http_cache_hits_total", method=method.upper(), host=_host(url))
            return cached
    if client is None:
        client = httpx.Client(**_client_kwargs(policy))
    try:
        for attempt in range(policy.max_retries + 1):
            _wait_rate_limit(url, policy)
            apply_jitter()
            response: httpx.Response | None = None
            try:
                with metrics.timer("http_request_seconds"):
                    response = client.request(method.upper(), url, **kwargs)
            except httpx.HTTPError:
                metrics.inc("http_errors_total", method=method.upper(), host=_host(url))
                if attempt >= policy.max_retries:
                    raise
                time.sleep(_retry_delay(None, attempt, policy))
                continue
            if (
                response.status_code not in policy.retry_statuses
                or attempt >= policy.max_retries
            ):
                metrics.inc(
                    "http_requests_total",
                    method=method.upper(),
                    host=_host(url),
                    status=str(response.status_code),
                )
                if use_cache:
                    _store_cached_response(cache_key, response)
                return response
            time.sleep(_retry_delay(response, attempt, policy))
        raise RuntimeError("unreachable HTTP retry state")
    finally:
        if owns_client:
            client.close()


async def async_request(
    method: str,
    url: str,
    *,
    client: httpx.AsyncClient | None = None,
    policy: HttpPolicy | None = None,
    **kwargs,
) -> httpx.Response:
    policy = policy or HttpPolicy()
    owns_client = client is None
    cache_key = _cache_key(method, url, kwargs)
    use_cache = _cache_allowed(method, kwargs, owns_client=owns_client)
    if use_cache:
        cached = _cached_response(method, url, cache_key)
        if cached is not None:
            metrics.inc("http_cache_hits_total", method=method.upper(), host=_host(url))
            return cached
    if client is None:
        client = httpx.AsyncClient(**_client_kwargs(policy))
    try:
        for attempt in range(policy.max_retries + 1):
            await _async_wait_rate_limit(url, policy)
            apply_jitter()
            response: httpx.Response | None = None
            try:
                start = time.perf_counter()
                response = await client.request(method.upper(), url, **kwargs)
                metrics.observe("http_request_seconds", time.perf_counter() - start)
            except httpx.HTTPError:
                metrics.inc("http_errors_total", method=method.upper(), host=_host(url))
                if attempt >= policy.max_retries:
                    raise
                await asyncio.sleep(_retry_delay(None, attempt, policy))
                continue
            if (
                response.status_code not in policy.retry_statuses
                or attempt >= policy.max_retries
            ):
                metrics.inc(
                    "http_requests_total",
                    method=method.upper(),
                    host=_host(url),
                    status=str(response.status_code),
                )
                if use_cache:
                    _store_cached_response(cache_key, response)
                return response
            await asyncio.sleep(_retry_delay(response, attempt, policy))
        raise RuntimeError("unreachable HTTP retry state")
    finally:
        if owns_client:
            await client.aclose()
