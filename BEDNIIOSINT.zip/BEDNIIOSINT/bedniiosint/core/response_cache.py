from __future__ import annotations

import base64
import hashlib
import json
import logging
import sqlite3
import threading
import time
from typing import Any

from ..config import settings

logger = logging.getLogger(__name__)


def _encode_cache_value(value: Any) -> Any:
    if isinstance(value, bytes):
        return {"__bedniiosint_bytes__": base64.b64encode(value).decode("ascii")}
    if isinstance(value, dict):
        return {str(key): _encode_cache_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_encode_cache_value(item) for item in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    raise TypeError(f"unsupported cache value type: {type(value).__name__}")


def _decode_cache_value(value: Any) -> Any:
    if isinstance(value, dict):
        encoded = value.get("__bedniiosint_bytes__")
        if isinstance(encoded, str) and set(value) == {"__bedniiosint_bytes__"}:
            return base64.b64decode(encoded.encode("ascii"))
        return {key: _decode_cache_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_decode_cache_value(item) for item in value]
    return value


class _MemoryBackend:
    def __init__(self) -> None:
        self._store: dict[str, tuple[float, Any]] = {}
        self._lock = threading.Lock()

    def get(self, key: str) -> Any | None:
        with self._lock:
            row = self._store.get(key)
            if row is None:
                return None
            expires, value = row
            if expires <= time.time():
                self._store.pop(key, None)
                return None
            return value

    def set(self, key: str, value: Any, expires: float) -> None:
        with self._lock:
            self._store[key] = (expires, value)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()


class _SqliteBackend:
    def __init__(self) -> None:
        self._lock = threading.Lock()

    def _db_path(self):
        settings.db_dir.mkdir(parents=True, exist_ok=True)
        return settings.db_dir / "_http_cache.sqlite"

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path(), timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute(
            "CREATE TABLE IF NOT EXISTS http_cache "
            "(key TEXT PRIMARY KEY, expires REAL NOT NULL, value TEXT NOT NULL)"
        )
        return conn

    def get(self, key: str) -> Any | None:
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT expires, value FROM http_cache WHERE key = ?",
                (key,),
            ).fetchone()
            if row is None:
                return None
            expires, payload = row
            if float(expires) <= time.time():
                conn.execute("DELETE FROM http_cache WHERE key = ?", (key,))
                return None
            try:
                return _decode_cache_value(json.loads(str(payload)))
            except (json.JSONDecodeError, TypeError, ValueError):
                conn.execute("DELETE FROM http_cache WHERE key = ?", (key,))
                return None

    def set(self, key: str, value: Any, expires: float) -> None:
        payload = json.dumps(_encode_cache_value(value), separators=(",", ":"))
        with self._lock, self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO http_cache(key, expires, value) VALUES (?, ?, ?)",
                (key, expires, payload),
            )

    def clear(self) -> None:
        with self._lock:
            path = self._db_path()
            if not path.exists():
                return
            with self._connect() as conn:
                conn.execute("DELETE FROM http_cache")


class _RedisBackend:
    def __init__(self) -> None:
        import redis  # type: ignore

        self._client = redis.Redis.from_url(settings.redis_url)

    def get(self, key: str) -> Any | None:
        payload = self._client.get(key)
        if payload is None:
            return None
        return _decode_cache_value(json.loads(payload.decode("utf-8")))

    def set(self, key: str, value: Any, expires: float) -> None:
        ttl = max(1, int(expires - time.time()))
        payload = json.dumps(_encode_cache_value(value), separators=(",", ":"))
        self._client.setex(key, ttl, payload)

    def clear(self) -> None:
        for key in self._client.scan_iter("bedniiosint:http:*"):
            self._client.delete(key)


class ResponseCache:
    def __init__(self) -> None:
        self._memory = _MemoryBackend()
        self._sqlite = _SqliteBackend()
        self._redis: _RedisBackend | None = None

    @staticmethod
    def key(method: str, url: str, params: object = None, body: object = None) -> str:
        raw = f"{method.upper()} {url} {params!r} {body!r}"
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        return f"bedniiosint:http:{digest}"

    def _backend(self):
        selected = str(settings.cache_backend or "sqlite").strip().lower()
        if selected == "memory":
            return self._memory
        if selected == "redis":
            try:
                if self._redis is None:
                    self._redis = _RedisBackend()
                return self._redis
            except Exception:
                return self._sqlite
        return self._sqlite

    def get(self, key: str) -> Any | None:
        if not settings.cache_enabled:
            return None
        return self._backend().get(key)

    def set(self, key: str, value: object, ttl: float | None = None) -> None:
        if not settings.cache_enabled:
            return
        ttl_value = settings.cache_ttl if ttl is None else ttl
        if ttl_value <= 0:
            return
        try:
            self._backend().set(key, value, time.time() + ttl_value)
        except (TypeError, ValueError):
            return

    def clear(self) -> None:
        self._memory.clear()
        self._sqlite.clear()
        if self._redis is not None:
            try:
                self._redis.clear()
            except Exception as exc:
                logger.debug("response_cache: redis clear failed: %s", exc)


response_cache = ResponseCache()
