from __future__ import annotations

import json
import logging
import os
from pathlib import Path


logger = logging.getLogger("bedniiosint.core.confidence_weights")

DEFAULT_WEIGHTS: dict[str, float] = {
    "status_exists": 0.30,
    "username_in_final_url": 0.15,
    "notfound_marker_absent": 0.10,
    "found_marker_present": 0.20,
    "control_passed": 0.25,
}


def _candidate_paths() -> list[Path]:
    paths: list[Path] = []
    env = os.environ.get("CONFIDENCE_WEIGHTS_PATH")
    if env:
        paths.append(Path(env))
    repo_root = Path(__file__).resolve().parents[2]
    paths.append(repo_root / "eval" / "calibration.json")
    paths.append(repo_root / "data" / "calibration.json")
    return paths


def _coerce_weights(data: dict) -> dict[str, float] | None:
    raw = data.get("weights")
    if raw is None and all(key in data for key in DEFAULT_WEIGHTS):
        raw = data
    if not isinstance(raw, dict):
        return None
    weights: dict[str, float] = {}
    for key, value in raw.items():
        if key in DEFAULT_WEIGHTS:
            weights[key] = max(0.0, float(value))
    return weights or None


def load_weights() -> dict[str, float]:
    for path in _candidate_paths():
        try:
            if path.is_file():
                data = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(data, dict):
                    continue
                weights = _coerce_weights(data)
                if not weights:
                    continue
                merged = {**DEFAULT_WEIGHTS, **weights}
                logger.info("loaded calibrated confidence weights from %s", path)
                return merged
        except Exception:
            logger.exception("failed to load weights from %s", path)
    return dict(DEFAULT_WEIGHTS)


WEIGHTS = load_weights()
