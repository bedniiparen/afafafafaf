from __future__ import annotations

from ..config import settings
from ..modules.email.analyzer import analyze_email
from ..storage.models import Case, Entity, Finding, Relation
from ..storage.sqlite import Storage
from .artifacts import capture_raw_result
from .confidence import markers_to_text
from .source_record import record_source


class EmailCase:
    def __init__(self, case_name: str, email: str, hibp_key: str | None = None):
        self.case_name = case_name
        self.email = email
        self.hibp_key = hibp_key
        self.storage = Storage(settings.db_path(case_name))

    def run(self) -> dict:
        result = analyze_email(self.email, self.hibp_key)
        with self.storage.session() as session:
            case = Case(name=self.case_name, target=self.email, module="email")
            session.add(case)
            session.commit()
            session.refresh(case)
            if case.id is None:
                raise RuntimeError("case was not persisted")

            session.add(Entity(case_id=case.id, type="email", value=self.email))
            if result.domain:
                session.add(Entity(case_id=case.id, type="domain", value=result.domain))
                session.add(
                    Relation(
                        case_id=case.id,
                        src_type="email",
                        src_value=self.email,
                        rel="uses_domain",
                        dst_type="domain",
                        dst_value=result.domain,
                    )
                )
            rejected = bool(result.reject_reason)
            source = record_source(
                session,
                case_id=case.id,
                name="email-analyzer",
                category="email",
                rejected=rejected,
                notes=result.reject_reason or "scored email OSINT signals",
            )
            finding = Finding(
                case_id=case.id,
                source_name="email-analyzer",
                source_reliability=source.reliability,
                entity_value=self.email,
                profile_url=f"mailto:{self.email}",
                status="exists" if result.valid_format else "not_exists",
                page_title=(
                    f"MX={len(result.mx)} gravatar={result.gravatar_exists} "
                    f"breached={result.breach.get('breached')}"
                ),
                matched_markers=markers_to_text(result.matched_markers),
                confidence=result.confidence,
                rejected=rejected,
                reject_reason=result.reject_reason,
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("finding was not persisted")
            capture_raw_result(
                self.storage,
                case_name=self.case_name,
                case_id=case.id,
                finding_id=finding.id,
                source_module="email",
                payload=result.__dict__,
                url=f"mailto:{self.email}",
                confidence=result.confidence,
                name_hint="email-analyzer",
            )
        return {
            "meta": {"case": self.case_name, "email": self.email, "module": "email"},
            "result": result.__dict__,
        }
