from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
from typing import Any

import httpx

from ..config import settings
from .redaction import redact_value


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def monitor_notifications_path(path: Path | None = None) -> Path:
    if path is not None:
        return path
    settings.db_dir.mkdir(parents=True, exist_ok=True)
    return settings.db_dir / "monitor_notifications.jsonl"


def _safe_alert(alert: dict[str, Any]) -> dict[str, Any]:
    safe = redact_value(alert)
    return safe if isinstance(safe, dict) else {}


def notify_monitor_alert(
    alert: dict[str, Any],
    *,
    notifications_path: Path | None = None,
    webhook_url: str | None = None,
) -> dict[str, Any]:
    safe_alert = _safe_alert(alert)
    result: dict[str, Any] = {
        "created_at": _now_iso(),
        "channels": [],
        "delivered": 0,
        "errors": [],
    }

    path = monitor_notifications_path(notifications_path)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("", encoding="utf-8") if not path.exists() else None
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(safe_alert, ensure_ascii=False, sort_keys=True, default=str) + "\n")
        result["channels"].append({"type": "jsonl", "path": str(path), "status": "written"})
        result["delivered"] += 1
    except OSError as exc:
        result["errors"].append({"type": "jsonl", "error": str(exc)})

    url = (webhook_url if webhook_url is not None else os.getenv("BEDNIIOSINT_MONITOR_WEBHOOK_URL", "")).strip()
    if not url:
        result["channels"].append({"type": "webhook", "status": "not_configured"})
        return result

    try:
        response = httpx.post(url, json=safe_alert, timeout=5.0)
        status = "delivered" if 200 <= int(response.status_code) < 300 else "failed"
        result["channels"].append(
            {
                "type": "webhook",
                "status": status,
                "status_code": int(response.status_code),
            }
        )
        if status == "delivered":
            result["delivered"] += 1
        else:
            result["errors"].append({"type": "webhook", "status_code": int(response.status_code)})
    except Exception as exc:
        result["channels"].append({"type": "webhook", "status": "failed"})
        result["errors"].append({"type": "webhook", "error": str(exc)})
    return result
