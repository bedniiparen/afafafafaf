from __future__ import annotations

from ..config import settings
from ..modules.domain.passive_tools import run_passive_tools
from ..storage.models import Case, Entity, Finding, Relation
from ..storage.sqlite import Storage
from .artifacts import capture_raw_result
from .confidence import markers_to_text
from .source_record import record_source


class DomainPassiveToolsCase:
    def __init__(
        self,
        case_name: str,
        domain: str,
        *,
        tools: list[str] | None = None,
        timeout: float = 60.0,
    ):
        self.case_name = case_name
        self.domain = domain
        self.tools = tools
        self.timeout = timeout
        self.storage = Storage(settings.db_path(case_name))

    def run(self) -> dict:
        result = run_passive_tools(self.domain, tools=self.tools, timeout=self.timeout)
        subdomains = result["subdomains"]
        markers = ["passive_external_tools"]
        if subdomains:
            markers.append("subdomains")
        with self.storage.session() as session:
            case = Case(
                name=self.case_name,
                target=result["domain"],
                module="domain_passive_tools",
            )
            session.add(case)
            session.commit()
            session.refresh(case)
            if case.id is None:
                raise RuntimeError("case was not persisted")
            session.add(Entity(case_id=case.id, type="domain", value=result["domain"]))
            for subdomain in subdomains:
                session.add(Entity(case_id=case.id, type="domain", value=subdomain["subdomain"]))
                session.add(
                    Relation(
                        case_id=case.id,
                        src_type="domain",
                        src_value=result["domain"],
                        rel="subdomain_of",
                        dst_type="domain",
                        dst_value=subdomain["subdomain"],
                    )
                )
            source = record_source(
                session,
                case_id=case.id,
                name="domain-passive-tools",
                url_main=f"https://{result['domain']}",
                category="domain",
                rejected=False,
                notes="passive external tools only; no active scan flags",
            )
            finding = Finding(
                case_id=case.id,
                source_name="domain-passive-tools",
                source_id="module:domain_passive_tools",
                source_reliability=source.reliability,
                entity_type="domain",
                entity_value=result["domain"],
                finding_type="passive_subdomain_enum",
                profile_url=f"https://{result['domain']}",
                status="exists" if subdomains else "unknown",
                page_title=f"passive_subdomains={len(subdomains)}",
                matched_markers=markers_to_text(markers),
                confidence=0.72 if subdomains else 0.25,
                confidence_reason="passive external tool output; corroborate before use",
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("finding was not persisted")
            capture_raw_result(
                self.storage,
                case_name=self.case_name,
                case_id=case.id,
                finding_id=finding.id,
                source_module="domain_passive_tools",
                payload=result,
                url=f"https://{result['domain']}",
                confidence=finding.confidence,
                name_hint="domain-passive-tools",
            )
        return {
            "meta": {
                "case": self.case_name,
                "domain": result["domain"],
                "module": "domain_passive_tools",
            },
            "result": result,
        }
