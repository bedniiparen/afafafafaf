from __future__ import annotations

import hashlib
import re
from typing import Any
from urllib.parse import urlsplit, urlunsplit


ALIAS_RELATIONS = {"alias_of", "same_as", "aka", "merged_into"}
CASEFOLD_TYPES = {
    "company",
    "domain",
    "email",
    "person",
    "profile",
    "username",
}


def normalize_entity_value(entity_type: str, value: str) -> str:
    entity_type = entity_type.strip().lower()
    text = " ".join(str(value or "").strip().split())
    if entity_type in {"domain", "email", "username"}:
        return text.lower().strip(".")
    if entity_type == "url":
        return _normalize_url(text)
    if entity_type == "phone":
        return _normalize_phone(text)
    if entity_type in CASEFOLD_TYPES:
        return text.casefold()
    return text


def canonical_entity_id(entity_type: str, value: str) -> str:
    normalized_type = entity_type.strip().lower() or "entity"
    normalized_value = normalize_entity_value(normalized_type, value)
    digest = hashlib.sha256(
        f"{normalized_type}:{normalized_value}".encode("utf-8")
    ).hexdigest()[:16]
    return f"{normalized_type}:{digest}"


def resolve_entities(
    entities: list[dict[str, Any]],
    relations: list[dict[str, Any]] | None = None,
    findings: list[dict[str, Any]] | None = None,
    evidence: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    by_id: dict[str, dict[str, Any]] = {}
    alias_links: list[dict[str, Any]] = []
    parent: dict[str, str] = {}

    for entity in entities:
        entity_type = str(entity.get("type") or "").strip().lower()
        value = str(entity.get("value") or "").strip()
        if not entity_type or not value:
            continue
        normalized = normalize_entity_value(entity_type, value)
        canonical_id = canonical_entity_id(entity_type, value)
        item = by_id.setdefault(
            canonical_id,
            {
                "id": canonical_id,
                "type": entity_type,
                "value": normalized,
                "display_values": [],
                "aliases": [],
                "confidence": 0.9,
                "reasons": [],
                "source_ids": [],
                "independent_sources": 0,
                "finding_ids": [],
                "evidence_count": 0,
                "statuses": [],
                "human_review_required": False,
                "review_reasons": [],
            },
        )
        parent.setdefault(canonical_id, canonical_id)
        if value not in item["display_values"]:
            item["display_values"].append(value)
        if normalized != value and normalized not in item["aliases"]:
            item["aliases"].append(normalized)
        reason = "normalized_same_type" if normalized != value else "exact_same_type"
        if reason not in item["reasons"]:
            item["reasons"].append(reason)

    evidence_by_finding = _evidence_by_finding(evidence or [])
    for finding in findings or []:
        entity_type = str(finding.get("entity_type") or "").strip().lower()
        value = str(finding.get("entity_value") or "").strip()
        if not entity_type or not value:
            continue
        canonical_id = canonical_entity_id(entity_type, value)
        normalized = normalize_entity_value(entity_type, value)
        item = by_id.setdefault(
            canonical_id,
            {
                "id": canonical_id,
                "type": entity_type,
                "value": normalized,
                "display_values": [],
                "aliases": [],
                "confidence": 0.0,
                "reasons": ["finding_only_entity"],
                "source_ids": [],
                "independent_sources": 0,
                "finding_ids": [],
                "evidence_count": 0,
                "statuses": [],
                "human_review_required": False,
                "review_reasons": [],
            },
        )
        parent.setdefault(canonical_id, canonical_id)
        _apply_finding_signal(item, finding, evidence_by_finding)

    for relation in relations or []:
        rel = str(relation.get("rel") or "").strip().lower()
        if rel not in ALIAS_RELATIONS:
            continue
        src_type = str(relation.get("src_type") or "").strip().lower()
        src_value = str(relation.get("src_value") or "").strip()
        dst_type = str(relation.get("dst_type") or "").strip().lower()
        dst_value = str(relation.get("dst_value") or "").strip()
        if not all([src_type, src_value, dst_type, dst_value]):
            continue
        src_id = canonical_entity_id(src_type, src_value)
        dst_id = canonical_entity_id(dst_type, dst_value)
        parent.setdefault(src_id, src_id)
        parent.setdefault(dst_id, dst_id)
        _union(parent, src_id, dst_id)
        alias_links.append(
            {
                "from": {"id": src_id, "type": src_type, "value": src_value},
                "into": {"id": dst_id, "type": dst_type, "value": dst_value},
                "rel": rel,
                "reason": f"explicit_relation:{rel}",
            }
        )

    for item in by_id.values():
        item["source_ids"] = sorted(set(item["source_ids"]))
        item["independent_sources"] = len(item["source_ids"])
        item["finding_ids"] = sorted(set(item["finding_ids"]))
        item["statuses"] = sorted(set(item["statuses"]))
        if item["independent_sources"] < 2:
            item["human_review_required"] = True
            if "needs independent corroboration" not in item["review_reasons"]:
                item["review_reasons"].append("needs independent corroboration")
        if item["evidence_count"] == 0 and item["finding_ids"]:
            item["human_review_required"] = True
            if "no captured evidence linked to finding" not in item["review_reasons"]:
                item["review_reasons"].append("no captured evidence linked to finding")
        item["review_reasons"] = sorted(set(item["review_reasons"]))

    canonical = sorted(by_id.values(), key=lambda row: (row["type"], row["value"]))
    clusters = _entity_clusters(canonical, parent, alias_links)
    return {
        "canonical_entities": canonical,
        "entity_clusters": clusters,
        "alias_links": alias_links,
        "counts": {
            "raw_entities": len(entities),
            "canonical_entities": len(canonical),
            "entity_clusters": len(clusters),
            "alias_links": len(alias_links),
            "supported_by_findings": sum(1 for row in canonical if row["finding_ids"]),
            "needs_review": sum(1 for row in canonical if row["human_review_required"]),
        },
    }


def _source_key(row: dict[str, Any]) -> str:
    return str(row.get("source_id") or row.get("source_name") or row.get("name") or "").strip()


def _evidence_by_finding(rows: list[dict[str, Any]]) -> dict[Any, list[dict[str, Any]]]:
    grouped: dict[Any, list[dict[str, Any]]] = {}
    for row in rows:
        finding_id = row.get("finding_id")
        if finding_id in {None, ""}:
            continue
        grouped.setdefault(finding_id, []).append(row)
    return grouped


def _unique_evidence_count(rows: list[dict[str, Any]]) -> int:
    seen = set()
    for row in rows:
        key = (
            row.get("id"),
            row.get("sha256"),
            row.get("artifact_path"),
            row.get("url"),
        )
        seen.add(key)
    return len(seen)


def _apply_finding_signal(
    item: dict[str, Any],
    finding: dict[str, Any],
    evidence_by_finding: dict[Any, list[dict[str, Any]]],
) -> None:
    finding_id = finding.get("id")
    if finding_id not in {None, ""}:
        item["finding_ids"].append(finding_id)
    status = str(finding.get("status") or "")
    if status:
        item["statuses"].append(status)
    confidence = float(finding.get("confidence") or 0.0)
    item["confidence"] = round(max(float(item.get("confidence") or 0.0), confidence), 3)
    if finding.get("rejected"):
        item["human_review_required"] = True
        item["review_reasons"].append("rejected finding present")
    if status == "exists" and not finding.get("rejected"):
        source = _source_key(finding)
        if source:
            item["source_ids"].append(source)
    elif status:
        item["human_review_required"] = True
        item["review_reasons"].append(f"non-confirmed status:{status}")
    item["evidence_count"] += _unique_evidence_count(evidence_by_finding.get(finding_id, []))
    if "finding_signal" not in item["reasons"]:
        item["reasons"].append("finding_signal")


def _find(parent: dict[str, str], item: str) -> str:
    parent.setdefault(item, item)
    while parent[item] != item:
        parent[item] = parent[parent[item]]
        item = parent[item]
    return item


def _union(parent: dict[str, str], left: str, right: str) -> None:
    left_root = _find(parent, left)
    right_root = _find(parent, right)
    if left_root == right_root:
        return
    parent[max(left_root, right_root)] = min(left_root, right_root)


def _entity_clusters(
    canonical: list[dict[str, Any]],
    parent: dict[str, str],
    alias_links: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    by_id = {row["id"]: row for row in canonical}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in canonical:
        grouped.setdefault(_find(parent, row["id"]), []).append(row)
    link_count_by_root: dict[str, int] = {}
    for link in alias_links:
        root = _find(parent, str(link.get("from", {}).get("id") or ""))
        link_count_by_root[root] = link_count_by_root.get(root, 0) + 1
    clusters = []
    for root, members in grouped.items():
        source_ids = sorted(
            {
                source
                for member in members
                for source in member.get("source_ids", [])
            }
        )
        finding_ids = sorted(
            {
                finding_id
                for member in members
                for finding_id in member.get("finding_ids", [])
            }
        )
        types = sorted({str(member.get("type") or "") for member in members})
        display_values = sorted(
            {
                value
                for member in members
                for value in member.get("display_values", [])
            }
        )
        evidence_count = sum(int(member.get("evidence_count") or 0) for member in members)
        max_confidence = max((float(member.get("confidence") or 0.0) for member in members), default=0.0)
        clusters.append(
            {
                "id": root,
                "primary_entity_id": root if root in by_id else members[0]["id"],
                "types": types,
                "display_values": display_values,
                "member_ids": sorted(member["id"] for member in members),
                "members": members,
                "source_ids": source_ids,
                "independent_sources": len(source_ids),
                "finding_ids": finding_ids,
                "evidence_count": evidence_count,
                "max_confidence": round(max_confidence, 3),
                "alias_link_count": link_count_by_root.get(root, 0),
                "human_review_required": any(bool(member.get("human_review_required")) for member in members),
            }
        )
    return sorted(
        clusters,
        key=lambda row: (
            -int(row["independent_sources"]),
            -float(row["max_confidence"]),
            str(row["id"]),
        ),
    )


def _normalize_url(value: str) -> str:
    try:
        parts = urlsplit(value)
    except ValueError:
        return value
    scheme = parts.scheme.lower() or "https"
    netloc = parts.netloc.lower()
    path = parts.path.rstrip("/") or "/"
    return urlunsplit((scheme, netloc, path, "", ""))


def _normalize_phone(value: str) -> str:
    if value.startswith("+"):
        prefix = "+"
    else:
        prefix = ""
    digits = "".join(re.findall(r"\d+", value))
    return f"{prefix}{digits}" if digits else value
