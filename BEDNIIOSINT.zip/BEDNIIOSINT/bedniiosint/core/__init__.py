"""Core orchestration and scoring."""
