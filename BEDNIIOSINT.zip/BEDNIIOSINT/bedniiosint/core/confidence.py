from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .confidence_weights import WEIGHTS
from .source_reliability import reliability_from_history

W_STATUS_MATCH = WEIGHTS["status_exists"]
W_USERNAME_IN_URL = WEIGHTS["username_in_final_url"]
W_NO_NOTFOUND_MARKER = WEIGHTS["notfound_marker_absent"]
W_FOUND_MARKER = WEIGHTS["found_marker_present"]
W_CONTROL_PASSED = WEIGHTS["control_passed"]


@dataclass
class ConfidenceInput:
    status_is_exists: bool
    username_in_final_url: bool
    notfound_marker_absent: bool
    found_marker_present: bool
    control_passed: bool
    source_reliability: float


@dataclass(frozen=True)
class ScoreSignal:
    name: str
    weight: float
    matched: bool
    reason: str = ""


@dataclass(frozen=True)
class ScoringResult:
    confidence: float
    matched_markers: list[str]
    reject_reason: str = ""


@dataclass(frozen=True)
class UniversalConfidenceContext:
    target_type: str
    independent_sources: int = 1
    source_reliability: float = 1.0
    source_success_count: int = 0
    source_error_count: int = 0
    weak_data: bool = False
    stale: bool = False
    reputation_only: bool = False


def compute_confidence(c: ConfidenceInput) -> float:
    return score_username(c).confidence


def score_username(c: ConfidenceInput) -> ScoringResult:
    return score_signals(
        [
            ScoreSignal("status_exists", W_STATUS_MATCH, c.status_is_exists),
            ScoreSignal(
                "username_in_final_url",
                W_USERNAME_IN_URL,
                c.username_in_final_url,
                "username absent from final URL",
            ),
            ScoreSignal(
                "notfound_marker_absent",
                W_NO_NOTFOUND_MARKER,
                c.notfound_marker_absent,
                "not-found marker present",
            ),
            ScoreSignal(
                "found_marker_present",
                W_FOUND_MARKER,
                c.found_marker_present,
                "source has no explicit found marker",
            ),
            ScoreSignal(
                "control_passed",
                W_CONTROL_PASSED,
                c.control_passed,
                "control username also matched",
            ),
        ],
        source_reliability=c.source_reliability,
    )


def score_signals(
    signals: Iterable[ScoreSignal],
    *,
    source_reliability: float = 1.0,
    reject_reason: str = "",
) -> ScoringResult:
    markers: list[str] = []
    raw = 0.0
    for signal in signals:
        marker = f"score:{signal.name}:{signal.weight:.2f}"
        if signal.matched:
            raw += signal.weight
            markers.append(marker)
        elif signal.reason:
            markers.append(f"score:{signal.name}:miss:{signal.reason}")

    reliability = max(0.0, min(1.0, source_reliability))
    confidence = round(min(1.0, max(0.0, raw) * reliability), 3)
    if reject_reason:
        return ScoringResult(
            confidence=confidence,
            matched_markers=markers,
            reject_reason=reject_reason,
        )
    if confidence <= 0 and markers:
        return ScoringResult(
            confidence=confidence,
            matched_markers=markers,
            reject_reason="no positive scoring signals",
        )
    return ScoringResult(confidence=confidence, matched_markers=markers)


def score_universal(
    signals: Iterable[ScoreSignal],
    *,
    context: UniversalConfidenceContext,
    reject_reason: str = "",
) -> ScoringResult:
    reliability, reliability_note = reliability_from_history(
        context.source_reliability,
        success_count=context.source_success_count,
        error_count=context.source_error_count,
    )
    scoring = score_signals(
        signals,
        source_reliability=reliability,
        reject_reason=reject_reason,
    )
    markers = list(scoring.matched_markers)
    confidence = scoring.confidence

    if reliability != context.source_reliability or context.source_error_count:
        markers.append(f"universal:source_history:{reliability:.2f}:{reliability_note}")

    if confidence > 0 and context.independent_sources > 1:
        boost = min(0.20, 0.05 * (context.independent_sources - 1))
        confidence = min(1.0, confidence + boost)
        markers.append(
            f"universal:independent_sources:+{boost:.2f}:{context.independent_sources}"
        )

    penalties = [
        ("weak_data", 0.15, context.weak_data),
        ("stale", 0.20, context.stale),
        ("reputation_only", 0.10, context.reputation_only),
    ]
    for name, penalty, active in penalties:
        if active and confidence > 0:
            confidence = max(0.0, confidence - penalty)
            markers.append(f"universal:{name}:-{penalty:.2f}")

    return ScoringResult(
        confidence=round(confidence, 3),
        matched_markers=markers,
        reject_reason=scoring.reject_reason,
    )


def markers_to_text(markers: Iterable[str]) -> str:
    return ",".join(marker for marker in markers if marker)
