from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config import settings
from .http import HttpPolicy
from .redaction import redact_urls_in_text, redact_value


class SourceBudgetExceeded(RuntimeError):
    def __init__(self, source_id: str):
        super().__init__(f"source budget exhausted: {source_id}")
        self.source_id = source_id


RISK_ORDER = {"low": 0, "medium": 1, "high": 2, "reject": 3}


@dataclass
class SourceRunContext:
    scope: str = "public_osint"
    timeout: float = settings.timeout
    max_retries: int = settings.http_max_retries
    backoff: float = settings.http_backoff
    rate_limit_delay: float = settings.http_rate_limit_delay
    cache_enabled: bool = False
    cache_ttl_seconds: int = 0
    cache_ttl_by_source: dict[str, int] = field(default_factory=dict)
    cache_dir: Path = field(default_factory=lambda: settings.db_dir / "_source_cache")
    request_budget: dict[str, int] = field(default_factory=dict)
    legal_flags: dict[str, Any] = field(default_factory=dict)
    user_agent: str = settings.user_agent

    def http_policy(self) -> HttpPolicy:
        return HttpPolicy(
            timeout=self.timeout,
            max_retries=self.max_retries,
            backoff=self.backoff,
            rate_limit_delay=self.rate_limit_delay,
            user_agent=self.user_agent,
        )

    def budget_remaining(self, source_id: str) -> int | None:
        if source_id in self.request_budget:
            return self.request_budget[source_id]
        if "*" in self.request_budget:
            return self.request_budget["*"]
        return None

    def consume_budget(self, source_id: str) -> int | None:
        remaining = self.budget_remaining(source_id)
        if remaining is None:
            return None
        if remaining <= 0:
            raise SourceBudgetExceeded(source_id)
        self.request_budget[source_id] = remaining - 1
        return self.request_budget[source_id]

    def source_allowed(
        self,
        source_id: str,
        *,
        terms_risk: str = "low",
    ) -> tuple[bool, str]:
        blocked = {
            str(item).strip().lower()
            for item in self.legal_flags.get("blocked_sources", [])
        }
        normalized = source_id.strip().lower()
        short = normalized.replace("api:", "", 1).replace("module:", "", 1)
        if normalized in blocked or short in blocked:
            return False, f"source blocked by scope: {source_id}"
        risk = terms_risk.lower()
        if risk == "reject":
            return False, f"source rejected by policy: {source_id}"
        if self.legal_flags.get("public_only") and risk != "low":
            return False, f"source terms risk exceeds public_only scope: {risk}"
        max_risk = str(self.legal_flags.get("max_terms_risk") or "").lower()
        if max_risk and RISK_ORDER.get(risk, 0) > RISK_ORDER.get(max_risk, 0):
            return False, f"source terms risk {risk} exceeds max_terms_risk={max_risk}"
        return True, ""

    def cache_ttl(self, source_id: str, headers: dict[str, Any] | None = None) -> int:
        ttl = int(
            self.cache_ttl_by_source.get(
                source_id,
                self.cache_ttl_by_source.get(_short_source_id(source_id), self.cache_ttl_seconds),
            )
            or 0
        )
        return _ttl_with_cache_control(ttl, headers or {})

    def cache_available(self, source_id: str | None = None) -> bool:
        if not self.cache_enabled:
            return False
        if source_id is None:
            return self.cache_ttl_seconds > 0 or any(
                int(value or 0) > 0 for value in self.cache_ttl_by_source.values()
            )
        return self.cache_ttl(source_id) > 0

    def cache_key(
        self,
        source_id: str,
        method: str,
        url: str,
        request_kwargs: dict[str, Any] | None = None,
    ) -> str:
        material = {
            "source_id": source_id,
            "method": method.upper(),
            "url": url,
            "request": _cache_safe_request(request_kwargs or {}),
        }
        raw = json.dumps(material, ensure_ascii=False, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def cache_path(
        self,
        source_id: str,
        method: str,
        url: str,
        request_kwargs: dict[str, Any] | None = None,
    ) -> Path:
        source_slug = source_id.replace(":", "_").replace("/", "_")
        filename = f"{self.cache_key(source_id, method, url, request_kwargs)}.json"
        return self.cache_dir / source_slug / filename

    def read_cache(
        self,
        source_id: str,
        method: str,
        url: str,
        request_kwargs: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        if not self.cache_available(source_id):
            return None
        path = self.cache_path(source_id, method, url, request_kwargs)
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        expires = float(payload.get("expires_epoch") or 0.0)
        if expires and time.time() > expires:
            return None
        created = float(payload.get("created_epoch") or 0.0)
        ttl = int(payload.get("cache_ttl_seconds") or self.cache_ttl(source_id))
        if not ttl or time.time() - created > ttl:
            return None
        return payload

    def write_cache(
        self,
        source_id: str,
        method: str,
        url: str,
        request_kwargs: dict[str, Any] | None,
        payload: dict[str, Any],
    ) -> None:
        headers = dict(payload.get("headers") or {})
        ttl = self.cache_ttl(source_id, headers)
        if not self.cache_enabled or ttl <= 0:
            return
        path = self.cache_path(source_id, method, url, request_kwargs)
        path.parent.mkdir(parents=True, exist_ok=True)
        now = time.time()
        safe_payload = _cache_safe_payload(payload)
        record = {
            **safe_payload,
            "source_id": source_id,
            "method": method.upper(),
            "url": redact_value(url, key="url"),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "created_epoch": now,
            "expires_epoch": now + ttl,
            "cache_ttl_seconds": ttl,
            "cache_control": _header_value(headers, "cache-control"),
        }
        path.write_text(
            json.dumps(record, ensure_ascii=False, sort_keys=True, default=str),
            encoding="utf-8",
        )


def _cache_safe_request(kwargs: dict[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in redact_value(kwargs).items()
        if key not in {"client"}
    }


def _cache_safe_payload(payload: dict[str, Any]) -> dict[str, Any]:
    safe = dict(redact_value(payload))
    if isinstance(safe.get("text"), str):
        safe["text"] = redact_urls_in_text(str(safe["text"]))
    return safe


def _header_value(headers: dict[str, Any], name: str) -> str:
    lowered = name.lower()
    for key, value in headers.items():
        if str(key).lower() == lowered:
            return str(value)
    return ""


def _short_source_id(source_id: str) -> str:
    return source_id.replace("api:", "", 1).replace("module:", "", 1)


def _cache_control_directives(headers: dict[str, Any]) -> dict[str, str | None]:
    raw = _header_value(headers, "cache-control")
    directives: dict[str, str | None] = {}
    for part in raw.split(","):
        item = part.strip()
        if not item:
            continue
        if "=" in item:
            key, value = item.split("=", 1)
            directives[key.strip().lower()] = value.strip().strip('"')
        else:
            directives[item.lower()] = None
    return directives


def _ttl_with_cache_control(configured_ttl: int, headers: dict[str, Any]) -> int:
    directives = _cache_control_directives(headers)
    if any(flag in directives for flag in ("no-store", "no-cache", "private")):
        return 0
    ttl = max(0, int(configured_ttl or 0))
    max_age = directives.get("s-maxage") or directives.get("max-age")
    if max_age is None:
        return ttl
    try:
        provider_ttl = max(0, int(float(max_age)))
    except (TypeError, ValueError):
        return ttl
    if ttl <= 0:
        return provider_ttl
    return min(ttl, provider_ttl)


def parse_cache_ttl_by_source(value: str | list[str] | tuple[str, ...] | None) -> dict[str, int]:
    if not value:
        return {}
    parts: list[str] = []
    if isinstance(value, str):
        parts = [item.strip() for item in value.split(",") if item.strip()]
    else:
        for item in value:
            parts.extend(part.strip() for part in str(item).split(",") if part.strip())
    parsed: dict[str, int] = {}
    for item in parts:
        if "=" not in item:
            raise ValueError("cache TTL source entries must use source=seconds")
        source_id, raw_ttl = item.split("=", 1)
        source_id = source_id.strip()
        if not source_id:
            raise ValueError("cache TTL source id must not be empty")
        try:
            ttl = int(raw_ttl.strip())
        except ValueError as exc:
            raise ValueError(f"invalid cache TTL for {source_id}") from exc
        if ttl < 0:
            raise ValueError(f"cache TTL for {source_id} must be >= 0")
        parsed[source_id] = ttl
    return parsed
