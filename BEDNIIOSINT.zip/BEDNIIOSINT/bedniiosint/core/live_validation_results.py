from __future__ import annotations

import json
import os
import csv
import hashlib
from io import StringIO
from collections.abc import Mapping
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .field_encryption import decrypt_json_field_if_needed, encrypt_json_field_if_configured
from ..config import settings
from ..storage.models import LiveValidationAuditEvent, LiveValidationResult
from ..storage.sqlite import Storage


SENSITIVE_KEY_PARTS = (
    "api_key",
    "apikey",
    "authorization",
    "cookie",
    "credential",
    "password",
    "secret",
    "token",
    "x-api-key",
)


LIVE_VALIDATION_EXPORT_COLUMNS = (
    "recorded_at",
    "run_id",
    "source_id",
    "name",
    "mode",
    "target",
    "status",
    "reason",
    "verification_status",
    "health_status",
    "network_required",
    "allow_opt_in",
    "redacted",
    "checks",
    "errors",
    "live_health",
)


def default_live_validation_storage() -> Storage:
    return Storage(settings.db_path("_live_validation"))


def sanitize_live_verification(
    verification: Mapping[str, Any],
    *,
    env: Mapping[str, str] | None = None,
) -> tuple[dict[str, Any], bool]:
    sanitized, redacted = _sanitize(dict(verification), env=env)
    return dict(sanitized), redacted


def record_live_validation_results(
    verification: Mapping[str, Any],
    *,
    run_id: str | None = None,
    target: str = "",
    allow_opt_in: bool = False,
    network_required: bool | None = None,
    storage: Storage | None = None,
    env: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    """Persist opt-in live verification output after redacting secret values."""
    store = storage or default_live_validation_storage()
    result_run_id = run_id or _default_run_id()
    rows = list(verification.get("results") or [])
    redacted_count = 0
    with store.session() as session:
        for row in rows:
            mode = str(row.get("mode") or verification.get("mode") or "")
            row_target = str(row.get("target") or target or "")
            sanitized_checks, checks_redacted = _sanitize(row.get("checks") or [], env=env)
            sanitized_errors, errors_redacted = _sanitize(row.get("errors") or [], env=env)
            sanitized_live, live_redacted = _sanitize(row.get("live_health") or {}, env=env)
            redacted = checks_redacted or errors_redacted or live_redacted
            redacted_count += 1 if redacted else 0
            session.add(
                LiveValidationResult(
                    run_id=result_run_id,
                    source_id=str(row.get("source_id") or ""),
                    name=str(row.get("name") or ""),
                    mode=mode,
                    target=row_target,
                    status=str(row.get("status") or "unknown"),
                    reason=str(row.get("reason") or ""),
                    verification_status=str(row.get("verification_status") or ""),
                    health_status=str(row.get("health_status") or ""),
                    network_required=(
                        bool(network_required) if network_required is not None else mode == "live"
                    ),
                    allow_opt_in=allow_opt_in,
                    checks_json=encrypt_json_field_if_configured(sanitized_checks),
                    errors_json=encrypt_json_field_if_configured(sanitized_errors),
                    live_health_json=encrypt_json_field_if_configured(sanitized_live),
                    redacted=redacted,
                )
            )
        session.commit()
    return {
        "run_id": result_run_id,
        "recorded": len(rows),
        "redacted_rows": redacted_count,
        "secrets_returned": False,
        "database": str(store.db_path),
    }


def live_validation_history(
    *,
    source_id: str | None = None,
    run_id: str | None = None,
    limit: int = 100,
    storage: Storage | None = None,
) -> dict[str, Any]:
    store = storage or default_live_validation_storage()
    with store.session() as session:
        rows = [row_as_dict(row) for row in session.query(LiveValidationResult).all()]
    if source_id:
        needle = source_id.lower()
        rows = [row for row in rows if str(row.get("source_id") or "").lower() == needle]
    if run_id:
        rows = [row for row in rows if row.get("run_id") == run_id]
    rows = sorted(rows, key=lambda row: str(row.get("recorded_at") or ""), reverse=True)
    limited = rows[: max(limit, 0)]
    statuses: dict[str, int] = {}
    for row in rows:
        status = str(row.get("status") or "unknown")
        statuses[status] = statuses.get(status, 0) + 1
    return {
        "summary": {
            "rows": len(rows),
            "returned": len(limited),
            "sources": len({row.get("source_id") for row in rows if row.get("source_id")}),
            "network_required": sum(1 for row in rows if row.get("network_required")),
            "redacted_rows": sum(1 for row in rows if row.get("redacted")),
            "secrets_returned": False,
            "statuses": dict(sorted(statuses.items())),
        },
        "results": limited,
    }


def export_live_validation_history(
    history: Mapping[str, Any] | None = None,
    *,
    export_format: str = "json",
) -> tuple[str, str]:
    data = dict(history or live_validation_history())
    fmt = export_format.strip().lower()
    if fmt in {"md", "markdown"}:
        return live_validation_markdown(data), "text/markdown; charset=utf-8"
    if fmt == "csv":
        return _live_validation_csv(data), "text/csv; charset=utf-8"
    if fmt == "json":
        return (
            json.dumps(data, indent=2, ensure_ascii=False, default=str),
            "application/json; charset=utf-8",
        )
    raise ValueError("export_format must be json, markdown or csv")


def record_live_validation_audit_event(
    *,
    action: str,
    channel: str = "core",
    source_id: str | None = None,
    run_id: str | None = None,
    filters: Mapping[str, Any] | None = None,
    export_format: str = "",
    matched: int = 0,
    affected: int = 0,
    dry_run: bool = False,
    applied: bool = False,
    output_path: str = "",
    output_sha256: str = "",
    output_bytes: int = 0,
    manifest_path: str = "",
    storage: Storage | None = None,
) -> dict[str, Any]:
    store = storage or default_live_validation_storage()
    event = LiveValidationAuditEvent(
        action=action,
        channel=channel,
        source_id=source_id or "",
        run_id=run_id or "",
        filters_json=json.dumps(dict(filters or {}), ensure_ascii=False, sort_keys=True, default=str),
        export_format=export_format,
        matched=matched,
        affected=affected,
        dry_run=dry_run,
        applied=applied,
        output_path=output_path,
        output_sha256=output_sha256,
        output_bytes=output_bytes,
        manifest_path=manifest_path,
        secrets_returned=False,
    )
    with store.session() as session:
        session.add(event)
        session.commit()
        session.refresh(event)
    return audit_event_as_dict(event)


def live_validation_export_hash(content: str | bytes) -> dict[str, Any]:
    data = content if isinstance(content, bytes) else content.encode("utf-8")
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def live_validation_export_manifest(
    *,
    content: str | bytes,
    export_format: str,
    content_type: str,
    history: Mapping[str, Any],
    filters: Mapping[str, Any] | None,
    audit_event: Mapping[str, Any],
    output_path: str = "",
) -> dict[str, Any]:
    digest = live_validation_export_hash(content)
    summary = history.get("summary") or {}
    return {
        "schema_version": "1.0",
        "kind": "bedniiosint.live_validation_export_manifest",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "secrets_returned": False,
        "export": {
            "format": export_format,
            "content_type": content_type,
            "sha256": digest["sha256"],
            "bytes": digest["bytes"],
            "output_path": output_path,
            "filters": dict(filters or {}),
            "rows": int(summary.get("rows") or 0),
            "returned": int(summary.get("returned") or 0),
        },
        "audit_event": {
            "id": audit_event.get("id"),
            "action": audit_event.get("action"),
            "channel": audit_event.get("channel"),
            "created_at": audit_event.get("created_at"),
            "output_sha256": audit_event.get("output_sha256"),
            "output_bytes": audit_event.get("output_bytes"),
            "manifest_path": audit_event.get("manifest_path"),
        },
    }


def write_live_validation_export_manifest(
    path: Path,
    *,
    content: str | bytes,
    export_format: str,
    content_type: str,
    history: Mapping[str, Any],
    filters: Mapping[str, Any] | None,
    audit_event: Mapping[str, Any],
    output_path: str = "",
) -> Path:
    manifest = live_validation_export_manifest(
        content=content,
        export_format=export_format,
        content_type=content_type,
        history=history,
        filters=filters,
        audit_event=audit_event,
        output_path=output_path,
    )
    path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    return path


def verify_live_validation_export_manifest(
    manifest_path: Path,
    *,
    export_path: Path | None = None,
    check_audit_log: bool = False,
    storage: Storage | None = None,
) -> dict[str, Any]:
    """Verify a live-validation export file against its sidecar manifest."""
    manifest_file = Path(manifest_path)
    errors: list[str] = []
    checks: dict[str, bool] = {}
    actual = {"sha256": "", "bytes": 0}
    expected = {"sha256": "", "bytes": 0, "output_path": ""}
    audit_summary: dict[str, Any] = {
        "id": None,
        "action": "",
        "channel": "",
        "output_sha256": "",
        "output_bytes": 0,
        "manifest_path": "",
    }
    audit_log: dict[str, Any] = {"checked": check_audit_log}
    resolved_export: Path | None = None

    def add_check(name: str, ok: bool, message: str) -> None:
        checks[name] = bool(ok)
        if not ok:
            errors.append(message)

    if not manifest_file.exists():
        add_check("manifest_exists", False, f"manifest not found: {manifest_file}")
        return _live_validation_verify_result(
            manifest_file=manifest_file,
            export_file=None,
            checks=checks,
            expected=expected,
            actual=actual,
            audit_event=audit_summary,
            audit_log=audit_log,
            errors=errors,
        )
    add_check("manifest_exists", True, "")

    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        add_check("manifest_json", False, f"manifest JSON is invalid: {exc}")
        return _live_validation_verify_result(
            manifest_file=manifest_file,
            export_file=None,
            checks=checks,
            expected=expected,
            actual=actual,
            audit_event=audit_summary,
            audit_log=audit_log,
            errors=errors,
        )
    add_check("manifest_json", isinstance(manifest, Mapping), "manifest must be a JSON object")
    if not isinstance(manifest, Mapping):
        return _live_validation_verify_result(
            manifest_file=manifest_file,
            export_file=None,
            checks=checks,
            expected=expected,
            actual=actual,
            audit_event=audit_summary,
            audit_log=audit_log,
            errors=errors,
        )

    export_info = manifest.get("export") if isinstance(manifest.get("export"), Mapping) else {}
    audit_event = manifest.get("audit_event") if isinstance(manifest.get("audit_event"), Mapping) else {}
    export_bytes_present = "bytes" in export_info
    expected = {
        "sha256": str(export_info.get("sha256") or ""),
        "bytes": _int_value(export_info.get("bytes")),
        "output_path": str(export_info.get("output_path") or ""),
    }
    audit_summary = {
        "id": audit_event.get("id"),
        "action": str(audit_event.get("action") or ""),
        "channel": str(audit_event.get("channel") or ""),
        "output_sha256": str(audit_event.get("output_sha256") or ""),
        "output_bytes": _int_value(audit_event.get("output_bytes")),
        "manifest_path": str(audit_event.get("manifest_path") or ""),
    }

    add_check(
        "kind",
        manifest.get("kind") == "bedniiosint.live_validation_export_manifest",
        "manifest kind is not bedniiosint.live_validation_export_manifest",
    )
    add_check(
        "schema_version",
        str(manifest.get("schema_version") or "") == "1.0",
        "manifest schema_version is not 1.0",
    )
    add_check(
        "secrets_returned",
        manifest.get("secrets_returned") is False,
        "manifest must declare secrets_returned=false",
    )
    add_check("export_sha256_present", bool(expected["sha256"]), "export sha256 is missing")
    add_check("export_bytes_present", export_bytes_present, "export byte size is missing")

    resolved_export = _resolve_live_validation_export_path(
        manifest_file,
        export_path=export_path,
        output_path=expected["output_path"],
    )
    add_check(
        "export_path",
        resolved_export is not None,
        "export path is missing; pass --export or keep the export next to the manifest",
    )
    if resolved_export is not None:
        add_check("export_exists", resolved_export.exists(), f"export not found: {resolved_export}")
        add_check("export_file", resolved_export.is_file(), f"export is not a file: {resolved_export}")
        if resolved_export.exists() and resolved_export.is_file():
            export_bytes = resolved_export.read_bytes()
            digest = live_validation_export_hash(export_bytes)
            actual = {"sha256": str(digest["sha256"]), "bytes": int(digest["bytes"])}
            add_check(
                "sha256",
                actual["sha256"] == expected["sha256"],
                "export SHA-256 does not match manifest",
            )
            add_check(
                "bytes",
                actual["bytes"] == expected["bytes"],
                "export byte size does not match manifest",
            )

    add_check("audit_event_id", audit_summary["id"] is not None, "audit event id is missing")
    add_check(
        "audit_event_action",
        audit_summary["action"] == "export",
        "audit event action is not export",
    )
    add_check(
        "audit_event_sha256",
        audit_summary["output_sha256"] == expected["sha256"],
        "audit event SHA-256 does not match manifest export SHA-256",
    )
    add_check(
        "audit_event_bytes",
        audit_summary["output_bytes"] == expected["bytes"],
        "audit event byte size does not match manifest export byte size",
    )
    add_check(
        "audit_event_manifest_path",
        bool(audit_summary["manifest_path"]),
        "audit event manifest path is missing",
    )

    if check_audit_log:
        _verify_live_validation_audit_log(
            audit_summary,
            expected,
            checks=checks,
            errors=errors,
            audit_log=audit_log,
            storage=storage,
        )

    return _live_validation_verify_result(
        manifest_file=manifest_file,
        export_file=resolved_export,
        checks=checks,
        expected=expected,
        actual=actual,
        audit_event=audit_summary,
        audit_log=audit_log,
        errors=errors,
    )


def live_validation_audit_history(
    *,
    action: str | None = None,
    source_id: str | None = None,
    run_id: str | None = None,
    limit: int = 100,
    storage: Storage | None = None,
) -> dict[str, Any]:
    store = storage or default_live_validation_storage()
    with store.session() as session:
        rows = [audit_event_as_dict(row) for row in session.query(LiveValidationAuditEvent).all()]
    if action:
        rows = [row for row in rows if row.get("action") == action]
    if source_id:
        needle = source_id.lower()
        rows = [row for row in rows if str(row.get("source_id") or "").lower() == needle]
    if run_id:
        rows = [row for row in rows if row.get("run_id") == run_id]
    rows = sorted(rows, key=lambda row: str(row.get("created_at") or ""), reverse=True)
    limited = rows[: max(limit, 0)]
    actions: dict[str, int] = {}
    for row in rows:
        row_action = str(row.get("action") or "unknown")
        actions[row_action] = actions.get(row_action, 0) + 1
    return {
        "summary": {
            "rows": len(rows),
            "returned": len(limited),
            "actions": dict(sorted(actions.items())),
            "affected": sum(int(row.get("affected") or 0) for row in rows),
            "secrets_returned": False,
        },
        "results": limited,
    }


def cleanup_live_validation_results(
    *,
    source_id: str | None = None,
    run_id: str | None = None,
    older_than_days: int | None = None,
    before: str | datetime | None = None,
    apply: bool = False,
    storage: Storage | None = None,
    now: datetime | None = None,
    audit: bool = True,
    channel: str = "core",
) -> dict[str, Any]:
    store = storage or default_live_validation_storage()
    cutoff = _cleanup_cutoff(older_than_days=older_than_days, before=before, now=now)
    if apply and not any([source_id, run_id, cutoff]):
        raise ValueError("cleanup apply requires --source, --run-id, --older-than-days or --before")

    with store.session() as session:
        rows = list(session.query(LiveValidationResult).all())
        matched = [
            row
            for row in rows
            if _cleanup_match(row, source_id=source_id, run_id=run_id, cutoff=cutoff)
        ]
        matched_dicts = [row_as_dict(row) for row in matched]
        if apply:
            for row in matched:
                session.delete(row)
            session.commit()

    result = {
        "summary": {
            "matched": len(matched),
            "deleted": len(matched) if apply else 0,
            "dry_run": not apply,
            "applied": apply,
            "database": str(store.db_path),
            "source_id": source_id or "",
            "run_id": run_id or "",
            "older_than_days": older_than_days,
            "before": cutoff,
            "secrets_returned": False,
        },
        "results": matched_dicts,
    }
    if audit:
        record_live_validation_audit_event(
            action="cleanup",
            channel=channel,
            source_id=source_id,
            run_id=run_id,
            filters={
                "source_id": source_id or "",
                "run_id": run_id or "",
                "older_than_days": older_than_days,
                "before": cutoff,
            },
            matched=len(matched),
            affected=len(matched) if apply else 0,
            dry_run=not apply,
            applied=apply,
            storage=store,
        )
    return result


def live_validation_markdown(history: Mapping[str, Any] | None = None) -> str:
    data = dict(history or live_validation_history())
    summary = data.get("summary") or {}
    rows = list(data.get("results") or [])
    lines = [
        "# BEDNIIOSINT Live Validation Results",
        "",
        "This report contains recorded opt-in validation outcomes only. Secret values are not stored or printed.",
        "",
        "## Summary",
        "",
        f"- Rows: {int(summary.get('rows') or 0)}",
        f"- Returned: {int(summary.get('returned') or 0)}",
        f"- Sources: {int(summary.get('sources') or 0)}",
        f"- Network-required rows: {int(summary.get('network_required') or 0)}",
        f"- Redacted rows: {int(summary.get('redacted_rows') or 0)}",
        f"- Secrets returned: {_yes_no(summary.get('secrets_returned'))}",
        "",
        "## Results",
        "",
    ]
    if not rows:
        lines.append("- No live validation results recorded.")
    for row in rows:
        lines.extend(
            [
                f"### {row.get('source_id') or 'unknown source'}",
                "",
                f"- Run: `{row.get('run_id') or ''}`",
                f"- Recorded: `{row.get('recorded_at') or ''}`",
                f"- Mode: `{row.get('mode') or ''}`",
                f"- Target: `{row.get('target') or 'not recorded'}`",
                f"- Status: `{row.get('status') or 'unknown'}`",
                f"- Verification: `{row.get('verification_status') or ''}`",
                f"- Health: `{row.get('health_status') or ''}`",
                f"- Network required: `{_yes_no(row.get('network_required'))}`",
                f"- Opt-in allowed: `{_yes_no(row.get('allow_opt_in'))}`",
                f"- Redacted: `{_yes_no(row.get('redacted'))}`",
                f"- Reason: {row.get('reason') or 'not recorded'}",
                "",
            ]
        )
    return "\n".join(lines).rstrip() + "\n"


def row_as_dict(row: LiveValidationResult) -> dict[str, Any]:
    return {
        "id": row.id,
        "run_id": row.run_id,
        "source_id": row.source_id,
        "name": row.name,
        "mode": row.mode,
        "target": row.target,
        "status": row.status,
        "reason": row.reason,
        "verification_status": row.verification_status,
        "health_status": row.health_status,
        "network_required": row.network_required,
        "allow_opt_in": row.allow_opt_in,
        "checks": _load_json(row.checks_json, []),
        "errors": _load_json(row.errors_json, []),
        "live_health": _load_json(row.live_health_json, {}),
        "redacted": row.redacted,
        "recorded_at": _datetime_text(row.recorded_at),
    }


def audit_event_as_dict(row: LiveValidationAuditEvent) -> dict[str, Any]:
    return {
        "id": row.id,
        "action": row.action,
        "channel": row.channel,
        "source_id": row.source_id,
        "run_id": row.run_id,
        "filters": _load_json(row.filters_json, {}),
        "export_format": row.export_format,
        "matched": row.matched,
        "affected": row.affected,
        "dry_run": row.dry_run,
        "applied": row.applied,
        "output_path": row.output_path,
        "output_sha256": row.output_sha256,
        "output_bytes": row.output_bytes,
        "manifest_path": row.manifest_path,
        "secrets_returned": row.secrets_returned,
        "created_at": _datetime_text(row.created_at),
    }


def _live_validation_verify_result(
    *,
    manifest_file: Path,
    export_file: Path | None,
    checks: Mapping[str, bool],
    expected: Mapping[str, Any],
    actual: Mapping[str, Any],
    audit_event: Mapping[str, Any],
    audit_log: Mapping[str, Any],
    errors: list[str],
) -> dict[str, Any]:
    return {
        "valid": bool(checks) and all(bool(value) for value in checks.values()),
        "manifest_path": str(manifest_file),
        "export_path": str(export_file) if export_file is not None else "",
        "checks": dict(checks),
        "expected": dict(expected),
        "actual": dict(actual),
        "audit_event": dict(audit_event),
        "audit_log": dict(audit_log),
        "errors": list(errors),
        "secrets_returned": False,
    }


def _resolve_live_validation_export_path(
    manifest_file: Path,
    *,
    export_path: Path | None,
    output_path: str,
) -> Path | None:
    if export_path is not None:
        return Path(export_path)
    candidates: list[Path] = []
    marker = ".manifest.json"
    if manifest_file.name.endswith(marker):
        candidates.append(manifest_file.with_name(manifest_file.name[: -len(marker)]))
    if output_path:
        path = Path(output_path)
        if path.is_absolute():
            candidates.append(path)
        else:
            candidates.append(manifest_file.parent / path)
            candidates.append(path)
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return candidates[0] if candidates else None


def _verify_live_validation_audit_log(
    audit_summary: Mapping[str, Any],
    expected: Mapping[str, Any],
    *,
    checks: dict[str, bool],
    errors: list[str],
    audit_log: dict[str, Any],
    storage: Storage | None,
) -> None:
    event_id = _int_value(audit_summary.get("id"))
    if event_id <= 0:
        checks["audit_log_event_id"] = False
        errors.append("audit log check requires a positive audit event id")
        audit_log["found"] = False
        return
    checks["audit_log_event_id"] = True

    store = storage or default_live_validation_storage()
    with store.session() as session:
        row = session.query(LiveValidationAuditEvent).filter(
            LiveValidationAuditEvent.id == event_id
        ).first()

    audit_log["database"] = str(store.db_path)
    audit_log["found"] = row is not None
    if row is None:
        checks["audit_log_found"] = False
        errors.append(f"audit event {event_id} not found in local audit log")
        return
    checks["audit_log_found"] = True

    stored = audit_event_as_dict(row)
    audit_log["event"] = {
        "id": stored.get("id"),
        "action": stored.get("action"),
        "channel": stored.get("channel"),
        "output_sha256": stored.get("output_sha256"),
        "output_bytes": stored.get("output_bytes"),
        "manifest_path": stored.get("manifest_path"),
    }
    comparisons = {
        "audit_log_action": stored.get("action") == audit_summary.get("action") == "export",
        "audit_log_sha256": stored.get("output_sha256") == expected.get("sha256"),
        "audit_log_bytes": _int_value(stored.get("output_bytes")) == _int_value(expected.get("bytes")),
        "audit_log_manifest_path": str(stored.get("manifest_path") or "")
        == str(audit_summary.get("manifest_path") or ""),
    }
    for name, ok in comparisons.items():
        checks[name] = bool(ok)
        if not ok:
            errors.append(f"{name} check failed")


def _int_value(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _sanitize(value: Any, *, env: Mapping[str, str] | None) -> tuple[Any, bool]:
    secrets = _secret_values(env or os.environ)
    return _redact(value, secrets)


def _live_validation_csv(history: Mapping[str, Any]) -> str:
    output = StringIO()
    writer = csv.DictWriter(output, fieldnames=list(LIVE_VALIDATION_EXPORT_COLUMNS))
    writer.writeheader()
    for row in history.get("results") or []:
        writer.writerow(
            {
                column: _csv_value(row.get(column))
                for column in LIVE_VALIDATION_EXPORT_COLUMNS
            }
        )
    return output.getvalue()


def _csv_value(value: Any) -> Any:
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return value


def _cleanup_cutoff(
    *,
    older_than_days: int | None,
    before: str | datetime | None,
    now: datetime | None,
) -> datetime | None:
    if older_than_days is not None:
        if older_than_days < 0:
            raise ValueError("older_than_days must be non-negative")
        base = now or datetime.now(timezone.utc)
        return base - timedelta(days=older_than_days)
    if before:
        return _parse_datetime(before)
    return None


def _cleanup_match(
    row: LiveValidationResult,
    *,
    source_id: str | None,
    run_id: str | None,
    cutoff: datetime | None,
) -> bool:
    if source_id and str(row.source_id or "").lower() != source_id.lower():
        return False
    if run_id and row.run_id != run_id:
        return False
    if cutoff:
        recorded = _parse_datetime(row.recorded_at)
        if recorded >= cutoff:
            return False
    return True


def _parse_datetime(value: str | datetime) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    else:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _datetime_text(value: str | datetime) -> str:
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value or "")


def _redact(value: Any, secrets: tuple[str, ...], key: str = "") -> tuple[Any, bool]:
    if _is_sensitive_key(key):
        return ("[redacted]" if value not in (None, "", [], {}) else value), bool(value)
    if isinstance(value, Mapping):
        out = {}
        redacted = False
        for item_key, item_value in value.items():
            clean_value, item_redacted = _redact(item_value, secrets, str(item_key))
            out[item_key] = clean_value
            redacted = redacted or item_redacted
        return out, redacted
    if isinstance(value, list):
        out = []
        redacted = False
        for item in value:
            clean_value, item_redacted = _redact(item, secrets, key)
            out.append(clean_value)
            redacted = redacted or item_redacted
        return out, redacted
    if isinstance(value, tuple):
        out = []
        redacted = False
        for item in value:
            clean_value, item_redacted = _redact(item, secrets, key)
            out.append(clean_value)
            redacted = redacted or item_redacted
        return out, redacted
    if isinstance(value, str):
        clean = value
        redacted = False
        for secret in secrets:
            if secret and secret in clean:
                clean = clean.replace(secret, "[redacted]")
                redacted = True
        return clean, redacted
    return value, False


def _secret_values(env: Mapping[str, str]) -> tuple[str, ...]:
    values = []
    for key, value in env.items():
        text = str(value or "")
        if _is_sensitive_key(str(key)) and len(text) >= 4:
            values.append(text)
    return tuple(sorted(set(values), key=len, reverse=True))


def _is_sensitive_key(key: str) -> bool:
    normalized = key.lower().replace("-", "_")
    return any(part.replace("-", "_") in normalized for part in SENSITIVE_KEY_PARTS)


def _load_json(text: str, fallback: Any) -> Any:
    return decrypt_json_field_if_needed(text, fallback)


def _default_run_id() -> str:
    return datetime.now(timezone.utc).strftime("live-%Y%m%d%H%M%S")


def _yes_no(value: Any) -> str:
    return "yes" if bool(value) else "no"
