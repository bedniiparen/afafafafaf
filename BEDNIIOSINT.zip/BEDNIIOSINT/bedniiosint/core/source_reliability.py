from __future__ import annotations

from difflib import SequenceMatcher


def text_similarity(a: str, b: str) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a[:4000], b[:4000]).ratio()


def reliability_from_calibration(
    *,
    controls_claimed_exist: int,
    controls_total: int,
    avg_similarity_real_vs_control: float,
) -> tuple[float, str]:
    if controls_total == 0:
        return 0.5, "no calibration performed"

    notes = []
    reliability = 1.0

    false_rate = controls_claimed_exist / controls_total
    if false_rate > 0:
        reliability -= 0.6 * false_rate
        notes.append(f"{controls_claimed_exist}/{controls_total} controls falsely matched")

    if avg_similarity_real_vs_control > 0.97:
        reliability -= 0.5
        notes.append(f"real/control responses {avg_similarity_real_vs_control:.2f} similar")

    reliability = max(0.0, min(1.0, reliability))
    return round(reliability, 3), "; ".join(notes) or "ok"


def reliability_from_history(
    base_reliability: float,
    *,
    success_count: int = 0,
    error_count: int = 0,
) -> tuple[float, str]:
    base = max(0.0, min(1.0, base_reliability))
    total = max(0, success_count) + max(0, error_count)
    if total == 0:
        return round(base, 3), "no source history"

    error_rate = max(0, error_count) / total
    success_rate = max(0, success_count) / total
    reliability = base - min(0.45, error_rate * 0.45)
    if error_count == 0:
        reliability += min(0.08, success_rate * 0.08)
    reliability = max(0.0, min(1.0, reliability))
    note = f"history success={success_count} error={error_count} error_rate={error_rate:.2f}"
    return round(reliability, 3), note
