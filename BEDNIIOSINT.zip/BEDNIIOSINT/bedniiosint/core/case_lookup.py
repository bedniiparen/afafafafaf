from __future__ import annotations

from ..storage.models import Case
from ..storage.repositories import CaseRepository
from ..storage.sqlite import Storage


def case_rows(storage: Storage, name: str) -> list[Case]:
    return CaseRepository(storage.db_path).list_by_name(name)


def case_ids(storage: Storage, name: str) -> list[int]:
    return CaseRepository(storage.db_path).ids_by_name(name)
