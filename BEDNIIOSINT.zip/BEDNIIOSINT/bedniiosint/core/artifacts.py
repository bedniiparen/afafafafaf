from __future__ import annotations

from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlsplit

from .. import __version__
from ..config import settings
from ..evidence.capture import EvidenceVault
from ..storage.sqlite import Storage


SECRET_KEYS = {"key", "api_key", "api_token", "access_key", "token", "secret", "password"}


def case_vault(storage: Storage, case_name: str, case_id: int) -> EvidenceVault:
    return EvidenceVault(storage, case_id, settings.db_dir / f"{case_name}_vault")


def _query_params(url: str) -> dict[str, str]:
    if not url:
        return {}
    out = {}
    for key, value in parse_qsl(urlsplit(url).query, keep_blank_values=True):
        out[key] = "[redacted]" if key.lower() in SECRET_KEYS else value
    return out


def _captureable_url(url: str) -> bool:
    return url.startswith("http://") or url.startswith("https://")


def capture_raw_result(
    storage: Storage,
    *,
    case_name: str,
    case_id: int,
    finding_id: int,
    source_module: str,
    payload: Any,
    url: str,
    final_url: str = "",
    http_status: int | None = None,
    confidence: float = 0.0,
    name_hint: str = "",
    headers: dict[str, Any] | None = None,
    method: str = "GET",
    adapter_version: str = "",
) -> None:
    vault = case_vault(storage, case_name, case_id)
    adapter_version = adapter_version or f"bedniiosint/{__version__}"
    attachment = vault.store_json(
        payload,
        finding_id,
        name_hint or source_module,
        adapter_version=adapter_version,
        metadata={
            "source_module": source_module,
            "url": url,
            "final_url": final_url,
            "http_status": http_status,
            "method": method,
        },
    )
    try:
        body_len = Path(attachment.path).stat().st_size
    except OSError:
        body_len = 0
    vault.record_evidence(
        finding_id=finding_id,
        url=url,
        final_url=final_url,
        http_status=http_status,
        sha256=attachment.sha256,
        body_len=body_len,
        source_module=source_module,
        adapter_version=adapter_version,
        content_type="application/json",
        headers=headers,
        query_params=_query_params(url),
        method=method,
        artifact_path=attachment.path,
        confidence_at_capture=confidence,
    )


def capture_html_result(
    storage: Storage,
    *,
    case_name: str,
    case_id: int,
    finding_id: int,
    source_module: str,
    html: str,
    url: str,
    final_url: str = "",
    http_status: int | None = None,
    confidence: float = 0.0,
    name_hint: str = "",
    headers: dict[str, Any] | None = None,
    method: str = "GET",
    adapter_version: str = "",
) -> None:
    if not html:
        return
    vault = case_vault(storage, case_name, case_id)
    adapter_version = adapter_version or f"bedniiosint/{__version__}"
    attachment = vault.store_html(
        html,
        finding_id,
        name_hint or source_module,
        adapter_version=adapter_version,
        metadata={
            "source_module": source_module,
            "url": url,
            "final_url": final_url,
            "http_status": http_status,
            "method": method,
        },
    )
    screenshot_url = final_url or url
    if _captureable_url(screenshot_url):
        vault.store_screenshot(
            screenshot_url,
            finding_id,
            name_hint or source_module,
            adapter_version=adapter_version,
            metadata={
                "source_module": source_module,
                "url": url,
                "final_url": final_url,
                "http_status": http_status,
                "method": method,
                "related_html_attachment_id": attachment.id,
                "related_html_sha256": attachment.sha256,
            },
        )
    vault.record_evidence(
        finding_id=finding_id,
        url=url,
        final_url=final_url,
        http_status=http_status,
        sha256=attachment.sha256,
        body_len=len(html.encode("utf-8", "ignore")),
        source_module=source_module,
        adapter_version=adapter_version,
        content_type="text/html",
        headers=headers,
        query_params=_query_params(url),
        method=method,
        artifact_path=attachment.path,
        confidence_at_capture=confidence,
    )
