from __future__ import annotations

import hmac
import json
import os
from dataclasses import dataclass, field
from hashlib import sha256
from pathlib import Path
from typing import Callable

from ..config import settings


@dataclass
class Plugin:
    name: str
    consumes: list[str]
    produces: list[str]
    runner: Callable[..., dict]


@dataclass
class PluginManifest:
    name: str
    consumes: list[str]
    produces: list[str]
    version: str = "0.1.0"
    entrypoint: str = ""
    description: str = ""
    source_id: str = ""
    auth: str = "none"
    env_vars: list[str] = field(default_factory=list)
    path: str = ""
    enabled: bool = True
    config: dict = field(default_factory=dict)
    signature: dict = field(default_factory=dict)
    signature_status: dict = field(default_factory=dict)
    validation: dict = field(default_factory=dict)

    @classmethod
    def from_path(
        cls,
        path: Path,
        *,
        require_valid_signature: bool | None = None,
    ) -> "PluginManifest":
        validation = validate_plugin_manifest(
            path,
            require_valid_signature=require_valid_signature,
        )
        if not validation["valid"]:
            raise ValueError("; ".join(validation["errors"]))
        data = json.loads(path.read_text(encoding="utf-8"))
        name = str(data["name"])
        return cls(
            name=name,
            consumes=list(data.get("consumes", [])),
            produces=list(data.get("produces", [])),
            version=str(data.get("version", "0.1.0")),
            entrypoint=str(data.get("entrypoint", "")),
            description=str(data.get("description", "")),
            source_id=str(data.get("source_id", "")),
            auth=str(data.get("auth", "none")),
            env_vars=list(data.get("env_vars", [])),
            path=str(path),
            enabled=plugin_enabled(name),
            config=get_plugin_config(name),
            signature=dict(data.get("signature") or {}),
            signature_status=validation["signature_status"],
            validation=validation,
        )

    def as_dict(self) -> dict:
        return {
            "name": self.name,
            "consumes": self.consumes,
            "produces": self.produces,
            "version": self.version,
            "entrypoint": self.entrypoint,
            "description": self.description,
            "source_id": self.source_id,
            "auth": self.auth,
            "env_vars": self.env_vars,
            "path": self.path,
            "enabled": self.enabled,
            "config": self.config,
            "signature": self.signature,
            "signature_status": self.signature_status,
            "validation": self.validation,
        }


_REGISTRY: dict[str, Plugin] = {}
PLUGIN_DIR = Path(__file__).resolve().parents[2] / "plugins"
PLUGIN_SIGNING_KEY_ENV = "BEDNIIOSINT_PLUGIN_SIGNING_KEY"
PLUGIN_REQUIRE_SIGNED_ENV = "BEDNIIOSINT_REQUIRE_SIGNED_PLUGINS"
PLUGIN_AUTH_MODES = {
    "",
    "none",
    "optional",
    "api_key",
    "optional_api_key",
    "api_key_for_account",
    "api_key_for_scan",
    "api_key_or_account",
    "api_key_or_community",
    "api_key_secret",
    "bearer_token",
    "none_or_api_key",
    "optional_api_token",
    "optional_token",
}


def _state_path() -> Path:
    settings.db_dir.mkdir(parents=True, exist_ok=True)
    return settings.db_dir / "_plugins.json"


def load_plugin_state() -> dict:
    path = _state_path()
    if not path.exists():
        return {"schema_version": "0.1", "plugins": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"schema_version": "0.1", "plugins": {}}
    if not isinstance(data, dict):
        return {"schema_version": "0.1", "plugins": {}}
    data.setdefault("schema_version", "0.1")
    data.setdefault("plugins", {})
    return data


def save_plugin_state(state: dict) -> Path:
    path = _state_path()
    path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def _plugin_state_row(state: dict, name: str) -> dict:
    plugins = state.setdefault("plugins", {})
    row = plugins.setdefault(name, {})
    row.setdefault("enabled", True)
    row.setdefault("config", {})
    return row


def plugin_enabled(name: str) -> bool:
    row = load_plugin_state().get("plugins", {}).get(name, {})
    return bool(row.get("enabled", True))


def set_plugin_enabled(name: str, enabled: bool) -> dict:
    state = load_plugin_state()
    row = _plugin_state_row(state, name)
    row["enabled"] = bool(enabled)
    save_plugin_state(state)
    return row


def get_plugin_config(name: str) -> dict:
    row = load_plugin_state().get("plugins", {}).get(name, {})
    config = row.get("config", {})
    return dict(config) if isinstance(config, dict) else {}


def set_plugin_config(name: str, config: dict) -> dict:
    state = load_plugin_state()
    row = _plugin_state_row(state, name)
    row["config"] = dict(config)
    save_plugin_state(state)
    return row["config"]


def _manifest_payload(data: dict) -> bytes:
    clean = {key: value for key, value in data.items() if key != "signature"}
    return json.dumps(
        clean,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def require_signed_plugins() -> bool:
    value = os.getenv(PLUGIN_REQUIRE_SIGNED_ENV, "")
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _string_list(value: object) -> bool:
    return isinstance(value, list) and all(isinstance(item, str) and item for item in value)


def validate_plugin_manifest(
    path: Path,
    signing_key: str | None = None,
    *,
    require_valid_signature: bool | None = None,
) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {
            "valid": False,
            "errors": [str(exc)],
            "warnings": [],
            "signature_status": {"signed": False, "verified": False, "error": str(exc)},
        }
    if not isinstance(data, dict):
        errors.append("manifest must be a JSON object")
        data = {}

    for field_name in ("name", "version", "entrypoint"):
        if not isinstance(data.get(field_name), str) or not str(data.get(field_name)).strip():
            errors.append(f"{field_name} must be a non-empty string")
    name = str(data.get("name", ""))
    if name and any(ch.isspace() for ch in name):
        errors.append("name must not contain whitespace")
    if not _string_list(data.get("consumes")):
        errors.append("consumes must be a non-empty list of strings")
    if not _string_list(data.get("produces")):
        errors.append("produces must be a non-empty list of strings")
    entrypoint = str(data.get("entrypoint", ""))
    if entrypoint and ":" not in entrypoint:
        errors.append("entrypoint must use module:function syntax")
    auth = str(data.get("auth", "none"))
    if auth not in PLUGIN_AUTH_MODES:
        warnings.append(f"unknown auth mode: {auth}")
    env_vars = data.get("env_vars", [])
    if not isinstance(env_vars, list) or not all(isinstance(item, str) and item for item in env_vars):
        errors.append("env_vars must be a list of strings")
    config_schema = data.get("config_schema", {})
    if config_schema and not isinstance(config_schema, dict):
        errors.append("config_schema must be a JSON object when present")

    signature_status = verify_plugin_manifest(path, signing_key)
    require_signature = require_signed_plugins() if require_valid_signature is None else require_valid_signature
    if require_signature:
        if not signature_status.get("signed"):
            errors.append("plugin manifest must be signed")
        elif signature_status.get("verified") is not True:
            errors.append(signature_status.get("error") or "plugin signature is not verified")
    elif signature_status.get("signed") and signature_status.get("verified") is False:
        warnings.append(signature_status.get("error") or "plugin signature is not verified")

    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "signature_status": signature_status,
    }


def sign_plugin_manifest(path: Path, signing_key: str, *, key_id: str = "local") -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    signature = hmac.new(
        signing_key.encode("utf-8"),
        _manifest_payload(data),
        sha256,
    ).hexdigest()
    data["signature"] = {
        "algorithm": "hmac-sha256",
        "key_id": key_id,
        "signature": signature,
    }
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return data["signature"]


def verify_plugin_manifest(path: Path, signing_key: str | None = None) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {"signed": False, "verified": False, "error": str(exc)}
    signature = data.get("signature")
    if not isinstance(signature, dict):
        return {"signed": False, "verified": None, "error": ""}
    if signature.get("algorithm") != "hmac-sha256":
        return {"signed": True, "verified": False, "error": "unsupported algorithm"}
    key = signing_key
    if key is None:
        key = os.getenv(PLUGIN_SIGNING_KEY_ENV)
    if not key:
        return {"signed": True, "verified": None, "error": "missing signing key"}
    expected = hmac.new(
        key.encode("utf-8"),
        _manifest_payload(data),
        sha256,
    ).hexdigest()
    verified = hmac.compare_digest(expected, str(signature.get("signature") or ""))
    return {
        "signed": True,
        "verified": verified,
        "key_id": signature.get("key_id", ""),
        "error": "" if verified else "signature mismatch",
    }


def register(plugin: Plugin) -> None:
    _REGISTRY[plugin.name] = plugin


def get(name: str) -> Plugin | None:
    return _REGISTRY.get(name)


def all_plugins() -> list[Plugin]:
    return list(_REGISTRY.values())


def discover_plugin_manifests(
    path: Path | None = None,
    *,
    include_disabled: bool = False,
    require_valid_signature: bool | None = None,
) -> list[PluginManifest]:
    root = path or PLUGIN_DIR
    if not root.exists():
        return []
    manifests: list[PluginManifest] = []
    for manifest_path in sorted(root.glob("*/plugin.json")):
        try:
            manifest = PluginManifest.from_path(
                manifest_path,
                require_valid_signature=require_valid_signature,
            )
            if include_disabled or manifest.enabled:
                manifests.append(manifest)
        except (KeyError, ValueError, json.JSONDecodeError, OSError):
            continue
    return manifests


def all_plugin_manifests(
    path: Path | None = None,
    *,
    include_disabled: bool = False,
    require_valid_signature: bool | None = None,
) -> list[PluginManifest]:
    builtin = [
        PluginManifest(
            name=plugin.name,
            consumes=plugin.consumes,
            produces=plugin.produces,
            version="builtin",
            entrypoint="registered-runner",
            description="Built-in BEDNIIOSINT plugin.",
            enabled=plugin_enabled(plugin.name),
            config=get_plugin_config(plugin.name),
        )
        for plugin in all_plugins()
        if include_disabled or plugin_enabled(plugin.name)
    ]
    return builtin + discover_plugin_manifests(
        path,
        include_disabled=include_disabled,
        require_valid_signature=require_valid_signature,
    )


def _bootstrap() -> None:
    from .case import UsernameCase
    from .case_domain import DomainCase
    from .case_domain_passive_tools import DomainPassiveToolsCase
    from .case_email import EmailCase
    from .case_extra import CompanyCase, IPCase, PhoneCase, URLCase, WalletCase
    from .case_metadata import MetadataCase

    register(
        Plugin(
            "username",
            ["username"],
            ["profile", "url", "avatar"],
            lambda case, target, **_k: UsernameCase(case, target).run(),
        )
    )
    register(
        Plugin(
            "email",
            ["email"],
            ["domain", "avatar", "breach"],
            lambda case, target, **k: EmailCase(case, target, k.get("hibp_key")).run(),
        )
    )
    register(
        Plugin(
            "domain",
            ["domain"],
            ["domain", "ip", "email"],
            lambda case, target, **k: DomainCase(
                case, target, k.get("resolve", True)
            ).run(),
        )
    )
    register(
        Plugin(
            "domain_passive_tools",
            ["domain"],
            ["domain", "subdomain"],
            lambda case, target, **k: DomainPassiveToolsCase(
                case,
                target,
                tools=k.get("tools"),
                timeout=float(k.get("timeout", 60.0)),
            ).run(),
        )
    )
    register(
        Plugin(
            "metadata",
            ["image", "document"],
            ["gps", "device"],
            lambda case, target, **_k: MetadataCase(case, target).run(),
        )
    )
    register(
        Plugin(
            "ip",
            ["ip"],
            ["asn", "domain", "geo"],
            lambda case, target, **_k: IPCase(case, target).run(),
        )
    )
    register(
        Plugin(
            "phone",
            ["phone"],
            ["carrier", "region", "timezone"],
            lambda case, target, **k: PhoneCase(case, target, k.get("region")).run(),
        )
    )
    register(
        Plugin(
            "url",
            ["url"],
            ["url", "email", "wallet", "social"],
            lambda case, target, **_k: URLCase(case, target).run(),
        )
    )
    register(
        Plugin(
            "wallet",
            ["wallet"],
            ["chain", "balance", "transaction"],
            lambda case, target, **_k: WalletCase(case, target).run(),
        )
    )
    register(
        Plugin(
            "company",
            ["company"],
            ["domain", "registry"],
            lambda case, target, **k: CompanyCase(case, target, k.get("domain")).run(),
        )
    )


_bootstrap()
