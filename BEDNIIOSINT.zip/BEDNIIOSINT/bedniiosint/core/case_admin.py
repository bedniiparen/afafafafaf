from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from ..config import settings
from ..storage.models import (
    AnalystNote,
    Attachment,
    Case,
    Entity,
    Evidence,
    Finding,
    Relation,
    SchemaMigration,
    Source,
    TimelineEvent,
)
from ..storage.sqlite import SCHEMA_VERSION, Storage
from ..storage.migrations import migration_status
from .case_lookup import case_rows
from .target import safe_case_name


def _clone(obj, **overrides):
    data = obj.as_dict()
    data.pop("id", None)
    data.update(overrides)
    return obj.__class__(**data)


def merge_cases(target_case: str, source_case: str) -> dict:
    target = safe_case_name(target_case)
    source = safe_case_name(source_case)
    target_storage = Storage(settings.db_path(target))
    source_path = settings.db_path(source)
    if not source_path.exists():
        raise KeyError(f"source case not found: {source}")
    source_storage = Storage(source_path)
    source_cases = case_rows(source_storage, source)
    if not source_cases:
        raise KeyError(f"source case not found: {source}")

    counts = {
        "cases": 0,
        "entities": 0,
        "sources": 0,
        "findings": 0,
        "relations": 0,
        "evidence": 0,
        "attachments": 0,
        "timeline": 0,
        "notes": 0,
    }
    with source_storage.session() as src_session, target_storage.session() as dst_session:
        for src_case in source_cases:
            old_case_id = src_case.id
            new_case = Case(
                name=target,
                target=src_case.target,
                module=src_case.module,
                created_at=src_case.created_at,
            )
            dst_session.add(new_case)
            dst_session.commit()
            dst_session.refresh(new_case)
            if new_case.id is None or old_case_id is None:
                raise RuntimeError("case merge failed to persist case")
            counts["cases"] += 1

            for model, key in (
                (Entity, "entities"),
                (Source, "sources"),
                (Relation, "relations"),
            ):
                for row in src_session.query(model).filter(model.case_id == old_case_id).all():
                    dst_session.add(_clone(row, case_id=new_case.id))
                    counts[key] += 1

            finding_map: dict[int, int] = {}
            for row in src_session.query(Finding).filter(Finding.case_id == old_case_id).all():
                old_finding_id = row.id
                new_finding = _clone(row, case_id=new_case.id)
                dst_session.add(new_finding)
                dst_session.commit()
                dst_session.refresh(new_finding)
                if old_finding_id is not None and new_finding.id is not None:
                    finding_map[old_finding_id] = new_finding.id
                counts["findings"] += 1

            for row in src_session.query(Evidence).filter(Evidence.case_id == old_case_id).all():
                dst_session.add(
                    _clone(
                        row,
                        case_id=new_case.id,
                        finding_id=finding_map.get(row.finding_id, row.finding_id),
                    )
                )
                counts["evidence"] += 1

            for row in src_session.query(Attachment).filter(Attachment.case_id == old_case_id).all():
                dst_session.add(
                    _clone(
                        row,
                        case_id=new_case.id,
                        finding_id=finding_map.get(row.finding_id, row.finding_id)
                        if row.finding_id is not None
                        else None,
                    )
                )
                counts["attachments"] += 1

            for row in src_session.query(TimelineEvent).filter(TimelineEvent.case_id == old_case_id).all():
                dst_session.add(
                    _clone(
                        row,
                        case_id=new_case.id,
                        finding_id=finding_map.get(row.finding_id, row.finding_id)
                        if row.finding_id is not None
                        else None,
                    )
                )
                counts["timeline"] += 1

            for row in src_session.query(AnalystNote).filter(AnalystNote.case_id == old_case_id).all():
                dst_session.add(_clone(row, case_id=new_case.id))
                counts["notes"] += 1
            dst_session.commit()

    return {"target": target, "source": source, "merged": counts}


def archive_case(case_name: str, out_dir: Path) -> Path:
    case = safe_case_name(case_name)
    db_path = settings.db_path(case)
    if not db_path.exists():
        raise KeyError(f"case not found: {case}")
    out_dir.mkdir(parents=True, exist_ok=True)
    vault_dir = settings.db_dir / f"{case}_vault"
    bundle = out_dir / f"{case}-case-archive.zip"
    files = [{"role": "database", "archive_path": f"cases/{db_path.name}"}]
    with ZipFile(bundle, "w", ZIP_DEFLATED) as archive:
        archive.write(db_path, arcname=f"cases/{db_path.name}")
        if vault_dir.exists():
            for path in sorted(vault_dir.rglob("*")):
                if path.is_file():
                    rel = path.relative_to(vault_dir)
                    archive_path = f"vault/{rel.as_posix()}"
                    files.append({"role": "vault", "archive_path": archive_path})
                    archive.write(path, arcname=archive_path)
        archive.writestr(
            "manifest.json",
            json.dumps(
                {
                    "schema_version": "0.1",
                    "storage_schema_version": SCHEMA_VERSION,
                    "case": case,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "files": files,
                },
                indent=2,
                ensure_ascii=False,
            ),
        )
    return bundle


def import_case_archive(
    bundle: Path,
    *,
    case_name: str | None = None,
    overwrite: bool = False,
) -> dict:
    with ZipFile(bundle) as archive:
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
        case = safe_case_name(case_name or manifest.get("case") or bundle.stem)
        db_members = [
            row["archive_path"]
            for row in manifest.get("files", [])
            if row.get("role") == "database"
        ]
        if not db_members:
            raise ValueError("archive manifest has no database file")
        target_db = settings.db_path(case)
        if target_db.exists() and not overwrite:
            raise FileExistsError(target_db)
        target_db.write_bytes(archive.read(db_members[0]))
        storage = Storage(target_db)
        if case_name:
            with storage.session() as session:
                for row in session.query(Case).all():
                    row.name = case
                    session.update(row)
                session.commit()

        vault_files = 0
        vault_root = settings.db_dir / f"{case}_vault"
        for member in archive.infolist():
            if not member.filename.startswith("vault/") or member.is_dir():
                continue
            rel = Path(member.filename).relative_to("vault")
            target = (vault_root / rel).resolve()
            root = vault_root.resolve()
            if target != root and root not in target.parents:
                raise ValueError(f"unsafe archive member path: {member.filename}")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(member.filename))
            vault_files += 1
    return {
        "case": case,
        "db_path": str(target_db),
        "vault_files": vault_files,
        "storage_schema_version": schema_status(case)["current_version"],
    }


def schema_status(case_name: str | None = None) -> dict:
    path = settings.db_path(safe_case_name(case_name)) if case_name else settings.db_dir / "_jobs.db"
    Storage(path)
    with sqlite3.connect(path) as conn:
        conn.row_factory = sqlite3.Row
        status = migration_status(conn)
    status["database"] = str(path)
    return status
