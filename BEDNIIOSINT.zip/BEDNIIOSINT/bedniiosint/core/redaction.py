from __future__ import annotations

import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


URL_RE = re.compile(r"https?://[^\s\"'<>]+")

SECRET_FIELD_MARKERS = (
    "api_key",
    "apikey",
    "api-token",
    "api_token",
    "auth",
    "authorization",
    "bearer",
    "cookie",
    "hibp-api-key",
    "key",
    "password",
    "set-cookie",
    "secret",
    "token",
    "x-apikey",
)


def is_secret_field(name: str) -> bool:
    lowered = name.lower()
    return any(marker in lowered for marker in SECRET_FIELD_MARKERS)


def redact_text(value: str, *, keep: int = 4) -> str:
    if not value:
        return value
    if len(value) <= keep:
        return "[redacted]"
    return f"{value[:keep]}...[redacted]"


def redact_value(value: Any, *, key: str = "") -> Any:
    if key.lower() in {"url", "uri", "profile_url", "final_url"} and isinstance(value, str):
        return redact_url(value)
    if key.lower() in {"error", "message"} and isinstance(value, str):
        return redact_urls_in_text(value)
    if key and is_secret_field(key):
        if isinstance(value, str):
            return redact_text(value)
        if value:
            return "[redacted]"
        return value
    if isinstance(value, dict):
        return {str(k): redact_value(v, key=str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [redact_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_value(item) for item in value)
    return value


def redact_url(value: str) -> str:
    try:
        parts = urlsplit(value)
    except ValueError:
        return value
    if not parts.query:
        return value
    query = []
    changed = False
    for name, item in parse_qsl(parts.query, keep_blank_values=True):
        if is_secret_field(name):
            query.append((name, "[redacted]"))
            changed = True
        else:
            query.append((name, item))
    if not changed:
        return value
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def redact_urls_in_text(value: str) -> str:
    return URL_RE.sub(lambda match: redact_url(match.group(0)), value)
