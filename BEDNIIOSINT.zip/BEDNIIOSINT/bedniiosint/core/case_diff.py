from __future__ import annotations

from typing import Any, Iterable


def _rows(summary: dict[str, Any], key: str) -> list[dict[str, Any]]:
    value = summary.get(key) or []
    return [dict(row) for row in value if isinstance(row, dict)]


def _entity_key(row: dict[str, Any]) -> tuple[str, str]:
    return (str(row.get("type") or ""), str(row.get("value") or ""))


def _finding_key(row: dict[str, Any]) -> tuple[str, str, str, str]:
    return (
        str(row.get("source_id") or row.get("source_name") or ""),
        str(row.get("entity_type") or ""),
        str(row.get("entity_value") or row.get("profile_url") or ""),
        str(row.get("status") or ""),
    )


def _relation_key(row: dict[str, Any]) -> tuple[str, str, str, str, str]:
    return (
        str(row.get("src_type") or ""),
        str(row.get("src_value") or ""),
        str(row.get("rel") or ""),
        str(row.get("dst_type") or ""),
        str(row.get("dst_value") or ""),
    )


def _index(
    rows: Iterable[dict[str, Any]],
    key_func,
) -> dict[tuple[str, ...], dict[str, Any]]:
    return {key_func(row): row for row in rows}


def _delta(
    previous: dict[tuple[str, ...], dict[str, Any]],
    current: dict[tuple[str, ...], dict[str, Any]],
) -> dict[str, list[dict[str, Any]]]:
    return {
        "added": [current[key] for key in sorted(set(current) - set(previous))],
        "removed": [previous[key] for key in sorted(set(previous) - set(current))],
    }


def diff_case_summaries(previous: dict[str, Any], current: dict[str, Any]) -> dict[str, Any]:
    entities = _delta(
        _index(_rows(previous, "entities"), _entity_key),
        _index(_rows(current, "entities"), _entity_key),
    )
    findings = _delta(
        _index(_rows(previous, "findings"), _finding_key),
        _index(_rows(current, "findings"), _finding_key),
    )
    relations = _delta(
        _index(_rows(previous, "relations"), _relation_key),
        _index(_rows(current, "relations"), _relation_key),
    )
    return {
        "schema_version": "0.1",
        "entities": entities,
        "findings": findings,
        "relations": relations,
        "summary": {
            "new_entities": len(entities["added"]),
            "removed_entities": len(entities["removed"]),
            "new_findings": len(findings["added"]),
            "removed_findings": len(findings["removed"]),
            "new_relations": len(relations["added"]),
            "removed_relations": len(relations["removed"]),
        },
    }
