from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from ..modules.metadata.analyzer import analyze_file


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".heic"}
VIDEO_SUFFIXES = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v", ".3gp"}


def build_media_verification_workflow(target: str | Path) -> dict[str, Any]:
    value = str(target)
    path = Path(value)
    generated_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    if path.exists() and path.is_file():
        metadata = analyze_file(path)
        target_type = "file"
        evidence = {
            "path": str(path),
            "sha256": metadata.sha256,
            "file_size": metadata.file_size,
            "exiftool_used": metadata.exiftool_used,
            "gps_status": "present_redacted" if metadata.gps else "not_found",
            "device": metadata.device,
            "software": metadata.software,
            "created": metadata.created,
            "modified": metadata.modified,
            "media_kind": _media_kind(path.name),
        }
    else:
        parsed = urlparse(value)
        target_type = "url" if parsed.scheme and parsed.netloc else "unknown"
        evidence = {
            "target": value,
            "scheme": parsed.scheme,
            "host": parsed.netloc,
            "path": parsed.path,
            "sha256": "",
            "file_size": None,
            "exiftool_used": False,
            "gps_status": "not_checked",
            "media_kind": _media_kind(parsed.path),
        }
    checks = _checks(target_type, evidence)
    archive_plan = _archive_plan(target_type, evidence)
    reverse_search_plan = _reverse_search_plan(target_type, evidence)
    geolocation_plan = _geolocation_plan()
    timeline_plan = _timeline_plan(evidence)
    return {
        "schema_version": "2.0",
        "generated_at": generated_at,
        "target": value,
        "target_type": target_type,
        "legal_scope": "public, permissioned OSINT; no scraping, login bypass or hidden tracking",
        "evidence": evidence,
        "privacy": {
            "third_party_upload_default": "disabled",
            "sensitive_media_policy": "hash and local metadata first; upload only with explicit analyst approval and allow_uploads",
            "identity_policy": "reverse-image matches are review leads, not identity proof",
        },
        "artifacts_to_collect": _artifacts_to_collect(target_type),
        "archive_plan": archive_plan,
        "reverse_search_plan": reverse_search_plan,
        "geolocation_plan": geolocation_plan,
        "timeline_plan": timeline_plan,
        "checks": checks,
        "not_confirmed": [
            row["task"]
            for row in checks
            if row["status"] == "not_confirmed"
        ],
    }


def write_media_verification_markdown(workflow: dict[str, Any], out: Path) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    evidence = workflow.get("evidence", {})
    lines = [
        f"# Media Verification Workflow: {workflow.get('target')}",
        "",
        f"Generated: {workflow.get('generated_at')}",
        f"Target type: {workflow.get('target_type')}",
        f"Legal scope: {workflow.get('legal_scope')}",
        "",
        "## Privacy",
    ]
    for key, value in (workflow.get("privacy") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(
        [
            "",
            "## Artifacts To Collect",
        ]
    )
    for artifact in workflow.get("artifacts_to_collect", []):
        lines.append(
            f"- {artifact['name']}: {artifact['why']} "
            f"(store: {artifact['store']})"
        )
    lines.extend(
        [
            "",
            "## Archive Search",
        ]
    )
    for item in workflow.get("archive_plan", []):
        lines.append(f"- [{item['status']}] {item['provider']}: {item['task']}")
    lines.extend(
        [
            "",
            "## Reverse Search",
        ]
    )
    for item in workflow.get("reverse_search_plan", []):
        upload_note = "requires upload opt-in" if item.get("requires_upload") else "no upload by default"
        lines.append(f"- [{item['status']}] {item['provider']}: {item['task']} ({upload_note})")
    lines.extend(
        [
            "",
            "## Geolocation",
        ]
    )
    for item in workflow.get("geolocation_plan", []):
        lines.append(f"- [{item['status']}] {item['task']} (record: {item['evidence_to_record']})")
    lines.extend(
        [
            "",
            "## Timeline",
        ]
    )
    for item in workflow.get("timeline_plan", []):
        lines.append(f"- [{item['status']}] {item['task']} (record: {item['evidence_to_record']})")
    lines.extend(
        [
            "",
            "## Evidence",
        ]
    )
    for key in (
        "path",
        "target",
        "host",
        "sha256",
        "file_size",
        "exiftool_used",
        "gps_status",
        "device",
        "software",
        "created",
        "modified",
    ):
        if key in evidence and evidence.get(key) not in {None, ""}:
            lines.append(f"- {key}: {evidence.get(key)}")
    lines.extend(["", "## Checks"])
    for check in workflow.get("checks", []):
        lines.append(
            f"- [{check['status']}] {check['category']}: {check['task']} "
            f"(how: {check['how_to_verify']}; record: {check.get('evidence_to_record', 'not recorded')})"
        )
    lines.extend(["", "## Not Confirmed"])
    not_confirmed = workflow.get("not_confirmed", [])
    if not_confirmed:
        lines.extend(f"- {item}" for item in not_confirmed)
    else:
        lines.append("- None.")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


def _checks(target_type: str, evidence: dict[str, Any]) -> list[dict[str, str]]:
    checks = [
        {
            "category": "integrity",
            "task": "Preserve original file or source URL and record SHA-256 when available",
            "status": "complete" if evidence.get("sha256") else "not_confirmed",
            "how_to_verify": "compare recorded SHA-256 with the original artifact",
            "evidence_to_record": "SHA-256, file size, original path or URL, capture timestamp",
            "tools": "BEDNIIOSINT metadata, sha256sum/Get-FileHash",
            "privacy_risk": "low",
        },
        {
            "category": "metadata",
            "task": "Review EXIF/container metadata for timestamps, software and GPS",
            "status": "complete" if evidence.get("exiftool_used") else "not_confirmed",
            "how_to_verify": "run local metadata extraction; do not upload private media to third-party tools by default",
            "evidence_to_record": "EXIF timestamps, device/software fields, GPS presence redacted when sensitive",
            "tools": "ExifTool, BEDNIIOSINT metadata module",
            "privacy_risk": "medium when GPS/device data is present",
        },
        {
            "category": "geolocation",
            "task": "Verify visible landmarks, shadows, weather and map context manually",
            "status": "not_confirmed",
            "how_to_verify": "compare against public maps/satellite imagery and preserve source links",
            "evidence_to_record": "candidate location, map links, visible landmarks, uncertainty notes",
            "tools": "public maps, satellite imagery, weather archives",
            "privacy_risk": "medium",
        },
        {
            "category": "reverse_search",
            "task": "Check prior appearances with lawful reverse image/video search",
            "status": "not_confirmed",
            "how_to_verify": "record provider, query time, result URL and avoid ToS-violating automation",
            "evidence_to_record": "provider, query type, result URLs, match type, analyst conclusion",
            "tools": "TinEye API with opt-in, manual reverse search, InVID-style keyframes",
            "privacy_risk": "medium/high when uploading local media",
        },
        {
            "category": "timeline",
            "task": "Corroborate claimed capture time with external public context",
            "status": "not_confirmed",
            "how_to_verify": "compare upload time, metadata time, news/weather/events and archive captures",
            "evidence_to_record": "claimed time, metadata time, first-seen time, archive captures, contradictions",
            "tools": "Wayback/Archive-It, news search, weather/event archives",
            "privacy_risk": "low",
        },
    ]
    if target_type == "url":
        checks.insert(
            1,
            {
                "category": "source_page",
                "task": "Archive and capture the public page containing the media",
                "status": "not_confirmed",
                "how_to_verify": "use legal public archiving/capture tools and store final URL/timestamp",
                "evidence_to_record": "source page URL, final URL, archive URL, capture timestamp",
                "tools": "Wayback Machine, archive.today alternatives, local screenshot/evidence vault",
                "privacy_risk": "medium if archiving exposes private or sensitive URLs",
            },
        )
    return checks


def _media_kind(name: str) -> str:
    suffix = Path(name).suffix.lower()
    if suffix in IMAGE_SUFFIXES:
        return "image"
    if suffix in VIDEO_SUFFIXES:
        return "video"
    return "unknown"


def _artifacts_to_collect(target_type: str) -> list[dict[str, str]]:
    artifacts = [
        {
            "name": "original_artifact_hash",
            "why": "proves later analysis refers to the same media",
            "store": "case evidence manifest",
        },
        {
            "name": "metadata_snapshot",
            "why": "captures timestamps, device/software and GPS presence before edits",
            "store": "local JSON/Markdown report",
        },
        {
            "name": "analyst_notes",
            "why": "records what is confirmed, contradicted and still uncertain",
            "store": "case notes",
        },
    ]
    if target_type == "url":
        artifacts.append(
            {
                "name": "source_page_archive",
                "why": "preserves the public page context around the media",
                "store": "archive URL and local evidence vault",
            }
        )
    return artifacts


def _archive_plan(target_type: str, evidence: dict[str, Any]) -> list[dict[str, Any]]:
    target = evidence.get("target") or evidence.get("path") or ""
    rows = [
        {
            "provider": "Wayback Machine / Internet Archive",
            "task": f"Check first-seen and capture history for {target}",
            "status": "not_confirmed",
            "evidence_to_record": "capture URL, timestamp, HTTP status and page title",
            "requires_upload": False,
        },
        {
            "provider": "archive.today / archive.is alternatives",
            "task": "Use only for public pages where archiving is allowed by scope",
            "status": "not_confirmed",
            "evidence_to_record": "archive URL, submission time and final URL",
            "requires_upload": False,
        },
    ]
    if target_type == "file":
        rows.append(
            {
                "provider": "Local evidence vault",
                "task": "Preserve local file hash instead of submitting private media to public archives",
                "status": "complete" if evidence.get("sha256") else "not_confirmed",
                "evidence_to_record": "SHA-256, file size and local path",
                "requires_upload": False,
            }
        )
    return rows


def _reverse_search_plan(target_type: str, evidence: dict[str, Any]) -> list[dict[str, Any]]:
    media_kind = evidence.get("media_kind") or "unknown"
    rows = [
        {
            "provider": "TinEye API",
            "task": "Run image URL lookup when the media is public and TINEYE_API_KEY is configured",
            "status": "not_confirmed",
            "command": "bedniiosint source-run api:tineye <image-url> --input image_url --allow-sensitive-sources",
            "requires_upload": False,
            "privacy_note": "URL lookup still discloses the URL to TinEye; use only with approved public media",
        },
        {
            "provider": "TinEye API upload",
            "task": "Upload a local image only after explicit analyst approval",
            "status": "not_confirmed",
            "command": "bedniiosint source-run api:tineye <file> --input image --allow-uploads --allow-sensitive-sources",
            "requires_upload": True,
            "privacy_note": "third-party upload is disabled by default",
        },
    ]
    if media_kind == "video":
        rows.append(
            {
                "provider": "InVID-style keyframe workflow",
                "task": "Extract representative keyframes locally before any reverse-image lookup",
                "status": "not_confirmed",
                "command": "ffmpeg -i <video> -vf fps=1/<seconds> keyframe-%03d.jpg",
                "requires_upload": False,
                "privacy_note": "review keyframes for sensitive content before third-party submission",
            }
        )
    return rows


def _geolocation_plan() -> list[dict[str, str]]:
    return [
        {
            "task": "List visible landmarks, signs, terrain, road markings, weather and shadows",
            "status": "not_confirmed",
            "evidence_to_record": "candidate clues and screenshots with source URLs",
        },
        {
            "task": "Compare clues against public maps and satellite imagery",
            "status": "not_confirmed",
            "evidence_to_record": "map links, coordinates if public/safe, confidence and contradictions",
        },
        {
            "task": "Record uncertainty instead of over-claiming a location",
            "status": "not_confirmed",
            "evidence_to_record": "confirmed, plausible and rejected location candidates",
        },
    ]


def _timeline_plan(evidence: dict[str, Any]) -> list[dict[str, str]]:
    created = evidence.get("created") or "not recorded"
    modified = evidence.get("modified") or "not recorded"
    return [
        {
            "task": "Compare claimed capture time with file metadata and source upload time",
            "status": "not_confirmed",
            "evidence_to_record": f"created={created}; modified={modified}; upload time",
        },
        {
            "task": "Check public context around the claimed time",
            "status": "not_confirmed",
            "evidence_to_record": "weather, events, news, shadows, transport schedules where relevant",
        },
        {
            "task": "Identify earliest public appearance",
            "status": "not_confirmed",
            "evidence_to_record": "archive captures, reverse-search first seen, repost chain",
        },
    ]
