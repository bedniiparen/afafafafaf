from __future__ import annotations

import random
import time
from email.utils import parsedate_to_datetime
from typing import Any

from ..config import settings
from .response_cache import ResponseCache, response_cache

_UA_POOL = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
)


def select_user_agent() -> str:
    if settings.rotate_user_agents:
        return random.choice(_UA_POOL)
    return settings.user_agent


def select_proxy() -> str | None:
    if settings.proxy_pool:
        return random.choice(settings.proxy_pool)
    return settings.proxy_url or None


def apply_jitter() -> None:
    if settings.request_jitter > 0:
        time.sleep(random.uniform(0.0, settings.request_jitter))


def cache_ttl_from_headers(headers: dict[str, str] | Any, default: float | None = None) -> float:
    cache_control = str(headers.get("Cache-Control", "") or "")
    directives = {
        item.strip().lower()
        for item in cache_control.split(",")
        if item.strip() and "=" not in item
    }
    if "no-store" in directives or "private" in directives:
        return 0.0
    for item in cache_control.split(","):
        key, sep, value = item.strip().partition("=")
        if sep and key.lower() in {"max-age", "s-maxage"}:
            try:
                return max(0.0, float(value.strip('"')))
            except ValueError:
                return default if default is not None else settings.cache_ttl
    expires = headers.get("Expires") if hasattr(headers, "get") else None
    if expires:
        try:
            return max(0.0, parsedate_to_datetime(str(expires)).timestamp() - time.time())
        except (TypeError, ValueError, OSError):
            pass
    return default if default is not None else settings.cache_ttl
