from __future__ import annotations

from collections.abc import Iterable
from typing import Any


NO_CACHE_MARKERS = ("no_cache", "do_not_cache", "manual", "submission", "upload")


def default_source_cache_ttl_seconds(source: Any) -> int:
    cache_policy = str(getattr(source, "cache_policy", "") or "").lower()
    if any(marker in cache_policy for marker in NO_CACHE_MARKERS):
        return 0
    if bool(getattr(source, "requires_opt_in", False)) and any(
        marker in str(getattr(source, "notes", "") or "").lower()
        for marker in ("upload", "submission")
    ):
        return 0
    quota_policy = str(getattr(source, "quota_policy", "") or "").lower()
    auth = str(getattr(source, "auth", "") or "").lower()
    risk = str(getattr(source, "terms_risk", "") or "").lower()
    priority = str(getattr(source, "priority", "") or "").upper()
    if "keyed" in quota_policy or auth not in {"", "none", "no auth", "optional"}:
        return 86_400
    if risk in {"medium", "high"}:
        return 21_600
    if priority in {"P0", "P1"}:
        return 3_600
    return 1_800


def source_cache_ttl_presets(source_ids: Iterable[str] | None = None) -> dict[str, int]:
    from ..catalog.registry import registry_entries

    selected = {str(item).strip() for item in source_ids or [] if str(item).strip()}
    presets: dict[str, int] = {}
    for source in registry_entries():
        if source.kind != "api":
            continue
        if selected and source.id not in selected and source.id.replace("api:", "", 1) not in selected:
            continue
        ttl = default_source_cache_ttl_seconds(source)
        if ttl > 0:
            presets[source.id] = ttl
    return presets


def merge_cache_ttl_presets(
    overrides: dict[str, int] | None = None,
    *,
    source_ids: Iterable[str] | None = None,
) -> dict[str, int]:
    merged = source_cache_ttl_presets(source_ids)
    merged.update(overrides or {})
    return merged
