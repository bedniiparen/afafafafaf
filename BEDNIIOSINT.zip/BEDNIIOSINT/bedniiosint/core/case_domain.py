from __future__ import annotations

from datetime import datetime

from ..config import settings
from ..modules.domain.analyzer import analyze_domain
from ..storage.models import Case, Entity, Finding, Relation
from ..storage.sqlite import Storage
from .artifacts import capture_raw_result
from .confidence import markers_to_text
from .source_record import record_source
from .timeline import add_event


class DomainCase:
    def __init__(self, case_name: str, domain: str, resolve_subs: bool = True):
        self.case_name = case_name
        self.domain = domain
        self.resolve = resolve_subs
        self.storage = Storage(settings.db_path(case_name))

    def run(self) -> dict:
        result = analyze_domain(self.domain, self.resolve)
        with self.storage.session() as session:
            case = Case(name=self.case_name, target=result.domain, module="domain")
            session.add(case)
            session.commit()
            session.refresh(case)
            if case.id is None:
                raise RuntimeError("case was not persisted")

            session.add(Entity(case_id=case.id, type="domain", value=result.domain))
            for subdomain in result.subdomains:
                session.add(
                    Entity(case_id=case.id, type="domain", value=subdomain["subdomain"])
                )
                session.add(
                    Relation(
                        case_id=case.id,
                        src_type="domain",
                        src_value=result.domain,
                        rel="same_domain",
                        dst_type="domain",
                        dst_value=subdomain["subdomain"],
                    )
                )
            rejected = bool(result.reject_reason)
            source = record_source(
                session,
                case_id=case.id,
                name="domain-analyzer",
                url_main=f"https://{result.domain}",
                category="domain",
                rejected=rejected,
                notes=result.reject_reason or "scored DNS/RDAP/CT signals",
            )
            finding = Finding(
                case_id=case.id,
                source_name="domain-analyzer",
                source_reliability=source.reliability,
                entity_value=result.domain,
                profile_url=f"https://{result.domain}",
                status="exists",
                page_title=(
                    f"subdomains={len(result.subdomains)} "
                    f"registrar={result.rdap.get('registrar', '?')}"
                ),
                matched_markers=markers_to_text(result.matched_markers),
                confidence=result.confidence,
                rejected=rejected,
                reject_reason=result.reject_reason,
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("finding was not persisted")
            capture_raw_result(
                self.storage,
                case_name=self.case_name,
                case_id=case.id,
                finding_id=finding.id,
                source_module="domain",
                payload=result.__dict__,
                url=f"https://{result.domain}",
                confidence=result.confidence,
                name_hint="domain-analyzer",
            )
            case_id = case.id

        registered = result.rdap.get("registration_date")
        if registered:
            try:
                add_event(
                    self.storage,
                    case_id,
                    kind="registered",
                    entity_type="domain",
                    entity_value=result.domain,
                    when=datetime.fromisoformat(registered.replace("Z", "+00:00")),
                    source="RDAP",
                    description="Domain registration",
                )
            except ValueError:
                pass
        return {
            "meta": {"case": self.case_name, "domain": result.domain, "module": "domain"},
            "result": result.__dict__,
        }
