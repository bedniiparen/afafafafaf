from __future__ import annotations

import logging
from datetime import datetime

from ..config import settings
from ..modules.metadata.analyzer import analyze_file
from ..storage.models import Case, Entity, Finding
from ..storage.sqlite import Storage
from .artifacts import capture_raw_result
from .confidence import markers_to_text
from .source_record import record_source
from .timeline import add_event

logger = logging.getLogger(__name__)


class MetadataCase:
    def __init__(self, case_name: str, file_path: str):
        self.case_name = case_name
        self.file_path = file_path
        self.storage = Storage(settings.db_path(case_name))

    def run(self) -> dict:
        result = analyze_file(self.file_path)
        with self.storage.session() as session:
            case = Case(name=self.case_name, target=self.file_path, module="metadata")
            session.add(case)
            session.commit()
            session.refresh(case)
            if case.id is None:
                raise RuntimeError("case was not persisted")

            entity_type = "image" if result.device or result.gps else "document"
            session.add(Entity(case_id=case.id, type=entity_type, value=result.path))
            source_name = "exiftool" if result.exiftool_used else "native"
            rejected = bool(result.reject_reason)
            record_source(
                session,
                case_id=case.id,
                name=source_name,
                category="metadata",
                rejected=rejected,
                notes=result.reject_reason or "scored file hash and metadata signals",
            )
            finding = Finding(
                case_id=case.id,
                source_name=source_name,
                entity_value=result.path,
                profile_url=result.path,
                status="exists",
                page_title=(
                    f"device={result.device} sw={result.software} "
                    f"gps={'yes' if result.gps else 'no'}"
                ),
                matched_markers=markers_to_text(result.matched_markers),
                confidence=result.confidence,
                rejected=rejected,
                reject_reason=result.reject_reason,
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            if finding.id is None:
                raise RuntimeError("finding was not persisted")
            capture_raw_result(
                self.storage,
                case_name=self.case_name,
                case_id=case.id,
                finding_id=finding.id,
                source_module="metadata",
                payload=result.__dict__,
                url=result.path,
                confidence=result.confidence,
                name_hint=source_name,
            )
            case_id = case.id

        if result.created:
            try:
                add_event(
                    self.storage,
                    case_id,
                    kind="created",
                    entity_type="document",
                    entity_value=result.path,
                    when=datetime.fromisoformat(
                        result.created.replace(":", "-", 2).replace("Z", "+00:00")
                    ),
                    source="EXIF",
                    description="File creation date",
                )
            except Exception as exc:
                logger.debug("case_metadata: failed to parse EXIF creation date: %s", exc)
        return {
            "meta": {
                "case": self.case_name,
                "file": result.path,
                "module": "metadata",
            },
            "result": {key: value for key, value in result.__dict__.items() if key != "raw"},
        }
