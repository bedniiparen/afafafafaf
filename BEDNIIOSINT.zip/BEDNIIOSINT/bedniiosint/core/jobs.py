from __future__ import annotations

import asyncio
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
import json
import os
import socket
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx

from ..config import DEFAULT_SITES_FILE, settings
from ..modules.username.scanner import SiteResult, load_sites, scan_site
from ..storage.models import ScanJob, ScanJobEvent
from ..storage.sqlite import Storage
from .cache_policy import merge_cache_ttl_presets
from .http import HttpPolicy
from .target import auto_case_name, detect_module, safe_case_name


_TERMINAL_STATUSES = {"finished", "failed", "cancelled"}
KEYED_BUDGETED_SOURCES = [
    "api:abuseipdb",
    "api:builtwith",
    "api:censys",
    "api:companies_house",
    "api:google_cse",
    "api:greynoise",
    "api:hibp",
    "api:hunter",
    "api:numverify",
    "api:open_measures",
    "api:osintly_api",
    "api:securitytrails",
    "api:shodan",
    "api:tineye",
    "api:twilio_lookup",
    "api:veriphone",
    "api:virustotal",
    "api:wappalyzer",
    "api:youtube",
]
KEYED_STANDARD_EXTRA_BUDGETS = {
    "api:github": 5,
    "api:github_search": 5,
    "api:ipinfo": 5,
    "api:opencorporates": 5,
}
RATE_LIMIT_BUDGET_PRESETS: dict[str, dict[str, int]] = {
    "none": {},
    "smoke": {
        "*": 1,
        **{source_id: 1 for source_id in KEYED_BUDGETED_SOURCES},
    },
    "conservative": {
        "*": 2,
        **{source_id: 1 for source_id in KEYED_BUDGETED_SOURCES},
        **{source_id: 2 for source_id in KEYED_STANDARD_EXTRA_BUDGETS},
    },
    "standard": {
        "*": 5,
        **{source_id: 2 for source_id in KEYED_BUDGETED_SOURCES},
        **KEYED_STANDARD_EXTRA_BUDGETS,
    },
}
_WORKER_LOCK = threading.Lock()
_WORKER_STOP = threading.Event()
_WORKER_THREAD: threading.Thread | None = None
_WORKER_STATE: dict[str, Any] = {
    "running": False,
    "last_job_id": None,
    "last_error": "",
    "jobs_run": 0,
    "started_at": None,
    "worker_id": "",
    "last_recovered_stale": 0,
    "stale_after_seconds": 300.0,
}


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def job_stale_after_seconds() -> float:
    return max(30.0, _env_float("BEDNIIOSINT_JOB_STALE_AFTER_SECONDS", 120.0))


def _username_job_workers(total: int) -> int:
    configured = _env_int(
        "BEDNIIOSINT_USERNAME_JOB_WORKERS",
        min(max(1, settings.max_concurrency), 24),
    )
    return max(1, min(max(1, total), configured))


def _search_job_workers() -> int:
    configured = _env_int("BEDNIIOSINT_SEARCH_JOB_WORKERS", 8)
    return max(1, min(max(1, settings.max_concurrency), configured))


def _username_job_http_policy() -> HttpPolicy:
    return HttpPolicy(
        timeout=max(1.0, _env_float("BEDNIIOSINT_USERNAME_JOB_TIMEOUT", 6.0)),
        max_retries=max(0, _env_int("BEDNIIOSINT_USERNAME_JOB_RETRIES", 0)),
        backoff=settings.http_backoff,
        rate_limit_delay=settings.http_rate_limit_delay,
        user_agent=settings.user_agent,
    )


def _single_module_socket_timeout() -> float:
    return max(1.0, _env_float("BEDNIIOSINT_JOB_SOCKET_TIMEOUT", settings.timeout))


def _heartbeat_interval() -> float:
    return max(0.5, _env_float("BEDNIIOSINT_JOB_HEARTBEAT_INTERVAL", 2.0))


def _job_storage() -> Storage:
    return Storage(settings.db_dir / "_jobs.db")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _worker_id() -> str:
    configured = os.environ.get("BEDNIIOSINT_WORKER_ID", "").strip()
    if configured:
        return configured
    return f"{socket.gethostname()}:{os.getpid()}:{threading.get_ident()}"


def _as_datetime(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if value is None or value == "":
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def _estimate_total(module: str, target: str = "") -> int:
    if module == "username":
        try:
            return len(load_sites(DEFAULT_SITES_FILE))
        except Exception:
            return 0
    if _is_investigate_module(module):
        return max(1, int(settings.autopivot_max_nodes))
    if _is_search_module(module):
        try:
            from ..search.planner import plan_search

            return len(
                plan_search(
                    target,
                    entity_type=_search_input_type(module, target),
                    include_auth_required=True,
                ).sources
            )
        except Exception:
            return 0
    if _is_pipeline_module(module):
        try:
            from .source_pipeline import pipeline_sources

            return len(pipeline_sources(_pipeline_input_type(module, "")))
        except Exception:
            return 0
    return 1


def _is_pipeline_module(module: str) -> bool:
    return module == "pipeline" or module.endswith("_pipeline")


def _is_search_module(module: str) -> bool:
    return module == "search" or module.endswith("_search")


def _is_investigate_module(module: str) -> bool:
    return module == "investigate" or module.endswith("_investigate")


def _search_input_type(module: str, target: str) -> str:
    if module == "search":
        return detect_module(target)
    if module.endswith("_search"):
        return module[: -len("_search")]
    return module


def _investigate_input_type(module: str, target: str) -> str:
    if module == "investigate":
        return detect_module(target)
    if module.endswith("_investigate"):
        return module[: -len("_investigate")]
    return module


def _pipeline_input_type(module: str, target: str) -> str:
    if module == "pipeline":
        return detect_module(target)
    if module.endswith("_pipeline"):
        return module[: -len("_pipeline")]
    return module


def parse_rate_limit_budget(raw: str | dict[str, Any] | None) -> dict[str, int]:
    if raw is None or raw == "":
        return {}
    if isinstance(raw, dict):
        items = raw.items()
    else:
        text = str(raw).strip()
        if not text:
            return {}
        if text.startswith("{"):
            data = json.loads(text)
            if not isinstance(data, dict):
                raise ValueError("rate limit budget JSON must be an object")
            items = data.items()
        else:
            pairs: list[tuple[str, str]] = []
            for chunk in text.split(","):
                chunk = chunk.strip()
                if not chunk:
                    continue
                if "=" in chunk:
                    key, value = chunk.split("=", 1)
                elif ":" in chunk:
                    key, value = chunk.split(":", 1)
                else:
                    raise ValueError("budget entries must look like source=limit")
                pairs.append((key, value))
            items = pairs

    budgets: dict[str, int] = {}
    for key, value in items:
        source = str(key).strip()
        if not source:
            continue
        budgets[source] = max(0, int(value))
    return budgets


def rate_limit_budget_preset(name: str | None) -> dict[str, int]:
    selected = (name or "none").strip().lower()
    if selected not in RATE_LIMIT_BUDGET_PRESETS:
        allowed = ", ".join(sorted(RATE_LIMIT_BUDGET_PRESETS))
        raise ValueError(f"unknown rate-limit budget preset: {name}; allowed: {allowed}")
    return dict(RATE_LIMIT_BUDGET_PRESETS[selected])


def rate_limit_budget_presets() -> dict[str, dict[str, int]]:
    return {
        name: dict(budget)
        for name, budget in RATE_LIMIT_BUDGET_PRESETS.items()
    }


def resolve_rate_limit_budget(
    raw: str | dict[str, Any] | None = None,
    *,
    preset: str | None = None,
) -> dict[str, int]:
    budget = rate_limit_budget_preset(preset)
    budget.update(parse_rate_limit_budget(raw))
    return budget


def _case_name_in_use(case_name: str, session) -> bool:
    if settings.db_path(case_name).exists():
        return True
    return session.query(ScanJob).filter(ScanJob.case_name == case_name).first() is not None


def _next_auto_case_name(base: str, session) -> str:
    if not _case_name_in_use(base, session):
        return base
    for index in range(2, 10_000):
        candidate = safe_case_name(f"{base}-{index}")
        if not _case_name_in_use(candidate, session):
            return candidate
    raise ValueError(f"could not allocate unique case name for {base}")


def create_job(
    target: str,
    *,
    module: str = "auto",
    case_name: str | None = None,
    max_retries: int = 1,
    rate_limit_budget: str | dict[str, Any] | None = None,
    resume: bool = False,
) -> ScanJob:
    selected = detect_module(target) if module == "auto" else module.strip().lower()
    if selected == "pipeline":
        selected = f"{detect_module(target)}_pipeline"
    if selected == "search":
        selected = f"{detect_module(target)}_search"
    budgets = parse_rate_limit_budget(rate_limit_budget)
    storage = _job_storage()
    with storage.session() as session:
        if case_name:
            case = safe_case_name(case_name)
        else:
            base_case = auto_case_name(selected, target)
            case = base_case if resume else _next_auto_case_name(base_case, session)
        job = ScanJob(
            case_name=case,
            target=target,
            module=selected,
            status="queued",
            total_sources=_estimate_total(selected, target),
            updated_at=_now(),
            max_retries=max(0, int(max_retries)),
            rate_limit_budget_json=json.dumps(budgets, ensure_ascii=False, sort_keys=True),
            resume=resume,
        )
        session.add(job)
        session.commit()
        session.refresh(job)
        if job.id is not None:
            session.add(
                ScanJobEvent(
                    job_id=job.id,
                    kind="created",
                    source=selected,
                    status="queued",
                    message="Job queued",
                    progress=0.0,
                )
            )
            session.commit()
        return job


def get_job(job_id: int) -> ScanJob | None:
    with _job_storage().session() as session:
        return session.query(ScanJob).filter(ScanJob.id == job_id).first()


def list_jobs(limit: int = 50) -> list[ScanJob]:
    with _job_storage().session() as session:
        jobs = session.query(ScanJob).all()
    jobs.sort(key=lambda job: job.created_at, reverse=True)
    return jobs[:limit]


def add_job_event(
    job_id: int,
    *,
    kind: str,
    source: str = "",
    status: str = "",
    message: str = "",
    progress: float = 0.0,
    attempt: int = 0,
    budget_remaining: int | None = None,
) -> ScanJobEvent:
    storage = _job_storage()
    with storage.session() as session:
        event = ScanJobEvent(
            job_id=job_id,
            kind=kind,
            source=source,
            status=status,
            message=message,
            progress=progress,
            attempt=attempt,
            budget_remaining=budget_remaining,
        )
        session.add(event)
        session.commit()
        session.refresh(event)
        return event


def list_job_events(job_id: int) -> list[ScanJobEvent]:
    with _job_storage().session() as session:
        events = session.query(ScanJobEvent).filter(ScanJobEvent.job_id == job_id).all()
    events.sort(key=lambda event: event.created_at)
    return events


def update_job(job_id: int, **changes: Any) -> ScanJob:
    storage = _job_storage()
    with storage.session() as session:
        job = session.query(ScanJob).filter(ScanJob.id == job_id).first()
        if job is None:
            raise KeyError(f"job not found: {job_id}")
        now = _now()
        for key, value in changes.items():
            if hasattr(job, key):
                setattr(job, key, value)
        job.updated_at = now
        if "heartbeat_at" not in changes and job.status in {"claimed", "running"}:
            job.heartbeat_at = now
        if (
            "claimed_at" not in changes
            and job.status == "claimed"
            and getattr(job, "claimed_at", None) is None
        ):
            job.claimed_at = now
        session.update(job)
        session.commit()
        session.refresh(job)
        return job


def heartbeat_job(job_id: int, worker_id: str | None = None) -> ScanJob:
    current = get_job(job_id)
    if current is None:
        raise KeyError(f"job not found: {job_id}")
    worker = worker_id or current.claimed_by or _worker_id()
    changes: dict[str, Any] = {"heartbeat_at": _now()}
    if not current.claimed_by:
        changes["claimed_by"] = worker
    if current.status in {"claimed", "running"} and current.claimed_at is None:
        changes["claimed_at"] = _now()
    return update_job(job_id, **changes)


def cancel_job(job_id: int) -> ScanJob:
    current = get_job(job_id)
    if current is None:
        raise KeyError(f"job not found: {job_id}")
    if current.status in _TERMINAL_STATUSES:
        return current
    job = update_job(job_id, cancel_requested=True, status="cancel_requested")
    add_job_event(
        job_id,
        kind="cancel_requested",
        source=job.current_source or job.module,
        status=job.status,
        message="Cancellation requested",
        progress=job.progress,
    )
    return job


def resume_job(job_id: int) -> ScanJob:
    current = get_job(job_id)
    if current is None:
        raise KeyError(f"job not found: {job_id}")
    job = update_job(
        job_id,
        status="queued",
        cancel_requested=False,
        resume=True,
        error="",
        claimed_by="",
        claimed_at=None,
        heartbeat_at=None,
        finished_at=None,
    )
    add_job_event(
        job_id,
        kind="resume_requested",
        source=job.module,
        status="queued",
        message="Job queued for resumable run",
        progress=job.progress,
    )
    return job


def _run_module(module: str, case_name: str, target: str) -> dict:
    from .case import UsernameCase
    from .case_domain import DomainCase
    from .case_email import EmailCase
    from .case_extra import CompanyCase, IPCase, PhoneCase, URLCase, WalletCase
    from .case_metadata import MetadataCase

    runners = {
        "username": lambda: UsernameCase(case_name, target).run(),
        "email": lambda: EmailCase(case_name, target).run(),
        "domain": lambda: DomainCase(case_name, target, resolve_subs=False).run(),
        "metadata": lambda: MetadataCase(case_name, target).run(),
        "ip": lambda: IPCase(case_name, target).run(),
        "url": lambda: URLCase(case_name, target).run(),
        "phone": lambda: PhoneCase(case_name, target).run(),
        "wallet": lambda: WalletCase(case_name, target).run(),
        "company": lambda: CompanyCase(case_name, target).run(),
    }
    if module not in runners:
        raise KeyError(f"unknown module: {module}")
    return runners[module]()


async def _scan_username_site_async(
    username: str, source_name: str, site: dict[str, Any]
) -> SiteResult | None:
    sem = asyncio.Semaphore(1)
    limits = httpx.Limits(max_connections=1)
    policy = _username_job_http_policy()
    async with httpx.AsyncClient(
        follow_redirects=True,
        timeout=policy.timeout,
        headers={"User-Agent": policy.user_agent},
        limits=limits,
    ) as client:
        return await scan_site(client, source_name, site, username, sem, policy=policy)


def _scan_username_site(
    username: str, source_name: str, site: dict[str, Any]
) -> SiteResult | None:
    return asyncio.run(_scan_username_site_async(username, source_name, site))


def _persist_username_results(
    case_name: str, username: str, results: list[SiteResult]
) -> dict[str, Any]:
    from .case import UsernameCase

    return UsernameCase(case_name, username)._persist(results)


def _pipeline_source_ids(input_type: str) -> list[str]:
    from .source_pipeline import pipeline_sources

    return pipeline_sources(input_type)


def _run_pipeline_source(source_id: str, target: str, input_type: str):
    from ..catalog import run_source

    return run_source(source_id, target, input_type=input_type)


def _persist_pipeline_job_results(
    *,
    case_name: str,
    target: str,
    input_type: str,
    sources: list[str],
    results: list[Any],
) -> dict[str, Any]:
    from .source_pipeline import PipelineResult, persist_pipeline_result

    pipeline = PipelineResult(target=target, input_type=input_type, sources=sources)
    for result in results:
        result_dict = result.as_dict() if hasattr(result, "as_dict") else dict(result)
        pipeline.results.append(result_dict)
        normalized = result_dict.get("normalized") or {}
        pipeline.normalized.append(normalized)
    persisted = persist_pipeline_result(pipeline, case_name=case_name)
    return {"meta": persisted["meta"], "counts": persisted["counts"]}


def _pipeline_result_source_ids(results: list[Any]) -> list[str]:
    ids: list[str] = []
    for result in results:
        if hasattr(result, "source_id"):
            ids.append(str(result.source_id))
        elif isinstance(result, dict) and result.get("source_id"):
            ids.append(str(result["source_id"]))
    return ids


def _job_budget(job: ScanJob) -> dict[str, int]:
    try:
        parsed = parse_rate_limit_budget(job.rate_limit_budget_json)
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}
    return parsed


def _budget_remaining(budgets: dict[str, int], source: str) -> int | None:
    if source in budgets:
        return budgets[source]
    if "*" in budgets:
        return budgets["*"]
    return None


def _consume_budget(job_id: int, budgets: dict[str, int], source: str) -> int | None:
    remaining = _budget_remaining(budgets, source)
    if remaining is None:
        return None
    if remaining <= 0:
        return 0
    budgets[source] = remaining - 1
    update_job(
        job_id,
        rate_limit_budget_json=json.dumps(budgets, ensure_ascii=False, sort_keys=True),
    )
    return budgets[source]


def _completed_source_names(job_id: int) -> set[str]:
    completed: set[str] = set()
    for event in list_job_events(job_id):
        if event.kind in {"source_finished", "source_skipped"}:
            completed.add(event.source)
    return completed


def _progress(completed: int, total: int) -> float:
    if total <= 0:
        return 1.0
    return min(1.0, max(0.0, completed / total))


def _stale_reference_time(job: ScanJob) -> datetime | None:
    return _as_datetime(getattr(job, "heartbeat_at", None)) or _as_datetime(job.updated_at)


def _is_stale_active_job(job: ScanJob, cutoff: datetime) -> bool:
    if job.status not in {"claimed", "running"}:
        return False
    reference = _stale_reference_time(job)
    if reference is None:
        return True
    return reference <= cutoff


def recover_stale_jobs(*, stale_after_seconds: float = 300.0) -> dict[str, Any]:
    threshold = max(0.0, float(stale_after_seconds))
    cutoff = _now() - timedelta(seconds=threshold)
    recovered: list[dict[str, Any]] = []
    for job in list_jobs(1000):
        if job.id is None or not _is_stale_active_job(job, cutoff):
            continue
        previous_status = job.status
        previous_source = job.current_source or job.claimed_by or job.module
        previous_worker = job.claimed_by
        updated = update_job(
            job.id,
            status="queued",
            current_source="",
            claimed_by="",
            claimed_at=None,
            heartbeat_at=None,
            resume=True,
        )
        add_job_event(
            job.id,
            kind="requeued_stale",
            source=previous_source,
            status="queued",
            message=(
                f"Recovered stale {previous_status} job"
                + (f" from {previous_worker}" if previous_worker else "")
            ),
            progress=updated.progress,
        )
        recovered.append(
            {
                "job": job.id,
                "previous_status": previous_status,
                "previous_worker": previous_worker,
            }
        )
    return {"requeued": len(recovered), "jobs": recovered}


def _mark_cancelled(job: ScanJob, progress: float) -> dict[str, Any]:
    if job.id is None:
        raise KeyError("job has no id")
    update_job(
        job.id,
        status="cancelled",
        current_source="",
        progress=progress,
        finished_at=_now(),
    )
    add_job_event(
        job.id,
        kind="cancelled",
        source=job.current_source or job.module,
        status="cancelled",
        message="Job cancelled",
        progress=progress,
    )
    return {"job": job.id, "status": "cancelled"}


def _mark_failed(job: ScanJob, error: str) -> dict[str, Any]:
    if job.id is None:
        raise KeyError("job has no id")
    failed = update_job(
        job.id,
        status="failed",
        current_source="",
        error=error,
        finished_at=_now(),
    )
    add_job_event(
        job.id,
        kind="failed",
        source=job.current_source or job.module,
        status="failed",
        message=error,
        progress=failed.progress,
    )
    return {"job": job.id, "status": "failed", "error": error}


def _run_with_heartbeat(
    job_id: int,
    *,
    source: str,
    progress_floor: float,
    progress_ceiling: float,
    func,
):
    stop = threading.Event()

    def pulse() -> None:
        while not stop.wait(_heartbeat_interval()):
            current = get_job(job_id)
            if current is None or current.status in _TERMINAL_STATUSES:
                return
            if current.cancel_requested:
                heartbeat_job(job_id)
                return
            next_progress = min(
                progress_ceiling,
                max(float(current.progress or 0.0) + 0.02, progress_floor),
            )
            update_job(
                job_id,
                status="running",
                current_source=source,
                progress=next_progress,
            )
            heartbeat_job(job_id)

    thread = threading.Thread(
        target=pulse,
        daemon=True,
        name=f"bedniiosint-heartbeat-{job_id}",
    )
    thread.start()
    try:
        return func()
    finally:
        stop.set()
        thread.join(timeout=1.0)


def _emit_source_skipped(
    job_id: int,
    *,
    source: str,
    completed: int,
    total: int,
    status: str,
    message: str,
    budget_remaining: int | None = None,
) -> None:
    progress = _progress(completed, total)
    update_job(
        job_id,
        completed_sources=completed,
        current_source="",
        progress=progress,
    )
    heartbeat_job(job_id)
    add_job_event(
        job_id,
        kind="source_skipped",
        source=source,
        status=status,
        message=message,
        progress=progress,
        budget_remaining=budget_remaining,
    )


def _run_username_job(
    job: ScanJob,
    *,
    max_retries: int,
    resume: bool,
    budgets: dict[str, int],
) -> dict[str, Any]:
    if job.id is None:
        raise KeyError("job has no id")
    sites = load_sites(DEFAULT_SITES_FILE)
    total = len(sites)
    completed_names = _completed_source_names(job.id) if resume else set()
    completed = len(completed_names)
    results: list[SiteResult] = []
    failures: list[str] = []
    workers = _username_job_workers(max(1, total - completed))

    update_job(
        job.id,
        total_sources=total,
        completed_sources=completed,
        progress=_progress(completed, total),
    )
    heartbeat_job(job.id)

    pending_items = [
        (source_name, site)
        for source_name, site in sites.items()
        if source_name not in completed_names
    ]
    item_index = 0
    futures: dict[Future, tuple[str, dict[str, Any], int]] = {}
    executor = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="bedniiosint-username")
    executor_shutdown = False

    def submit_next() -> bool:
        nonlocal item_index, completed
        while item_index < len(pending_items):
            source_name, site = pending_items[item_index]
            item_index += 1

            fresh = get_job(job.id)
            if fresh is None:
                raise KeyError(f"job not found: {job.id}")
            if fresh.cancel_requested:
                return False

            remaining = _budget_remaining(budgets, source_name)
            if remaining is not None and remaining <= 0:
                completed += 1
                _emit_source_skipped(
                    job.id,
                    source=source_name,
                    completed=completed,
                    total=total,
                    status="rate_limited",
                    message="Source skipped because rate-limit budget is exhausted",
                    budget_remaining=0,
                )
                continue

            budget_after_attempt = _consume_budget(job.id, budgets, source_name)
            progress = _progress(completed, total)
            update_job(
                job.id,
                status="running",
                current_source=f"{len(futures) + 1} active username checks",
                progress=progress,
            )
            heartbeat_job(job.id)
            add_job_event(
                job.id,
                kind="source_started",
                source=source_name,
                status="running",
                message="Source attempt 1 started",
                progress=progress,
                attempt=1,
                budget_remaining=budget_after_attempt,
            )
            future = executor.submit(_scan_username_site, job.target, source_name, site)
            futures[future] = (source_name, site, 1)
            return True
        return False

    try:
        while len(futures) < workers and submit_next():
            pass

        while futures:
            done, _ = wait(set(futures), timeout=1.0, return_when=FIRST_COMPLETED)
            if not done:
                heartbeat_job(job.id)
                fresh = get_job(job.id)
                if fresh is not None and fresh.cancel_requested:
                    if results:
                        _persist_username_results(job.case_name, job.target, results)
                    executor.shutdown(wait=False, cancel_futures=True)
                    executor_shutdown = True
                    return _mark_cancelled(fresh, _progress(completed, total))
                continue

            for future in done:
                source_name, site, attempt = futures.pop(future)
                fresh = get_job(job.id)
                if fresh is None:
                    raise KeyError(f"job not found: {job.id}")

                try:
                    result = future.result()
                except Exception as exc:
                    if attempt <= max_retries:
                        remaining = _budget_remaining(budgets, source_name)
                        if remaining is not None and remaining <= 0:
                            completed += 1
                            _emit_source_skipped(
                                job.id,
                                source=source_name,
                                completed=completed,
                                total=total,
                                status="rate_limited",
                                message="Source skipped because rate-limit budget is exhausted",
                                budget_remaining=0,
                            )
                        else:
                            add_job_event(
                                job.id,
                                kind="retry",
                                source=source_name,
                                status="queued",
                                message=str(exc),
                                progress=_progress(completed, total),
                                attempt=attempt,
                                budget_remaining=_budget_remaining(budgets, source_name),
                            )
                            budget_after_attempt = _consume_budget(job.id, budgets, source_name)
                            next_attempt = attempt + 1
                            add_job_event(
                                job.id,
                                kind="source_started",
                                source=source_name,
                                status="running",
                                message=f"Source attempt {next_attempt} started",
                                progress=_progress(completed, total),
                                attempt=next_attempt,
                                budget_remaining=budget_after_attempt,
                            )
                            retry_future = executor.submit(
                                _scan_username_site,
                                job.target,
                                source_name,
                                site,
                            )
                            futures[retry_future] = (source_name, site, next_attempt)
                    else:
                        failures.append(f"{source_name}: {exc}")
                        completed += 1
                        progress = _progress(completed, total)
                        update_job(
                            job.id,
                            completed_sources=completed,
                            current_source="",
                            progress=progress,
                        )
                        heartbeat_job(job.id)
                        add_job_event(
                            job.id,
                            kind="source_failed",
                            source=source_name,
                            status="failed",
                            message=str(exc),
                            progress=progress,
                            attempt=attempt,
                            budget_remaining=_budget_remaining(budgets, source_name),
                        )
                else:
                    completed += 1
                    if result is None:
                        _emit_source_skipped(
                            job.id,
                            source=source_name,
                            completed=completed,
                            total=total,
                            status="skipped",
                            message="Source skipped by selector validation",
                            budget_remaining=_budget_remaining(budgets, source_name),
                        )
                    else:
                        results.append(result)
                        progress = _progress(completed, total)
                        update_job(
                            job.id,
                            completed_sources=completed,
                            current_source="",
                            progress=progress,
                        )
                        heartbeat_job(job.id)
                        add_job_event(
                            job.id,
                            kind="source_finished",
                            source=source_name,
                            status="finished",
                            message=f"Source finished with status {result.status}",
                            progress=progress,
                            attempt=attempt,
                            budget_remaining=_budget_remaining(budgets, source_name),
                        )

                fresh = get_job(job.id)
                if fresh is not None and fresh.cancel_requested:
                    persisted = (
                        _persist_username_results(job.case_name, job.target, results)
                        if results
                        else {}
                    )
                    executor.shutdown(wait=False, cancel_futures=True)
                    executor_shutdown = True
                    cancelled = _mark_cancelled(fresh, _progress(completed, total))
                    cancelled["result"] = persisted
                    return cancelled

                while len(futures) < workers and submit_next():
                    pass
    finally:
        if not executor_shutdown:
            executor.shutdown(wait=True)

    persisted: dict[str, Any] = {"meta": {"case": job.case_name, "username": job.target}}
    if results:
        persisted = _persist_username_results(job.case_name, job.target, results)

    error = "; ".join(failures[:5])
    if len(failures) > 5:
        error += f"; +{len(failures) - 5} more"
    update_job(
        job.id,
        status="finished",
        completed_sources=total,
        current_source="",
        progress=1.0,
        error=error,
        finished_at=_now(),
    )
    add_job_event(
        job.id,
        kind="finished",
        source=job.module,
        status="finished",
        message="Job finished" if not failures else f"Job finished with {len(failures)} source errors",
        progress=1.0,
    )
    return {"job": job.id, "status": "finished", "result": persisted}


def _run_pipeline_job(
    job: ScanJob,
    *,
    max_retries: int,
    resume: bool,
    budgets: dict[str, int],
) -> dict[str, Any]:
    if job.id is None:
        raise KeyError("job has no id")
    input_type = _pipeline_input_type(job.module, job.target)
    sources = _pipeline_source_ids(input_type)
    total = len(sources)
    completed_names = _completed_source_names(job.id) if resume else set()
    completed = len([source for source in sources if source in completed_names])
    results: list[Any] = []
    failures: list[str] = []

    update_job(
        job.id,
        total_sources=total,
        completed_sources=completed,
        progress=_progress(completed, total),
    )
    heartbeat_job(job.id)

    for source_id in sources:
        if source_id in completed_names:
            continue

        fresh = get_job(job.id)
        if fresh is None:
            raise KeyError(f"job not found: {job.id}")
        if fresh.cancel_requested:
            persisted = (
                _persist_pipeline_job_results(
                    case_name=job.case_name,
                    target=job.target,
                    input_type=input_type,
                    sources=_pipeline_result_source_ids(results),
                    results=results,
                )
                if results
                else {}
            )
            cancelled = _mark_cancelled(fresh, _progress(completed, total))
            cancelled["result"] = persisted
            return cancelled

        remaining = _budget_remaining(budgets, source_id)
        if remaining is not None and remaining <= 0:
            completed += 1
            _emit_source_skipped(
                job.id,
                source=source_id,
                completed=completed,
                total=total,
                status="rate_limited",
                message="Source skipped because rate-limit budget is exhausted",
                budget_remaining=0,
            )
            continue

        update_job(
            job.id,
            status="running",
            current_source=source_id,
            progress=_progress(completed, total),
        )
        heartbeat_job(job.id)

        attempt = 1
        while True:
            fresh = get_job(job.id)
            if fresh is None:
                raise KeyError(f"job not found: {job.id}")
            if fresh.cancel_requested:
                persisted = (
                    _persist_pipeline_job_results(
                        case_name=job.case_name,
                        target=job.target,
                        input_type=input_type,
                        sources=_pipeline_result_source_ids(results),
                        results=results,
                    )
                    if results
                    else {}
                )
                cancelled = _mark_cancelled(fresh, _progress(completed, total))
                cancelled["result"] = persisted
                return cancelled

            remaining = _budget_remaining(budgets, source_id)
            if remaining is not None and remaining <= 0:
                completed += 1
                _emit_source_skipped(
                    job.id,
                    source=source_id,
                    completed=completed,
                    total=total,
                    status="rate_limited",
                    message="Source skipped because rate-limit budget is exhausted",
                    budget_remaining=0,
                )
                break

            budget_after_attempt = _consume_budget(job.id, budgets, source_id)
            add_job_event(
                job.id,
                kind="source_started",
                source=source_id,
                status="running",
                message=f"Pipeline source attempt {attempt} started",
                progress=_progress(completed, total),
                attempt=attempt,
                budget_remaining=budget_after_attempt,
            )
            try:
                result = _run_with_heartbeat(
                    job.id,
                    source=source_id,
                    progress_floor=max(_progress(completed, total), 0.02),
                    progress_ceiling=min(0.98, _progress(completed + 1, total)),
                    func=lambda: _run_pipeline_source(source_id, job.target, input_type),
                )
            except Exception as exc:
                if attempt <= max_retries:
                    add_job_event(
                        job.id,
                        kind="retry",
                        source=source_id,
                        status="queued",
                        message=str(exc),
                        progress=_progress(completed, total),
                        attempt=attempt,
                        budget_remaining=_budget_remaining(budgets, source_id),
                    )
                    heartbeat_job(job.id)
                    attempt += 1
                    continue
                failures.append(f"{source_id}: {exc}")
                completed += 1
                progress = _progress(completed, total)
                update_job(
                    job.id,
                    completed_sources=completed,
                    current_source="",
                    progress=progress,
                )
                heartbeat_job(job.id)
                add_job_event(
                    job.id,
                    kind="source_failed",
                    source=source_id,
                    status="failed",
                    message=str(exc),
                    progress=progress,
                    attempt=attempt,
                    budget_remaining=_budget_remaining(budgets, source_id),
                )
                break

            results.append(result)
            completed += 1
            progress = _progress(completed, total)
            update_job(
                job.id,
                completed_sources=completed,
                current_source="",
                progress=progress,
            )
            heartbeat_job(job.id)
            status = getattr(result, "status", "finished")
            add_job_event(
                job.id,
                kind="source_finished",
                source=source_id,
                status=str(status),
                message=f"Pipeline source finished with status {status}",
                progress=progress,
                attempt=attempt,
                budget_remaining=_budget_remaining(budgets, source_id),
            )
            fresh = get_job(job.id)
            if fresh is not None and fresh.cancel_requested:
                persisted = _persist_pipeline_job_results(
                    case_name=job.case_name,
                    target=job.target,
                    input_type=input_type,
                    sources=_pipeline_result_source_ids(results),
                    results=results,
                )
                cancelled = _mark_cancelled(fresh, progress)
                cancelled["result"] = persisted
                return cancelled
            break

    persisted: dict[str, Any] = {}
    if results:
        persisted = _persist_pipeline_job_results(
            case_name=job.case_name,
            target=job.target,
            input_type=input_type,
            sources=_pipeline_result_source_ids(results),
            results=results,
        )

    error = "; ".join(failures[:5])
    if len(failures) > 5:
        error += f"; +{len(failures) - 5} more"
    update_job(
        job.id,
        status="finished",
        completed_sources=total,
        current_source="",
        progress=1.0,
        error=error,
        finished_at=_now(),
    )
    add_job_event(
        job.id,
        kind="finished",
        source=job.module,
        status="finished",
        message="Pipeline job finished"
        if not failures
        else f"Pipeline job finished with {len(failures)} source errors",
        progress=1.0,
    )
    return {"job": job.id, "status": "finished", "result": persisted}


def _run_investigate_job(
    job: ScanJob,
    *,
    budgets: dict[str, int],
) -> dict[str, Any]:
    if job.id is None:
        raise KeyError("job has no id")
    input_type = _investigate_input_type(job.module, job.target)
    from ..search.auto_pivot import run_recursive_investigation
    from ..search.live_events import WaveEmitter
    from .source_context import SourceRunContext

    def emit_live_event(event: dict[str, Any]) -> None:
        current = get_job(job.id)
        add_job_event(
            job.id,
            kind=str(event.get("kind") or "event"),
            source=str(event.get("source_id") or "investigate"),
            status="running",
            message=str(event.get("title") or event.get("value") or event.get("kind") or "event"),
            progress=float(getattr(current, "progress", 0.0) or 0.0),
        )

    emitter = WaveEmitter(emit=emit_live_event, job_id=job.id)

    total = max(1, int(settings.autopivot_max_nodes))
    update_job(
        job.id,
        status="running",
        total_sources=total,
        completed_sources=0,
        current_source="investigate",
        progress=0.05,
    )
    heartbeat_job(job.id)
    add_job_event(
        job.id,
        kind="investigation_planned",
        source="investigate",
        status="running",
        message=f"Deep investigation planned up to {total} graph node(s)",
        progress=0.05,
    )
    fresh = get_job(job.id)
    if fresh is None:
        raise KeyError(f"job not found: {job.id}")
    if fresh.cancel_requested:
        return _mark_cancelled(fresh, fresh.progress)

    try:
        result = _run_with_heartbeat(
            job.id,
            source="investigate",
            progress_floor=0.08,
            progress_ceiling=0.95,
            func=lambda: run_recursive_investigation(
                job.target,
                entity_type=input_type,
                save=True,
                case_name=job.case_name,
                concurrent=True,
                max_workers=_search_job_workers(),
                include_dorking=True,
                include_username_scan=True,
                emitter=emitter,
                context=SourceRunContext(
                    scope="public_osint",
                    request_budget=budgets,
                    cache_enabled=True,
                    cache_ttl_seconds=3600,
                    cache_ttl_by_source=merge_cache_ttl_presets(),
                ),
            ),
        )
    except Exception as exc:
        current = get_job(job.id) or fresh
        if current.cancel_requested:
            return _mark_cancelled(current, current.progress)
        return _mark_failed(current, str(exc))

    completed_sources = int(result.get("node_count") or total)
    update_job(
        job.id,
        status="finished",
        completed_sources=min(total, max(1, completed_sources)),
        current_source="",
        progress=1.0,
        error="",
        finished_at=_now(),
    )
    add_job_event(
        job.id,
        kind="finished",
        source=job.module,
        status="finished",
        message=(
            "Deep investigation job finished: "
            f"{result.get('node_count', 0)} node(s), "
            f"{result.get('result_count', 0)} result(s), "
            f"{len(result.get('correlations') or [])} correlation(s)"
        ),
        progress=1.0,
    )
    return {"job": job.id, "status": "finished", "result": result}


def _run_search_job(
    job: ScanJob,
    *,
    budgets: dict[str, int],
) -> dict[str, Any]:
    if job.id is None:
        raise KeyError("job has no id")
    input_type = _search_input_type(job.module, job.target)
    from ..search.planner import plan_search
    from ..search.pipeline import run_planned_search_pipeline
    from .source_context import SourceRunContext

    plan = plan_search(
        job.target,
        entity_type=input_type,
        include_auth_required=True,
    )
    total = len(plan.sources)
    update_job(
        job.id,
        status="running",
        total_sources=total,
        completed_sources=0,
        current_source="search",
        progress=0.05,
    )
    heartbeat_job(job.id)
    add_job_event(
        job.id,
        kind="search_planned",
        source="search",
        status="running",
        message=f"Unified search planned {total} search source groups",
        progress=0.05,
    )
    fresh = get_job(job.id)
    if fresh is None:
        raise KeyError(f"job not found: {job.id}")
    if fresh.cancel_requested:
        return _mark_cancelled(fresh, fresh.progress)

    try:
        result = _run_with_heartbeat(
            job.id,
            source="search",
            progress_floor=0.08,
            progress_ceiling=0.95,
            func=lambda: run_planned_search_pipeline(
                job.target,
                entity_type=input_type,
                include_auth_required=True,
                available_only=True,
                save=True,
                case_name=job.case_name,
                context=SourceRunContext(
                    scope="public_osint",
                    request_budget=budgets,
                    cache_enabled=True,
                    cache_ttl_seconds=3600,
                    cache_ttl_by_source=merge_cache_ttl_presets(),
                ),
                search_plan=plan,
                concurrent=True,
                max_workers=_search_job_workers(),
                include_dorking=True,
            ),
        )
    except Exception as exc:
        if fresh.cancel_requested:
            return _mark_cancelled(fresh, fresh.progress)
        return _mark_failed(fresh, str(exc))

    completed_sources = int(result.get("counts", {}).get("search_sources") or total)
    update_job(
        job.id,
        status="finished",
        completed_sources=completed_sources,
        current_source="",
        progress=1.0,
        error="",
        finished_at=_now(),
    )
    add_job_event(
        job.id,
        kind="finished",
        source=job.module,
        status="finished",
        message=(
            "Unified search job finished: "
            f"{result.get('counts', {}).get('search_results', 0)} result(s), "
            f"{result.get('dedup_summary', {}).get('clusters', 0)} cluster(s)"
        ),
        progress=1.0,
    )
    return {"job": job.id, "status": "finished", "result": result}


def _run_single_module_job(
    job: ScanJob,
    *,
    max_retries: int,
    resume: bool,
    budgets: dict[str, int],
    raise_on_error: bool,
) -> dict[str, Any]:
    if job.id is None:
        raise KeyError("job has no id")
    source = job.module
    total = 1
    completed_names = _completed_source_names(job.id) if resume else set()
    if source in completed_names:
        update_job(
            job.id,
            status="finished",
            total_sources=1,
            completed_sources=1,
            current_source="",
            progress=1.0,
            finished_at=_now(),
        )
        add_job_event(
            job.id,
            kind="finished",
            source=source,
            status="finished",
            message="Job already complete; resumed without rerun",
            progress=1.0,
        )
        return {"job": job.id, "status": "finished", "result": None}

    remaining = _budget_remaining(budgets, source)
    if remaining is not None and remaining <= 0:
        _emit_source_skipped(
            job.id,
            source=source,
            completed=1,
            total=1,
            status="rate_limited",
            message="Source skipped because rate-limit budget is exhausted",
            budget_remaining=0,
        )
        update_job(
            job.id,
            status="finished",
            total_sources=1,
            completed_sources=1,
            current_source="",
            progress=1.0,
            finished_at=_now(),
        )
        add_job_event(
            job.id,
            kind="finished",
            source=source,
            status="finished",
            message="Job finished with source skipped by rate-limit budget",
            progress=1.0,
        )
        return {"job": job.id, "status": "finished", "result": None}

    update_job(
        job.id,
        status="running",
        total_sources=1,
        completed_sources=0,
        current_source=source,
        progress=0.0,
    )
    heartbeat_job(job.id)

    attempt = 1
    while True:
        fresh = get_job(job.id)
        if fresh is None:
            raise KeyError(f"job not found: {job.id}")
        if fresh.cancel_requested:
            return _mark_cancelled(fresh, fresh.progress)

        remaining = _budget_remaining(budgets, source)
        if remaining is not None and remaining <= 0:
            _emit_source_skipped(
                job.id,
                source=source,
                completed=1,
                total=1,
                status="rate_limited",
                message="Source skipped because rate-limit budget is exhausted",
                budget_remaining=0,
            )
            update_job(
                job.id,
                status="finished",
                completed_sources=1,
                current_source="",
                progress=1.0,
                finished_at=_now(),
            )
            add_job_event(
                job.id,
                kind="finished",
                source=source,
                status="finished",
                message="Job finished with source skipped by rate-limit budget",
                progress=1.0,
            )
            return {"job": job.id, "status": "finished", "result": None}

        budget_after_attempt = _consume_budget(job.id, budgets, source)
        add_job_event(
            job.id,
            kind="source_started",
            source=source,
            status="running",
            message=f"Source attempt {attempt} started",
            progress=0.0,
            attempt=attempt,
            budget_remaining=budget_after_attempt,
        )
        try:
            previous_timeout = socket.getdefaulttimeout()
            socket.setdefaulttimeout(_single_module_socket_timeout())
            try:
                result = _run_with_heartbeat(
                    job.id,
                    source=source,
                    progress_floor=0.05,
                    progress_ceiling=0.9,
                    func=lambda: _run_module(source, job.case_name, job.target),
                )
            finally:
                socket.setdefaulttimeout(previous_timeout)
        except Exception as exc:
            if attempt <= max_retries:
                add_job_event(
                    job.id,
                    kind="retry",
                    source=source,
                    status="queued",
                    message=str(exc),
                    progress=0.0,
                    attempt=attempt,
                    budget_remaining=_budget_remaining(budgets, source),
                )
                heartbeat_job(job.id)
                attempt += 1
                continue
            heartbeat_job(job.id)
            update_job(
                job.id,
                status="failed",
                error=str(exc),
                completed_sources=0,
                current_source="",
                progress=0.0,
                finished_at=_now(),
            )
            add_job_event(
                job.id,
                kind="source_failed",
                source=source,
                status="failed",
                message=str(exc),
                progress=0.0,
                attempt=attempt,
                budget_remaining=_budget_remaining(budgets, source),
            )
            add_job_event(
                job.id,
                kind="failed",
                source=source,
                status="failed",
                message=str(exc),
                progress=0.0,
            )
            if raise_on_error:
                raise
            return {"job": job.id, "status": "failed", "error": str(exc)}

        heartbeat_job(job.id)
        update_job(
            job.id,
            status="finished",
            completed_sources=1,
            current_source="",
            progress=1.0,
            error="",
            finished_at=_now(),
        )
        add_job_event(
            job.id,
            kind="source_finished",
            source=source,
            status="finished",
            message="Source finished",
            progress=1.0,
            attempt=attempt,
            budget_remaining=_budget_remaining(budgets, source),
        )
        add_job_event(
            job.id,
            kind="finished",
            source=source,
            status="finished",
            message="Job finished",
            progress=1.0,
        )
        return {"job": job.id, "status": "finished", "result": result}


def run_job(
    job_id: int,
    *,
    max_retries: int | None = None,
    resume: bool | None = None,
    raise_on_error: bool = True,
    worker_id: str | None = None,
) -> dict[str, Any]:
    job = get_job(job_id)
    if job is None or job.id is None:
        raise KeyError(f"job not found: {job_id}")
    runner_id = worker_id or job.claimed_by or _worker_id()
    resumable = job.resume if resume is None else resume
    if job.status in _TERMINAL_STATUSES and not resumable:
        return {"job": job.id, "status": job.status}
    if job.status == "running" and not resumable:
        return {"job": job.id, "status": "running"}
    if job.cancel_requested and not resumable:
        return _mark_cancelled(job, job.progress)
    if resumable and job.cancel_requested:
        job = update_job(job_id, cancel_requested=False, status="queued", error="")

    retry_value = job.max_retries if max_retries is None else max_retries
    effective_retries = max(0, int(1 if retry_value is None else retry_value))
    budgets = _job_budget(job)
    update_job(
        job_id,
        status="running",
        current_source=job.module,
        claimed_by=runner_id,
        claimed_at=job.claimed_at or _now(),
        heartbeat_at=_now(),
        progress=max(job.progress, 0.01),
    )
    add_job_event(
        job_id,
        kind="started",
        source=job.module,
        status="running",
        message="Job started" if not resumable else "Resumable job started",
        progress=max(job.progress, 0.01),
    )

    if job.module == "username":
        return _run_username_job(
            job,
            max_retries=effective_retries,
            resume=resumable,
            budgets=budgets,
        )
    if _is_pipeline_module(job.module):
        return _run_pipeline_job(
            job,
            max_retries=effective_retries,
            resume=resumable,
            budgets=budgets,
        )
    if _is_investigate_module(job.module):
        return _run_investigate_job(
            job,
            budgets=budgets,
        )
    if _is_search_module(job.module):
        return _run_search_job(
            job,
            budgets=budgets,
        )
    return _run_single_module_job(
        job,
        max_retries=effective_retries,
        resume=resumable,
        budgets=budgets,
        raise_on_error=raise_on_error,
    )


def _next_queued_job() -> ScanJob | None:
    with _job_storage().session() as session:
        jobs = [
            job
            for job in session.query(ScanJob).all()
            if job.status == "queued" and not job.cancel_requested
        ]
    jobs.sort(key=lambda job: job.created_at)
    return jobs[0] if jobs else None


def _claim_next_queued_job(worker_id: str | None = None) -> ScanJob | None:
    worker = worker_id or _worker_id()
    with _WORKER_LOCK:
        job = _next_queued_job()
        if job is None or job.id is None:
            return None
        now = _now()
        claimed = update_job(
            job.id,
            status="claimed",
            current_source="worker",
            claimed_by=worker,
            claimed_at=now,
            heartbeat_at=now,
            progress=max(job.progress, 0.001),
        )
        add_job_event(
            job.id,
            kind="claimed",
            source=worker,
            status="claimed",
            message="Job claimed by worker",
            progress=claimed.progress,
        )
        return claimed


def run_worker_once(
    *,
    recover_stale: bool = True,
    stale_after_seconds: float = 300.0,
    worker_id: str | None = None,
) -> dict[str, Any] | None:
    worker = worker_id or _worker_id()
    recovered = (
        recover_stale_jobs(stale_after_seconds=stale_after_seconds)
        if recover_stale
        else {"requeued": 0}
    )
    job = _claim_next_queued_job(worker)
    if job is None or job.id is None:
        with _WORKER_LOCK:
            _WORKER_STATE["worker_id"] = worker
            _WORKER_STATE["last_recovered_stale"] = recovered.get("requeued", 0)
            _WORKER_STATE["stale_after_seconds"] = float(stale_after_seconds)
        return None
    with _WORKER_LOCK:
        _WORKER_STATE["worker_id"] = worker
        _WORKER_STATE["last_job_id"] = job.id
        _WORKER_STATE["last_error"] = ""
        _WORKER_STATE["last_recovered_stale"] = recovered.get("requeued", 0)
        _WORKER_STATE["stale_after_seconds"] = float(stale_after_seconds)
    try:
        result = run_job(job.id, raise_on_error=False, worker_id=worker)
    except Exception as exc:
        try:
            current = get_job(job.id) or job
            result = _mark_failed(current, str(exc))
        except Exception:
            result = {"job": job.id, "status": "failed", "error": str(exc)}
        with _WORKER_LOCK:
            _WORKER_STATE["last_error"] = str(exc)
    with _WORKER_LOCK:
        _WORKER_STATE["jobs_run"] = int(_WORKER_STATE["jobs_run"]) + 1
    return result


def _worker_loop(
    poll_interval: float,
    stale_after_seconds: float,
    worker_id: str,
) -> None:
    while not _WORKER_STOP.is_set():
        ran = run_worker_once(
            stale_after_seconds=stale_after_seconds,
            worker_id=worker_id,
        )
        if ran is None:
            _WORKER_STOP.wait(poll_interval)


def start_worker(
    poll_interval: float = 1.0,
    *,
    stale_after_seconds: float = 300.0,
) -> dict[str, Any]:
    global _WORKER_THREAD
    with _WORKER_LOCK:
        if _WORKER_THREAD is not None and _WORKER_THREAD.is_alive():
            already_running = True
        else:
            already_running = False
    if already_running:
        return worker_status()
    worker = _worker_id()
    with _WORKER_LOCK:
        _WORKER_STOP.clear()
        _WORKER_STATE["running"] = True
        _WORKER_STATE["started_at"] = _now().isoformat()
        _WORKER_STATE["worker_id"] = worker
        _WORKER_STATE["stale_after_seconds"] = float(stale_after_seconds)
        _WORKER_THREAD = threading.Thread(
            target=_worker_loop,
            args=(
                max(0.05, float(poll_interval)),
                max(0.0, float(stale_after_seconds)),
                worker,
            ),
            daemon=True,
            name="bedniiosint-job-worker",
        )
        _WORKER_THREAD.start()
    return worker_status()


def stop_worker(timeout: float = 2.0) -> dict[str, Any]:
    global _WORKER_THREAD
    _WORKER_STOP.set()
    thread = _WORKER_THREAD
    if thread is not None and thread.is_alive():
        thread.join(timeout=timeout)
    with _WORKER_LOCK:
        _WORKER_STATE["running"] = bool(thread is not None and thread.is_alive())
        if not _WORKER_STATE["running"]:
            _WORKER_THREAD = None
    return worker_status()


def worker_status(*, stale_after_seconds: float | None = None) -> dict[str, Any]:
    thread_alive = _WORKER_THREAD is not None and _WORKER_THREAD.is_alive()
    with _WORKER_LOCK:
        status = dict(_WORKER_STATE)
    threshold = (
        float(stale_after_seconds)
        if stale_after_seconds is not None
        else float(status.get("stale_after_seconds", 300.0) or 300.0)
    )
    jobs = list_jobs(1000)
    status_counts: dict[str, int] = {}
    cutoff = _now() - timedelta(seconds=max(0.0, threshold))
    stale_active = 0
    for job in jobs:
        status_counts[job.status] = status_counts.get(job.status, 0) + 1
        if _is_stale_active_job(job, cutoff):
            stale_active += 1
    active_statuses = {"queued", "claimed", "running", "cancel_requested"}
    queued = status_counts.get("queued", 0)
    claimed = status_counts.get("claimed", 0)
    active = sum(count for status, count in status_counts.items() if status in active_statuses)
    status["running"] = thread_alive
    status["queued"] = queued
    status["claimed"] = claimed
    status["stale_active"] = stale_active
    status["worker_id"] = status.get("worker_id") or _worker_id()
    status["stale_after_seconds"] = threshold
    status["active"] = active
    status["status_counts"] = status_counts
    status["polling"] = not _WORKER_STOP.is_set() and thread_alive
    return status


def wait_for_worker_idle(timeout: float = 10.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not worker_status().get("active"):
            return True
        time.sleep(0.05)
    return not worker_status().get("active")


def job_as_dict(job: ScanJob) -> dict[str, Any]:
    data = job.as_dict()
    defaults = {
        "max_retries": 1,
        "rate_limit_budget_json": "{}",
        "resume": False,
    }
    for key, value in defaults.items():
        if data.get(key) is None:
            data[key] = value
    for key, value in list(data.items()):
        if hasattr(value, "isoformat"):
            data[key] = value.isoformat()
    return data


def job_event_as_dict(event: ScanJobEvent) -> dict[str, Any]:
    data = event.as_dict()
    for key, value in list(data.items()):
        if hasattr(value, "isoformat"):
            data[key] = value.isoformat()
    return data
