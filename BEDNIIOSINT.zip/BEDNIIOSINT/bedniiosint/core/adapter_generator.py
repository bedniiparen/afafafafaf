from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..catalog.adapters import auth_env_vars
from ..catalog.source_catalog import load_catalog


def _slug(value: str) -> str:
    text = value.strip().lower().replace("api:", "")
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in text)
    return "_".join(part for part in safe.split("_") if part) or "adapter"


def _env_vars(source_id: str, auth: str) -> list[str]:
    return auth_env_vars(source_id, auth)


def _find_api(source_id: str, catalog: dict[str, Any] | None = None) -> dict[str, Any]:
    source_id = source_id.replace("api:", "").strip().lower()
    data = catalog or load_catalog()
    for api in data.get("api_sources", []):
        if str(api.get("id", "")).lower() == source_id:
            return api
    raise KeyError(f"catalog API source not found: {source_id}")


def scaffold_adapter(
    source_id: str,
    out_dir: Path,
    *,
    catalog: dict[str, Any] | None = None,
    force: bool = False,
) -> dict[str, Path]:
    api = _find_api(source_id, catalog)
    slug = _slug(api["id"])
    root = out_dir / slug
    if root.exists() and not force:
        raise FileExistsError(f"adapter already exists: {root}")
    root.mkdir(parents=True, exist_ok=True)

    endpoints = api.get("endpoints", [])
    base_url = str(api.get("base_url", "")).rstrip("/")
    first = endpoints[0] if endpoints else {"method": "GET", "path": ""}
    method = first.get("method", "GET")
    path = first.get("path", "")
    inputs = list(api.get("inputs", []))
    produces = list(api.get("category", [])) or inputs
    auth = api.get("auth", "none")
    env_vars = _env_vars(api["id"], auth)
    manifest = {
        "name": slug,
        "version": "0.1.0",
        "description": f"Generated adapter scaffold for {api.get('name', api['id'])}.",
        "source_id": api["id"],
        "consumes": inputs,
        "produces": produces,
        "entrypoint": "adapter:run",
        "auth": auth,
        "env_vars": env_vars,
    }

    adapter_py = f'''from __future__ import annotations

import os
from typing import Any

import httpx

from bedniiosint.core.http import request


SOURCE_ID = "{api["id"]}"
BASE_URL = "{base_url}"
METHOD = "{method}"
PATH_TEMPLATE = "{path}"
ENDPOINTS = {endpoints!r}
INPUT_TYPES = {inputs!r}
OUTPUT_TYPES = {produces!r}
AUTH = "{auth}"
ENV_VARS = {env_vars!r}
CONTRACT_VERSION = "0.2"


def schema() -> dict:
    return {{
        "source_id": SOURCE_ID,
        "contract_version": CONTRACT_VERSION,
        "adapter": "generated-catalog-http",
        "input_schema": {{
            "target": {{"type": "string", "required": True}},
            "input_types": INPUT_TYPES,
            "auth": AUTH,
            "env_vars": ENV_VARS,
        }},
        "output_schema": {{
            "status": "ok|error|missing_keys",
            "status_code": "integer|null",
            "url": "string",
            "headers": "dict",
            "json": "json|null",
            "text": "string",
        }},
        "normalized_schema": {{
            "entities": "list[{{type,value}}]",
            "relations": "list[{{src_type,src_value,rel,dst_type,dst_value}}]",
            "findings": "list[{{source_id,entity_type,entity_value,status,confidence}}]",
            "timeline": "list[{{kind,entity_type,entity_value,source,confidence}}]",
            "raw": "adapter result",
        }},
    }}


def _required_auth_missing() -> list[str]:
    optional_auth = AUTH in {{"none", "", "optional", "none_or_api_key", "api_key_or_community", "optional_api_key", "optional_api_token", "optional_token"}}
    missing = [name for name in ENV_VARS if not os.getenv(name)]
    return [] if optional_auth else missing


def _format_fields(template: str) -> set[str]:
    import string

    return {{
        field_name
        for _, field_name, _, _ in string.Formatter().parse(template)
        if field_name
    }}


def _select_endpoint(input_type: str) -> dict:
    endpoints = ENDPOINTS or [{{"method": METHOD, "path": PATH_TEMPLATE}}]
    for endpoint in endpoints:
        if input_type in _format_fields(str(endpoint.get("path", ""))):
            return endpoint
    if SOURCE_ID == "osintly_api":
        for endpoint in endpoints:
            if str(endpoint.get("path", "")).rstrip("/") == "/search":
                return endpoint
    for endpoint in endpoints:
        fields = _format_fields(str(endpoint.get("path", "")))
        if "query" in fields or "q" in fields:
            return endpoint
    for endpoint in endpoints:
        if str(endpoint.get("method", "GET")).upper() in {{"POST", "PUT", "PATCH"}}:
            return endpoint
    return endpoints[0]


def _auth_values(api_key: str | None = None) -> tuple[str, str]:
    values = [os.getenv(name, "") for name in ENV_VARS]
    key = api_key or next((value for value in values if value), "")
    secret = values[1] if len(values) > 1 else ""
    return key, secret


def _format_path(path_template: str, target: str, input_type: str, api_key: str | None = None, **kwargs: Any) -> str:
    auth_key, secret = _auth_values(api_key)
    instance = kwargs.get("instance", "")
    if not instance and "@" in target and not target.startswith("@"):
        instance = target.rsplit("@", 1)[-1]
    values = {{"target": target, "query": target, "q": target, "sparql": kwargs.get("sparql", target), "address": target, "place": target, "instance": instance, **kwargs}}
    for field in INPUT_TYPES:
        values.setdefault(field, target)
    values.update({{
        input_type: target,
        "api_key": auth_key,
        "api_token": auth_key,
        "access_key": auth_key,
        "token": auth_key,
        "api_secret": secret,
        "secret": secret,
    }})
    return path_template.format(**values)


def _auth_request_kwargs(api_key: str | None = None) -> dict:
    key, secret = _auth_values(api_key)
    if not key:
        return {{}}
    headers: dict[str, str] = {{}}
    params: dict[str, str] = {{}}
    request_kwargs: dict[str, Any] = {{}}
    if SOURCE_ID == "securitytrails":
        headers["APIKEY"] = key
    elif SOURCE_ID == "virustotal":
        headers["x-apikey"] = key
    elif SOURCE_ID == "abuseipdb":
        headers["Key"] = key
        headers["Accept"] = "application/json"
    elif SOURCE_ID == "alienvault_otx":
        headers["X-OTX-API-KEY"] = key
    elif SOURCE_ID == "greynoise":
        headers["key"] = key
    elif SOURCE_ID == "hibp":
        headers["hibp-api-key"] = key
    elif SOURCE_ID == "emailrep":
        headers["Key"] = key
    elif SOURCE_ID == "urlscan":
        headers["API-Key"] = key
    elif SOURCE_ID == "ipinfo":
        params["token"] = key
    elif SOURCE_ID == "github" or AUTH in {{"bearer_token", "optional_token"}}:
        headers["Authorization"] = f"Bearer {{key}}"
    elif SOURCE_ID == "companies_house":
        request_kwargs["auth"] = (key, "")
    elif AUTH == "api_key_secret":
        request_kwargs["auth"] = (key, secret)
    elif AUTH in {{"api_key", "optional_api_key", "none_or_api_key", "api_key_or_community"}}:
        params["api_key"] = key
    elif AUTH == "optional_api_token":
        params["api_token"] = key
    elif AUTH == "api_key_or_account":
        headers["Authorization"] = f"Bearer {{key}}"
    if headers:
        request_kwargs["headers"] = headers
    if params:
        request_kwargs["params"] = params
    return request_kwargs


def _post_request_kwargs(method: str, input_type: str, target: str, kwargs: dict[str, Any]) -> dict:
    if method.upper() not in {{"POST", "PUT", "PATCH"}}:
        return {{}}
    if any(key in kwargs for key in ("json", "data", "content")):
        return {{key: kwargs[key] for key in ("json", "data", "content") if key in kwargs}}
    if SOURCE_ID == "urlhaus":
        field = "url" if input_type == "url" else "host"
        return {{"data": {{field: target}}}}
    if SOURCE_ID == "urlscan":
        return {{"json": {{"url": target, "visibility": kwargs.get("visibility", "unlisted")}}}}
    if SOURCE_ID == "osintly_api":
        return {{"json": {{"target": target, "type": input_type}}}}
    return {{"data": {{input_type: target}}}}


def _merge_request_kwargs(*items: dict) -> dict:
    merged: dict[str, Any] = {{}}
    for item in items:
        for key, value in item.items():
            if key in {{"headers", "params"}} and key in merged and isinstance(value, dict):
                merged[key] = {{**merged[key], **value}}
            else:
                merged[key] = value
    return merged


def run(target: str, *, input_type: str | None = None, api_key: str | None = None, timeout: float = 20.0, **kwargs: Any) -> dict:
    missing = _required_auth_missing()
    if missing:
        return {{"source": SOURCE_ID, "target": target, "status": "missing_keys", "missing_env": missing}}
    selected = input_type or (INPUT_TYPES[0] if INPUT_TYPES else "target")
    endpoint = _select_endpoint(selected)
    method = str(endpoint.get("method", METHOD)).upper()
    path_template = str(endpoint.get("path", PATH_TEMPLATE))
    path = _format_path(path_template, target, selected, api_key=api_key, **kwargs)
    url = path if path.startswith("http://") or path.startswith("https://") else BASE_URL + path
    headers = {{"User-Agent": "BEDNIIOSINT"}}
    request_kwargs = _merge_request_kwargs(
        _auth_request_kwargs(api_key),
        _post_request_kwargs(method, selected, target, kwargs),
    )
    with httpx.Client(timeout=timeout, headers=headers) as client:
        response = request(method, url, client=client, **request_kwargs)
    return {{
        "source": SOURCE_ID,
        "target": target,
        "input_type": selected,
        "method": method,
        "status": "ok" if response.status_code < 400 else "error",
        "url": str(response.url),
        "status_code": response.status_code,
        "headers": dict(response.headers),
        "json": response.json() if response.headers.get("content-type", "").startswith("application/json") else None,
        "text": response.text if not response.headers.get("content-type", "").startswith("application/json") else "",
    }}


def parse(raw: dict, target: str) -> dict:
    data = raw.get("json") if isinstance(raw.get("json"), (dict, list)) else raw.get("text", "")
    input_type = raw.get("input_type") or (INPUT_TYPES[0] if INPUT_TYPES else "target")
    status_code = raw.get("status_code")
    ok = raw.get("status") == "ok" or (status_code is not None and int(status_code) < 400)
    entities = [
        {{"type": input_type, "value": target}},
        {{"type": "source", "value": SOURCE_ID}},
    ]
    relations = [
        {{
            "src_type": input_type,
            "src_value": target,
            "rel": "queried_in",
            "dst_type": "source",
            "dst_value": SOURCE_ID,
        }}
    ]
    findings = [
        {{
            "source_id": SOURCE_ID,
            "entity_type": input_type,
            "entity_value": target,
            "finding_type": "adapter_result",
            "profile_url": raw.get("url", ""),
            "status": "exists" if ok else raw.get("status", "error"),
            "status_code": status_code,
            "confidence": 0.75 if ok else 0.0,
            "reject_reason": "" if raw.get("status") in {{"ok", None}} else raw.get("status", ""),
        }}
    ]
    timeline = [
        {{
            "kind": "adapter_observed",
            "entity_type": input_type,
            "entity_value": target,
            "source": SOURCE_ID,
            "confidence": findings[0]["confidence"],
            "description": f"{{SOURCE_ID}} returned adapter data",
        }}
    ]
    return {{"entities": entities, "relations": relations, "findings": findings, "timeline": timeline, "raw": data}}


def health_check(target: str = "example.com", **kwargs: Any) -> dict:
    missing = _required_auth_missing()
    if missing:
        return {{"source_id": SOURCE_ID, "status": "missing_keys", "status_code": None, "error": "", "missing_env": missing}}
    try:
        raw = run(target, **kwargs)
        status_code = raw.get("status_code")
        ok = status_code is not None and int(status_code) < 500
        return {{
            "source_id": SOURCE_ID,
            "status": "available" if ok else "error",
            "status_code": status_code,
            "error": "" if ok else f"HTTP {{status_code}}",
            "missing_env": raw.get("missing_env", []),
        }}
    except Exception as exc:
        return {{"source_id": SOURCE_ID, "status": "error", "status_code": None, "error": str(exc), "missing_env": []}}
'''

    readme = f"""# {slug}

Generated BEDNIIOSINT adapter scaffold for `{api.get("name", api["id"])}`.

- Source ID: `{api["id"]}`
- Auth: `{api.get("auth", "none")}`
- Base URL: `{base_url}`
- First endpoint: `{method} {path}`

Review auth handling, `parse()` entity extraction and `health_check()` probes before enabling this adapter in production.
"""

    files = {
        "manifest": root / "plugin.json",
        "adapter": root / "adapter.py",
        "readme": root / "README.md",
    }
    files["manifest"].write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    files["adapter"].write_text(adapter_py, encoding="utf-8")
    files["readme"].write_text(readme, encoding="utf-8")
    return files
