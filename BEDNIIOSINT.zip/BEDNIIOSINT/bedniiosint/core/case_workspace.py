from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config import settings
from ..evidence.bundle import inspect_evidence_bundle
from ..evidence.hashing import sha256_file
from ..evidence.manifest import evidence_manifest
from ..graph.builder import build_graph, graph_metrics
from ..graph.export import to_cytoscape
from ..reports.manifest import verify_report_manifest
from ..storage.models import (
    AnalystNote,
    Attachment,
    Case,
    Entity,
    Evidence,
    Finding,
    Relation,
    Source,
    TimelineEvent,
)
from ..storage.sqlite import Storage
from ..web.presenters import (
    build_case_presentation,
    build_case_workspace_model,
    build_finding_display,
    finding_is_unverified_generated_profile_url,
    infer_case_entity_type,
)
from .case_lookup import case_ids
from .entity_resolution import resolve_entities
from .timeline import get_timeline


@dataclass
class WorkspaceFilters:
    entity_type: str = ""
    source: str = ""
    status: str = ""
    min_confidence: float | None = None
    since: str = ""
    until: str = ""
    kind: str = ""


def _case_storage(case_name: str) -> tuple[Storage, list[int]]:
    storage = Storage(settings.db_path(case_name))
    ids = case_ids(storage, case_name)
    if not ids:
        raise KeyError(f"case not found: {case_name}")
    return storage, ids


def _row(obj) -> dict[str, Any]:
    data = obj.as_dict() if hasattr(obj, "as_dict") else dict(obj)
    for key, value in list(data.items()):
        if hasattr(value, "isoformat"):
            data[key] = value.isoformat()
    return data


def _loads(value: str | None) -> Any:
    if not value:
        return {}
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return value


def _match_date(value: str | None, *, since: str = "", until: str = "") -> bool:
    if not value:
        return True
    if since and value < since:
        return False
    if until and value > until:
        return False
    return True


def _finding_matches(row: dict[str, Any], filters: WorkspaceFilters) -> bool:
    if filters.entity_type and row.get("entity_type") not in {"", filters.entity_type}:
        return False
    if filters.source:
        source_id = str(row.get("source_id") or "")
        source_name = str(row.get("source_name") or "")
        if filters.source not in {source_id, source_name}:
            return False
    if filters.status and row.get("status") != filters.status:
        return False
    if filters.min_confidence is not None:
        try:
            if float(row.get("confidence") or 0.0) < filters.min_confidence:
                return False
        except (TypeError, ValueError):
            return False
    captured = str(row.get("captured_at") or row.get("last_seen") or "")
    return _match_date(captured, since=filters.since, until=filters.until)


def _timeline_matches(row: dict[str, Any], filters: WorkspaceFilters) -> bool:
    if filters.kind and row.get("kind") != filters.kind:
        return False
    return _match_date(str(row.get("when") or ""), since=filters.since, until=filters.until)


def _source_health(source: dict[str, Any]) -> dict[str, Any]:
    success = int(source.get("success_count") or 0)
    errors = int(source.get("error_count") or 0)
    total = success + errors
    historical = success / total if total else None
    reliability = source.get("reliability")
    if historical is not None and reliability is not None:
        reliability = round((float(reliability) * 0.7) + (historical * 0.3), 3)
    return {
        "status": source.get("health_status") or "unknown",
        "checked_at": source.get("health_checked_at"),
        "last_error": source.get("last_error") or "",
        "success_count": success,
        "error_count": errors,
        "historical_success_rate": round(historical, 3) if historical is not None else None,
        "effective_reliability": reliability,
    }


def _reports_dir() -> Path:
    return settings.db_dir.parent / "reports_out"


def _bundle_integrity(bundle: Path) -> dict[str, Any]:
    if not bundle.exists() or not bundle.is_file():
        return {
            "valid": False,
            "exists": False,
            "bundle": str(bundle),
            "files": 0,
            "sha256_ok": 0,
            "errors": [f"evidence bundle not found: {bundle}"],
        }
    try:
        inspected = inspect_evidence_bundle(bundle)
    except (OSError, ValueError) as exc:
        return {
            "valid": False,
            "exists": True,
            "bundle": str(bundle),
            "files": 0,
            "sha256_ok": 0,
            "errors": [f"evidence bundle inspection failed: {exc}"],
        }
    errors = []
    for row in inspected.get("files") or []:
        if not row.get("present"):
            errors.append(f"bundle member missing: {row.get('archive_path')}")
        if row.get("sha256_ok") is False:
            errors.append(f"bundle member SHA-256 mismatch: {row.get('archive_path')}")
    return {
        "valid": not errors,
        "exists": True,
        "bundle": str(bundle),
        "files": len(inspected.get("files") or []),
        "sha256_ok": sum(1 for row in inspected.get("files") or [] if row.get("sha256_ok")),
        "errors": errors,
    }


def _vault_artifact_integrity(manifest: dict[str, Any]) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for section, role in (("evidence", "evidence"), ("attachments", "attachment")):
        for item in manifest.get(section) or []:
            if not isinstance(item, dict):
                continue
            artifact = item.get("artifact") if isinstance(item.get("artifact"), dict) else {}
            path_value = str((artifact or {}).get("path") or item.get("artifact_path") or item.get("path") or "")
            if not path_value:
                continue
            if path_value in seen:
                continue
            seen.add(path_value)
            path = Path(path_value)
            expected_sha256 = str(item.get("sha256") or "")
            exists = path.exists() and path.is_file()
            actual_sha256 = sha256_file(path) if exists else ""
            rows.append(
                {
                    "role": role,
                    "id": item.get("id"),
                    "path": path_value,
                    "exists": exists,
                    "covered": bool(expected_sha256),
                    "sha256_ok": exists and bool(expected_sha256) and actual_sha256 == expected_sha256,
                    "expected_sha256": expected_sha256,
                    "actual_sha256": actual_sha256,
                }
            )
    return {
        "files": len(rows),
        "existing": sum(1 for row in rows if row["exists"]),
        "covered": sum(1 for row in rows if row["covered"]),
        "sha256_ok": sum(1 for row in rows if row["sha256_ok"]),
        "items": rows,
    }


def _workspace_integrity(case_name: str, manifest: dict[str, Any]) -> dict[str, Any]:
    root = _reports_dir()
    report = verify_report_manifest(root / "reports-manifest.json", case_name=case_name)
    report_summary = {
        "valid": report.get("valid") is True,
        "manifest_path": report.get("manifest_path", ""),
        "reports_dir": report.get("reports_dir", ""),
        "files": int((report.get("summary") or {}).get("files") or 0),
        "present": int((report.get("summary") or {}).get("present") or 0),
        "sha256_ok": int((report.get("summary") or {}).get("sha256_ok") or 0),
        "errors": list(report.get("errors") or []),
    }
    vault = _vault_artifact_integrity(manifest)
    bundle = _bundle_integrity(root / f"{case_name}-evidence-bundle.zip")
    return {
        "secrets_returned": False,
        "reports": report_summary,
        "evidence_vault": vault,
        "evidence_bundle": bundle,
    }


def _display_graph_from_presentation(
    *,
    target: str,
    entity_type: str,
    findings: list[dict[str, Any]],
) -> dict[str, Any]:
    target_type = entity_type or "target"
    target_id = f"{target_type}:{target}"
    nodes_by_id: dict[str, dict[str, Any]] = {
        target_id: {"data": {"id": target_id, "label": target, "type": target_type}}
    }
    edges: list[dict[str, Any]] = []
    seen_edges: set[tuple[str, str, str]] = set()
    for row in findings:
        display = row.get("display") if isinstance(row.get("display"), dict) else {}
        value = str(display.get("display_entity_value") or row.get("entity_value") or row.get("profile_url") or "").strip()
        kind = str(display.get("display_entity_type") or row.get("entity_type") or "unknown").strip() or "unknown"
        if not value or value == target:
            continue
        node_id = f"{kind}:{value}"
        nodes_by_id.setdefault(
            node_id,
            {"data": {"id": node_id, "label": value, "type": kind}},
        )
        label = "profile_candidate" if display.get("profile_candidate") else "observed"
        edge_key = (target_id, node_id, label)
        if edge_key in seen_edges:
            continue
        seen_edges.add(edge_key)
        edges.append(
            {
                "data": {
                    "source": target_id,
                    "target": node_id,
                    "label": label,
                    "confidence": row.get("confidence") or 0,
                    "evidence_count": row.get("evidence_count") or 0,
                    "source_id": row.get("source_id") or row.get("source_name") or "",
                }
            }
        )
    return {
        "metrics": {"nodes": len(nodes_by_id), "edges": len(edges)},
        "nodes": list(nodes_by_id.values()),
        "edges": edges,
    }


def get_workspace(
    case_name: str,
    *,
    filters: WorkspaceFilters | None = None,
) -> dict[str, Any]:
    filters = filters or WorkspaceFilters()
    storage, ids = _case_storage(case_name)
    findings: list[dict[str, Any]] = []
    entities: list[dict[str, Any]] = []
    relations: list[dict[str, Any]] = []
    evidence: list[dict[str, Any]] = []
    attachments: list[dict[str, Any]] = []
    sources: list[dict[str, Any]] = []
    notes: list[dict[str, Any]] = []
    timeline_rows: list[dict[str, Any]] = []
    case_rows: list[dict[str, Any]] = []

    with storage.session() as session:
        for cid in ids:
            case = session.query(Case).filter(Case.id == cid).first()
            if case is not None:
                case_rows.append(_row(case))
            findings.extend(_row(row) for row in session.query(Finding).filter(Finding.case_id == cid).all())
            entities.extend(_row(row) for row in session.query(Entity).filter(Entity.case_id == cid).all())
            relations.extend(_row(row) for row in session.query(Relation).filter(Relation.case_id == cid).all())
            evidence.extend(_row(row) for row in session.query(Evidence).filter(Evidence.case_id == cid).all())
            attachments.extend(_row(row) for row in session.query(Attachment).filter(Attachment.case_id == cid).all())
            sources.extend(_row(row) for row in session.query(Source).filter(Source.case_id == cid).all())
            notes.extend(_row(row) for row in session.query(AnalystNote).filter(AnalystNote.case_id == cid).all())
            timeline_rows.extend(_row(row) for row in session.query(TimelineEvent).filter(TimelineEvent.case_id == cid).all())

    filtered_findings = [row for row in findings if _finding_matches(row, filters)]
    filtered_timeline = [
        row for row in get_timeline(storage, ids) if _timeline_matches(row, filters)
    ]
    finding_ids = {row.get("id") for row in filtered_findings}
    evidence_by_finding: dict[int, list[dict[str, Any]]] = {}
    attachment_by_finding: dict[int, list[dict[str, Any]]] = {}
    for row in evidence:
        row["headers"] = _loads(row.get("headers_json"))
        row["query_params"] = _loads(row.get("query_params_json"))
        finding_id = row.get("finding_id")
        if finding_id in finding_ids:
            evidence_by_finding.setdefault(finding_id, []).append(row)
    for row in attachments:
        row["metadata"] = _loads(row.get("metadata_json"))
        finding_id = row.get("finding_id")
        if finding_id in finding_ids:
            attachment_by_finding.setdefault(finding_id, []).append(row)

    for row in filtered_findings:
        finding_id = row.get("id")
        row["evidence_count"] = len(evidence_by_finding.get(finding_id, []))
        row["attachment_count"] = len(attachment_by_finding.get(finding_id, []))

    graph = build_graph(storage, ids)
    cytoscape = to_cytoscape(graph).get("elements", {})
    source_rows = []
    for source in sources:
        enriched = dict(source)
        enriched["health"] = _source_health(source)
        source_rows.append(enriched)

    manifest = evidence_manifest(storage, ids)
    target = case_rows[-1].get("target") if case_rows else case_name
    module = case_rows[-1].get("module") if case_rows else ""
    workspace = {
        "meta": {
            "case": case_name,
            "found": True,
            "case_ids": ids,
            "runs": case_rows,
            "target": target,
            "module": module,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "filters": filters.__dict__,
        },
        "counts": {
            "findings": len(filtered_findings),
            "entities": len(entities),
            "relations": len(relations),
            "evidence": len(evidence),
            "attachments": len(attachments),
            "sources": len(sources),
            "timeline": len(filtered_timeline),
            "notes": len(notes),
        },
        "findings": sorted(
            filtered_findings,
            key=lambda row: float(row.get("confidence") or 0.0),
            reverse=True,
        ),
        "entities": entities,
        "entity_resolution": resolve_entities(
            entities,
            relations,
            findings=filtered_findings,
            evidence=evidence,
        ),
        "relations": relations,
        "sources": source_rows,
        "timeline": filtered_timeline,
        "evidence": evidence,
        "attachments": attachments,
        "notes": notes,
        "evidence_by_finding": evidence_by_finding,
        "attachments_by_finding": attachment_by_finding,
        "graph": {
            "metrics": graph_metrics(graph),
            "nodes": cytoscape.get("nodes", []),
            "edges": cytoscape.get("edges", []),
        },
        "manifest": manifest,
        "integrity": _workspace_integrity(case_name, manifest),
    }
    presentation = build_case_presentation(
        {
            "case": case_name,
            "target": target,
            "module": module,
            "runs": case_rows,
            "entity_type": infer_case_entity_type(
                {"case": case_name, "module": module, "target": target}
            ),
            "last_updated": case_rows[-1].get("created_at") if case_rows else "",
            "findings": filtered_findings,
            "entities": entities,
            "relations": relations,
            "sources": source_rows,
            "timeline": filtered_timeline,
            "evidence": evidence,
            "attachments": attachments,
            "evidence_by_finding": evidence_by_finding,
            "attachments_by_finding": attachment_by_finding,
        }
    )
    workspace["presentation"] = presentation
    generated_url_candidates = [
        row for row in presentation["findings"] if finding_is_unverified_generated_profile_url(row)
    ]
    display_findings = [
        row for row in presentation["findings"] if not finding_is_unverified_generated_profile_url(row)
    ]
    workspace["findings"] = sorted(
        display_findings,
        key=lambda row: float(row.get("confidence") or 0.0),
        reverse=True,
    )
    workspace["generated_url_candidates"] = sorted(
        generated_url_candidates,
        key=lambda row: str(row.get("source_id") or row.get("profile_url") or row.get("entity_value") or ""),
    )
    workspace["review_only_search_leads"] = sorted(
        presentation.get("review_only_search_leads") or [],
        key=lambda row: str(row.get("source_id") or row.get("profile_url") or row.get("entity_value") or ""),
    )
    workspace["rejected_findings"] = sorted(
        presentation.get("rejected_findings") or [],
        key=lambda row: float(row.get("confidence") or 0.0),
        reverse=True,
    )
    workspace["counts"]["findings"] = len(workspace["findings"])
    workspace["counts"]["rejected_findings"] = len(workspace["rejected_findings"])
    workspace["counts"]["review_only_search_leads"] = len(workspace["review_only_search_leads"])
    workspace["counts"]["generated_url_candidates"] = len(workspace["generated_url_candidates"])
    workspace["counts"]["all_findings"] = len(filtered_findings)
    workspace["raw_graph_metrics"] = workspace["graph"]["metrics"]
    workspace["graph"] = _display_graph_from_presentation(
        target=target,
        entity_type=presentation["summary"].get("entity_type") or "target",
        findings=workspace["findings"],
    )
    workspace["workspace_model"] = build_case_workspace_model(workspace)
    workspace["tables"] = workspace["workspace_model"]["tables"]
    return workspace


def get_finding_detail(case_name: str, finding_id: int) -> dict[str, Any]:
    storage, ids = _case_storage(case_name)
    with storage.session() as session:
        finding = session.query(Finding).filter(Finding.id == finding_id).first()
        if finding is None or finding.case_id not in ids:
            raise KeyError(f"finding not found: {finding_id}")
        finding_row = _row(finding)
        evidence = [
            _row(row)
            for row in session.query(Evidence).filter(Evidence.finding_id == finding_id).all()
        ]
        attachments = [
            _row(row)
            for row in session.query(Attachment).filter(Attachment.finding_id == finding_id).all()
        ]
    for row in evidence:
        row["headers"] = _loads(row.get("headers_json"))
        row["query_params"] = _loads(row.get("query_params_json"))
    for row in attachments:
        row["metadata"] = _loads(row.get("metadata_json"))
        path = Path(str(row.get("path") or ""))
        if path.exists() and path.is_file() and path.stat().st_size <= 200_000:
            try:
                row["preview"] = path.read_text(encoding="utf-8", errors="replace")[:5000]
            except OSError:
                row["preview"] = ""
        else:
            row["preview"] = ""
    finding_row["display"] = build_finding_display(
        finding_row,
        evidence,
        attachments=attachments,
        independent_sources=1,
        target=finding_row.get("entity_value") or "",
    )
    finding_row["verdict"] = finding_row["display"]["verdict"]
    finding_row["display_entity_type"] = finding_row["display"]["display_entity_type"]
    finding_row["display_entity_value"] = finding_row["display"]["display_entity_value"]
    finding_row["what_found"] = finding_row["display"]["what_found"]
    finding_row["why_it_matters"] = finding_row["display"]["why_it_matters"]
    finding_row["confidence_explanation"] = finding_row["display"]["confidence_explanation"]
    finding_row["weaknesses"] = finding_row["display"]["weaknesses"]
    finding_row["recommended_actions"] = finding_row["display"]["recommended_actions"]
    return {
        "finding": finding_row,
        "evidence": evidence,
        "attachments": attachments,
    }


def add_note(
    case_name: str,
    *,
    entity_type: str,
    entity_value: str,
    note: str,
) -> dict[str, Any]:
    storage, ids = _case_storage(case_name)
    with storage.session() as session:
        item = AnalystNote(
            case_id=ids[-1],
            entity_type=entity_type,
            entity_value=entity_value,
            note=note,
        )
        session.add(item)
        session.commit()
        session.refresh(item)
        return _row(item)


def _clean(value: str) -> str:
    return value.strip()


def _ensure_entity(session, case_id: int, entity_type: str, entity_value: str) -> Entity:
    entity = (
        session.query(Entity)
        .filter(Entity.case_id == case_id)
        .filter(Entity.type == entity_type)
        .filter(Entity.value == entity_value)
        .first()
    )
    if entity is not None:
        return entity
    entity = Entity(case_id=case_id, type=entity_type, value=entity_value)
    session.add(entity)
    session.commit()
    session.refresh(entity)
    return entity


def _dedupe_entities(session, case_ids_: list[int]) -> int:
    removed = 0
    seen: set[tuple[int, str, str]] = set()
    for cid in case_ids_:
        entities = session.query(Entity).filter(Entity.case_id == cid).all()
        for entity in entities:
            key = (entity.case_id, entity.type, entity.value)
            if key in seen:
                session.delete(entity)
                removed += 1
            else:
                seen.add(key)
    return removed


def _relation_for_case(session, ids: list[int], relation_id: int) -> Relation:
    relation = session.query(Relation).filter(Relation.id == relation_id).first()
    if relation is None or relation.case_id not in ids:
        raise KeyError(f"relation not found: {relation_id}")
    return relation


def _dedupe_relations(session, case_ids_: list[int]) -> int:
    removed = 0
    seen: set[tuple[int, str, str, str, str, str]] = set()
    for cid in case_ids_:
        relations = session.query(Relation).filter(Relation.case_id == cid).all()
        for relation in relations:
            key = (
                relation.case_id,
                relation.src_type,
                relation.src_value,
                relation.rel,
                relation.dst_type,
                relation.dst_value,
            )
            if key in seen:
                session.delete(relation)
                removed += 1
            else:
                seen.add(key)
    return removed


def _finding_key(finding: Finding) -> tuple[Any, ...]:
    return (
        finding.case_id,
        finding.source_id or finding.source_name,
        finding.source_name,
        finding.entity_type,
        finding.entity_value,
        finding.finding_type,
        finding.profile_url,
        finding.status,
    )


def _dedupe_findings(session, case_ids_: list[int]) -> int:
    removed = 0
    for cid in case_ids_:
        groups: dict[tuple[Any, ...], list[Finding]] = {}
        for finding in session.query(Finding).filter(Finding.case_id == cid).all():
            groups.setdefault(_finding_key(finding), []).append(finding)
        evidence_rows = session.query(Evidence).filter(Evidence.case_id == cid).all()
        attachment_rows = session.query(Attachment).filter(Attachment.case_id == cid).all()
        timeline_rows = session.query(TimelineEvent).filter(TimelineEvent.case_id == cid).all()
        for rows in groups.values():
            if len(rows) < 2:
                continue
            rows.sort(key=lambda item: (float(item.confidence or 0.0), -(item.id or 0)), reverse=True)
            keep = rows[0]
            for duplicate in rows[1:]:
                for evidence in evidence_rows:
                    if evidence.finding_id == duplicate.id:
                        evidence.finding_id = keep.id
                        session.update(evidence)
                for attachment in attachment_rows:
                    if attachment.finding_id == duplicate.id:
                        attachment.finding_id = keep.id
                        session.update(attachment)
                for event in timeline_rows:
                    if event.finding_id == duplicate.id:
                        event.finding_id = keep.id
                        session.update(event)
                session.delete(duplicate)
                removed += 1
    return removed


def add_manual_event(
    case_name: str,
    *,
    kind: str,
    entity_type: str,
    entity_value: str,
    when: datetime | None = None,
    confidence: float = 1.0,
    description: str = "",
) -> dict[str, Any]:
    storage, ids = _case_storage(case_name)
    with storage.session() as session:
        event = TimelineEvent(
            case_id=ids[-1],
            when=when,
            kind=kind,
            entity_type=entity_type,
            entity_value=entity_value,
            source_name="analyst",
            confidence=confidence,
            description=description,
        )
        session.add(event)
        session.commit()
        session.refresh(event)
        return _row(event)


def add_manual_relation(
    case_name: str,
    *,
    src_type: str,
    src_value: str,
    rel: str,
    dst_type: str,
    dst_value: str,
) -> dict[str, Any]:
    storage, ids = _case_storage(case_name)
    with storage.session() as session:
        relation = Relation(
            case_id=ids[-1],
            src_type=src_type,
            src_value=src_value,
            rel=rel,
            dst_type=dst_type,
            dst_value=dst_value,
        )
        session.add(relation)
        session.commit()
        session.refresh(relation)
        return _row(relation)


def update_manual_relation(
    case_name: str,
    relation_id: int,
    *,
    src_type: str,
    src_value: str,
    rel: str,
    dst_type: str,
    dst_value: str,
) -> dict[str, Any]:
    storage, ids = _case_storage(case_name)
    src_type = _clean(src_type)
    src_value = _clean(src_value)
    rel = _clean(rel)
    dst_type = _clean(dst_type)
    dst_value = _clean(dst_value)
    if not all([src_type, src_value, rel, dst_type, dst_value]):
        raise ValueError("relation fields are required")
    with storage.session() as session:
        relation = _relation_for_case(session, ids, relation_id)
        relation.src_type = src_type
        relation.src_value = src_value
        relation.rel = rel
        relation.dst_type = dst_type
        relation.dst_value = dst_value
        session.update(relation)
        _ensure_entity(session, relation.case_id, src_type, src_value)
        _ensure_entity(session, relation.case_id, dst_type, dst_value)
        session.commit()
        session.refresh(relation)
        return _row(relation)


def delete_manual_relation(case_name: str, relation_id: int) -> dict[str, Any]:
    storage, ids = _case_storage(case_name)
    with storage.session() as session:
        relation = _relation_for_case(session, ids, relation_id)
        row = _row(relation)
        session.delete(relation)
        session.commit()
    return {"deleted": True, "relation": row}


def dedupe_case(case_name: str) -> dict[str, Any]:
    storage, ids = _case_storage(case_name)
    with storage.session() as session:
        removed = {
            "entities": _dedupe_entities(session, ids),
            "relations": _dedupe_relations(session, ids),
            "findings": _dedupe_findings(session, ids),
        }
        session.commit()
    return {"deduped": True, "case": case_name, "removed": removed}


def merge_entities(
    case_name: str,
    *,
    from_type: str,
    from_value: str,
    into_type: str,
    into_value: str,
    note: str = "",
) -> dict[str, Any]:
    storage, ids = _case_storage(case_name)
    from_type = _clean(from_type)
    from_value = _clean(from_value)
    into_type = _clean(into_type)
    into_value = _clean(into_value)
    note = _clean(note)
    if not all([from_type, from_value, into_type, into_value]):
        raise ValueError("merge entity fields are required")
    if (from_type, from_value) == (into_type, into_value):
        raise ValueError("merge source and target must differ")

    changed = {
        "entities": 0,
        "relations": 0,
        "findings": 0,
        "timeline": 0,
        "notes": 0,
        "deduped_entities": 0,
    }
    with storage.session() as session:
        _ensure_entity(session, ids[-1], into_type, into_value)
        for cid in ids:
            for entity in session.query(Entity).filter(Entity.case_id == cid).all():
                if entity.type == from_type and entity.value == from_value:
                    entity.type = into_type
                    entity.value = into_value
                    session.update(entity)
                    changed["entities"] += 1
            for relation in session.query(Relation).filter(Relation.case_id == cid).all():
                touched = False
                if relation.src_type == from_type and relation.src_value == from_value:
                    relation.src_type = into_type
                    relation.src_value = into_value
                    touched = True
                if relation.dst_type == from_type and relation.dst_value == from_value:
                    relation.dst_type = into_type
                    relation.dst_value = into_value
                    touched = True
                if touched:
                    session.update(relation)
                    changed["relations"] += 1
            for finding in session.query(Finding).filter(Finding.case_id == cid).all():
                if finding.entity_type == from_type and finding.entity_value == from_value:
                    finding.entity_type = into_type
                    finding.entity_value = into_value
                    session.update(finding)
                    changed["findings"] += 1
            for event in session.query(TimelineEvent).filter(TimelineEvent.case_id == cid).all():
                if event.entity_type == from_type and event.entity_value == from_value:
                    event.entity_type = into_type
                    event.entity_value = into_value
                    session.update(event)
                    changed["timeline"] += 1
            for item in session.query(AnalystNote).filter(AnalystNote.case_id == cid).all():
                if item.entity_type == from_type and item.entity_value == from_value:
                    item.entity_type = into_type
                    item.entity_value = into_value
                    session.update(item)
                    changed["notes"] += 1

        if note:
            session.add(
                AnalystNote(
                    case_id=ids[-1],
                    entity_type=into_type,
                    entity_value=into_value,
                    note=note,
                )
            )
            changed["notes"] += 1
        changed["deduped_entities"] = _dedupe_entities(session, ids)
        session.commit()

    return {
        "merged": True,
        "from": {"type": from_type, "value": from_value},
        "into": {"type": into_type, "value": into_value},
        "changed": changed,
    }


def split_entity(
    case_name: str,
    *,
    entity_type: str,
    entity_value: str,
    new_type: str,
    new_value: str,
    rel: str = "split_from",
    note: str = "",
) -> dict[str, Any]:
    storage, ids = _case_storage(case_name)
    entity_type = _clean(entity_type)
    entity_value = _clean(entity_value)
    new_type = _clean(new_type)
    new_value = _clean(new_value)
    rel = _clean(rel) or "split_from"
    note = _clean(note)
    if not all([entity_type, entity_value, new_type, new_value]):
        raise ValueError("split entity fields are required")
    with storage.session() as session:
        original = _ensure_entity(session, ids[-1], entity_type, entity_value)
        created = _ensure_entity(session, ids[-1], new_type, new_value)
        relation = Relation(
            case_id=ids[-1],
            src_type=new_type,
            src_value=new_value,
            rel=rel,
            dst_type=entity_type,
            dst_value=entity_value,
        )
        session.add(relation)
        if note:
            session.add(
                AnalystNote(
                    case_id=ids[-1],
                    entity_type=new_type,
                    entity_value=new_value,
                    note=note,
                )
            )
        session.commit()
        session.refresh(relation)
        return {
            "split": True,
            "original": _row(original),
            "entity": _row(created),
            "relation": _row(relation),
        }
