from __future__ import annotations

import re


CYRILLIC_RE = re.compile(r"[А-Яа-яЁё]")
ALPHA_WORD_RE = re.compile(r"[^\W\d_]+", re.UNICODE)
LEGAL_ENTITY_MARKER_RE = re.compile(
    r"(?:^|\b)("
    r"incorporated|inc|llc|ltd|limited|corp|corporation|company|co|gmbh|sa|sas|sarl|plc|"
    r"ооо|оао|пао|зао|ао|ип|нко|фгуп|муп|тоо|тов|одоо|общество|компания"
    r")(?:\b|$)",
    re.IGNORECASE,
)

CYRILLIC_TRANSLIT = {
    "а": "a",
    "б": "b",
    "в": "v",
    "г": "g",
    "д": "d",
    "е": "e",
    "ё": "e",
    "ж": "zh",
    "з": "z",
    "и": "i",
    "й": "y",
    "к": "k",
    "л": "l",
    "м": "m",
    "н": "n",
    "о": "o",
    "п": "p",
    "р": "r",
    "с": "s",
    "т": "t",
    "у": "u",
    "ф": "f",
    "х": "h",
    "ц": "ts",
    "ч": "ch",
    "ш": "sh",
    "щ": "sch",
    "ъ": "",
    "ы": "y",
    "ь": "",
    "э": "e",
    "ю": "yu",
    "я": "ya",
}


def has_cyrillic(value: str) -> bool:
    return bool(CYRILLIC_RE.search(str(value or "")))


def has_legal_entity_marker(value: str) -> bool:
    return bool(LEGAL_ENTITY_MARKER_RE.search(str(value or "")))


def split_alpha_words(value: str) -> list[str]:
    return ALPHA_WORD_RE.findall(str(value or ""))


def transliterate_cyrillic(value: str) -> str:
    return "".join(CYRILLIC_TRANSLIT.get(char.lower(), char) for char in str(value or ""))


def ascii_slug(value: str, *, separator: str = "-") -> str:
    lowered = transliterate_cyrillic(value).lower()
    if separator:
        clean = re.sub(r"[^a-z0-9]+", separator, lowered).strip(separator)
        return re.sub(f"{re.escape(separator)}+", separator, clean)
    return re.sub(r"[^a-z0-9]+", "", lowered)


def is_probable_cyrillic_person_name(value: str) -> bool:
    text = str(value or "").strip()
    if not has_cyrillic(text) or has_legal_entity_marker(text):
        return False
    if any(char.isdigit() for char in text):
        return False
    words = split_alpha_words(text)
    return 2 <= len(words) <= 4 and all(len(word) >= 2 for word in words)
