from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from pathlib import Path

from ..config import DEFAULT_SITES_FILE, settings
from ..evidence.capture import EvidenceVault
from ..modules.url.analyzer import fetch_and_parse
from ..modules.username.false_positive import evaluate as fp_evaluate
from ..modules.username.scanner import SiteResult, load_sites, scan_username
from ..storage.models import (
    Case,
    Entity,
    Evidence,
    Finding,
    Relation,
    Source,
    TimelineEvent,
)
from ..storage.sqlite import Storage
from .artifacts import capture_raw_result


class UsernameCase:
    def __init__(
        self,
        case_name: str,
        username: str,
        sites_file: Path | None = None,
        *,
        categories: list[str] | None = None,
        names: list[str] | None = None,
        include_protected: bool = True,
        offset: int = 0,
        limit: int | None = None,
    ):
        self.case_name = case_name
        self.username = username
        self.sites_file = sites_file or DEFAULT_SITES_FILE
        self.categories = categories
        self.names = names
        self.include_protected = include_protected
        self.offset = offset
        self.limit = limit
        self.storage = Storage(settings.db_path(case_name))

    def run(self) -> dict:
        sites = load_sites(self.sites_file)
        results = asyncio.run(
            scan_username(
                self.username,
                sites,
                categories=self.categories,
                names=self.names,
                include_protected=self.include_protected,
                offset=self.offset,
                limit=self.limit,
            )
        )
        return self._persist(results)

    def _persist(self, results: list[SiteResult]) -> dict:
        with self.storage.session() as session:
            case = Case(name=self.case_name, target=self.username, module="username")
            session.add(case)
            session.commit()
            session.refresh(case)
            if case.id is None:
                raise RuntimeError("case was not persisted")

            session.add(Entity(case_id=case.id, type="username", value=self.username))
            summary: dict[str, list | dict] = {
                "high": [],
                "medium": [],
                "weak": [],
                "rejected": [],
                "sources": [],
            }
            vault = EvidenceVault(
                self.storage,
                case.id,
                settings.db_dir / f"{self.case_name}_vault",
            )

            for result in results:
                verdict = fp_evaluate(
                    status=result.status,
                    source_reliability=result.source_reliability,
                    min_reliability=settings.min_source_reliability,
                    control_passed=result.control_passed,
                )
                session.add(
                    Source(
                        case_id=case.id,
                        name=result.site_name,
                        url_main=result.url_main,
                        category=result.category,
                        reliability=result.source_reliability,
                        calibrated=True,
                        notes=result.reliability_note,
                    )
                )

                finding = Finding(
                    case_id=case.id,
                    source_name=result.site_name,
                    entity_value=self.username,
                    profile_url=result.display_url,
                    status=result.status,
                    status_code=result.status_code,
                    final_url=result.final_url,
                    redirected=result.redirected,
                    page_title=result.page_title,
                    matched_markers=",".join(result.matched_markers),
                    confidence=result.confidence,
                    rejected=verdict.rejected,
                    reject_reason=verdict.reason,
                )
                session.add(finding)
                session.commit()
                session.refresh(finding)
                if finding.id is None:
                    raise RuntimeError("finding was not persisted")

                session.add(
                    Evidence(
                        case_id=case.id,
                        finding_id=finding.id,
                        url=result.probe_url,
                        final_url=result.final_url,
                        http_status=result.status_code,
                        sha256=result.body_sha256,
                        body_len=result.body_len,
                        source_module="username",
                        confidence_at_capture=result.confidence,
                    )
                )
                session.commit()
                capture_raw_result(
                    self.storage,
                    case_name=self.case_name,
                    case_id=case.id,
                    finding_id=finding.id,
                    source_module="username",
                    payload={
                        **result.__dict__,
                        "false_positive_rejected": verdict.rejected,
                        "false_positive_reason": verdict.reason,
                    },
                    url=result.probe_url,
                    final_url=result.final_url,
                    http_status=result.status_code,
                    confidence=result.confidence,
                    name_hint=result.site_name,
                )

                row = self._row(result, verdict.rejected, verdict.reason)
                summary["sources"].append(
                    {
                        "name": result.site_name,
                        "reliability": result.source_reliability,
                        "note": result.reliability_note,
                        "category": result.category,
                    }
                )

                if verdict.rejected:
                    summary["rejected"].append(row)
                elif result.status == "exists" and result.confidence >= settings.high_threshold:
                    summary["high"].append(row)
                    session.add(
                        Relation(
                            case_id=case.id,
                            src_type="username",
                            src_value=self.username,
                            rel="same_username",
                            dst_type="profile",
                            dst_value=result.display_url,
                        )
                    )
                    session.commit()
                    self._enrich_profile(
                        session=session,
                        case_id=case.id,
                        finding_id=finding.id,
                        result=result,
                        vault=vault,
                    )
                elif (
                    result.status == "exists"
                    and result.confidence >= settings.medium_threshold
                ):
                    summary["medium"].append(row)
                elif result.status == "exists":
                    summary["weak"].append(row)

            session.commit()

        for tier in ("high", "medium", "weak", "rejected"):
            summary[tier].sort(key=lambda item: item["confidence"], reverse=True)
        summary["sources"].sort(key=lambda item: item["name"])
        summary["meta"] = {
            "case": self.case_name,
            "username": self.username,
            "sites_checked": len(results),
        }
        return summary

    def _enrich_profile(
        self,
        *,
        session,
        case_id: int,
        finding_id: int,
        result: SiteResult,
        vault: EvidenceVault,
    ) -> None:
        profile, html, _status_code = fetch_and_parse(result.display_url)
        if html:
            vault.store_html(html, finding_id, result.site_name)
            vault.store_screenshot(result.display_url, finding_id, result.site_name)

        if profile:
            if profile.avatar_url:
                session.add(Entity(case_id=case_id, type="avatar", value=profile.avatar_url))
                session.add(
                    Relation(
                        case_id=case_id,
                        src_type="profile",
                        src_value=result.display_url,
                        rel="has_avatar",
                        dst_type="avatar",
                        dst_value=profile.avatar_url,
                    )
                )
            for urls in profile.social_links.values():
                for url in urls:
                    session.add(Entity(case_id=case_id, type="url", value=url))
                    session.add(
                        Relation(
                            case_id=case_id,
                            src_type="profile",
                            src_value=result.display_url,
                            rel="same_social_link",
                            dst_type="url",
                            dst_value=url,
                        )
                    )
            for email in profile.emails:
                session.add(Entity(case_id=case_id, type="email", value=email))
                session.add(
                    Relation(
                        case_id=case_id,
                        src_type="profile",
                        src_value=result.display_url,
                        rel="uses_email",
                        dst_type="email",
                        dst_value=email,
                    )
                )
            for wallet_type, wallets in profile.wallets.items():
                for wallet in wallets:
                    session.add(Entity(case_id=case_id, type="wallet", value=wallet))
                    session.add(
                        Relation(
                            case_id=case_id,
                            src_type="profile",
                            src_value=result.display_url,
                            rel=f"uses_{wallet_type}_wallet",
                            dst_type="wallet",
                            dst_value=wallet,
                        )
                    )

        session.add(
            TimelineEvent(
                case_id=case_id,
                kind="first_seen",
                entity_type="profile",
                entity_value=result.display_url,
                when=datetime.now(timezone.utc),
                source_name=result.site_name,
                description="Profile discovered",
            )
        )

    @staticmethod
    def _row(result: SiteResult, rejected: bool, reason: str) -> dict:
        return {
            "site": result.site_name,
            "category": result.category,
            "url": result.display_url,
            "final_url": result.final_url,
            "status": result.status,
            "status_code": result.status_code,
            "confidence": result.confidence,
            "reliability": result.source_reliability,
            "title": result.page_title,
            "markers": result.matched_markers,
            "redirected": result.redirected,
            "sha256": result.body_sha256,
            "rejected": rejected,
            "reject_reason": reason,
        }
