from __future__ import annotations

from typing import Any

from ..config import settings
from ..catalog.policy import source_policy_context
from ..graph.builder import build_graph, graph_metrics
from ..storage.models import (
    AnalystNote,
    Attachment,
    Case,
    Entity,
    Evidence,
    Finding,
    Relation,
    Source,
)
from ..storage.repositories import ModelRepository
from ..storage.sqlite import Storage
from .case_lookup import case_ids, case_rows
from .pivoting import build_case_pivot_plan
from .timeline import get_timeline


def _row(obj) -> dict[str, Any]:
    out = obj.as_dict()
    for key, value in list(out.items()):
        if hasattr(value, "isoformat"):
            out[key] = value.isoformat()
    return out


def _visible_finding(row: dict[str, Any]) -> bool:
    if row.get("rejected"):
        return False
    return row.get("status") == "exists"


def _source_key(row: dict[str, Any]) -> str:
    return str(row.get("source_id") or row.get("source_name") or row.get("name") or "").strip()


def _source_with_policy(row: dict[str, Any]) -> dict[str, Any]:
    enriched = dict(row)
    labels = []
    if isinstance(row.get("policy_label_list"), list):
        labels = [str(item) for item in row.get("policy_label_list") or []]
    context = source_policy_context(
        _source_key(row),
        name=str(row.get("name") or row.get("source_name") or ""),
        category=str(row.get("category") or ""),
        notes=str(row.get("notes") or ""),
    )
    if not labels:
        labels = [str(item) for item in context.get("policy_labels") or []]
    enriched["terms_risk"] = context.get("terms_risk") or "not confirmed"
    enriched["collection_mode"] = context.get("collection_mode") or "lookup"
    enriched["sensitivity"] = context.get("sensitivity") or "standard"
    enriched["requires_opt_in"] = bool(context.get("requires_opt_in"))
    enriched["policy_label_list"] = labels
    enriched["policy_labels"] = ", ".join(labels)
    return enriched


def _expected_pipeline_sources(cases: list[Case]) -> list[str]:
    expected: list[str] = []
    try:
        from .source_pipeline import pipeline_sources
        from .target import detect_module
    except Exception:
        return expected
    for case in cases:
        module = str(case.module or "")
        input_type = ""
        if module == "pipeline":
            input_type = detect_module(str(case.target or ""))
        elif module.endswith("_pipeline"):
            input_type = module[: -len("_pipeline")]
        if input_type:
            for source_id in pipeline_sources(input_type):
                if source_id not in expected:
                    expected.append(source_id)
    return expected


def _source_status(source: dict[str, Any], statuses: set[str]) -> str:
    success = int(source.get("success_count") or 0)
    errors = int(source.get("error_count") or 0)
    health = str(source.get("health_status") or "").lower()
    notes = str(source.get("notes") or "").lower()
    last_error = str(source.get("last_error") or "").strip()
    if errors > 0 or last_error or "error" in statuses:
        return "error"
    if (
        health == "missing_keys"
        or "missing_keys" in statuses
        or "required api keys missing" in notes
    ):
        return "missing_keys"
    if success > 0 or statuses.intersection({"exists", "ok"}):
        return "checked"
    if statuses.intersection({"skipped", "blocked_by_scope", "rate_limited"}):
        return "skipped"
    return "skipped"


def _source_coverage(
    *,
    sources: list[dict[str, Any]],
    findings: list[dict[str, Any]],
    cases: list[Case],
) -> dict[str, Any]:
    finding_statuses: dict[str, set[str]] = {}
    for finding in findings:
        key = _source_key(finding)
        if key:
            finding_statuses.setdefault(key, set()).add(str(finding.get("status") or ""))

    rows = []
    for source in sources:
        key = _source_key(source)
        statuses = finding_statuses.get(key, set())
        success = int(source.get("success_count") or 0)
        errors = int(source.get("error_count") or 0)
        total = success + errors
        rows.append(
            {
                "source": key,
                "name": source.get("name") or key,
                "category": source.get("category") or "",
                "status": _source_status(source, statuses),
                "success_count": success,
                "error_count": errors,
                "success_rate": round(success / total, 3) if total else None,
                "health_status": source.get("health_status") or "unknown",
                "last_error": source.get("last_error") or "",
                "notes": source.get("notes") or "",
                "terms_risk": source.get("terms_risk") or "not confirmed",
                "collection_mode": source.get("collection_mode") or "lookup",
                "sensitivity": source.get("sensitivity") or "standard",
                "policy_labels": source.get("policy_labels") or "",
            }
        )

    observed = {row["source"] for row in rows if row["source"]}
    expected = _expected_pipeline_sources(cases)
    missing = [source_id for source_id in expected if source_id not in observed]
    return {
        "summary": {
            "recorded_sources": len(rows),
            "checked": sum(1 for row in rows if row["status"] == "checked"),
            "skipped": sum(1 for row in rows if row["status"] == "skipped"),
            "missing_keys": sum(1 for row in rows if row["status"] == "missing_keys"),
            "errors": sum(1 for row in rows if row["status"] == "error"),
            "expected_sources": len(expected),
            "missing_expected_sources": len(missing),
            "passive_only_sources": sum(
                1 for row in rows if "passive_only" in str(row.get("policy_labels") or "")
            ),
            "sensitive_data_sources": sum(
                1 for row in rows if "sensitive_data" in str(row.get("policy_labels") or "")
            ),
        },
        "rows": rows,
        "missing_expected": missing,
    }


def _source_health_state(source: dict[str, Any]) -> str:
    success = int(source.get("success_count") or 0)
    errors = int(source.get("error_count") or 0)
    health = str(source.get("health_status") or "").lower()
    notes = str(source.get("notes") or "").lower()
    last_error = str(source.get("last_error") or "").strip()
    if errors > 0 or last_error or health == "error":
        return "error"
    if health == "missing_keys" or "required api keys missing" in notes:
        return "missing_keys"
    if success > 0 or health in {"available", "healthy"}:
        return "healthy"
    return "skipped"


def _source_health_history(
    *,
    sources: list[dict[str, Any]],
    cases: list[Case],
) -> dict[str, Any]:
    run_by_id = {_row(case).get("id"): _row(case) for case in cases}
    rows: list[dict[str, Any]] = []
    for source in sources:
        run = run_by_id.get(source.get("case_id"), {})
        success = int(source.get("success_count") or 0)
        errors = int(source.get("error_count") or 0)
        total = success + errors
        observed_at = (
            source.get("health_checked_at")
            or source.get("captured_at")
            or run.get("created_at")
            or ""
        )
        rows.append(
            {
                "run_id": source.get("case_id"),
                "run_module": run.get("module") or "",
                "run_target": run.get("target") or "",
                "observed_at": observed_at,
                "source_id": _source_key(source),
                "name": source.get("name") or _source_key(source),
                "category": source.get("category") or "",
                "health_state": _source_health_state(source),
                "health_status": source.get("health_status") or "unknown",
                "success_count": success,
                "error_count": errors,
                "success_rate": round(success / total, 3) if total else None,
                "last_error": source.get("last_error") or "",
                "terms_risk": source.get("terms_risk") or "not confirmed",
                "sensitivity": source.get("sensitivity") or "standard",
                "policy_labels": source.get("policy_labels") or "",
                "notes": source.get("notes") or "",
            }
        )

    latest_by_source: dict[str, dict[str, Any]] = {}
    for row in rows:
        source_id = str(row.get("source_id") or "")
        if not source_id:
            continue
        current = latest_by_source.get(source_id)
        if current is None or str(row.get("observed_at") or "") >= str(current.get("observed_at") or ""):
            latest_by_source[source_id] = row
    latest = sorted(
        latest_by_source.values(),
        key=lambda row: (str(row.get("health_state") or ""), str(row.get("source_id") or "")),
    )
    states = {}
    for row in latest:
        state = str(row.get("health_state") or "unknown")
        states[state] = states.get(state, 0) + 1
    return {
        "summary": {
            "history_rows": len(rows),
            "sources": len(latest),
            "healthy": states.get("healthy", 0),
            "missing_keys": states.get("missing_keys", 0),
            "errors": states.get("error", 0),
            "skipped": states.get("skipped", 0),
            "states": dict(sorted(states.items())),
        },
        "latest": latest,
        "rows": sorted(
            rows,
            key=lambda row: (str(row.get("observed_at") or ""), str(row.get("source_id") or "")),
            reverse=True,
        ),
    }


def _finding_band(confidence: float) -> str:
    if confidence >= 0.75:
        return "high"
    if confidence >= 0.45:
        return "medium"
    return "weak"


def _corroborated_entity_count(findings: list[dict[str, Any]]) -> int:
    by_entity: dict[tuple[str, str], set[str]] = {}
    for finding in findings:
        confidence = float(finding.get("confidence") or 0.0)
        if confidence <= 0:
            continue
        entity = (
            str(finding.get("entity_type") or ""),
            str(finding.get("entity_value") or ""),
        )
        source = str(finding.get("source_id") or finding.get("source_name") or "")
        if entity[0] and entity[1] and source:
            by_entity.setdefault(entity, set()).add(source)
    return sum(1 for sources in by_entity.values() if len(sources) >= 2)


def _independent_sources_by_entity(findings: list[dict[str, Any]]) -> dict[tuple[str, str], set[str]]:
    by_entity: dict[tuple[str, str], set[str]] = {}
    for finding in findings:
        if finding.get("rejected"):
            continue
        confidence = float(finding.get("confidence") or 0.0)
        if confidence <= 0:
            continue
        entity = (
            str(finding.get("entity_type") or ""),
            str(finding.get("entity_value") or ""),
        )
        source = _source_key(finding)
        if entity[0] and entity[1] and source:
            by_entity.setdefault(entity, set()).add(source)
    return by_entity


def _source_risk_label(source: dict[str, Any]) -> str:
    terms = str(source.get("terms_risk") or "not confirmed")
    sensitivity = str(source.get("sensitivity") or "standard")
    labels = str(source.get("policy_labels") or "")
    parts = [f"terms:{terms}", f"sensitivity:{sensitivity}"]
    if labels:
        parts.append(f"labels:{labels}")
    return "; ".join(parts)


def _human_review_reasons(finding: dict[str, Any], source: dict[str, Any], independent_count: int) -> list[str]:
    reasons: list[str] = []
    confidence = float(finding.get("confidence") or 0.0)
    status = str(finding.get("status") or "")
    terms = str(source.get("terms_risk") or "").lower()
    sensitivity = str(source.get("sensitivity") or "").lower()
    if finding.get("rejected"):
        reasons.append(str(finding.get("reject_reason") or "rejected finding"))
    if status != "exists":
        reasons.append(f"status requires review: {status or 'unknown'}")
    if confidence < 0.75:
        reasons.append("confidence below high threshold")
    if independent_count < 2:
        reasons.append("needs independent corroboration")
    if terms in {"medium", "high", "reject"}:
        reasons.append(f"source terms risk: {terms}")
    if sensitivity == "sensitive_data":
        reasons.append("sensitive source context")
    return sorted(set(reason for reason in reasons if reason))


def _enrich_findings_for_review(
    findings: list[dict[str, Any]],
    sources: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    sources_by_id = {
        _source_key(source): source
        for source in sources
        if _source_key(source)
    }
    independent_by_entity = _independent_sources_by_entity(findings)
    enriched = []
    for finding in findings:
        row = dict(finding)
        entity = (
            str(row.get("entity_type") or ""),
            str(row.get("entity_value") or ""),
        )
        source = sources_by_id.get(_source_key(row), {})
        independent_count = len(independent_by_entity.get(entity, set()))
        reasons = _human_review_reasons(row, source, independent_count)
        row["independent_corroboration_count"] = independent_count
        row["source_risk_label"] = _source_risk_label(source) if source else "terms:not confirmed; sensitivity:standard"
        row["human_review_required"] = bool(reasons)
        row["human_review_reasons"] = reasons
        enriched.append(row)
    return enriched


def _risk_summary(
    *,
    visible_findings: list[dict[str, Any]],
    findings: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
    coverage: dict[str, Any],
) -> dict[str, Any]:
    bands = {"high": 0, "medium": 0, "weak": 0}
    confidences: list[float] = []
    for finding in visible_findings:
        confidence = float(finding.get("confidence") or 0.0)
        confidences.append(confidence)
        bands[_finding_band(confidence)] += 1

    coverage_summary = coverage.get("summary") or {}
    missing_keys = int(coverage_summary.get("missing_keys") or 0)
    errors = int(coverage_summary.get("errors") or 0)
    skipped = int(coverage_summary.get("skipped") or 0)
    review_required = len([finding for finding in findings if finding.get("rejected")])
    corroborated = _corroborated_entity_count(visible_findings)
    confidence_score = round((sum(confidences) / len(confidences)) * 100, 1) if confidences else 0.0
    raw_risk = (
        bands["high"] * 22
        + bands["medium"] * 11
        + bands["weak"] * 4
        + corroborated * 10
        + min(10, len(evidence) * 2)
    )
    evidence_gap_penalty = min(25, errors * 5 + missing_keys * 2 + skipped)
    risk_score = max(0, min(100, raw_risk - evidence_gap_penalty))
    risk_level = "high" if risk_score >= 70 else "medium" if risk_score >= 35 else "low"
    drivers = []
    if bands["high"]:
        drivers.append(f"{bands['high']} high-confidence findings")
    if bands["medium"]:
        drivers.append(f"{bands['medium']} medium-confidence findings")
    if corroborated:
        drivers.append(f"{corroborated} entities corroborated by 2+ sources")
    if evidence:
        drivers.append(f"{len(evidence)} preserved evidence rows")
    if missing_keys:
        drivers.append(f"{missing_keys} sources missing required keys")
    if errors:
        drivers.append(f"{errors} sources with errors")
    if review_required:
        drivers.append(f"{review_required} rejected or not-confirmed findings kept for review")
    return {
        "risk_score": round(risk_score, 1),
        "risk_level": risk_level,
        "confidence_score": confidence_score,
        "confidence_band_counts": bands,
        "corroborated_entities": corroborated,
        "review_required": review_required,
        "evidence_gap_penalty": evidence_gap_penalty,
        "drivers": drivers,
        "note": "Risk score is a case-exposure indicator, not identity proof.",
    }


def _relation_enrichment_from_graph(graph) -> dict[int, dict[str, Any]]:
    enriched: dict[int, dict[str, Any]] = {}
    for _src, _dst, data in graph.edges(data=True):
        relation_id = data.get("relation_id")
        if relation_id is None:
            continue
        provenance = data.get("provenance") or {}
        enriched[int(relation_id)] = {
            "confidence": float(data.get("confidence") or provenance.get("confidence") or 0.0),
            "weight": float(data.get("weight") or provenance.get("weight") or 0.0),
            "evidence_count": int(data.get("evidence_count") or provenance.get("evidence_count") or 0),
            "source_ids": list(provenance.get("source_ids") or []),
            "evidence_refs": list(data.get("evidence_refs") or provenance.get("evidence_refs") or []),
            "provenance_reason": str(provenance.get("reason") or ""),
        }
    return enriched


def _enrich_relations_from_graph(relations: list[dict[str, Any]], graph) -> list[dict[str, Any]]:
    enrichment = _relation_enrichment_from_graph(graph)
    enriched = []
    for relation in relations:
        row = dict(relation)
        relation_id = row.get("id")
        if relation_id is not None and int(relation_id) in enrichment:
            row.update(enrichment[int(relation_id)])
        enriched.append(row)
    return enriched


def build_case_summary(case_name: str) -> dict:
    storage = Storage(settings.db_path(case_name))
    cases = case_rows(storage, case_name)
    ids = case_ids(storage, case_name)
    if not ids:
        return {"meta": {"case": case_name, "found": False}}

    def rows_for(model):
        repository = ModelRepository(storage.db_path, model)
        return [_row(item) for item in repository.list_by_values("case_id", ids)]

    findings = rows_for(Finding)
    entities = rows_for(Entity)
    relations = rows_for(Relation)
    evidence = rows_for(Evidence)
    sources = rows_for(Source)
    attachments = rows_for(Attachment)
    notes = rows_for(AnalystNote)

    sources = [_source_with_policy(row) for row in sources]
    findings = _enrich_findings_for_review(findings, sources)
    visible_findings = [row for row in findings if _visible_finding(row)]
    graph = build_graph(storage, ids)
    relations = _enrich_relations_from_graph(relations, graph)
    coverage = _source_coverage(sources=sources, findings=findings, cases=cases)
    health_history = _source_health_history(sources=sources, cases=cases)
    risk = _risk_summary(
        visible_findings=visible_findings,
        findings=findings,
        evidence=evidence,
        coverage=coverage,
    )
    pivot_plan = build_case_pivot_plan(findings, entities)
    return {
        "meta": {
            "case": case_name,
            "found": True,
            "runs": [_row(case) for case in cases],
            "run_count": len(cases),
        },
        "entities": entities,
        "all_findings": sorted(
            findings,
            key=lambda row: row.get("confidence", 0),
            reverse=True,
        ),
        "findings": sorted(
            visible_findings,
            key=lambda row: row.get("confidence", 0),
            reverse=True,
        ),
        "risk_summary": risk,
        "relations": relations,
        "evidence": evidence,
        "sources": sources,
        "source_coverage": coverage,
        "source_health_history": health_history,
        "pivot_plan": pivot_plan,
        "attachments": attachments,
        "notes": notes,
        "timeline": get_timeline(storage, ids),
        "graph": graph_metrics(graph),
    }
