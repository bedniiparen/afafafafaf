from __future__ import annotations

from ..catalog.policy import format_policy_note, source_policy_context
from ..storage.models import Source
from .source_reliability import reliability_from_history


MODULE_RELIABILITY = {
    "email-analyzer": 0.78,
    "domain-analyzer": 0.82,
    "ip-analyzer": 0.76,
    "phone-analyzer": 0.72,
    "url-analyzer": 0.70,
    "bitcoin-explorer": 0.74,
    "ethereum-explorer": 0.74,
    "unknown-explorer": 0.35,
    "company-analyzer": 0.62,
    "exiftool": 0.90,
    "native": 0.55,
}


def source_reliability(
    source_name: str,
    *,
    rejected: bool = False,
    success_count: int = 0,
    error_count: int = 0,
) -> float:
    base = MODULE_RELIABILITY.get(source_name, 0.60)
    if rejected:
        base *= 0.65
    reliability, _note = reliability_from_history(
        base,
        success_count=success_count,
        error_count=error_count,
    )
    return reliability


def record_source(
    session,
    *,
    case_id: int,
    name: str,
    source_id: str | None = None,
    url_main: str = "",
    category: str = "module",
    rejected: bool = False,
    success_count: int | None = None,
    error_count: int | None = None,
    notes: str = "",
) -> Source:
    success = success_count if success_count is not None else (0 if rejected else 1)
    errors = error_count if error_count is not None else 0
    persisted_source_id = source_id or name
    policy_context = source_policy_context(
        persisted_source_id,
        name=name,
        category=category,
        notes=notes,
    )
    policy_note = format_policy_note(policy_context)
    source_notes = notes
    if policy_note and policy_note not in source_notes:
        source_notes = f"{source_notes}; {policy_note}" if source_notes else policy_note
    source = Source(
        case_id=case_id,
        name=name,
        source_id=persisted_source_id,
        url_main=url_main,
        category=category,
        reliability=source_reliability(
            name,
            rejected=rejected,
            success_count=success,
            error_count=errors,
        ),
        calibrated=False,
        success_count=success,
        error_count=errors,
        notes=source_notes,
    )
    session.add(source)
    return source
