from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable

try:
    from rapidfuzz import fuzz as _fuzz
    from rapidfuzz.distance import JaroWinkler as _JW
    from rapidfuzz.distance import Levenshtein as _Lev

    _HAS_RAPIDFUZZ = True
except Exception:  # pragma: no cover - optional speedup
    _HAS_RAPIDFUZZ = False


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text or "").casefold().strip()
    return re.sub(r"\s+", " ", text)


def _py_levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        current = [i]
        for j, cb in enumerate(b, 1):
            current.append(
                min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + (ca != cb))
            )
        previous = current
    return previous[-1]


def levenshtein(a: str, b: str) -> int:
    if _HAS_RAPIDFUZZ:
        return int(_Lev.distance(a or "", b or ""))
    return _py_levenshtein(a or "", b or "")


def ratio(a: str, b: str) -> float:
    a = normalize(a)
    b = normalize(b)
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    if _HAS_RAPIDFUZZ:
        return float(_fuzz.ratio(a, b)) / 100.0
    return 1.0 - _py_levenshtein(a, b) / max(len(a), len(b))


def token_ratio(a: str, b: str) -> float:
    a = normalize(a)
    b = normalize(b)
    if not a or not b:
        return 0.0
    if _HAS_RAPIDFUZZ:
        return max(float(_fuzz.token_sort_ratio(a, b)), float(_fuzz.token_set_ratio(a, b))) / 100.0
    left = set(a.split())
    right = set(b.split())
    return len(left & right) / len(left | right) if left or right else 0.0


def _py_jaro_winkler(a: str, b: str) -> float:
    match_dist = max(max(len(a), len(b)) // 2 - 1, 0)
    a_match = [False] * len(a)
    b_match = [False] * len(b)
    matches = 0
    for i, ca in enumerate(a):
        lo = max(0, i - match_dist)
        hi = min(i + match_dist + 1, len(b))
        for j in range(lo, hi):
            if not b_match[j] and ca == b[j]:
                a_match[i] = True
                b_match[j] = True
                matches += 1
                break
    if not matches:
        return 0.0
    transpositions = 0
    k = 0
    for i, matched in enumerate(a_match):
        if not matched:
            continue
        while not b_match[k]:
            k += 1
        if a[i] != b[k]:
            transpositions += 1
        k += 1
    transpositions /= 2
    jaro = (matches / len(a) + matches / len(b) + (matches - transpositions) / matches) / 3
    prefix = 0
    for ca, cb in zip(a, b):
        if ca == cb and prefix < 4:
            prefix += 1
        else:
            break
    return jaro + prefix * 0.1 * (1 - jaro)


def jaro_winkler(a: str, b: str) -> float:
    a = normalize(a)
    b = normalize(b)
    if a == b:
        return 1.0
    if not a or not b:
        return 0.0
    if _HAS_RAPIDFUZZ:
        return float(_JW.similarity(a, b))
    return _py_jaro_winkler(a, b)


def best_ratio(a: str, b: str) -> float:
    return max(jaro_winkler(a, b), token_ratio(a, b), ratio(a, b))


def same_entity(a: str, b: str, *, threshold: float = 0.88, method: str = "jw") -> bool:
    if method == "jw":
        score = jaro_winkler(a, b)
    elif method == "token":
        score = token_ratio(a, b)
    elif method == "best":
        score = best_ratio(a, b)
    else:
        score = ratio(a, b)
    return score >= threshold


def _blocking_key(value: str) -> str:
    normalized = normalize(value)
    if not normalized:
        return ":"
    return f"{normalized[:1]}:{len(normalized) // 4}"


def dedupe(values: Iterable[str], *, threshold: float = 0.9, method: str = "jw") -> list[list[str]]:
    buckets: dict[str, list[list[str]]] = {}
    order: list[list[str]] = []
    for value in values:
        key = _blocking_key(value)
        placed = False
        for cluster in buckets.setdefault(key, []):
            if same_entity(value, cluster[0], threshold=threshold, method=method):
                cluster.append(value)
                placed = True
                break
        if not placed:
            cluster = [value]
            buckets[key].append(cluster)
            order.append(cluster)
    return order
