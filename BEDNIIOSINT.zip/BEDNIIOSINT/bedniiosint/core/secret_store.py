from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config import settings


SECRET_KEY_ENV = "BEDNIIOSINT_SECRETS_KEY"
STORE_VERSION = 1
KDF_ITERATIONS = 210_000
SETUP_PROFILES = {
    "windows-cmd-session",
    "windows-cmd-user",
    "powershell-session",
    "powershell-user",
    "systemd-env",
    "docker-env",
    "env-file",
}
SETUP_APPLY_PROFILES = {
    "windows-cmd-session",
    "windows-cmd-user",
    "powershell-session",
    "powershell-user",
    "systemd-env",
    "docker-env",
    "env-file",
}
SYSTEMD_DROPIN_NAME = "bedniiosint-secrets.conf"


def secret_store_path(path: Path | None = None) -> Path:
    return path or (settings.db_dir / "_secrets.json")


def secret_value(name: str, *, path: Path | None = None) -> str:
    env_value = os.getenv(name)
    if env_value:
        return env_value
    record = _load_store(path).get("secrets", {}).get(name)
    if not record:
        return ""
    passphrase = _passphrase()
    if not passphrase:
        return ""
    try:
        return _decrypt_record(record, passphrase)
    except ValueError:
        return ""


def secret_configured(name: str, *, path: Path | None = None) -> bool:
    return bool(secret_value(name, path=path))


def missing_secret_names(names: list[str], *, path: Path | None = None) -> list[str]:
    return [name for name in names if not secret_configured(name, path=path)]


def secret_values(names: list[str], *, path: Path | None = None) -> list[str]:
    return [secret_value(name, path=path) for name in names]


def store_secret(
    name: str,
    value: str,
    *,
    path: Path | None = None,
    overwrite: bool = True,
) -> dict[str, Any]:
    _validate_secret_name(name)
    if not value:
        raise ValueError("secret value must not be empty")
    passphrase = _require_passphrase()
    store = _load_store(path)
    records = store.setdefault("secrets", {})
    if name in records and not overwrite:
        raise FileExistsError(f"secret already exists: {name}")
    now = _now()
    previous = records.get(name, {})
    record = _encrypt_value(value, passphrase)
    record.update(
        {
            "name": name,
            "backend": "passphrase-v1",
            "created_at": previous.get("created_at") or now,
            "updated_at": now,
        }
    )
    records[name] = record
    _write_store(store, path)
    return _public_record(record)


def delete_secret(name: str, *, path: Path | None = None) -> bool:
    store = _load_store(path)
    records = store.setdefault("secrets", {})
    existed = name in records
    if existed:
        del records[name]
        _write_store(store, path)
    return existed


def list_secrets(*, path: Path | None = None) -> list[dict[str, Any]]:
    records = _load_store(path).get("secrets", {})
    return [_public_record(record) for _name, record in sorted(records.items())]


def audit_secret_store(
    *,
    path: Path | None = None,
    min_iterations: int = KDF_ITERATIONS,
) -> dict[str, Any]:
    store_path = secret_store_path(path)
    store = _load_store(path)
    records = store.get("secrets", {})
    passphrase = _passphrase()
    errors: list[str] = []
    warnings: list[str] = []
    rows: list[dict[str, Any]] = []
    authenticated = 0
    rotation_required = 0
    required_fields = {"kdf", "iterations", "salt", "nonce", "ciphertext", "tag"}
    for name, record in sorted(records.items()):
        missing = sorted(field for field in required_fields if not record.get(field))
        iterations = int(record.get("iterations") or 0)
        kdf = str(record.get("kdf") or "")
        needs_rotation = bool(missing) or kdf != "pbkdf2-sha256" or iterations < min_iterations
        if needs_rotation:
            rotation_required += 1
        status = "ok"
        if missing:
            status = "invalid"
            errors.append(f"{name}: missing fields: {', '.join(missing)}")
        elif kdf != "pbkdf2-sha256":
            status = "unsupported_kdf"
            errors.append(f"{name}: unsupported kdf: {kdf or 'missing'}")
        elif iterations < min_iterations:
            status = "rotation_required"
            warnings.append(f"{name}: KDF iterations below policy")
        auth_status = "not_checked"
        if passphrase and not missing and kdf == "pbkdf2-sha256":
            try:
                _decrypt_record(record, passphrase)
            except (KeyError, ValueError, TypeError):
                status = "auth_failed"
                auth_status = "failed"
                errors.append(f"{name}: authentication failed")
            else:
                authenticated += 1
                auth_status = "verified"
        rows.append(
            {
                "name": name,
                "backend": record.get("backend", ""),
                "kdf": kdf,
                "iterations": iterations,
                "status": status,
                "auth_status": auth_status,
                "rotation_required": needs_rotation,
                "created_at": record.get("created_at", ""),
                "updated_at": record.get("updated_at", ""),
            }
        )
    if int(store.get("version") or 0) != STORE_VERSION:
        warnings.append("secret store version differs from current version")
    if records and not passphrase:
        warnings.append(f"{SECRET_KEY_ENV} is not set; authentication was not checked")
    return {
        "store": str(store_path),
        "exists": store_path.exists(),
        "version": store.get("version"),
        "current_version": STORE_VERSION,
        "kdf_policy": "pbkdf2-sha256",
        "min_iterations": min_iterations,
        "passphrase_env_set": bool(passphrase),
        "records": rows,
        "summary": {
            "records": len(records),
            "authenticated": authenticated,
            "rotation_required": rotation_required,
            "errors": len(errors),
            "warnings": len(warnings),
        },
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "secrets_returned": False,
    }


def rotate_secret_store(*, path: Path | None = None) -> dict[str, Any]:
    passphrase = _require_passphrase()
    store = _load_store(path)
    records = store.setdefault("secrets", {})
    rotated = 0
    now = _now()
    for name, record in sorted(list(records.items())):
        value = _decrypt_record(record, passphrase)
        replacement = _encrypt_value(value, passphrase)
        replacement.update(
            {
                "name": record.get("name") or name,
                "backend": "passphrase-v1",
                "created_at": record.get("created_at") or now,
                "updated_at": now,
                "rotated_at": now,
            }
        )
        records[name] = replacement
        rotated += 1
    store["version"] = STORE_VERSION
    _write_store(store, path)
    return {
        "store": str(secret_store_path(path)),
        "rotated": rotated,
        "iterations": KDF_ITERATIONS,
        "kdf": "pbkdf2-sha256",
        "secrets_returned": False,
    }


def secret_store_setup_template(
    *,
    profile: str = "windows-cmd-user",
    placeholder: str = "<set-a-long-passphrase>",
) -> str:
    """Return a setup template for persisting the secret-store passphrase."""
    profile = profile.strip().lower()
    if profile not in SETUP_PROFILES:
        allowed = ", ".join(sorted(SETUP_PROFILES))
        raise ValueError(f"profile must be one of: {allowed}")
    if not placeholder or "\n" in placeholder or "\r" in placeholder:
        raise ValueError("placeholder must be a single non-empty line")
    value = placeholder
    comment = "rem" if profile.startswith("windows-cmd") else "#"
    lines = [
        f"{comment} BEDNIIOSINT encrypted secret store setup",
        f"{comment} Replace the placeholder with a long local passphrase.",
        f"{comment} Do not commit files or terminal logs that contain the real passphrase.",
        "",
    ]
    if profile == "windows-cmd-session":
        lines.append(f'set "{SECRET_KEY_ENV}={value}"')
    elif profile == "windows-cmd-user":
        lines.append(f'setx {SECRET_KEY_ENV} "{value}"')
    elif profile == "powershell-session":
        lines.append(f"$env:{SECRET_KEY_ENV} = '{_ps_quote(value)}'")
    elif profile == "powershell-user":
        lines.append(
            f"[Environment]::SetEnvironmentVariable('{SECRET_KEY_ENV}', '{_ps_quote(value)}', 'User')"
        )
    elif profile == "systemd-env":
        lines.extend(
            [
                "[Service]",
                f'Environment="{SECRET_KEY_ENV}={value}"',
            ]
        )
    elif profile == "docker-env":
        lines.append(f"-e {SECRET_KEY_ENV}={value}")
    elif profile == "env-file":
        lines.append(f"{SECRET_KEY_ENV}={value}")
    return "\n".join(lines) + "\n"


def write_secret_store_setup_template(
    out: Path,
    *,
    profile: str = "windows-cmd-user",
    placeholder: str = "<set-a-long-passphrase>",
    overwrite: bool = False,
) -> Path:
    if out.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite existing setup template: {out}")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        secret_store_setup_template(profile=profile, placeholder=placeholder),
        encoding="utf-8",
    )
    return out


def apply_secret_store_setup(
    *,
    profile: str = "windows-cmd-user",
    passphrase: str,
    out: Path | None = None,
    overwrite: bool = False,
    allow_secret_file: bool = False,
) -> dict[str, Any]:
    """Persist or apply BEDNIIOSINT_SECRETS_KEY without returning the secret."""
    profile = profile.strip().lower()
    if profile not in SETUP_PROFILES:
        allowed = ", ".join(sorted(SETUP_PROFILES))
        raise ValueError(f"profile must be one of: {allowed}")
    if profile not in SETUP_APPLY_PROFILES:
        allowed = ", ".join(sorted(SETUP_APPLY_PROFILES))
        raise ValueError(f"profile does not support direct apply; use one of: {allowed}")
    _validate_setup_passphrase(passphrase)
    if profile in {"systemd-env", "docker-env", "env-file"}:
        if out is None:
            raise ValueError(f"{profile} apply requires an explicit output path")
        if not allow_secret_file:
            raise ValueError(f"{profile} apply writes a secret file; pass allow_secret_file=True")
        path = write_secret_store_setup_template(
            out,
            profile=profile,
            placeholder=passphrase,
            overwrite=overwrite,
        )
        _restrict_file_to_owner(path)
        return {
            "profile": profile,
            "status": "applied",
            "target": str(path),
            "persistent": True,
            "requires_restart": True,
            "secret_returned": False,
            "secret_file_written": True,
        }
    if profile in {"windows-cmd-session", "powershell-session"}:
        os.environ[SECRET_KEY_ENV] = passphrase
        return {
            "profile": profile,
            "status": "applied",
            "target": "current-process-environment",
            "persistent": False,
            "requires_restart": False,
            "secret_returned": False,
            "secret_file_written": False,
        }
    if os.name != "nt":
        raise RuntimeError("persistent user environment apply is only supported on Windows")
    _set_windows_user_environment(SECRET_KEY_ENV, passphrase)
    os.environ[SECRET_KEY_ENV] = passphrase
    return {
        "profile": profile,
        "status": "applied",
        "target": "windows-user-environment",
        "persistent": True,
        "requires_restart": True,
        "secret_returned": False,
        "secret_file_written": False,
    }


def install_secret_store_systemd_dropin(
    *,
    service: str,
    passphrase: str,
    user: bool = True,
    root: Path | None = None,
    overwrite: bool = False,
    allow_secret_file: bool = False,
    reload_daemon: bool = False,
    restart_service: bool = False,
    runner=None,
) -> dict[str, Any]:
    service_name = _normalize_systemd_service_name(service)
    base = root or (
        Path.home() / ".config" / "systemd" / "user"
        if user
        else Path("/etc/systemd/system")
    )
    out = base / f"{service_name}.d" / SYSTEMD_DROPIN_NAME
    result = apply_secret_store_setup(
        profile="systemd-env",
        passphrase=passphrase,
        out=out,
        overwrite=overwrite,
        allow_secret_file=allow_secret_file,
    )
    commands: list[list[str]] = []
    if reload_daemon:
        commands.append(["systemctl", *(["--user"] if user else []), "daemon-reload"])
    if restart_service:
        commands.append(["systemctl", *(["--user"] if user else []), "restart", service_name])
    executed: list[list[str]] = []
    command_runner = runner or subprocess.run
    for command in commands:
        command_runner(command, check=True)
        executed.append(command)
    return {
        **result,
        "target": "systemd-user-dropin" if user else "systemd-system-dropin",
        "service": service_name,
        "path": str(out),
        "reload_commands": commands,
        "executed_commands": executed,
    }


def _load_store(path: Path | None = None) -> dict[str, Any]:
    store_path = secret_store_path(path)
    if not store_path.exists():
        return {"version": STORE_VERSION, "secrets": {}}
    data = json.loads(store_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("secret store must be a JSON object")
    data.setdefault("version", STORE_VERSION)
    data.setdefault("secrets", {})
    return data


def _write_store(store: dict[str, Any], path: Path | None = None) -> None:
    store_path = secret_store_path(path)
    store_path.parent.mkdir(parents=True, exist_ok=True)
    store_path.write_text(
        json.dumps(store, indent=2, ensure_ascii=False, sort_keys=True),
        encoding="utf-8",
    )


def _encrypt_value(value: str, passphrase: str) -> dict[str, Any]:
    salt = secrets.token_bytes(16)
    nonce = secrets.token_bytes(16)
    key = _derive_key(passphrase, salt)
    enc_key, mac_key = key[:32], key[32:]
    plaintext = value.encode("utf-8")
    ciphertext = _xor_bytes(plaintext, _keystream(enc_key, nonce, len(plaintext)))
    tag = hmac.new(mac_key, nonce + ciphertext, hashlib.sha256).digest()
    return {
        "kdf": "pbkdf2-sha256",
        "iterations": KDF_ITERATIONS,
        "salt": _b64(salt),
        "nonce": _b64(nonce),
        "ciphertext": _b64(ciphertext),
        "tag": _b64(tag),
    }


def _decrypt_record(record: dict[str, Any], passphrase: str) -> str:
    salt = _unb64(record["salt"])
    nonce = _unb64(record["nonce"])
    ciphertext = _unb64(record["ciphertext"])
    tag = _unb64(record["tag"])
    iterations = int(record.get("iterations") or KDF_ITERATIONS)
    key = hashlib.pbkdf2_hmac(
        "sha256",
        passphrase.encode("utf-8"),
        salt,
        iterations,
        dklen=64,
    )
    enc_key, mac_key = key[:32], key[32:]
    expected = hmac.new(mac_key, nonce + ciphertext, hashlib.sha256).digest()
    if not hmac.compare_digest(expected, tag):
        raise ValueError("secret store authentication failed")
    plaintext = _xor_bytes(ciphertext, _keystream(enc_key, nonce, len(ciphertext)))
    return plaintext.decode("utf-8")


def _derive_key(passphrase: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac(
        "sha256",
        passphrase.encode("utf-8"),
        salt,
        KDF_ITERATIONS,
        dklen=64,
    )


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        out.extend(hmac.new(key, nonce + counter.to_bytes(8, "big"), hashlib.sha256).digest())
        counter += 1
    return bytes(out[:length])


def _xor_bytes(left: bytes, right: bytes) -> bytes:
    return bytes(a ^ b for a, b in zip(left, right))


def _b64(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def _unb64(value: str) -> bytes:
    return base64.b64decode(value.encode("ascii"))


def _passphrase() -> str:
    return os.getenv(SECRET_KEY_ENV, "")


def _require_passphrase() -> str:
    value = _passphrase()
    if not value:
        raise RuntimeError(f"set {SECRET_KEY_ENV} before using the encrypted secret store")
    return value


def _validate_secret_name(name: str) -> None:
    if not name or not all(ch.isalnum() or ch == "_" for ch in name):
        raise ValueError("secret name must contain only letters, numbers and underscores")


def _validate_setup_passphrase(value: str) -> None:
    if not value or "\n" in value or "\r" in value:
        raise ValueError("passphrase must be a single non-empty line")


def _set_windows_user_environment(name: str, value: str) -> None:
    import winreg

    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, value)


def _normalize_systemd_service_name(service: str) -> str:
    clean = service.strip()
    if not clean:
        raise ValueError("systemd service name must not be empty")
    if "/" in clean or "\\" in clean or ".." in clean:
        raise ValueError("systemd service name must not contain path separators")
    if not all(ch.isalnum() or ch in {"@", ".", "_", "-"} for ch in clean):
        raise ValueError("systemd service name contains unsupported characters")
    if not clean.endswith(".service"):
        clean += ".service"
    return clean


def _restrict_file_to_owner(path: Path) -> None:
    try:
        path.chmod(0o600)
    except OSError:
        pass


def _ps_quote(value: str) -> str:
    return value.replace("'", "''")


def _public_record(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": record.get("name", ""),
        "backend": record.get("backend", ""),
        "created_at": record.get("created_at", ""),
        "updated_at": record.get("updated_at", ""),
        "configured": True,
    }


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()
