from __future__ import annotations

from ..catalog import run_source
from ..config import settings
from ..storage.models import Finding
from ..storage.sqlite import Storage
from .normalizer import normalize_adapter_result, persist_normalized


SOURCE_MODULES = {
    "email-analyzer": "email",
    "domain-analyzer": "domain",
    "ip-analyzer": "ip",
    "phone-analyzer": "phone",
    "url-analyzer": "url",
    "bitcoin-explorer": "wallet",
    "ethereum-explorer": "wallet",
    "unknown-explorer": "wallet",
    "company-analyzer": "company",
}

ENTITY_MODULES = {
    "email": "email",
    "domain": "domain",
    "ip": "ip",
    "phone": "phone",
    "url": "url",
    "profile": "url",
    "wallet": "wallet",
    "company": "company",
}


def recheck_finding(case_name: str, finding_id: int) -> dict:
    storage = Storage(settings.db_path(case_name))
    with storage.session() as session:
        finding = session.query(Finding).filter(Finding.id == finding_id).first()
    if finding is None:
        raise KeyError(f"finding not found: {finding_id}")
    source_name = str(finding.source_name)
    if not source_name.startswith(("api:", "plugin:", "module:")):
        module = SOURCE_MODULES.get(source_name) or ENTITY_MODULES.get(
            str(finding.entity_type or "")
        )
        if module is None:
            raise KeyError(f"finding source is not re-checkable: {finding.source_name}")
        from .jobs import _run_module

        summary = _run_module(module, case_name, finding.entity_value)
        summary["meta"]["rechecked_finding_id"] = finding_id
        summary["meta"]["source"] = finding.source_name
        summary["meta"]["recheck_module"] = module
        return summary

    result = run_source(
        source_name,
        finding.entity_value,
        input_type="auto",
        case=f"{case_name}-recheck",
    )
    normalized = normalize_adapter_result(result)
    summary = persist_normalized(
        normalized,
        case_name=case_name,
        module="recheck",
    )
    summary["meta"]["rechecked_finding_id"] = finding_id
    summary["meta"]["source"] = source_name
    return summary
