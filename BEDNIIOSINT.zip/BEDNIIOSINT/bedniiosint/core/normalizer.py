from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from ..catalog.adapters import AdapterResult
from ..config import settings
from ..storage.models import Case, Finding, TimelineEvent
from ..storage.sqlite import Storage
from .artifacts import capture_raw_result
from .persist import add_entity_once, add_relation_once
from .source_record import record_source
from .target import detect_module


EMAIL_RE = re.compile(r"(?<![\w.+-])[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}(?![\w.-])")
URL_RE = re.compile(r"https?://[^\s\"'<>]+")
ETH_RE = re.compile(r"0x[a-fA-F0-9]{40}")
BTC_RE = re.compile(r"\b(?:bc1[a-z0-9]{25,62}|[13][a-km-zA-HJ-NP-Z1-9]{25,39})\b")
DOMAIN_RE = re.compile(r"\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b", re.I)


@dataclass
class NormalizedRecord:
    source_id: str
    target: str
    status: str
    confidence: float
    input_type: str = ""
    method: str = "GET"
    url: str = ""
    profile_url: str = ""
    status_code: int | None = None
    headers: dict[str, Any] = field(default_factory=dict)
    title: str = ""
    entities: list[dict[str, str]] = field(default_factory=list)
    relations: list[dict[str, str]] = field(default_factory=list)
    timeline: list[dict[str, Any]] = field(default_factory=list)
    raw: Any = None
    reject_reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "target": self.target,
            "status": self.status,
            "confidence": self.confidence,
            "input_type": self.input_type,
            "method": self.method,
            "url": self.url,
            "profile_url": self.profile_url,
            "status_code": self.status_code,
            "headers": self.headers,
            "title": self.title,
            "entities": self.entities,
            "relations": self.relations,
            "timeline": self.timeline,
            "raw": self.raw,
            "reject_reason": self.reject_reason,
        }


def _walk_strings(value: Any) -> list[str]:
    out: list[str] = []
    if isinstance(value, str):
        out.append(value)
    elif isinstance(value, dict):
        for item in value.values():
            out.extend(_walk_strings(item))
    elif isinstance(value, list | tuple | set):
        for item in value:
            out.extend(_walk_strings(item))
    return out


def _entity_candidates(*values: Any) -> list[dict[str, str]]:
    found: dict[tuple[str, str], dict[str, str]] = {}
    text = "\n".join(item for value in values for item in _walk_strings(value))
    for regex, entity_type in (
        (URL_RE, "url"),
        (EMAIL_RE, "email"),
        (ETH_RE, "wallet"),
        (BTC_RE, "wallet"),
        (DOMAIN_RE, "domain"),
    ):
        for match in regex.findall(text):
            value = match.rstrip(".,;)")
            found[(entity_type, value)] = {"type": entity_type, "value": value}
    return list(found.values())


def normalize_adapter_result(result: AdapterResult | dict[str, Any]) -> NormalizedRecord:
    data = result.as_dict() if hasattr(result, "as_dict") else dict(result)
    normalized = data.get("normalized") or {}
    status = data.get("status") or "unknown"
    status_code = data.get("status_code")
    ok = status == "ok" and (status_code is None or int(status_code) < 400)
    target = str(data.get("target") or "")
    input_type = str(data.get("input_type") or detect_module(target))
    confidence = 0.0
    reject_reason = ""
    if ok:
        confidence = 0.45
        if data.get("data"):
            confidence += 0.25
        if data.get("url"):
            confidence += 0.1
        if _entity_candidates(data.get("data"), data.get("text")):
            confidence += 0.2
    elif status == "missing_keys":
        reject_reason = "required API keys missing"
    else:
        reject_reason = str(data.get("error") or status)

    entities = [
        {"type": str(row.get("type") or ""), "value": str(row.get("value") or "")}
        for row in normalized.get("entities", [])
        if row.get("type") and row.get("value")
    ] or [{"type": input_type, "value": target}]
    for entity in _entity_candidates(data.get("url"), data.get("data"), data.get("text")):
        if entity not in entities:
            entities.append(entity)

    relations = [
        {
            "src_type": str(row.get("src_type") or ""),
            "src_value": str(row.get("src_value") or ""),
            "rel": str(row.get("rel") or ""),
            "dst_type": str(row.get("dst_type") or ""),
            "dst_value": str(row.get("dst_value") or ""),
        }
        for row in normalized.get("relations", [])
        if all(row.get(key) for key in ("src_type", "src_value", "rel", "dst_type", "dst_value"))
    ] or [
        {
            "src_type": input_type,
            "src_value": target,
            "rel": "observed_by",
            "dst_type": "source",
            "dst_value": str(data.get("source_id") or "adapter"),
        }
    ]
    for entity in entities[1:]:
        relation = {
            "src_type": input_type,
            "src_value": target,
            "rel": f"mentions_{entity['type']}",
            "dst_type": entity["type"],
            "dst_value": entity["value"],
        }
        if relation not in relations:
            relations.append(relation)

    normalized_findings = normalized.get("findings", [])
    parser_status = ""
    if normalized_findings:
        first = normalized_findings[0]
        if first.get("confidence") not in {None, ""}:
            confidence = float(first.get("confidence") or 0.0)
        reject_reason = str(first.get("reject_reason") or reject_reason)
        parser_status = str(first.get("status") or "")
        status = parser_status or status
    profile_url = ""
    if normalized_findings:
        profile_url = str(normalized_findings[0].get("profile_url") or "")
    timeline = [
        {
            "kind": str(row.get("kind") or "adapter_observed"),
            "entity_type": str(row.get("entity_type") or input_type),
            "entity_value": str(row.get("entity_value") or target),
            "source": str(row.get("source") or data.get("source_id") or "adapter"),
            "confidence": float(row.get("confidence") or confidence),
            "description": str(row.get("description") or ""),
        }
        for row in normalized.get("timeline", [])
    ]

    return NormalizedRecord(
        source_id=str(data.get("source_id") or "adapter"),
        target=target,
        status=status if parser_status or not ok else "exists",
        confidence=round(min(confidence, 1.0), 3),
        input_type=input_type,
        method=str(data.get("method") or "GET").upper(),
        url=str(data.get("url") or ""),
        profile_url=profile_url or str(data.get("url") or ""),
        status_code=status_code,
        headers=dict(data.get("headers") or {}),
        title=f"adapter={data.get('source_id')} status={status}",
        entities=entities,
        relations=relations,
        timeline=timeline,
        raw=data,
        reject_reason=reject_reason,
    )


def persist_normalized(
    record: NormalizedRecord,
    *,
    case_name: str,
    module: str = "adapter",
) -> dict[str, Any]:
    storage = Storage(settings.db_path(case_name))
    with storage.session() as session:
        case = Case(name=case_name, target=record.target, module=module)
        session.add(case)
        session.commit()
        session.refresh(case)
        if case.id is None:
            raise RuntimeError("case was not persisted")

        for entity in record.entities:
            add_entity_once(
                session,
                case_id=case.id,
                type=entity["type"],
                value=entity["value"],
            )
        add_entity_once(
            session,
            case_id=case.id,
            type="source",
            value=record.source_id,
        )
        for relation in record.relations:
            add_relation_once(session, case_id=case.id, **relation)
        for event in record.timeline:
            session.add(
                TimelineEvent(
                    case_id=case.id,
                    kind=event.get("kind", "adapter_observed"),
                    entity_type=event.get("entity_type", record.input_type),
                    entity_value=event.get("entity_value", record.target),
                    source_name=event.get("source", record.source_id),
                    confidence=float(event.get("confidence") or record.confidence),
                    description=event.get("description", ""),
                )
            )

        rejected = bool(record.reject_reason)
        record_source(
            session,
            case_id=case.id,
            name=record.source_id,
            url_main=record.url,
            category=module,
            rejected=rejected,
            notes=record.reject_reason or "normalized adapter output",
        )
        finding = Finding(
            case_id=case.id,
            source_name=record.source_id,
            source_id=record.source_id,
            entity_value=record.target,
            entity_type=record.input_type,
            finding_type="adapter_result",
            profile_url=record.profile_url or record.url,
            status=record.status,
            status_code=record.status_code,
            page_title=record.title,
            matched_markers="adapter:normalized",
            confidence=record.confidence,
            rejected=rejected,
            reject_reason=record.reject_reason,
        )
        session.add(finding)
        session.commit()
        session.refresh(finding)
        if finding.id is None:
            raise RuntimeError("finding was not persisted")
        finding_id = finding.id
        case_id = case.id

    capture_raw_result(
        storage,
        case_name=case_name,
        case_id=case_id,
        finding_id=finding_id,
        source_module=module,
        payload=record.as_dict(),
        url=record.url,
        final_url=record.url,
        http_status=record.status_code,
        confidence=record.confidence,
        name_hint=record.source_id,
        headers=record.headers,
        method=record.method,
    )
    return {"meta": {"case": case_name, "module": module}, "result": record.as_dict()}
