from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


CHAIN_ORDER = {"username": 10, "email": 20, "domain": 30, "wallet": 40}
WALLET_TYPES = {"wallet", "crypto_wallet", "bitcoin", "ethereum", "btc", "eth"}


@dataclass(frozen=True)
class PivotPlanStep:
    from_type: str
    from_value: str
    to_type: str
    target: str
    relation: str
    priority: int
    ready: bool
    independent_sources: int
    max_confidence: float
    command: str
    reason: str
    safety_gate: str
    blocked_reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _source_key(row: dict[str, Any]) -> str:
    return str(row.get("source_id") or row.get("source_name") or row.get("name") or "").strip()


def _entity_key(entity_type: str, value: str) -> tuple[str, str]:
    clean_type = str(entity_type or "").strip().lower()
    clean_value = str(value or "").strip()
    if clean_type in {"domain", "email", "username"}:
        clean_value = clean_value.lower().strip(".")
    return clean_type, clean_value


def _quote_arg(value: str) -> str:
    text = str(value or "")
    if not text:
        return '""'
    if any(char.isspace() for char in text) or '"' in text:
        return '"' + text.replace('"', '\\"') + '"'
    return text


def _entity_records(
    findings: list[dict[str, Any]],
    entities: list[dict[str, Any]],
) -> dict[tuple[str, str], dict[str, Any]]:
    records: dict[tuple[str, str], dict[str, Any]] = {}
    for entity in entities:
        key = _entity_key(str(entity.get("type") or ""), str(entity.get("value") or ""))
        if not key[0] or not key[1]:
            continue
        records.setdefault(
            key,
            {
                "type": key[0],
                "value": key[1],
                "sources": set(),
                "max_confidence": 0.0,
                "statuses": set(),
            },
        )

    for finding in findings:
        key = _entity_key(
            str(finding.get("entity_type") or ""),
            str(finding.get("entity_value") or ""),
        )
        if not key[0] or not key[1]:
            continue
        record = records.setdefault(
            key,
            {
                "type": key[0],
                "value": key[1],
                "sources": set(),
                "max_confidence": 0.0,
                "statuses": set(),
            },
        )
        status = str(finding.get("status") or "")
        record["statuses"].add(status)
        if finding.get("rejected") or status != "exists":
            continue
        source = _source_key(finding)
        if source:
            record["sources"].add(source)
        record["max_confidence"] = max(
            float(record["max_confidence"]),
            float(finding.get("confidence") or 0.0),
        )
    return records


def _ready(record: dict[str, Any], min_independent_sources: int) -> tuple[bool, str]:
    independent = len(record["sources"])
    if independent >= min_independent_sources:
        return True, ""
    if independent == 0:
        return False, "no confirmed source evidence for pivot seed"
    return False, "needs independent corroboration before automatic pivot"


def _step(
    record: dict[str, Any],
    *,
    to_type: str,
    target: str,
    relation: str,
    priority: int,
    command: str,
    reason: str,
    min_independent_sources: int,
) -> PivotPlanStep:
    ready, blocked = _ready(record, min_independent_sources)
    return PivotPlanStep(
        from_type=str(record["type"]),
        from_value=str(record["value"]),
        to_type=to_type,
        target=target,
        relation=relation,
        priority=priority,
        ready=ready,
        independent_sources=len(record["sources"]),
        max_confidence=round(float(record["max_confidence"]), 3),
        command=command,
        reason=reason,
        safety_gate="independent_corroboration_required",
        blocked_reason=blocked,
    )


def _steps_for_record(
    record: dict[str, Any],
    *,
    min_independent_sources: int,
) -> list[PivotPlanStep]:
    entity_type = str(record["type"])
    value = str(record["value"])
    quoted = _quote_arg(value)
    steps: list[PivotPlanStep] = []
    if entity_type == "username":
        steps.append(
            _step(
                record,
                to_type="email",
                target=value,
                relation="username_to_email_discovery",
                priority=90,
                command=f"bedniiosint search-run {quoted} --source contact_discovery,email_enrichment",
                reason="Use a corroborated username as a seed for public email/contact discovery.",
                min_independent_sources=min_independent_sources,
            )
        )
    if entity_type == "email" and "@" in value:
        localpart, domain = value.rsplit("@", 1)
        steps.append(
            _step(
                record,
                to_type="username",
                target=localpart,
                relation="email_to_localpart_username",
                priority=68,
                command=f"bedniiosint username {_quote_arg(localpart)} --case pivot-{_quote_arg(localpart)}",
                reason="Email localpart is a weak username pivot and must be treated as a candidate.",
                min_independent_sources=min_independent_sources,
            )
        )
        steps.append(
            _step(
                record,
                to_type="domain",
                target=domain,
                relation="email_to_domain",
                priority=85,
                command=f"bedniiosint pipeline-run {_quote_arg(domain)} domain",
                reason="Email domain can pivot into DNS, RDAP, CT, archive and business context.",
                min_independent_sources=min_independent_sources,
            )
        )
    if entity_type == "domain":
        steps.append(
            _step(
                record,
                to_type="wallet",
                target=value,
                relation="domain_to_wallet_mentions",
                priority=50,
                command=f"bedniiosint search-run {quoted} --source web_search,archive_discovery",
                reason="Search public pages and archives for wallet/address mentions tied to the domain.",
                min_independent_sources=min_independent_sources,
            )
        )
    if entity_type in WALLET_TYPES:
        steps.append(
            _step(
                record,
                to_type="wallet_context",
                target=value,
                relation="wallet_to_blockchain_context",
                priority=80,
                command=f"bedniiosint wallet {quoted}",
                reason="A corroborated wallet can be enriched through public blockchain lookup.",
                min_independent_sources=min_independent_sources,
            )
        )
    return steps


def build_case_pivot_plan(
    findings: list[dict[str, Any]],
    entities: list[dict[str, Any]],
    *,
    min_independent_sources: int = 2,
) -> dict[str, Any]:
    records = _entity_records(findings, entities)
    steps: list[PivotPlanStep] = []
    for record in records.values():
        steps.extend(_steps_for_record(record, min_independent_sources=min_independent_sources))
    steps.sort(
        key=lambda row: (
            not row.ready,
            CHAIN_ORDER.get(row.from_type, 99),
            -row.priority,
            row.from_value,
        )
    )
    ready_steps = [step for step in steps if step.ready]
    blocked_steps = [step for step in steps if not step.ready]
    return {
        "style": "case_pivot_chain",
        "safety_gate": "independent_corroboration_required",
        "min_independent_sources": int(min_independent_sources),
        "steps": [step.as_dict() for step in steps],
        "summary": {
            "entities": len(records),
            "steps": len(steps),
            "ready": len(ready_steps),
            "blocked": len(blocked_steps),
        },
        "next_ready": [step.as_dict() for step in ready_steps[:8]],
    }
