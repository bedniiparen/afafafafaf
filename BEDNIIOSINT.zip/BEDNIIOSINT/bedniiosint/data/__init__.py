"""Packaged data catalogs for BEDNIIOSINT."""
