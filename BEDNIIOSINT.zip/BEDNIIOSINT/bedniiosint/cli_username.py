from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table


console = Console()
username_app = typer.Typer(add_completion=False, help="Username investigation commands")


@username_app.command("run")
def username(
    target: str = typer.Argument(..., help="Username to investigate"),
    case: str = typer.Option("default-case", "--case", help="Case name"),
    html: bool = typer.Option(False, "--html", help="Write HTML report"),
    json_out: bool = typer.Option(False, "--json", help="Write JSON report"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out", help="Output dir"),
    category: list[str] | None = typer.Option(
        None, "--category", help="Limit username scan to one or more site categories"
    ),
    site: list[str] | None = typer.Option(
        None, "--site", help="Limit username scan to explicit site names"
    ),
    offset: int = typer.Option(0, "--offset", min=0),
    limit: int | None = typer.Option(None, "--limit", min=1),
    include_protected: bool = typer.Option(True, "--include-protected/--skip-protected"),
):
    """Run a username case across all sites in sites.json."""
    from .core.case import UsernameCase

    console.print(
        f"[bold cyan]BEDNIIOSINT[/] | case '[bold]{case}[/]' | target '[bold]{target}[/]'"
    )
    with console.status("Scanning + calibrating sites..."):
        summary = UsernameCase(
            case,
            target,
            categories=category,
            names=site,
            include_protected=include_protected,
            offset=offset,
            limit=limit,
        ).run()

    table = Table(title="Summary")
    table.add_column("Tier")
    table.add_column("Count")
    table.add_row("[green]High[/]", str(len(summary["high"])))
    table.add_row("[yellow]Medium[/]", str(len(summary["medium"])))
    table.add_row("[blue]Weak[/]", str(len(summary["weak"])))
    table.add_row("[red]Rejected (FP)[/]", str(len(summary["rejected"])))
    console.print(table)

    for row in summary["high"]:
        console.print(
            f"  [green]+[/] {row['site']:<16} {row['url']}  ([green]{row['confidence']:.2f}[/])"
        )

    out_dir.mkdir(parents=True, exist_ok=True)
    if json_out or not html:
        from .reports.json import write_json

        path = write_json(summary, out_dir / f"{case}.json")
        console.print(f"[dim]JSON ->[/] {path}")
    if html:
        from .reports.html import write_html

        path = write_html(summary, out_dir / f"{case}.html")
        console.print(f"[dim]HTML ->[/] {path}")


@username_app.command("sources")
def username_sources(
    category: list[str] | None = typer.Option(None, "--category"),
    site: list[str] | None = typer.Option(None, "--site"),
    offset: int = typer.Option(0, "--offset", min=0),
    limit: int | None = typer.Option(None, "--limit", min=1),
    include_protected: bool = typer.Option(True, "--include-protected/--skip-protected"),
):
    """Inspect username source catalog size, categories and selected scan chunk."""
    from .config import DEFAULT_SITES_FILE
    from .modules.username.scanner import load_sites, select_sites, site_catalog_stats

    sites = load_sites(DEFAULT_SITES_FILE)
    selected = select_sites(
        sites,
        categories=category,
        names=site,
        include_protected=include_protected,
        offset=offset,
        limit=limit,
    )
    payload = site_catalog_stats(sites)
    payload["selected"] = len(selected)
    payload["selected_names"] = list(selected)
    console.print(json.dumps(payload, indent=2, ensure_ascii=False))


@username_app.command("catalog-validate")
def username_catalog_validate(
    catalog: Path = typer.Argument(...),
):
    """Validate an external Sherlock/Maigret/WhatsMyName/Nexfil-style username catalog."""
    from .modules.username.catalog import import_site_catalog

    result = import_site_catalog(catalog)
    console.print(json.dumps(result.as_dict(), indent=2, ensure_ascii=False))


@username_app.command("catalog-merge")
def username_catalog_merge(
    catalogs: list[Path] = typer.Argument(...),
    base: Path | None = typer.Option(None, "--base", help="Base sites.json path"),
    out: Path = typer.Option(Path("sites-merged.json"), "--out"),
    overwrite: bool = typer.Option(False, "--overwrite"),
    dry_run: bool = typer.Option(False, "--dry-run"),
):
    """Merge external username catalogs into a scanner-compatible sites.json."""
    from .config import DEFAULT_SITES_FILE
    from .modules.username.catalog import merge_site_catalogs

    result = merge_site_catalogs(
        base or DEFAULT_SITES_FILE,
        catalogs,
        out,
        overwrite=overwrite,
        dry_run=dry_run,
    )
    console.print(json.dumps(result, indent=2, ensure_ascii=False))


@username_app.command("catalog-coverage")
def username_catalog_coverage_cmd(
    catalogs: list[Path] = typer.Argument(...),
    base: Path | None = typer.Option(None, "--base", help="Base sites.json path"),
    sample_limit: int = typer.Option(25, "--sample-limit", min=0),
):
    """Compare local username catalog coverage against external catalogs."""
    from .config import DEFAULT_SITES_FILE
    from .modules.username.catalog import username_catalog_coverage

    result = username_catalog_coverage(
        base or DEFAULT_SITES_FILE,
        catalogs,
        sample_limit=sample_limit,
    )
    console.print(json.dumps(result, indent=2, ensure_ascii=False), soft_wrap=True)
