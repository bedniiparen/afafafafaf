from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table


console = Console()
live_results_app = typer.Typer(add_completion=False, help="Live validation result commands")


@live_results_app.command("results")
def live_results(
    source: str | None = typer.Option(None, "--source", help="Filter by source id"),
    run_id: str | None = typer.Option(None, "--run-id", help="Filter by persisted run id"),
    export_format: str = typer.Option("json", "--format", help="Output format for --out/--json: json, markdown or csv"),
    markdown: bool = typer.Option(False, "--markdown", help="Print Markdown report"),
    out: Path | None = typer.Option(None, "--out", help="Write JSON, Markdown or CSV output to this path"),
    json_out: bool = typer.Option(False, "--json", help="Print full JSON result"),
    limit: int = typer.Option(100, "--limit", min=1),
):
    """Report persisted opt-in live validation results without printing secrets."""
    from .core.live_validation_results import (
        export_live_validation_history,
        live_validation_export_hash,
        live_validation_history,
        record_live_validation_audit_event,
        write_live_validation_export_manifest,
    )

    result = live_validation_history(source_id=source, run_id=run_id, limit=limit)
    selected_format = "json" if json_out else "markdown" if markdown else export_format
    try:
        output, content_type = export_live_validation_history(result, export_format=selected_format)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    export_requested = bool(out) or json_out or markdown or selected_format.lower() != "json"
    filters = {"source_id": source or "", "run_id": run_id or "", "limit": limit}
    output_bytes = output.encode("utf-8")
    digest = live_validation_export_hash(output_bytes)
    if out:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(output_bytes)
        if export_requested:
            manifest_path = out.with_name(f"{out.name}.manifest.json")
            audit_event = record_live_validation_audit_event(
                action="export",
                channel="cli",
                source_id=source,
                run_id=run_id,
                filters=filters,
                export_format=selected_format,
                matched=int(result["summary"].get("rows") or 0),
                affected=int(result["summary"].get("returned") or 0),
                output_path=str(out),
                output_sha256=str(digest["sha256"]),
                output_bytes=int(digest["bytes"]),
                manifest_path=str(manifest_path),
            )
            write_live_validation_export_manifest(
                manifest_path,
                content=output_bytes,
                export_format=selected_format,
                content_type=content_type,
                history=result,
                filters=filters,
                audit_event=audit_event,
                output_path=str(out),
            )
        console.print(f"[dim]Live validation results ->[/] {out}")
        if export_requested:
            console.print(f"[dim]Live validation export manifest ->[/] {manifest_path}")
        return
    if json_out or markdown or selected_format.lower() in {"json", "markdown", "md", "csv"} and selected_format.lower() != "json":
        if export_requested:
            record_live_validation_audit_event(
                action="export",
                channel="cli",
                source_id=source,
                run_id=run_id,
                filters=filters,
                export_format=selected_format,
                matched=int(result["summary"].get("rows") or 0),
                affected=int(result["summary"].get("returned") or 0),
                output_sha256=str(digest["sha256"]),
                output_bytes=int(digest["bytes"]),
            )
        console.print(output, markup=False, soft_wrap=True)
        return

    summary = result["summary"]
    table = Table(
        title=(
            "Live validation results: "
            f"{summary['rows']} rows, {summary['sources']} sources, "
            f"{summary['redacted_rows']} redacted"
        )
    )
    table.add_column("Recorded")
    table.add_column("Run")
    table.add_column("Source")
    table.add_column("Mode")
    table.add_column("Status")
    table.add_column("Target")
    table.add_column("Reason")
    for row in result["results"]:
        table.add_row(
            str(row.get("recorded_at") or ""),
            str(row.get("run_id") or ""),
            str(row.get("source_id") or ""),
            str(row.get("mode") or ""),
            str(row.get("status") or ""),
            str(row.get("target") or ""),
            str(row.get("reason") or ""),
        )
    console.print(table)


@live_results_app.command("results-cleanup")
def live_results_cleanup(
    source: str | None = typer.Option(None, "--source", help="Filter by source id"),
    run_id: str | None = typer.Option(None, "--run-id", help="Filter by persisted run id"),
    older_than_days: int | None = typer.Option(None, "--older-than-days", min=0, help="Match rows older than this many days"),
    before: str | None = typer.Option(None, "--before", help="Match rows before an ISO timestamp"),
    apply: bool = typer.Option(False, "--apply", help="Actually delete matched rows; default is dry-run"),
    json_out: bool = typer.Option(False, "--json", help="Print cleanup result as JSON"),
    limit: int = typer.Option(25, "--limit", min=1, help="Preview row limit"),
):
    """Dry-run or apply retention cleanup for persisted live validation history."""
    from .core.live_validation_results import cleanup_live_validation_results

    try:
        result = cleanup_live_validation_results(
            source_id=source,
            run_id=run_id,
            older_than_days=older_than_days,
            before=before,
            apply=apply,
            channel="cli",
        )
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc

    if json_out:
        console.print(
            json.dumps(result, indent=2, ensure_ascii=False, default=str),
            markup=False,
            soft_wrap=True,
        )
        return

    summary = result["summary"]
    table = Table(
        title=(
            "Live validation cleanup: "
            f"{summary['matched']} matched, {summary['deleted']} deleted, "
            f"{'applied' if summary['applied'] else 'dry-run'}"
        )
    )
    table.add_column("Recorded")
    table.add_column("Run")
    table.add_column("Source")
    table.add_column("Mode")
    table.add_column("Status")
    table.add_column("Reason")
    for row in result["results"][:limit]:
        table.add_row(
            str(row.get("recorded_at") or ""),
            str(row.get("run_id") or ""),
            str(row.get("source_id") or ""),
            str(row.get("mode") or ""),
            str(row.get("status") or ""),
            str(row.get("reason") or ""),
        )
    console.print(table)


@live_results_app.command("results-audit")
def live_results_audit(
    action: str | None = typer.Option(None, "--action", help="Filter by action, e.g. export or cleanup"),
    source: str | None = typer.Option(None, "--source", help="Filter by source id"),
    run_id: str | None = typer.Option(None, "--run-id", help="Filter by persisted run id"),
    json_out: bool = typer.Option(False, "--json", help="Print audit result as JSON"),
    limit: int = typer.Option(100, "--limit", min=1),
):
    """Report audit events for live-validation export and cleanup actions."""
    from .core.live_validation_results import live_validation_audit_history

    result = live_validation_audit_history(
        action=action,
        source_id=source,
        run_id=run_id,
        limit=limit,
    )
    if json_out:
        console.print(
            json.dumps(result, indent=2, ensure_ascii=False, default=str),
            markup=False,
            soft_wrap=True,
        )
        return

    summary = result["summary"]
    table = Table(
        title=(
            "Live validation audit: "
            f"{summary['rows']} rows, {summary['affected']} affected"
        )
    )
    table.add_column("Created")
    table.add_column("Action")
    table.add_column("Channel")
    table.add_column("Run")
    table.add_column("Source")
    table.add_column("Matched")
    table.add_column("Affected")
    table.add_column("Format")
    table.add_column("Output")
    table.add_column("SHA-256")
    for row in result["results"]:
        table.add_row(
            str(row.get("created_at") or ""),
            str(row.get("action") or ""),
            str(row.get("channel") or ""),
            str(row.get("run_id") or ""),
            str(row.get("source_id") or ""),
            str(row.get("matched") or 0),
            str(row.get("affected") or 0),
            str(row.get("export_format") or ""),
            str(row.get("output_path") or ""),
            str(row.get("output_sha256") or "")[:16],
        )
    console.print(table)


@live_results_app.command("results-verify")
def live_results_verify(
    manifest: Path = typer.Argument(..., help="Sidecar live-results export manifest JSON"),
    export: Path | None = typer.Option(None, "--export", help="Export file to verify; inferred when omitted"),
    audit_log: bool = typer.Option(False, "--audit-log", help="Also compare against the local live-validation audit DB"),
    json_out: bool = typer.Option(False, "--json", help="Print verification result as JSON"),
):
    """Verify a live-validation export file against its sidecar manifest."""
    from .core.live_validation_results import verify_live_validation_export_manifest

    result = verify_live_validation_export_manifest(
        manifest,
        export_path=export,
        check_audit_log=audit_log,
    )
    if json_out:
        console.print(
            json.dumps(result, indent=2, ensure_ascii=False, default=str),
            markup=False,
            soft_wrap=True,
        )
        if not result["valid"]:
            raise typer.Exit(1)
        return

    table = Table(
        title=(
            "Live validation export verification: "
            f"{'valid' if result['valid'] else 'invalid'}"
        )
    )
    table.add_column("Check")
    table.add_column("OK")
    for name, ok in result["checks"].items():
        table.add_row(str(name), "yes" if ok else "no")
    console.print(table)
    if result["errors"]:
        for error in result["errors"]:
            console.print(f"[red]{error}[/]")
    if not result["valid"]:
        raise typer.Exit(1)
