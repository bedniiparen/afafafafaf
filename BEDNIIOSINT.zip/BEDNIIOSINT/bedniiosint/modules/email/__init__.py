"""Email OSINT module."""
