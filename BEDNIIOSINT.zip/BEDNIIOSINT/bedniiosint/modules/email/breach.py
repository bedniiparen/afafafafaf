from __future__ import annotations

import os

import httpx

from ...core.http import request


def hibp_breaches(email: str, api_key: str | None = None) -> dict:
    key = api_key or os.getenv("HIBP_API_KEY")
    if not key:
        return {"available": False, "reason": "no API key (set HIBP_API_KEY)"}
    url = (
        "https://haveibeenpwned.com/api/v3/breachedaccount/"
        f"{email}?truncateResponse=false"
    )
    try:
        with httpx.Client(timeout=15) as client:
            response = request(
                "GET",
                url,
                client=client,
                headers={"hibp-api-key": key, "User-Agent": "BEDNIIOSINT"},
            )
            if response.status_code == 404:
                return {"available": True, "breached": False, "breaches": []}
            if response.status_code == 200:
                data = response.json()
                return {
                    "available": True,
                    "breached": True,
                    "breaches": [item.get("Name") for item in data],
                }
            return {"available": False, "reason": f"HTTP {response.status_code}"}
    except httpx.HTTPError as exc:
        return {"available": False, "reason": str(exc)}
