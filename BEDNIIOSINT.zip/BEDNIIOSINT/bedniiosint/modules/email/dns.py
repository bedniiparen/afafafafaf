from __future__ import annotations

import httpx

try:
    import dns.resolver

    _HAS_DNS = True
except Exception:
    _HAS_DNS = False


def _doh_query(domain: str, rtype: str) -> list[str]:
    try:
        with httpx.Client(timeout=8, headers={"User-Agent": "BEDNIIOSINT"}) as client:
            response = client.get(
                "https://dns.google/resolve",
                params={"name": domain, "type": rtype},
            )
            if response.status_code != 200:
                return []
            data = response.json()
    except Exception:
        return []

    answers = data.get("Answer") or []
    return [str(item.get("data", "")).strip() for item in answers if item.get("data")]


def _query(domain: str, rtype: str) -> list[str]:
    if not _HAS_DNS:
        return _doh_query(domain, rtype)
    try:
        answers = dns.resolver.resolve(domain, rtype, lifetime=8)
        rows = [record.to_text() for record in answers]
    except Exception:
        rows = []
    return rows or _doh_query(domain, rtype)


def mx_records(domain: str) -> list[str]:
    return _query(domain, "MX")


def txt_records(domain: str) -> list[str]:
    return _query(domain, "TXT")


def spf_record(domain: str) -> str | None:
    for value in txt_records(domain):
        if "v=spf1" in value:
            return value.strip('"')
    return None


def dmarc_record(domain: str) -> str | None:
    for value in txt_records(f"_dmarc.{domain}"):
        if "v=DMARC1" in value:
            return value.strip('"')
    return None
