from __future__ import annotations

import re
from dataclasses import dataclass, field

from ...core.confidence import ScoreSignal, UniversalConfidenceContext, score_signals, score_universal
from ...core.source_record import source_reliability
from . import breach, dns, gravatar

_EMAIL_RE = re.compile(r"^[a-zA-Z0-9_.+-]+@([a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)$")


@dataclass
class EmailResult:
    email: str
    valid_format: bool
    domain: str = ""
    mx: list[str] = field(default_factory=list)
    spf: str | None = None
    dmarc: str | None = None
    deliverable_hint: bool = False
    gravatar_md5: str = ""
    gravatar_exists: bool = False
    gravatar_profile: dict | None = None
    breach: dict = field(default_factory=dict)
    confidence: float = 0.0
    matched_markers: list[str] = field(default_factory=list)
    reject_reason: str = ""


def analyze_email(email: str, hibp_key: str | None = None) -> EmailResult:
    match = _EMAIL_RE.match(email.strip())
    if not match:
        scoring = score_signals(
            [ScoreSignal("valid_format", 0.3, False, "invalid email format")],
            reject_reason="invalid email format",
        )
        return EmailResult(
            email=email,
            valid_format=False,
            confidence=scoring.confidence,
            matched_markers=scoring.matched_markers,
            reject_reason=scoring.reject_reason,
        )
    domain = match.group(1).lower()
    mx = dns.mx_records(domain)
    spf = dns.spf_record(domain)
    dmarc = dns.dmarc_record(domain)
    hashes = gravatar.gravatar_hashes(email)
    profile = gravatar.gravatar_profile(email)

    result = EmailResult(
        email=email,
        valid_format=True,
        domain=domain,
        mx=mx,
        spf=spf,
        dmarc=dmarc,
        deliverable_hint=bool(mx),
        gravatar_md5=hashes["md5"],
        gravatar_exists=profile is not None,
        gravatar_profile=profile,
        breach=breach.hibp_breaches(email, hibp_key),
    )
    independent_sources = 1 + int(bool(result.mx)) + int(result.gravatar_exists) + int(
        bool(result.breach.get("breached"))
    )
    scoring = score_universal(
        [
            ScoreSignal("valid_format", 0.3, result.valid_format),
            ScoreSignal("mx_records", 0.3, bool(result.mx), "no MX records"),
            ScoreSignal(
                "gravatar_profile",
                0.2,
                result.gravatar_exists,
                "no Gravatar profile",
            ),
            ScoreSignal(
                "breach_record",
                0.2,
                bool(result.breach.get("breached")),
                "no breach record",
            ),
        ],
        context=UniversalConfidenceContext(
            target_type="email",
            independent_sources=independent_sources,
            source_reliability=source_reliability("email-analyzer"),
            weak_data=not bool(result.mx),
            reputation_only=bool(result.breach.get("breached"))
            and not (result.mx or result.gravatar_exists),
        ),
    )
    result.confidence = scoring.confidence
    result.matched_markers = scoring.matched_markers
    result.reject_reason = scoring.reject_reason
    return result
