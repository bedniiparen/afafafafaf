from __future__ import annotations

import hashlib
import logging

import httpx

from ...core.http import request
from ...evidence.hashing import md5_text

logger = logging.getLogger(__name__)


def gravatar_hashes(email: str) -> dict[str, str]:
    norm = email.strip().lower()
    return {
        "md5": md5_text(norm),
        "sha256": hashlib.sha256(norm.encode()).hexdigest(),
    }


def gravatar_profile(email: str) -> dict | None:
    digest = gravatar_hashes(email)["md5"]
    try:
        with httpx.Client(timeout=10) as client:
            response = request("GET", f"https://www.gravatar.com/{digest}.json", client=client)
            if response.status_code == 200:
                return response.json()
    except Exception as exc:
        logger.debug("gravatar lookup failed: %s", exc)
    return None


def gravatar_avatar_url(email: str) -> str:
    return f"https://www.gravatar.com/avatar/{gravatar_hashes(email)['md5']}?d=404"
