from __future__ import annotations

from dataclasses import dataclass, field

from ...core.confidence import ScoreSignal, UniversalConfidenceContext, score_signals, score_universal
from ...core.source_record import source_reliability

try:
    import phonenumbers
    from phonenumbers import NumberParseException, carrier, geocoder
    from phonenumbers import timezone as pn_tz

    _HAS_PN = True
except Exception:
    _HAS_PN = False


@dataclass
class PhoneResult:
    raw: str
    valid: bool = False
    e164: str = ""
    country_code: int | None = None
    country: str = ""
    location: str = ""
    carrier: str = ""
    timezones: list[str] = field(default_factory=list)
    line_type: str = ""
    confidence: float = 0.0
    matched_markers: list[str] = field(default_factory=list)
    reject_reason: str = ""
    note: str = ""


_TYPE_MAP = {
    0: "FIXED_LINE",
    1: "MOBILE",
    2: "FIXED_OR_MOBILE",
    3: "TOLL_FREE",
    4: "PREMIUM_RATE",
    5: "SHARED_COST",
    6: "VOIP",
    7: "PERSONAL",
    9: "PAGER",
    10: "UAN",
    27: "EMERGENCY",
}


def analyze_phone(number: str, region: str | None = None) -> PhoneResult:
    if not _HAS_PN:
        scoring = score_signals(
            [ScoreSignal("phonenumbers_available", 1.0, False, "dependency missing")],
            reject_reason="install 'phonenumbers' for phone OSINT",
        )
        return PhoneResult(
            raw=number,
            note="install 'phonenumbers' for phone OSINT",
            confidence=scoring.confidence,
            matched_markers=scoring.matched_markers,
            reject_reason=scoring.reject_reason,
        )
    try:
        parsed = phonenumbers.parse(number, region)
    except NumberParseException as exc:
        scoring = score_signals(
            [ScoreSignal("valid_number", 0.5, False, "parse error")],
            reject_reason=f"parse error: {exc}",
        )
        return PhoneResult(
            raw=number,
            note=f"parse error: {exc}",
            confidence=scoring.confidence,
            matched_markers=scoring.matched_markers,
            reject_reason=scoring.reject_reason,
        )

    valid = phonenumbers.is_valid_number(parsed)
    result = PhoneResult(
        raw=number,
        valid=valid,
        e164=phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164),
        country_code=parsed.country_code,
        country=geocoder.region_code_for_number(parsed) or "",
        location=geocoder.description_for_number(parsed, "en"),
        carrier=carrier.name_for_number(parsed, "en"),
        timezones=list(pn_tz.time_zones_for_number(parsed)),
        line_type=_TYPE_MAP.get(phonenumbers.number_type(parsed), "UNKNOWN"),
    )
    independent_sources = sum(
        1
        for matched in (
            valid,
            bool(result.carrier),
            bool(result.location),
            bool(result.timezones),
        )
        if matched
    )
    scoring = score_universal(
        [
            ScoreSignal("valid_number", 0.5, valid, "number failed validation"),
            ScoreSignal("carrier", 0.2, bool(result.carrier), "carrier unknown"),
            ScoreSignal("location", 0.2, bool(result.location), "location unknown"),
            ScoreSignal("timezone", 0.1, bool(result.timezones), "timezone unknown"),
        ],
        context=UniversalConfidenceContext(
            target_type="phone",
            independent_sources=max(1, independent_sources),
            source_reliability=source_reliability("phone-analyzer"),
            weak_data=valid and not (result.carrier or result.location),
        ),
        reject_reason="" if valid else "phone number failed validation",
    )
    result.confidence = scoring.confidence
    result.matched_markers = scoring.matched_markers
    result.reject_reason = scoring.reject_reason
    return result
