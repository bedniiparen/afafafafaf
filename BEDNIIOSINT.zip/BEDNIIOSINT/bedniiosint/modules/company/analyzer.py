from __future__ import annotations

import os
from dataclasses import dataclass, field

import httpx

from ...core.confidence import ScoreSignal, UniversalConfidenceContext, score_universal
from ...config import settings
from ...core.http import HttpPolicy, request
from ...core.source_record import source_reliability
from ..domain.analyzer import analyze_domain


@dataclass
class CompanyResult:
    name: str
    guessed_domain: str = ""
    domain_data: dict = field(default_factory=dict)
    registry_matches: list = field(default_factory=list)
    confidence: float = 0.0
    matched_markers: list[str] = field(default_factory=list)
    reject_reason: str = ""
    note: str = ""


def _slug(name: str) -> str:
    return "".join(ch for ch in name.lower() if ch.isalnum())


def opencorporates_search(name: str) -> list[dict]:
    token = os.getenv("OPENCORPORATES_API_TOKEN")
    if not token:
        return []
    try:
        policy = HttpPolicy(timeout=settings.timeout, max_retries=0)
        with httpx.Client(timeout=policy.timeout, headers={"User-Agent": policy.user_agent}) as client:
            response = request(
                "GET",
                "https://api.opencorporates.com/v0.4/companies/search",
                client=client,
                policy=policy,
                params={"q": name, "api_token": token},
            )
            if response.status_code == 200:
                companies = response.json().get("results", {}).get("companies", [])
                return [
                    {
                        "name": item["company"].get("name"),
                        "jurisdiction": item["company"].get("jurisdiction_code"),
                        "number": item["company"].get("company_number"),
                        "status": item["company"].get("current_status"),
                        "incorporation_date": item["company"].get("incorporation_date"),
                    }
                    for item in companies[:10]
                ]
    except httpx.HTTPError:
        pass
    return []


def analyze_company(name: str, domain: str | None = None) -> CompanyResult:
    result = CompanyResult(name=name)
    result.guessed_domain = domain or f"{_slug(name)}.com"
    try:
        domain_result = analyze_domain(result.guessed_domain, resolve_subs=False)
        result.domain_data = {
            "domain": domain_result.domain,
            "has_dns": bool(
                domain_result.dns.get("A") or domain_result.dns.get("AAAA")
            ),
            "registrar": domain_result.rdap.get("registrar", ""),
            "registration_date": domain_result.rdap.get("registration_date"),
            "mx": domain_result.dns.get("MX", []),
        }
    except Exception as exc:
        result.note = f"domain enrich failed: {exc}"

    result.registry_matches = opencorporates_search(name)
    independent_sources = sum(
        1
        for matched in (
            bool(result.domain_data.get("has_dns")),
            bool(result.registry_matches),
            bool(result.domain_data.get("registration_date")),
        )
        if matched
    )
    scoring = score_universal(
        [
            ScoreSignal(
                "domain_dns",
                0.4,
                bool(result.domain_data.get("has_dns")),
                result.note or "guessed domain has no A/AAAA records",
            ),
            ScoreSignal(
                "registry_match",
                0.4,
                bool(result.registry_matches),
                "no registry matches",
            ),
            ScoreSignal(
                "domain_registration",
                0.2,
                bool(result.domain_data.get("registration_date")),
                "no domain registration date",
            ),
        ],
        context=UniversalConfidenceContext(
            target_type="company",
            independent_sources=max(1, independent_sources),
            source_reliability=source_reliability(
                "company-analyzer",
                success_count=0 if result.note else 1,
                error_count=1 if result.note else 0,
            ),
            weak_data=independent_sources <= 1,
            reputation_only=bool(result.registry_matches)
            and not result.domain_data.get("has_dns"),
        ),
    )
    result.confidence = scoring.confidence
    result.matched_markers = scoring.matched_markers
    result.reject_reason = scoring.reject_reason
    return result
