"""Company OSINT module."""
