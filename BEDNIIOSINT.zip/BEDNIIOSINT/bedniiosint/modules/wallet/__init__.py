"""Crypto wallet OSINT module."""
