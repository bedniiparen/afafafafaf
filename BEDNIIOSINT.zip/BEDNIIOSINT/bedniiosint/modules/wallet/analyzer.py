from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

import httpx

from ...core.confidence import ScoreSignal, UniversalConfidenceContext, score_signals, score_universal
from ...core.http import request
from ...core.source_record import source_reliability

_BTC_RE = re.compile(r"^(bc1[a-z0-9]{25,62}|[13][a-km-zA-HJ-NP-Z1-9]{25,39})$")
_ETH_RE = re.compile(r"^0x[a-fA-F0-9]{40}$")


@dataclass
class WalletResult:
    address: str
    chain: str = "unknown"
    valid_format: bool = False
    found: bool = False
    balance: float | None = None
    tx_count: int | None = None
    first_seen: str = ""
    last_seen: str = ""
    confidence: float = 0.0
    matched_markers: list[str] = field(default_factory=list)
    reject_reason: str = ""
    note: str = ""
    raw: dict = field(default_factory=dict)


def detect_chain(addr: str) -> str:
    if _ETH_RE.match(addr):
        return "ethereum"
    if _BTC_RE.match(addr):
        return "bitcoin"
    return "unknown"


def _stale_activity(value: str, *, years: int = 5) -> bool:
    if not value:
        return False
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - parsed).days > years * 365


def _btc_lookup(addr: str) -> WalletResult:
    result = WalletResult(address=addr, chain="bitcoin", valid_format=True)
    try:
        with httpx.Client(timeout=20, headers={"User-Agent": "BEDNIIOSINT"}) as client:
            response = request(
                "GET",
                f"https://blockchain.info/rawaddr/{addr}?limit=1",
                client=client,
            )
            if response.status_code == 200:
                data = response.json()
                result.found = True
                result.balance = data.get("final_balance", 0) / 1e8
                result.tx_count = data.get("n_tx")
                result.raw = {"total_received": data.get("total_received", 0) / 1e8}
            else:
                result.note = f"HTTP {response.status_code}"
    except httpx.HTTPError as exc:
        result.note = str(exc)
    return result


def _eth_lookup(addr: str) -> WalletResult:
    result = WalletResult(address=addr, chain="ethereum", valid_format=True)
    try:
        with httpx.Client(timeout=20, headers={"User-Agent": "BEDNIIOSINT"}) as client:
            response = request(
                "GET",
                f"https://api.blockchair.com/ethereum/dashboards/address/{addr}",
                client=client,
            )
            if response.status_code == 200:
                data = response.json().get("data", {}).get(addr.lower(), {})
                addr_data = data.get("address", {})
                if addr_data:
                    result.found = True
                    balance = addr_data.get("balance")
                    result.balance = (int(balance) / 1e18) if balance else 0.0
                    result.tx_count = addr_data.get("transaction_count")
                    result.first_seen = addr_data.get("first_seen_receiving", "") or ""
                    result.last_seen = addr_data.get("last_seen_spending", "") or ""
            else:
                result.note = f"HTTP {response.status_code}"
    except httpx.HTTPError as exc:
        result.note = str(exc)
    return result


def analyze_wallet(address: str) -> WalletResult:
    address = address.strip()
    chain = detect_chain(address)
    if chain == "bitcoin":
        result = _btc_lookup(address)
    elif chain == "ethereum":
        result = _eth_lookup(address)
    else:
        scoring = score_signals(
            [ScoreSignal("valid_address", 0.3, False, "unrecognized address format")],
            reject_reason="unrecognized address format",
        )
        return WalletResult(
            address=address,
            note="unrecognized address format",
            confidence=scoring.confidence,
            matched_markers=scoring.matched_markers,
            reject_reason=scoring.reject_reason,
        )
    source_name = f"{result.chain}-explorer"
    independent_sources = sum(
        1
        for matched in (result.valid_format, result.found, (result.tx_count or 0) > 0)
        if matched
    )
    scoring = score_universal(
        [
            ScoreSignal("valid_address", 0.3, result.valid_format),
            ScoreSignal(
                "explorer_record",
                0.4,
                result.found,
                result.note or "address not found by explorer",
            ),
            ScoreSignal(
                "transactions",
                0.3,
                (result.tx_count or 0) > 0,
                "no transactions returned",
            ),
        ],
        context=UniversalConfidenceContext(
            target_type="wallet",
            independent_sources=max(1, independent_sources),
            source_reliability=source_reliability(
                source_name,
                success_count=1 if result.found else 0,
                error_count=1 if result.note and not result.found else 0,
            ),
            weak_data=result.found and not result.tx_count,
            stale=_stale_activity(result.last_seen or result.first_seen),
        ),
    )
    result.confidence = scoring.confidence
    result.matched_markers = scoring.matched_markers
    result.reject_reason = scoring.reject_reason
    return result
