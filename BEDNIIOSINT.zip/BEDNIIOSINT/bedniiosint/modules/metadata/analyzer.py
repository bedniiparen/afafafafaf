from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ...core.confidence import ScoreSignal, score_signals
from ...evidence.hashing import sha256_file
from .exiftool import exiftool_available, run_exiftool


@dataclass
class MetadataResult:
    path: str
    sha256: str
    file_size: int
    exiftool_used: bool
    gps: dict | None = None
    device: str = ""
    software: str = ""
    created: str = ""
    modified: str = ""
    confidence: float = 0.0
    matched_markers: list[str] = field(default_factory=list)
    reject_reason: str = ""
    raw: dict = field(default_factory=dict)


def _g(data: dict, *keys: str, default=""):
    for key in keys:
        for full_key, value in data.items():
            if full_key.split(":")[-1].lower() == key.lower():
                return value
    return default


def analyze_file(path: str | Path) -> MetadataResult:
    p = Path(path)
    digest = sha256_file(p)
    size = p.stat().st_size
    raw = run_exiftool(p) or {}

    gps = None
    lat = _g(raw, "GPSLatitude", default=None)
    lon = _g(raw, "GPSLongitude", default=None)
    if lat is not None and lon is not None:
        gps = {"lat": lat, "lon": lon}

    exiftool_used = exiftool_available() and bool(raw)
    device = f"{_g(raw, 'Make')} {_g(raw, 'Model')}".strip()
    software = _g(raw, "Software", "Creator", "Producer")
    created = _g(raw, "CreateDate", "DateTimeOriginal", "CreationDate")
    modified = _g(raw, "ModifyDate", "FileModifyDate")
    scoring = score_signals(
        [
            ScoreSignal(
                "file_hash",
                0.5,
                bool(digest),
                "file hash unavailable",
            ),
            ScoreSignal(
                "exiftool_metadata",
                0.2,
                exiftool_used,
                "exiftool unavailable or no metadata",
            ),
            ScoreSignal(
                "identity_metadata",
                0.2,
                bool(device or software),
                "no device/software metadata",
            ),
            ScoreSignal(
                "temporal_metadata",
                0.1,
                bool(created or modified),
                "no timestamp metadata",
            ),
        ]
    )
    return MetadataResult(
        path=str(p),
        sha256=digest,
        file_size=size,
        exiftool_used=exiftool_used,
        gps=gps,
        device=device,
        software=software,
        created=created,
        modified=modified,
        confidence=scoring.confidence,
        matched_markers=scoring.matched_markers,
        reject_reason=scoring.reject_reason,
        raw=raw,
    )
