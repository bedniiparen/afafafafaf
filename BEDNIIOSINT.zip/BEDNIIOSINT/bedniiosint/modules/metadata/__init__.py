"""File metadata module."""
