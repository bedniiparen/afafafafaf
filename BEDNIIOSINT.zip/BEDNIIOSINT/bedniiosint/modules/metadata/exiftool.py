from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path


def exiftool_available() -> bool:
    return shutil.which("exiftool") is not None


def run_exiftool(path: Path) -> dict | None:
    if not exiftool_available():
        return None
    try:
        proc = subprocess.run(
            ["exiftool", "-json", "-n", "-G", str(path)],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            data = json.loads(proc.stdout)
            return data[0] if data else None
    except Exception:
        return None
    return None
