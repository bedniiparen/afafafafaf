from __future__ import annotations

import httpx

from ...config import settings
from ...core.http import HttpPolicy, request


def crtsh_subdomains(domain: str) -> list[str]:
    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    try:
        policy = HttpPolicy(timeout=settings.timeout, max_retries=0)
        with httpx.Client(timeout=policy.timeout, headers={"User-Agent": policy.user_agent}) as client:
            response = request("GET", url, client=client, policy=policy)
            if response.status_code != 200:
                return []
            data = response.json()
    except Exception:
        return []

    subs: set[str] = set()
    for row in data:
        for name in str(row.get("name_value", "")).splitlines():
            name = name.strip().lstrip("*.").lower()
            if name.endswith(domain) and "@" not in name:
                subs.add(name)
    return sorted(subs)
