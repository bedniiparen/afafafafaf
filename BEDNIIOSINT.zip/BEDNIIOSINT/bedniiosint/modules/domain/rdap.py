from __future__ import annotations

import httpx

from ...config import settings
from ...core.http import HttpPolicy, request


def rdap_lookup(domain: str) -> dict:
    try:
        policy = HttpPolicy(timeout=settings.timeout, max_retries=0)
        with httpx.Client(
            follow_redirects=True,
            timeout=policy.timeout,
            headers={"User-Agent": policy.user_agent},
        ) as client:
            response = request(
                "GET",
                f"https://rdap.org/domain/{domain}",
                client=client,
                policy=policy,
            )
            if response.status_code != 200:
                return {"available": False, "reason": f"HTTP {response.status_code}"}
            data = response.json()
    except Exception as exc:
        return {"available": False, "reason": str(exc)}

    events = {
        event.get("eventAction"): event.get("eventDate")
        for event in data.get("events", [])
    }
    nameservers = [item.get("ldhName") for item in data.get("nameservers", [])]
    registrar = ""
    for entity in data.get("entities", []):
        if "registrar" not in entity.get("roles", []):
            continue
        for value in entity.get("vcardArray", [[], []])[1]:
            if value and value[0] == "fn":
                registrar = value[3]
    return {
        "available": True,
        "registrar": registrar,
        "registration_date": events.get("registration"),
        "expiration_date": events.get("expiration"),
        "last_changed": events.get("last changed"),
        "nameservers": nameservers,
        "status": data.get("status", []),
    }
