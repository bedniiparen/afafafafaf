from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from urllib.parse import urlparse

from ...core.confidence import ScoreSignal, UniversalConfidenceContext, score_universal
from ...core.source_record import source_reliability
from .dns_records import collect_dns
from .rdap import rdap_lookup
from .subdomains import enumerate_subdomains


@dataclass
class DomainResult:
    domain: str
    dns: dict = field(default_factory=dict)
    rdap: dict = field(default_factory=dict)
    subdomains: list = field(default_factory=list)
    confidence: float = 0.0
    matched_markers: list[str] = field(default_factory=list)
    reject_reason: str = ""


def _normalize_domain(domain: str) -> str:
    value = domain.strip().lower()
    parsed = urlparse(value if "://" in value else f"//{value}")
    return (parsed.netloc or parsed.path).split("/")[0]


def analyze_domain(domain: str, resolve_subs: bool = True) -> DomainResult:
    domain = _normalize_domain(domain)
    with ThreadPoolExecutor(max_workers=3, thread_name_prefix="bedniiosint-domain") as executor:
        dns_future = executor.submit(collect_dns, domain)
        rdap_future = executor.submit(rdap_lookup, domain)
        subs_future = executor.submit(enumerate_subdomains, domain, resolve_subs)
        try:
            dns_data = dns_future.result()
        except Exception:
            dns_data = {}
        try:
            rdap = rdap_future.result()
        except Exception as exc:
            rdap = {"available": False, "reason": str(exc)}
        try:
            subs = subs_future.result()
        except Exception:
            subs = []
    independent_sources = sum(
        1
        for matched in (
            bool(dns_data.get("A") or dns_data.get("AAAA")),
            bool(rdap.get("available")),
            bool(dns_data.get("MX")),
            bool(subs),
        )
        if matched
    )
    scoring = score_universal(
        [
            ScoreSignal(
                "address_records",
                0.25,
                bool(dns_data.get("A") or dns_data.get("AAAA")),
                "no A/AAAA records",
            ),
            ScoreSignal(
                "rdap_record",
                0.25,
                bool(rdap.get("available")),
                str(rdap.get("reason") or "no RDAP record"),
            ),
            ScoreSignal("mx_records", 0.25, bool(dns_data.get("MX")), "no MX records"),
            ScoreSignal("subdomains", 0.25, bool(subs), "no subdomains found"),
        ],
        context=UniversalConfidenceContext(
            target_type="domain",
            independent_sources=max(1, independent_sources),
            source_reliability=source_reliability("domain-analyzer"),
            weak_data=independent_sources <= 1,
        ),
    )
    return DomainResult(
        domain=domain,
        dns=dns_data,
        rdap=rdap,
        subdomains=subs,
        confidence=scoring.confidence,
        matched_markers=scoring.matched_markers,
        reject_reason=scoring.reject_reason,
    )
