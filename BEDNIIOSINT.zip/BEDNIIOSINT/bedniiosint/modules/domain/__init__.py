"""Domain OSINT module."""
