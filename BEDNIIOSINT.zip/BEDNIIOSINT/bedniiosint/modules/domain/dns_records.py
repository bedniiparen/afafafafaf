from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

from ..email import dns as edns


def collect_dns(domain: str) -> dict:
    checks = {
        "A": lambda: edns._query(domain, "A"),
        "AAAA": lambda: edns._query(domain, "AAAA"),
        "MX": lambda: edns.mx_records(domain),
        "NS": lambda: edns._query(domain, "NS"),
        "TXT": lambda: edns.txt_records(domain),
        "SPF": lambda: edns.spf_record(domain),
        "DMARC": lambda: edns.dmarc_record(domain),
    }
    with ThreadPoolExecutor(max_workers=len(checks), thread_name_prefix="bedniiosint-dns") as executor:
        futures = {key: executor.submit(func) for key, func in checks.items()}
        return {
            key: future.result() if future.exception() is None else ([] if key != "SPF" and key != "DMARC" else None)
            for key, future in futures.items()
        }
