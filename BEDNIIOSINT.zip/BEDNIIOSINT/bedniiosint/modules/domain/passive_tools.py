from __future__ import annotations

import json
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from urllib.parse import urlparse


SUPPORTED_TOOLS = {"amass", "subfinder"}
DOMAIN_RE = re.compile(r"^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}$", re.IGNORECASE)


@dataclass
class PassiveToolRun:
    tool: str
    status: str
    command: list[str] = field(default_factory=list)
    subdomains: list[str] = field(default_factory=list)
    error: str = ""
    returncode: int | None = None

    def as_dict(self) -> dict:
        return {
            "tool": self.tool,
            "status": self.status,
            "command": self.command,
            "subdomains": self.subdomains,
            "error": self.error,
            "returncode": self.returncode,
        }


def normalize_domain(domain: str) -> str:
    value = domain.strip().lower()
    parsed = urlparse(value if "://" in value else f"//{value}")
    return (parsed.netloc or parsed.path).split("/")[0]


def passive_tool_available(tool: str) -> bool:
    return tool in SUPPORTED_TOOLS and shutil.which(tool) is not None


def run_passive_tool(domain: str, tool: str, *, timeout: float = 60.0) -> PassiveToolRun:
    domain = normalize_domain(domain)
    if tool not in SUPPORTED_TOOLS:
        return PassiveToolRun(tool=tool, status="unsupported", error="unsupported passive tool")
    command = _command(tool, domain)
    if shutil.which(tool) is None:
        return PassiveToolRun(tool=tool, status="missing_tool", command=command)
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            check=False,
            encoding="utf-8",
            errors="replace",
            shell=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        return PassiveToolRun(
            tool=tool,
            status="timeout",
            command=command,
            error=str(exc),
        )
    subdomains = _parse_output(domain, tool, completed.stdout)
    status = "ok" if completed.returncode == 0 else "error"
    return PassiveToolRun(
        tool=tool,
        status=status,
        command=command,
        subdomains=subdomains,
        error="" if status == "ok" else completed.stderr.strip()[:1000],
        returncode=completed.returncode,
    )


def run_passive_tools(
    domain: str,
    *,
    tools: list[str] | None = None,
    timeout: float = 60.0,
) -> dict:
    selected = tools or ["amass", "subfinder"]
    runs = [run_passive_tool(domain, tool, timeout=timeout) for tool in selected]
    seen: set[str] = set()
    merged = []
    for run in runs:
        for subdomain in run.subdomains:
            if subdomain not in seen:
                seen.add(subdomain)
                merged.append({"subdomain": subdomain, "source": run.tool, "resolves": None, "a": []})
    return {
        "domain": normalize_domain(domain),
        "mode": "passive_external_tools",
        "tools": [run.as_dict() for run in runs],
        "subdomains": merged,
    }


def _command(tool: str, domain: str) -> list[str]:
    if tool == "amass":
        return ["amass", "enum", "-passive", "-d", domain]
    if tool == "subfinder":
        return ["subfinder", "-silent", "-d", domain, "-json"]
    return [tool]


def _parse_output(domain: str, tool: str, stdout: str) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()
    for line in stdout.splitlines():
        candidate = _candidate_from_line(tool, line)
        if not candidate:
            continue
        candidate = candidate.strip().lower().rstrip(".")
        if _valid_subdomain(domain, candidate) and candidate not in seen:
            seen.add(candidate)
            found.append(candidate)
    return found


def _candidate_from_line(tool: str, line: str) -> str:
    line = line.strip()
    if not line:
        return ""
    if tool == "subfinder" and line.startswith("{"):
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            return ""
        return str(data.get("host") or data.get("subdomain") or data.get("value") or "")
    return line.split()[0]


def _valid_subdomain(domain: str, value: str) -> bool:
    domain = normalize_domain(domain)
    return value != domain and value.endswith(f".{domain}") and bool(DOMAIN_RE.match(value))
