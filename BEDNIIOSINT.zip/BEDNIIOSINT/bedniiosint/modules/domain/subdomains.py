from __future__ import annotations

from ..email import dns as edns
from .ct_logs import crtsh_subdomains


def enumerate_subdomains(domain: str, resolve: bool = True) -> list[dict]:
    subs = crtsh_subdomains(domain)
    out = []
    for subdomain in subs:
        entry = {"subdomain": subdomain, "resolves": None, "a": []}
        if resolve:
            records = edns._query(subdomain, "A")
            entry["a"] = records
            entry["resolves"] = bool(records)
        out.append(entry)
    return out
