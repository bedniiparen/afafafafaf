from __future__ import annotations

import ipaddress
import logging
from dataclasses import dataclass, field

import httpx

from ...core.confidence import ScoreSignal, UniversalConfidenceContext, score_signals, score_universal
from ...config import settings
from ...core.http import HttpPolicy, request
from ...core.source_record import source_reliability
from ..email import dns as edns

logger = logging.getLogger(__name__)


@dataclass
class IPResult:
    ip: str
    valid: bool = False
    version: int = 0
    is_private: bool = False
    country: str = ""
    region: str = ""
    city: str = ""
    org: str = ""
    asn: str = ""
    isp: str = ""
    reverse_dns: list[str] = field(default_factory=list)
    confidence: float = 0.0
    matched_markers: list[str] = field(default_factory=list)
    reject_reason: str = ""
    note: str = ""


def analyze_ip(ip: str) -> IPResult:
    ip = ip.strip()
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        scoring = score_signals(
            [ScoreSignal("valid_ip", 0.3, False, "invalid IP address")],
            reject_reason="invalid IP address",
        )
        return IPResult(
            ip=ip,
            note="invalid IP address",
            confidence=scoring.confidence,
            matched_markers=scoring.matched_markers,
            reject_reason=scoring.reject_reason,
        )

    result = IPResult(ip=ip, valid=True, version=addr.version, is_private=addr.is_private)
    if addr.is_private:
        result.note = "private/reserved address - no public geolocation"
        scoring = score_signals(
            [
                ScoreSignal("valid_ip", 0.3, True),
                ScoreSignal(
                    "public_geolocation",
                    0.4,
                    False,
                    "private/reserved address",
                ),
                ScoreSignal("asn", 0.3, False, "private/reserved address"),
            ],
            reject_reason=result.note,
        )
        result.confidence = scoring.confidence
        result.matched_markers = scoring.matched_markers
        result.reject_reason = scoring.reject_reason
        return result

    try:
        policy = HttpPolicy(timeout=settings.timeout, max_retries=0)
        with httpx.Client(timeout=policy.timeout, headers={"User-Agent": policy.user_agent}) as client:
            response = request("GET", f"https://ipwho.is/{ip}", client=client, policy=policy)
            if response.status_code == 200:
                data = response.json()
                if data.get("success", True):
                    connection = data.get("connection") or {}
                    result.country = data.get("country", "")
                    result.region = data.get("region", "")
                    result.city = data.get("city", "")
                    result.org = connection.get("org", "")
                    result.isp = connection.get("isp", "")
                    asn = connection.get("asn", "")
                    result.asn = f"AS{asn}" if asn and not str(asn).startswith("AS") else str(asn)
                else:
                    result.note = data.get("message", "")
    except httpx.HTTPError as exc:
        result.note = str(exc)

    try:
        result.reverse_dns = edns._query(addr.reverse_pointer, "PTR")
    except Exception as exc:
        logger.debug("ip analyzer: reverse DNS lookup failed: %s", exc)

    independent_sources = sum(
        1
        for matched in (
            result.valid,
            bool(result.country),
            bool(result.asn),
            bool(result.reverse_dns),
        )
        if matched
    )
    scoring = score_universal(
        [
            ScoreSignal("valid_ip", 0.3, result.valid),
            ScoreSignal(
                "public_geolocation",
                0.4,
                bool(result.country),
                result.note or "no country returned",
            ),
            ScoreSignal("asn", 0.3, bool(result.asn), "no ASN returned"),
        ],
        context=UniversalConfidenceContext(
            target_type="ip",
            independent_sources=max(1, independent_sources),
            source_reliability=source_reliability(
                "ip-analyzer",
                success_count=0 if result.note else 1,
                error_count=1 if result.note else 0,
            ),
            weak_data=not (result.country and result.asn),
        ),
    )
    result.confidence = scoring.confidence
    result.matched_markers = scoring.matched_markers
    result.reject_reason = scoring.reject_reason
    return result
