from __future__ import annotations

import asyncio
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from collections import Counter

import httpx

from ...config import DEFAULT_SITES_FILE, settings
from ...core.confidence import ConfidenceInput, score_username
from ...core.http import HttpPolicy, async_request
from ...core.source_reliability import reliability_from_calibration, text_similarity
from . import validators


@dataclass
class SiteResult:
    site_name: str
    url_main: str
    category: str
    probe_url: str
    display_url: str
    status: str
    status_code: int | None
    final_url: str
    redirected: bool
    page_title: str
    matched_markers: list[str]
    confidence: float
    source_reliability: float
    reliability_note: str
    control_passed: bool
    body_sha256: str = ""
    body_len: int = 0


@dataclass
class _Probe:
    status_code: int | None
    final_url: str
    redirected: bool
    text: str
    title: str
    ok: bool
    method: str = "GET"


def load_sites(path: Path | None = None) -> dict[str, dict[str, Any]]:
    data = json.loads(Path(path or DEFAULT_SITES_FILE).read_text(encoding="utf-8-sig"))
    return data["sites"]


def site_catalog_stats(sites: dict[str, dict[str, Any]]) -> dict[str, Any]:
    categories = Counter(
        str(site.get("cat") or site.get("category") or "misc") for site in sites.values()
    )
    protected = sum(1 for site in sites.values() if site.get("protection"))
    regex_checked = sum(1 for site in sites.values() if site.get("regexCheck"))
    return {
        "sites": len(sites),
        "categories": dict(sorted(categories.items())),
        "protected": protected,
        "regex_checked": regex_checked,
        "supports_external_catalog": True,
        "scale_target": "500-1000+ sites via compatible sites.json files",
    }


def select_sites(
    sites: dict[str, dict[str, Any]],
    *,
    categories: list[str] | None = None,
    names: list[str] | None = None,
    include_protected: bool = True,
    include_disabled: bool = False,
    offset: int = 0,
    limit: int | None = None,
) -> dict[str, dict[str, Any]]:
    category_set = {item.lower() for item in categories or [] if item}
    name_set = {item.lower() for item in names or [] if item}
    selected: list[tuple[str, dict[str, Any]]] = []
    for name, site in sites.items():
        category = str(site.get("cat") or site.get("category") or "misc").lower()
        if category_set and category not in category_set:
            continue
        if name_set and name.lower() not in name_set:
            continue
        if not include_disabled and site.get("disabled"):
            continue
        if not include_protected and site.get("protection"):
            continue
        selected.append((name, site))
    start = max(0, int(offset or 0))
    end = start + limit if limit is not None else None
    return dict(selected[start:end])


def _extract_title(html: str) -> str:
    lo = html.lower()
    i = lo.find("<title")
    if i == -1:
        return ""
    start = html.find(">", i)
    end = lo.find("</title>", start)
    if start == -1 or end == -1:
        return ""
    return html[start + 1 : end].strip()[:300]


def build_url(template: str, username: str) -> str:
    return template.replace("{account}", username).replace("{username}", username).replace("{}", username)


def _check_template(site: dict[str, Any]) -> str:
    return site.get("uri_check") or site.get("urlProbe") or site["url"]


def _interpolate_sherlock(value: Any, username: str) -> Any:
    if isinstance(value, str):
        return build_url(value, username)
    if isinstance(value, dict):
        return {key: _interpolate_sherlock(item, username) for key, item in value.items()}
    if isinstance(value, list):
        return [_interpolate_sherlock(item, username) for item in value]
    return value


def _error_types(site: dict[str, Any]) -> list[str]:
    raw = site.get("errorType", "status_code")
    if isinstance(raw, list):
        return [str(item).strip().lower() for item in raw if str(item or "").strip()]
    return [str(raw or "status_code").strip().lower()]


def _probe_method(site: dict[str, Any]) -> str:
    explicit = str(site.get("request_method") or "").strip().upper()
    if explicit:
        return explicit
    error_types = set(_error_types(site))
    needs_body = bool(
        {"message", "response_url"} & error_types
        or site.get("errorMsg")
        or site.get("e_string")
        or site.get("m_string")
    )
    if "status_code" in error_types and not needs_body:
        return "HEAD"
    return "GET"


WAF_HIT_MESSAGES: tuple[tuple[str, str], ...] = (
    (
        "cloudflare_challenge",
        ".loading-spinner{visibility:hidden}body.no-js .challenge-running{display:none}",
    ),
    ("cloudflare_error", '<span id="challenge-error-text">'),
    ("aws_waf", "AwsWafIntegration.forceRefreshToken"),
    ("perimeterx", '{return l.onPageView}}),Object.defineProperty(r,"perimeterxIdentifiers"'),
)


def _waf_marker(text: str) -> str:
    for marker_name, needle in WAF_HIT_MESSAGES:
        if needle and needle in text:
            return f"waf:{marker_name}"
    return ""


async def _do_probe(
    client: httpx.AsyncClient,
    site: dict[str, Any],
    username: str,
    policy: HttpPolicy | None = None,
) -> _Probe:
    url = build_url(_check_template(site), username)
    method = _probe_method(site)
    headers = site.get("headers", {})
    follow_redirects = "response_url" not in set(_error_types(site))
    try:
        if method == "POST":
            kwargs: dict[str, Any]
            if site.get("request_payload") is not None:
                kwargs = {"json": _interpolate_sherlock(site.get("request_payload"), username)}
            else:
                body_tpl = site.get("post_body") or json.dumps({})
                kwargs = {"content": build_url(str(body_tpl), username)}
            resp = await async_request(
                "POST",
                url,
                client=client,
                headers=headers,
                policy=policy,
                follow_redirects=follow_redirects,
                **kwargs,
            )
        elif method in {"GET", "HEAD", "PUT"}:
            request_kwargs: dict[str, Any] = {}
            if method == "PUT" and site.get("request_payload") is not None:
                request_kwargs["json"] = _interpolate_sherlock(site.get("request_payload"), username)
            resp = await async_request(
                method,
                url,
                client=client,
                headers=headers,
                policy=policy,
                follow_redirects=follow_redirects,
                **request_kwargs,
            )
        else:
            return _Probe(None, url, False, "", "", ok=False, method=method)
    except (httpx.HTTPError, ValueError):
        return _Probe(None, url, False, "", "", ok=False, method=method)

    text = resp.text or ""
    return _Probe(
        status_code=resp.status_code,
        final_url=str(resp.url),
        redirected=str(resp.url) != url,
        text=text,
        title=_extract_title(text),
        ok=True,
        method=method,
    )


def _as_list(v: Any) -> list[str]:
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def _looks_like_missing_page(text: str) -> bool:
    normalized = " ".join(text.lower().split())
    return "page not found" in normalized and "this page no longer exists" in normalized


def classify(site: dict[str, Any], probe: _Probe, username: str) -> tuple[str, list[str]]:
    if not probe.ok:
        return "unknown", []

    markers: list[str] = []
    text = probe.text
    waf_marker = _waf_marker(text)
    if waf_marker:
        return "waf", [waf_marker]
    if _looks_like_missing_page(text):
        return "not_exists", ["global_missing:page_not_found"]

    error_types = set(_error_types(site))

    e_strings = _as_list(site.get("e_string"))
    for marker in e_strings:
        if marker and marker in text:
            markers.append(f"e_string:{marker[:40]}")

    m_strings = _as_list(site.get("m_string")) + _as_list(site.get("errorMsg"))
    missing_hit = next((marker for marker in m_strings if marker and marker in text), None)

    if "response_url" in error_types:
        err_url = build_url(site.get("errorUrl", ""), username)
        if err_url and probe.final_url.rstrip("/") == err_url.rstrip("/"):
            return "not_exists", markers
        if probe.status_code and probe.status_code < 400:
            return "exists", markers
        return "not_exists", markers

    if "message" in error_types or e_strings or m_strings:
        if e_strings and markers:
            return "exists", markers
        if missing_hit:
            return "not_exists", markers + [f"m_string:{missing_hit[:40]}"]
        if probe.status_code and probe.status_code < 400:
            return "exists", markers
        if probe.status_code in (404, 410):
            return "not_exists", markers
        return "unknown", markers

    e_code = site.get("e_code")
    m_code = site.get("m_code")
    e_codes = set(_as_list(e_code))
    m_codes = set(_as_list(m_code))
    if e_codes and probe.status_code in e_codes:
        return "exists", markers + [f"e_code:{probe.status_code}"]
    if m_codes and probe.status_code in m_codes:
        return "not_exists", markers + [f"m_code:{probe.status_code}"]
    if probe.status_code is not None and probe.status_code < 400:
        return "exists", markers
    if probe.status_code in (404, 410):
        return "not_exists", markers
    return "unknown", markers


async def scan_site(
    client: httpx.AsyncClient,
    site_name: str,
    site: dict[str, Any],
    username: str,
    sem: asyncio.Semaphore,
    *,
    policy: HttpPolicy | None = None,
) -> SiteResult | None:
    display_tpl = site.get("uri_pretty") or site.get("url") or _check_template(site)
    url_main = site.get("urlMain") or site.get("url_main", "")
    category = site.get("cat") or site.get("category", "misc")

    clean_user = validators.strip_bad_chars(username, site.get("strip_bad_char"))
    if not validators.passes_regex(clean_user, site.get("regexCheck")):
        return None

    async with sem:
        real = await _do_probe(client, site, clean_user, policy=policy)
        controls_claimed = 0
        sims: list[float] = []
        controls_run = 0

        for _ in range(settings.control_usernames):
            ctrl = validators.random_control_username(settings.control_length)
            if not validators.passes_regex(ctrl, site.get("regexCheck")):
                continue
            controls_run += 1
            cp = await _do_probe(client, site, ctrl, policy=policy)
            c_status, _ = classify(site, cp, ctrl)
            if c_status == "exists":
                controls_claimed += 1
            if real.text or cp.text:
                sims.append(text_similarity(real.text, cp.text))

    avg_sim = sum(sims) / len(sims) if sims else 0.0
    reliability, note = reliability_from_calibration(
        controls_claimed_exist=controls_claimed,
        controls_total=controls_run,
        avg_similarity_real_vs_control=avg_sim,
    )
    control_passed = controls_run > 0 and controls_claimed == 0 and avg_sim <= 0.97
    status, markers = classify(site, real, clean_user)

    marker_text = " ".join(markers)
    notfound_absent = "m_string" not in marker_text and "m_code" not in marker_text
    found_marker = any(marker.startswith(("e_string", "e_code")) for marker in markers)
    scoring = score_username(
        ConfidenceInput(
            status_is_exists=status == "exists",
            username_in_final_url=validators.username_in_url(clean_user, real.final_url),
            notfound_marker_absent=notfound_absent,
            found_marker_present=found_marker,
            control_passed=control_passed,
            source_reliability=reliability,
        )
    )

    body_sha = hashlib.sha256(real.text.encode("utf-8", "ignore")).hexdigest()
    return SiteResult(
        site_name=site_name,
        url_main=url_main,
        category=category,
        probe_url=build_url(_check_template(site), clean_user),
        display_url=build_url(display_tpl, clean_user),
        status=status,
        status_code=real.status_code,
        final_url=real.final_url,
        redirected=real.redirected,
        page_title=real.title,
        matched_markers=markers + scoring.matched_markers,
        confidence=scoring.confidence,
        source_reliability=reliability,
        reliability_note=note,
        control_passed=control_passed,
        body_sha256=body_sha,
        body_len=len(real.text),
    )


async def scan_username(
    username: str,
    sites: dict[str, dict[str, Any]],
    *,
    categories: list[str] | None = None,
    names: list[str] | None = None,
    include_protected: bool = True,
    include_disabled: bool = False,
    offset: int = 0,
    limit: int | None = None,
    policy: HttpPolicy | None = None,
) -> list[SiteResult]:
    selected_sites = select_sites(
        sites,
        categories=categories,
        names=names,
        include_protected=include_protected,
        include_disabled=include_disabled,
        offset=offset,
        limit=limit,
    )
    sem = asyncio.Semaphore(settings.max_concurrency)
    limits = httpx.Limits(max_connections=settings.max_concurrency)
    async with httpx.AsyncClient(
        follow_redirects=True,
        timeout=policy.timeout if policy is not None else settings.timeout,
        headers={"User-Agent": (policy.user_agent if policy is not None else settings.user_agent)},
        limits=limits,
    ) as client:
        tasks = [
            scan_site(client, name, site, username, sem, policy=policy)
            for name, site in selected_sites.items()
        ]
        results = await asyncio.gather(*tasks)
    return [result for result in results if result is not None]
