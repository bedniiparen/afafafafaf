from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .scanner import load_sites, site_catalog_stats


REQUIRED_SITE_FIELDS = {"url"}


@dataclass
class CatalogIssue:
    severity: str
    site: str
    message: str

    def as_dict(self) -> dict[str, str]:
        return {"severity": self.severity, "site": self.site, "message": self.message}


@dataclass
class CatalogImportResult:
    source: str
    total: int
    valid: int
    invalid: int
    duplicates: int
    sites: dict[str, dict[str, Any]] = field(default_factory=dict)
    issues: list[CatalogIssue] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "total": self.total,
            "valid": self.valid,
            "invalid": self.invalid,
            "duplicates": self.duplicates,
            "issues": [issue.as_dict() for issue in self.issues],
            "sites": len(self.sites),
        }


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _merge_engine_site(site: dict[str, Any], engines: dict[str, Any]) -> dict[str, Any]:
    engine_name = str(site.get("engine") or "").strip()
    if not engine_name:
        return dict(site)
    engine = engines.get(engine_name)
    if not isinstance(engine, dict) or not isinstance(engine.get("site"), dict):
        return dict(site)
    merged = dict(engine["site"])
    merged.update(site)
    return merged


def _infer_site_name(site: dict[str, Any], index: int) -> str:
    explicit = site.get("name") or site.get("site") or site.get("id")
    if explicit:
        return str(explicit)
    url = str(_pick(site, "url", "uri", "uri_pretty", "uri_check", "urlProbe", "urlMain") or "")
    parsed = urlparse(url if "://" in url else f"https://{url}")
    host = parsed.netloc.lower().removeprefix("www.")
    base = host.split(".", 1)[0] if host else f"site_{index}"
    path_tokens = [
        token.lower()
        for token in re.split(r"[^A-Za-z0-9]+", parsed.path)
        if token
        and "{" not in token
        and token.lower() not in {"@", "u", "user", "users", "profile", "profiles"}
    ]
    suffix = "_" + path_tokens[0] if path_tokens else ""
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{base}{suffix}").strip("_") or f"site_{index}"


def _site_items(data: Any) -> list[tuple[str, dict[str, Any]]]:
    if (
        isinstance(data, dict)
        and isinstance(data.get("sites"), dict)
        and isinstance(data["sites"].get("sites"), dict)
    ):
        data = data["sites"]
    engines = data.get("engines", {}) if isinstance(data, dict) else {}
    if not isinstance(engines, dict):
        engines = {}
    if isinstance(data, dict) and isinstance(data.get("sites"), dict):
        return [
            (str(name), _merge_engine_site(dict(site), engines))
            for name, site in data["sites"].items()
            if isinstance(site, dict)
        ]
    if isinstance(data, dict) and isinstance(data.get("sites"), list):
        rows = []
        for index, site in enumerate(data["sites"], start=1):
            if not isinstance(site, dict):
                continue
            name = _infer_site_name(site, index)
            if name:
                rows.append((str(name), _merge_engine_site(dict(site), engines)))
        return rows
    if isinstance(data, list):
        rows = []
        for index, site in enumerate(data, start=1):
            if not isinstance(site, dict):
                continue
            name = _infer_site_name(site, index)
            if name:
                rows.append((str(name), dict(site)))
        return rows
    if isinstance(data, dict):
        return [
            (str(name), dict(site))
            for name, site in data.items()
            if isinstance(site, dict)
        ]
    return []


def _pick(site: dict[str, Any], *names: str) -> Any:
    for name in names:
        if name in site and _has_value(site[name]):
            return site[name]
    return None


def _has_value(value: Any) -> bool:
    return value is not None and value != ""


def _resolve_site_template(value: Any, site: dict[str, Any]) -> Any:
    if not _has_value(value):
        return value
    text = str(value)
    replacements = {
        "urlMain": _pick(site, "urlMain", "url_main", "main_url", "home") or "",
        "urlSubpath": site.get("urlSubpath") or "",
    }
    for key, replacement in replacements.items():
        text = text.replace("{" + key + "}", str(replacement))
    return re.sub(r"(?<!:)//+", "/", text)


TAG_CATEGORY_MAP = {
    "anime": "gaming",
    "auto": "hobby",
    "bookmarks": "links",
    "books": "books",
    "career": "business",
    "crypto": "finance",
    "design": "art",
    "discussion": "forum",
    "education": "education",
    "fintech": "finance",
    "forum": "forum",
    "freelance": "business",
    "hacking": "security",
    "links": "links",
    "maps": "maps",
    "mastodon": "social",
    "medicine": "health",
    "movies": "video",
    "nft": "finance",
    "photo": "images",
    "porn": "adult",
    "q&a": "forum",
    "reading": "books",
    "research": "education",
    "review": "reviews",
    "sharing": "files",
    "sport": "sports",
    "stock": "images",
    "streaming": "video",
    "travel": "travel",
    "webcam": "adult",
    "wiki": "wiki",
    "writing": "blog",
}

DIRECT_TAG_CATEGORIES = {
    "archived",
    "art",
    "blog",
    "business",
    "coding",
    "dating",
    "finance",
    "gaming",
    "health",
    "hobby",
    "music",
    "news",
    "political",
    "shopping",
    "social",
    "tech",
    "video",
}

COUNTRY_TAGS = {
    "ar",
    "au",
    "be",
    "bg",
    "br",
    "by",
    "ca",
    "cn",
    "cz",
    "de",
    "eg",
    "es",
    "fr",
    "gb",
    "gr",
    "in",
    "ir",
    "it",
    "jp",
    "kr",
    "kz",
    "nl",
    "pk",
    "pl",
    "pt",
    "ru",
    "sg",
    "th",
    "tr",
    "ua",
    "us",
    "vn",
}


def _tag_values(tags: Any) -> list[str]:
    if isinstance(tags, str):
        values = [tags]
    elif isinstance(tags, list):
        values = tags
    else:
        return []
    return [str(tag).strip().lower() for tag in values if str(tag or "").strip()]


def _category_from_tags(tags: Any) -> str:
    for tag in _tag_values(tags):
        if tag in COUNTRY_TAGS:
            continue
        if tag in DIRECT_TAG_CATEGORIES:
            return tag
        if tag in TAG_CATEGORY_MAP:
            return TAG_CATEGORY_MAP[tag]
    return ""


def normalize_site(name: str, site: dict[str, Any], *, source_label: str) -> dict[str, Any]:
    clean: dict[str, Any] = {}
    url = _pick(site, "url", "uri", "uri_pretty", "uri_check", "urlProbe", "urlMain") or ""
    url = _resolve_site_template(url, site)
    check = _pick(site, "uri_check", "urlProbe", "check_uri", "url_probe")
    check = _resolve_site_template(check, site)
    pretty = _pick(site, "uri_pretty", "url")
    pretty = _resolve_site_template(pretty, site)
    clean["url"] = str(url)
    if check:
        clean["uri_check"] = str(check)
    if pretty and str(pretty) != clean["url"]:
        clean["uri_pretty"] = str(pretty)
    main = _pick(site, "urlMain", "url_main", "main_url", "home")
    main = _resolve_site_template(main, site)
    if main:
        clean["urlMain"] = str(main)
    category = _pick(site, "cat", "category", "type") or _category_from_tags(site.get("tags"))
    clean["cat"] = str(category or "misc").lower()
    nexfil_test = str(site.get("test") or site.get("nexfil_test") or "").strip().lower()
    nexfil_data = site.get("data") if "data" in site else site.get("nexfil_data")
    error_type = _pick(site, "errorType", "error_type", "checkType")
    if not error_type and nexfil_test == "string" and _has_value(nexfil_data):
        error_type = "message"
    error_type = error_type or "status_code"
    if isinstance(error_type, list):
        clean["errorType"] = [str(item) for item in error_type if _has_value(item)] or ["status_code"]
    else:
        clean["errorType"] = str(error_type)

    for key in (
        "e_code",
        "m_code",
        "e_string",
        "m_string",
        "presenseStrs",
        "presenceStrs",
        "absenceStrs",
        "errorMsg",
        "errors",
        "errorUrl",
        "regexCheck",
        "test",
        "data",
        "nexfil_test",
        "nexfil_data",
        "request_method",
        "requestHeadOnly",
        "headers",
        "post_body",
        "request_payload",
        "strip_bad_char",
        "engine",
        "urlSubpath",
        "username_claimed",
        "usernameClaimed",
        "username_unclaimed",
        "usernameUnclaimed",
        "protection",
        "isNSFW",
        "tags",
        "rank",
        "alexaRank",
        "disabled",
    ):
        if key in site and _has_value(site[key]):
            clean[key] = site[key]
    if "errorCode" in site and _has_value(site["errorCode"]) and "m_code" not in clean:
        clean["m_code"] = site["errorCode"]
    if "absenceStrs" in clean and "m_string" not in clean:
        clean["m_string"] = clean["absenceStrs"]
    if "presenseStrs" in clean and "e_string" not in clean:
        clean["e_string"] = clean["presenseStrs"]
    if "presenceStrs" in clean and "e_string" not in clean:
        clean["e_string"] = clean["presenceStrs"]
    if nexfil_test == "string" and _has_value(nexfil_data) and "m_string" not in clean:
        clean["m_string"] = nexfil_data
    if "usernameClaimed" in clean and "username_claimed" not in clean:
        clean["username_claimed"] = clean["usernameClaimed"]
    if "alexaRank" in clean and "rank" not in clean:
        clean["rank"] = clean["alexaRank"]
    if clean.get("requestHeadOnly") is False and "request_method" not in clean:
        clean["request_method"] = "GET"
    clean["provenance"] = {
        "source": source_label,
        "original_name": name,
    }
    return clean


def validate_site(name: str, site: dict[str, Any]) -> list[CatalogIssue]:
    issues: list[CatalogIssue] = []
    missing = [field for field in REQUIRED_SITE_FIELDS if not site.get(field)]
    for field in missing:
        issues.append(CatalogIssue("error", name, f"missing required field {field}"))
    url = str(site.get("url") or "")
    check = str(site.get("uri_check") or site.get("urlProbe") or url)
    if "{}" not in url and "{account}" not in url and "{username}" not in url:
        issues.append(CatalogIssue("warning", name, "url has no username placeholder"))
    if "{}" not in check and "{account}" not in check and "{username}" not in check:
        issues.append(CatalogIssue("warning", name, "check URL has no username placeholder"))
    error_types = site.get("errorType")
    if not isinstance(error_types, list):
        error_types = [error_types]
    if "message" in {str(item) for item in error_types} and not (
        site.get("e_string") or site.get("m_string") or site.get("errorMsg")
    ):
        issues.append(CatalogIssue("warning", name, "message errorType has no markers"))
    return issues


def import_site_catalog(path: Path, *, source_label: str | None = None) -> CatalogImportResult:
    label = source_label or path.stem
    items = _site_items(_read_json(path))
    sites: dict[str, dict[str, Any]] = {}
    issues: list[CatalogIssue] = []
    duplicates = 0
    invalid = 0
    seen: set[str] = set()
    for raw_name, raw_site in items:
        name = raw_name.strip()
        if not name:
            continue
        key = name.lower()
        if key in seen:
            duplicates += 1
            issues.append(CatalogIssue("warning", name, "duplicate in import source"))
            continue
        seen.add(key)
        site = normalize_site(name, raw_site, source_label=label)
        site_issues = validate_site(name, site)
        issues.extend(site_issues)
        if any(issue.severity == "error" for issue in site_issues):
            invalid += 1
            continue
        sites[name] = site
    return CatalogImportResult(
        source=str(path),
        total=len(items),
        valid=len(sites),
        invalid=invalid,
        duplicates=duplicates,
        sites=sites,
        issues=issues,
    )


def merge_site_catalogs(
    base_path: Path,
    import_paths: list[Path],
    out_path: Path,
    *,
    overwrite: bool = False,
    dry_run: bool = False,
) -> dict[str, Any]:
    base_sites = load_sites(base_path)
    merged = dict(base_sites)
    imports = [import_site_catalog(path) for path in import_paths]
    added = 0
    replaced = 0
    skipped = 0
    existing = {name.lower(): name for name in merged}
    for imported in imports:
        for name, site in imported.sites.items():
            key = name.lower()
            if key in existing and not overwrite:
                skipped += 1
                continue
            if key in existing:
                current_name = existing[key]
                current_site = merged[current_name]
                current_provenance = (
                    current_site.get("provenance")
                    if isinstance(current_site.get("provenance"), dict)
                    else {}
                )
                if overwrite and not current_provenance.get("source"):
                    skipped += 1
                    continue
                merged[current_name] = site
                replaced += 1
            else:
                merged[name] = site
                existing[key] = name
                added += 1

    payload = {
        "license": [
            "Merged username site catalog. Preserve upstream attribution and licenses.",
            "Sherlock imports are MIT licensed; WhatsMyName-derived rows are CC BY-SA 4.0.",
            "Maigret and Nexfil imports are MIT licensed.",
            "Each imported site row includes provenance.source and provenance.original_name.",
        ],
        "schema_version": "0.3",
        "sites": merged,
    }
    if not dry_run:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "base": str(base_path),
        "output": str(out_path),
        "dry_run": dry_run,
        "added": added,
        "replaced": replaced,
        "skipped": skipped,
        "imports": [item.as_dict() for item in imports],
        "stats": site_catalog_stats(merged),
    }


def username_catalog_coverage(
    base_path: Path,
    import_paths: list[Path],
    *,
    sample_limit: int = 25,
) -> dict[str, Any]:
    base_sites = load_sites(base_path)
    base_keys = {name.lower(): name for name in base_sites}
    imports = [import_site_catalog(path) for path in import_paths]
    rows: list[dict[str, Any]] = []
    all_missing: dict[str, dict[str, Any]] = {}
    all_overlap: set[str] = set()
    for imported in imports:
        missing = []
        overlap = []
        missing_by_category: dict[str, int] = {}
        for name, site in imported.sites.items():
            key = name.lower()
            if key in base_keys:
                overlap.append(name)
                all_overlap.add(base_keys[key])
                continue
            missing.append(name)
            all_missing.setdefault(name, site)
            category = str(site.get("cat") or "misc")
            missing_by_category[category] = missing_by_category.get(category, 0) + 1
        rows.append(
            {
                "source": imported.source,
                "valid": imported.valid,
                "invalid": imported.invalid,
                "duplicates": imported.duplicates,
                "overlap": len(overlap),
                "missing": len(missing),
                "coverage": round(len(overlap) / imported.valid, 3) if imported.valid else 0.0,
                "missing_by_category": dict(sorted(missing_by_category.items())),
                "missing_sample": sorted(missing)[: max(0, sample_limit)],
            }
        )

    total_external_valid = sum(item.valid for item in imports)
    total_overlap = sum(row["overlap"] for row in rows)
    return {
        "base": str(base_path),
        "base_stats": site_catalog_stats(base_sites),
        "imports": rows,
        "summary": {
            "base_sites": len(base_sites),
            "imports": len(imports),
            "external_valid": total_external_valid,
            "overlap": total_overlap,
            "unique_overlap": len(all_overlap),
            "unique_missing": len(all_missing),
            "coverage": round(total_overlap / total_external_valid, 3)
            if total_external_valid
            else 0.0,
            "potential_total_after_merge": len(base_sites) + len(all_missing),
        },
        "missing_sample": sorted(all_missing)[: max(0, sample_limit)],
        "license_note": (
            "Use this as a coverage benchmark only. Preserve upstream licenses, "
            "review per-site ToS, and do not copy external catalog data into the "
            "project without license review."
        ),
    }
