from __future__ import annotations

import re
import secrets
import string


def passes_regex(username: str, regex_check: str | None) -> bool:
    if not regex_check:
        return True
    try:
        return re.search(regex_check, username) is not None
    except re.error:
        return True


def strip_bad_chars(username: str, bad: str | None) -> str:
    if not bad:
        return username
    return "".join(ch for ch in username if ch not in bad)


def random_control_username(length: int = 22) -> str:
    alphabet = string.ascii_lowercase + string.digits
    core = "".join(secrets.choice(alphabet) for _ in range(length))
    return f"zz{core}qx"


def username_in_url(username: str, url: str) -> bool:
    return username.lower() in (url or "").lower()
