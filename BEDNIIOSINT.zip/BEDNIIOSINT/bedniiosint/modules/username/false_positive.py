from __future__ import annotations

from dataclasses import dataclass


@dataclass
class FalsePositiveVerdict:
    rejected: bool
    reason: str


def evaluate(
    *,
    status: str,
    source_reliability: float,
    min_reliability: float,
    control_passed: bool,
) -> FalsePositiveVerdict:
    if status != "exists":
        return FalsePositiveVerdict(False, "")

    if source_reliability < min_reliability:
        return FalsePositiveVerdict(
            True,
            f"source reliability {source_reliability:.2f} below floor {min_reliability:.2f}",
        )
    if not control_passed:
        return FalsePositiveVerdict(True, "site also matched random control username")
    return FalsePositiveVerdict(False, "")
