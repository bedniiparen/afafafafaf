from __future__ import annotations

import re
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

SOCIAL_HOSTS = {
    "twitter.com": "twitter",
    "x.com": "twitter",
    "t.me": "telegram",
    "instagram.com": "instagram",
    "facebook.com": "facebook",
    "github.com": "github",
    "gitlab.com": "gitlab",
    "youtube.com": "youtube",
    "linkedin.com": "linkedin",
    "mastodon.social": "mastodon",
    "reddit.com": "reddit",
    "tiktok.com": "tiktok",
    "twitch.tv": "twitch",
    "keybase.io": "keybase",
    "medium.com": "medium",
    "dribbble.com": "dribbble",
}

_EMAIL_RE = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+")
_WALLET_BTC = re.compile(r"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,39}\b")
_WALLET_ETH = re.compile(r"\b0x[a-fA-F0-9]{40}\b")


class _AnchorParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.hrefs: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "a":
            return
        for key, value in attrs:
            if key.lower() == "href" and value:
                self.hrefs.append(value)


def extract_outbound_links(html: str, base_url: str) -> list[str]:
    parser = _AnchorParser()
    parser.feed(html)
    out, seen = [], set()
    base_host = urlparse(base_url).netloc
    for raw_href in parser.hrefs:
        href = urljoin(base_url, raw_href)
        host = urlparse(href).netloc
        if href.startswith("http") and host and host != base_host and href not in seen:
            seen.add(href)
            out.append(href)
    return out[:200]


def classify_social_links(links: list[str]) -> dict[str, list[str]]:
    found: dict[str, list[str]] = {}
    for link in links:
        host = urlparse(link).netloc.lower().removeprefix("www.")
        for known, name in SOCIAL_HOSTS.items():
            if host == known or host.endswith("." + known):
                found.setdefault(name, []).append(link)
    return found


def extract_emails(text: str) -> list[str]:
    return sorted({match.group(0).lower() for match in _EMAIL_RE.finditer(text)})


def extract_wallets(text: str) -> dict[str, list[str]]:
    return {
        "btc": sorted(set(_WALLET_BTC.findall(text))),
        "eth": sorted(set(_WALLET_ETH.findall(text))),
    }
