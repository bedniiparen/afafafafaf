from __future__ import annotations

import re
from dataclasses import dataclass, field
from html import unescape
from html.parser import HTMLParser
from urllib.parse import urljoin

from .extract_links import (
    classify_social_links,
    extract_emails,
    extract_outbound_links,
    extract_wallets,
)


@dataclass
class ProfileData:
    title: str = ""
    description: str = ""
    avatar_url: str = ""
    canonical: str = ""
    outbound_links: list[str] = field(default_factory=list)
    social_links: dict = field(default_factory=dict)
    emails: list[str] = field(default_factory=list)
    wallets: dict = field(default_factory=dict)


class _MetaParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.title_parts: list[str] = []
        self._in_title = False
        self.meta: dict[str, str] = {}
        self.canonical = ""
        self.text_parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attrs_dict = {k.lower(): v for k, v in attrs if v is not None}
        if tag.lower() == "title":
            self._in_title = True
        elif tag.lower() == "meta":
            key = attrs_dict.get("property") or attrs_dict.get("name")
            content = attrs_dict.get("content")
            if key and content:
                self.meta[key] = content.strip()
        elif tag.lower() == "link" and attrs_dict.get("rel") == "canonical":
            self.canonical = attrs_dict.get("href", "").strip()

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title_parts.append(data)
        if data.strip():
            self.text_parts.append(data)


def _first(meta: dict[str, str], *names: str) -> str:
    for name in names:
        value = meta.get(name)
        if value:
            return value.strip()
    return ""


def _strip_tags(html: str) -> str:
    return unescape(re.sub(r"<[^>]+>", " ", html))


def parse_profile(html: str, url: str) -> ProfileData:
    parser = _MetaParser()
    parser.feed(html)
    title = " ".join(part.strip() for part in parser.title_parts if part.strip())[:300]
    desc = _first(parser.meta, "og:description", "description", "twitter:description")
    avatar = _first(parser.meta, "og:image", "twitter:image")
    if avatar:
        avatar = urljoin(url, avatar)
    canonical = urljoin(url, parser.canonical) if parser.canonical else ""
    links = extract_outbound_links(html, url)
    text = " ".join(parser.text_parts) or _strip_tags(html)
    return ProfileData(
        title=title,
        description=desc[:500],
        avatar_url=avatar,
        canonical=canonical,
        outbound_links=links,
        social_links=classify_social_links(links),
        emails=extract_emails(text),
        wallets=extract_wallets(text),
    )
