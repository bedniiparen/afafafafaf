from __future__ import annotations

import httpx

from ...config import settings
from ...core.confidence import (
    ScoreSignal,
    ScoringResult,
    UniversalConfidenceContext,
    score_universal,
)
from ...core.http import request
from ...core.source_record import source_reliability
from .profile_parser import ProfileData, parse_profile


def fetch_and_parse(url: str) -> tuple[ProfileData | None, str, int | None]:
    try:
        with httpx.Client(
            follow_redirects=True,
            timeout=settings.timeout,
            headers={"User-Agent": settings.user_agent},
        ) as client:
            response = request("GET", url, client=client)
            html = response.text or ""
            return parse_profile(html, str(response.url)), html, response.status_code
    except httpx.HTTPError:
        return None, "", None


def score_url_profile(
    profile: ProfileData | None,
    status_code: int | None,
) -> ScoringResult:
    ok_status = status_code is not None and status_code < 400
    linked_entities = bool(
        profile
        and (
            profile.outbound_links
            or profile.social_links
            or profile.emails
            or any(profile.wallets.values())
        )
    )
    independent_sources = 1 + int(bool(profile and ok_status)) + int(linked_entities)
    return score_universal(
        [
            ScoreSignal(
                "http_ok",
                0.2,
                ok_status,
                "HTTP status unavailable or >=400",
            ),
            ScoreSignal(
                "profile_parsed",
                0.5,
                profile is not None and ok_status,
                "profile parser returned no data",
            ),
            ScoreSignal(
                "profile_identity",
                0.2,
                bool(profile and (profile.title or profile.description or profile.canonical)),
                "no title/description/canonical",
            ),
            ScoreSignal(
                "linked_entities",
                0.1,
                linked_entities,
                "no outbound entities",
            ),
        ],
        context=UniversalConfidenceContext(
            target_type="url",
            independent_sources=independent_sources,
            source_reliability=source_reliability(
                "url-analyzer",
                success_count=1 if ok_status else 0,
                error_count=0 if ok_status else 1,
            ),
            weak_data=profile is None or not linked_entities,
        ),
        reject_reason="" if ok_status else "URL did not return an HTTP success status",
    )
