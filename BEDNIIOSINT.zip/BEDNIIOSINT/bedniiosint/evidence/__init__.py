"""Evidence vault helpers."""
