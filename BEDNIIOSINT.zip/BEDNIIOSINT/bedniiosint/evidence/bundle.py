from __future__ import annotations

import hmac
import json
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from ..storage.sqlite import Storage
from .hashing import sha256_file
from .manifest import evidence_manifest


def _canonical_json(data: object) -> bytes:
    return json.dumps(
        data,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def sign_manifest(
    manifest: dict,
    signing_key: str,
    *,
    key_id: str = "local",
) -> dict:
    digest = hmac.new(
        signing_key.encode("utf-8"),
        _canonical_json(manifest),
        sha256,
    ).hexdigest()
    return {
        "schema_version": "0.1",
        "algorithm": "hmac-sha256",
        "key_id": key_id,
        "signed_at": datetime.now(timezone.utc).isoformat(),
        "signature": digest,
    }


def verify_manifest_signature(
    manifest: dict,
    signature: dict,
    signing_key: str,
) -> bool:
    if signature.get("algorithm") != "hmac-sha256":
        return False
    expected = sign_manifest(
        manifest,
        signing_key,
        key_id=str(signature.get("key_id") or "local"),
    )["signature"]
    return hmac.compare_digest(expected, str(signature.get("signature") or ""))


def _safe_name(value: str) -> str:
    clean = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in value)
    return clean.strip("._") or "artifact"


def _artifact_rows(manifest: dict) -> list[dict]:
    rows: list[dict] = []
    seen: set[str] = set()
    roles = {"attachments": "attachment", "evidence": "evidence"}
    for section, id_key in (("attachments", "id"), ("evidence", "id")):
        for item in manifest.get(section, []):
            artifact = item.get("artifact") if isinstance(item, dict) else None
            if not isinstance(artifact, dict) or not artifact.get("exists"):
                continue
            path = Path(str(artifact.get("path") or ""))
            if not path.exists() or not path.is_file():
                continue
            try:
                resolved = str(path.resolve())
            except OSError:
                resolved = str(path)
            if resolved in seen:
                continue
            seen.add(resolved)
            artifact_id = item.get(id_key) or len(rows) + 1
            name = _safe_name(path.name)
            archive_path = f"artifacts/{section}/{artifact_id}-{name}"
            digest = str(item.get("sha256") or sha256_file(path))
            rows.append(
                {
                    "role": roles[section],
                    "id": artifact_id,
                    "finding_id": item.get("finding_id"),
                    "original_path": str(path),
                    "archive_path": archive_path,
                    "sha256": digest,
                    "size": path.stat().st_size,
                }
            )
    return rows


def write_evidence_bundle(
    storage: Storage,
    case_id: int | list[int],
    out: Path,
    *,
    signing_key: str | None = None,
    key_id: str = "local",
) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    manifest = evidence_manifest(storage, case_id)
    bundle_files = _artifact_rows(manifest)
    manifest["bundle"] = {
        "schema_version": "0.1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "artifact_count": len(bundle_files),
        "archive_format": "zip",
    }
    manifest["bundle_files"] = bundle_files
    signature = sign_manifest(manifest, signing_key, key_id=key_id) if signing_key else None

    with ZipFile(out, "w", ZIP_DEFLATED) as archive:
        archive.writestr(
            "evidence-manifest.json",
            json.dumps(manifest, indent=2, ensure_ascii=False),
        )
        if signature:
            archive.writestr(
                "manifest-signature.json",
                json.dumps(signature, indent=2, ensure_ascii=False),
            )
        for row in bundle_files:
            path = Path(row["original_path"])
            if path.exists() and path.is_file():
                archive.write(path, arcname=row["archive_path"])
    return out


def inspect_evidence_bundle(
    bundle: Path,
    *,
    signing_key: str | None = None,
) -> dict:
    with ZipFile(bundle) as archive:
        names = set(archive.namelist())
        manifest = json.loads(archive.read("evidence-manifest.json").decode("utf-8"))
        signature = None
        if "manifest-signature.json" in names:
            signature = json.loads(archive.read("manifest-signature.json").decode("utf-8"))
        file_checks = []
        for row in manifest.get("bundle_files", []):
            archive_path = row.get("archive_path")
            present = archive_path in names
            digest_ok = None
            if present:
                digest = sha256(archive.read(archive_path)).hexdigest()
                digest_ok = digest == row.get("sha256")
            file_checks.append(
                {
                    "archive_path": archive_path,
                    "present": present,
                    "sha256_ok": digest_ok,
                }
            )

    signature_verified = None
    if signature is not None and signing_key is not None:
        signature_verified = verify_manifest_signature(manifest, signature, signing_key)
    return {
        "bundle": str(bundle),
        "manifest": manifest,
        "signature": signature,
        "signature_verified": signature_verified,
        "files": file_checks,
    }


def import_evidence_bundle(
    bundle: Path,
    out_dir: Path,
    *,
    signing_key: str | None = None,
    require_valid: bool = True,
) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    root = out_dir.resolve()
    inspected = inspect_evidence_bundle(bundle, signing_key=signing_key)
    if require_valid:
        bad_files = [
            row
            for row in inspected.get("files", [])
            if not row.get("present") or row.get("sha256_ok") is False
        ]
        if bad_files:
            names = ", ".join(str(row.get("archive_path")) for row in bad_files[:5])
            raise ValueError(f"evidence bundle integrity check failed: {names}")
        if signing_key is not None and inspected.get("signature") is not None:
            if inspected.get("signature_verified") is not True:
                raise ValueError("evidence bundle signature verification failed")
    extracted: list[str] = []
    with ZipFile(bundle) as archive:
        for member in archive.infolist():
            target = (out_dir / member.filename).resolve()
            if target != root and root not in target.parents:
                raise ValueError(f"unsafe bundle member path: {member.filename}")
            archive.extract(member, out_dir)
            extracted.append(str(target))
    inspected["imported_to"] = str(root)
    inspected["extracted"] = extracted
    return inspected
