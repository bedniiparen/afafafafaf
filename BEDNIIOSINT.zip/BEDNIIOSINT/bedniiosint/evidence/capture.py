from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..storage.models import Attachment, Evidence
from ..storage.sqlite import Storage
from .hashing import sha256_file
from .screenshot import capture_screenshot, screenshots_available
from .snapshot import save_html_snapshot, save_json_snapshot


class EvidenceVault:
    def __init__(self, storage: Storage, case_id: int, base_dir: Path):
        self.storage = storage
        self.case_id = case_id
        self.dir = base_dir
        self.dir.mkdir(parents=True, exist_ok=True)

    def store_html(
        self,
        html: str,
        finding_id: int | None,
        name_hint: str,
        *,
        adapter_version: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> Attachment:
        path, digest = save_html_snapshot(html, self.dir / "html", name_hint)
        return self._record(
            "html_snapshot",
            path,
            digest,
            finding_id,
            "text/html",
            adapter_version=adapter_version,
            metadata=metadata,
        )

    def store_json(
        self,
        data: object,
        finding_id: int | None,
        name_hint: str,
        *,
        adapter_version: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> Attachment:
        path, digest = save_json_snapshot(data, self.dir / "raw", name_hint)
        return self._record(
            "raw_json",
            path,
            digest,
            finding_id,
            "application/json",
            adapter_version=adapter_version,
            metadata=metadata,
        )

    def store_screenshot(
        self,
        url: str,
        finding_id: int | None,
        name_hint: str,
        *,
        adapter_version: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> Attachment | None:
        if not screenshots_available():
            return None
        path = capture_screenshot(url, self.dir / "screenshots", name_hint)
        if path is None:
            return None
        return self._record(
            "screenshot",
            path,
            sha256_file(path),
            finding_id,
            "image/png",
            adapter_version=adapter_version,
            metadata=metadata,
        )

    def record_evidence(
        self,
        *,
        finding_id: int,
        url: str,
        final_url: str = "",
        http_status: int | None = None,
        sha256: str = "",
        body_len: int = 0,
        source_module: str,
        adapter_version: str = "",
        content_type: str = "",
        headers: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
        method: str = "GET",
        artifact_path: str = "",
        confidence_at_capture: float = 0.0,
    ) -> Evidence:
        with self.storage.session() as session:
            evidence = Evidence(
                case_id=self.case_id,
                finding_id=finding_id,
                url=url,
                final_url=final_url,
                http_status=http_status,
                sha256=sha256,
                body_len=body_len,
                source_module=source_module,
                adapter_version=adapter_version,
                content_type=content_type,
                headers_json=json.dumps(headers or {}, ensure_ascii=False, sort_keys=True),
                query_params_json=json.dumps(
                    query_params or {},
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                method=method,
                artifact_path=artifact_path,
                confidence_at_capture=confidence_at_capture,
            )
            session.add(evidence)
            session.commit()
            session.refresh(evidence)
            return evidence

    def _record(
        self,
        kind: str,
        path: Path,
        digest: str,
        finding_id: int | None,
        mime: str,
        *,
        adapter_version: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> Attachment:
        with self.storage.session() as session:
            attachment = Attachment(
                case_id=self.case_id,
                finding_id=finding_id,
                kind=kind,
                path=str(path),
                sha256=digest,
                mime=mime,
                source_adapter_version=adapter_version,
                metadata_json=json.dumps(
                    metadata or {},
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            )
            session.add(attachment)
            session.commit()
            session.refresh(attachment)
            return attachment
