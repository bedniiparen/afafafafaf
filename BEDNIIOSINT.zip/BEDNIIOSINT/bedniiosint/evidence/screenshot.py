from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright

    _HAS_PLAYWRIGHT = True
except Exception:  # pragma: no cover
    _HAS_PLAYWRIGHT = False


def screenshots_available() -> bool:
    return _HAS_PLAYWRIGHT


def capture_screenshot(
    url: str, vault_dir: Path, name_hint: str, timeout_ms: int = 15000
) -> Path | None:
    if not _HAS_PLAYWRIGHT:
        return None
    vault_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    safe = "".join(c for c in name_hint if c.isalnum() or c in "-_")[:40] or "shot"
    out = vault_dir / f"{ts}_{safe}.png"
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            page.goto(url, timeout=timeout_ms, wait_until="domcontentloaded")
            page.screenshot(path=str(out), full_page=False)
            browser.close()
        return out
    except Exception:
        return None
