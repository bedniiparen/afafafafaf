from __future__ import annotations

import json
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from ..storage.models import Attachment, Case, Evidence, Finding
from ..storage.sqlite import Storage


SECRET_KEYS = {"key", "api_key", "api_token", "access_key", "token", "secret", "password"}


def _ids(case_id: int | Iterable[int]) -> list[int]:
    if isinstance(case_id, int):
        return [case_id]
    return list(case_id)


def _redact_url(url: str) -> str:
    if not url:
        return ""
    parts = urlsplit(url)
    query = []
    for key, value in parse_qsl(parts.query, keep_blank_values=True):
        query.append((key, "[redacted]" if key.lower() in SECRET_KEYS else value))
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def _loads(value: str | None) -> object:
    if not value:
        return {}
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return value


def _redact_secret_values(value: object) -> object:
    if isinstance(value, dict):
        return {
            key: "[redacted]"
            if str(key).lower() in SECRET_KEYS
            else _redact_secret_values(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_redact_secret_values(item) for item in value]
    return value


def _artifact_info(path_value: str) -> dict:
    path = Path(path_value) if path_value else Path()
    if not path_value or not path.exists() or not path.is_file():
        return {"path": path_value, "exists": False, "size": 0}
    return {"path": path_value, "exists": True, "size": path.stat().st_size}


def evidence_manifest(storage: Storage, case_id: int | Iterable[int]) -> dict:
    ids = _ids(case_id)
    cases = []
    evidence_rows = []
    attachment_rows = []
    finding_rows = []
    with storage.session() as session:
        for cid in ids:
            case = session.query(Case).filter(Case.id == cid).first()
            if case:
                cases.append(case.as_dict())
            findings = session.query(Finding).filter(Finding.case_id == cid).all()
            finding_rows.extend(findings)
            evidence_rows.extend(session.query(Evidence).filter(Evidence.case_id == cid).all())
            attachment_rows.extend(
                session.query(Attachment).filter(Attachment.case_id == cid).all()
            )

    def clean(row) -> dict:
        data = dict(row) if isinstance(row, dict) else row.as_dict()
        for key, value in list(data.items()):
            if hasattr(value, "isoformat"):
                data[key] = value.isoformat()
            if key in {"url", "final_url", "profile_url"}:
                data[key] = _redact_url(str(value or ""))
        if "headers_json" in data:
            data["headers"] = _loads(data.pop("headers_json"))
        if "query_params_json" in data:
            data["query_params"] = _redact_secret_values(_loads(data.pop("query_params_json")))
        if "metadata_json" in data:
            data["metadata"] = _loads(data.pop("metadata_json"))
        if "artifact_path" in data and data["artifact_path"]:
            data["artifact"] = _artifact_info(str(data["artifact_path"]))
        if "path" in data and data["path"]:
            data["artifact"] = _artifact_info(str(data["path"]))
        return data

    generated_at = datetime.now(timezone.utc).isoformat()
    return {
        "schema_version": "0.3",
        "generated_at": generated_at,
        "forensic": {
            "hash_algorithm": "sha256",
            "chain_of_custody": True,
            "secret_query_keys_redacted": sorted(SECRET_KEYS),
            "case_count": len(cases),
            "finding_count": len(finding_rows),
            "evidence_count": len(evidence_rows),
            "attachment_count": len(attachment_rows),
        },
        "cases": [clean(row) for row in cases],
        "findings": [clean(row) for row in finding_rows],
        "evidence": [clean(row) for row in evidence_rows],
        "attachments": [clean(row) for row in attachment_rows],
        "chain_of_custody": [
            {
                "manifest_generated_at": generated_at,
                "attachment_id": row.id,
                "finding_id": row.finding_id,
                "kind": row.kind,
                "path": row.path,
                "sha256": row.sha256,
                "source_adapter_version": row.source_adapter_version,
                "metadata": _loads(row.metadata_json),
                "captured_at": row.captured_at.isoformat()
                if hasattr(row.captured_at, "isoformat")
                else row.captured_at,
            }
            for row in attachment_rows
        ],
    }


def write_evidence_manifest(storage: Storage, case_id: int | Iterable[int], out: Path) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(evidence_manifest(storage, case_id), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return out
