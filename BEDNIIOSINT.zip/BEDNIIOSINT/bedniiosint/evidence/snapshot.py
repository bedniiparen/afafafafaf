from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from .hashing import sha256_text


def save_html_snapshot(html: str, vault_dir: Path, name_hint: str) -> tuple[Path, str]:
    vault_dir.mkdir(parents=True, exist_ok=True)
    digest = sha256_text(html)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    safe = "".join(c for c in name_hint if c.isalnum() or c in "-_")[:40] or "snap"
    path = vault_dir / f"{ts}_{safe}_{digest[:12]}.html"
    path.write_bytes(html.encode("utf-8"))
    return path, digest


def save_json_snapshot(data: object, vault_dir: Path, name_hint: str) -> tuple[Path, str]:
    text = json.dumps(data, indent=2, ensure_ascii=False, default=str)
    vault_dir.mkdir(parents=True, exist_ok=True)
    digest = sha256_text(text)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    safe = "".join(c for c in name_hint if c.isalnum() or c in "-_")[:40] or "raw"
    path = vault_dir / f"{ts}_{safe}_{digest[:12]}.json"
    path.write_bytes(text.encode("utf-8"))
    return path, digest
