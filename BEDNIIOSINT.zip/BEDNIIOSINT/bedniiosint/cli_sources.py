from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table


console = Console()
sources_app = typer.Typer(add_completion=False, help="Source registry and adapter commands")


@sources_app.command("budget-presets")
def budget_presets():
    """Print provider-specific rate-limit budget presets."""
    from .core.jobs import rate_limit_budget_presets

    console.print(json.dumps(rate_limit_budget_presets(), indent=2, ensure_ascii=False))


@sources_app.command("list")
def sources(
    input_type: str | None = typer.Option(
        None, "--input", help="Filter by selector type, e.g. domain, email, phone"
    ),
    kind: str | None = typer.Option(None, "--kind", help="Filter by module or api"),
    auth: str | None = typer.Option(None, "--auth", help="Filter by auth mode"),
    runnable: bool = typer.Option(False, "--runnable", help="Show runnable sources only"),
    endpoints: bool = typer.Option(False, "--endpoints", help="Show endpoint templates"),
    health_check: str | None = typer.Option(None, "--health-check", help="Execute adapter health check for a source id"),
    limit: int = typer.Option(25, "--limit", min=1, help="Maximum rows to print"),
):
    """List the unified source registry."""
    from .catalog import adapter_health, endpoint_index, filter_registry, registry_summary

    if health_check:
        console.print(json.dumps(adapter_health(health_check), indent=2, ensure_ascii=False))
        return

    selected = filter_registry(
        input_type=input_type,
        kind=kind,
        auth=auth,
        runnable=True if runnable else None,
    )
    summary = registry_summary(selected)
    console.print(
        "[bold cyan]Source registry[/] | "
        f"{summary['sources']} sources | {summary['runnable']} runnable | "
        f"{summary['configured']} configured | {summary['auth_required']} require auth"
    )

    table = Table(title="Sources")
    table.add_column("ID")
    table.add_column("Name")
    table.add_column("Kind")
    table.add_column("Inputs")
    table.add_column("Auth")
    table.add_column("Runnable")
    table.add_column("Configured")
    table.add_column("Docs")

    for source in selected[:limit]:
        table.add_row(
            source.id,
            source.name,
            source.kind,
            ", ".join(source.inputs),
            source.auth,
            "yes" if source.runnable else "no",
            "yes" if source.configured else ",".join(source.env_vars),
            source.docs_url,
        )
    console.print(table)

    if endpoints:
        ep_table = Table(title="Endpoint templates")
        ep_table.add_column("Source")
        ep_table.add_column("Method")
        ep_table.add_column("URL")
        for row in endpoint_index()[:limit]:
            ep_table.add_row(row["source"], row["method"], row["url"])
        console.print(ep_table)


@sources_app.command("maintenance")
def source_maintenance(
    fixture_dir: Path = typer.Option(Path("tests/fixtures/sources"), "--fixture-dir"),
    json_out: bool = typer.Option(False, "--json", help="Print full JSON maintenance report"),
    limit: int = typer.Option(15, "--limit", min=1),
):
    """Print offline source maintenance and live-readiness diagnostics."""
    from .catalog.health import source_maintenance_report

    report = source_maintenance_report(fixture_dir=fixture_dir)
    if json_out:
        console.print(json.dumps(report, indent=2, ensure_ascii=False), soft_wrap=True)
        return

    summary = report["summary"]
    fixture = summary["fixture_coverage"]
    live = summary["live_validation"]
    console.print(
        "[bold cyan]Source maintenance[/] | "
        f"score {summary['average_readiness_score']} | "
        f"{summary['action_required']} action required | {summary['watch']} watch | "
        f"ok fixtures {fixture['ok_coverage']} | live sections ready {live.get('ready', 0)}"
    )
    table = Table(title="Top source maintenance actions")
    table.add_column("Source")
    table.add_column("Priority")
    table.add_column("Status")
    table.add_column("Score")
    table.add_column("Live")
    table.add_column("Next action")
    for row in report["top_actions"][:limit]:
        table.add_row(
            str(row["source_id"]),
            str(row["priority"]),
            str(row["maintenance_status"]),
            str(row["readiness_score"]),
            str(row["live_readiness"]),
            str(row["next_action"]),
        )
    console.print(table)


@sources_app.command("verify")
def source_verify(
    mode: str = typer.Option("contract", "--mode", help="contract, fixture, live-plan or live"),
    source: str | None = typer.Option(None, "--source", help="Filter by source id, e.g. api:crtsh"),
    input_type: str | None = typer.Option(None, "--input", help="Filter by input type"),
    kind: str | None = typer.Option(None, "--kind", help="Filter by module, api or plugin"),
    runnable: bool = typer.Option(False, "--runnable", help="Verify runnable sources only"),
    target: str | None = typer.Option(None, "--target", help="Live probe target override"),
    fixture_dir: Path | None = typer.Option(None, "--fixture-dir", help="Fixture root for fixture mode"),
    fixture: str = typer.Option("ok", "--fixture", help="Fixture variant name, e.g. ok, rate_limited, schema_changed"),
    plugins_dir: Path = typer.Option(Path("plugins"), "--plugins-dir"),
    allow_opt_in: bool = typer.Option(False, "--allow-opt-in", help="Allow live verification of opt-in sources"),
    record_live_result: bool = typer.Option(
        False,
        "--record-live-result",
        help="Persist live/live-plan verification results after secret redaction",
    ),
    run_id: str | None = typer.Option(None, "--run-id", help="Run id for persisted live validation results"),
    json_out: bool = typer.Option(False, "--json", help="Print full JSON result"),
    limit: int = typer.Option(100, "--limit", min=1),
):
    """Verify source contracts, fixtures or live adapter health."""
    from .catalog.verify import verify_sources
    from .core.live_validation_results import (
        record_live_validation_results,
        sanitize_live_verification,
    )

    result = verify_sources(
        mode=mode,
        source_id=source,
        input_type=input_type,
        kind=kind,
        runnable=True if runnable else None,
        target=target,
        fixture_dir=fixture_dir,
        fixture_name=fixture,
        plugin_dir=plugins_dir,
        allow_opt_in=allow_opt_in,
    )
    normalized_mode = mode.lower().strip().replace("-", "_")
    if record_live_result:
        if normalized_mode not in {"live", "live_plan"}:
            raise typer.BadParameter("--record-live-result only supports --mode live or live-plan")
        recording = record_live_validation_results(
            result,
            run_id=run_id,
            target=target or "",
            allow_opt_in=allow_opt_in,
            network_required=normalized_mode == "live",
        )
        result["recording"] = recording
    if json_out:
        printable = result
        if normalized_mode in {"live", "live_plan"}:
            printable, _redacted = sanitize_live_verification(result)
        console.print(
            json.dumps(printable, indent=2, ensure_ascii=False, default=str),
            markup=False,
            soft_wrap=True,
        )
        return
    if record_live_result:
        recording = result["recording"]
        console.print(
            "[dim]Live validation results recorded ->[/] "
            f"{recording['recorded']} rows, run_id {recording['run_id']}"
        )

    summary = result["summary"]
    coverage = summary.get("fixture_coverage")
    if coverage:
        console.print(
            "[dim]Fixture coverage ->[/] "
            f"{coverage['fixture_name']} "
            f"{coverage['fixture_sources']}/{coverage['api_sources']} "
            f"({coverage['coverage']:.3f}); missing {len(coverage['missing'])}"
        )
    table = Table(
        title=(
            f"Source verification: {mode} | "
            f"{summary['passed']} passed, {summary['failed']} failed, {summary['skipped']} skipped"
        )
    )
    table.add_column("Source")
    table.add_column("Status")
    table.add_column("Verification")
    table.add_column("Reason")
    table.add_column("Errors")
    for row in result["results"][:limit]:
        table.add_row(
            str(row["source_id"]),
            str(row["status"]),
            str(row["verification_status"]),
            str(row["reason"]),
            ", ".join(row.get("errors") or []),
        )
    console.print(table)


@sources_app.command("quality-gate")
def source_quality_gate_cmd(
    source: str | None = typer.Option(None, "--source", help="Limit to one source id"),
    priority: str | None = typer.Option(None, "--priority", help="Limit to P0/P1/P2/P3 policy priority"),
    fixture_dir: Path = typer.Option(Path("tests/fixtures/sources"), "--fixture-dir"),
    strict: bool = typer.Option(False, "--strict", help="Treat warnings as failures"),
    json_out: bool = typer.Option(False, "--json", help="Print full JSON gate result"),
    limit: int = typer.Option(25, "--limit", min=1),
):
    """Run an offline source quality gate over catalog metadata and fixtures."""
    from .catalog.verify import source_quality_gate

    result = source_quality_gate(
        fixture_dir=fixture_dir,
        source_id=source,
        priority=priority,
        strict=strict,
    )
    if json_out:
        console.print(json.dumps(result, indent=2, ensure_ascii=False), soft_wrap=True)
        return

    summary = result["summary"]
    table = Table(
        title=(
            "Source quality gate: "
            f"{summary['passed']} passed, {summary['warning']} warning, {summary['failed']} failed"
        )
    )
    table.add_column("Source")
    table.add_column("Priority")
    table.add_column("Status")
    table.add_column("Failures")
    table.add_column("Warnings")
    for row in result["results"][:limit]:
        table.add_row(
            str(row["source_id"]),
            str(row.get("priority") or ""),
            str(row["status"]),
            ", ".join(row.get("required_failures") or []),
            ", ".join(row.get("warnings") or []),
        )
    console.print(table)


@sources_app.command("run")
def source_run(
    source_id: str = typer.Argument(..., help="Source id, e.g. api:crtsh or plugin:demo"),
    target: str = typer.Argument(..., help="Target selector to pass to the adapter"),
    input_type: str | None = typer.Option(None, "--input", help="Selector type override"),
    case: str = typer.Option("adapter-run", "--case", help="Case name for module adapters"),
    plugins_dir: Path = typer.Option(Path("plugins"), "--plugins-dir"),
    save: bool = typer.Option(False, "--save", help="Persist normalized adapter output to a case"),
    cache_ttl: int = typer.Option(0, "--cache-ttl", min=0, help="Enable source response cache for N seconds"),
    cache_ttl_source: list[str] | None = typer.Option(
        None,
        "--cache-ttl-source",
        help="Per-source cache TTL as source=seconds, repeatable or comma-separated",
    ),
    request_budget: str | None = typer.Option(None, "--request-budget", help="JSON or source=limit pairs, e.g. *=2,api:crtsh=1"),
    budget_preset: str = typer.Option("none", "--budget-preset", help="Budget preset: none, smoke, conservative, standard"),
    timeout: float | None = typer.Option(None, "--timeout", min=0.1, help="HTTP timeout override"),
    rate_limit_delay: float | None = typer.Option(None, "--rate-limit-delay", min=0.0, help="Per-host delay override"),
    scope: str = typer.Option("public_osint", "--scope", help="Legal/privacy scope label recorded in run context"),
    public_only: bool = typer.Option(False, "--public-only", help="Block medium/high terms-risk sources"),
    max_terms_risk: str | None = typer.Option(None, "--max-terms-risk", help="Maximum allowed terms risk: low, medium, high"),
    allow_sensitive_sources: bool = typer.Option(False, "--allow-sensitive-sources", help="Allow phone/sanctions/social/high-risk sources that require explicit opt-in"),
    allow_uploads: bool = typer.Option(False, "--allow-uploads", help="Allow third-party upload/submission workflows"),
    allow_active_checks: bool = typer.Option(False, "--allow-active-checks", help="Allow active checks when a source requires them"),
):
    """Run a source registry adapter and print its normalized result."""
    from .catalog import run_source
    from .config import settings
    from .core.cache_policy import merge_cache_ttl_presets
    from .core.jobs import resolve_rate_limit_budget
    from .core.normalizer import normalize_adapter_result, persist_normalized
    from .core.source_context import SourceRunContext, parse_cache_ttl_by_source

    try:
        budget = resolve_rate_limit_budget(request_budget, preset=budget_preset)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    try:
        cache_ttls = merge_cache_ttl_presets(
            parse_cache_ttl_by_source(cache_ttl_source),
            source_ids=[source_id],
        )
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    context = SourceRunContext(
        scope=scope,
        timeout=timeout if timeout is not None else settings.timeout,
        rate_limit_delay=rate_limit_delay if rate_limit_delay is not None else settings.http_rate_limit_delay,
        cache_enabled=cache_ttl > 0 or bool(cache_ttls),
        cache_ttl_seconds=cache_ttl,
        cache_ttl_by_source=cache_ttls,
        request_budget=budget,
        legal_flags={
            "public_only": public_only,
            "max_terms_risk": max_terms_risk,
            "allow_sensitive_sources": allow_sensitive_sources,
            "allow_uploads": allow_uploads,
            "allow_active_checks": allow_active_checks,
        },
    )
    result = run_source(
        source_id,
        target,
        plugin_dir=plugins_dir,
        input_type=input_type,
        case=case,
        context=context,
    )
    if save:
        summary = persist_normalized(
            normalize_adapter_result(result),
            case_name=case,
            module="adapter",
        )
        console.print(json.dumps(summary, indent=2, ensure_ascii=False, default=str))
    else:
        console.print(json.dumps(result.as_dict(), indent=2, ensure_ascii=False, default=str))
