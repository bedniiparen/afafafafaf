from __future__ import annotations

import typer

from .cli_api_keys import (
    api_key_setup,
    api_key_store_audit,
    api_key_store_delete,
    api_key_store_list,
    api_key_store_rotate,
    api_key_store_set,
    api_key_store_setup,
    api_key_template,
    api_keys_app,
)
from .cli_case_admin import (
    case_admin_app,
    case_archive,
    case_import,
    case_merge,
    evidence_bundle_import,
    evidence_bundle_inspect,
    recheck,
    schema_status_cmd,
)
from .cli_cases import (
    case_app,
    case_diff,
    company,
    domain,
    email,
    find,
    graph,
    ip,
    media_verify_plan,
    metadata,
    phone,
    timeline,
    url,
    wallet,
)
from .cli_cti import cti_app, cti_preflight, cti_sync, live_plan
from .cli_jobs import (
    jobs_app,
    job_cancel,
    job_create,
    job_events,
    job_list,
    job_recover_stale,
    job_resume,
    job_run,
    job_worker_loop,
    job_worker_once,
    job_worker_status,
)
from .cli_live_results import (
    live_results,
    live_results_app,
    live_results_audit,
    live_results_cleanup,
    live_results_verify,
)
from .cli_monitor import monitor_app
from .cli_plugins import (
    generate_adapter,
    plugin_config,
    plugin_disable,
    plugin_enable,
    plugin_sign,
    plugin_verify,
    plugins,
    plugins_app,
)
from .cli_reports import report, reports_app, reports_verify
from .cli_search import (
    investigation_plan_command,
    pipeline_run,
    search_index_command,
    search_app,
    search_plan_command,
    search_run_command,
    search_sources_command,
)
from .cli_sources import (
    budget_presets,
    source_maintenance,
    source_quality_gate_cmd,
    source_run,
    source_verify,
    sources,
    sources_app,
)
from .cli_username import (
    username,
    username_app,
    username_catalog_coverage_cmd,
    username_catalog_merge,
    username_catalog_validate,
    username_sources,
)

app = typer.Typer(add_completion=False, help="BEDNIIOSINT - OSINT Case Builder")
app.add_typer(api_keys_app, name="api-keys")
app.add_typer(case_app, name="case")
app.add_typer(case_admin_app, name="case-admin")
app.add_typer(cti_app, name="cti")
app.add_typer(jobs_app, name="jobs")
app.add_typer(live_results_app, name="live")
app.add_typer(monitor_app, name="monitor")
app.add_typer(plugins_app, name="plugin")
app.add_typer(reports_app, name="reports")
app.add_typer(search_app, name="search")
app.add_typer(sources_app, name="source")
app.add_typer(username_app, name="username-tools")
app.command("api-key-setup")(api_key_setup)
app.command("api-key-template")(api_key_template)
app.command("api-key-store-set")(api_key_store_set)
app.command("api-key-store-list")(api_key_store_list)
app.command("api-key-store-setup")(api_key_store_setup)
app.command("api-key-store-delete")(api_key_store_delete)
app.command("api-key-store-audit")(api_key_store_audit)
app.command("api-key-store-rotate")(api_key_store_rotate)
app.command("job-create")(job_create)
app.command("job-run")(job_run)
app.command("job-list")(job_list)
app.command("job-cancel")(job_cancel)
app.command("job-resume")(job_resume)
app.command("job-events")(job_events)
app.command("job-worker-once")(job_worker_once)
app.command("job-worker-loop")(job_worker_loop)
app.command("job-recover-stale")(job_recover_stale)
app.command("job-worker-status")(job_worker_status)
app.command("report")(report)
app.command("reports-verify")(reports_verify)
app.command("plugins")(plugins)
app.command("plugin-enable")(plugin_enable)
app.command("plugin-disable")(plugin_disable)
app.command("plugin-config")(plugin_config)
app.command("plugin-sign")(plugin_sign)
app.command("plugin-verify")(plugin_verify)
app.command("generate-adapter")(generate_adapter)
app.command("username")(username)
app.command("username-sources")(username_sources)
app.command("username-catalog-validate")(username_catalog_validate)
app.command("username-catalog-merge")(username_catalog_merge)
app.command("username-catalog-coverage")(username_catalog_coverage_cmd)
app.command("evidence-bundle-inspect")(evidence_bundle_inspect)
app.command("evidence-bundle-import")(evidence_bundle_import)
app.command("case-merge")(case_merge)
app.command("case-archive")(case_archive)
app.command("case-import")(case_import)
app.command("schema-status")(schema_status_cmd)
app.command("recheck")(recheck)
app.command("live-results")(live_results)
app.command("live-results-cleanup")(live_results_cleanup)
app.command("live-results-audit")(live_results_audit)
app.command("live-results-verify")(live_results_verify)
app.command("email")(email)
app.command("domain")(domain)
app.command("metadata")(metadata)
app.command("media-verify-plan")(media_verify_plan)
app.command("ip")(ip)
app.command("phone")(phone)
app.command("url")(url)
app.command("wallet")(wallet)
app.command("company")(company)
app.command("find")(find)
app.command("graph")(graph)
app.command("timeline")(timeline)
app.command("case-diff")(case_diff)
app.command("budget-presets")(budget_presets)
app.command("sources")(sources)
app.command("source-maintenance")(source_maintenance)
app.command("source-verify")(source_verify)
app.command("source-quality-gate")(source_quality_gate_cmd)
app.command("source-run")(source_run)
app.command("pipeline-run")(pipeline_run)
app.command("search-plan")(search_plan_command)
app.command("search-run")(search_run_command)
app.command("search-index")(search_index_command)
app.command("investigation-plan")(investigation_plan_command)
app.command("search-sources")(search_sources_command)
app.command("cti-sync")(cti_sync)
app.command("cti-preflight")(cti_preflight)
app.command("live-plan")(live_plan)


@app.command("source-health")
def source_health_cmd():
    """Show connector runtime health."""
    from rich.console import Console
    from rich.table import Table

    from .search.source_health import GLOBAL_SOURCE_HEALTH

    columns = ("source_id", "requests", "success_rate", "avg_latency", "last_error")
    table = Table(title="Source health")
    for column in columns:
        table.add_column(column)
    for row in GLOBAL_SOURCE_HEALTH.snapshot():
        table.add_row(*(str(row.get(column, "")) for column in columns))
    Console().print(table)


@app.callback()
def main():
    """BEDNIIOSINT command group."""

if __name__ == "__main__":
    app()




