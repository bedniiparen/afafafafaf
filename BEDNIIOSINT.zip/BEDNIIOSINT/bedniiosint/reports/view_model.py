from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
import re
from typing import Any
from urllib.parse import urlparse

from ..core.entity_resolution import resolve_entities


REPORT_VERSION = "0.7-report-system"
LEGAL_PRIVACY_NOTE = (
    "Use only for authorized public OSINT workflows. Treat identity and ownership "
    "claims as unconfirmed until reviewed with preserved evidence and independent "
    "corroboration."
)

ENTITY_GROUPS = (
    ("primary_target", "Primary target"),
    ("domains", "Domains"),
    ("urls", "URLs"),
    ("emails", "Emails"),
    ("phones", "Phones"),
    ("ips", "IP addresses"),
    ("companies", "Companies / brands"),
    ("social_profiles", "Social profiles"),
    ("usernames", "Usernames"),
    ("crypto", "Crypto addresses"),
    ("files", "Files / hashes"),
    ("unknown", "Unknown entities"),
)

CLUSTER_ORDER = (
    "Confirmed matches",
    "Likely matches",
    "Weak observations",
    "Same-name only",
    "Infrastructure",
    "Public profiles",
    "Business registry",
    "Review-only leads",
    "Rejected / false positives",
    "Unknown",
)

CLUSTER_MEANINGS = {
    "Confirmed matches": "Strong findings with high confidence and confirmation signals.",
    "Likely matches": "Useful findings that still need analyst review or another source.",
    "Weak observations": "Leads with sparse evidence, low confidence or no confirmation.",
    "Same-name only": "Name or username overlap without enough identity evidence.",
    "Infrastructure": "Domains, URLs, IPs, DNS, certificates or hosting relationships.",
    "Public profiles": "Public accounts, profile URLs and social/profile observations.",
    "Business registry": "Company registry, brand or legal-entity observations.",
    "Review-only leads": "Search and dorking leads preserved for manual review, not treated as findings.",
    "Rejected / false positives": "Candidates retained to document why they should not be used.",
    "Unknown": "Items that do not fit a stronger report category yet.",
}

DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")
FILELIKE_DOMAIN_SUFFIXES = (
    ".atom",
    ".css",
    ".gif",
    ".jpeg",
    ".jpg",
    ".java",
    ".json",
    ".js",
    ".map",
    ".png",
    ".run",
    ".svg",
    ".ts",
    ".txt",
    ".xml",
)


def _clean(value: Any) -> str:
    return " ".join(str(value or "").replace("\r", " ").replace("\n", " ").split())


def _lower(value: Any) -> str:
    return _clean(value).lower()


def _confidence(value: Any) -> float:
    try:
        score = float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0
    if score > 1.0 and score <= 100.0:
        score = score / 100.0
    return max(0.0, min(1.0, score))


def _pct(value: Any) -> int:
    return int(round(_confidence(value) * 100))


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _markers(value: Any) -> list[str]:
    if isinstance(value, list):
        return [_clean(item) for item in value if _clean(item)]
    return [_clean(item) for item in _clean(value).split(",") if _clean(item)]


def _source_key(row: dict[str, Any]) -> str:
    return _clean(row.get("source_id") or row.get("source_name") or row.get("name"))


def _source_name(row: dict[str, Any]) -> str:
    return _clean(row.get("source_name") or row.get("name") or row.get("source_id") or "unknown")


def _host(value: Any) -> str:
    raw = _clean(value)
    if not raw:
        return ""
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = parsed.netloc or parsed.path
    return host.split("@")[-1].split(":")[0].strip("/").lower()


def _path_name(value: Any) -> str:
    raw = _clean(value)
    return Path(raw).name if raw else ""


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return _lower(value) in {"1", "true", "yes", "y"}


def _row_id(row: dict[str, Any]) -> str:
    value = row.get("id")
    return str(value) if value is not None else ""


def _entity_type_from_value(value: str) -> str:
    low = value.lower()
    if "@" in value and "." in value:
        return "email"
    if low.startswith(("http://", "https://")):
        return "url"
    if "." in value and " " not in value:
        return "domain"
    return "unknown"


def _display_entity_from_finding(finding: dict[str, Any]) -> dict[str, str]:
    entity_type = _clean(finding.get("display_entity_type") or finding.get("entity_type"))
    entity_value = _clean(
        finding.get("display_entity_value")
        or finding.get("entity_value")
        or finding.get("profile_url")
        or finding.get("final_url")
    )
    profile_url = _clean(finding.get("profile_url") or finding.get("final_url"))
    source = _lower(finding.get("source_name") or finding.get("source_id"))
    markers = " ".join(_markers(finding.get("matched_markers"))).lower()
    if entity_type == "company" and profile_url and (
        "company-analyzer" in source or "guessed" in markers
    ):
        return {"type": "domain", "value": _host(profile_url)}
    if entity_type in {"", "unknown", "observation"} and entity_value:
        entity_type = _entity_type_from_value(entity_value)
    if entity_type == "url" and not entity_value and profile_url:
        entity_value = profile_url
    return {"type": entity_type or "unknown", "value": entity_value or "unknown"}


def _entity_key(row: dict[str, Any]) -> tuple[str, str]:
    if "type" in row and "value" in row:
        return (_clean(row.get("type") or "unknown"), _clean(row.get("value") or "unknown"))
    entity = _display_entity_from_finding(row)
    return (entity["type"], entity["value"])


def _all_findings(case: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for key in ("all_findings", "findings"):
        for row in case.get(key) or []:
            item = dict(row)
            marker = _row_id(item) or repr(sorted(item.items()))
            if marker in seen:
                continue
            seen.add(marker)
            rows.append(item)
    return rows


def _evidence_by_finding(evidence: list[dict[str, Any]]) -> dict[Any, list[dict[str, Any]]]:
    grouped: dict[Any, list[dict[str, Any]]] = defaultdict(list)
    for row in evidence:
        grouped[row.get("finding_id")].append(row)
    return grouped


def _sources_by_entity(findings: list[dict[str, Any]]) -> dict[tuple[str, str], set[str]]:
    grouped: dict[tuple[str, str], set[str]] = defaultdict(set)
    for row in findings:
        if _bool(row.get("rejected")) or _is_review_only_finding(row):
            continue
        key = _entity_key(row)
        source = _source_key(row)
        if key[1] and source:
            grouped[key].add(source)
    return grouped


def _evidence_count_for_finding(
    finding: dict[str, Any],
    grouped: dict[Any, list[dict[str, Any]]],
) -> int:
    if finding.get("evidence_count") is not None:
        try:
            return int(finding.get("evidence_count") or 0)
        except (TypeError, ValueError):
            return 0
    return len(grouped.get(finding.get("id"), []))


def _source_count_for_entity(
    finding: dict[str, Any],
    source_sets: dict[tuple[str, str], set[str]],
) -> int:
    count = len(source_sets.get(_entity_key(finding), set()))
    return count or (1 if _source_key(finding) else 0)


def _has_marker(finding: dict[str, Any], needle: str) -> bool:
    needle = needle.lower()
    return any(needle in marker.lower() for marker in _markers(finding.get("matched_markers")))


def _marker_has_miss(finding: dict[str, Any], needle: str) -> bool:
    needle = needle.lower()
    return any(needle in marker.lower() and ":miss:" in marker.lower() for marker in _markers(finding.get("matched_markers")))


def _is_direct_profile_candidate(finding: dict[str, Any]) -> bool:
    source_id = _lower(finding.get("source_id") or finding.get("source_name"))
    value = _clean(finding.get("profile_url") or finding.get("final_url") or finding.get("entity_value"))
    return source_id.startswith("dorking:profile:") and value.startswith(("http://", "https://"))


def _is_review_only_finding(finding: dict[str, Any]) -> bool:
    if _is_direct_profile_candidate(finding):
        return False
    source_id = _lower(finding.get("source_id") or finding.get("source_name"))
    finding_type = _lower(finding.get("finding_type"))
    markers = " ".join(_markers(finding.get("matched_markers"))).lower()
    return (
        source_id.startswith("dorking:")
        or finding_type == "dorking_lead"
        or "review_only" in markers
        or "manual_verification_required" in markers
    )


def _analysis_findings(findings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [row for row in findings if not _is_review_only_finding(row)]


def _is_review_only_source(row: dict[str, Any]) -> bool:
    source_id = _lower(row.get("source_id") or row.get("source") or row.get("name"))
    category = _lower(row.get("category") or row.get("source_category"))
    mode = _lower(row.get("collection_mode"))
    return (
        source_id.startswith("dorking:")
        or category == "search_dorking"
        or mode in {"review_only", "dorking"}
    )


def _review_only_finding_ids(findings: list[dict[str, Any]]) -> set[str]:
    return {_row_id(row) for row in findings if _row_id(row) and _is_review_only_finding(row)}


def _is_review_only_evidence(evidence: dict[str, Any], review_only_ids: set[str]) -> bool:
    finding_id = evidence.get("finding_id")
    if finding_id is not None:
        return str(finding_id) in review_only_ids
    source = _lower(
        evidence.get("source_id")
        or evidence.get("source")
        or evidence.get("source_module")
        or evidence.get("module")
    )
    kind = _lower(evidence.get("kind") or evidence.get("content_type"))
    artifact = _lower(evidence.get("artifact_path") or evidence.get("path") or evidence.get("url"))
    return (
        source.startswith("dorking:")
        or source == "search_dorking"
        or kind == "dorking_lead"
        or "dorking" in artifact
    )


def _aggregate_source_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[_clean(row.get("source")) or _clean(row.get("name")) or "unknown"].append(row)

    def merged_status(items: list[dict[str, Any]]) -> str:
        statuses = {str(row.get("status") or "unknown") for row in items}
        for status in ("successful", "timed_out", "failed", "missing_api_key", "disabled"):
            if status in statuses:
                return status
        return "unknown"

    merged = []
    for source, items in grouped.items():
        if len(items) == 1:
            merged.append(items[0])
            continue
        names = sorted({_clean(row.get("name")) for row in items if _clean(row.get("name"))})
        categories = sorted({_clean(row.get("source_category")) for row in items if _clean(row.get("source_category"))})
        health = sorted({_clean(row.get("health_status")) for row in items if _clean(row.get("health_status"))})
        sensitivities = sorted({_clean(row.get("sensitivity")) for row in items if _clean(row.get("sensitivity"))})
        labels = sorted({_clean(row.get("policy_labels")) for row in items if _clean(row.get("policy_labels"))})
        last_errors = sorted({_clean(row.get("last_error")) for row in items if _clean(row.get("last_error"))})
        reliabilities = [
            _confidence(row.get("source_reliability"))
            for row in items
            if row.get("source_reliability") not in {"", None}
        ]
        status = merged_status(items)
        merged.append(
            {
                "source": source,
                "name": ", ".join(names) if names else source,
                "status": status,
                "successful": sum(int(row.get("successful") or 0) for row in items),
                "failed": sum(int(row.get("failed") or 0) for row in items),
                "timed_out": sum(int(row.get("timed_out") or 0) for row in items),
                "missing_api_key": sum(int(row.get("missing_api_key") or 0) for row in items),
                "disabled": sum(int(row.get("disabled") or 0) for row in items),
                "source_reliability": max(reliabilities) if reliabilities else "",
                "source_category": ", ".join(categories),
                "duration": "",
                "last_error": "; ".join(last_errors[:3]),
                "health_status": ", ".join(health) if health else "unknown",
                "collection_mode": ", ".join(sorted({_clean(row.get("collection_mode")) for row in items if _clean(row.get("collection_mode"))})),
                "sensitivity": ", ".join(sensitivities),
                "policy_labels": ", ".join(labels),
                "notes": f"{len(items)} recorded source row(s) grouped.",
                "source_templates": len(items),
            }
        )
    return sorted(merged, key=lambda row: (_clean(row.get("source_category")), _clean(row.get("source"))))


def _analysis_evidence(
    evidence: list[dict[str, Any]],
    findings: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    review_only_ids = _review_only_finding_ids(findings)
    return [row for row in evidence if not _is_review_only_evidence(row, review_only_ids)]


def _timeline_event_is_review_only(row: dict[str, Any]) -> bool:
    kind = _lower(row.get("kind") or row.get("event_type"))
    source = _lower(row.get("source") or row.get("source_name") or row.get("source_id"))
    description = _lower(row.get("description"))
    return (
        kind.startswith("dorking")
        or source.startswith("dorking:")
        or "review-only dorking" in description
    )


def _timeline_event_is_noise(row: dict[str, Any]) -> bool:
    entity = _clean(row.get("entity") or row.get("entity_value"))
    if ":" in entity:
        entity_type, entity_value = entity.split(":", 1)
        if entity_type in {"query", "source"}:
            return True
        return _is_noise_entity(entity_type, entity_value)
    return False


def _is_noise_entity(entity_type: str, value: str) -> bool:
    kind = _lower(entity_type)
    raw = _clean(value)
    low = raw.lower()
    if not raw or low == "unknown":
        return True
    if kind == "domain":
        if raw != low:
            return True
        if any(low.endswith(suffix) for suffix in FILELIKE_DOMAIN_SUFFIXES):
            return True
        if any(
            token in low
            for token in (
                ".dofilter",
                ".doget",
                ".doscope",
                ".handle",
                ".java",
                ".succeeded",
                "futuretask",
                "javax.",
                "org.eclipse.",
                "org.openrdf.",
                "servlet",
            )
        ):
            return True
        if any(char in raw for char in ("/", "\\", " ", "(", ")", "_")):
            return True
        return not bool(DOMAIN_RE.fullmatch(low))
    if kind == "url":
        return not low.startswith(("http://", "https://"))
    return False


def _reportable_related_label(label: str) -> bool:
    entity_type, _, value = _clean(label).partition(":")
    if entity_type in {"query", "source"}:
        return False
    return not _is_noise_entity(entity_type, value)


def _guessed_domain(finding: dict[str, Any]) -> bool:
    markers = " ".join(_markers(finding.get("matched_markers"))).lower()
    source = _lower(finding.get("source_name") or finding.get("source_id"))
    return "guessed domain" in markers or (
        "company-analyzer" in source and _display_entity_from_finding(finding)["type"] == "domain"
    )


def _confidence_band(confidence: Any) -> str:
    score = _confidence(confidence)
    if score >= 0.8:
        return "High"
    if score >= 0.5:
        return "Medium"
    if score > 0:
        return "Low"
    return "None"


def classify_verdict(finding: dict[str, Any]) -> str:
    if _bool(finding.get("rejected")):
        return "Rejected"
    status = _lower(finding.get("status"))
    confidence = _confidence(finding.get("confidence"))
    if status in {"not_exists", "missing_keys", "error", "skipped", "blocked_by_scope"}:
        return "Unconfirmed"
    if confidence >= 0.8 and status in {"exists", "ok", "found"}:
        return "Confirmed"
    if confidence >= 0.5:
        return "Likely"
    if confidence > 0:
        return "Weak"
    return "Unconfirmed"


def classify_cluster(finding: dict[str, Any]) -> str:
    if _bool(finding.get("rejected")) or classify_verdict(finding) == "Rejected":
        return "Rejected / false positives"
    if _is_direct_profile_candidate(finding):
        return "Public profiles"
    entity = _display_entity_from_finding(finding)
    entity_type = entity["type"]
    confidence = _confidence(finding.get("confidence"))
    source = _lower(finding.get("source_name") or finding.get("source_id"))
    markers = " ".join(_markers(finding.get("matched_markers"))).lower()
    if confidence >= 0.8:
        return "Confirmed matches"
    if confidence >= 0.5:
        return "Likely matches"
    if "same-name" in markers or "same_name" in markers:
        return "Same-name only"
    if confidence <= 0:
        return "Weak observations"
    if entity_type in {"domain", "ip", "url"} or any(term in source for term in ("dns", "rdap", "crt", "urlscan", "wayback")):
        return "Infrastructure"
    if entity_type in {"profile", "username"} or "profile" in source or "social" in source:
        return "Public profiles"
    if entity_type == "company" or "registry" in source or "corporate" in source:
        return "Business registry"
    return "Unknown"


def _positive_signals(
    finding: dict[str, Any],
    *,
    evidence_count: int = 0,
    source_count: int = 0,
) -> list[str]:
    signals: list[str] = []
    if _has_marker(finding, "exact"):
        signals.append("Exact entity match")
    if _has_marker(finding, "variant") or _has_marker(finding, "username_in_final_url"):
        signals.append("Matched variant")
    if _confidence(finding.get("source_reliability")) >= 0.7:
        signals.append("Source reliability signal")
    if evidence_count > 0:
        signals.append(f"{evidence_count} preserved evidence record(s)")
    if source_count >= 2:
        signals.append(f"{source_count} independent source confirmations")
    if _has_marker(finding, "registry_match") and not _marker_has_miss(finding, "registry_match"):
        signals.append("Registry match")
    if _has_marker(finding, "cross_link") or _has_marker(finding, "cross-link"):
        signals.append("Cross-link signal")
    if finding.get("first_seen") and finding.get("last_seen"):
        signals.append("Stable first_seen / last_seen context")
    if _has_marker(finding, "relation") or _has_marker(finding, "graph"):
        signals.append("Graph relationship support")
    if _lower(finding.get("status")) in {"exists", "ok", "found"}:
        signals.append("Source reported an observed result")
    return list(dict.fromkeys(signals))


def _negative_signals(
    finding: dict[str, Any],
    *,
    evidence_count: int = 0,
    source_count: int = 0,
) -> list[str]:
    signals: list[str] = []
    confidence = _confidence(finding.get("confidence"))
    if source_count <= 1:
        signals.append("Single-source observation")
    if _marker_has_miss(finding, "registry") or not _has_marker(finding, "registry_match"):
        signals.append("No registry confirmation")
    if source_count <= 1:
        signals.append("No independent confirmation")
    if _guessed_domain(finding):
        signals.append("Domain was guessed from target name")
    reliability = _confidence(finding.get("source_reliability"))
    if reliability and reliability < 0.5:
        signals.append("Low source reliability")
    if _has_marker(finding, "duplicate"):
        signals.append("Duplicate result")
    if _has_marker(finding, "conflict"):
        signals.append("Conflicting evidence")
    if _lower(finding.get("status")) in {"unknown", "", "skipped"}:
        signals.append("Status needs review")
    if _bool(finding.get("rejected")):
        signals.append("Rejected flag is set")
    if evidence_count <= 0:
        signals.append("No preserved evidence")
    if confidence <= 0:
        signals.append("No confirmation signals")
    return list(dict.fromkeys(signals))


def humanize_confidence(finding: dict[str, Any]) -> dict[str, Any]:
    confidence = _confidence(finding.get("confidence"))
    source_count = int(finding.get("source_count") or 0)
    evidence_count = int(finding.get("evidence_count") or 0)
    positive = _positive_signals(finding, evidence_count=evidence_count, source_count=source_count)
    negative = _negative_signals(finding, evidence_count=evidence_count, source_count=source_count)
    explanation: list[str] = []
    summary = f"{_confidence_band(confidence)} confidence ({_pct(confidence)}%)"
    if confidence >= 0.8 and source_count <= 1:
        summary += "; single-source, verify independently"
    elif negative:
        summary += f"; weakness: {negative[0].lower()}"
    explanation.append(summary)
    return {
        "score": confidence,
        "percent": _pct(confidence),
        "band": _confidence_band(confidence),
        "label": f"{_confidence_band(confidence)} / {_pct(confidence)}%" if confidence else "No confidence / 0%",
        "explanation": explanation,
        "positive_signals": positive,
        "negative_signals": negative,
        "warning": "High score, but single-source evidence. Requires independent verification."
        if confidence >= 0.8 and source_count <= 1
        else "",
    }


def _finding_title(finding: dict[str, Any]) -> str:
    if _bool(finding.get("rejected")):
        return "Rejected / false positive candidate"
    if _is_direct_profile_candidate(finding):
        return "Profile URL candidate"
    entity = _display_entity_from_finding(finding)
    finding_type = _lower(finding.get("finding_type"))
    if finding_type in {"observation", "", "unknown"} and entity["type"] in {"domain", "url"}:
        return "Possible related domain / URL" if entity["type"] == "url" else "Possible related domain"
    if entity["type"] == "url":
        return "Possible related URL"
    if entity["type"] == "domain":
        return "Infrastructure lead"
    if entity["type"] in {"profile", "username"}:
        return "Public profile lead"
    if entity["type"] == "company":
        return "Business registry / company lead"
    if finding_type:
        return finding_type.replace("_", " ").title()
    return "Requires review"


def humanize_finding(finding: dict[str, Any]) -> dict[str, Any]:
    entity = _display_entity_from_finding(finding)
    verdict = classify_verdict(finding)
    confidence = humanize_confidence(finding)
    evidence_count = int(finding.get("evidence_count") or 0)
    source_count = int(finding.get("source_count") or 0)
    independent_count = int(finding.get("independent_corroboration_count") or source_count)
    weakness = ", ".join(confidence["negative_signals"][:3]) or "No major weakness recorded"
    if verdict == "Rejected":
        explanation = _clean(finding.get("reject_reason")) or "Rejected candidate."
    elif confidence["score"] <= 0:
        explanation = "Unconfirmed lead (manual review)."
    else:
        explanation = f"{_source_name(finding)}: {entity['type']} {entity['value']}."
    return {
        "id": finding.get("id"),
        "verdict": verdict,
        "confidence": confidence,
        "title": _finding_title(finding),
        "entity_type": entity["type"],
        "entity_value": entity["value"],
        "source": _source_name(finding),
        "source_id": _source_key(finding),
        "source_risk_label": _clean(finding.get("source_risk_label")),
        "human_review_required": bool(finding.get("human_review_required")),
        "human_review_reasons": list(finding.get("human_review_reasons") or []),
        "plain_language_explanation": explanation,
        "why_matched": "matched markers: " + _clean(finding.get("matched_markers"))
        if _clean(finding.get("matched_markers"))
        else "no explicit match markers recorded",
        "confidence_reason": _clean(finding.get("confidence_reason")),
        "evidence_count": evidence_count,
        "source_count": source_count,
        "independent_corroboration_count": independent_count,
        "weakness": weakness,
        "next_action": _next_action_for_entity(entity["type"], entity["value"], finding),
        "status_label": "Needs review" if _lower(finding.get("status")) in {"unknown", "", "skipped"} else _clean(finding.get("status")),
        "url": _clean(finding.get("profile_url") or finding.get("final_url")),
        "raw_id": finding.get("id"),
    }


def humanize_evidence(evidence: dict[str, Any]) -> dict[str, Any]:
    sha = _clean(evidence.get("sha256"))
    artifact = _clean(evidence.get("artifact_path") or evidence.get("path"))
    kind = _clean(evidence.get("kind") or evidence.get("content_type") or evidence.get("source_module") or "evidence")
    return {
        "id": evidence.get("id"),
        "type": kind,
        "summary": _clean(evidence.get("url") or artifact or sha or "Evidence record"),
        "sha256": sha,
        "has_hash": bool(sha),
        "artifact": artifact,
        "captured_at": _clean(evidence.get("captured_at")),
        "integrity": "hash present" if sha else "missing hash",
    }


def humanize_relation(relation: dict[str, Any]) -> dict[str, Any]:
    label = _clean(relation.get("rel") or "related_to").replace("_", " ")
    source = f"{_clean(relation.get('src_type'))}:{_clean(relation.get('src_value'))}"
    target = f"{_clean(relation.get('dst_type'))}:{_clean(relation.get('dst_value'))}"
    return {
        "id": relation.get("id"),
        "label": label,
        "source": source,
        "target": target,
        "confidence": _confidence(relation.get("confidence") or relation.get("weight") or 0.5),
        "evidence_count": int(relation.get("evidence_count") or 0),
        "explanation": f"{source} {label} {target}.",
    }


def build_case_metadata(case: dict[str, Any]) -> dict[str, Any]:
    meta = dict(case.get("meta") or case)
    runs = list(meta.get("runs") or [])
    latest = runs[-1] if runs else {}
    created_values = [_clean(row.get("created_at")) for row in runs if _clean(row.get("created_at"))]
    updated_values = [_clean(row.get("updated_at") or row.get("created_at")) for row in runs if _clean(row.get("updated_at") or row.get("created_at"))]
    target = _clean(meta.get("target") or latest.get("target") or case.get("target") or meta.get("case"))
    module = _clean(meta.get("module") or latest.get("module") or case.get("module") or "case")
    case_name = _clean(meta.get("case") or case.get("case") or "case")
    inferred_type = module
    for candidate in ("company", "domain", "username", "email", "ip", "phone", "wallet", "url", "image"):
        if case_name.startswith(f"{candidate}-") or case_name.startswith(f"{candidate}_"):
            inferred_type = candidate
            break
    if module in {"search_dorking", "query_pipeline"} and inferred_type == module:
        inferred_type = "search"
    search_module = "unified_search" if module in {"search_dorking", "query_pipeline"} or "_search" in case_name else module
    return {
        "case_title": case_name,
        "case_name": case_name,
        "target": target,
        "entity_type": inferred_type or "case",
        "search_module": search_module or "case",
        "scope": _clean(meta.get("scope") or search_module or module or "case"),
        "created_at": min(created_values) if created_values else "",
        "updated_at": max(updated_values) if updated_values else "",
        "runs_count": int(meta.get("run_count") or len(runs) or 0),
        "runs": runs,
        "report_generated_at": _iso_now(),
        "report_version": REPORT_VERSION,
        "legal_privacy_note": LEGAL_PRIVACY_NOTE,
        "found": meta.get("found") is not False,
    }


def _prepare_findings(
    findings: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    evidence_groups = _evidence_by_finding(evidence)
    source_sets = _sources_by_entity(findings)
    prepared = []
    for row in findings:
        item = dict(row)
        item["evidence_count"] = _evidence_count_for_finding(item, evidence_groups)
        item["source_count"] = _source_count_for_entity(item, source_sets)
        item["verdict"] = classify_verdict(item)
        item["cluster"] = classify_cluster(item)
        prepared.append(item)
    return prepared


def build_executive_summary(
    case: dict[str, Any],
    findings: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
    sources: list[dict[str, Any]],
    relations: list[dict[str, Any]],
) -> dict[str, Any]:
    metadata = build_case_metadata(case)
    analysis_rows = _analysis_findings(findings)
    review_only_count = len(findings) - len(analysis_rows)
    counts = Counter(classify_verdict(row) for row in analysis_rows)
    confidence_values = [_confidence(row.get("confidence")) for row in analysis_rows if not _bool(row.get("rejected"))]
    overall = round((sum(confidence_values) / len(confidence_values)) if confidence_values else 0.0, 3)
    weak_risks = build_false_positive_risks(analysis_rows or findings)
    evidence_summary = build_evidence_summary(evidence, findings)
    next_actions = build_recommended_next_actions(case, case.get("entities") or [], analysis_rows)
    status = (
        "Confirmed findings present"
        if counts["Confirmed"]
        else "Needs corroboration"
        if counts["Likely"]
        else "Needs review"
    )
    what_found = "No confirmed findings yet."
    if analysis_rows:
        what_found = (
            f"{len(analysis_rows)} analyst finding(s): {counts['Confirmed']} confirmed, "
            f"{counts['Likely']} likely, {counts['Weak']} weak, "
            f"{counts['Unconfirmed']} unconfirmed, {counts['Rejected']} rejected."
        )
        if review_only_count:
            what_found += f" {review_only_count} review-only dorking lead(s) were moved out of Key Findings."
    elif review_only_count:
        what_found = f"No confirmed findings yet. {review_only_count} review-only dorking lead(s) need manual review."
    return {
        "target": metadata["target"],
        "entity_type": metadata["entity_type"],
        "case_status": status,
        "what_was_checked": f"{metadata['search_module']} scope for {metadata['target']}",
        "what_was_found": what_found,
        "overall_confidence": {
            "score": overall,
            "percent": _pct(overall),
            "label": f"{_confidence_band(overall)} / {_pct(overall)}%" if overall else "No confidence / 0%",
        },
        "counts": {
            "confirmed": counts["Confirmed"],
            "likely": counts["Likely"],
            "weak": counts["Weak"],
            "unconfirmed": counts["Unconfirmed"],
            "rejected": counts["Rejected"],
            "findings": len(analysis_rows),
            "review_only_leads": review_only_count,
            "evidence": evidence_summary["total_evidence_files"],
            "review_only_evidence": evidence_summary["review_only_evidence_files"],
            "sources": len(sources),
            "relations": len(relations),
        },
        "main_false_positive_risk": weak_risks[0]["risk"] if weak_risks else "No major false-positive risk recorded.",
        "main_evidence_problem": evidence_summary["missing_evidence"][0] if evidence_summary["missing_evidence"] else "No major evidence gap recorded.",
        "next_recommended_step": next_actions[0]["action"] if next_actions else "Review raw appendix and preserved evidence.",
        "plain_language": [
            item
            for item in [
            f"Investigated {metadata['target']} as {metadata['entity_type']}.",
            what_found,
            f"{review_only_count} review-only lead(s) are preserved for manual review, not treated as confirmed results."
            if review_only_count
            else "",
            "Confidence is based on confirmation signals, source count, evidence and false-positive controls.",
            ]
            if item
        ],
    }


def build_key_findings(
    findings: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
    sources: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    del evidence, sources
    priority = {"Confirmed": 0, "Likely": 1, "Weak": 2, "Unconfirmed": 3, "Rejected": 4}
    analysis_rows = _analysis_findings(findings)
    key_rows = [row for row in analysis_rows if not _bool(row.get("rejected"))]
    rows = sorted(
        key_rows,
        key=lambda row: (
            priority.get(classify_verdict(row), 9),
            -_confidence(row.get("confidence")),
            _source_name(row),
        ),
    )
    humanized = [humanize_finding(row) for row in rows[:10]]
    if not humanized:
        review_only_count = len(findings) - len(analysis_rows)
        humanized.append(
            {
                "verdict": "Unconfirmed",
                "confidence": {
                    "score": 0.0,
                    "percent": 0,
                    "band": "None",
                    "label": "No confidence / 0%",
                    "explanation": ["None confidence (0%)"],
                    "positive_signals": [],
                    "negative_signals": ["No findings recorded"],
                    "warning": "",
                },
                "title": "No confirmed findings",
                "plain_language_explanation": "No analyst findings were recorded for this case."
                if not review_only_count
                else f"{review_only_count} review-only dorking lead(s) were generated, but none are confirmed findings.",
                "evidence_count": 0,
                "source_count": 0,
                "weakness": "No evidence",
                "next_action": "Run relevant sources for the target type.",
            }
        )
    return humanized


def _group_for_entity(entity_type: str, value: str) -> str:
    kind = entity_type.lower()
    if kind in {"domain", "hostname"}:
        return "domains"
    if kind in {"url", "profile"}:
        if any(site in value.lower() for site in ("twitter.", "x.com", "facebook.", "instagram.", "linkedin.", "github.", "gitlab.", "reddit.", "t.me", "youtube.")):
            return "social_profiles"
        return "urls"
    if kind == "email":
        return "emails"
    if kind == "phone":
        return "phones"
    if kind in {"ip", "ipv4", "ipv6"}:
        return "ips"
    if kind in {"company", "brand", "organization"}:
        return "companies"
    if kind == "username":
        return "usernames"
    if kind in {"wallet", "crypto", "btc", "eth"}:
        return "crypto"
    if kind in {"file", "hash", "sha256", "md5"}:
        return "files"
    return "unknown"


def build_entity_overview(
    entities: list[dict[str, Any]],
    findings: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
    relations: list[dict[str, Any]],
) -> dict[str, Any]:
    source_sets = _sources_by_entity(findings)
    evidence_groups = _evidence_by_finding(evidence)
    rows_by_key: dict[tuple[str, str], dict[str, Any]] = {}
    for row in entities:
        key = _entity_key(row)
        rows_by_key.setdefault(
            key,
            {
                "value": key[1],
                "type": key[0],
                "confidence": 0.0,
                "source_count": 0,
                "evidence_count": 0,
                "first_seen": _clean(row.get("created_at")),
                "last_seen": _clean(row.get("created_at")),
                "related_entities": [],
                "actions": [],
            },
        )
    for finding in findings:
        if _is_review_only_finding(finding):
            continue
        key = _entity_key(finding)
        entity = rows_by_key.setdefault(
            key,
            {
                "value": key[1],
                "type": key[0],
                "confidence": 0.0,
                "source_count": 0,
                "evidence_count": 0,
                "first_seen": "",
                "last_seen": "",
                "related_entities": [],
                "actions": [],
            },
        )
        entity["confidence"] = max(entity["confidence"], _confidence(finding.get("confidence")))
        entity["source_count"] = max(entity["source_count"], len(source_sets.get(key, set())))
        entity["evidence_count"] += len(evidence_groups.get(finding.get("id"), []))
        first_seen = _clean(finding.get("first_seen") or finding.get("captured_at"))
        last_seen = _clean(finding.get("last_seen") or finding.get("captured_at"))
        if first_seen and (not entity["first_seen"] or first_seen < entity["first_seen"]):
            entity["first_seen"] = first_seen
        if last_seen and (not entity["last_seen"] or last_seen > entity["last_seen"]):
            entity["last_seen"] = last_seen
    for relation in relations:
        src = (_clean(relation.get("src_type")), _clean(relation.get("src_value")))
        dst = (_clean(relation.get("dst_type")), _clean(relation.get("dst_value")))
        if _is_noise_entity(src[0], src[1]) or _is_noise_entity(dst[0], dst[1]):
            continue
        if src in rows_by_key:
            rows_by_key[src]["related_entities"].append(f"{dst[0]}:{dst[1]}")
        if dst in rows_by_key:
            rows_by_key[dst]["related_entities"].append(f"{src[0]}:{src[1]}")
    groups = {
        key: {"title": title, "entities": []}
        for key, title in ENTITY_GROUPS
    }
    reportable_entities: list[dict[str, Any]] = []
    for entity in rows_by_key.values():
        if _is_noise_entity(entity["type"], entity["value"]):
            continue
        if entity["type"] in {"query", "source"}:
            continue
        if not (entity["confidence"] > 0 or entity["source_count"] > 0 or entity["evidence_count"] > 0):
            continue
        if entity["type"] in {"domain", "url", "unknown"} and not (
            entity["confidence"] > 0
            or entity["source_count"] > 0
            or entity["evidence_count"] > 0
        ):
            continue
        entity["confidence_label"] = f"{_confidence_band(entity['confidence'])} / {_pct(entity['confidence'])}%" if entity["confidence"] else "No confidence / 0%"
        reportable_entities.append(entity)
    reportable_labels = {
        f"{entity['type']}:{entity['value']}"
        for entity in reportable_entities
    }
    for entity in reportable_entities:
        entity["related_entities"] = [
            label
            for label in sorted(set(entity["related_entities"]))
            if label in reportable_labels and _reportable_related_label(label)
        ][:10]
        entity["actions"] = [_next_action_for_entity(entity["type"], entity["value"], {})]
        group_key = _group_for_entity(entity["type"], entity["value"])
        groups[group_key]["entities"].append(entity)
    return {
        "groups": groups,
        "all_entities": sorted(
            reportable_entities,
            key=lambda row: (row["type"], row["value"]),
        ),
    }


def _cluster_review_reasons(cluster: dict[str, Any]) -> list[str]:
    reasons: list[str] = []
    for reason in cluster.get("review_reasons") or []:
        if _clean(reason):
            reasons.append(_clean(reason))
    for member in cluster.get("members") or []:
        for reason in member.get("review_reasons") or []:
            if _clean(reason):
                reasons.append(_clean(reason))
    if cluster.get("human_review_required") and not reasons:
        reasons.append("requires analyst review")
    return sorted(set(reasons))


def _alias_link_row(link: dict[str, Any]) -> dict[str, Any]:
    left = link.get("from") or {}
    right = link.get("into") or {}
    return {
        "from": f"{_clean(left.get('type'))}:{_clean(left.get('value'))}",
        "into": f"{_clean(right.get('type'))}:{_clean(right.get('value'))}",
        "relation": _clean(link.get("rel") or "alias"),
        "reason": _clean(link.get("reason") or "entity resolution"),
    }


def build_entity_correlation(
    case: dict[str, Any],
    entities: list[dict[str, Any]],
    relations: list[dict[str, Any]],
    findings: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
) -> dict[str, Any]:
    resolution = case.get("entity_resolution")
    if not isinstance(resolution, dict):
        analysis_findings = _analysis_findings(findings)
        analysis_evidence = _analysis_evidence(evidence, findings)
        resolution = resolve_entities(
            entities,
            relations,
            findings=analysis_findings,
            evidence=analysis_evidence,
        )

    counts = resolution.get("counts") or {}
    clusters = []
    review_queue = []
    for row in resolution.get("entity_clusters") or []:
        reasons = _cluster_review_reasons(row)
        display_values = [_clean(value) for value in row.get("display_values") or [] if _clean(value)]
        types = [_clean(value) for value in row.get("types") or [] if _clean(value)]
        members = row.get("member_ids") or []
        cluster = {
            "id": _clean(row.get("id")),
            "types": types,
            "display_values": display_values,
            "members": len(members),
            "member_ids": [str(member) for member in members],
            "independent_sources": int(row.get("independent_sources") or 0),
            "source_ids": [_clean(source) for source in row.get("source_ids") or [] if _clean(source)],
            "finding_ids": [str(finding_id) for finding_id in row.get("finding_ids") or []],
            "evidence_count": int(row.get("evidence_count") or 0),
            "max_confidence": _confidence(row.get("max_confidence")),
            "max_confidence_label": f"{_confidence_band(row.get('max_confidence'))} / {_pct(row.get('max_confidence'))}%",
            "alias_link_count": int(row.get("alias_link_count") or 0),
            "human_review_required": _bool(row.get("human_review_required")),
            "review": "needs review" if _bool(row.get("human_review_required")) else "corroborated",
            "review_reasons": reasons,
        }
        clusters.append(cluster)
        if cluster["human_review_required"]:
            review_queue.append(
                {
                    "cluster_id": cluster["id"],
                    "entities": ", ".join(cluster["display_values"][:5]),
                    "types": ", ".join(cluster["types"]),
                    "sources": cluster["independent_sources"],
                    "evidence": cluster["evidence_count"],
                    "reasons": "; ".join(reasons),
                }
            )

    alias_links = [_alias_link_row(link) for link in resolution.get("alias_links") or []]
    summary = {
        "canonical_entities": int(counts.get("canonical_entities") or 0),
        "entity_clusters": int(counts.get("entity_clusters") or len(clusters)),
        "alias_links": int(counts.get("alias_links") or len(alias_links)),
        "supported_by_findings": int(counts.get("supported_by_findings") or 0),
        "needs_review": int(counts.get("needs_review") or len(review_queue)),
    }
    return {
        "summary": summary,
        "clusters": clusters,
        "alias_links": alias_links,
        "review_queue": review_queue,
        "empty": not clusters,
        "empty_explanation": "No entity correlation data was recorded." if not clusters else "",
    }


def build_result_clusters(findings: list[dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[str, list[dict[str, Any]]] = {name: [] for name in CLUSTER_ORDER}
    for row in findings:
        if _is_review_only_finding(row):
            grouped["Review-only leads"].append(row)
        else:
            grouped.setdefault(classify_cluster(row), []).append(row)
    clusters = []
    for name in CLUSTER_ORDER:
        rows = grouped.get(name, [])
        if name == "Review-only leads":
            source_counts = Counter(_source_key(row) or _source_name(row) for row in rows)
            top = [
                {
                    "title": "Review-only search lead batch",
                    "entity_value": f"{count} lead(s) from {source}",
                    "confidence": {"label": "Review-only / unconfirmed"},
                }
                for source, count in source_counts.most_common(5)
            ]
        else:
            top = [humanize_finding(row) for row in sorted(rows, key=lambda item: -_confidence(item.get("confidence")))[:5]]
        weakness = "Requires analyst review."
        if name == "Confirmed matches":
            weakness = "Still verify source evidence before external reporting."
        elif name == "Rejected / false positives":
            weakness = "Do not promote these as positive matches."
        elif name == "Review-only leads":
            weakness = "These are search URLs or dorking leads, not confirmed evidence."
        elif name == "Weak observations":
            weakness = "Weak or missing confirmation signals."
        clusters.append(
            {
                "name": name,
                "count": len(rows),
                "meaning": CLUSTER_MEANINGS[name],
                "top_items": top,
                "why_grouped_here": f"Classified by verdict, confidence, entity type and source context as {name}.",
                "weakness": weakness,
                "recommended_next_action": "Manually inspect promising leads and promote only confirmed observations."
                if name == "Review-only leads"
                else "Corroborate with an independent source."
                if name not in {"Rejected / false positives", "Confirmed matches"}
                else "Keep rejected rationale documented." if name == "Rejected / false positives" else "Preserve evidence and review before reporting.",
            }
        )
    return {"clusters": clusters, "by_name": {row["name"]: row for row in clusters}}


def build_evidence_summary(
    evidence: list[dict[str, Any]],
    findings: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    findings = findings or []
    review_only_ids = _review_only_finding_ids(findings)
    analysis_raw_rows = [row for row in evidence if not _is_review_only_evidence(row, review_only_ids)]
    review_only_raw_rows = [row for row in evidence if _is_review_only_evidence(row, review_only_ids)]
    rows = [humanize_evidence(row) for row in analysis_raw_rows]
    review_only_rows = [humanize_evidence(row) for row in review_only_raw_rows]
    hashes = [row["sha256"] for row in rows if row["sha256"]]
    duplicate_hashes = sorted([item for item, count in Counter(hashes).items() if count > 1])
    missing_hash = [row for row in rows if not row["has_hash"]]
    screenshots = [row for row in rows if "screen" in row["type"].lower() or _path_name(row["artifact"]).lower().endswith((".png", ".jpg", ".jpeg", ".webp"))]
    pages = [row for row in rows if any(term in row["type"].lower() for term in ("html", "page", "text/html"))]
    files = [row for row in rows if row["artifact"]]
    integrity_status = "verified hashes present" if rows and not missing_hash else "missing hashes" if missing_hash else "no evidence recorded"
    return {
        "total_evidence_files": len(rows),
        "all_evidence_files": len(evidence),
        "review_only_evidence_files": len(review_only_rows),
        "screenshots": len(screenshots),
        "pages": len(pages),
        "files": len(files),
        "hash_records": len(hashes),
        "review_only_hash_records": sum(1 for row in review_only_rows if row["sha256"]),
        "evidence_integrity_status": integrity_status,
        "missing_evidence": ["No evidence records were preserved."] if not rows else [f"{len(missing_hash)} evidence record(s) have no SHA-256 hash."] if missing_hash else [],
        "duplicate_evidence": duplicate_hashes,
        "evidence_chain": rows,
        "review_only_evidence_sample": review_only_rows[:10],
        "manifest": {
            "available": bool(rows or review_only_rows),
            "hash_algorithm": "sha256",
            "records_with_hash": len(hashes),
            "review_only_records_with_hash": sum(1 for row in review_only_rows if row["sha256"]),
        },
    }


def build_source_coverage(
    sources: list[dict[str, Any]],
    findings: list[dict[str, Any]],
    diagnostics: dict[str, Any] | None = None,
) -> dict[str, Any]:
    diagnostics = diagnostics or {}
    rows = []
    review_only_sources = []
    for source in sources:
        success = int(source.get("success_count") or 0)
        errors = int(source.get("error_count") or 0)
        health = _lower(source.get("health_status"))
        last_error = _clean(source.get("last_error"))
        status = "successful" if success > 0 else "failed" if errors or last_error else "missing_api_key" if health == "missing_keys" else "disabled" if health in {"disabled", "skipped"} else "unknown"
        if "timeout" in last_error.lower():
            status = "timed_out"
        row = {
            "source": _source_key(source),
            "name": _source_name(source),
            "status": status,
            "successful": success,
            "failed": errors,
            "timed_out": 1 if status == "timed_out" else 0,
            "missing_api_key": 1 if status == "missing_api_key" else 0,
            "disabled": 1 if status == "disabled" else 0,
            "source_reliability": source.get("reliability"),
            "source_category": source.get("category") or "",
            "duration": source.get("duration") or source.get("duration_seconds") or "",
            "last_error": last_error,
            "health_status": source.get("health_status") or "unknown",
            "collection_mode": source.get("collection_mode") or "",
            "sensitivity": source.get("sensitivity") or "",
            "policy_labels": source.get("policy_labels") or "",
        }
        if _is_review_only_source(source):
            review_only_sources.append(row)
            continue
        rows.append(row)
    rows = _aggregate_source_rows(rows)
    if review_only_sources:
        review_statuses = Counter(row["status"] for row in review_only_sources)
        rows.append(
            {
                "source": "dorking:review_queue",
                "name": "Review-only dorking leads",
                "status": "review_only",
                "successful": sum(int(row.get("successful") or 0) for row in review_only_sources),
                "failed": sum(int(row.get("failed") or 0) for row in review_only_sources),
                "timed_out": sum(int(row.get("timed_out") or 0) for row in review_only_sources),
                "missing_api_key": sum(int(row.get("missing_api_key") or 0) for row in review_only_sources),
                "disabled": sum(int(row.get("disabled") or 0) for row in review_only_sources),
                "source_reliability": "",
                "source_category": "search_dorking",
                "duration": "",
                "last_error": "",
                "health_status": "review_only",
                "collection_mode": "manual_review",
                "sensitivity": "standard",
                "policy_labels": "manual_verification_required",
                "notes": f"{len(review_only_sources)} dorking source template(s) grouped out of the main source list.",
                "source_templates": len(review_only_sources),
                "status_breakdown": dict(review_statuses),
            }
        )
    status_counts = Counter(row["status"] for row in rows if row.get("status") != "review_only")
    analysis_findings = _analysis_findings(findings)
    review_only_findings = [row for row in findings if _is_review_only_finding(row)]
    if diagnostics.get("summary") and not rows:
        summary = dict(diagnostics.get("summary") or {})
    else:
        visible_review_row_count = 1 if review_only_sources else 0
        summary = {
            "sources_checked": len(rows),
            "all_source_records": len(sources),
            "analyst_sources_checked": len(rows) - visible_review_row_count,
            "analyst_source_records": len(sources) - len(review_only_sources),
            "review_only_source_templates": len(review_only_sources),
            "successful_sources": status_counts["successful"],
            "failed_sources": status_counts["failed"],
            "timed_out_sources": status_counts["timed_out"],
            "missing_api_keys": status_counts["missing_api_key"],
            "disabled_sources": status_counts["disabled"],
            "unknown_sources": status_counts["unknown"],
            "review_only_successful_sources": sum(1 for row in review_only_sources if row["status"] == "successful"),
            "findings_by_source": len({_source_key(row) for row in analysis_findings if _source_key(row)}),
            "review_only_findings_by_source": len({_source_key(row) for row in review_only_findings if _source_key(row)}),
        }
    return {"summary": summary, "rows": rows, "review_only_rows": review_only_sources}


def build_confidence_breakdown(
    findings: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
    sources: list[dict[str, Any]],
    relations: list[dict[str, Any]],
) -> dict[str, Any]:
    del evidence, sources
    analysis_rows = _analysis_findings(findings)
    review_only_count = len(findings) - len(analysis_rows)
    confidence_values = [_confidence(row.get("confidence")) for row in analysis_rows if not _bool(row.get("rejected"))]
    overall = round((sum(confidence_values) / len(confidence_values)) if confidence_values else 0.0, 3)
    positives: list[str] = []
    negatives: list[str] = []
    independent = 0
    single_source_warnings = []
    registry_matches = 0
    cross_links = 0
    for row in analysis_rows:
        conf = humanize_confidence(row)
        positives.extend(conf["positive_signals"])
        negatives.extend(conf["negative_signals"])
        if int(row.get("source_count") or 0) >= 2:
            independent += 1
        if int(row.get("source_count") or 0) <= 1:
            single_source_warnings.append(_display_entity_from_finding(row)["value"])
        if "Registry match" in conf["positive_signals"]:
            registry_matches += 1
        if any("Cross-link" in signal for signal in conf["positive_signals"]):
            cross_links += 1
    conflicts = sum(1 for row in analysis_rows if _has_marker(row, "conflict"))
    duplicate_penalties = sum(1 for row in analysis_rows if _has_marker(row, "duplicate"))
    rejected_count = sum(1 for row in analysis_rows if _bool(row.get("rejected")))
    return {
        "overall_confidence": {
            "score": overall,
            "percent": _pct(overall),
            "label": f"{_confidence_band(overall)} / {_pct(overall)}%" if overall else "No confidence / 0%",
        },
        "positive_signals": sorted(set(positives)) or ["No positive confidence signals recorded."],
        "negative_signals": sorted(set(negatives)) or ["No major negative confidence signals recorded."],
        "independent_confirmations": independent,
        "single_source_warnings": sorted(set(single_source_warnings)),
        "registry_confirmation_status": "present" if registry_matches else "not confirmed",
        "registry_matches": registry_matches,
        "cross_links": cross_links,
        "conflicts": conflicts,
        "duplicate_penalties": duplicate_penalties,
        "rejected_count": rejected_count,
        "review_only_leads": review_only_count,
    }


def build_graph_summary(
    entities: list[dict[str, Any]],
    relations: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
    reportable_entities: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    del evidence
    base_entities = reportable_entities if reportable_entities is not None else entities
    restrict_to_reportable = reportable_entities is not None
    entity_nodes = {
        _entity_key(row)
        for row in base_entities
        if not _is_noise_entity(_entity_key(row)[0], _entity_key(row)[1])
        and _entity_key(row)[0] not in {"query", "source"}
    }
    filtered_relations = []
    for relation in relations:
        src = (_clean(relation.get("src_type")), _clean(relation.get("src_value")))
        dst = (_clean(relation.get("dst_type")), _clean(relation.get("dst_value")))
        if _is_noise_entity(src[0], src[1]) or _is_noise_entity(dst[0], dst[1]):
            continue
        if src[0] in {"query", "source"} or dst[0] in {"query", "source"}:
            continue
        if restrict_to_reportable and (src not in entity_nodes or dst not in entity_nodes):
            continue
        entity_nodes.add(src)
        entity_nodes.add(dst)
        filtered_relations.append(relation)
    relation_rows = [humanize_relation(row) for row in filtered_relations]
    sparse = len(entity_nodes) < 3 or len(relation_rows) < 2
    return {
        "entities": len(entity_nodes),
        "relationships": len(relation_rows),
        "relation_labels": sorted({row["label"] for row in relation_rows}),
        "edges": relation_rows,
        "sparse": sparse,
        "sparse_graph_explanation": "Sparse graph: there are too few nodes or edges to infer structure."
        if sparse
        else "",
    }


def build_timeline_summary(
    timeline: list[dict[str, Any]],
    findings: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
) -> dict[str, Any]:
    rows = []
    review_only_events = 0
    suppressed_noise_events = 0
    for row in timeline:
        if _timeline_event_is_review_only(row):
            review_only_events += 1
            continue
        if _timeline_event_is_noise(row):
            suppressed_noise_events += 1
            continue
        rows.append(
            {
                "when": _clean(row.get("when")),
                "kind": _clean(row.get("kind") or "event"),
                "entity": _clean(row.get("entity") or row.get("entity_value")),
                "source": _clean(row.get("source") or row.get("source_name")),
                "confidence": _confidence(row.get("confidence")),
                "description": _clean(row.get("description")),
            }
        )
    if not rows:
        for finding in findings[:20]:
            if finding.get("captured_at") or finding.get("last_seen") or finding.get("first_seen"):
                rows.append(
                    {
                        "when": _clean(finding.get("captured_at") or finding.get("last_seen") or finding.get("first_seen")),
                        "kind": "finding captured",
                        "entity": _display_entity_from_finding(finding)["value"],
                        "source": _source_name(finding),
                        "confidence": _confidence(finding.get("confidence")),
                        "description": _finding_title(finding),
                    }
                )
        for row in evidence[:20]:
            rows.append(
                {
                    "when": _clean(row.get("captured_at")),
                    "kind": "evidence stored",
                    "entity": _clean(row.get("url") or row.get("artifact_path") or row.get("sha256")),
                    "source": _clean(row.get("source_module")),
                    "confidence": _confidence(row.get("confidence_at_capture")),
                    "description": "Evidence record preserved.",
                }
            )
    rows.sort(key=lambda row: row.get("when") or "")
    return {
        "events": rows,
        "count": len(rows),
        "empty": not rows,
        "empty_explanation": "No timeline events were recorded." if not rows else "",
        "event_types": dict(Counter(row["kind"] for row in rows)),
        "review_only_events": review_only_events,
        "suppressed_noise_events": suppressed_noise_events,
    }


def build_unconfirmed_hypotheses(
    findings: list[dict[str, Any]],
    entities: list[dict[str, Any]],
    relations: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    del entities, relations
    rows = []
    for finding in findings:
        if _bool(finding.get("rejected")) or _is_review_only_finding(finding):
            continue
        confidence = _confidence(finding.get("confidence"))
        if confidence >= 0.5:
            continue
        entity = _display_entity_from_finding(finding)
        reason = "This may be related, but current evidence is not confirmed."
        if _guessed_domain(finding):
            reason = "This domain-like result was guessed from the target name."
        rows.append(
            {
                "hypothesis": f"{entity['value']} may be related to the target.",
                "entity_type": entity["type"],
                "entity_value": entity["value"],
                "why_hypothesis": reason,
                "needed_sources": _sources_needed_for_entity(entity["type"]),
            }
        )
    return rows


def build_false_positive_risks(findings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    checks = [
        ("same-name only", lambda row: _has_marker(row, "same_name") or _has_marker(row, "same-name")),
        ("single-source evidence", lambda row: int(row.get("source_count") or 0) <= 1),
        ("guessed domain", _guessed_domain),
        ("no registry match", lambda row: _marker_has_miss(row, "registry") or not _has_marker(row, "registry_match")),
        ("no independent confirmation", lambda row: int(row.get("source_count") or 0) <= 1),
        ("weak source", lambda row: 0 < _confidence(row.get("source_reliability")) < 0.5),
        ("conflict", lambda row: _has_marker(row, "conflict")),
        ("rejected candidate", lambda row: _bool(row.get("rejected"))),
    ]
    risks = []
    for label, predicate in checks:
        matched = [row for row in findings if predicate(row)]
        if matched:
            risks.append(
                {
                    "risk": label,
                    "count": len(matched),
                    "examples": [_display_entity_from_finding(row)["value"] for row in matched[:5]],
                    "meaning": _risk_meaning(label),
                }
            )
    return risks


def _risk_meaning(label: str) -> str:
    meanings = {
        "same-name only": "The match may only share a name or username.",
        "single-source evidence": "One source is not enough for confident attribution.",
        "guessed domain": "The domain was inferred from the target name and needs confirmation.",
        "no registry match": "No registry source confirmed this observation.",
        "no independent confirmation": "No second independent source supports the observation.",
        "weak source": "The supporting source has low reliability.",
        "conflict": "Recorded evidence includes conflicting signals.",
        "rejected candidate": "The candidate was explicitly rejected.",
    }
    return meanings.get(label, "Requires analyst review.")


def _sources_needed_for_entity(entity_type: str) -> list[str]:
    mapping = {
        "company": ["/business/registry", "/business/news", "/business/social_profiles"],
        "domain": ["/infra/dns", "/infra/certificates", "/archive/wayback", "/cyber/urlscan"],
        "url": ["/archive/wayback", "/cyber/urlscan"],
        "username": ["/identity/username", "/social/public_profiles", "/dev/github/profile"],
        "profile": ["/social/public_profiles", "/identity/username"],
        "ip": ["/cyber/threatintel", "/infra/asn", "/cyber/reverse_dns"],
    }
    return mapping.get(entity_type, ["/search/broad", "/source/independent_confirmation"])


def _next_action_for_entity(entity_type: str, value: str, finding: dict[str, Any]) -> str:
    del finding
    entity_type = entity_type.lower()
    if entity_type == "company":
        return "Run /business/registry, /business/news and /business/social_profiles."
    if entity_type == "domain":
        return f"Run /infra/dns and /infra/certificates for {value}."
    if entity_type == "url":
        return f"Run /archive/wayback and /cyber/urlscan for {value}."
    if entity_type in {"username", "profile"}:
        return "Run /identity/username and /social/public_profiles."
    if entity_type == "ip":
        return "Run /cyber/threatintel, /infra/asn and /cyber/reverse_dns."
    return "Corroborate with an independent configured source."


def build_recommended_next_actions(
    case: dict[str, Any],
    entities: list[dict[str, Any]],
    findings: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    metadata = build_case_metadata(case)
    entity_type = metadata["entity_type"].lower()
    target = metadata["target"]
    entity_types = {entity_type}
    analysis_rows = _analysis_findings(findings)
    entity_types.update(
        _entity_key(row)[0].lower()
        for row in entities
        if not _is_noise_entity(_entity_key(row)[0], _entity_key(row)[1])
    )
    entity_types.update(_entity_key(row)[0].lower() for row in analysis_rows)
    actions: list[dict[str, Any]] = []

    def add(scope: str, action: str, reason: str) -> None:
        actions.append({"scope": scope, "action": action, "reason": reason})

    if "company" in entity_types or entity_type == "company":
        add("/business/registry", "Run /business/registry", "Confirm legal entity and registry match.")
        add("/business/news", "Run /business/news", "Find public coverage and timeline context.")
        add("/business/social_profiles", "Run /business/social_profiles", "Confirm official public profiles.")
        domains = sorted(
            {
                _entity_key(row)[1]
                for row in analysis_rows
                if _entity_key(row)[0] == "domain" and not _is_noise_entity("domain", _entity_key(row)[1])
            }
        )
        if domains:
            add("/infra/domain", f"Run /infra/domain for {domains[0]}", "Confirm infrastructure for the strongest domain lead.")
    if "domain" in entity_types or entity_type == "domain":
        add("/infra/dns", "Run /infra/dns", "Confirm DNS records and related infrastructure.")
        add("/infra/certificates", "Run /infra/certificates", "Check certificate transparency relationships.")
        add("/archive/wayback", "Run /archive/wayback", "Review historical captures.")
        add("/cyber/urlscan", "Run /cyber/urlscan", "Review URL scanning observations.")
    if "username" in entity_types or entity_type == "username":
        add("/identity/username", "Run /identity/username", "Check username across public platforms.")
        add("/social/public_profiles", "Run /social/public_profiles", "Review public social profiles.")
        add("/dev/github/profile", "Run /dev/github/profile", "Check developer profile signals.")
        add("/creator/public", "Run creator scopes if relevant", "Check creator platforms only when in scope.")
    if "ip" in entity_types or entity_type == "ip":
        add("/cyber/threatintel", "Run /cyber/threatintel", "Check public reputation and threat intel.")
        add("/infra/asn", "Run /infra/asn", "Confirm ASN and network ownership.")
        add("/cyber/reverse_dns", "Run /cyber/reverse_dns", "Look for reverse DNS context.")
    if not actions:
        add("/search/broad", f"Run broader configured search for {target}", "Add independent confirmation.")
    seen: set[tuple[str, str]] = set()
    unique = []
    for row in actions:
        key = (row["scope"], row["action"])
        if key not in seen:
            seen.add(key)
            unique.append(row)
    return unique


def build_raw_appendix(
    case: dict[str, Any],
    findings: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
    entities: list[dict[str, Any]],
    relations: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "primary": False,
        "collapsed_in_ui": True,
        "case": case.get("meta") or case,
        "risk_summary": case.get("risk_summary") or {},
        "source_coverage": case.get("source_coverage") or {},
        "source_health_history": case.get("source_health_history") or {},
        "raw_findings": findings,
        "raw_evidence": evidence,
        "raw_entities": entities,
        "raw_relations": relations,
        "raw_sources": list(case.get("sources") or []),
        "raw_attachments": list(case.get("attachments") or []),
        "raw_timeline": list(case.get("timeline") or []),
    }


def build_report_view_model(case_id: str | dict[str, Any]) -> dict[str, Any]:
    if isinstance(case_id, dict):
        case = case_id
    else:
        from ..core.case_summary import build_case_summary

        case = build_case_summary(str(case_id))

    metadata = build_case_metadata(case)
    if metadata["found"] is False:
        return {
            "schema_version": "1.0",
            "report_version": REPORT_VERSION,
            "metadata": metadata,
            "sections": {},
            "raw_appendix": {"primary": False, "collapsed_in_ui": True},
        }

    raw_findings = _all_findings(case)
    evidence = list(case.get("evidence") or [])
    sources = list(case.get("sources") or [])
    entities = list(case.get("entities") or [])
    relations = list(case.get("relations") or [])
    timeline = list(case.get("timeline") or [])
    prepared_findings = _prepare_findings(raw_findings, evidence)
    for index, row in enumerate(prepared_findings):
        prepared_findings[index] = {**row, "display": humanize_finding(row)}
    analysis_findings = _analysis_findings(prepared_findings)
    analysis_evidence = _analysis_evidence(evidence, prepared_findings)

    source_diagnostics = case.get("source_coverage") or {}
    entity_overview = build_entity_overview(entities, prepared_findings, evidence, relations)
    sections = {
        "cover": metadata,
        "executive_summary": build_executive_summary(case, prepared_findings, evidence, sources, relations),
        "key_findings": build_key_findings(prepared_findings, evidence, sources),
        "entity_overview": entity_overview,
        "entity_correlation": build_entity_correlation(
            case,
            entities,
            relations,
            prepared_findings,
            evidence,
        ),
        "result_clusters": build_result_clusters(prepared_findings),
        "evidence_summary": build_evidence_summary(evidence + list(case.get("attachments") or []), prepared_findings),
        "source_coverage": build_source_coverage(sources, prepared_findings, source_diagnostics),
        "confidence_breakdown": build_confidence_breakdown(prepared_findings, evidence, sources, relations),
        "graph_relationships": build_graph_summary(
            entities,
            relations,
            evidence,
            entity_overview.get("all_entities") or [],
        ),
        "timeline": build_timeline_summary(timeline, analysis_findings, analysis_evidence),
        "unconfirmed_hypotheses": build_unconfirmed_hypotheses(prepared_findings, entities, relations),
        "false_positive_risks": build_false_positive_risks(analysis_findings or prepared_findings),
        "recommended_next_actions": build_recommended_next_actions(case, entities, analysis_findings),
        "legal_privacy_notes": {
            "note": LEGAL_PRIVACY_NOTE,
            "raw_data_policy": "Raw data is retained in the appendix, not used as primary report content.",
        },
    }
    return {
        "schema_version": "1.0",
        "kind": "bedniiosint.technical_report",
        "report_version": REPORT_VERSION,
        "metadata": metadata,
        "sections": sections,
        "findings": prepared_findings,
        "raw_appendix": build_raw_appendix(case, prepared_findings, evidence, entities, relations),
        "exports": {
            "analyst_html_report": True,
            "technical_json_report": True,
            "evidence_bundle": True,
            "graph_export": True,
            "timeline_export": True,
            "markdown_report": True,
        },
    }
