from __future__ import annotations

from datetime import datetime, timezone
from html import escape
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from ..catalog.policy import policy_for_source
from .graph_html import build_graph_payload_from_section, render_relationship_graph
from .redaction import redact_report_summary
from .view_model import build_report_view_model


def _e(value) -> str:
    return escape("" if value is None else str(value))


def _cell_html(value: Any) -> str:
    text = "" if value is None else str(value)
    stripped = text.strip()
    parsed = urlparse(stripped)
    if parsed.scheme in {"http", "https"} and parsed.netloc:
        escaped = _e(stripped)
        return f'<a href="{escaped}" target="_blank" rel="noopener noreferrer">{escaped}</a>'
    if "@" in stripped and " " not in stripped and stripped.count("@") == 1:
        local, domain = stripped.rsplit("@", 1)
        if local and "." in domain:
            escaped = _e(stripped)
            return f'<a href="mailto:{escaped}">{escaped}</a>'
    return _e(text)


def _table(rows: list[dict], columns: list[tuple[str, str]]) -> str:
    if not rows:
        return '<div class="empty">None.</div>'
    head = "".join(f"<th>{_e(label)}</th>" for key, label in columns)
    body = []
    for row in rows:
        cells = "".join(f"<td>{_cell_html(row.get(key, ''))}</td>" for key, _label in columns)
        body.append(f"<tr>{cells}</tr>")
    return f'<div class="table-wrap"><table><tr>{head}</tr>{"".join(body)}</table></div>'


def _confidence_band(value: float) -> str:
    if value >= 0.75:
        return "high"
    if value >= 0.45:
        return "medium"
    return "weak"


def _source_policy(source_id: str, name: str = ""):
    return policy_for_source(source_id or name, name=name)


def _source_risk(source_id: str, name: str = "") -> str:
    policy = _source_policy(source_id, name)
    return policy.tos_privacy_risk if policy else "not confirmed"


def _corroboration(summary: dict) -> dict[tuple[str, str], set[str]]:
    seen: dict[tuple[str, str], set[str]] = {}
    for row in summary.get("findings", []):
        if row.get("rejected"):
            continue
        confidence = float(row.get("confidence") or 0.0)
        if confidence <= 0:
            continue
        key = (str(row.get("entity_type") or ""), str(row.get("entity_value") or ""))
        source = str(row.get("source_id") or row.get("source_name") or "")
        if key[0] and key[1] and source:
            seen.setdefault(key, set()).add(source)
    return seen


def _corroboration_rows(summary: dict) -> list[dict]:
    rows = []
    for (entity_type, entity_value), sources in sorted(
        _corroboration(summary).items(),
        key=lambda item: (-len(item[1]), item[0]),
    ):
        rows.append(
            {
                "entity_type": entity_type,
                "entity_value": entity_value,
                "independent_sources": len(sources),
                "sources": ", ".join(sorted(sources)),
                "review": "corroborated" if len(sources) >= 2 else "single-source",
            }
        )
    return rows


def _review_queue(summary: dict) -> list[dict]:
    rows = []
    for row in summary.get("findings", []):
        confidence = float(row.get("confidence") or 0.0)
        rejected = bool(row.get("rejected"))
        status = str(row.get("status") or "")
        reason = ""
        if rejected:
            reason = row.get("reject_reason") or "rejected finding"
        elif confidence < 0.75:
            reason = "confidence below high threshold"
        elif status in {"unknown", "not_exists", "missing_keys", "error"}:
            reason = f"status requires review: {status}"
        if not reason:
            continue
        rows.append(
            {
                "source": row.get("source_name") or row.get("source_id"),
                "entity": row.get("entity_value"),
                "status": status,
                "confidence": confidence,
                "reason": reason,
                "human_review": "required",
            }
        )
    return rows


def _finding_explanations(summary: dict) -> list[dict]:
    rows = []
    for row in summary.get("findings", []):
        markers = str(row.get("matched_markers") or "").strip()
        confidence = float(row.get("confidence") or 0.0)
        status = str(row.get("status") or "unknown")
        reason = str(row.get("confidence_reason") or "").strip()
        evidence_bits = []
        if markers:
            evidence_bits.append(f"matched markers: {markers}")
        if row.get("profile_url"):
            evidence_bits.append("profile URL observed")
        if row.get("final_url") and row.get("final_url") != row.get("profile_url"):
            evidence_bits.append("redirect/final URL preserved")
        if row.get("page_title"):
            evidence_bits.append(f"page title: {row.get('page_title')}")
        if not evidence_bits:
            evidence_bits.append("no explicit match markers recorded")

        if row.get("rejected"):
            review = row.get("reject_reason") or "do not treat as confirmed"
        elif status != "exists":
            review = f"manual review required: status is {status}"
        elif confidence < 0.75:
            review = "manual review required before treating as established"
        else:
            review = "review evidence and corroborate before external use"

        rows.append(
            {
                "source": row.get("source_name") or row.get("source_id"),
                "entity": row.get("entity_value"),
                "status": status,
                "confidence": confidence,
                "why_matched": "; ".join(evidence_bits),
                "confidence_reason": reason or "not recorded",
                "review_note": review,
            }
        )
    return rows


def _executive_summary(summary: dict, graph: dict) -> str:
    findings = summary.get("findings", [])
    sources = summary.get("sources", [])
    timeline = summary.get("timeline", [])
    evidence = summary.get("evidence", [])
    risk = summary.get("risk_summary") or {}
    bands = {"high": 0, "medium": 0, "weak": 0}
    for finding in findings:
        bands[_confidence_band(float(finding.get("confidence") or 0.0))] += 1
    top = findings[:5]
    top_items = "".join(
        "<li>"
        f"<b>{_e(row.get('source_name'))}</b>: {_e(row.get('entity_value'))} "
        f"({_e(row.get('status'))}, confidence {_e(row.get('confidence'))})"
        "</li>"
        for row in top
    )
    if not top_items:
        top_items = '<li class="empty">No visible findings.</li>'
    return f"""
  <div class="summary-grid">
    <div><b>{_e(risk.get("risk_score", 0))}</b><span>risk score ({_e(risk.get("risk_level", "low"))})</span></div>
    <div><b>{_e(risk.get("confidence_score", 0))}</b><span>confidence score</span></div>
    <div><b>{len(findings)}</b><span>visible findings</span></div>
    <div><b>{bands["high"]}</b><span>high confidence</span></div>
    <div><b>{len(sources)}</b><span>sources</span></div>
    <div><b>{len(evidence)}</b><span>evidence rows</span></div>
    <div><b>{len(timeline)}</b><span>timeline events</span></div>
    <div><b>{_e(graph.get("nodes", 0))}/{_e(graph.get("edges", 0))}</b><span>graph nodes/edges</span></div>
  </div>
  <h3>Strongest Signals</h3>
  <ul class="signal-list">{top_items}</ul>
"""


def _risk_summary(summary: dict) -> str:
    risk = summary.get("risk_summary") or {}
    bands = risk.get("confidence_band_counts") or {}
    drivers = risk.get("drivers") or []
    driver_rows = [{"driver": driver} for driver in drivers]
    metrics = [
        {"metric": "risk_score", "value": risk.get("risk_score", 0)},
        {"metric": "risk_level", "value": risk.get("risk_level", "low")},
        {"metric": "confidence_score", "value": risk.get("confidence_score", 0)},
        {"metric": "high_confidence", "value": bands.get("high", 0)},
        {"metric": "medium_confidence", "value": bands.get("medium", 0)},
        {"metric": "weak_confidence", "value": bands.get("weak", 0)},
        {"metric": "corroborated_entities", "value": risk.get("corroborated_entities", 0)},
        {"metric": "review_required", "value": risk.get("review_required", 0)},
        {"metric": "evidence_gap_penalty", "value": risk.get("evidence_gap_penalty", 0)},
    ]
    return (
        _table(metrics, [("metric", "Metric"), ("value", "Value")])
        + "<h3>Drivers</h3>"
        + _table(driver_rows, [("driver", "Driver")])
        + f'<p class="sub">{_e(risk.get("note", ""))}</p>'
    )


def _confidence_methodology() -> str:
    return """
  <div class="methodology">
    <p>Confidence combines source reliability, target-specific evidence, status signals, false-positive controls, markers, redirects and stale or weak-source penalties where available.</p>
    <p>High confidence is 0.75 and above, medium confidence is 0.45 to 0.74, and weak confidence is below 0.45. Independent corroborating sources should be preferred over reputation-only or stale observations.</p>
    <p>Evidence rows and attachments preserve SHA-256 hashes, capture timestamps, adapter versions, HTTP metadata and redacted query secrets for review.</p>
  </div>
"""


def _investigator_review(summary: dict) -> str:
    findings = summary.get("findings", [])
    high = [row for row in findings if float(row.get("confidence") or 0.0) >= 0.75]
    needs_review = [
        row for row in findings if float(row.get("confidence") or 0.0) < 0.75
    ]
    errors = [
        row
        for row in summary.get("sources", [])
        if int(row.get("error_count") or 0) > 0 or row.get("last_error")
    ]
    corroborated = sum(1 for sources in _corroboration(summary).values() if len(sources) >= 2)
    return f"""
  <div class="review-grid">
    <div><b>{len(high)}</b><span>Corroborated / high confidence</span></div>
    <div><b>{len(needs_review)}</b><span>Needs verification</span></div>
    <div><b>{len(errors)}</b><span>Sources with errors</span></div>
    <div><b>{corroborated}</b><span>Entities with 2+ sources</span></div>
  </div>
  <p class="sub">Findings below 0.75 confidence should be manually reviewed against the preserved evidence before being treated as established facts. Missing-key, error and not-found adapter results are kept in source/evidence context where available instead of being promoted as positive findings.</p>
"""


def _next_steps(summary: dict) -> str:
    steps = []
    review_rows = _review_queue(summary)
    single_source = sum(1 for sources in _corroboration(summary).values() if len(sources) == 1)
    errors = [
        row
        for row in summary.get("sources", [])
        if int(row.get("error_count") or 0) > 0 or row.get("last_error")
    ]
    if review_rows:
        steps.append(
            f"Review {len(review_rows)} not-confirmed or low-confidence findings against the evidence appendix."
        )
    if single_source:
        steps.append(
            f"Corroborate {single_source} single-source entities with an independent source before external use."
        )
    if errors:
        steps.append(
            f"Fix or re-run {len(errors)} sources with recorded errors, missing keys or stale health."
        )
    if summary.get("evidence"):
        steps.append("Preserve evidence hashes and captured URLs when sharing or rechecking findings.")
    if not steps:
        steps.append("No immediate blockers found; re-run selected sources when the investigation scope changes.")
    rows = [{"step": index + 1, "action": action} for index, action in enumerate(steps)]
    return _table(rows, [("step", "Step"), ("action", "Action")])


def _pivot_plan(summary: dict) -> str:
    pivot_plan = summary.get("pivot_plan") or {}
    steps = list(pivot_plan.get("steps") or [])
    rows = []
    for row in steps[:16]:
        rows.append(
            {
                "state": "ready" if row.get("ready") else "blocked",
                "from": f"{row.get('from_type')}:{row.get('from_value')}",
                "to": f"{row.get('to_type')}:{row.get('target')}",
                "sources": row.get("independent_sources", 0),
                "confidence": row.get("max_confidence", 0),
                "reason": row.get("reason", ""),
                "blocked_reason": row.get("blocked_reason", ""),
                "command": row.get("command", ""),
            }
        )
    summary_row = [
        {"metric": "safety_gate", "value": pivot_plan.get("safety_gate", "not recorded")},
        {"metric": "min_independent_sources", "value": pivot_plan.get("min_independent_sources", 0)},
        {"metric": "ready", "value": (pivot_plan.get("summary") or {}).get("ready", 0)},
        {"metric": "blocked", "value": (pivot_plan.get("summary") or {}).get("blocked", 0)},
    ]
    return (
        "<h3>Pivot Safety Summary</h3>"
        + _table(summary_row, [("metric", "Metric"), ("value", "Value")])
        + "<h3>Candidate Pivot Steps</h3>"
        + _table(
            rows,
            [
                ("state", "State"),
                ("from", "From"),
                ("to", "To"),
                ("sources", "Sources"),
                ("confidence", "Confidence"),
                ("reason", "Reason"),
                ("blocked_reason", "Blocked reason"),
                ("command", "Command"),
            ],
        )
    )


def _source_coverage(summary: dict) -> str:
    coverage = summary.get("source_coverage") or {}
    if coverage:
        totals = coverage.get("summary") or {}
        overview = _table(
            [
                {"metric": key, "value": value}
                for key, value in totals.items()
            ],
            [("metric", "Metric"), ("value", "Value")],
        )
        rows = _table(
            list(coverage.get("rows") or []),
            [
                ("source", "Source"),
                ("category", "Category"),
                ("status", "Status"),
                ("success_count", "Success"),
                ("error_count", "Errors"),
                ("success_rate", "Success rate"),
                ("health_status", "Health"),
                ("terms_risk", "Risk"),
                ("collection_mode", "Mode"),
                ("sensitivity", "Sensitivity"),
                ("policy_labels", "Policy labels"),
                ("last_error", "Last error"),
                ("notes", "Notes"),
            ],
        )
        missing = [
            {"source": source_id, "status": "not recorded"}
            for source_id in coverage.get("missing_expected") or []
        ]
        return (
            "<h3>Coverage Summary</h3>"
            + overview
            + "<h3>Recorded Sources</h3>"
            + rows
            + "<h3>Expected Pipeline Sources Not Recorded</h3>"
            + _table(missing, [("source", "Source"), ("status", "Status")])
        )

    sources = summary.get("sources", [])
    rows = []
    for source in sources:
        success = int(source.get("success_count") or 0)
        errors = int(source.get("error_count") or 0)
        total = success + errors
        rows.append(
            {
                "source": source.get("source_id") or source.get("name"),
                "category": source.get("category"),
                "success": success,
                "errors": errors,
                "success_rate": round(success / total, 3) if total else "",
                "health": source.get("health_status") or "unknown",
                "risk": _source_risk(source.get("source_id") or source.get("name"), source.get("name")),
                "mode": source.get("collection_mode") or "lookup",
                "sensitivity": source.get("sensitivity") or "standard",
                "labels": source.get("policy_labels") or "",
                "last_error": source.get("last_error") or "",
            }
        )
    return _table(
        rows,
        [
            ("source", "Source"),
            ("category", "Category"),
            ("success", "Success"),
            ("errors", "Errors"),
            ("success_rate", "Success rate"),
            ("health", "Health"),
            ("risk", "Risk"),
            ("mode", "Mode"),
            ("sensitivity", "Sensitivity"),
            ("labels", "Policy labels"),
            ("last_error", "Last error"),
        ],
    )


def _source_health_history(summary: dict) -> str:
    history = summary.get("source_health_history") or {}
    totals = history.get("summary") or {}
    latest = list(history.get("latest") or [])
    rows = list(history.get("rows") or [])[:50]
    return (
        "<h3>Health Summary</h3>"
        + _table(
            [{"metric": key, "value": value} for key, value in totals.items()],
            [("metric", "Metric"), ("value", "Value")],
        )
        + "<h3>Latest Source State</h3>"
        + _table(
            latest,
            [
                ("source_id", "Source"),
                ("health_state", "State"),
                ("health_status", "Health"),
                ("success_count", "Success"),
                ("error_count", "Errors"),
                ("success_rate", "Success rate"),
                ("observed_at", "Observed"),
                ("last_error", "Last error"),
            ],
        )
        + "<h3>Health History</h3>"
        + _table(
            rows,
            [
                ("observed_at", "Observed"),
                ("run_id", "Run"),
                ("source_id", "Source"),
                ("run_module", "Module"),
                ("health_state", "State"),
                ("success_count", "Success"),
                ("error_count", "Errors"),
                ("last_error", "Last error"),
            ],
        )
    )


def _legal_privacy_scope() -> str:
    return """
  <div class="methodology">
    <p>This report is designed for public, permissioned OSINT workflows. It should not be used as evidence of identity without human review, corroboration and a documented lawful basis.</p>
    <p>Source coverage labels passive-only lookups and sensitive-data contexts so internet-exposure, breach, phone and social-source findings are reviewed with the right caveats.</p>
    <p>Secrets in URLs, headers and query parameters are redacted in generated evidence manifests. Do not add stolen datasets, credential stuffing, authentication bypass, private tracking or ToS-violating collection to this case file.</p>
    <p>Retain only evidence needed for the investigation scope, and prefer official APIs, cached responses and source-specific rate limits when rechecking findings.</p>
  </div>
"""


def _graph_snapshot(summary: dict, graph: dict) -> str:
    relation_preview = summary.get("relations", [])[:20]
    metrics = [
        {"metric": "nodes", "value": graph.get("nodes", 0)},
        {"metric": "edges", "value": graph.get("edges", 0)},
    ]
    hubs = graph.get("hubs", [])
    return (
        _table(metrics, [("metric", "Metric"), ("value", "Value")])
        + "<h3>Hubs</h3>"
        + _table(hubs, [("node", "Node"), ("degree", "Degree")])
        + "<h3>Relation Preview</h3>"
        + _table(
            relation_preview,
            [
                ("src_type", "Source type"),
                ("src_value", "Source"),
                ("rel", "Relation"),
                ("dst_type", "Target type"),
                ("dst_value", "Target"),
            ],
        )
    )


def _report_badge(value: str, kind: str = "") -> str:
    return f'<span class="badge {kind}">{_e(value)}</span>'


def _report_rows(rows: list[dict], columns: list[tuple[str, str]]) -> str:
    if not rows:
        return '<div class="empty">None recorded.</div>'
    head = "".join(f"<th>{_e(label)}</th>" for _key, label in columns)
    body = []
    for row in rows:
        cells = "".join(f"<td>{_cell_html(row.get(key, ''))}</td>" for key, _label in columns)
        body.append(f"<tr>{cells}</tr>")
    return f'<div class="table-wrap"><table><tr>{head}</tr>{"".join(body)}</table></div>'


def _metric_grid(rows: list[tuple[str, Any]]) -> str:
    return (
        '<div class="summary-grid">'
        + "".join(
            f"<div><b>{_e(value)}</b><span>{_e(label)}</span></div>"
            for label, value in rows
        )
        + "</div>"
    )


def _list(items: list[Any], empty: str = "None recorded.") -> str:
    values = [_e(item) for item in items if _e(item)]
    if not values:
        return f'<div class="empty">{_e(empty)}</div>'
    return "<ul>" + "".join(f"<li>{value}</li>" for value in values) + "</ul>"


def _key_findings_html(rows: list[dict]) -> str:
    if not rows:
        return '<div class="empty">No key findings recorded.</div>'
    cards = []
    for row in rows:
        confidence = row.get("confidence") or {}
        explanation = row.get("plain_language_explanation") or ""
        cards.append(
            '<article class="finding-card">'
            f'<div class="finding-top">{_report_badge(row.get("verdict", "Needs review"), str(row.get("verdict", "")).lower())}'
            f'<span class="confidence">{_e(confidence.get("label"))}</span></div>'
            f'<h3>{_e(row.get("title"))}</h3>'
            f'<p>{_e(explanation)}</p>'
            f'<p><b>Why matched:</b> {_e(row.get("why_matched"))}</p>'
            f'<p><b>Confidence reason:</b> {_e(row.get("confidence_reason"))}</p>'
            f'<p><b>Source risk:</b> {_e(row.get("source_risk_label"))}</p>'
            '<div class="finding-meta">'
            f'<span>Evidence: {_e(row.get("evidence_count", 0))}</span>'
            f'<span>Sources: {_e(row.get("source_count", 0))}</span>'
            f'<span>Corroboration: {_e(row.get("independent_corroboration_count", row.get("source_count", 0)))}</span>'
            f'<span>Human review: {_e("required" if row.get("human_review_required") else "not required")}</span>'
            f'<span>Weakness: {_e(row.get("weakness"))}</span>'
            '</div>'
            f'<p class="next"><b>Next action:</b> {_e(row.get("next_action"))}</p>'
            "</article>"
        )
    return '<div class="finding-list">' + "".join(cards) + "</div>"


def _entity_overview_html(section: dict) -> str:
    groups = section.get("groups") or {}
    parts = []
    for group in groups.values():
        rows = []
        for entity in group.get("entities") or []:
            rows.append(
                {
                    "value": entity.get("value"),
                    "type": entity.get("type"),
                    "confidence": entity.get("confidence_label"),
                    "sources": entity.get("source_count"),
                    "evidence": entity.get("evidence_count"),
                    "first_seen": entity.get("first_seen"),
                    "last_seen": entity.get("last_seen"),
                    "related": ", ".join(entity.get("related_entities") or []),
                    "actions": "; ".join(entity.get("actions") or []),
                }
            )
        parts.append(
            f'<h3>{_e(group.get("title"))}</h3>'
            + _report_rows(
                rows,
                [
                    ("value", "Value"),
                    ("type", "Type"),
                    ("confidence", "Confidence"),
                    ("sources", "Sources"),
                    ("evidence", "Evidence"),
                    ("first_seen", "First seen"),
                    ("last_seen", "Last seen"),
                    ("related", "Related entities"),
                    ("actions", "Actions"),
                ],
            )
        )
    return "".join(parts)


def _entity_correlation_html(section: dict) -> str:
    summary = section.get("summary") or {}
    cluster_rows = []
    for row in section.get("clusters") or []:
        cluster_rows.append(
            {
                "entities": ", ".join(row.get("display_values") or []),
                "types": ", ".join(row.get("types") or []),
                "members": row.get("members", 0),
                "sources": row.get("independent_sources", 0),
                "evidence": row.get("evidence_count", 0),
                "confidence": row.get("max_confidence_label") or row.get("max_confidence"),
                "aliases": row.get("alias_link_count", 0),
                "review": row.get("review"),
                "reasons": "; ".join(row.get("review_reasons") or []),
            }
        )
    return (
        "<h3>Correlation Summary</h3>"
        + _metric_grid(
            [
                ("canonical entities", summary.get("canonical_entities", 0)),
                ("entity clusters", summary.get("entity_clusters", 0)),
                ("alias links", summary.get("alias_links", 0)),
                ("supported by findings", summary.get("supported_by_findings", 0)),
                ("needs review", summary.get("needs_review", 0)),
            ]
        )
        + "<h3>Entity Clusters</h3>"
        + _report_rows(
            cluster_rows,
            [
                ("entities", "Entities"),
                ("types", "Types"),
                ("members", "Members"),
                ("sources", "Sources"),
                ("evidence", "Evidence"),
                ("confidence", "Max confidence"),
                ("aliases", "Alias links"),
                ("review", "Review"),
                ("reasons", "Reasons"),
            ],
        )
        + "<h3>Alias Links</h3>"
        + _report_rows(
            list(section.get("alias_links") or []),
            [
                ("from", "From"),
                ("relation", "Relation"),
                ("into", "Into"),
                ("reason", "Reason"),
            ],
        )
        + "<h3>Human Review Queue</h3>"
        + _report_rows(
            list(section.get("review_queue") or []),
            [
                ("entities", "Entities"),
                ("types", "Types"),
                ("sources", "Sources"),
                ("evidence", "Evidence"),
                ("reasons", "Reasons"),
            ],
        )
    )


def _clusters_html(section: dict) -> str:
    clusters = section.get("clusters") or []
    cards = []
    for cluster in clusters:
        top = [
            f"{item.get('title')} - {item.get('entity_value')} ({(item.get('confidence') or {}).get('label')})"
            for item in cluster.get("top_items") or []
        ]
        cards.append(
            '<article class="cluster-card">'
            f'<h3>{_e(cluster.get("name"))} <span>{_e(cluster.get("count", 0))}</span></h3>'
            f'<p>{_e(cluster.get("meaning"))}</p>'
            f'<p><b>Why grouped here:</b> {_e(cluster.get("why_grouped_here"))}</p>'
            f'<p><b>Weakness:</b> {_e(cluster.get("weakness"))}</p>'
            f'{_list(top, "No items in this cluster.")}'
            f'<p class="next"><b>Next action:</b> {_e(cluster.get("recommended_next_action"))}</p>'
            "</article>"
        )
    return '<div class="cluster-grid">' + "".join(cards) + "</div>"


def _evidence_summary_html(section: dict) -> str:
    metrics = _metric_grid(
        [
            ("total evidence files", section.get("total_evidence_files", 0)),
            ("review-only artifacts", section.get("review_only_evidence_files", 0)),
            ("all evidence records", section.get("all_evidence_files", section.get("total_evidence_files", 0))),
            ("screenshots", section.get("screenshots", 0)),
            ("pages", section.get("pages", 0)),
            ("files", section.get("files", 0)),
            ("hash records", section.get("hash_records", 0)),
            ("integrity", section.get("evidence_integrity_status", "")),
        ]
    )
    chain = _report_rows(
        list(section.get("evidence_chain") or [])[:50],
        [
            ("type", "Type"),
            ("summary", "Summary"),
            ("sha256", "SHA-256"),
            ("artifact", "Artifact"),
            ("captured_at", "Captured"),
            ("integrity", "Integrity"),
        ],
    )
    return (
        metrics
        + "<h3>Missing evidence</h3>"
        + _list(section.get("missing_evidence") or [])
        + "<h3>Duplicate evidence</h3>"
        + _list(section.get("duplicate_evidence") or [])
        + "<h3>Evidence chain</h3>"
        + chain
    )


def _source_coverage_html(section: dict) -> str:
    summary = section.get("summary") or {}
    metrics = _metric_grid(
        [
            ("sources checked", summary.get("sources_checked", summary.get("recorded_sources", 0))),
            ("analyst sources", summary.get("analyst_sources_checked", summary.get("sources_checked", 0))),
            ("review-only templates", summary.get("review_only_source_templates", 0)),
            ("successful", summary.get("successful_sources", summary.get("checked", 0))),
            ("review-only successful", summary.get("review_only_successful_sources", 0)),
            ("failed", summary.get("failed_sources", summary.get("errors", 0))),
            ("timed out", summary.get("timed_out_sources", 0)),
            ("missing API keys", summary.get("missing_api_keys", 0)),
            ("disabled", summary.get("disabled_sources", summary.get("skipped", 0))),
        ]
    )
    rows = _report_rows(
        list(section.get("rows") or []),
        [
            ("source", "Source"),
            ("name", "Name"),
            ("status", "Status"),
            ("source_category", "Category"),
            ("source_reliability", "Reliability"),
            ("duration", "Duration"),
            ("last_error", "Last error"),
            ("notes", "Notes"),
        ],
    )
    return "<h3>Coverage Summary</h3>" + metrics + rows


def _confidence_breakdown_html(section: dict) -> str:
    overall = section.get("overall_confidence") or {}
    return (
        "<h3>Risk And Confidence Summary</h3>"
        + _metric_grid(
            [
                ("overall confidence", overall.get("label", "No confidence / 0%")),
                ("independent confirmations", section.get("independent_confirmations", 0)),
                ("registry status", section.get("registry_confirmation_status", "")),
                ("cross-links", section.get("cross_links", 0)),
                ("conflicts", section.get("conflicts", 0)),
                ("rejected", section.get("rejected_count", 0)),
            ]
        )
        + "<h3>Confidence Methodology</h3>"
        + _confidence_methodology()
        + "<h3>Positive signals</h3>"
        + _list(section.get("positive_signals") or [])
        + "<h3>Negative signals</h3>"
        + _list(section.get("negative_signals") or [])
        + "<h3>Single-source warnings</h3>"
        + _list(section.get("single_source_warnings") or [])
    )


def _graph_relationships_html(section: dict) -> str:
    graph_nodes, graph_edges = build_graph_payload_from_section(section)
    graph_block = render_relationship_graph(
        graph_nodes,
        graph_edges,
        container_id="bednii-relationship-graph",
    )
    return (
        _metric_grid(
            [
                ("entities", section.get("entities", 0)),
                ("relationships", section.get("relationships", 0)),
                ("sparse graph", "yes" if section.get("sparse") else "no"),
            ]
        )
        + (
            f'<p class="empty">{_e(section.get("sparse_graph_explanation"))}</p>'
            if section.get("sparse_graph_explanation")
            else ""
        )
        + "<h3>Interactive Graph</h3>"
        + graph_block
        + _report_rows(
            list(section.get("edges") or []),
            [
                ("source", "Source"),
                ("label", "Relation"),
                ("target", "Target"),
                ("confidence", "Confidence"),
                ("evidence_count", "Evidence"),
                ("explanation", "Explanation"),
            ],
        )
    )


def _timeline_html_section(section: dict) -> str:
    metrics = _metric_grid(
        [
            ("visible events", section.get("count", 0)),
            ("review-only events hidden", section.get("review_only_events", 0)),
            ("noise/query events hidden", section.get("suppressed_noise_events", 0)),
        ]
    )
    if section.get("empty"):
        return metrics + f'<div class="empty">{_e(section.get("empty_explanation"))}</div>'
    return metrics + _report_rows(
        list(section.get("events") or []),
        [
            ("when", "When"),
            ("kind", "Kind"),
            ("entity", "Entity"),
            ("source", "Source"),
            ("confidence", "Confidence"),
            ("description", "Description"),
        ],
    )


def _hypotheses_html(rows: list[dict]) -> str:
    return _report_rows(
        rows,
        [
            ("hypothesis", "Hypothesis"),
            ("why_hypothesis", "Why this is unconfirmed"),
            ("needed_sources", "Sources needed"),
        ],
    )


def _risks_html(rows: list[dict]) -> str:
    table_rows = [
        {
            "risk": row.get("risk"),
            "count": row.get("count"),
            "examples": ", ".join(row.get("examples") or []),
            "meaning": row.get("meaning"),
        }
        for row in rows
    ]
    return _report_rows(
        table_rows,
        [
            ("risk", "Risk"),
            ("count", "Count"),
            ("examples", "Examples"),
            ("meaning", "Meaning"),
        ],
    )


def _actions_html(rows: list[dict]) -> str:
    return _report_rows(
        rows,
        [
            ("scope", "Scope"),
            ("action", "Action"),
            ("reason", "Reason"),
        ],
    )


def _raw_appendix_html(appendix: dict) -> str:
    return (
        '<details class="raw-appendix">'
        "<summary>Raw Appendix</summary>"
        f"<pre>{_e(__import__('json').dumps(appendix, indent=2, default=str, ensure_ascii=False))}</pre>"
        "</details>"
    )


def _compatibility_review_sections(view: dict) -> str:
    sections = view.get("sections") or {}
    confidence = sections.get("confidence_breakdown") or {}
    key_findings = sections.get("key_findings") or []
    review_rows = [
        {
            "entity": row.get("entity_value"),
            "verdict": row.get("verdict"),
            "confidence": (row.get("confidence") or {}).get("label"),
            "reason": row.get("weakness"),
            "human_review": "Needs verification"
            if row.get("verdict") in {"Weak", "Unconfirmed", "Rejected"}
            else "Review evidence before reporting",
        }
        for row in key_findings
        if row.get("verdict") in {"Weak", "Unconfirmed", "Rejected"}
    ]
    corroboration = [
        {
            "metric": "Independent confirmations",
            "value": confidence.get("independent_confirmations", 0),
        },
        {
            "metric": "Single-source warnings",
            "value": len(confidence.get("single_source_warnings") or []),
        },
    ]
    actions = sections.get("recommended_next_actions") or []
    why_rows = [
        {
            "entity": row.get("entity_value"),
            "why_matched": row.get("why_matched"),
            "confidence_reason": row.get("confidence_reason"),
            "review_note": row.get("weakness"),
        }
        for row in key_findings
    ]
    return (
        '<section><h2>Investigator Review</h2>'
        '<p class="empty">Needs verification rows should be reviewed against preserved evidence before external reporting.</p>'
        + _report_rows(
            review_rows,
            [
                ("entity", "Entity"),
                ("verdict", "Verdict"),
                ("confidence", "Confidence"),
                ("reason", "Reason"),
                ("human_review", "Human review"),
            ],
        )
        + "</section>"
        + '<section><h2>Next Steps</h2>'
        + _report_rows(
            actions,
            [
                ("scope", "Scope"),
                ("action", "Action"),
                ("reason", "Reason"),
            ],
        )
        + "</section>"
        + '<section><h2>Independent Corroboration</h2>'
        + _report_rows(corroboration, [("metric", "Metric"), ("value", "Value")])
        + "</section>"
        + '<section><h2>Not Confirmed / Review Queue</h2>'
        + _report_rows(
            review_rows,
            [
                ("entity", "Entity"),
                ("verdict", "Verdict"),
                ("confidence", "Confidence"),
                ("reason", "Reason"),
            ],
        )
        + "</section>"
        + '<section><h2>Why Matched / Review Notes</h2>'
        + _report_rows(
            why_rows,
            [
                ("entity", "Entity"),
                ("why_matched", "Why matched"),
                ("confidence_reason", "Confidence reason"),
                ("review_note", "Review note"),
            ],
        )
        + "</section>"
        + '<section><h2>Source Health History</h2><p class="empty">Detailed source health history is preserved in the raw appendix and technical JSON report.</p></section>'
    )


def write_case_html(summary: dict, out: Path) -> Path:
    summary = redact_report_summary(summary)
    view = build_report_view_model(summary)
    meta = view.get("metadata", {})
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    if not meta.get("found"):
        html = f"<html><body><h1>Case not found: {_e(meta.get('case'))}</h1></body></html>"
        out.write_text(html, encoding="utf-8")
        return out

    sections = view.get("sections") or {}
    executive = sections.get("executive_summary") or {}
    counts = executive.get("counts") or {}
    confidence = executive.get("overall_confidence") or {}
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>BEDNIIOSINT Analyst Report - {_e(meta.get("case_name"))}</title>
<style>
  :root{{--bg:#0d1117;--panel:#161b22;--panel2:#0f1622;--border:#30363d;--txt:#e6edf3;--muted:#8b949e;--link:#58a6ff;--good:#3fb950;--warn:#d29922;--bad:#f85149;}}
  *{{box-sizing:border-box}}
  html,body{{max-width:100%;overflow-x:hidden}}
  body{{margin:0;background:var(--bg);color:var(--txt);font:14px/1.5 -apple-system,Segoe UI,Roboto,sans-serif}}
  header{{padding:30px 34px;border-bottom:1px solid var(--border);background:var(--panel)}}
  main{{padding:24px 34px;max-width:1320px;margin:0 auto;min-width:0}}
  h1{{margin:0;font-size:24px;letter-spacing:0;overflow-wrap:anywhere}} h2{{font-size:16px;margin:0 0 14px;border-left:3px solid var(--link);padding-left:10px;overflow-wrap:anywhere}}
  h3{{font-size:13px;margin:16px 0 8px;color:var(--muted);overflow-wrap:anywhere}} section{{margin:0 0 22px;padding:18px;border:1px solid var(--border);border-radius:8px;background:var(--panel2);min-width:0;overflow:hidden}}
  p,li,span,b,div,a{{overflow-wrap:anywhere;word-wrap:break-word;word-break:break-word}}
  .sub,.empty{{color:var(--muted)}} .badge{{display:inline-block;border:1px solid var(--border);border-radius:999px;padding:2px 8px;font-size:11px;font-weight:700;text-transform:uppercase;color:var(--muted)}}
  .confirmed{{color:var(--good);border-color:rgba(63,185,80,.45)}} .likely{{color:var(--link);border-color:rgba(88,166,255,.45)}} .weak,.unconfirmed{{color:var(--warn);border-color:rgba(210,153,34,.45)}} .rejected{{color:var(--bad);border-color:rgba(248,81,73,.45)}}
  .summary-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:12px 0 14px}}
  .summary-grid div{{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:12px;min-width:0}}
  .summary-grid b{{display:block;font-size:20px}} .summary-grid span{{color:var(--muted);font-size:11px;text-transform:uppercase}}
  .finding-list,.cluster-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}}
  .finding-card,.cluster-card{{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:14px;min-width:0;overflow:hidden}}
  .finding-top{{display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap}} .confidence{{color:var(--muted);font-size:12px}}
  .finding-meta{{display:flex;gap:8px;flex-wrap:wrap;color:var(--muted);font-size:12px}} .next{{color:var(--txt)}}
  .cluster-card h3{{display:flex;justify-content:space-between;gap:10px;color:var(--txt);flex-wrap:wrap}} .methodology p{{margin:8px 0;color:var(--txt)}}
  .table-wrap{{width:100%;max-width:100%;overflow-x:auto;border:1px solid var(--border);border-radius:8px;background:var(--panel)}}
  table{{width:100%;max-width:100%;min-width:0;table-layout:fixed;border-collapse:collapse;background:var(--panel)}}
  th,td{{padding:8px 10px;text-align:left;border-bottom:1px solid var(--border);font-size:12px;vertical-align:top;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-word;hyphens:auto;line-height:1.45}}
  th{{color:var(--muted);text-transform:uppercase;font-size:10px}} tr:last-child td{{border-bottom:none}}
  .raw-appendix summary{{cursor:pointer;font-weight:700}} pre{{max-height:520px;max-width:100%;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-word;background:#08101a;border:1px solid var(--border);border-radius:8px;padding:12px;color:#C9D7EA;font:12px/1.45 Consolas,monospace}}
  footer{{padding:20px 32px;color:var(--muted);font-size:12px;border-top:1px solid var(--border)}}
  @media (max-width:720px){{header,main,footer{{padding-left:16px;padding-right:16px}}.finding-list,.cluster-grid{{grid-template-columns:1fr}}}}
  @page{{margin:12mm}}
  @media print{{html,body{{overflow:visible}}body{{background:#fff;color:#111;font-size:11px}}main{{max-width:none;padding:0}}header,section,.table-wrap,table{{background:#fff;color:#111;border-color:#bbb}}section,.finding-card,.cluster-card,.table-wrap,table,tr,th,td{{overflow:visible;break-inside:auto;page-break-inside:auto}}.sub,.empty,th{{color:#555}}pre{{max-height:none;overflow:visible;white-space:pre-wrap}}}}
</style>
</head>
<body>
<header>
  <h1>BEDNIIOSINT Analyst Report</h1>
  <div class="sub">Case: <b>{_e(meta.get("case_name"))}</b> | Target: {_e(meta.get("target"))} | Type: {_e(meta.get("entity_type"))} | Runs: {_e(meta.get("runs_count"))} | Generated {generated}</div>
</header>
<main>
  <section><h2>A. Cover / Case Metadata</h2>
    {_report_rows([meta], [("case_title", "Case title"), ("target", "Target"), ("entity_type", "Entity type"), ("search_module", "Search module"), ("scope", "Scope"), ("created_at", "Created"), ("updated_at", "Updated"), ("runs_count", "Runs"), ("report_generated_at", "Report generated"), ("report_version", "Report version"), ("legal_privacy_note", "Legal/privacy note")])}
  </section>
  <section><h2>B. Executive Summary</h2>
    {_metric_grid([("overall confidence", confidence.get("label", "No confidence / 0%")), ("confirmed", counts.get("confirmed", 0)), ("likely", counts.get("likely", 0)), ("weak", counts.get("weak", 0)), ("unconfirmed", counts.get("unconfirmed", 0)), ("rejected", counts.get("rejected", 0))])}
    {_list(executive.get("plain_language") or [])}
    <p><b>Main false-positive risk:</b> {_e(executive.get("main_false_positive_risk"))}</p>
    <p><b>Main evidence problem:</b> {_e(executive.get("main_evidence_problem"))}</p>
    <p><b>Next recommended step:</b> {_e(executive.get("next_recommended_step"))}</p>
  </section>
  <section><h2>C. Key Findings</h2>{_key_findings_html(sections.get("key_findings") or [])}</section>
  <section><h2>D. Entity Overview</h2>{_entity_overview_html(sections.get("entity_overview") or {})}</section>
  <section><h2>D2. Entity Correlation</h2>{_entity_correlation_html(sections.get("entity_correlation") or {})}</section>
  <section><h2>E. Result Clusters</h2>{_clusters_html(sections.get("result_clusters") or {})}</section>
  <section><h2>F. Evidence Summary</h2>{_evidence_summary_html(sections.get("evidence_summary") or {})}</section>
  <section><h2>G. Source Coverage</h2>{_source_coverage_html(sections.get("source_coverage") or {})}</section>
  <section><h2>H. Confidence Breakdown</h2>{_confidence_breakdown_html(sections.get("confidence_breakdown") or {})}</section>
  <section><h2>I. Graph Relationships</h2><h3>Graph Snapshot</h3>{_graph_relationships_html(sections.get("graph_relationships") or {})}</section>
  <section><h2>J. Timeline</h2>{_timeline_html_section(sections.get("timeline") or {})}</section>
  <section><h2>K. Unconfirmed Hypotheses</h2>{_hypotheses_html(sections.get("unconfirmed_hypotheses") or [])}</section>
  <section><h2>L. False Positive Risks</h2>{_risks_html(sections.get("false_positive_risks") or [])}</section>
  <section><h2>M. Recommended Next Actions</h2>{_actions_html(sections.get("recommended_next_actions") or [])}</section>
  <section><h2>Pivot Plan</h2>{_pivot_plan(summary)}</section>
  <section><h2>Legal and Privacy Scope</h2>{_legal_privacy_scope()}</section>
  {_compatibility_review_sections(view)}
  <section><h2>N. Raw Appendix</h2><h3>Evidence Appendix</h3>{_raw_appendix_html(view.get("raw_appendix") or {})}</section>
</main>
<footer>BEDNIIOSINT v0.6 | Analyst HTML Report | Evidence hashes are SHA-256.</footer>
</body>
</html>"""
    out.write_text(html, encoding="utf-8")
    return out
