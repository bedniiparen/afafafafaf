from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .redaction import redact_report_summary
from .view_model import build_report_view_model


def _text(value: Any) -> str:
    return " ".join(str(value or "").replace("\r", " ").replace("\n", " ").split())


def _line(value: Any) -> str:
    text = _text(value)
    return text if text else "not recorded"


def _opt(label: str, value: Any) -> str | None:
    text = _text(value)
    if not text or text.lower() in {"0", "none", "not recorded"}:
        return None
    return f"- {label}: {text}"


def _labels(row: dict[str, Any]) -> str:
    text = _text(row.get("policy_labels"))
    return text if text else "none"


def _is_review_only_source_id(value: Any) -> bool:
    return _text(value).lower().startswith("dorking:")


def _group_review_only_latest(rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
    visible = []
    review_only = []
    for row in rows:
        if _is_review_only_source_id(row.get("source_id")):
            review_only.append(row)
        else:
            visible.append(row)
    if review_only:
        visible.append(
            {
                "source_id": "dorking:review_queue",
                "health_state": "grouped",
                "success_count": sum(int(row.get("success_count") or 0) for row in review_only),
                "error_count": sum(int(row.get("error_count") or 0) for row in review_only),
                "observed_at": _line(review_only[0].get("observed_at")),
            }
        )
    return visible, len(review_only)


def _confidence_band(value: float) -> str:
    if value >= 0.75:
        return "high"
    if value >= 0.45:
        return "medium"
    return "weak"


def _corroboration(summary: dict[str, Any]) -> dict[tuple[str, str], set[str]]:
    seen: dict[tuple[str, str], set[str]] = {}
    for row in summary.get("findings", []):
        if row.get("rejected"):
            continue
        confidence = float(row.get("confidence") or 0.0)
        if confidence <= 0:
            continue
        key = (_text(row.get("entity_type")), _text(row.get("entity_value")))
        source = _text(row.get("source_id") or row.get("source_name"))
        if key[0] and key[1] and source:
            seen.setdefault(key, set()).add(source)
    return seen


def _review_reason(row: dict[str, Any]) -> str:
    confidence = float(row.get("confidence") or 0.0)
    status = _text(row.get("status")) or "unknown"
    if row.get("rejected"):
        return _line(row.get("reject_reason") or "rejected finding")
    if confidence < 0.75:
        return "confidence below high threshold"
    if status in {"unknown", "not_exists", "missing_keys", "error"}:
        return f"status requires review: {status}"
    return ""


def _why_matched(row: dict[str, Any]) -> str:
    bits = []
    markers = _text(row.get("matched_markers"))
    if markers:
        bits.append(f"matched markers: {markers}")
    if row.get("profile_url"):
        bits.append("profile URL observed")
    if row.get("final_url") and row.get("final_url") != row.get("profile_url"):
        bits.append("redirect/final URL preserved")
    if row.get("page_title"):
        bits.append(f"page title: {_text(row.get('page_title'))}")
    return "; ".join(bits) if bits else "no explicit match markers recorded"


def _next_steps(summary: dict[str, Any]) -> list[str]:
    review_count = sum(1 for row in summary.get("findings", []) if _review_reason(row))
    single_source = sum(1 for sources in _corroboration(summary).values() if len(sources) == 1)
    error_count = sum(
        1
        for row in summary.get("sources", [])
        if int(row.get("error_count") or 0) > 0 or row.get("last_error")
    )
    steps = []
    if review_count:
        steps.append(f"Review {review_count} not-confirmed or low-confidence findings.")
    if single_source:
        steps.append(f"Corroborate {single_source} single-source entities independently.")
    if error_count:
        steps.append(f"Fix or re-run {error_count} sources with recorded errors.")
    if summary.get("evidence"):
        steps.append("Preserve evidence hashes and captured URLs when sharing findings.")
    return steps or ["No immediate blockers found; re-run selected sources when scope changes."]


def _pivot_plan_lines(summary: dict[str, Any]) -> list[str]:
    pivot_plan = summary.get("pivot_plan") or {}
    steps = list(pivot_plan.get("steps") or [])
    if not steps:
        return ["- No pivot steps available."]
    lines = [
        f"- Safety gate: {_line(pivot_plan.get('safety_gate'))}",
        f"- Minimum independent sources: {pivot_plan.get('min_independent_sources', 0)}",
    ]
    for row in steps[:12]:
        state = "ready" if row.get("ready") else "blocked"
        blocked = _line(row.get("blocked_reason")) if row.get("blocked_reason") else ""
        suffix = f"; blocked: {blocked}" if blocked else ""
        lines.append(
            "- "
            f"{state}: {_line(row.get('from_type'))}:{_line(row.get('from_value'))} -> "
            f"{_line(row.get('to_type'))}:{_line(row.get('target'))} "
            f"(sources {row.get('independent_sources', 0)}, confidence {row.get('max_confidence', 0)}{suffix})"
        )
        lines.append(f"  - Command: `{_line(row.get('command'))}`")
    return lines


def _reorder_report_sections(lines: list[str]) -> list[str]:
    prefix: list[str] = []
    sections: dict[str, list[str]] = {}
    order: list[str] = []
    current: str | None = None
    for line in lines:
        if line.startswith("## "):
            current = line
            if current not in sections:
                sections[current] = [line]
                order.append(current)
            else:
                sections[current].append("")
                sections[current].append(line)
            continue
        if current is None:
            prefix.append(line)
        else:
            sections[current].append(line)

    core_order = [
        "## Cover / Case Metadata",
        "## Executive Summary",
        "## Strongest Signals",
        "## Key Findings",
        "## Not Confirmed / Review Queue",
        "## Source Coverage",
        "## Evidence Summary",
        "## Recommended Next Actions",
        "## Next Steps",
        "## Legal / Privacy Scope",
    ]
    appendix_order = [
        "## Pivot Plan",
        "## Risk And Confidence Summary",
        "## Entity Overview",
        "## Entity Correlation",
        "## Result Clusters",
        "## Source Health History",
        "## Confidence Breakdown",
        "## Graph Relationships",
        "## Timeline",
        "## Unconfirmed Hypotheses",
        "## False Positive Risks",
    ]

    used: set[str] = set()
    reordered = list(prefix)
    for heading in core_order:
        if heading in sections:
            if reordered and reordered[-1] != "":
                reordered.append("")
            reordered.extend(sections[heading])
            used.add(heading)

    appendix_sections = [
        heading
        for heading in appendix_order + [heading for heading in order if heading not in core_order + appendix_order]
        if heading in sections and heading not in used
    ]
    if appendix_sections:
        if reordered and reordered[-1] != "":
            reordered.append("")
        reordered.append("## Appendix (details)")
        for heading in appendix_sections:
            reordered.append("")
            reordered.extend(sections[heading])
            used.add(heading)

    return reordered


def write_case_markdown(summary: dict[str, Any], out: Path) -> Path:
    summary = redact_report_summary(summary)
    view = build_report_view_model(summary)
    meta = view.get("metadata", {})
    if not meta.get("found"):
        out.write_text(f"# Case not found: {_line(meta.get('case_name'))}\n", encoding="utf-8")
        return out

    sections = view.get("sections") or {}
    executive = sections.get("executive_summary") or {}
    counts = executive.get("counts") or {}
    confidence = executive.get("overall_confidence") or {}
    key_findings = list(sections.get("key_findings") or [])
    source_coverage = sections.get("source_coverage") or {}
    evidence_summary = sections.get("evidence_summary") or {}
    confidence_breakdown = sections.get("confidence_breakdown") or {}
    graph = sections.get("graph_relationships") or {}
    timeline = sections.get("timeline") or {}
    entity_correlation = sections.get("entity_correlation") or {}
    legacy_risk = summary.get("risk_summary") or {}

    lines = [
        f"# BEDNIIOSINT Case Report: {_line(meta.get('case_name'))}",
        "",
        f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        "",
        "## Cover / Case Metadata",
        f"- Case title: {_line(meta.get('case_title'))}",
        f"- Target: {_line(meta.get('target'))}",
        f"- Entity type: {_line(meta.get('entity_type'))}",
        f"- Search module / scope: {_line(meta.get('search_module'))} / {_line(meta.get('scope'))}",
        f"- Runs count: {meta.get('runs_count', 0)}",
        f"- Report version: {_line(meta.get('report_version'))}",
        f"- Legal/privacy note: {_line(meta.get('legal_privacy_note'))}",
        "",
        "## Executive Summary",
        f"- What was checked: {_line(executive.get('what_was_checked'))}",
        f"- What was found: {_line(executive.get('what_was_found'))}",
        f"- Overall confidence: {_line(confidence.get('label'))}",
        f"- Findings: confirmed {counts.get('confirmed', 0)}, likely {counts.get('likely', 0)}, "
        f"weak {counts.get('weak', 0)}, unconfirmed {counts.get('unconfirmed', 0)}, "
        f"rejected {counts.get('rejected', 0)}",
        f"- Main false-positive risk: {_line(executive.get('main_false_positive_risk'))}",
        f"- Main evidence problem: {_line(executive.get('main_evidence_problem'))}",
        f"- Next recommended step: {_line(executive.get('next_recommended_step'))}",
        "",
        "## Recommended Next Actions",
    ]
    for row in sections.get("recommended_next_actions") or []:
        lines.append(f"- {row.get('action')} ({row.get('scope')}): {row.get('reason')}")
    lines.extend(["", "## Next Steps"])
    lines.extend(f"- {step}" for step in _next_steps(summary))

    lines.extend(["", "## Pivot Plan"])
    lines.extend(_pivot_plan_lines(summary))

    lines.extend(["", "## Risk And Confidence Summary"])
    lines.append(
        f"- Confidence score: {legacy_risk.get('confidence_score', (confidence_breakdown.get('overall_confidence') or {}).get('percent', 0))}"
    )
    lines.append(f"- Overall confidence: {_line((confidence_breakdown.get('overall_confidence') or {}).get('label'))}")
    for row in (
        _opt("Independent confirmations", confidence_breakdown.get("independent_confirmations")),
        _opt("Registry confirmation status", confidence_breakdown.get("registry_confirmation_status")),
        _opt("Cross-links", confidence_breakdown.get("cross_links")),
        _opt("Conflicts", confidence_breakdown.get("conflicts")),
        _opt("Duplicate penalties", confidence_breakdown.get("duplicate_penalties")),
        _opt("Rejected count", confidence_breakdown.get("rejected_count")),
    ):
        if row:
            lines.append(row)

    lines.extend(["", "## Strongest Signals"])
    if key_findings:
        for index, row in enumerate(key_findings[:10], start=1):
            conf = row.get("confidence") or {}
            corro = row.get("independent_corroboration_count", row.get("source_count", 0))
            review = "review" if row.get("human_review_required") else "ok"
            lines.append(
                f"{index}. {_line(row.get('entity_value'))} - {_line(row.get('verdict'))}, "
                f"{_line(conf.get('label'))}, corrob {corro}, {review}"
            )
            next_action = _text(row.get("next_action"))
            if next_action:
                lines.append(f"   next: {next_action}")
    else:
        lines.append("- No visible findings.")

    lines.extend(["", "## Key Findings"])
    for row in key_findings:
        conf = row.get("confidence") or {}
        lines.append(
            f"- {row.get('verdict')}: {row.get('title')} ({conf.get('label')}); "
            f"corroboration {row.get('independent_corroboration_count', row.get('source_count', 0))}; "
            f"Source risk: {_line(row.get('source_risk_label'))}; "
            f"Why matched: {_line(row.get('why_matched'))}; "
            f"review {'required' if row.get('human_review_required') else 'not required'}"
        )

    entity_rows = (sections.get("entity_overview") or {}).get("all_entities") or []
    lines.extend(["", "## Entity Overview"])
    if entity_rows:
        for row in entity_rows:
            lines.append(
                f"- {row.get('type')}:{row.get('value')} - {row.get('confidence_label')}, "
                f"{row.get('source_count')} source(s), {row.get('evidence_count')} evidence row(s)"
            )
    else:
        lines.append("- No entities recorded.")

    lines.extend(["", "## Entity Correlation"])
    correlation_summary = entity_correlation.get("summary") or {}
    lines.extend(
        [
            f"- Canonical entities: {correlation_summary.get('canonical_entities', 0)}",
            f"- Entity clusters: {correlation_summary.get('entity_clusters', 0)}",
            f"- Alias links: {correlation_summary.get('alias_links', 0)}",
            f"- Supported by findings: {correlation_summary.get('supported_by_findings', 0)}",
            f"- Needs review: {correlation_summary.get('needs_review', 0)}",
        ]
    )
    clusters = list(entity_correlation.get("clusters") or [])
    if clusters:
        lines.extend(["", "### Correlated Entity Clusters"])
        for row in clusters[:20]:
            entities = ", ".join(row.get("display_values") or []) or _line(row.get("id"))
            types = ", ".join(row.get("types") or [])
            reasons = "; ".join(row.get("review_reasons") or []) or "none"
            lines.append(
                f"- {entities} ({types}): {row.get('independent_sources', 0)} source(s), "
                f"{row.get('evidence_count', 0)} evidence row(s), "
                f"{_line(row.get('max_confidence_label'))}, "
                f"{_line(row.get('review'))}; reasons: {reasons}"
            )
    else:
        lines.append("- No entity correlation data recorded.")
    aliases = list(entity_correlation.get("alias_links") or [])
    if aliases:
        lines.extend(["", "### Alias Links"])
        for row in aliases[:20]:
            lines.append(
                f"- {_line(row.get('from'))} {_line(row.get('relation'))} "
                f"{_line(row.get('into'))}: {_line(row.get('reason'))}"
            )
    review_queue = list(entity_correlation.get("review_queue") or [])
    if review_queue:
        lines.extend(["", "### Entity Review Queue"])
        for row in review_queue[:20]:
            lines.append(
                f"- {_line(row.get('entities'))}: {_line(row.get('reasons'))}"
            )

    lines.extend(["", "## Result Clusters"])
    for cluster in (sections.get("result_clusters") or {}).get("clusters") or []:
        lines.append(f"- {cluster.get('name')}: {cluster.get('count')} - {cluster.get('meaning')}")

    lines.extend(["", "## Evidence Summary"])
    lines.extend(
        [
            f"- Total evidence files: {evidence_summary.get('total_evidence_files', 0)}",
            f"- Review-only lead artifacts: {evidence_summary.get('review_only_evidence_files', 0)}",
            f"- All preserved evidence records: {evidence_summary.get('all_evidence_files', evidence_summary.get('total_evidence_files', 0))}",
            f"- Screenshots/pages/files/hash records: {evidence_summary.get('screenshots', 0)} / {evidence_summary.get('pages', 0)} / {evidence_summary.get('files', 0)} / {evidence_summary.get('hash_records', 0)}",
            f"- Evidence integrity status: {_line(evidence_summary.get('evidence_integrity_status'))}",
            f"- Duplicate evidence: {len(evidence_summary.get('duplicate_evidence') or [])}",
        ]
    )

    lines.extend(["", "## Not Confirmed / Review Queue"])
    review_rows = [
        row
        for row in key_findings
        if row.get("verdict") in {"Weak", "Unconfirmed", "Rejected"}
    ]
    if review_rows:
        for row in review_rows:
            lines.append(
                f"- {_line(row.get('entity_value'))}: {_line(row.get('verdict'))} - {_line(row.get('weakness'))}"
            )
    else:
        lines.append("- None.")

    lines.extend(["", "## Source Coverage"])
    coverage = source_coverage
    if coverage:
        totals = coverage.get("summary") or {}
        lines.extend(
            [
                f"- Sources checked: {totals.get('sources_checked', totals.get('recorded_sources', 0))}",
                f"- Analyst sources checked: {totals.get('analyst_sources_checked', totals.get('sources_checked', 0))}",
                f"- Review-only source templates: {totals.get('review_only_source_templates', 0)}",
                f"- Successful sources: {totals.get('successful_sources', totals.get('checked', 0))}",
                f"- Review-only successful templates: {totals.get('review_only_successful_sources', 0)}",
                f"- Failed sources: {totals.get('failed_sources', totals.get('errors', 0))}",
                f"- Timed out sources: {totals.get('timed_out_sources', 0)}",
                f"- Missing keys: {totals.get('missing_api_keys', totals.get('missing_keys', 0))}",
                f"- Disabled sources: {totals.get('disabled_sources', totals.get('skipped', 0))}",
                "",
                "### Recorded Sources",
            ]
        )
        rows = list(coverage.get("rows") or [])
        if rows:
            for source in rows:
                lines.append(
                    f"- {_line(source.get('source') or source.get('name'))}: "
                    f"{_line(source.get('status'))}, "
                    f"{int(source.get('successful') or source.get('success_count') or 0)} success, "
                    f"{int(source.get('failed') or source.get('error_count') or 0)} errors, "
                    f"health {_line(source.get('health_status'))}, "
                    f"category {_line(source.get('source_category') or source.get('category'))}, "
                    f"mode {_line(source.get('collection_mode'))}, "
                    f"sensitivity {_line(source.get('sensitivity'))}, "
                    f"labels {_labels(source)}"
                )
        else:
            lines.append("- No source rows recorded.")
    else:
        lines.append("- No source rows recorded.")

    history = summary.get("source_health_history") or {}
    if history:
        totals = history.get("summary") or {}
        lines.extend(["", "## Source Health History"])
        for row in (
            _opt("History rows", totals.get("history_rows")),
            _opt("Sources", totals.get("sources")),
            _opt("Healthy", totals.get("healthy")),
            _opt("Missing keys", totals.get("missing_keys")),
            _opt("Errors", totals.get("errors")),
        ):
            if row:
                lines.append(row)
        latest = list(history.get("latest") or [])
        if latest:
            latest, grouped_review_only = _group_review_only_latest(latest)
            lines.extend(["", "### Latest Source State"])
            if grouped_review_only:
                lines.append(f"- Review-only source health rows grouped: {grouped_review_only}")
            for row in latest:
                lines.append(
                    f"- {_line(row.get('source_id'))}: "
                    f"{_line(row.get('health_state'))}, "
                    f"{int(row.get('success_count') or 0)} success, "
                    f"{int(row.get('error_count') or 0)} errors, "
                    f"observed {_line(row.get('observed_at'))}"
                )
        else:
            lines.append("- No source health rows recorded.")

    lines.extend(["", "## Confidence Breakdown"])
    lines.append("- Positive signals:")
    lines.extend(f"  - {item}" for item in confidence_breakdown.get("positive_signals") or [])
    lines.append("- Negative signals:")
    lines.extend(f"  - {item}" for item in confidence_breakdown.get("negative_signals") or [])

    lines.extend(["", "## Graph Relationships"])
    lines.extend(
        [
            f"- Entities: {graph.get('entities', 0)}",
            f"- Relationships: {graph.get('relationships', 0)}",
            f"- Sparse graph explanation: {_line(graph.get('sparse_graph_explanation'))}",
        ]
    )

    lines.extend(["", "## Timeline"])
    lines.append(f"- Review-only events moved out of primary timeline: {timeline.get('review_only_events', 0)}")
    lines.append(f"- Noise/query events hidden from primary timeline: {timeline.get('suppressed_noise_events', 0)}")
    if timeline.get("events"):
        for row in timeline.get("events") or []:
            lines.append(f"- {_line(row.get('when'))}: {_line(row.get('kind'))} - {_line(row.get('entity'))}")
    else:
        lines.append(f"- {_line(timeline.get('empty_explanation') or 'No timeline events recorded.')}")

    lines.extend(["", "## Unconfirmed Hypotheses"])
    hypotheses = sections.get("unconfirmed_hypotheses") or []
    if hypotheses:
        for row in hypotheses:
            lines.append(f"- {row.get('hypothesis')} Reason: {row.get('why_hypothesis')}")
    else:
        lines.append("- None.")

    lines.extend(["", "## False Positive Risks"])
    risks = sections.get("false_positive_risks") or []
    if risks:
        for row in risks:
            lines.append(f"- {row.get('risk')}: {row.get('count')} - {row.get('meaning')}")
    else:
        lines.append("- None.")

    lines.extend(
        [
            "",
            "## Legal / Privacy Scope",
            f"- {_line((sections.get('legal_privacy_notes') or {}).get('note'))}",
            "- Raw JSON / findings / evidence are kept in the technical JSON export, not in this report.",
            "",
        ]
    )
    lines = _reorder_report_sections(lines)
    out.write_text("\n".join(lines), encoding="utf-8")
    return out
