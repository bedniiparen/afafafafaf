from __future__ import annotations

from typing import Any

from ..core.redaction import redact_text, redact_url, redact_urls_in_text


REPORT_SECRET_KEYS = {
    "api_key",
    "apikey",
    "api-token",
    "api_token",
    "authorization",
    "bearer",
    "cookie",
    "hibp-api-key",
    "hibp_api_key",
    "password",
    "set-cookie",
    "set_cookie",
    "secret",
    "token",
    "x-apikey",
    "x_apikey",
    "x-api-key",
    "x_api_key",
}


def _normalized_key(value: str) -> str:
    return value.strip().lower()


def _is_report_secret_key(key: str) -> bool:
    normalized = _normalized_key(key)
    underscored = normalized.replace("-", "_")
    return (
        normalized in REPORT_SECRET_KEYS
        or underscored in REPORT_SECRET_KEYS
        or underscored.endswith("_api_key")
        or underscored.endswith("_token")
        or underscored.endswith("_secret")
        or underscored.endswith("_password")
    )


def _is_url_key(key: str) -> bool:
    normalized = _normalized_key(key)
    return normalized in {"url", "uri", "profile_url", "final_url"} or normalized.endswith("_url")


def redact_report_value(value: Any, *, key: str = "") -> Any:
    if key and _is_report_secret_key(key):
        if isinstance(value, str):
            return redact_text(value)
        if value:
            return "[redacted]"
        return value
    if isinstance(value, str):
        if key and _is_url_key(key):
            return redact_url(value)
        return redact_urls_in_text(value)
    if isinstance(value, dict):
        return {str(k): redact_report_value(v, key=str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [redact_report_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_report_value(item) for item in value)
    return value


def redact_report_summary(summary: dict[str, Any]) -> dict[str, Any]:
    redacted = redact_report_value(summary)
    return redacted if isinstance(redacted, dict) else {}
