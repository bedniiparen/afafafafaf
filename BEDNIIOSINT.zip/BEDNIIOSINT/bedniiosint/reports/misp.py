from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


MISP_ENTITY_TYPES = {
    "domain": ("domain", "Network activity"),
    "email": ("email-src", "Payload delivery"),
    "ip": ("ip-dst", "Network activity"),
    "url": ("url", "Network activity"),
    "profile": ("link", "External analysis"),
    "username": ("text", "Social network"),
    "wallet": ("text", "Financial fraud"),
}


def case_summary_to_misp_event(summary: dict[str, Any]) -> dict[str, Any]:
    meta = summary.get("meta", {})
    case_name = str(meta.get("case") or "case")
    attributes: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for entity in summary.get("entities", []):
        entity_type = str(entity.get("type") or "").lower()
        value = str(entity.get("value") or "").strip()
        if not value:
            continue
        misp_type, category = MISP_ENTITY_TYPES.get(entity_type, ("text", "External analysis"))
        key = (misp_type, category, value)
        if key in seen:
            continue
        seen.add(key)
        attributes.append(
            {
                "type": misp_type,
                "category": category,
                "value": value,
                "to_ids": False,
                "comment": f"BEDNIIOSINT entity type={entity_type}",
            }
        )

    for finding in summary.get("findings", []):
        url = str(finding.get("profile_url") or "").strip()
        if not url:
            continue
        key = ("link", "External analysis", url)
        if key in seen:
            continue
        seen.add(key)
        attributes.append(
            {
                "type": "link",
                "category": "External analysis",
                "value": url,
                "to_ids": False,
                "comment": (
                    f"BEDNIIOSINT finding source={finding.get('source_name') or ''} "
                    f"confidence={finding.get('confidence') or 0}"
                ),
            }
        )

    return {
        "Event": {
            "info": f"BEDNIIOSINT case {case_name}",
            "date": datetime.now(timezone.utc).date().isoformat(),
            "distribution": 0,
            "threat_level_id": "4",
            "analysis": "0",
            "published": False,
            "Attribute": attributes,
            "Tag": [
                {"name": "tlp:white"},
                {"name": "bedniiosint:source=\"local-case\""},
            ],
        }
    }


def write_misp_event(summary: dict[str, Any], out: Path) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(case_summary_to_misp_event(summary), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return out
