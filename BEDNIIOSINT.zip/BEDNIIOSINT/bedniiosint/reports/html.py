from __future__ import annotations

from datetime import datetime, timezone
from html import escape
from pathlib import Path
from urllib.parse import urlparse

TEMPLATES = Path(__file__).resolve().parent / "templates"


def _e(value) -> str:
    return escape("" if value is None else str(value))


def _link(value) -> str:
    # Scheme-safe link rendering: bare domains (e.g. 'adobe.com') get https://
    # prepended; anything without a valid http(s) host renders as plain text
    # instead of a broken relative <a href> link.
    text = "" if value is None else str(value).strip()
    if not text:
        return "-"
    candidate = text if "://" in text else "https://" + text
    parsed = urlparse(candidate)
    if parsed.scheme in ("http", "https") and parsed.netloc and " " not in parsed.netloc and "." in parsed.netloc:
        safe = _e(candidate)
        return f'<a href="{safe}" target="_blank" rel="noopener">{safe}</a>'
    return _e(text)


def _rows(rows: list[dict]) -> str:
    if not rows:
        return '<div class="empty">None.</div>'
    body = []
    for row in rows:
        cls = "hi" if row.get("confidence", 0) >= 0.75 else "med" if row.get("confidence", 0) >= 0.45 else "low"
        body.append(
            "<tr>"
            f"<td>{_e(row.get('site'))}</td>"
            f"<td><span class=\"pill\">{_e(row.get('category'))}</span></td>"
            f"<td>{_link(row.get('url'))}"
            f"<div class=\"hash\">{_e(row.get('title'))}</div></td>"
            f"<td>{_e(row.get('status_code') or '-')}</td>"
            f"<td class=\"conf {cls}\">{float(row.get('confidence', 0)):.2f}</td>"
            f"<td>{float(row.get('reliability', 0)):.2f}</td>"
            f"<td class=\"hash\">{_e(str(row.get('sha256', ''))[:24])}...</td>"
            "</tr>"
        )
    return (
        '<div class="table-wrap"><table><tr><th>Site</th><th>Category</th><th>Profile</th><th>Code</th>'
        "<th>Confidence</th><th>Reliability</th><th>Evidence SHA-256</th></tr>"
        + "".join(body)
        + "</table></div>"
    )


def _fallback_html(summary: dict, generated: str) -> str:
    meta = summary.get("meta", {})
    rejected = summary.get("rejected", [])
    rejected_rows = "".join(
        "<tr>"
        f"<td>{_e(row.get('site'))}</td>"
        f"<td>{_link(row.get('url'))}</td>"
        f"<td class=\"bad\">{_e(row.get('reject_reason'))}</td>"
        f"<td>{float(row.get('reliability', 0)):.2f}</td>"
        "</tr>"
        for row in rejected
    )
    sources = "".join(
        "<tr>"
        f"<td>{_e(src.get('name'))}</td>"
        f"<td><span class=\"pill\">{_e(src.get('category'))}</span></td>"
        f"<td>{float(src.get('reliability', 0)):.2f}</td>"
        f"<td class=\"hash\">{_e(src.get('note'))}</td>"
        "</tr>"
        for src in summary.get("sources", [])
    )
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>BEDNIIOSINT - {_e(meta.get("username"))}</title>
<style>
  :root{{--bg:#0d1117;--panel:#161b22;--border:#30363d;--txt:#e6edf3;--muted:#8b949e;--hi:#3fb950;--med:#d29922;--low:#58a6ff;--bad:#f85149;}}
  *{{box-sizing:border-box}} html,body{{max-width:100%;overflow-x:hidden}} body{{margin:0;background:var(--bg);color:var(--txt);font:14px/1.5 -apple-system,Segoe UI,Roboto,sans-serif}}
  header{{padding:28px 32px;border-bottom:1px solid var(--border);background:var(--panel)}} main{{padding:24px 32px;max-width:1200px;margin:0 auto;min-width:0}}
  h1{{margin:0;font-size:20px;letter-spacing:0;overflow-wrap:anywhere}} h2{{margin:28px 0 12px;font-size:15px;border-left:3px solid var(--low);padding-left:10px;overflow-wrap:anywhere}}
  p,li,span,b,div,a{{overflow-wrap:anywhere;word-wrap:break-word;word-break:break-word}}
  .sub,.empty{{color:var(--muted)}} .cards{{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:28px}}
  .card{{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:16px 20px;min-width:140px;max-width:100%;overflow:hidden}} .n{{font-size:26px;font-weight:700}} .l{{color:var(--muted);font-size:12px;text-transform:uppercase}}
  .table-wrap{{width:100%;max-width:100%;overflow-x:auto;border:1px solid var(--border);border-radius:8px;background:var(--panel)}}
  table{{width:100%;max-width:100%;min-width:0;table-layout:fixed;border-collapse:collapse;background:var(--panel)}} th,td{{padding:9px 12px;text-align:left;border-bottom:1px solid var(--border);font-size:13px;vertical-align:top;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-word;hyphens:auto;line-height:1.45}}
  th{{color:var(--muted);font-weight:600;text-transform:uppercase;font-size:11px}} tr:last-child td{{border-bottom:none}} a{{color:var(--low);text-decoration:none;overflow-wrap:anywhere;word-wrap:break-word}}
  .conf{{font-weight:700}} .hi{{color:var(--hi)}} .med{{color:var(--med)}} .low{{color:var(--low)}} .bad{{color:var(--bad)}} .pill{{display:inline-block;padding:1px 8px;border-radius:999px;font-size:11px;background:#21262d;color:var(--muted)}} .hash{{font-family:ui-monospace,monospace;color:var(--muted);font-size:11px;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-word}}
  footer{{padding:20px 32px;color:var(--muted);font-size:12px;border-top:1px solid var(--border)}} @media(max-width:720px){{header,main,footer{{padding-left:16px;padding-right:16px}}}}
  @page{{margin:12mm}} @media print{{html,body{{overflow:visible}}body{{background:#fff;color:#111;font-size:11px}}main{{max-width:none;padding:0}}header,.table-wrap,table{{background:#fff;color:#111;border-color:#bbb}}.table-wrap,table,tr,th,td{{overflow:visible;break-inside:auto;page-break-inside:auto}}}}
</style>
</head>
<body>
<header><h1>BEDNIIOSINT - Username Case Report</h1><div class="sub">Target: <b>{_e(meta.get("username"))}</b> | Case: {_e(meta.get("case"))} | Sites checked: {_e(meta.get("sites_checked"))} | Generated {generated}</div></header>
<main>
<div class="cards"><div class="card"><div class="n hi">{len(summary.get("high", []))}</div><div class="l">High confidence</div></div><div class="card"><div class="n med">{len(summary.get("medium", []))}</div><div class="l">Medium</div></div><div class="card"><div class="n low">{len(summary.get("weak", []))}</div><div class="l">Weak / unverified</div></div><div class="card"><div class="n bad">{len(rejected)}</div><div class="l">Rejected (FP)</div></div></div>
<h2>High-confidence findings</h2>{_rows(summary.get("high", []))}
<h2>Medium-confidence findings</h2>{_rows(summary.get("medium", []))}
<h2>Weak / unverified</h2>{_rows(summary.get("weak", []))}
<h2>Removed false positives</h2>{'<div class="table-wrap"><table><tr><th>Site</th><th>Profile</th><th>Reason</th><th>Reliability</th></tr>' + rejected_rows + '</table></div>' if rejected else '<div class="empty">None.</div>'}
<h2>Source reliability table</h2>{'<div class="table-wrap"><table><tr><th>Source</th><th>Category</th><th>Reliability</th><th>Calibration note</th></tr>' + sources + '</table></div>' if sources else '<div class="empty">None.</div>'}
</main><footer>BEDNIIOSINT v0.5 | Evidence hashed with SHA-256 at capture time.</footer>
</body></html>"""


def write_html(summary: dict, out: Path) -> Path:
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    try:
        from jinja2 import Environment, FileSystemLoader, select_autoescape

        env = Environment(
            loader=FileSystemLoader(str(TEMPLATES)),
            autoescape=select_autoescape(["html"]),
        )
        tpl = env.get_template("report.html")
        html = tpl.render(s=summary, generated=generated)
    except Exception:
        html = _fallback_html(summary, generated)
    out.write_text(html, encoding="utf-8")
    return out
