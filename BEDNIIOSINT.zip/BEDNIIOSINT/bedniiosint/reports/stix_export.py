from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any


_NAMESPACE = uuid.UUID("59ac471a-c959-49f2-b6f3-48b82ab78f93")


def _stix_id(kind: str, seed: str) -> str:
    return f"{kind}--{uuid.uuid5(_NAMESPACE, kind + ':' + seed)}"


def _created() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _fallback_bundle(case_id: str, findings: list[dict[str, Any]]) -> str:
    created = _created()
    identity_id = _stix_id("identity", f"bedniiosint:{case_id}")
    objects: list[dict[str, Any]] = [
        {
            "type": "identity",
            "spec_version": "2.1",
            "id": identity_id,
            "created": created,
            "modified": created,
            "name": f"BEDNIIOSINT case {case_id}",
            "identity_class": "system",
        }
    ]
    for index, finding in enumerate(findings):
        content = str(finding.get("snippet") or finding.get("title") or finding.get("url") or "")
        objects.append(
            {
                "type": "note",
                "spec_version": "2.1",
                "id": _stix_id("note", f"{case_id}:{index}:{content}"),
                "created": created,
                "modified": created,
                "abstract": str(finding.get("source_id") or "finding"),
                "content": content,
                "object_refs": [identity_id],
            }
        )
    return json.dumps(
        {
            "type": "bundle",
            "id": _stix_id("bundle", case_id),
            "spec_version": "2.1",
            "objects": objects,
        },
        indent=2,
        ensure_ascii=False,
    )


def findings_to_stix(case_id: str, findings: list[dict[str, Any]]) -> str:
    try:
        from stix2 import Bundle, Identity, Note  # type: ignore
    except Exception:
        return _fallback_bundle(case_id, findings)

    objects = []
    identity = Identity(name=f"BEDNIIOSINT case {case_id}", identity_class="system")
    objects.append(identity)
    for finding in findings:
        objects.append(
            Note(
                abstract=finding.get("source_id", "finding"),
                content=finding.get("snippet") or finding.get("title") or "",
                object_refs=[identity.id],
            )
        )
    return Bundle(objects=objects).serialize(pretty=True)
