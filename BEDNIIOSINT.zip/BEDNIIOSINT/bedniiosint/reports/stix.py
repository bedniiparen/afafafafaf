from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


_NAMESPACE = uuid.UUID("7b0f6688-3f70-47e4-8e31-cceec00c6f40")


def _stix_id(kind: str, seed: str) -> str:
    return f"{kind}--{uuid.uuid5(_NAMESPACE, kind + ':' + seed)}"


def _created() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _entity_object(entity: dict[str, Any]) -> dict[str, Any]:
    entity_type = str(entity.get("type") or "entity").lower()
    value = str(entity.get("value") or "")
    common = {"id": _stix_id(_stix_type(entity_type), value)}
    if entity_type == "email":
        return {"type": "email-addr", **common, "value": value}
    if entity_type == "domain":
        return {"type": "domain-name", **common, "value": value}
    if entity_type == "ip":
        stix_type = "ipv6-addr" if ":" in value else "ipv4-addr"
        return {"type": stix_type, "id": _stix_id(stix_type, value), "value": value}
    if entity_type in {"url", "profile"}:
        return {"type": "url", "id": _stix_id("url", value), "value": value}
    return {
        "type": "x-bedniiosint-entity",
        **common,
        "entity_type": entity_type,
        "value": value,
    }


def _stix_type(entity_type: str) -> str:
    if entity_type == "email":
        return "email-addr"
    if entity_type == "domain":
        return "domain-name"
    if entity_type == "ip":
        return "ip-addr"
    if entity_type in {"url", "profile"}:
        return "url"
    return "x-bedniiosint-entity"


def _relationship_type(value: str) -> str:
    clean = "".join(ch if ch.isalnum() or ch == "-" else "-" for ch in value.lower())
    return clean.strip("-") or "related-to"


def _artifact_object(row: dict[str, Any], *, case_name: str, role: str) -> dict[str, Any]:
    row_id = row.get("id") or row.get("path") or row.get("artifact_path") or row.get("sha256")
    seed = f"{case_name}:{role}:{row_id}"
    sha256 = str(row.get("sha256") or "")
    obj = {
        "type": "artifact",
        "spec_version": "2.1",
        "id": _stix_id("artifact", seed),
        "x_bedniiosint_role": role,
    }
    if sha256:
        obj["hashes"] = {"SHA-256": sha256}
    mime = row.get("mime") or row.get("content_type")
    if mime:
        obj["mime_type"] = mime
    url = row.get("url") or row.get("final_url") or row.get("path") or row.get("artifact_path")
    if url:
        obj["url"] = str(url)
    for source_key, stix_key in (
        ("finding_id", "x_bedniiosint_finding_id"),
        ("source_module", "x_bedniiosint_source_module"),
        ("adapter_version", "x_bedniiosint_adapter_version"),
        ("source_adapter_version", "x_bedniiosint_adapter_version"),
        ("method", "x_bedniiosint_http_method"),
        ("http_status", "x_bedniiosint_http_status"),
        ("artifact_path", "x_bedniiosint_artifact_path"),
        ("path", "x_bedniiosint_artifact_path"),
    ):
        if row.get(source_key) not in {None, ""}:
            obj[stix_key] = row.get(source_key)
    return obj


def case_summary_to_stix(summary: dict[str, Any]) -> dict[str, Any]:
    meta = summary.get("meta", {})
    case_name = str(meta.get("case") or "case")
    created = _created()
    identity_id = _stix_id("identity", f"bedniiosint:{case_name}")
    objects: list[dict[str, Any]] = [
        {
            "type": "identity",
            "spec_version": "2.1",
            "id": identity_id,
            "created": created,
            "modified": created,
            "name": f"BEDNIIOSINT case {case_name}",
            "identity_class": "system",
        }
    ]

    entity_ids: dict[tuple[str, str], str] = {}
    for entity in summary.get("entities", []):
        obj = _entity_object(entity)
        obj.setdefault("spec_version", "2.1")
        entity_ids[(str(entity.get("type") or ""), str(entity.get("value") or ""))] = obj["id"]
        objects.append(obj)

    observed_ids: dict[str, str] = {}
    for finding in summary.get("findings", []):
        entity_key = (
            str(finding.get("entity_type") or ""),
            str(finding.get("entity_value") or ""),
        )
        object_ref = entity_ids.get(entity_key)
        first_seen = finding.get("first_seen") or finding.get("captured_at") or created
        last_seen = finding.get("last_seen") or first_seen
        observed_id = _stix_id("observed-data", f"{case_name}:{finding.get('id')}")
        observed_ids[str(finding.get("id") or "")] = observed_id
        observed = {
            "type": "observed-data",
            "spec_version": "2.1",
            "id": observed_id,
            "created": created,
            "modified": created,
            "first_observed": first_seen,
            "last_observed": last_seen,
            "number_observed": 1,
            "created_by_ref": identity_id,
            "confidence": int(float(finding.get("confidence") or 0.0) * 100),
            "x_bedniiosint_source": finding.get("source_name"),
            "x_bedniiosint_status": finding.get("status"),
            "x_bedniiosint_profile_url": finding.get("profile_url"),
        }
        if object_ref:
            observed["object_refs"] = [object_ref]
        objects.append(observed)

    for role, rows in (
        ("evidence", summary.get("evidence", [])),
        ("attachment", summary.get("attachments", [])),
    ):
        for row in rows:
            artifact = _artifact_object(row, case_name=case_name, role=role)
            artifact_id = artifact["id"]
            objects.append(artifact)
            finding_id = str(row.get("finding_id") or "")
            observed_id = observed_ids.get(finding_id)
            if not observed_id:
                continue
            rel_type = "evidenced-by"
            objects.append(
                {
                    "type": "relationship",
                    "spec_version": "2.1",
                    "id": _stix_id("relationship", f"{observed_id}:{rel_type}:{artifact_id}"),
                    "created": created,
                    "modified": created,
                    "relationship_type": rel_type,
                    "source_ref": observed_id,
                    "target_ref": artifact_id,
                    "created_by_ref": identity_id,
                }
            )

    for relation in summary.get("relations", []):
        src = entity_ids.get(
            (str(relation.get("src_type") or ""), str(relation.get("src_value") or ""))
        )
        dst = entity_ids.get(
            (str(relation.get("dst_type") or ""), str(relation.get("dst_value") or ""))
        )
        if not src or not dst:
            continue
        rel_type = _relationship_type(str(relation.get("rel") or "related-to"))
        objects.append(
            {
                "type": "relationship",
                "spec_version": "2.1",
                "id": _stix_id("relationship", f"{src}:{rel_type}:{dst}"),
                "created": created,
                "modified": created,
                "relationship_type": rel_type,
                "source_ref": src,
                "target_ref": dst,
                "created_by_ref": identity_id,
            }
        )

    return {
        "type": "bundle",
        "id": _stix_id("bundle", case_name),
        "spec_version": "2.1",
        "objects": objects,
    }


def case_summary_to_taxii_envelope(summary: dict[str, Any]) -> dict[str, Any]:
    meta = summary.get("meta", {})
    case_name = str(meta.get("case") or "case")
    bundle = case_summary_to_stix(summary)
    return {
        "type": "taxii-collection-envelope",
        "taxii_version": "2.1",
        "collection": {
            "id": str(uuid.uuid5(_NAMESPACE, f"taxii-collection:{case_name}")),
            "title": f"BEDNIIOSINT {case_name}",
            "description": "Local TAXII-compatible export envelope for a BEDNIIOSINT case.",
            "can_read": True,
            "can_write": False,
            "media_type": "application/taxii+json;version=2.1",
        },
        "objects": bundle["objects"],
    }


def stix_bundle_to_case_summary(bundle: dict[str, Any], *, case_name: str = "stix-import") -> dict[str, Any]:
    objects = bundle.get("objects", []) if isinstance(bundle, dict) else []
    entities: list[dict[str, Any]] = []
    relations: list[dict[str, Any]] = []
    findings: list[dict[str, Any]] = []
    id_to_entity: dict[str, dict[str, str]] = {}

    for obj in objects:
        if not isinstance(obj, dict):
            continue
        obj_type = obj.get("type")
        value = obj.get("value")
        entity_type = ""
        if obj_type == "email-addr":
            entity_type = "email"
        elif obj_type == "domain-name":
            entity_type = "domain"
        elif obj_type in {"ipv4-addr", "ipv6-addr"}:
            entity_type = "ip"
        elif obj_type == "url":
            entity_type = "url"
        elif obj_type == "x-bedniiosint-entity":
            entity_type = str(obj.get("entity_type") or "entity")
        if not entity_type or not value:
            continue
        entity = {"type": entity_type, "value": str(value)}
        if entity not in entities:
            entities.append(entity)
        if obj.get("id"):
            id_to_entity[str(obj["id"])] = entity

    for obj in objects:
        if not isinstance(obj, dict):
            continue
        if obj.get("type") == "relationship":
            src = id_to_entity.get(str(obj.get("source_ref") or ""))
            dst = id_to_entity.get(str(obj.get("target_ref") or ""))
            if not src or not dst:
                continue
            relations.append(
                {
                    "src_type": src["type"],
                    "src_value": src["value"],
                    "rel": obj.get("relationship_type") or "related-to",
                    "dst_type": dst["type"],
                    "dst_value": dst["value"],
                }
            )
        elif obj.get("type") == "observed-data":
            refs = obj.get("object_refs") or []
            ref_entity = id_to_entity.get(str(refs[0])) if refs else None
            if not ref_entity:
                continue
            findings.append(
                {
                    "source_name": obj.get("x_bedniiosint_source") or "stix-import",
                    "entity_type": ref_entity["type"],
                    "entity_value": ref_entity["value"],
                    "status": obj.get("x_bedniiosint_status") or "exists",
                    "confidence": round(float(obj.get("confidence") or 0) / 100, 3),
                    "profile_url": obj.get("x_bedniiosint_profile_url") or "",
                }
            )

    return {
        "meta": {"case": case_name, "found": True, "module": "stix_import"},
        "entities": entities,
        "relations": relations,
        "findings": findings,
        "sources": [],
        "evidence": [],
        "attachments": [],
        "timeline": [],
        "notes": [],
        "graph": {"nodes": len(entities), "edges": len(relations), "hubs": []},
    }


_SDO_TYPES_REQUIRING_TIMESTAMPS = {
    "identity",
    "relationship",
    "observed-data",
}

_SCO_TYPES = {
    "email-addr",
    "domain-name",
    "url",
    "ipv4-addr",
    "ipv6-addr",
    "artifact",
}


def validate_stix_bundle(bundle: dict[str, Any]) -> list[str]:
    """Validate a STIX 2.1 bundle for structural completeness."""
    errors: list[str] = []
    if not isinstance(bundle, dict):
        return ["bundle is not an object"]
    if bundle.get("type") != "bundle":
        errors.append("top-level type must be 'bundle'")
    if not str(bundle.get("id") or "").startswith("bundle--"):
        errors.append("bundle id must start with 'bundle--'")

    objects = bundle.get("objects")
    if not isinstance(objects, list) or not objects:
        errors.append("bundle has no objects")
        return errors

    ids: set[str] = set()
    for index, obj in enumerate(objects):
        if not isinstance(obj, dict):
            errors.append(f"object[{index}] is not an object")
            continue
        obj_type = str(obj.get("type") or "")
        obj_id = str(obj.get("id") or "")
        if not obj_type:
            errors.append(f"object[{index}] missing type")
        if "--" not in obj_id:
            errors.append(f"object[{index}] ({obj_type}) has invalid id: {obj_id!r}")
        else:
            if obj_id in ids:
                errors.append(f"duplicate object id: {obj_id}")
            ids.add(obj_id)
        if obj_type not in _SCO_TYPES and obj.get("spec_version") != "2.1":
            errors.append(f"{obj_type} {obj_id} missing spec_version 2.1")
        if obj_type in _SDO_TYPES_REQUIRING_TIMESTAMPS:
            for field_name in ("created", "modified"):
                if not obj.get(field_name):
                    errors.append(f"{obj_type} {obj_id} missing {field_name}")

    for obj in objects:
        if not isinstance(obj, dict):
            continue
        if obj.get("type") == "relationship":
            for ref_key in ("source_ref", "target_ref"):
                ref = str(obj.get(ref_key) or "")
                if not ref:
                    errors.append(f"relationship {obj.get('id')} missing {ref_key}")
                elif ref not in ids:
                    errors.append(
                        f"relationship {obj.get('id')} has dangling {ref_key}: {ref}"
                    )
        elif obj.get("type") == "observed-data":
            refs = obj.get("object_refs") or []
            if not refs:
                errors.append(f"observed-data {obj.get('id')} has no object_refs")
            for ref in refs:
                if str(ref) not in ids:
                    errors.append(
                        f"observed-data {obj.get('id')} references unknown object: {ref}"
                    )
    return errors


def write_stix(summary: dict[str, Any], out: Path, *, validate: bool = False) -> Path:
    bundle = case_summary_to_stix(summary)
    if validate:
        problems = validate_stix_bundle(bundle)
        if problems:
            raise ValueError("invalid STIX bundle: " + "; ".join(problems))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(bundle, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return out


def write_taxii_envelope(summary: dict[str, Any], out: Path) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(case_summary_to_taxii_envelope(summary), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return out
