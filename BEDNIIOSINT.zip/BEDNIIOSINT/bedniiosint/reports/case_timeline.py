from __future__ import annotations

"""In-memory investigation case timeline."""

from typing import Any


def _ts(value: Any) -> str:
    return str(value or "")


def build_timeline(payload: dict[str, Any]) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    seed = payload.get("seed") or {}
    if seed:
        events.append(
            {
                "ts": "",
                "order": 0,
                "kind": "seed",
                "label": str(seed.get("value") or ""),
                "detail": f"Seed entity ({seed.get('entity_type') or 'unknown'})",
            }
        )

    for result in payload.get("search_results") or []:
        data = result if isinstance(result, dict) else {}
        ts = _ts(data.get("first_seen") or data.get("found_at") or data.get("last_seen"))
        events.append(
            {
                "ts": ts,
                "order": 1,
                "kind": "result",
                "label": str(data.get("title") or data.get("source_name") or data.get("source_id") or ""),
                "detail": str(data.get("url") or ""),
                "source_id": str(data.get("source_id") or ""),
                "confidence": data.get("confidence_score"),
            }
        )

    for identity in payload.get("identities") or []:
        data = identity if isinstance(identity, dict) else {}
        events.append(
            {
                "ts": "",
                "order": 2,
                "kind": "identity",
                "label": str(data.get("label") or ""),
                "detail": f"status={data.get('status')} confidence={data.get('confidence')}",
            }
        )

    for link in payload.get("correlations") or []:
        data = link if isinstance(link, dict) else {}
        events.append(
            {
                "ts": "",
                "order": 3,
                "kind": "correlation",
                "label": str(data.get("kind") or ""),
                "detail": str(data.get("explanation") or ""),
                "confidence": data.get("confidence"),
            }
        )

    events.sort(key=lambda event: (event["ts"] == "", event["ts"], event["order"]))
    for index, event in enumerate(events, start=1):
        event["seq"] = index
    return events


def timeline_markdown(payload: dict[str, Any]) -> str:
    events = build_timeline(payload)
    lines = ["# Investigation timeline", ""]
    for event in events:
        stamp = event["ts"] or "-"
        label = event["label"] or event["kind"]
        detail = f" - {event['detail']}" if event.get("detail") else ""
        lines.append(f"{event['seq']}. **[{event['kind']}]** `{stamp}` {label}{detail}")
    return "\n".join(lines)
