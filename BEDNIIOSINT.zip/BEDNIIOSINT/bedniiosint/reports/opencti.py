from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .stix import case_summary_to_stix


def case_summary_to_opencti_envelope(summary: dict[str, Any]) -> dict[str, Any]:
    meta = summary.get("meta", {})
    case_name = str(meta.get("case") or "case")
    return {
        "type": "opencti-import-envelope",
        "schema_version": "1.0",
        "created_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "source": "BEDNIIOSINT",
        "case": case_name,
        "import_mode": "stix2-bundle",
        "connector_hints": {
            "create_indicator_from_observables": False,
            "mark_confidence_from_bedniiosint": True,
            "preserve_custom_properties": True,
        },
        "stix_bundle": case_summary_to_stix(summary),
    }


def write_opencti_envelope(summary: dict[str, Any], out: Path) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(case_summary_to_opencti_envelope(summary), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return out
