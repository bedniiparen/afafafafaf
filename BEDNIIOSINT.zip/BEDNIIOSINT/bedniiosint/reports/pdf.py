from __future__ import annotations

import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    from weasyprint import HTML as _WeasyHTML

    _HAS_WEASY = True
except Exception:
    _HAS_WEASY = False

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

    _HAS_REPORTLAB = True
except Exception:
    _HAS_REPORTLAB = False


def pdf_available() -> bool:
    return _HAS_WEASY or _HAS_REPORTLAB


def pdf_backend() -> str:
    if _HAS_WEASY:
        return "weasyprint"
    if _HAS_REPORTLAB:
        return "reportlab"
    return "none"


def pdf_unavailable_reason() -> str:
    if pdf_available():
        return ""
    return (
        "PDF export disabled: neither weasyprint nor reportlab is installed. "
        "Install one of them: pip install weasyprint  (or)  pip install reportlab"
    )


def _html_to_text(html: str) -> list[str]:
    text = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = re.sub(r"(?i)</(p|div|h[1-6]|li|tr)>", "\n", text)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    text = text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    text = text.replace("&quot;", '"').replace("&#39;", "'").replace("&nbsp;", " ")
    lines = [line.strip() for line in text.splitlines()]
    return [line for line in lines if line]


def _reportlab_from_html(html_path: Path, pdf_path: Path) -> Path | None:
    try:
        html = Path(html_path).read_text(encoding="utf-8", errors="replace")
        doc = SimpleDocTemplate(str(pdf_path), pagesize=A4)
        styles = getSampleStyleSheet()
        story = []
        for line in _html_to_text(html):
            safe = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            story.append(Paragraph(safe, styles["BodyText"]))
            story.append(Spacer(1, 4))
        if not story:
            story.append(Paragraph("(empty report)", styles["BodyText"]))
        doc.build(story)
        return pdf_path
    except Exception as exc:
        logger.warning("reportlab PDF fallback failed: %s", exc)
        return None


def html_to_pdf(html_path: Path, pdf_path: Path) -> Path | None:
    html_path = Path(html_path)
    pdf_path = Path(pdf_path)
    if _HAS_WEASY:
        try:
            _WeasyHTML(filename=str(html_path)).write_pdf(str(pdf_path))
            return pdf_path
        except Exception as exc:
            logger.warning("weasyprint failed, trying reportlab fallback: %s", exc)
    if _HAS_REPORTLAB:
        return _reportlab_from_html(html_path, pdf_path)
    logger.warning("%s", pdf_unavailable_reason())
    return None
