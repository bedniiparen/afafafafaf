from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote, urlparse

from ..core.http import request
from ..core.secret_store import secret_value
from .misp import case_summary_to_misp_event
from .opencti import case_summary_to_opencti_envelope


_OPENCTI_FIELD_PATCH_MUTATIONS = {
    "Attack-Pattern": "attackPatternFieldPatch",
    "Campaign": "campaignFieldPatch",
    "Case-Incident": "caseIncidentFieldPatch",
    "Case-Rfi": "caseRfiFieldPatch",
    "Case-Rft": "caseRftFieldPatch",
    "Course-Of-Action": "courseOfActionFieldPatch",
    "Grouping": "groupingFieldPatch",
    "Identity": "identityFieldPatch",
    "Incident": "incidentFieldPatch",
    "Indicator": "indicatorFieldPatch",
    "Infrastructure": "infrastructureFieldPatch",
    "Intrusion-Set": "intrusionSetFieldPatch",
    "Location": "locationFieldPatch",
    "Malware": "malwareFieldPatch",
    "Note": "noteFieldPatch",
    "Observed-Data": "observedDataFieldPatch",
    "Opinion": "opinionFieldPatch",
    "Report": "reportFieldPatch",
    "Threat-Actor": "threatActorFieldPatch",
    "Threat-Actor-Group": "threatActorGroupFieldPatch",
    "Threat-Actor-Individual": "threatActorIndividualFieldPatch",
    "Tool": "toolFieldPatch",
    "Vulnerability": "vulnerabilityFieldPatch",
}


@dataclass
class SyncResult:
    target: str
    url: str
    dry_run: bool
    status: str
    status_code: int | None = None
    error: str = ""
    payload_counts: dict[str, int] = field(default_factory=dict)
    remote_id: str = ""
    remote_uuid: str = ""
    lifecycle: list[dict[str, Any]] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "url": self.url,
            "dry_run": self.dry_run,
            "status": self.status,
            "status_code": self.status_code,
            "error": self.error,
            "payload_counts": self.payload_counts,
            "remote_id": self.remote_id,
            "remote_uuid": self.remote_uuid,
            "lifecycle": self.lifecycle,
        }


@dataclass
class PreflightResult:
    target: str
    url: str
    status: str
    status_code: int | None = None
    error: str = ""
    checks: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "url": self.url,
            "status": self.status,
            "status_code": self.status_code,
            "error": self.error,
            "checks": self.checks,
            "details": self.details,
        }


@dataclass
class LifecycleResult:
    target: str
    action: str
    url: str
    status: str
    status_code: int | None = None
    error: str = ""
    remote_id: str = ""
    remote_uuid: str = ""
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "action": self.action,
            "url": self.url,
            "status": self.status,
            "status_code": self.status_code,
            "error": self.error,
            "remote_id": self.remote_id,
            "remote_uuid": self.remote_uuid,
            "details": self.details,
        }


def sync_opencti(
    summary: dict[str, Any],
    *,
    url: str,
    token: str | None = None,
    token_name: str = "OPENCTI_TOKEN",
    dry_run: bool = True,
    read_back: bool = False,
    delete_after: bool = False,
    patch_fields: dict[str, Any] | None = None,
    patch_mutation: str = "",
    patch_mutation_map: dict[str, str] | None = None,
) -> SyncResult:
    payload = case_summary_to_opencti_envelope(summary)
    token_value = token or secret_value(token_name)
    counts = {"stix_objects": len(payload.get("stix_bundle", {}).get("objects", []))}
    if dry_run:
        return SyncResult("opencti", url, True, "dry_run", payload_counts=counts)
    if not token_value:
        return SyncResult("opencti", url, False, "missing_token", error=f"missing {token_name}", payload_counts=counts)
    result = _post_json(
        "opencti",
        url,
        payload,
        headers=_opencti_headers(token_value),
        counts=counts,
    )
    remote_ref = result.remote_id or result.remote_uuid
    if result.status != "ok" or not remote_ref:
        return result
    read_result: LifecycleResult | None = None
    needs_patch_inference = bool(patch_fields and not patch_mutation.strip())
    if read_back:
        read_result = read_opencti_stix_core_object(url=url, object_id=remote_ref, token=token_value)
        result.lifecycle.append(read_result.as_dict())
    elif needs_patch_inference:
        read_result = read_opencti_stix_core_object(url=url, object_id=remote_ref, token=token_value)
    if patch_fields:
        mutation = patch_mutation
        if needs_patch_inference:
            mutation_fields: set[str] | None = None
            inference = _opencti_inference_result(
                read_result,
                url=url,
                object_id=remote_ref,
                mutation_map=patch_mutation_map,
            )
            if inference.status != "ok" and read_result is not None and read_result.status == "ok":
                mutation_fields, introspection = _read_opencti_mutation_fields(url=url, token=token_value)
                result.lifecycle.append(introspection.as_dict())
                inference = _opencti_inference_result(
                    read_result,
                    url=url,
                    object_id=remote_ref,
                    available_mutations=mutation_fields,
                    mutation_map=patch_mutation_map,
                )
            result.lifecycle.append(inference.as_dict())
            mutation = str(inference.details.get("mutation") or "") if inference.status == "ok" else ""
            if not mutation:
                result.lifecycle.append(
                    LifecycleResult(
                        "opencti",
                        "field_patch",
                        _opencti_graphql_url(url),
                        "error",
                        error=(
                            "opencti edit mutation could not be inferred; "
                            "pass --opencti-patch-mutation or --opencti-patch-map for this object type"
                        ),
                        remote_id=str(remote_ref),
                    ).as_dict()
                )
                if delete_after:
                    result.lifecycle.append(
                        delete_opencti_stix_core_object(url=url, object_id=remote_ref, token=token_value).as_dict()
                    )
                return result
        result.lifecycle.append(
            patch_opencti_object_fields(
                url=url,
                object_id=remote_ref,
                fields=patch_fields,
                edit_mutation=mutation,
                token=token_value,
            ).as_dict()
        )
    if delete_after:
        result.lifecycle.append(
            delete_opencti_stix_core_object(url=url, object_id=remote_ref, token=token_value).as_dict()
        )
    return result


def sync_misp(
    summary: dict[str, Any],
    *,
    url: str,
    api_key: str | None = None,
    api_key_name: str = "MISP_API_KEY",
    dry_run: bool = True,
    read_back: bool = False,
    delete_after: bool = False,
) -> SyncResult:
    event = case_summary_to_misp_event(summary)
    key_value = api_key or secret_value(api_key_name)
    post_url = url.rstrip("/") + "/events/add"
    counts = {"attributes": len(event.get("Event", {}).get("Attribute", []))}
    if dry_run:
        return SyncResult("misp", post_url, True, "dry_run", payload_counts=counts)
    if not key_value:
        return SyncResult("misp", post_url, False, "missing_token", error=f"missing {api_key_name}", payload_counts=counts)
    result = _post_json(
        "misp",
        post_url,
        event,
        headers=_misp_headers(key_value),
        counts=counts,
    )
    remote_ref = result.remote_id or result.remote_uuid
    if result.status != "ok" or not remote_ref:
        return result
    if read_back:
        result.lifecycle.append(
            read_misp_event(url=url, event_id=remote_ref, api_key=key_value).as_dict()
        )
    if delete_after:
        result.lifecycle.append(
            delete_misp_event(url=url, event_id=remote_ref, api_key=key_value).as_dict()
        )
    return result


def _post_json(
    target: str,
    url: str,
    payload: dict[str, Any],
    *,
    headers: dict[str, str],
    counts: dict[str, int],
) -> SyncResult:
    try:
        response = request("POST", url, json=payload, headers=headers)
        status = "ok" if response.status_code < 400 else "error"
        details = _json_response(response)
        remote_id, remote_uuid = _remote_refs(target, details)
        return SyncResult(
            target,
            url,
            False,
            status,
            status_code=response.status_code,
            error="" if status == "ok" else f"HTTP {response.status_code}",
            payload_counts=counts,
            remote_id=remote_id,
            remote_uuid=remote_uuid,
        )
    except Exception as exc:
        return SyncResult(
            target,
            url,
            False,
            "error",
            error=str(exc),
            payload_counts=counts,
        )


def read_misp_event(
    *,
    url: str,
    event_id: str,
    api_key: str | None = None,
    api_key_name: str = "MISP_API_KEY",
) -> LifecycleResult:
    key_value = api_key or secret_value(api_key_name)
    endpoint = _misp_event_view_url(url, event_id)
    if not key_value:
        return LifecycleResult("misp", "read_back", endpoint, "missing_token", error=f"missing {api_key_name}")
    try:
        response = request("GET", endpoint, headers=_misp_headers(key_value))
        details = _json_response(response)
        remote_id, remote_uuid = _remote_refs("misp", details)
        status = "ok" if response.status_code < 400 else "error"
        attributes = 0
        event = _misp_event(details)
        if event:
            attributes = len(event.get("Attribute", []) or [])
        return LifecycleResult(
            "misp",
            "read_back",
            endpoint,
            status,
            status_code=response.status_code,
            error="" if status == "ok" else f"HTTP {response.status_code}",
            remote_id=remote_id,
            remote_uuid=remote_uuid,
            details={"attributes": attributes} if status == "ok" else {},
        )
    except Exception as exc:
        return LifecycleResult("misp", "read_back", endpoint, "error", error=str(exc))


def delete_misp_event(
    *,
    url: str,
    event_id: str,
    api_key: str | None = None,
    api_key_name: str = "MISP_API_KEY",
) -> LifecycleResult:
    key_value = api_key or secret_value(api_key_name)
    endpoint = _misp_event_delete_url(url, event_id)
    if not key_value:
        return LifecycleResult("misp", "delete", endpoint, "missing_token", error=f"missing {api_key_name}")
    try:
        response = request("DELETE", endpoint, headers=_misp_headers(key_value))
        status = "ok" if response.status_code < 400 else "error"
        return LifecycleResult(
            "misp",
            "delete",
            endpoint,
            status,
            status_code=response.status_code,
            error="" if status == "ok" else f"HTTP {response.status_code}",
            remote_id=str(event_id),
        )
    except Exception as exc:
        return LifecycleResult("misp", "delete", endpoint, "error", error=str(exc), remote_id=str(event_id))


def read_opencti_stix_core_object(
    *,
    url: str,
    object_id: str,
    token: str | None = None,
    token_name: str = "OPENCTI_TOKEN",
) -> LifecycleResult:
    endpoint = _opencti_graphql_url(url)
    token_value = token or secret_value(token_name)
    if not token_value:
        return LifecycleResult("opencti", "read_back", endpoint, "missing_token", error=f"missing {token_name}")
    try:
        response = request(
            "POST",
            endpoint,
            json={
                "query": (
                    "query BedniiosintReadStixCoreObject($id: String!) { "
                    "stixCoreObject(id: $id) { id standard_id entity_type created_at updated_at } "
                    "}"
                ),
                "variables": {"id": object_id},
            },
            headers=_opencti_headers(token_value),
        )
        details = _json_response(response)
        item = _opencti_stix_core_object(details)
        status = (
            "ok"
            if response.status_code < 400 and not _graphql_errors(details) and bool(item)
            else "error"
        )
        remote_id = str(item.get("id") or object_id) if item else str(object_id)
        standard_id = str(item.get("standard_id") or "") if item else ""
        return LifecycleResult(
            "opencti",
            "read_back",
            endpoint,
            status,
            status_code=response.status_code,
            error="" if status == "ok" else _preflight_error(response.status_code, details),
            remote_id=remote_id,
            details={
                "standard_id": standard_id,
                "entity_type": str(item.get("entity_type") or ""),
                "created_at": str(item.get("created_at") or ""),
                "updated_at": str(item.get("updated_at") or ""),
            }
            if item
            else {},
        )
    except Exception as exc:
        return LifecycleResult("opencti", "read_back", endpoint, "error", error=str(exc), remote_id=str(object_id))


def delete_opencti_stix_core_object(
    *,
    url: str,
    object_id: str,
    token: str | None = None,
    token_name: str = "OPENCTI_TOKEN",
) -> LifecycleResult:
    endpoint = _opencti_graphql_url(url)
    token_value = token or secret_value(token_name)
    if not token_value:
        return LifecycleResult("opencti", "delete", endpoint, "missing_token", error=f"missing {token_name}")
    try:
        response = request(
            "POST",
            endpoint,
            json={
                "query": (
                    "mutation BedniiosintDeleteStixCoreObject($id: ID!) { "
                    "stixCoreObjectEdit(id: $id) { delete } "
                    "}"
                ),
                "variables": {"id": object_id},
            },
            headers=_opencti_headers(token_value),
        )
        details = _json_response(response)
        deleted = bool(
            details.get("data", {})
            .get("stixCoreObjectEdit", {})
            .get("delete")
        )
        status = (
            "ok"
            if response.status_code < 400 and not _graphql_errors(details) and deleted
            else "error"
        )
        return LifecycleResult(
            "opencti",
            "delete",
            endpoint,
            status,
            status_code=response.status_code,
            error="" if status == "ok" else _preflight_error(response.status_code, details),
            remote_id=str(object_id),
            details={"deleted": deleted},
        )
    except Exception as exc:
        return LifecycleResult("opencti", "delete", endpoint, "error", error=str(exc), remote_id=str(object_id))


def patch_opencti_object_fields(
    *,
    url: str,
    object_id: str,
    fields: dict[str, Any],
    edit_mutation: str,
    token: str | None = None,
    token_name: str = "OPENCTI_TOKEN",
    operation: str = "replace",
) -> LifecycleResult:
    endpoint = _opencti_graphql_url(url)
    token_value = token or secret_value(token_name)
    if not token_value:
        return LifecycleResult("opencti", "field_patch", endpoint, "missing_token", error=f"missing {token_name}")
    try:
        mutation = _validated_opencti_patch_mutation(edit_mutation)
    except ValueError as exc:
        return LifecycleResult(
            "opencti",
            "field_patch",
            endpoint,
            "error",
            error=str(exc),
            remote_id=str(object_id),
        )
    if not mutation:
        return LifecycleResult(
            "opencti",
            "field_patch",
            endpoint,
            "error",
            error="opencti edit mutation is required, e.g. identityEdit or reportEdit",
            remote_id=str(object_id),
        )
    try:
        patch_input = _opencti_edit_input(fields, operation=operation)
    except ValueError as exc:
        return LifecycleResult(
            "opencti",
            "field_patch",
            endpoint,
            "error",
            error=str(exc),
            remote_id=str(object_id),
        )
    query = _opencti_field_patch_query(mutation)
    try:
        response = request(
            "POST",
            endpoint,
            json={
                "query": query,
                "variables": {"id": object_id, "input": patch_input},
            },
            headers=_opencti_headers(token_value),
        )
        details = _json_response(response)
        item = _opencti_field_patch_result(details, mutation)
        status = (
            "ok"
            if response.status_code < 400 and not _graphql_errors(details) and bool(item)
            else "error"
        )
        return LifecycleResult(
            "opencti",
            "field_patch",
            endpoint,
            status,
            status_code=response.status_code,
            error="" if status == "ok" else _preflight_error(response.status_code, details),
            remote_id=str(item.get("id") or object_id) if item else str(object_id),
            details={
                "mutation": mutation,
                "patched_keys": sorted(fields),
                "entity_type": str(item.get("entity_type") or ""),
                "standard_id": str(item.get("standard_id") or ""),
            }
            if item
            else {"mutation": mutation, "patched_keys": sorted(fields)},
        )
    except Exception as exc:
        return LifecycleResult("opencti", "field_patch", endpoint, "error", error=str(exc), remote_id=str(object_id))


def preflight_opencti(
    *,
    url: str,
    token: str | None = None,
    token_name: str = "OPENCTI_TOKEN",
) -> PreflightResult:
    endpoint = _opencti_graphql_url(url)
    token_value = token or secret_value(token_name)
    checks = ["url normalized", "token resolved"]
    if not token_value:
        return PreflightResult(
            "opencti",
            endpoint,
            "missing_token",
            error=f"missing {token_name}",
            checks=checks,
        )
    try:
        response = request(
            "POST",
            endpoint,
            json={"query": "query BedniiosintPreflight { about { version } }"},
            headers={
                **_opencti_headers(token_value),
            },
        )
        details = _json_response(response)
        version = (
            details.get("data", {})
            .get("about", {})
            .get("version", "")
            if isinstance(details, dict)
            else ""
        )
        checks.append("about version query executed")
        status = "ok" if response.status_code < 400 and not _graphql_errors(details) else "error"
        error = ""
        if status != "ok":
            error = _preflight_error(response.status_code, details)
        return PreflightResult(
            "opencti",
            endpoint,
            status,
            status_code=response.status_code,
            error=error,
            checks=checks,
            details={"version": version} if version else {},
        )
    except Exception as exc:
        return PreflightResult(
            "opencti",
            endpoint,
            "error",
            error=str(exc),
            checks=checks,
        )


def preflight_misp(
    *,
    url: str,
    api_key: str | None = None,
    api_key_name: str = "MISP_API_KEY",
) -> PreflightResult:
    endpoint = _misp_version_url(url)
    key_value = api_key or secret_value(api_key_name)
    checks = ["url normalized", "api key resolved"]
    if not key_value:
        return PreflightResult(
            "misp",
            endpoint,
            "missing_token",
            error=f"missing {api_key_name}",
            checks=checks,
        )
    try:
        response = request(
            "GET",
            endpoint,
            headers=_misp_headers(key_value),
        )
        details = _json_response(response)
        checks.append("version endpoint requested")
        status = "ok" if response.status_code < 400 else "error"
        version = ""
        if isinstance(details, dict):
            version = str(details.get("version") or details.get("Version") or "")
        return PreflightResult(
            "misp",
            endpoint,
            status,
            status_code=response.status_code,
            error="" if status == "ok" else _preflight_error(response.status_code, details),
            checks=checks,
            details={"version": version} if version else {},
        )
    except Exception as exc:
        return PreflightResult(
            "misp",
            endpoint,
            "error",
            error=str(exc),
            checks=checks,
        )


def _opencti_graphql_url(url: str) -> str:
    clean = url.strip().rstrip("/")
    parsed = urlparse(clean)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("OpenCTI URL must be absolute")
    if parsed.path.rstrip("/") == "/graphql" or parsed.path.endswith("/graphql"):
        return clean
    return f"{parsed.scheme}://{parsed.netloc}/graphql"


def _misp_version_url(url: str) -> str:
    clean = url.strip().rstrip("/")
    parsed = urlparse(clean)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("MISP URL must be absolute")
    if parsed.path.endswith("/servers/getVersion"):
        return clean
    return clean + "/servers/getVersion"


def _misp_event_view_url(url: str, event_id: str) -> str:
    clean = url.strip().rstrip("/")
    parsed = urlparse(clean)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("MISP URL must be absolute")
    return clean + f"/events/view/{quote(str(event_id), safe='')}"


def _misp_event_delete_url(url: str, event_id: str) -> str:
    clean = url.strip().rstrip("/")
    parsed = urlparse(clean)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("MISP URL must be absolute")
    return clean + f"/events/delete/{quote(str(event_id), safe='')}"


def _misp_headers(api_key: str) -> dict[str, str]:
    return {
        "Authorization": api_key,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def _opencti_headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def _json_response(response) -> dict[str, Any]:
    try:
        data = response.json()
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _graphql_errors(data: dict[str, Any]) -> bool:
    errors = data.get("errors") if isinstance(data, dict) else None
    return bool(errors)


def _preflight_error(status_code: int, details: dict[str, Any]) -> str:
    if _graphql_errors(details):
        return "GraphQL errors returned"
    return f"HTTP {status_code}"


def _remote_refs(target: str, details: dict[str, Any]) -> tuple[str, str]:
    if target == "misp":
        event = _misp_event(details)
        if event:
            return str(event.get("id") or ""), str(event.get("uuid") or "")
    candidates = [
        details,
        details.get("data", {}) if isinstance(details.get("data"), dict) else {},
        details.get("result", {}) if isinstance(details.get("result"), dict) else {},
    ]
    for row in candidates:
        if not isinstance(row, dict):
            continue
        remote_id = str(row.get("id") or row.get("standard_id") or "")
        remote_uuid = str(row.get("uuid") or "")
        if remote_id or remote_uuid:
            return remote_id, remote_uuid
    return "", ""


def _misp_event(details: dict[str, Any]) -> dict[str, Any]:
    event = details.get("Event") if isinstance(details, dict) else None
    if isinstance(event, dict):
        return event
    response = details.get("response") if isinstance(details, dict) else None
    if isinstance(response, dict) and isinstance(response.get("Event"), dict):
        return response["Event"]
    return {}


def _opencti_stix_core_object(details: dict[str, Any]) -> dict[str, Any]:
    data = details.get("data") if isinstance(details, dict) else None
    if not isinstance(data, dict):
        return {}
    item = data.get("stixCoreObject")
    return item if isinstance(item, dict) else {}


def _opencti_field_patch_result(details: dict[str, Any], edit_mutation: str) -> dict[str, Any]:
    data = details.get("data") if isinstance(details, dict) else None
    if not isinstance(data, dict):
        return {}
    edit = data.get(edit_mutation)
    if not isinstance(edit, dict):
        return {}
    if edit_mutation.endswith("FieldPatch"):
        return edit
    item = edit.get("fieldPatch")
    return item if isinstance(item, dict) else {}


def _opencti_inference_result(
    read_result: LifecycleResult | None,
    *,
    url: str,
    object_id: str,
    available_mutations: set[str] | None = None,
    mutation_map: dict[str, str] | None = None,
) -> LifecycleResult:
    endpoint = _opencti_graphql_url(url)
    if read_result is None:
        return LifecycleResult(
            "opencti",
            "infer_mutation",
            endpoint,
            "error",
            error="opencti object metadata was not read",
            remote_id=str(object_id),
    )
    entity_type = str(read_result.details.get("entity_type") or "")
    try:
        mutation = infer_opencti_field_patch_mutation(
            entity_type,
            available_mutations=available_mutations,
            mutation_map=mutation_map,
        )
    except ValueError as exc:
        return LifecycleResult(
            "opencti",
            "infer_mutation",
            endpoint,
            "error",
            error=str(exc),
            remote_id=str(object_id),
            details={"entity_type": entity_type},
        )
    if read_result.status != "ok":
        return LifecycleResult(
            "opencti",
            "infer_mutation",
            endpoint,
            "error",
            status_code=read_result.status_code,
            error=f"opencti object metadata read failed: {read_result.error or read_result.status}",
            remote_id=str(object_id),
            details={"entity_type": entity_type},
        )
    if not mutation:
        return LifecycleResult(
            "opencti",
            "infer_mutation",
            endpoint,
            "error",
            error=f"no known OpenCTI field patch mutation for entity_type {entity_type or '<empty>'}",
            remote_id=str(object_id),
            details={"entity_type": entity_type},
        )
    return LifecycleResult(
        "opencti",
        "infer_mutation",
        endpoint,
        "ok",
        status_code=read_result.status_code,
        remote_id=str(object_id),
        details={"entity_type": entity_type, "mutation": mutation},
    )


def infer_opencti_field_patch_mutation(
    entity_type: str,
    *,
    available_mutations: set[str] | None = None,
    mutation_map: dict[str, str] | None = None,
) -> str:
    mapped = _mapped_opencti_patch_mutation(entity_type, mutation_map or {})
    if mapped:
        return _validated_opencti_patch_mutation(mapped)
    candidates = _opencti_field_patch_candidates(entity_type)
    if available_mutations is not None:
        return next((name for name in candidates if name in available_mutations), "")
    return _OPENCTI_FIELD_PATCH_MUTATIONS.get(entity_type.strip(), "")


def _mapped_opencti_patch_mutation(entity_type: str, mutation_map: dict[str, str]) -> str:
    clean = entity_type.strip()
    lowered = clean.lower()
    for key, value in mutation_map.items():
        if key.strip() == clean or key.strip().lower() == lowered:
            return value.strip()
    return ""


def _read_opencti_mutation_fields(
    *,
    url: str,
    token: str,
) -> tuple[set[str], LifecycleResult]:
    endpoint = _opencti_graphql_url(url)
    try:
        response = request(
            "POST",
            endpoint,
            json={
                "query": (
                    "query BedniiosintOpenCtiMutationFields { "
                    "__schema { mutationType { fields { name } } } "
                    "}"
                )
            },
            headers=_opencti_headers(token),
        )
        details = _json_response(response)
        mutations = _opencti_mutation_names(details)
        status = "ok" if response.status_code < 400 and not _graphql_errors(details) and mutations else "error"
        field_patch_count = len([name for name in mutations if name.endswith("FieldPatch")])
        return mutations, LifecycleResult(
            "opencti",
            "schema_introspection",
            endpoint,
            status,
            status_code=response.status_code,
            error="" if status == "ok" else _preflight_error(response.status_code, details),
            details={
                "mutation_count": len(mutations),
                "field_patch_mutation_count": field_patch_count,
            },
        )
    except Exception as exc:
        return set(), LifecycleResult("opencti", "schema_introspection", endpoint, "error", error=str(exc))


def _opencti_mutation_names(details: dict[str, Any]) -> set[str]:
    data = details.get("data") if isinstance(details, dict) else None
    schema = data.get("__schema") if isinstance(data, dict) else None
    mutation_type = schema.get("mutationType") if isinstance(schema, dict) else None
    fields = mutation_type.get("fields") if isinstance(mutation_type, dict) else None
    if not isinstance(fields, list):
        return set()
    names = set()
    for field in fields:
        if isinstance(field, dict) and field.get("name"):
            names.add(str(field["name"]))
    return names


def _opencti_field_patch_candidates(entity_type: str) -> list[str]:
    clean = entity_type.strip()
    candidates: list[str] = []
    known = _OPENCTI_FIELD_PATCH_MUTATIONS.get(clean)
    if known:
        candidates.append(known)
    generated = _opencti_field_patch_candidate(clean)
    if generated:
        candidates.append(generated)
    deduped: list[str] = []
    for candidate in candidates:
        if candidate not in deduped:
            deduped.append(candidate)
    return deduped


def _opencti_field_patch_candidate(entity_type: str) -> str:
    parts: list[str] = []
    current = []
    for char in entity_type:
        if char.isalnum():
            current.append(char)
        elif current:
            parts.append("".join(current))
            current = []
    if current:
        parts.append("".join(current))
    if not parts:
        return ""
    first = parts[0][:1].lower() + parts[0][1:]
    rest = [part[:1].upper() + part[1:] for part in parts[1:]]
    return "".join([first, *rest]) + "FieldPatch"


def _validated_opencti_patch_mutation(value: str) -> str:
    clean = value.strip()
    if not clean:
        return ""
    if clean.startswith("__") or not clean.endswith(("Edit", "FieldPatch")):
        raise ValueError(
            "opencti patch mutation must be a concrete GraphQL mutation ending with Edit or FieldPatch"
        )
    if not re_fullmatch_identifier(clean):
        raise ValueError("opencti patch mutation must contain only letters, numbers and underscores")
    return clean


def _validated_opencti_edit_mutation(value: str) -> str:
    return _validated_opencti_patch_mutation(value)


def re_fullmatch_identifier(value: str) -> bool:
    if not value or not (value[0].isalpha() or value[0] == "_"):
        return False
    return all(ch.isalnum() or ch == "_" for ch in value)


def _opencti_edit_input(fields: dict[str, Any], *, operation: str) -> list[dict[str, Any]]:
    op = operation.strip().lower()
    if op not in {"add", "replace", "remove"}:
        raise ValueError("opencti patch operation must be add, replace or remove")
    rows: list[dict[str, Any]] = []
    for key, value in sorted(fields.items()):
        clean_key = str(key).strip()
        if not clean_key:
            raise ValueError("opencti patch field names must not be empty")
        if isinstance(value, (list, tuple)):
            values = [str(item) for item in value]
        else:
            values = [str(value)]
        rows.append({"key": clean_key, "value": values, "operation": op})
    if not rows:
        raise ValueError("opencti patch fields must not be empty")
    return rows


def _opencti_field_patch_query(mutation: str) -> str:
    if mutation.endswith("FieldPatch"):
        return f"""
            mutation BedniiosintPatchOpenCtiObject($id: ID!, $input: [EditInput]!) {{
                {mutation}(id: $id, input: $input) {{
                    id
                    standard_id
                    entity_type
                    created_at
                    updated_at
                }}
            }}
        """
    return f"""
        mutation BedniiosintPatchOpenCtiObject($id: ID!, $input: [EditInput]!) {{
            {mutation}(id: $id) {{
                fieldPatch(input: $input) {{
                    id
                    standard_id
                    entity_type
                    created_at
                    updated_at
                }}
            }}
        }}
    """
