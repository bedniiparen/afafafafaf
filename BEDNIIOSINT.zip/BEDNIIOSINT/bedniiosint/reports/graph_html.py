from __future__ import annotations

import html as _html
import json
from typing import Any, Iterable

_VIS_JS = "https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"


def _json_for_script(value: Any) -> str:
    return (
        json.dumps(value, ensure_ascii=False)
        .replace("</", "<\\/")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def render_relationship_graph(
    nodes: Iterable[dict[str, Any]],
    edges: Iterable[dict[str, Any]],
    height: str = "480px",
    container_id: str = "bednii-graph",
) -> str:
    node_list = list(nodes)
    edge_list = list(edges)
    if not node_list:
        return '<div class="graph-empty">No relationship data to display.</div>'
    nodes_json = _json_for_script(node_list)
    edges_json = _json_for_script(edge_list)
    cid = _html.escape(container_id, quote=True)
    cid_js = _json_for_script(container_id)
    return (
        '<div class="relationship-graph">'
        f'<div id="{cid}" style="height:{_html.escape(height)};border:1px solid #ddd;border-radius:8px;"></div>'
        f'<script src="{_VIS_JS}"></script>'
        "<script>(function(){"
        "try{"
        f"var nodes=new vis.DataSet({nodes_json});"
        f"var edges=new vis.DataSet({edges_json});"
        f"var c=document.getElementById({cid_js});"
        "new vis.Network(c,{nodes:nodes,edges:edges},"
        '{physics:{stabilization:true},nodes:{shape:"dot",size:14,font:{size:13}},'
        'edges:{arrows:"to",smooth:true}});'
        "}catch(e){"
        f"document.getElementById({cid_js}).innerHTML="
        '"<em>Interactive graph unavailable offline.</em>";'
        "}})();</script></div>"
    )


def build_graph_payload(results: list) -> tuple[list[dict], list[dict]]:
    nodes: dict[str, dict] = {}
    edges: list[dict] = []

    def add_node(node_id: str, label: str, group: str) -> None:
        if node_id and node_id not in nodes:
            nodes[node_id] = {"id": node_id, "label": label[:40], "group": group}

    for result in results:
        if isinstance(result, dict):
            entity = str(result.get("matched_entity") or result.get("entity_input") or "")
            source = str(result.get("source_name") or result.get("source_id") or "")
            url = str(result.get("url") or "")
        else:
            entity = str(getattr(result, "matched_entity", "") or getattr(result, "entity_input", ""))
            source = str(getattr(result, "source_name", "") or getattr(result, "source_id", ""))
            url = str(getattr(result, "url", "") or "")
        if entity:
            add_node(f"entity:{entity}", entity, "entity")
        target_id = url or f"src:{source}:{entity}"
        add_node(target_id, source or url or "result", "result")
        if entity and target_id:
            edges.append({"from": f"entity:{entity}", "to": target_id, "label": source})
    return list(nodes.values()), edges


def build_graph_payload_from_section(section: dict[str, Any]) -> tuple[list[dict], list[dict]]:
    nodes: dict[str, dict] = {}
    edges: list[dict] = []

    def add_node(node_id: str) -> None:
        node_id = str(node_id or "")
        if node_id and node_id not in nodes:
            label = node_id.split(":", 1)[1] if ":" in node_id else node_id
            group = node_id.split(":", 1)[0] if ":" in node_id else "entity"
            nodes[node_id] = {"id": node_id, "label": label[:40], "group": group}

    for row in section.get("edges") or []:
        source = str(row.get("source") or "")
        target = str(row.get("target") or "")
        label = str(row.get("label") or "related")
        if not source or not target:
            continue
        add_node(source)
        add_node(target)
        edges.append({"from": source, "to": target, "label": label})
    return list(nodes.values()), edges
