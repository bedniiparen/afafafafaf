from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zipfile import ZIP_DEFLATED, ZipFile

from ..evidence.hashing import sha256_file


REPORT_SUFFIXES = {
    ".html": "html",
    ".json": "json",
    ".csv": "csv",
    ".md": "markdown",
    ".pdf": "pdf",
    ".zip": "bundle",
}

REPORT_STEM_SUFFIXES = (
    "-case-archive",
    "-evidence-bundle",
    "-evidence-manifest",
    "-source_health_history",
    "-technical",
    "-opencti",
    "-graphml",
    "-findings",
    "-entities",
    "-relations",
    "-attachments",
    "-metadata",
    "-username",
    "-company",
    "-domain",
    "-wallet",
    "-bundle",
    "-case",
    "-stix",
    "-taxii",
    "-misp",
    "-gexf",
    "-graph",
    "-evidence",
    "-email",
    "-phone",
    "-url",
    "-ip",
)


def _file_kind(path: Path) -> str:
    return REPORT_SUFFIXES.get(path.suffix.lower(), "file")


def case_name_for_report_file(path: Path) -> str:
    stem = path.stem
    for suffix in REPORT_STEM_SUFFIXES:
        if stem.endswith(suffix):
            return stem[: -len(suffix)]
    return stem


def _case_name_for_report(path: Path) -> str:
    return case_name_for_report_file(path)


def report_manifest(out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    files = []
    cases: dict[str, dict] = {}
    for path in sorted(out_dir.glob("*")):
        if not path.is_file() or path.name == "reports-manifest.json":
            continue
        stat = path.stat()
        case_name = _case_name_for_report(path)
        row = {
            "case": case_name,
            "name": path.name,
            "kind": _file_kind(path),
            "suffix": path.suffix.lower(),
            "size": stat.st_size,
            "sha256": sha256_file(path),
            "modified_at": datetime.fromtimestamp(
                stat.st_mtime, timezone.utc
            ).isoformat(),
        }
        files.append(row)
        case = cases.setdefault(
            case_name,
            {"case": case_name, "files": 0, "size": 0, "kinds": []},
        )
        case["files"] += 1
        case["size"] += stat.st_size
        if row["kind"] not in case["kinds"]:
            case["kinds"].append(row["kind"])

    return {
        "schema_version": "0.5",
        "kind": "bedniiosint.reports_manifest",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "reports_dir": str(out_dir),
        "secrets_returned": False,
        "cases": sorted(cases.values(), key=lambda item: item["case"]),
        "files": files,
    }


def write_report_manifest(out_dir: Path) -> Path:
    manifest = report_manifest(out_dir)
    path = out_dir / "reports-manifest.json"
    path.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    return path


def verify_report_manifest(
    manifest_path: Path,
    *,
    reports_dir: Path | None = None,
    case_name: str | None = None,
) -> dict[str, Any]:
    manifest_file = Path(manifest_path)
    errors: list[str] = []
    checks: dict[str, bool] = {}
    file_checks: list[dict[str, Any]] = []

    def add_check(name: str, ok: bool, message: str) -> None:
        checks[name] = bool(ok)
        if not ok:
            errors.append(message)

    if not manifest_file.exists():
        add_check("manifest_exists", False, f"manifest not found: {manifest_file}")
        return _report_verify_result(
            manifest_file=manifest_file,
            reports_root=reports_dir,
            case_name=case_name,
            checks=checks,
            file_checks=file_checks,
            errors=errors,
        )
    add_check("manifest_exists", True, "")

    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        add_check("manifest_json", False, f"manifest JSON is invalid: {exc}")
        return _report_verify_result(
            manifest_file=manifest_file,
            reports_root=reports_dir,
            case_name=case_name,
            checks=checks,
            file_checks=file_checks,
            errors=errors,
        )
    add_check("manifest_json", isinstance(manifest, dict), "manifest must be a JSON object")
    if not isinstance(manifest, dict):
        return _report_verify_result(
            manifest_file=manifest_file,
            reports_root=reports_dir,
            case_name=case_name,
            checks=checks,
            file_checks=file_checks,
            errors=errors,
        )

    add_check(
        "kind",
        manifest.get("kind") in {"bedniiosint.reports_manifest", None},
        "manifest kind is not bedniiosint.reports_manifest",
    )
    add_check(
        "schema_version",
        str(manifest.get("schema_version") or "") in {"0.4", "0.5"},
        "unsupported report manifest schema_version",
    )
    add_check(
        "secrets_returned",
        manifest.get("secrets_returned") is not True,
        "manifest must not declare secrets_returned=true",
    )

    root = reports_dir or _manifest_reports_dir(manifest_file, manifest)
    files = manifest.get("files") if isinstance(manifest.get("files"), list) else []
    if case_name:
        files = [row for row in files if isinstance(row, dict) and row.get("case") == case_name]
    add_check("files_present", bool(files), "manifest has no matching files")

    missing = 0
    unsafe = 0
    size_failed = 0
    sha256_failed = 0
    hash_missing = 0
    for row in files:
        if not isinstance(row, dict):
            unsafe += 1
            file_checks.append({"name": "", "safe_path": False, "present": False})
            continue
        name = str(row.get("name") or "")
        expected_size = _int_value(row.get("size"))
        expected_sha256 = str(row.get("sha256") or "")
        target = _safe_report_path(root, name)
        if target is None:
            unsafe += 1
            file_checks.append(
                {
                    "case": row.get("case") or "",
                    "name": name,
                    "kind": row.get("kind") or "",
                    "safe_path": False,
                    "present": False,
                    "size_ok": False,
                    "sha256_ok": False,
                    "expected_size": expected_size,
                    "actual_size": 0,
                    "expected_sha256": expected_sha256,
                    "actual_sha256": "",
                }
            )
            continue
        present = target.exists() and target.is_file()
        if not present:
            missing += 1
        actual_size = target.stat().st_size if present else 0
        actual_sha256 = sha256_file(target) if present else ""
        size_ok = present and actual_size == expected_size
        sha256_ok = present and bool(expected_sha256) and actual_sha256 == expected_sha256
        if present and not size_ok:
            size_failed += 1
        if not expected_sha256:
            hash_missing += 1
        elif present and not sha256_ok:
            sha256_failed += 1
        file_checks.append(
            {
                "case": row.get("case") or "",
                "name": name,
                "kind": row.get("kind") or "",
                "safe_path": True,
                "present": present,
                "size_ok": size_ok,
                "sha256_ok": sha256_ok,
                "expected_size": expected_size,
                "actual_size": actual_size,
                "expected_sha256": expected_sha256,
                "actual_sha256": actual_sha256,
            }
        )

    add_check("safe_paths", unsafe == 0, f"{unsafe} unsafe report path(s)")
    add_check("files_exist", missing == 0, f"{missing} report file(s) missing")
    add_check("sizes", size_failed == 0, f"{size_failed} report file size check(s) failed")
    add_check("hashes_present", hash_missing == 0, f"{hash_missing} report hash(es) missing")
    add_check("sha256", sha256_failed == 0, f"{sha256_failed} report SHA-256 check(s) failed")

    return _report_verify_result(
        manifest_file=manifest_file,
        reports_root=root,
        case_name=case_name,
        checks=checks,
        file_checks=file_checks,
        errors=errors,
    )


def write_case_bundle(out_dir: Path, case_name: str) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = report_manifest(out_dir)
    selected = [row for row in manifest["files"] if row["case"] == case_name]
    bundle_path = out_dir / f"{case_name}-bundle.zip"
    with ZipFile(bundle_path, "w", ZIP_DEFLATED) as archive:
        selected = [row for row in selected if row["name"] != bundle_path.name]
        archive.writestr(
            "manifest.json",
            json.dumps(
                {
                    "schema_version": manifest["schema_version"],
                    "generated_at": manifest["generated_at"],
                    "case": case_name,
                    "files": selected,
                },
                indent=2,
            ),
        )
        for row in selected:
            path = out_dir / row["name"]
            if path.exists() and path.is_file() and path != bundle_path:
                archive.write(path, arcname=row["name"])
    return bundle_path


def _manifest_reports_dir(manifest_file: Path, manifest: dict[str, Any]) -> Path:
    reported = Path(str(manifest.get("reports_dir") or ""))
    if reported.is_absolute():
        return reported
    if str(reported):
        candidate = manifest_file.parent / reported
        if candidate.exists():
            return candidate
    return manifest_file.parent


def _safe_report_path(root: Path, name: str) -> Path | None:
    if not name:
        return None
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        return None
    root_resolved = root.resolve()
    target = (root_resolved / relative).resolve()
    if target != root_resolved and root_resolved not in target.parents:
        return None
    return target


def _report_verify_result(
    *,
    manifest_file: Path,
    reports_root: Path | None,
    case_name: str | None,
    checks: dict[str, bool],
    file_checks: list[dict[str, Any]],
    errors: list[str],
) -> dict[str, Any]:
    return {
        "valid": bool(checks) and all(bool(value) for value in checks.values()),
        "manifest_path": str(manifest_file),
        "reports_dir": str(reports_root or ""),
        "case": case_name or "",
        "summary": {
            "files": len(file_checks),
            "present": sum(1 for row in file_checks if row.get("present")),
            "missing": sum(1 for row in file_checks if not row.get("present")),
            "sha256_ok": sum(1 for row in file_checks if row.get("sha256_ok")),
            "size_ok": sum(1 for row in file_checks if row.get("size_ok")),
        },
        "checks": dict(checks),
        "files": file_checks,
        "errors": list(errors),
        "secrets_returned": False,
    }


def _int_value(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0
