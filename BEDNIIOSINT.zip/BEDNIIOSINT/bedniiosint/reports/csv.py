from __future__ import annotations

import csv
from pathlib import Path

from .redaction import redact_report_value


EXPORT_TABLES = {
    "findings": (
        "source_name",
        "source_id",
        "source_reliability",
        "entity_type",
        "entity_value",
        "finding_type",
        "status",
        "confidence",
        "confidence_reason",
        "profile_url",
        "first_seen",
        "last_seen",
        "rejected",
        "reject_reason",
    ),
    "entities": ("type", "value", "created_at"),
    "relations": ("src_type", "src_value", "rel", "dst_type", "dst_value"),
    "evidence": (
        "source_module",
        "adapter_version",
        "method",
        "url",
        "final_url",
        "http_status",
        "content_type",
        "sha256",
        "artifact_path",
        "captured_at",
    ),
    "attachments": (
        "kind",
        "path",
        "sha256",
        "mime",
        "source_adapter_version",
        "captured_at",
    ),
    "sources": (
        "source_id",
        "name",
        "category",
        "adapter",
        "auth",
        "reliability",
        "success_count",
        "error_count",
        "health_status",
        "terms_risk",
        "collection_mode",
        "sensitivity",
        "policy_labels",
        "last_error",
    ),
    "source_health_history": (
        "observed_at",
        "run_id",
        "run_module",
        "run_target",
        "source_id",
        "name",
        "category",
        "health_state",
        "health_status",
        "success_count",
        "error_count",
        "success_rate",
        "last_error",
        "terms_risk",
        "sensitivity",
        "policy_labels",
        "notes",
    ),
    "timeline": (
        "when",
        "precision",
        "kind",
        "entity_type",
        "entity_value",
        "source",
        "confidence",
        "description",
    ),
    "notes": ("entity_type", "entity_value", "note", "created_at"),
}


def write_case_csv(summary: dict, out_dir: Path, case_name: str) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    written: dict[str, Path] = {}
    for table, columns in EXPORT_TABLES.items():
        if table == "source_health_history":
            rows = summary.get("source_health_history", {}).get("rows", [])
        else:
            rows = summary.get(table, [])
        path = out_dir / f"{case_name}-{table}.csv"
        with path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(columns), extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                redacted_row = {
                    column: redact_report_value(row.get(column), key=column)
                    for column in columns
                }
                writer.writerow(redacted_row)
        written[table] = path
    return written
