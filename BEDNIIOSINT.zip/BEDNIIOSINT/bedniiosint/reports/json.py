from __future__ import annotations

import json
from pathlib import Path

from .redaction import redact_report_summary


def write_json(summary: dict, out: Path) -> Path:
    summary = redact_report_summary(summary)
    out.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    return out
