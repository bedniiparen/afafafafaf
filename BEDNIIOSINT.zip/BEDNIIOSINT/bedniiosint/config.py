from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
DATA_DIR = PACKAGE_DIR / "modules" / "username"
DEFAULT_SITES_FILE = DATA_DIR / "sites.json"

_PREFIX = "BEDNIIOSINT_"


def _env_str(name: str, default: str) -> str:
    return os.getenv(_PREFIX + name, default)


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(_PREFIX + name)
    if raw is None:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(_PREFIX + name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(_PREFIX + name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_list(name: str, default: tuple[str, ...] = ()) -> tuple[str, ...]:
    raw = os.getenv(_PREFIX + name, "")
    if not raw:
        return default
    return tuple(part.strip() for part in raw.split(",") if part.strip())


def _default_db_dir() -> Path:
    override = os.getenv(_PREFIX + "DB_DIR")
    return Path(override) if override else PACKAGE_DIR.parent / "runtime" / "cases"


@dataclass(frozen=True)
class Settings:
    timeout: float = field(default_factory=lambda: _env_float("TIMEOUT", 12.0))
    max_concurrency: int = field(default_factory=lambda: _env_int("MAX_CONCURRENCY", 64))
    user_agent: str = field(
        default_factory=lambda: _env_str(
            "USER_AGENT",
            "Mozilla/5.0 (compatible; BEDNIIOSINT/0.1; +https://example.invalid)",
        )
    )
    control_usernames: int = field(default_factory=lambda: _env_int("CONTROL_USERNAMES", 2))
    control_length: int = field(default_factory=lambda: _env_int("CONTROL_LENGTH", 22))
    high_threshold: float = field(default_factory=lambda: _env_float("HIGH_THRESHOLD", 0.75))
    medium_threshold: float = field(default_factory=lambda: _env_float("MEDIUM_THRESHOLD", 0.45))
    min_source_reliability: float = field(
        default_factory=lambda: _env_float("MIN_SOURCE_RELIABILITY", 0.35)
    )
    http_max_retries: int = field(default_factory=lambda: _env_int("HTTP_MAX_RETRIES", 2))
    http_backoff: float = field(default_factory=lambda: _env_float("HTTP_BACKOFF", 0.5))
    http_rate_limit_delay: float = field(
        default_factory=lambda: _env_float("HTTP_RATE_LIMIT_DELAY", 0.05)
    )
    proxy_url: str = field(default_factory=lambda: _env_str("PROXY_URL", ""))
    proxy_pool: tuple[str, ...] = field(default_factory=lambda: _env_list("PROXY_POOL"))
    rotate_user_agents: bool = field(default_factory=lambda: _env_bool("ROTATE_UA", False))
    request_jitter: float = field(default_factory=lambda: _env_float("REQUEST_JITTER", 0.0))
    cache_enabled: bool = field(default_factory=lambda: _env_bool("CACHE_ENABLED", True))
    cache_ttl: float = field(default_factory=lambda: _env_float("CACHE_TTL", 3600.0))
    cache_backend: str = field(default_factory=lambda: _env_str("CACHE_BACKEND", "sqlite"))
    redis_url: str = field(default_factory=lambda: _env_str("REDIS_URL", "redis://localhost:6379/0"))
    breaker_failures: int = field(default_factory=lambda: _env_int("BREAKER_FAILURES", 5))
    breaker_reset: float = field(default_factory=lambda: _env_float("BREAKER_RESET", 120.0))
    db_dir: Path = field(default_factory=_default_db_dir)
    database_url: str = field(default_factory=lambda: _env_str("DATABASE_URL", ""))
    embedding_provider: str = field(default_factory=lambda: _env_str("EMBEDDING_PROVIDER", ""))
    embedding_rerank_enabled: bool = field(
        default_factory=lambda: _env_bool("EMBEDDING_RERANK", False)
    )
    rank_relevance_weight: float = field(
        default_factory=lambda: _env_float("RANK_RELEVANCE_WEIGHT", 0.5)
    )
    rank_confidence_weight: float = field(
        default_factory=lambda: _env_float("RANK_CONFIDENCE_WEIGHT", 0.5)
    )
    presence_filter_enabled: bool = field(
        default_factory=lambda: _env_bool("PRESENCE_FILTER", True)
    )
    presence_drop_absent: bool = field(
        default_factory=lambda: _env_bool("PRESENCE_DROP_ABSENT", True)
    )
    verify_candidate_urls: bool = field(
        default_factory=lambda: _env_bool("VERIFY_CANDIDATE_URLS", True)
    )
    verify_candidate_limit: int = field(
        default_factory=lambda: _env_int("VERIFY_CANDIDATE_LIMIT", 180)
    )
    verify_candidate_workers: int = field(
        default_factory=lambda: _env_int("VERIFY_CANDIDATE_WORKERS", 16)
    )
    verify_candidate_timeout: float = field(
        default_factory=lambda: _env_float("VERIFY_CANDIDATE_TIMEOUT", 25.0)
    )
    verify_candidate_drop_absent: bool = field(
        default_factory=lambda: _env_bool("VERIFY_CANDIDATE_DROP_ABSENT", True)
    )
    strict_profile_results: bool = field(
        default_factory=lambda: _env_bool("STRICT_PROFILE_RESULTS", True)
    )
    identity_resolution_enabled: bool = field(
        default_factory=lambda: _env_bool("IDENTITY_RESOLUTION", True)
    )
    username_corpus_sync_enabled: bool = field(
        default_factory=lambda: _env_bool("USERNAME_CORPUS_SYNC", True)
    )
    username_corpus_ttl: float = field(
        default_factory=lambda: _env_float("USERNAME_CORPUS_TTL", 604800.0)
    )
    username_corpus_cache_dir: str = field(
        default_factory=lambda: _env_str("USERNAME_CORPUS_CACHE_DIR", "")
    )
    evidence_capture_enabled: bool = field(
        default_factory=lambda: _env_bool("EVIDENCE_CAPTURE", True)
    )
    evidence_capture_live: bool = field(
        default_factory=lambda: _env_bool("EVIDENCE_CAPTURE_LIVE", False)
    )
    evidence_capture_limit: int = field(
        default_factory=lambda: _env_int("EVIDENCE_CAPTURE_LIMIT", 25)
    )
    account_existence_enabled: bool = field(
        default_factory=lambda: _env_bool("ACCOUNT_EXISTENCE", True)
    )
    numverify_api_key: str = field(
        default_factory=lambda: _env_str("NUMVERIFY_API_KEY", "")
    )
    veriphone_api_key: str = field(
        default_factory=lambda: _env_str("VERIPHONE_API_KEY", "")
    )
    breach_enabled: bool = field(
        default_factory=lambda: _env_bool("BREACH_ENABLED", True)
    )
    dehashed_api_key: str = field(
        default_factory=lambda: _env_str("DEHASHED_API_KEY", "")
    )
    dehashed_username: str = field(
        default_factory=lambda: _env_str("DEHASHED_USERNAME", "")
    )
    leakcheck_api_key: str = field(
        default_factory=lambda: _env_str("LEAKCHECK_API_KEY", "")
    )
    intelx_api_key: str = field(
        default_factory=lambda: _env_str("INTELX_API_KEY", "")
    )
    intelx_base_url: str = field(
        default_factory=lambda: _env_str("INTELX_BASE_URL", "")
    )
    combolist_paths: str = field(
        default_factory=lambda: _env_str("COMBOLIST_PATHS", "")
    )
    search_calibration_model: str = field(
        default_factory=lambda: _env_str("SEARCH_CALIBRATION_MODEL", "")
    )
    search_calibration_overwrite: bool = field(
        default_factory=lambda: _env_bool("SEARCH_CALIBRATION_OVERWRITE", False)
    )
    search_profile_extract_enabled: bool = field(
        default_factory=lambda: _env_bool("SEARCH_PROFILE_EXTRACT", False)
    )
    search_profile_extract_limit: int = field(
        default_factory=lambda: _env_int("SEARCH_PROFILE_EXTRACT_LIMIT", 50)
    )
    search_avatar_hash_enabled: bool = field(
        default_factory=lambda: _env_bool("SEARCH_AVATAR_HASH", False)
    )
    search_avatar_hash_limit: int = field(
        default_factory=lambda: _env_int("SEARCH_AVATAR_HASH_LIMIT", 200)
    )
    correlation_rules_path: str = field(
        default_factory=lambda: _env_str("CORRELATION_RULES_PATH", "")
    )
    shodan_api_key: str = field(default_factory=lambda: _env_str("SHODAN_API_KEY", ""))
    censys_api_id: str = field(default_factory=lambda: _env_str("CENSYS_API_ID", ""))
    censys_api_secret: str = field(default_factory=lambda: _env_str("CENSYS_API_SECRET", ""))
    hibp_api_key: str = field(default_factory=lambda: _env_str("HIBP_API_KEY", ""))
    hunter_api_key: str = field(default_factory=lambda: _env_str("HUNTER_API_KEY", ""))
    securitytrails_api_key: str = field(
        default_factory=lambda: _env_str("SECURITYTRAILS_API_KEY", "")
    )
    virustotal_api_key: str = field(default_factory=lambda: _env_str("VIRUSTOTAL_API_KEY", ""))
    urlscan_api_key: str = field(default_factory=lambda: _env_str("URLSCAN_API_KEY", ""))
    greynoise_api_key: str = field(default_factory=lambda: _env_str("GREYNOISE_API_KEY", ""))
    opencorporates_api_token: str = field(
        default_factory=lambda: _env_str("OPENCORPORATES_API_TOKEN", "")
    )
    # Optional tokens that only raise rate limits for otherwise-keyless connectors.
    github_token: str = field(default_factory=lambda: _env_str("GITHUB_TOKEN", ""))
    ipinfo_token: str = field(default_factory=lambda: _env_str("IPINFO_TOKEN", ""))
    # Auto-pivot / recursive investigation limits.
    autopivot_max_depth: int = field(default_factory=lambda: _env_int("AUTOPIVOT_MAX_DEPTH", 2))
    autopivot_max_nodes: int = field(default_factory=lambda: _env_int("AUTOPIVOT_MAX_NODES", 25))
    autopivot_min_confidence: float = field(
        default_factory=lambda: _env_float("AUTOPIVOT_MIN_CONFIDENCE", 0.6)
    )
    autopivot_per_type_cap: int = field(default_factory=lambda: _env_int("AUTOPIVOT_PER_TYPE_CAP", 8))
    search_source_timeout: float = field(
        default_factory=lambda: _env_float("SEARCH_SOURCE_TIMEOUT", 30.0)
    )
    investigation_deadline_seconds: float = field(
        default_factory=lambda: _env_float("INVESTIGATION_DEADLINE", 180.0)
    )

    def db_path(self, case_name: str) -> Path:
        safe = "".join(c for c in case_name if c.isalnum() or c in "-_") or "case"
        self.db_dir.mkdir(parents=True, exist_ok=True)
        return self.db_dir / f"{safe}.db"


settings = Settings()
