from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table


console = Console()
case_app = typer.Typer(add_completion=False, help="Case runner and case view commands")


def _write_module_json(summary: dict, out_dir: Path, case: str, module: str) -> Path:
    from .reports.json import write_json

    out_dir.mkdir(parents=True, exist_ok=True)
    return write_json(summary, out_dir / f"{case}-{module}.json")


def _print_result(summary: dict) -> None:
    result = summary.get("result")
    if isinstance(result, dict):
        table = Table(title="Result")
        table.add_column("Field")
        table.add_column("Value")
        for key, value in result.items():
            if key == "raw":
                continue
            table.add_row(str(key), str(value))
        console.print(table)
    else:
        console.print(summary)


def _load_case_summary_arg(value: str) -> dict:
    path = Path(value)
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    from .core.case_summary import build_case_summary

    summary = build_case_summary(value)
    if not summary.get("meta", {}).get("found"):
        raise typer.BadParameter(f"case or JSON file not found: {value}")
    return summary


def _case_diff_payload(previous: str, current: str) -> dict:
    from .core.case_diff import diff_case_summaries

    return diff_case_summaries(
        _load_case_summary_arg(previous),
        _load_case_summary_arg(current),
    )


@case_app.command("email")
def email(
    target: str,
    case: str = typer.Option("default-case", "--case"),
    json_out: bool = typer.Option(True, "--json"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """Email OSINT: format, MX/SPF/DMARC, Gravatar, breach if key is set."""
    from .core.case_email import EmailCase

    summary = EmailCase(case, target).run()
    console.print(summary["result"])
    if json_out:
        path = _write_module_json(summary, out_dir, case, "email")
        console.print(f"[dim]JSON ->[/] {path}")


@case_app.command("domain")
def domain(
    target: str,
    case: str = typer.Option("default-case", "--case"),
    no_resolve: bool = typer.Option(False, "--no-resolve"),
    json_out: bool = typer.Option(True, "--json"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """Domain OSINT: DNS, RDAP, CT-log subdomains."""
    from .core.case_domain import DomainCase

    summary = DomainCase(case, target, resolve_subs=not no_resolve).run()
    console.print(f"Subdomains found: {len(summary['result']['subdomains'])}")
    if json_out:
        path = _write_module_json(summary, out_dir, case, "domain")
        console.print(f"[dim]JSON ->[/] {path}")


@case_app.command("metadata")
def metadata(
    file: Path,
    case: str = typer.Option("default-case", "--case"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """Extract EXIF/PDF/Office metadata via ExifTool when available."""
    from .core.case_metadata import MetadataCase

    summary = MetadataCase(case, str(file)).run()
    console.print(summary["result"])
    out_dir.mkdir(parents=True, exist_ok=True)
    path = _write_module_json(summary, out_dir, case, "metadata")
    console.print(f"[dim]JSON ->[/] {path}")


@case_app.command("media-verify-plan")
def media_verify_plan(
    target: str = typer.Argument(..., help="Local media file path or public media URL"),
    out: Path | None = typer.Option(None, "--out", help="Write Markdown workflow to this path"),
    json_out: bool = typer.Option(False, "--json", help="Print workflow JSON"),
):
    """Create a legal media verification workflow without third-party uploads."""
    from .core.media_verification import (
        build_media_verification_workflow,
        write_media_verification_markdown,
    )

    workflow = build_media_verification_workflow(target)
    if json_out:
        console.print(json.dumps(workflow, indent=2, ensure_ascii=False, default=str))
    if out:
        path = write_media_verification_markdown(workflow, out)
        console.print(f"[dim]Media verification workflow ->[/] {path}")
    elif not json_out:
        console.print(json.dumps(workflow, indent=2, ensure_ascii=False, default=str))


@case_app.command("ip")
def ip(
    target: str = typer.Argument(..., help="IP address to investigate"),
    case: str = typer.Option("default-case", "--case"),
    json_out: bool = typer.Option(True, "--json"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """IP OSINT: validation, geolocation, ASN/ISP and reverse DNS."""
    from .core.case_extra import IPCase

    summary = IPCase(case, target).run()
    _print_result(summary)
    if json_out:
        path = _write_module_json(summary, out_dir, case, "ip")
        console.print(f"[dim]JSON ->[/] {path}")


@case_app.command("phone")
def phone(
    target: str = typer.Argument(..., help="Phone number to investigate"),
    case: str = typer.Option("default-case", "--case"),
    region: str | None = typer.Option(None, "--region", help="Default parsing region"),
    json_out: bool = typer.Option(True, "--json"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """Phone OSINT: format, region, carrier, timezone and line type."""
    from .core.case_extra import PhoneCase

    summary = PhoneCase(case, target, region).run()
    _print_result(summary)
    if json_out:
        path = _write_module_json(summary, out_dir, case, "phone")
        console.print(f"[dim]JSON ->[/] {path}")


@case_app.command("url")
def url(
    target: str = typer.Argument(..., help="URL or profile page to analyze"),
    case: str = typer.Option("default-case", "--case"),
    json_out: bool = typer.Option(True, "--json"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """URL/profile OSINT: metadata, outbound links, socials, emails and wallets."""
    from .core.case_extra import URLCase

    summary = URLCase(case, target).run()
    _print_result(summary)
    if json_out:
        path = _write_module_json(summary, out_dir, case, "url")
        console.print(f"[dim]JSON ->[/] {path}")


@case_app.command("wallet")
def wallet(
    target: str = typer.Argument(..., help="BTC or ETH wallet address"),
    case: str = typer.Option("default-case", "--case"),
    json_out: bool = typer.Option(True, "--json"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """Crypto OSINT: BTC/ETH format, explorer lookup, balance and transaction count."""
    from .core.case_extra import WalletCase

    summary = WalletCase(case, target).run()
    _print_result(summary)
    if json_out:
        path = _write_module_json(summary, out_dir, case, "wallet")
        console.print(f"[dim]JSON ->[/] {path}")


@case_app.command("company")
def company(
    target: str = typer.Argument(..., help="Company name to investigate"),
    case: str = typer.Option("default-case", "--case"),
    domain: str | None = typer.Option(None, "--domain", help="Known company domain"),
    json_out: bool = typer.Option(True, "--json"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """Company OSINT: guessed domain and optional registry enrichment."""
    from .core.case_extra import CompanyCase

    summary = CompanyCase(case, target, domain).run()
    _print_result(summary)
    if json_out:
        path = _write_module_json(summary, out_dir, case, "company")
        console.print(f"[dim]JSON ->[/] {path}")


@case_app.command("find")
def find(
    target: str = typer.Argument(..., help="Auto-detect target type and run a case"),
    case: str | None = typer.Option(None, "--case"),
    module: str = typer.Option("auto", "--module", help="Module name or auto"),
    json_out: bool = typer.Option(True, "--json"),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
):
    """Auto-detect a target and run the matching module."""
    from .core.case import UsernameCase
    from .core.case_domain import DomainCase
    from .core.case_email import EmailCase
    from .core.case_extra import CompanyCase, IPCase, PhoneCase, URLCase, WalletCase
    from .core.case_metadata import MetadataCase
    from .core.target import auto_case_name, detect_module, safe_case_name

    selected = detect_module(target) if module == "auto" else module.strip().lower()
    case_name = safe_case_name(case) if case else auto_case_name(selected, target)
    runners = {
        "username": lambda: UsernameCase(case_name, target).run(),
        "email": lambda: EmailCase(case_name, target).run(),
        "domain": lambda: DomainCase(case_name, target).run(),
        "metadata": lambda: MetadataCase(case_name, target).run(),
        "ip": lambda: IPCase(case_name, target).run(),
        "url": lambda: URLCase(case_name, target).run(),
        "phone": lambda: PhoneCase(case_name, target).run(),
        "wallet": lambda: WalletCase(case_name, target).run(),
        "company": lambda: CompanyCase(case_name, target).run(),
    }
    runner = runners.get(selected)
    if runner is None:
        console.print(f"[red]unknown module:[/] {selected}")
        raise typer.Exit(1)
    console.print(f"[bold cyan]Detected[/] {selected} | case '[bold]{case_name}[/]'")
    summary = runner()
    _print_result(summary)
    if json_out:
        path = _write_module_json(summary, out_dir, case_name, selected)
        console.print(f"[dim]JSON ->[/] {path}")


@case_app.command("graph")
def graph(
    case: str = typer.Argument(...),
    out_dir: Path = typer.Option(Path("runtime/reports_out"), "--out"),
    graphml: bool = typer.Option(False, "--graphml", help="Write GraphML export"),
    gexf: bool = typer.Option(False, "--gexf", help="Write GEXF export"),
):
    """Export the analyst display graph as Cytoscape JSON and print metrics."""
    from .core.case_workspace import get_workspace
    from .graph.export import graph_from_cytoscape_elements, write_gexf, write_graph_json, write_graphml

    try:
        workspace = get_workspace(case)
    except KeyError:
        console.print("[red]case not found[/]")
        raise typer.Exit(1)
    display = workspace.get("graph") or {}
    elements = {
        "nodes": display.get("nodes") or [],
        "edges": display.get("edges") or [],
    }
    result = graph_from_cytoscape_elements(elements)
    console.print(display.get("metrics") or {})
    out_dir.mkdir(parents=True, exist_ok=True)
    path = write_graph_json(result, out_dir / f"{case}-graph.json")
    console.print(f"[dim]Graph ->[/] {path}")
    if graphml:
        path = write_graphml(result, out_dir / f"{case}-graphml.graphml")
        console.print(f"[dim]GraphML ->[/] {path}")
    if gexf:
        path = write_gexf(result, out_dir / f"{case}-gexf.gexf")
        console.print(f"[dim]GEXF ->[/] {path}")


@case_app.command("timeline")
def timeline(case: str = typer.Argument(...)):
    """Print the chronological timeline for a case."""
    from .config import settings
    from .core.case_lookup import case_ids
    from .core.timeline import get_timeline
    from .storage.sqlite import Storage

    storage = Storage(settings.db_path(case))
    ids = case_ids(storage, case)
    if not ids:
        console.print("[red]case not found[/]")
        raise typer.Exit(1)
    for event in get_timeline(storage, ids):
        when = event["when"] or "-"
        console.print(
            f"[cyan]{when}[/] | {event['kind']:<10} | {event['entity']} ({event['source']})"
        )


@case_app.command("diff")
def case_diff(
    previous: str = typer.Argument(..., help="Previous case name or summary JSON file"),
    current: str = typer.Argument(..., help="Current case name or summary JSON file"),
    json_out: bool = typer.Option(True, "--json/--table", help="Print JSON diff by default"),
):
    """Compare two case summaries and show added/removed findings."""
    diff = _case_diff_payload(previous, current)
    if json_out:
        console.print(json.dumps(diff, indent=2, ensure_ascii=False, default=str))
        return
    table = Table(title="Case Diff")
    table.add_column("Metric")
    table.add_column("Count")
    for key, value in diff["summary"].items():
        table.add_row(str(key), str(value))
    console.print(table)
