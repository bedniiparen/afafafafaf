from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

plugins_app = typer.Typer(help="Plugin discovery, state, config and signing commands")
console = Console()


@plugins_app.command("list")
def plugins(
    plugins_dir: Path = typer.Option(Path("plugins"), "--dir", help="Plugin directory"),
    include_disabled: bool = typer.Option(False, "--include-disabled"),
):
    """List built-in and local plugin manifests."""
    from .core.plugins import all_plugin_manifests

    manifests = all_plugin_manifests(plugins_dir, include_disabled=include_disabled)
    table = Table(title="Plugins")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Enabled")
    table.add_column("Signature")
    table.add_column("Consumes")
    table.add_column("Produces")
    table.add_column("Entrypoint")
    table.add_column("Path")
    for manifest in manifests:
        status = manifest.signature_status or {}
        if status.get("verified") is True:
            signature = "verified"
        elif status.get("signed"):
            signature = "signed"
        else:
            signature = "unsigned"
        table.add_row(
            manifest.name,
            manifest.version,
            "yes" if manifest.enabled else "no",
            signature,
            ", ".join(manifest.consumes),
            ", ".join(manifest.produces),
            manifest.entrypoint,
            manifest.path,
        )
    console.print(table)


@plugins_app.command("enable")
def plugin_enable(name: str = typer.Argument(...)):
    """Enable a plugin manifest by name."""
    from .core.plugins import set_plugin_enabled

    console.print(json.dumps(set_plugin_enabled(name, True), indent=2, ensure_ascii=False))


@plugins_app.command("disable")
def plugin_disable(name: str = typer.Argument(...)):
    """Disable a plugin manifest by name."""
    from .core.plugins import set_plugin_enabled

    console.print(json.dumps(set_plugin_enabled(name, False), indent=2, ensure_ascii=False))


@plugins_app.command("config")
def plugin_config(
    name: str = typer.Argument(...),
    config_json: str | None = typer.Option(None, "--set-json"),
):
    """Read or replace per-plugin JSON config."""
    from .core.plugins import get_plugin_config, set_plugin_config

    if config_json is None:
        console.print(json.dumps(get_plugin_config(name), indent=2, ensure_ascii=False))
        return
    data = json.loads(config_json)
    if not isinstance(data, dict):
        console.print("[red]config must be a JSON object[/]")
        raise typer.Exit(1)
    console.print(json.dumps(set_plugin_config(name, data), indent=2, ensure_ascii=False))


@plugins_app.command("sign")
def plugin_sign(
    manifest: Path = typer.Argument(...),
    key: str = typer.Option(..., "--key"),
    key_id: str = typer.Option("local", "--key-id"),
):
    """Write an HMAC signature into a plugin manifest."""
    from .core.plugins import sign_plugin_manifest

    console.print(
        json.dumps(
            sign_plugin_manifest(manifest, key, key_id=key_id),
            indent=2,
            ensure_ascii=False,
        )
    )


@plugins_app.command("verify")
def plugin_verify(
    manifest: Path = typer.Argument(...),
    key: str | None = typer.Option(None, "--key"),
):
    """Verify a signed plugin manifest."""
    from .core.plugins import verify_plugin_manifest

    console.print(json.dumps(verify_plugin_manifest(manifest, key), indent=2, ensure_ascii=False))


@plugins_app.command("generate-adapter")
def generate_adapter(
    source_id: str = typer.Argument(..., help="Catalog API id, e.g. crtsh or api:crtsh"),
    out_dir: Path = typer.Option(Path("plugins"), "--out", help="Plugin output directory"),
    force: bool = typer.Option(False, "--force", help="Overwrite an existing scaffold"),
):
    """Generate a local adapter scaffold from the source catalog."""
    from .core.adapter_generator import scaffold_adapter

    try:
        files = scaffold_adapter(source_id, out_dir, force=force)
    except KeyError as exc:
        console.print(f"[red]{exc}[/]")
        raise typer.Exit(1) from exc
    except FileExistsError as exc:
        console.print(f"[yellow]{exc}[/]")
        raise typer.Exit(1) from exc

    for label, path in files.items():
        console.print(f"[dim]{label} ->[/] {path}")
