from __future__ import annotations

import os
from dataclasses import dataclass

import httpx

from ..observability import get_logger

log = get_logger("alerts")


@dataclass(frozen=True)
class Alert:
    level: str
    title: str
    text: str = ""


def _webhooks() -> list[str]:
    raw = os.getenv("BEDNIIOSINT_ALERT_WEBHOOKS", "")
    return [url.strip() for url in raw.split(",") if url.strip()]


def dispatch(alert: Alert) -> None:
    hooks = _webhooks()
    if not hooks:
        log.info("alert without webhook", extra={"level": alert.level, "title": alert.title})
        return
    payload = {"text": f"[{alert.level.upper()}] {alert.title}\n{alert.text}".strip()}
    for url in hooks:
        try:
            with httpx.Client(timeout=10.0) as client:
                client.post(url, json=payload)
        except httpx.HTTPError as exc:
            log.error("alert dispatch failed", extra={"url": url, "err": str(exc)})


def notify(level: str, title: str, text: str = "") -> None:
    dispatch(Alert(level=level, title=title, text=text))
