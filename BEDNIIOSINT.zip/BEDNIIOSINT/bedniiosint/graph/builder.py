from __future__ import annotations

from collections.abc import Iterable
from typing import TYPE_CHECKING

from ..core.redaction import redact_url

try:
    import networkx as nx
except Exception:  # pragma: no cover
    nx = None

if TYPE_CHECKING:
    from ..storage.sqlite import Storage


class SimpleDiGraph:
    def __init__(self) -> None:
        self._nodes: dict[str, dict] = {}
        self._edges: list[tuple[str, str, dict]] = []

    def add_node(self, node: str, **attrs) -> None:
        self._nodes.setdefault(node, {}).update(attrs)

    def add_edge(self, src: str, dst: str, **attrs) -> None:
        self.add_node(src)
        self.add_node(dst)
        self._edges.append((src, dst, attrs))

    def nodes(self, data: bool = False):
        return list(self._nodes.items()) if data else list(self._nodes)

    def edges(self, data: bool = False):
        return list(self._edges) if data else [(src, dst) for src, dst, _ in self._edges]

    def number_of_nodes(self) -> int:
        return len(self._nodes)

    def number_of_edges(self) -> int:
        return len(self._edges)

    def degree(self):
        counts = {node: 0 for node in self._nodes}
        for src, dst, _attrs in self._edges:
            counts[src] = counts.get(src, 0) + 1
            counts[dst] = counts.get(dst, 0) + 1
        return counts.items()


GraphType = object


def new_graph():
    return nx.DiGraph() if nx is not None else SimpleDiGraph()


def _ids(case_id: int | Iterable[int]) -> list[int]:
    if isinstance(case_id, int):
        return [case_id]
    return list(case_id)


def build_graph(storage: "Storage", case_id: int | Iterable[int]) -> GraphType:
    from ..storage.models import Entity, Evidence, Finding, Relation

    graph = new_graph()
    case_ids = _ids(case_id)
    with storage.session() as session:
        findings_by_entity: dict[tuple[int, str, str], list[Finding]] = {}
        evidence_refs_by_finding: dict[int, list[dict]] = {}
        for cid in case_ids:
            for finding in session.query(Finding).filter(Finding.case_id == cid).all():
                key = (cid, finding.entity_type, finding.entity_value)
                findings_by_entity.setdefault(key, []).append(finding)
            for evidence in session.query(Evidence).filter(Evidence.case_id == cid).all():
                evidence_refs_by_finding.setdefault(evidence.finding_id, []).append(
                    _evidence_ref(evidence)
                )
        for cid in case_ids:
            for entity in session.query(Entity).filter(Entity.case_id == cid).all():
                node_id = f"{entity.type}:{entity.value}"
                graph.add_node(node_id, type=entity.type, value=entity.value)
            for relation in session.query(Relation).filter(Relation.case_id == cid).all():
                src = f"{relation.src_type}:{relation.src_value}"
                dst = f"{relation.dst_type}:{relation.dst_value}"
                graph.add_node(src, type=relation.src_type, value=relation.src_value)
                graph.add_node(dst, type=relation.dst_type, value=relation.dst_value)
                provenance = _relation_provenance(
                    relation,
                    findings_by_entity=findings_by_entity,
                    evidence_refs_by_finding=evidence_refs_by_finding,
                )
                graph.add_edge(
                    src,
                    dst,
                    rel=relation.rel,
                    relation_id=relation.id,
                    case_id=relation.case_id,
                    weight=provenance["weight"],
                    confidence=provenance["confidence"],
                    evidence_count=provenance["evidence_count"],
                    evidence_refs=provenance["evidence_refs"],
                    provenance=provenance,
                )
    return graph


def _value_as_text(value) -> str:
    if value is None:
        return ""
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


def _evidence_ref(evidence) -> dict:
    return {
        "id": evidence.id,
        "finding_id": evidence.finding_id,
        "sha256": _value_as_text(evidence.sha256),
        "artifact_path": _value_as_text(evidence.artifact_path),
        "source_module": _value_as_text(evidence.source_module),
        "url": redact_url(_value_as_text(evidence.url)),
        "final_url": redact_url(_value_as_text(evidence.final_url)),
        "captured_at": _value_as_text(evidence.captured_at),
    }


def _unique_evidence_refs(rows: list[dict]) -> list[dict]:
    seen = set()
    unique = []
    for row in rows:
        key = (
            row.get("id"),
            row.get("sha256"),
            row.get("artifact_path"),
            row.get("url"),
        )
        if key in seen:
            continue
        seen.add(key)
        unique.append(row)
    return unique


def _relation_provenance(
    relation,
    *,
    findings_by_entity: dict[tuple[int, str, str], list],
    evidence_refs_by_finding: dict[int, list[dict]],
) -> dict:
    related = []
    for key in (
        (relation.case_id, relation.src_type, relation.src_value),
        (relation.case_id, relation.dst_type, relation.dst_value),
    ):
        related.extend(findings_by_entity.get(key, []))
    source_ids = sorted(
        {
            str(finding.source_id or finding.source_name)
            for finding in related
            if str(finding.source_id or finding.source_name)
        }
    )
    confidences = [float(finding.confidence or 0.0) for finding in related]
    confidence = round(max(confidences), 3) if confidences else 0.5
    evidence_refs = _unique_evidence_refs(
        [
            ref
            for finding in related
            for ref in evidence_refs_by_finding.get(finding.id or 0, [])
        ]
    )
    evidence_count = len(evidence_refs)
    weight = _relation_weight(
        str(relation.rel or ""),
        confidence=confidence,
        source_count=len(source_ids),
        evidence_count=evidence_count,
    )
    return {
        "relation_id": relation.id,
        "case_id": relation.case_id,
        "source_ids": source_ids,
        "confidence": confidence,
        "evidence_count": evidence_count,
        "evidence_refs": evidence_refs,
        "weight": weight,
        "reason": "relation+finding+evidence" if related else "relation_only",
    }


def _relation_weight(
    rel: str,
    *,
    confidence: float,
    source_count: int,
    evidence_count: int,
) -> float:
    rel = rel.lower()
    base = 0.45
    if rel in {"same_username", "same_as", "alias_of", "owns_profile", "registered_by"}:
        base += 0.2
    elif rel.startswith("mentions_"):
        base -= 0.1
    source_boost = min(0.2, max(0, source_count - 1) * 0.05)
    evidence_boost = min(0.15, evidence_count * 0.03)
    confidence_boost = max(0.0, min(1.0, confidence)) * 0.2
    return round(max(0.05, min(1.0, base + source_boost + evidence_boost + confidence_boost)), 3)


def graph_metrics(graph: GraphType) -> dict:
    if graph.number_of_nodes() == 0:
        return {"nodes": 0, "edges": 0, "hubs": [], "average_weight": 0.0, "strong_edges": 0}
    degree = dict(graph.degree())
    hubs = sorted(degree.items(), key=lambda item: item[1], reverse=True)[:5]
    weights = [
        float(data.get("weight") or 0.0)
        for _src, _dst, data in graph.edges(data=True)
    ]
    return {
        "nodes": graph.number_of_nodes(),
        "edges": graph.number_of_edges(),
        "hubs": [{"node": node, "degree": value} for node, value in hubs],
        "average_weight": round(sum(weights) / len(weights), 3) if weights else 0.0,
        "strong_edges": sum(1 for weight in weights if weight >= 0.75),
    }
