from __future__ import annotations

from html import escape
import json
from typing import Any

from .builder import graph_metrics, new_graph
from .export import to_cytoscape
from .pyvis_render import render_graph_html


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _safe_id(prefix: str, value: Any) -> str:
    text = _clean(value)
    if not text:
        text = "unknown"
    return f"{prefix}:{text}"


def _result_id(result: dict[str, Any], index: int) -> str:
    return _safe_id("result", result.get("id") or index)


def _entity_node_id(entity_type: Any, value: Any) -> str:
    kind = _clean(entity_type).lower() or "entity"
    return _safe_id(kind, value)


def _confidence(value: Any, default: float = 0.5) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def _evidence_refs(result: dict[str, Any]) -> list[dict[str, Any]]:
    for key in ("evidence_refs", "evidence", "artifacts"):
        rows = result.get(key)
        if isinstance(rows, list):
            return [row for row in rows if isinstance(row, dict)]
    return []


def _edge_attrs(
    rel: str,
    *,
    confidence: float = 0.5,
    evidence_refs: list[dict[str, Any]] | None = None,
    provenance: dict[str, Any] | None = None,
) -> dict[str, Any]:
    refs = evidence_refs or []
    evidence_count = len(refs)
    weight = round(max(0.1, min(1.0, 0.35 + confidence * 0.4 + min(0.25, evidence_count * 0.05))), 3)
    return {
        "rel": rel,
        "weight": weight,
        "confidence": round(confidence, 3),
        "evidence_count": evidence_count,
        "evidence_refs": refs,
        "provenance": provenance or {},
    }


def build_investigation_graph(payload: dict[str, Any]):
    graph = new_graph()
    seed = payload.get("seed") if isinstance(payload.get("seed"), dict) else {}
    seed_type = _clean(seed.get("entity_type")).lower() or "entity"
    seed_value = _clean(seed.get("value") or payload.get("target"))
    seed_id = _entity_node_id(seed_type, seed_value)
    graph.add_node(seed_id, type=seed_type, value=seed_value or "seed")

    node_ids_by_value: dict[str, str] = {}
    for node in payload.get("nodes") or []:
        if not isinstance(node, dict):
            continue
        entity_type = _clean(node.get("entity_type")).lower() or "entity"
        value = _clean(node.get("value"))
        if not value:
            continue
        node_id = _entity_node_id(entity_type, value)
        node_ids_by_value[value.lower()] = node_id
        graph.add_node(
            node_id,
            type=entity_type,
            value=value,
            depth=node.get("depth"),
            result_count=node.get("result_count", 0),
        )
        parent = _clean(node.get("parent"))
        if parent:
            parent_id = node_ids_by_value.get(parent.lower()) or _entity_node_id("entity", parent)
            graph.add_edge(
                parent_id,
                node_id,
                **_edge_attrs(
                    _clean(node.get("reason")) or "pivot",
                    confidence=0.72,
                    provenance={"reason": node.get("reason"), "depth": node.get("depth")},
                ),
            )
        elif node_id != seed_id:
            graph.add_edge(
                seed_id,
                node_id,
                **_edge_attrs("investigates", confidence=0.75, provenance={"reason": "seed"}),
            )

    result_ids: dict[str, str] = {}
    for index, result in enumerate(payload.get("search_results") or []):
        if not isinstance(result, dict):
            continue
        result_node_id = _result_id(result, index)
        result_key = _clean(result.get("id") or f"result-{index}")
        result_ids[result_key] = result_node_id
        label = _clean(result.get("title") or result.get("matched_entity") or result.get("url") or result_key)
        result_type = _clean(result.get("entity_type")).lower() or "result"
        graph.add_node(
            result_node_id,
            type=result_type,
            value=label[:120],
            source_id=result.get("source_id"),
            url=result.get("url"),
        )
        autopivot = result.get("autopivot") if isinstance(result.get("autopivot"), dict) else {}
        via = _clean(autopivot.get("via") or result.get("matched_entity") or seed_value)
        via_id = node_ids_by_value.get(via.lower()) or seed_id
        refs = _evidence_refs(result)
        graph.add_edge(
            via_id,
            result_node_id,
            **_edge_attrs(
                "found_result",
                confidence=_confidence(result.get("confidence_score"), 0.55),
                evidence_refs=refs,
                provenance={
                    "source_id": result.get("source_id"),
                    "source_name": result.get("source_name"),
                    "url": result.get("url"),
                    "autopivot": autopivot,
                },
            ),
        )

    for identity in payload.get("identities") or []:
        if not isinstance(identity, dict):
            continue
        identity_key = _clean(identity.get("key") or identity.get("label"))
        if not identity_key:
            continue
        identity_id = _safe_id("identity", identity_key)
        graph.add_node(
            identity_id,
            type="identity",
            value=_clean(identity.get("label") or identity_key),
            status=identity.get("status"),
        )
        for result_key in identity.get("result_ids") or []:
            result_node_id = result_ids.get(_clean(result_key))
            if not result_node_id:
                continue
            graph.add_edge(
                identity_id,
                result_node_id,
                **_edge_attrs(
                    "resolved_from",
                    confidence=_confidence(identity.get("confidence"), 0.6),
                    provenance={
                        "status": identity.get("status"),
                        "source_count": identity.get("source_count"),
                    },
                ),
            )

    for correlation in payload.get("correlations") or []:
        if not isinstance(correlation, dict):
            continue
        kind = _clean(correlation.get("kind")) or "correlation"
        key = _clean(correlation.get("key")) or kind
        correlation_id = _safe_id("correlation", f"{kind}:{key}")
        graph.add_node(correlation_id, type="correlation", value=f"{kind}: {key}")
        confidence = _confidence(correlation.get("confidence"), 0.6)
        for result_key in correlation.get("member_ids") or []:
            result_node_id = result_ids.get(_clean(result_key))
            if not result_node_id:
                continue
            graph.add_edge(
                correlation_id,
                result_node_id,
                **_edge_attrs(
                    kind,
                    confidence=confidence,
                    provenance={
                        "sources": correlation.get("sources") or [],
                        "explanation": correlation.get("explanation") or "",
                    },
                ),
            )

    return graph


def investigation_graph_cytoscape(payload: dict[str, Any]) -> dict[str, Any]:
    graph = build_investigation_graph(payload)
    data = to_cytoscape(graph)
    data["metrics"] = graph_metrics(graph)
    data["seed"] = payload.get("seed") or {}
    return data


def investigation_graph_html(payload: dict[str, Any]) -> str:
    graph = build_investigation_graph(payload)
    graph_html = render_graph_html(graph)
    metrics = graph_metrics(graph)
    seed = payload.get("seed") if isinstance(payload.get("seed"), dict) else {}
    title = f"{_clean(seed.get('entity_type')) or 'target'}: {_clean(seed.get('value')) or 'unknown'}"
    cytoscape_json = json.dumps(investigation_graph_cytoscape(payload), ensure_ascii=False, default=str)
    cytoscape_json = cytoscape_json.replace("</", "<\\/")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Investigation graph</title>
<style>
body {{ margin: 0; background: #0d1117; color: #e6edf3; font: 14px/1.5 system-ui, -apple-system, Segoe UI, sans-serif; }}
main {{ max-width: 1180px; margin: 0 auto; padding: 24px; }}
h1 {{ margin: 0 0 6px; font-size: 24px; }}
.muted {{ color: #8b949e; }}
.metrics {{ display: flex; gap: 10px; flex-wrap: wrap; margin: 16px 0; }}
.metric {{ border: 1px solid #30363d; border-radius: 8px; padding: 8px 12px; background: #161b22; }}
.graph-frame {{ border: 1px solid #30363d; border-radius: 8px; overflow: hidden; background: #0d1117; }}
.empty {{ padding: 24px; color: #8b949e; }}
</style>
</head>
<body>
<main>
  <h1>Investigation graph</h1>
  <div class="muted">{escape(title)}</div>
  <div class="metrics">
    <div class="metric">Nodes: {metrics["nodes"]}</div>
    <div class="metric">Edges: {metrics["edges"]}</div>
    <div class="metric">Strong edges: {metrics["strong_edges"]}</div>
    <div class="metric">Average weight: {metrics["average_weight"]}</div>
  </div>
  <section class="graph-frame">{graph_html}</section>
  <script type="application/json" id="investigation-graph-data">{cytoscape_json}</script>
</main>
</body>
</html>"""
