from __future__ import annotations

try:
    from pyvis.network import Network

    _HAS_PYVIS = True
except Exception:
    _HAS_PYVIS = False

_COLORS = {
    "username": "#58a6ff",
    "profile": "#3fb950",
    "url": "#8b949e",
    "email": "#d29922",
    "domain": "#bc8cff",
    "image": "#f778ba",
    "document": "#56d4dd",
    "wallet": "#f0883e",
    "phone": "#a5d6ff",
    "ip": "#ff7b72",
    "company": "#e3b341",
}


def render_graph_html(graph) -> str:
    if not _HAS_PYVIS or graph.number_of_nodes() == 0:
        return (
            '<div class="empty">Interactive graph unavailable '
            "(install pyvis, or no relations were found).</div>"
        )

    net = Network(
        height="520px",
        width="100%",
        bgcolor="#0d1117",
        font_color="#e6edf3",
        directed=True,
        notebook=False,
        cdn_resources="remote",
    )
    net.barnes_hut(gravity=-8000, spring_length=160)
    for node, data in graph.nodes(data=True):
        entity_type = data.get("type", "")
        value = data.get("value", node)
        net.add_node(
            node,
            label=str(value)[:28],
            title=f"{entity_type}: {value}",
            color=_COLORS.get(entity_type, "#8b949e"),
            shape="dot",
            size=18,
        )
    for src, dst, data in graph.edges(data=True):
        net.add_edge(
            src,
            dst,
            title=data.get("rel", ""),
            label=data.get("rel", ""),
            color="#30363d",
            arrows="to",
        )

    full = net.generate_html(notebook=False)
    start = full.find("<body>")
    end = full.find("</body>")
    if start != -1 and end != -1:
        return full[start + 6 : end]
    return full
