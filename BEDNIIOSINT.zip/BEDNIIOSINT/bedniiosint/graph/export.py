from __future__ import annotations

from html import escape
import json
from pathlib import Path

from .builder import new_graph


def to_cytoscape(graph) -> dict:
    nodes = [
        {
            "data": {
                "id": node,
                "label": data.get("value", node),
                "type": data.get("type", ""),
            }
        }
        for node, data in graph.nodes(data=True)
    ]
    edges = [
        {
            "data": {
                "source": src,
                "target": dst,
                "label": data.get("rel", ""),
                "weight": data.get("weight", 0.0),
                "confidence": data.get("confidence", 0.0),
                "evidence_count": data.get("evidence_count", 0),
                "evidence_refs": data.get("evidence_refs", []),
                "relation_id": data.get("relation_id"),
                "case_id": data.get("case_id"),
                "provenance": data.get("provenance", {}),
            }
        }
        for src, dst, data in graph.edges(data=True)
    ]
    return {"elements": {"nodes": nodes, "edges": edges}}


def write_graph_json(graph, out: Path) -> Path:
    out.write_text(json.dumps(to_cytoscape(graph), indent=2), encoding="utf-8")
    return out


def graph_from_cytoscape_elements(elements: dict) -> object:
    graph = new_graph()
    for row in elements.get("nodes") or []:
        data = row.get("data") if isinstance(row, dict) else {}
        node_id = str(data.get("id") or "")
        if not node_id:
            continue
        graph.add_node(
            node_id,
            type=str(data.get("type") or ""),
            value=str(data.get("label") or node_id),
        )
    for row in elements.get("edges") or []:
        data = row.get("data") if isinstance(row, dict) else {}
        source = str(data.get("source") or "")
        target = str(data.get("target") or "")
        if not source or not target:
            continue
        confidence = float(data.get("confidence") or 0.0)
        evidence_count = int(data.get("evidence_count") or 0)
        graph.add_edge(
            source,
            target,
            rel=str(data.get("label") or ""),
            weight=max(0.1, min(1.0, 0.35 + confidence * 0.4 + min(0.25, evidence_count * 0.05))),
            confidence=confidence,
            evidence_count=evidence_count,
            evidence_refs=list(data.get("evidence_refs") or []),
            provenance={
                "source_id": data.get("source_id") or "",
                "evidence_count": evidence_count,
                "evidence_refs": list(data.get("evidence_refs") or []),
                "display_graph": True,
            },
        )
    return graph


def to_graphml(graph) -> str:
    nodes = list(graph.nodes(data=True))
    edges = list(graph.edges(data=True))
    node_xml = "\n".join(
        f'    <node id="{escape(str(node), quote=True)}">'
        f'<data key="type">{escape(str(data.get("type", "")))}</data>'
        f'<data key="value">{escape(str(data.get("value", "")))}</data></node>'
        for node, data in nodes
    )
    edge_xml = "\n".join(
        f'    <edge source="{escape(str(src), quote=True)}" '
        f'target="{escape(str(dst), quote=True)}">'
        f'<data key="rel">{escape(str(data.get("rel", "")))}</data>'
        f'<data key="weight">{escape(str(data.get("weight", 0.0)))}</data>'
        f'<data key="confidence">{escape(str(data.get("confidence", 0.0)))}</data>'
        f'<data key="provenance">{escape(json.dumps(data.get("provenance", {}), sort_keys=True))}</data></edge>'
        for src, dst, data in edges
    )
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<graphml xmlns="http://graphml.graphdrawing.org/xmlns">
  <key id="type" for="node" attr.name="type" attr.type="string"/>
  <key id="value" for="node" attr.name="value" attr.type="string"/>
  <key id="rel" for="edge" attr.name="rel" attr.type="string"/>
  <key id="weight" for="edge" attr.name="weight" attr.type="double"/>
  <key id="confidence" for="edge" attr.name="confidence" attr.type="double"/>
  <key id="provenance" for="edge" attr.name="provenance" attr.type="string"/>
  <graph edgedefault="directed">
{node_xml}
{edge_xml}
  </graph>
</graphml>
'''


def to_gexf(graph) -> str:
    nodes = list(graph.nodes(data=True))
    edges = list(graph.edges(data=True))
    node_xml = "\n".join(
        f'      <node id="{escape(str(node), quote=True)}" '
        f'label="{escape(str(data.get("value", node)), quote=True)}">'
        f'<attvalues><attvalue for="type" value="{escape(str(data.get("type", "")), quote=True)}"/>'
        f'</attvalues></node>'
        for node, data in nodes
    )
    edge_xml = "\n".join(
        f'      <edge id="{idx}" source="{escape(str(src), quote=True)}" '
        f'target="{escape(str(dst), quote=True)}" '
        f'label="{escape(str(data.get("rel", "")), quote=True)}" '
        f'weight="{escape(str(data.get("weight", 0.0)), quote=True)}">'
        f'<attvalues><attvalue for="confidence" value="{escape(str(data.get("confidence", 0.0)), quote=True)}"/>'
        f'<attvalue for="provenance" value="{escape(json.dumps(data.get("provenance", {}), sort_keys=True), quote=True)}"/>'
        f'</attvalues></edge>'
        for idx, (src, dst, data) in enumerate(edges)
    )
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<gexf xmlns="http://www.gexf.net/1.2draft" version="1.2">
  <graph mode="static" defaultedgetype="directed">
    <attributes class="node">
      <attribute id="type" title="type" type="string"/>
    </attributes>
    <attributes class="edge">
      <attribute id="confidence" title="confidence" type="double"/>
      <attribute id="provenance" title="provenance" type="string"/>
    </attributes>
    <nodes>
{node_xml}
    </nodes>
    <edges>
{edge_xml}
    </edges>
  </graph>
</gexf>
'''


def write_graphml(graph, out: Path) -> Path:
    out.write_text(to_graphml(graph), encoding="utf-8")
    return out


def write_gexf(graph, out: Path) -> Path:
    out.write_text(to_gexf(graph), encoding="utf-8")
    return out
