@echo off
setlocal
cd /d "%~dp0"
title BEDNIIOSINT Clear

set "CLEAR_SCRIPT=%~dp0scripts\clear_windows.ps1"
if not exist "%CLEAR_SCRIPT%" (
    echo BEDNIIOSINT clear file is missing:
    echo %CLEAR_SCRIPT%
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%CLEAR_SCRIPT%" %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
    echo.
    echo BEDNIIOSINT cleanup did not finish. See the message above.
    pause
)
exit /b %EXIT_CODE%
