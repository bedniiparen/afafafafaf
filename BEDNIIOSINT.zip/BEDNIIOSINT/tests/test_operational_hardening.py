from __future__ import annotations

from pathlib import Path

import httpx


ROOT = Path(__file__).resolve().parents[1]


def test_windows_one_click_launcher_bootstraps_python_and_dashboard():
    start_bat = ROOT / "start.bat"
    bootstrap = ROOT / "scripts" / "bootstrap_windows.ps1"
    start_py = ROOT / "scripts" / "start.py"
    verify_py = ROOT / "scripts" / "verify_launchers.py"

    assert start_bat.exists()
    assert not (ROOT / ("start" + ".cmd")).exists()
    assert sorted(path.name for path in ROOT.glob("*.bat")) == ["clear.bat", "start.bat"]
    assert sorted(path.name for path in ROOT.iterdir() if path.is_file()) == ["clear.bat", "start.bat"]
    assert [path.name for path in ROOT.glob("start.*") if path.suffix.lower() in {".bat", ".cmd"}] == ["start.bat"]
    assert bootstrap.exists()

    bat_text = start_bat.read_text(encoding="utf-8").lower()
    bootstrap_text = bootstrap.read_text(encoding="utf-8")
    start_text = start_py.read_text(encoding="utf-8")

    assert "bootstrap_windows.ps1" in bat_text
    assert "%*" in bat_text
    assert "powershell.exe" in bat_text
    assert "ValueFromRemainingArguments" in bootstrap_text
    assert "@StartArgs" in bootstrap_text
    assert "Python.Python.3.12" in bootstrap_text
    assert "winget" in bootstrap_text
    assert "scripts\\start.py" in bootstrap_text
    assert "MINIMAL_PACKAGES" in start_text
    assert "_ensure_dependencies" in start_text
    assert 'ROOT / "runtime" / ".venv"' in start_text
    assert 'ROOT / "requirements" / "base.txt"' in start_text
    assert '"--check"' in start_text
    assert '"--no-install"' in start_text
    assert "Installing required dashboard dependencies" in start_text
    assert '"fastapi"' in start_text
    assert '"uvicorn"' in start_text
    assert '"sqlmodel"' in start_text
    assert "Full dependency install failed" in start_text
    assert verify_py.exists()
    verify_text = verify_py.read_text(encoding="utf-8")
    assert "check_isolated_clear" in verify_text
    assert "clear_windows.ps1" in verify_text
    assert "start.py\", \"--check\", \"--no-install\"" in verify_text


def test_windows_clear_launcher_removes_only_local_runtime_artifacts():
    clear_bat = ROOT / "clear.bat"
    clear_script = ROOT / "scripts" / "clear_windows.ps1"

    assert clear_bat.exists()
    assert clear_script.exists()

    bat_text = clear_bat.read_text(encoding="utf-8").lower()
    script_text = clear_script.read_text(encoding="utf-8")

    assert "clear_windows.ps1" in bat_text
    assert "powershell.exe" in bat_text
    assert "Type CLEAR to continue" not in script_text
    assert "Read-Host" not in script_text
    assert "non-interactive" in script_text
    assert "Test-InsideRoot" in script_text
    assert '"cases"' in script_text
    assert '"reports_out"' in script_text
    assert '"runtime\\cases"' in script_text
    assert '"runtime\\reports_out"' in script_text
    assert '"runtime\\.venv"' in script_text
    assert '".venv"' in script_text
    assert '".env"' in script_text
    assert "config\\env.example" in script_text
    assert "Remove-Item -LiteralPath $Path -Recurse -Force" in script_text
    assert "Kept: source code, docs, data catalogs" in script_text


def test_project_root_exposes_only_two_clickable_batch_files():
    files = sorted(path.name for path in ROOT.iterdir() if path.is_file())
    assert files == ["clear.bat", "start.bat"]
    assert (ROOT / "requirements" / "base.txt").exists()
    assert (ROOT / "config" / "env.example").exists()
    assert (ROOT / "infra" / "docker" / "Dockerfile").exists()
    assert (ROOT / "docs" / "project" / "README.md").exists()


def test_settings_read_env_overrides(monkeypatch, tmp_path):
    from bedniiosint.config import Settings

    monkeypatch.setenv("BEDNIIOSINT_TIMEOUT", "3.5")
    monkeypatch.setenv("BEDNIIOSINT_MAX_CONCURRENCY", "7")
    monkeypatch.setenv("BEDNIIOSINT_DB_DIR", str(tmp_path))
    monkeypatch.setenv("BEDNIIOSINT_PROXY_POOL", "http://one.test, http://two.test")
    monkeypatch.setenv("BEDNIIOSINT_CACHE_ENABLED", "false")

    settings = Settings()

    assert settings.timeout == 3.5
    assert settings.max_concurrency == 7
    assert settings.db_dir == tmp_path
    assert settings.proxy_pool == ("http://one.test", "http://two.test")
    assert settings.cache_enabled is False


def test_sqlite_connection_enables_operational_pragmas(tmp_path):
    from bedniiosint.storage.sqlite import Storage

    storage = Storage(tmp_path / "case.db")

    with storage.session() as session:
        assert session.conn.execute("PRAGMA busy_timeout").fetchone()[0] == 5000
        assert session.conn.execute("PRAGMA foreign_keys").fetchone()[0] == 1
        assert session.conn.execute("PRAGMA temp_store").fetchone()[0] == 2


def test_matching_and_username_permutations_are_deterministic():
    from bedniiosint.core.matching import dedupe, jaro_winkler, same_entity
    from bedniiosint.search.permutations import name_permutations, username_variants

    assert jaro_winkler("Alice Smith", "alice  smith") == 1.0
    assert same_entity("alice smith", "alice smyth", threshold=0.9)
    assert dedupe(["alice smith", "Alice  Smith", "bob"]) == [
        ["alice smith", "Alice  Smith"],
        ["bob"],
    ]

    variants = name_permutations("Ivan", "Petrov", years=(1990,), include_leet=True)
    assert "ivan.petrov" in variants
    assert "ipetrov" in variants
    assert "ivanpetrov90" in variants
    assert username_variants("\u0438\u0432\u0430\u043d.\u043f\u0435\u0442\u0440\u043e\u0432")[0]


def test_http_get_uses_cache_control_for_repeat_requests(monkeypatch, tmp_path):
    from bedniiosint.core import http as http_mod
    from bedniiosint.core.netpolicy import ResponseCache, response_cache
    from bedniiosint.config import settings

    calls = {"count": 0}
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    response_cache.clear()

    class FakeClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def request(self, method, url, **kwargs):
            calls["count"] += 1
            return httpx.Response(
                200,
                headers={"Cache-Control": "max-age=60"},
                content=f"call-{calls['count']}".encode(),
                request=httpx.Request(method, url),
            )

        def close(self):
            pass

    monkeypatch.setattr(http_mod.httpx, "Client", FakeClient)

    try:
        first = http_mod.request("GET", "https://example.test/data")
        second = http_mod.request("GET", "https://example.test/data")

        assert first.text == "call-1"
        assert second.text == "call-1"
        assert second.extensions["bedniiosint_cache_hit"] is True
        assert calls["count"] == 1
        assert (tmp_path / "_http_cache.sqlite").exists()
        cache_key = response_cache.key(
            "GET",
            "https://example.test/data",
            params={"params": None, "json": None, "data": None, "content": None},
        )
        persisted = ResponseCache().get(cache_key)
        assert persisted["content"] == b"call-1"
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_prometheus_metrics_render_labels():
    from bedniiosint.monitoring.metrics import Metrics

    metrics = Metrics()
    metrics.inc("source_success_total", source="api:rdap")
    metrics.observe("source_run_seconds", 0.25)

    rendered = metrics.render_prometheus()

    assert 'source_success_total{source="api:rdap"} 1.0' in rendered
    assert "source_run_seconds_count 1" in rendered
    assert "source_run_seconds_sum 0.25" in rendered
