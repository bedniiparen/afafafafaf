import os

import pytest

from bedniiosint.reports.cti_sync import (
    preflight_misp,
    preflight_opencti,
    sync_misp,
    sync_opencti,
)


def _live_enabled() -> bool:
    return os.getenv("BEDNIIOSINT_CTI_LIVE_TESTS", "").strip() == "1"


def _send_enabled() -> bool:
    return os.getenv("BEDNIIOSINT_CTI_LIVE_SEND", "").strip() == "1"


def _cleanup_enabled() -> bool:
    return os.getenv("BEDNIIOSINT_CTI_LIVE_CLEANUP", "").strip() == "1"


def _opencti_patch_config() -> tuple[dict[str, str] | None, str]:
    if os.getenv("BEDNIIOSINT_CTI_LIVE_PATCH", "").strip() != "1":
        return None, ""
    mutation = os.getenv("OPENCTI_PATCH_MUTATION", "").strip()
    field = os.getenv("OPENCTI_PATCH_FIELD", "").strip()
    if "=" not in field:
        pytest.skip("set OPENCTI_PATCH_FIELD=key=value for live OpenCTI patch")
    key, value = field.split("=", 1)
    key = key.strip()
    if not key:
        pytest.skip("OPENCTI_PATCH_FIELD key must not be empty")
    return {key: value}, mutation


def _opencti_patch_map() -> dict[str, str] | None:
    raw = os.getenv("OPENCTI_PATCH_MAP", "").strip()
    if not raw:
        return None
    if "=" not in raw:
        pytest.skip("OPENCTI_PATCH_MAP must be entity_type=mutation")
    entity_type, mutation = raw.split("=", 1)
    entity_type = entity_type.strip()
    mutation = mutation.strip()
    if not entity_type or not mutation:
        pytest.skip("OPENCTI_PATCH_MAP must be entity_type=mutation")
    return {entity_type: mutation}


def _skip_unless_live() -> None:
    if not _live_enabled():
        pytest.skip("set BEDNIIOSINT_CTI_LIVE_TESTS=1 to run live CTI checks")


def _sample_summary() -> dict:
    return {
        "meta": {"case": "bedniiosint-live-cti-check", "found": True},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [
            {
                "id": 1,
                "entity_type": "domain",
                "entity_value": "example.com",
                "source_name": "bedniiosint-live-check",
                "source_id": "test:cti-live",
                "status": "exists",
                "confidence": 0.1,
                "profile_url": "https://example.com/",
            }
        ],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }


def test_live_opencti_preflight_when_configured():
    _skip_unless_live()
    url = os.getenv("OPENCTI_URL", "").strip()
    if not url or not os.getenv("OPENCTI_TOKEN", "").strip():
        pytest.skip("set OPENCTI_URL and OPENCTI_TOKEN for OpenCTI live preflight")

    result = preflight_opencti(url=url)

    assert result.status == "ok", result.as_dict()
    assert result.status_code is not None and result.status_code < 400


def test_live_misp_preflight_when_configured():
    _skip_unless_live()
    url = os.getenv("MISP_URL", "").strip()
    if not url or not os.getenv("MISP_API_KEY", "").strip():
        pytest.skip("set MISP_URL and MISP_API_KEY for MISP live preflight")

    result = preflight_misp(url=url)

    assert result.status == "ok", result.as_dict()
    assert result.status_code is not None and result.status_code < 400


def test_live_opencti_send_when_explicitly_enabled():
    _skip_unless_live()
    if not _send_enabled():
        pytest.skip("set BEDNIIOSINT_CTI_LIVE_SEND=1 to POST live CTI payloads")
    url = os.getenv("OPENCTI_SYNC_URL", "").strip()
    if not url or not os.getenv("OPENCTI_TOKEN", "").strip():
        pytest.skip("set OPENCTI_SYNC_URL and OPENCTI_TOKEN for OpenCTI live send")

    read_back = os.getenv("BEDNIIOSINT_CTI_LIVE_READ_BACK", "").strip() == "1"
    patch_fields, patch_mutation = _opencti_patch_config()
    result = sync_opencti(
        _sample_summary(),
        url=url,
        dry_run=False,
        read_back=read_back,
        delete_after=_cleanup_enabled() if read_back else False,
        patch_fields=patch_fields,
        patch_mutation=patch_mutation,
        patch_mutation_map=_opencti_patch_map(),
    )

    assert result.status == "ok", result.as_dict()
    assert result.status_code is not None and result.status_code < 400
    if result.remote_id and read_back:
        assert any(row["action"] == "read_back" for row in result.lifecycle)
    if result.remote_id and patch_fields:
        assert any(row["action"] == "field_patch" for row in result.lifecycle)


def test_live_misp_send_when_explicitly_enabled():
    _skip_unless_live()
    if not _send_enabled():
        pytest.skip("set BEDNIIOSINT_CTI_LIVE_SEND=1 to POST live CTI payloads")
    url = os.getenv("MISP_URL", "").strip()
    if not url or not os.getenv("MISP_API_KEY", "").strip():
        pytest.skip("set MISP_URL and MISP_API_KEY for MISP live send")

    result = sync_misp(
        _sample_summary(),
        url=url,
        dry_run=False,
        read_back=True,
        delete_after=_cleanup_enabled(),
    )

    assert result.status == "ok", result.as_dict()
    assert result.status_code is not None and result.status_code < 400
    if result.remote_id:
        assert any(row["action"] == "read_back" for row in result.lifecycle)
