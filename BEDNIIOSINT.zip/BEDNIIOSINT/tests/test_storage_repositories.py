from __future__ import annotations

from pathlib import Path

from bedniiosint.core.case_lookup import case_ids, case_rows
from bedniiosint.storage.models import Case, Evidence, Finding
from bedniiosint.storage.repositories import CaseRepository, ModelRepository
from bedniiosint.storage.sqlite import Storage


def test_case_repository_reads_legacy_storage_rows(tmp_path: Path):
    storage = Storage(tmp_path / "case.db")
    with storage.session() as session:
        first = Case(name="repo-case", target="alice", module="username")
        second = Case(name="repo-case", target="alice@example.com", module="email")
        session.add(first)
        session.add(second)
        session.commit()

    repo = CaseRepository(storage.db_path)
    rows = repo.list_by_name("repo-case")

    assert [row.module for row in rows] == ["username", "email"]
    assert all(row.created_at.tzinfo is not None for row in rows)
    assert repo.ids_by_name("repo-case") == case_ids(storage, "repo-case")
    assert [row.target for row in case_rows(storage, "repo-case")] == ["alice", "alice@example.com"]


def test_case_repository_writes_rows_readable_by_legacy_session(tmp_path: Path):
    storage = Storage(tmp_path / "case.db")
    repo = CaseRepository(storage.db_path)

    row = repo.add(Case(name="repo-write", target="example.com", module="domain"))

    assert row.id is not None
    with storage.session() as session:
        legacy = session.query(Case).filter(Case.name == "repo-write").first()

    assert legacy is not None
    assert legacy.id == row.id
    assert legacy.target == "example.com"


def test_model_repository_reads_case_scoped_legacy_rows(tmp_path: Path):
    storage = Storage(tmp_path / "case.db")
    with storage.session() as session:
        first_case = Case(name="repo-case-a", target="alice", module="username")
        second_case = Case(name="repo-case-b", target="example.com", module="domain")
        session.add(first_case)
        session.add(second_case)
        session.commit()

        first = Finding(
            case_id=first_case.id,
            source_name="source-a",
            source_id="api:a",
            entity_value="alice",
            entity_type="username",
            profile_url="https://example.test/alice",
            status="exists",
            confidence=0.9,
        )
        second = Finding(
            case_id=second_case.id,
            source_name="source-b",
            source_id="api:b",
            entity_value="example.com",
            entity_type="domain",
            profile_url="https://example.test/domain",
            status="exists",
            confidence=0.8,
        )
        session.add(first)
        session.add(second)
        session.commit()

        session.add(
            Evidence(
                case_id=first_case.id,
                finding_id=first.id,
                url="https://example.test/alice",
                final_url="https://example.test/alice",
                sha256="a" * 64,
            )
        )
        session.commit()

    finding_repo = ModelRepository(storage.db_path, Finding)
    evidence_repo = ModelRepository(storage.db_path, Evidence)

    findings = finding_repo.list_by_values("case_id", [second_case.id, first_case.id])
    evidence = evidence_repo.list_by_values("case_id", [first_case.id])

    assert [row.entity_value for row in findings] == ["alice", "example.com"]
    assert evidence[0].sha256 == "a" * 64
    assert finding_repo.list_by_values("case_id", []) == []


def test_model_repository_update_delete_and_count_round_trip(tmp_path: Path):
    storage = Storage(tmp_path / "case.db")
    repo = CaseRepository(storage.db_path)

    row = repo.add(Case(name="mutable", target="alice", module="username"))
    assert row.id is not None
    assert repo.count_by(name="mutable") == 1
    assert repo.get(row.id).target == "alice"

    row.target = "alice@example.com"
    row.module = "email"
    repo.update(row)

    updated = repo.get(row.id)
    assert updated is not None
    assert updated.target == "alice@example.com"
    assert updated.module == "email"
    with storage.session() as session:
        legacy = session.query(Case).filter(Case.name == "mutable").first()
    assert legacy.target == "alice@example.com"

    assert repo.delete(row) is True
    assert repo.get(row.id) is None
    assert repo.count_by(name="mutable") == 0
