from __future__ import annotations


def test_infrastructure_connectors_registered_and_have_settings():
    from bedniiosint.config import settings
    from bedniiosint.search.connectors import CONNECTOR_CLASSES

    assert {"urlscan", "greynoise", "securitytrails", "virustotal"} <= set(CONNECTOR_CLASSES)
    assert hasattr(settings, "urlscan_api_key")
    assert hasattr(settings, "greynoise_api_key")
    assert hasattr(settings, "securitytrails_api_key")
    assert hasattr(settings, "virustotal_api_key")


def test_urlscan_parse_normalize_sample():
    from bedniiosint.search.connectors.urlscan import UrlscanConnector

    connector = UrlscanConnector()
    raw = {
        "status": "ok",
        "data": {
            "results": [
                {
                    "_id": "scan-id",
                    "result": "https://urlscan.io/result/scan-id/",
                    "page": {
                        "url": "https://example.com/login",
                        "domain": "example.com",
                        "ip": "93.184.216.34",
                        "country": "US",
                    },
                    "task": {"time": "2026-06-01T00:00:00.000Z"},
                }
            ]
        },
    }

    rows = connector.normalize(connector.parse(raw))

    assert len(rows) == 1
    assert rows[0].source_id == "urlscan"
    assert rows[0].matched_entity == "example.com"
    assert rows[0].last_seen == "2026-06-01T00:00:00.000Z"


def test_greynoise_parse_normalize_sample():
    from bedniiosint.search.connectors.greynoise import GreyNoiseConnector

    connector = GreyNoiseConnector()
    raw = {
        "status": "ok",
        "data": {
            "ip": "8.8.8.8",
            "classification": "benign",
            "noise": True,
            "riot": True,
            "name": "Google Public DNS",
            "last_seen": "2026-06-01",
        },
    }

    rows = connector.normalize(connector.parse(raw))

    assert len(rows) == 1
    assert rows[0].source_id == "greynoise"
    assert rows[0].matched_entity == "8.8.8.8"
    assert "background_noise" in rows[0].risk_flags


def test_securitytrails_missing_key_and_normalize_sample(monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.search.connectors.securitytrails import SecurityTrailsConnector

    connector = SecurityTrailsConnector()
    plan = connector.build_queries({"type": "domain", "value": "example.com"})
    original = settings.securitytrails_api_key
    object.__setattr__(settings, "securitytrails_api_key", "")
    try:
        assert connector.run(plan)["status"] == "missing_keys"
    finally:
        object.__setattr__(settings, "securitytrails_api_key", original)

    raw = {"status": "ok", "apex": "example.com", "data": {"subdomains": ["www", "api"]}}
    rows = connector.normalize(connector.parse(raw))

    assert [row.matched_entity for row in rows] == ["www.example.com", "api.example.com"]
    assert all(row.source_id == "securitytrails" for row in rows)


def test_virustotal_missing_key_and_normalize_sample(monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.search.connectors.virustotal import VirusTotalConnector

    connector = VirusTotalConnector()
    plan = connector.build_queries({"type": "domain", "value": "example.com"})
    original = settings.virustotal_api_key
    object.__setattr__(settings, "virustotal_api_key", "")
    try:
        assert connector.run(plan)["status"] == "missing_keys"
    finally:
        object.__setattr__(settings, "virustotal_api_key", original)

    raw = {
        "status": "ok",
        "entity_type": "domain",
        "indicator": "example.com",
        "data": {
            "data": {
                "id": "example.com",
                "attributes": {
                    "last_analysis_stats": {"malicious": 1, "suspicious": 2},
                    "reputation": -10,
                },
            }
        },
    }
    rows = connector.normalize(connector.parse(raw))

    assert len(rows) == 1
    assert rows[0].source_id == "virustotal"
    assert rows[0].matched_entity == "example.com"
    assert {"vt_malicious", "vt_suspicious"} <= set(rows[0].risk_flags)
