from bedniiosint.graph.builder import new_graph
from bedniiosint.graph.export import to_cytoscape
from bedniiosint.modules.email.analyzer import analyze_email
from bedniiosint.modules.email.gravatar import gravatar_hashes
from bedniiosint.modules.url.extract_links import (
    classify_social_links,
    extract_emails,
    extract_outbound_links,
    extract_wallets,
)
from bedniiosint.modules.url.profile_parser import parse_profile


def test_social_link_classification():
    links = ["https://github.com/bob", "https://x.com/bob", "https://nope.com/x"]
    result = classify_social_links(links)
    assert "github" in result and "twitter" in result and "nope" not in str(result)


def test_email_extraction():
    assert "a@b.com" in extract_emails("contact A@B.COM please")


def test_wallet_extraction():
    eth = "0x" + "a" * 40
    assert eth in extract_wallets(f"send to {eth}")["eth"]


def test_outbound_links_excludes_same_host():
    html = '<a href="https://other.com/x">x</a><a href="/internal">y</a>'
    links = extract_outbound_links(html, "https://base.com/")
    assert "https://other.com/x" in links
    assert all("base.com" not in link for link in links)


def test_profile_parser_meta():
    html = (
        "<html><head><title>Bob</title>"
        '<meta property="og:description" content="hi"/>'
        '<meta property="og:image" content="/a.png"/></head>'
        '<body><a href="https://github.com/bob">gh</a></body></html>'
    )
    profile = parse_profile(html, "https://x.com/bob")
    assert profile.title == "Bob" and profile.description == "hi"
    assert profile.avatar_url.endswith("/a.png")
    assert "github" in profile.social_links


def test_gravatar_hash_is_normalized():
    a = gravatar_hashes("  USER@Example.COM ")["md5"]
    b = gravatar_hashes("user@example.com")["md5"]
    assert a == b and len(a) == 32


def test_email_invalid_format():
    result = analyze_email("not-an-email")
    assert not result.valid_format and result.confidence == 0.0


def test_graph_cytoscape_export():
    graph = new_graph()
    graph.add_node("username:bob", type="username", value="bob")
    graph.add_node("profile:url", type="profile", value="url")
    graph.add_edge("username:bob", "profile:url", rel="same_username")
    cytoscape = to_cytoscape(graph)
    assert len(cytoscape["elements"]["nodes"]) == 2
    assert cytoscape["elements"]["edges"][0]["data"]["label"] == "same_username"
