from __future__ import annotations

import json

from bedniiosint.core.notifications import notify_monitor_alert


def test_monitor_alert_notification_writes_jsonl_and_skips_unconfigured_webhook(tmp_path, monkeypatch):
    monkeypatch.delenv("BEDNIIOSINT_MONITOR_WEBHOOK_URL", raising=False)
    path = tmp_path / "notifications.jsonl"
    alert = {
        "target": "bob",
        "current_case": "monitor-bob",
        "message": "changed https://example.test/?token=secret",
    }

    result = notify_monitor_alert(alert, notifications_path=path)
    lines = path.read_text(encoding="utf-8").splitlines()
    payload = json.loads(lines[0])

    assert result["delivered"] == 1
    assert result["channels"][0]["type"] == "jsonl"
    assert result["channels"][1]["status"] == "not_configured"
    assert payload["message"] == "changed https://example.test/?token=%5Bredacted%5D"


def test_monitor_alert_notification_posts_configured_webhook(tmp_path, monkeypatch):
    calls = []

    class Response:
        status_code = 204

    def fake_post(url, **kwargs):
        calls.append((url, kwargs))
        return Response()

    monkeypatch.setattr("bedniiosint.core.notifications.httpx.post", fake_post)
    result = notify_monitor_alert(
        {"target": "bob", "message": "change"},
        notifications_path=tmp_path / "notifications.jsonl",
        webhook_url="https://hooks.example.test/monitor",
    )

    assert result["delivered"] == 2
    assert calls[0][0] == "https://hooks.example.test/monitor"
    assert calls[0][1]["json"]["target"] == "bob"
