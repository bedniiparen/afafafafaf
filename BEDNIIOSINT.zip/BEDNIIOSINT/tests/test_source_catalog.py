import json
import hashlib
import sqlite3
import warnings
from pathlib import Path

from bedniiosint.catalog import (
    adapter_for,
    adapter_health,
    api_key_status,
    catalog_summary,
    endpoint_index,
    fixture_coverage,
    filter_registry,
    iter_apis,
    load_catalog,
    registry_entries,
    registry_summary,
    run_source,
    source_health,
    source_health_summary,
    source_maintenance_report,
    source_quality_gate,
    api_key_env_template,
    api_key_setup_plan,
    write_api_key_env_template,
    verify_sources,
)
from bedniiosint.catalog.adapters import AdapterResult, CatalogResponseParser
from bedniiosint.catalog.policy import load_policy_catalog, policy_for_source, source_policy_context
from bedniiosint.catalog.parsers import parse_specialized
from bedniiosint.core.adapter_generator import scaffold_adapter
from bedniiosint.core.normalizer import normalize_adapter_result
from bedniiosint.core.live_plan import (
    live_account_validation_runbook,
    live_validation_plan,
    live_validation_runbook,
)
from bedniiosint.core.cache_policy import (
    merge_cache_ttl_presets,
    source_cache_ttl_presets,
)
from bedniiosint.core.source_context import SourceRunContext, parse_cache_ttl_by_source
from bedniiosint.core.plugins import (
    all_plugin_manifests,
    discover_plugin_manifests,
    set_plugin_config,
    set_plugin_enabled,
    sign_plugin_manifest,
    validate_plugin_manifest,
)
from bedniiosint.core.secret_store import (
    SECRET_KEY_ENV,
    apply_secret_store_setup,
    audit_secret_store,
    delete_secret,
    install_secret_store_systemd_dropin,
    list_secrets,
    rotate_secret_store,
    secret_value,
    secret_store_setup_template,
    store_secret,
    write_secret_store_setup_template,
)


FIXTURE_ROOT = Path(__file__).parent / "fixtures" / "sources"


def _source_fixture(source_id: str, name: str = "ok"):
    return json.loads((FIXTURE_ROOT / source_id / f"{name}.json").read_text(encoding="utf-8"))


def test_source_catalog_loads_and_summarizes():
    catalog = load_catalog()
    summary = catalog_summary(catalog)
    assert summary["api_sources"] >= 30
    assert summary["endpoints"] >= summary["api_sources"]
    assert "domain" in summary["inputs"]


def test_osint_policy_catalog_loads_priorities_and_rejects():
    policies = load_policy_catalog()
    shodan = policy_for_source("shodan")
    hibp = policy_for_source("hibp")
    urlhaus = policy_for_source("urlhaus")
    holehe = policy_for_source("holehe")

    assert len(policies) >= 70
    assert shodan is not None
    assert shodan.collection_mode == "passive_lookup"
    assert shodan.passive_only
    assert "passive_only" in shodan.labels
    assert hibp is not None
    assert hibp.sensitive_data
    assert "sensitive_data" in hibp.labels
    assert urlhaus is not None
    assert urlhaus.priority == "P0"
    assert urlhaus.tos_privacy_risk == "low"
    assert holehe is not None
    assert holehe.blocked
    assert "reject" in holehe.labels


def test_v25_source_policy_context_labels_unknown_passive_and_sensitive_sources():
    passive = source_policy_context(
        "module:domain_passive_tools",
        category="Domain intelligence",
        notes="passive external tools only",
    )
    sensitive = source_policy_context(
        "local_phone_lookup",
        category="Phone intelligence",
        notes="public phone enrichment",
    )

    assert passive["collection_mode"] == "passive_lookup"
    assert passive["sensitivity"] == "standard"
    assert "passive_only" in passive["policy_labels"]
    assert sensitive["sensitivity"] == "sensitive_data"
    assert "sensitive_data" in sensitive["policy_labels"]


def test_source_catalog_filters_domain_apis():
    apis = iter_apis(input_type="domain")
    ids = {api["id"] for api in apis}
    assert {"crtsh", "rdap", "shodan"} <= ids


def test_endpoint_index_contains_templates():
    endpoints = endpoint_index()
    urls = {row["url"] for row in endpoints}
    assert "https://crt.sh/?q=%25.{domain}&output=json" in urls


def test_source_registry_merges_modules_and_catalog():
    entries = registry_entries()
    ids = {entry.id for entry in entries}
    summary = registry_summary(entries)
    crtsh = next(entry for entry in entries if entry.id == "api:crtsh")
    twilio = next(entry for entry in entries if entry.id == "api:twilio_lookup")

    assert "module:username" in ids
    assert "module:domain_passive_tools" in ids
    assert "api:crtsh" in ids
    assert summary["modules"] >= 9
    assert summary["apis"] >= 30
    assert summary["runnable"] >= 9
    assert summary["typed_parsers"] >= 30
    assert summary["terms_risk"]["medium"] >= 1
    assert crtsh.adapter == "catalog-http"
    assert crtsh.source_maturity == "typed_parser"
    assert crtsh.terms_risk == "low"
    assert crtsh.cache_policy == "ttl_cache_allowed"
    assert crtsh.quota_policy == "public_rate_limited"
    assert twilio.terms_risk == "high"
    assert "domain" in crtsh.input_schema["input_types"]
    assert crtsh.output_schema["status"] == "ok|error|missing_keys"


def test_source_registry_filters_and_auth_hints(monkeypatch):
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)
    domain_sources = filter_registry(input_type="domain", runnable=True)
    ids = {entry.id for entry in domain_sources}
    shodan = next(entry for entry in registry_entries() if entry.id == "api:shodan")

    assert "module:domain" in ids
    assert "api:crtsh" in ids
    assert shodan.env_vars == ["SHODAN_API_KEY"]
    assert not shodan.configured


def test_v25_sources_cli_summary_uses_filtered_registry():
    from typer.testing import CliRunner

    from bedniiosint.cli import app

    api_count = registry_summary(filter_registry(kind="api"))["sources"]
    all_count = registry_summary()["sources"]
    result = CliRunner().invoke(app, ["sources", "--kind", "api", "--limit", "1"])

    assert result.exit_code == 0
    assert f"| {api_count} sources |" in result.output
    assert f"| {all_count} sources |" not in result.output


def test_v25_api_key_setup_plan_prioritizes_missing_p1_keyed_sources(monkeypatch):
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)
    monkeypatch.delenv("CENSYS_API_ID", raising=False)
    monkeypatch.delenv("CENSYS_API_SECRET", raising=False)

    plan = api_key_setup_plan(priorities=("P1",), missing_only=True)
    rows = {row["source_id"]: row for row in plan["sources"]}

    assert plan["summary"]["priorities"] == ["P1"]
    assert plan["summary"]["missing_sources"] >= 1
    assert "api:shodan" in rows
    assert "SHODAN_API_KEY" in rows["api:shodan"]["missing_env"]
    assert rows["api:shodan"]["safe_env_lines"] == ["SHODAN_API_KEY="]
    assert "api:censys" in rows
    assert {"CENSYS_API_ID", "CENSYS_API_SECRET"}.issubset(set(rows["api:censys"]["missing_env"]))
    assert "SHODAN_API_KEY=" in plan["safe_env_template"]
    assert "secret" not in plan["safe_env_template"].lower().replace("censys_api_secret", "")


def test_v06_api_key_status_and_source_health(monkeypatch):
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)
    monkeypatch.setenv("HIBP_API_KEY", "configured")

    keys = {row.name: row for row in api_key_status()}
    health = {row.source_id: row for row in source_health()}
    summary = source_health_summary()

    assert keys["HIBP_API_KEY"].configured
    assert not keys["SHODAN_API_KEY"].configured
    assert health["module:email"].status == "available"
    assert health["api:shodan"].status == "missing_keys"
    assert health["api:shodan"].auth_required
    assert health["api:shodan"].terms_risk == "medium"
    assert health["api:shodan"].source_maturity == "typed_parser"
    assert health["api:shodan"].quota_policy == "keyed_quota"
    assert "SHODAN_API_KEY" in health["api:shodan"].remediation
    assert health["api:shodan"].verification_status == "needs_api_key"
    assert health["api:crtsh"].remediation.startswith("Ready to run")
    assert health["api:crtsh"].verification_status == "fixture_ready"
    assert health["api:crtsh"].contract_gaps == []
    assert summary["missing_required_keys"] >= 1
    assert summary["typed_parsers"] >= 30
    assert summary["verification_statuses"]["fixture_ready"] >= 1
    assert summary["verification_statuses"]["needs_api_key"] >= 1
    assert summary["contract_gaps"] >= 0
    assert summary["terms_risk"]["medium"] >= 1


def test_v26_source_maintenance_report_prioritizes_offline_actions(monkeypatch):
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)
    report = source_maintenance_report(fixture_dir=FIXTURE_ROOT, env={})
    rows = {row["source_id"]: row for row in report["sources"]}

    assert report["summary"]["network_called"] is False
    assert report["summary"]["secrets_returned"] is False
    assert report["summary"]["fixture_coverage"]["ok_coverage"] == 1.0
    assert report["summary"]["fixture_coverage"]["error_coverage"] == 1.0
    assert report["summary"]["live_validation"]["ready"] == 0
    assert rows["api:crtsh"]["maintenance_status"] == "ok"
    assert rows["api:crtsh"]["live_readiness"] == "ready"
    assert rows["api:shodan"]["maintenance_status"] == "action_required"
    assert rows["api:shodan"]["live_readiness"] == "needs_api_key"
    assert "SHODAN_API_KEY" in rows["api:shodan"]["next_action"]
    assert report["top_actions"][0]["maintenance_status"] == "action_required"


def test_v16_source_verification_contract_fixture_and_live_skip(monkeypatch):
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)

    contract = verify_sources(mode="contract", source_id="api:crtsh")
    fixture = verify_sources(mode="fixture", source_id="api:shodan", fixture_dir=FIXTURE_ROOT)
    live = verify_sources(mode="live", source_id="api:shodan")

    assert contract["summary"] == {
        "sources": 1,
        "passed": 1,
        "failed": 0,
        "skipped": 0,
        "statuses": {"passed": 1},
    }
    assert fixture["summary"]["passed"] == 1
    assert fixture["results"][0]["fixture_path"].endswith("shodan\\ok.json") or fixture["results"][0][
        "fixture_path"
    ].endswith("shodan/ok.json")
    assert fixture["results"][0]["normalized_counts"]["entities"] >= 1
    assert live["summary"]["skipped"] == 1
    assert live["results"][0]["reason"] == "required API keys are missing"


def test_v16_source_verification_fixture_can_override_input_type():
    result = verify_sources(
        mode="fixture",
        source_id="api:virustotal",
        fixture_dir=FIXTURE_ROOT,
        fixture_name="upload_ok",
    )

    assert result["summary"]["passed"] == 1
    assert result["results"][0]["fixture_variant"] == "upload_ok"
    assert result["results"][0]["normalized_counts"]["entities"] >= 4
    assert result["results"][0]["normalized_counts"]["timeline"] == 1


def test_v19_fixture_coverage_summary_lists_missing_sources():
    coverage = fixture_coverage(fixture_dir=FIXTURE_ROOT)
    result = verify_sources(mode="fixture", kind="api", fixture_dir=FIXTURE_ROOT)

    assert coverage["api_sources"] >= 55
    assert coverage["fixture_sources"] == coverage["api_sources"]
    assert coverage["coverage"] == 1.0
    assert "api:shodan" in coverage["covered"]
    assert coverage["missing"] == []
    assert coverage["typed_missing"] == []
    assert result["summary"]["passed"] == coverage["api_sources"]
    assert result["summary"]["failed"] == 0
    assert result["summary"]["skipped"] == 0
    assert result["summary"]["fixture_coverage"]["fixture_sources"] == coverage["fixture_sources"]


def test_v24_source_quality_gate_reports_fixture_and_metadata_readiness():
    crtsh = source_quality_gate(fixture_dir=FIXTURE_ROOT, source_id="api:crtsh")
    bgpview = source_quality_gate(fixture_dir=FIXTURE_ROOT, source_id="api:bgpview")
    bgpview_strict = source_quality_gate(
        fixture_dir=FIXTURE_ROOT,
        source_id="api:bgpview",
        strict=True,
    )

    crtsh_row = crtsh["results"][0]
    bgpview_row = bgpview["results"][0]

    assert crtsh["summary"]["passed"] == 1
    assert crtsh_row["status"] == "passed"
    assert crtsh_row["checks"]["docs_url"]
    assert {"ok", "http_error"}.issubset(set(crtsh_row["fixture_variants"]))
    assert bgpview["summary"]["passed"] == 1
    assert bgpview_row["status"] == "passed"
    assert {"ok", "rate_limited"}.issubset(set(bgpview_row["fixture_variants"]))
    assert bgpview_row["warnings"] == []
    assert bgpview_strict["summary"]["passed"] == 1


def test_v24_source_quality_gate_strict_api_catalog_passes():
    gate = source_quality_gate(fixture_dir=FIXTURE_ROOT, strict=True)

    assert gate["summary"]["sources"] >= 56
    assert gate["summary"]["passed"] == gate["summary"]["sources"]
    assert gate["summary"]["warning"] == 0
    assert gate["summary"]["failed"] == 0
    assert all(row["warnings"] == [] for row in gate["results"])
    assert all(row["required_failures"] == [] for row in gate["results"])


def test_v24_error_fixture_variants_parse_without_positive_confidence():
    gate = source_quality_gate(fixture_dir=FIXTURE_ROOT)
    checked = 0

    for row in gate["results"]:
        variants = [
            variant
            for variant in row["fixture_variants"]
            if variant in {"rate_limited", "http_error", "schema_changed", "not_found"}
        ]
        assert variants, row["source_id"]
        result = verify_sources(
            mode="fixture",
            source_id=row["source_id"],
            fixture_dir=FIXTURE_ROOT,
            fixture_name=variants[0],
        )
        assert result["summary"]["passed"] == 1, result["results"][0]
        assert result["results"][0]["errors"] == []
        checked += 1

    assert checked == gate["summary"]["sources"]


def test_v24_abuseipdb_rate_limit_fixture_closes_quality_gap():
    fixture = verify_sources(
        mode="fixture",
        source_id="api:abuseipdb",
        fixture_dir=FIXTURE_ROOT,
        fixture_name="rate_limited",
    )
    gate = source_quality_gate(fixture_dir=FIXTURE_ROOT, source_id="api:abuseipdb")

    assert fixture["summary"]["passed"] == 1
    assert gate["results"][0]["status"] == "passed"
    assert {"ok", "rate_limited"}.issubset(set(gate["results"][0]["fixture_variants"]))


def test_v24_source_quality_gate_cli_outputs_valid_json():
    from typer.testing import CliRunner

    from bedniiosint.cli import app

    result = CliRunner().invoke(
        app,
        [
            "source-quality-gate",
            "--source",
            "api:crtsh",
            "--fixture-dir",
            str(FIXTURE_ROOT),
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["summary"]["sources"] == 1
    assert payload["results"][0]["source_id"] == "api:crtsh"


def test_v26_source_maintenance_cli_outputs_json():
    from typer.testing import CliRunner

    from bedniiosint.cli import app

    result = CliRunner().invoke(
        app,
        [
            "source-maintenance",
            "--fixture-dir",
            str(FIXTURE_ROOT),
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["summary"]["network_called"] is False
    assert payload["summary"]["fixture_coverage"]["ok_coverage"] == 1.0
    assert payload["sources"]


def test_v20_fixture_variants_cover_rate_limit_errors_and_schema_drift(monkeypatch):
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)

    shodan = verify_sources(
        mode="fixture",
        source_id="api:shodan",
        fixture_dir=FIXTURE_ROOT,
        fixture_name="rate_limited",
    )
    crtsh = verify_sources(
        mode="fixture",
        source_id="api:crtsh",
        fixture_dir=FIXTURE_ROOT,
        fixture_name="http_error",
    )
    github = verify_sources(
        mode="fixture",
        source_id="api:github_search",
        fixture_dir=FIXTURE_ROOT,
        fixture_name="schema_changed",
    )

    assert shodan["summary"]["passed"] == 1
    assert shodan["results"][0]["fixture_variant"] == "rate_limited"
    assert shodan["results"][0]["errors"] == []
    assert crtsh["summary"]["passed"] == 1
    assert github["summary"]["passed"] == 1
    assert github["results"][0]["errors"] == []


def test_v20_live_plan_does_not_call_network(monkeypatch):
    import bedniiosint.catalog.verify as verify

    monkeypatch.delenv("SHODAN_API_KEY", raising=False)

    def fail_adapter_health(*args, **kwargs):
        raise AssertionError("live-plan must not call adapter health")

    monkeypatch.setattr(verify, "adapter_health", fail_adapter_health)

    public = verify_sources(mode="live-plan", source_id="api:crtsh")
    keyed = verify_sources(mode="live-plan", source_id="api:shodan")

    assert public["summary"]["passed"] == 1
    assert public["results"][0]["mode"] == "live_plan"
    assert keyed["summary"]["skipped"] == 1
    assert keyed["results"][0]["reason"] == "required API keys are missing"


def test_v22_live_validation_plan_reports_env_readiness(monkeypatch):
    monkeypatch.delenv("TINEYE_API_KEY", raising=False)
    empty = live_validation_plan({})

    assert empty["network_required"] is True
    assert empty["secrets_returned"] is False
    assert empty["summary"]["ready"] == 0
    assert {row["name"] for row in empty["sections"]} >= {
        "source_live",
        "tineye_image_url_live",
        "opencti_patch_map_live",
    }

    configured_env = {
        "BEDNIIOSINT_SOURCE_LIVE_TESTS": "1",
        "BEDNIIOSINT_SOURCE_LIVE_ID": "api:tineye",
        "BEDNIIOSINT_SOURCE_LIVE_TARGET": "https://example.test/image.jpg",
        "BEDNIIOSINT_SOURCE_LIVE_ALLOW_OPT_IN": "1",
        "BEDNIIOSINT_MEDIA_LIVE_TESTS": "1",
        "BEDNIIOSINT_MEDIA_LIVE_UPLOAD": "1",
        "TINEYE_API_KEY": "tineye-secret",
        "TINEYE_LIVE_IMAGE_URL": "https://example.test/image.jpg",
        "TINEYE_LIVE_IMAGE_PATH": "sample.jpg",
        "BEDNIIOSINT_CTI_LIVE_TESTS": "1",
        "BEDNIIOSINT_CTI_LIVE_SEND": "1",
        "BEDNIIOSINT_CTI_LIVE_PATCH": "1",
        "OPENCTI_URL": "https://opencti.example",
        "OPENCTI_SYNC_URL": "https://opencti.example/import",
        "OPENCTI_TOKEN": "opencti-secret",
        "OPENCTI_PATCH_FIELD": "description=updated",
        "OPENCTI_PATCH_MAP": "X-Private=privateObjectFieldPatch",
        "MISP_URL": "https://misp.example",
        "MISP_API_KEY": "misp-secret",
    }
    configured = live_validation_plan(configured_env)

    by_name = {row["name"]: row for row in configured["sections"]}
    assert by_name["source_live"]["status"] == "ready"
    assert by_name["tineye_image_upload_live"]["status"] == "ready"
    assert by_name["opencti_patch_map_live"]["status"] == "ready"
    assert by_name["misp_send_live"]["status"] == "ready"
    assert "tineye-secret" not in str(configured)
    assert "opencti-secret" not in str(configured)
    assert "misp-secret" not in str(configured)


def test_v23_live_validation_runbook_lists_commands_without_secrets():
    configured_env = {
        "BEDNIIOSINT_SOURCE_LIVE_TESTS": "1",
        "BEDNIIOSINT_SOURCE_LIVE_ID": "api:tineye",
        "BEDNIIOSINT_SOURCE_LIVE_TARGET": "https://example.test/image.jpg",
        "BEDNIIOSINT_SOURCE_LIVE_ALLOW_OPT_IN": "1",
        "BEDNIIOSINT_MEDIA_LIVE_TESTS": "1",
        "BEDNIIOSINT_MEDIA_LIVE_UPLOAD": "1",
        "TINEYE_API_KEY": "tineye-secret",
        "TINEYE_LIVE_IMAGE_URL": "https://example.test/image.jpg",
        "TINEYE_LIVE_IMAGE_PATH": "sample.jpg",
        "BEDNIIOSINT_CTI_LIVE_TESTS": "1",
        "BEDNIIOSINT_CTI_LIVE_SEND": "1",
        "BEDNIIOSINT_CTI_LIVE_PATCH": "1",
        "OPENCTI_URL": "https://opencti.example",
        "OPENCTI_SYNC_URL": "https://opencti.example/import",
        "OPENCTI_TOKEN": "opencti-secret",
        "OPENCTI_PATCH_FIELD": "description=updated",
        "OPENCTI_PATCH_MAP": "X-Private=privateObjectFieldPatch",
        "MISP_URL": "https://misp.example",
        "MISP_API_KEY": "misp-secret",
    }

    runbook = live_validation_runbook(live_validation_plan(configured_env))

    assert runbook.startswith("# BEDNIIOSINT Live Validation Runbook")
    assert "pytest -q tests/test_source_live.py" in runbook
    assert "pytest -q tests/test_cti_live.py" in runbook
    assert "`TINEYE_API_KEY`" in runbook
    assert "`OPENCTI_PATCH_MAP`" in runbook
    assert "`MISP_API_KEY`" in runbook
    assert "schema introspection is disabled" in runbook
    assert "tineye-secret" not in runbook
    assert "opencti-secret" not in runbook
    assert "misp-secret" not in runbook


def test_v23_live_account_validation_runbook_lists_commands_without_secrets():
    configured_env = {
        "SHODAN_API_KEY": "shodan-secret",
        "VIRUSTOTAL_API_KEY": "vt-secret",
    }

    runbook = live_account_validation_runbook(configured_env, priorities=("P0", "P1"))

    assert runbook.startswith("# BEDNIIOSINT Live Account Validation Runbook")
    assert "bedniiosint source-verify --mode live --source api:shodan" in runbook
    assert "`SHODAN_API_KEY`" in runbook
    assert "`VIRUSTOTAL_API_KEY`" in runbook
    assert "shodan-secret" not in runbook
    assert "vt-secret" not in runbook


def test_v23_live_plan_cli_supports_runbook_and_out(tmp_path):
    from typer.testing import CliRunner

    from bedniiosint.cli import app

    runner = CliRunner()
    help_result = runner.invoke(app, ["live-plan", "--help"])

    assert help_result.exit_code == 0
    assert "--runbook" in help_result.output
    assert "--account-runbook" in help_result.output
    assert "--priority" in help_result.output
    assert "--out" in help_result.output

    out_path = tmp_path / "live-runbook.md"
    result = runner.invoke(app, ["live-plan", "--runbook", "--out", str(out_path)])

    assert result.exit_code == 0
    written = out_path.read_text(encoding="utf-8")
    assert written.startswith("# BEDNIIOSINT Live Validation Runbook")
    assert "tineye-secret" not in written
    assert "opencti-secret" not in written
    assert "misp-secret" not in written

    account_result = runner.invoke(app, ["live-plan", "--account-runbook"])

    assert account_result.exit_code == 0
    assert "Live Account Validation Runbook" in account_result.output
    assert "source-verify --mode live" in account_result.output


def test_v20_web_source_verify_accepts_fixture_variant(tmp_path):
    import pytest

    import bedniiosint.web.app as web_app
    import bedniiosint.web.routers.search as search_router
    from bedniiosint.config import settings
    from bedniiosint.core.live_validation_results import record_live_validation_results

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Using `httpx` with `starlette.testclient` is deprecated.*",
        )
        from fastapi.testclient import TestClient

        client = TestClient(web_app.app)

    response = client.get(
        "/sources/verify",
        params={
            "mode": "fixture",
            "source": "api:shodan",
            "fixture_dir": str(FIXTURE_ROOT),
            "fixture": "rate_limited",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["summary"]["passed"] == 1
    assert payload["results"][0]["fixture_variant"] == "rate_limited"

    maintenance = client.get("/sources/maintenance", params={"fixture_dir": str(FIXTURE_ROOT)})
    assert maintenance.status_code == 200
    maintenance_payload = maintenance.json()
    assert maintenance_payload["summary"]["network_called"] is False
    assert maintenance_payload["summary"]["fixture_coverage"]["ok_coverage"] == 1.0
    assert maintenance_payload["top_actions"]

    live_plan = client.get("/live-plan")
    assert live_plan.status_code == 200
    assert live_plan.json()["secrets_returned"] is False

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        secret = "web-live-secret"
        record_live_validation_results(
            {
                "results": [
                    {
                        "source_id": "api:crtsh",
                        "name": "crt.sh",
                        "mode": "live",
                        "target": "example.test",
                        "status": "passed",
                        "reason": "mocked web validation",
                        "verification_status": "fixture_ready",
                        "health_status": "available",
                        "checks": ["adapter health_check executed"],
                        "errors": [],
                        "live_health": {"status": "available", "token": secret},
                    }
                ]
            },
            run_id="web-run-1",
            target="example.test",
            network_required=True,
            env={"TEST_API_KEY": secret},
        )

        history = client.get("/live-results", params={"run_id": "web-run-1"})
        assert history.status_code == 200
        history_payload = history.json()
        assert history_payload["summary"]["rows"] == 1
        assert history_payload["results"][0]["live_health"]["token"] == "[redacted]"
        assert secret not in history.text

        page = client.get("/live-results/view", params={"run_id": "web-run-1"})
        assert page.status_code == 200
        assert "Live Validation Results" in page.text
        assert "Retention guidance" in page.text
        assert "Retention Cleanup" in page.text
        assert "/live-results/export?" in page.text
        assert "api:crtsh" in page.text
        assert secret not in page.text

        exported = client.get(
            "/live-results/export",
            params={"run_id": "web-run-1", "format": "csv"},
        )
        assert exported.status_code == 200
        assert exported.text.startswith("recorded_at,run_id,source_id")
        assert "api:crtsh" in exported.text
        assert secret not in exported.text
        export_sha = hashlib.sha256(exported.text.encode("utf-8")).hexdigest()
        assert exported.headers["x-bedniiosint-export-sha256"] == export_sha
        assert exported.headers["x-bedniiosint-export-bytes"] == str(
            len(exported.text.encode("utf-8"))
        )
        assert exported.headers["x-bedniiosint-audit-event-id"]

        cleanup = client.get("/live-results/cleanup", params={"run_id": "web-run-1"})
        assert cleanup.status_code == 200
        assert cleanup.json()["summary"]["matched"] == 1
        assert cleanup.json()["summary"]["deleted"] == 0
        audit_before = client.get("/live-results/audit", params={"run_id": "web-run-1"})
        assert audit_before.status_code == 200
        assert audit_before.json()["summary"]["actions"]["export"] >= 1
        assert audit_before.json()["summary"]["actions"]["cleanup"] >= 1
        assert any(
            row["output_sha256"] == export_sha
            for row in audit_before.json()["results"]
            if row["action"] == "export"
        )
        assert secret not in audit_before.text

        applied = client.post(
            "/live-results/cleanup",
            data={"run_id": "web-run-1", "apply": "1"},
        )
        assert applied.status_code == 200
        assert "Cleanup deleted 1 rows." in applied.text
        assert client.get("/live-results", params={"run_id": "web-run-1"}).json()["summary"]["rows"] == 0
        audit_after = client.get("/live-results/audit", params={"run_id": "web-run-1"})
        assert audit_after.json()["summary"]["actions"]["cleanup"] >= 2
        assert any(
            row["applied"] for row in audit_after.json()["results"] if row["action"] == "cleanup"
        )
        assert secret not in applied.text
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v16_api_key_env_template_is_blank_and_metadata_rich(monkeypatch, tmp_path):
    monkeypatch.setenv("SHODAN_API_KEY", "real-secret-value")

    template = api_key_env_template(source="api:shodan")
    path = write_api_key_env_template(tmp_path / "bedniiosint.env.example", source="api:shodan")

    assert "SHODAN_API_KEY=" in template
    assert "real-secret-value" not in template
    assert "api:shodan" in template
    assert "risk medium" in template
    written = path.read_text(encoding="utf-8")
    assert "SHODAN_API_KEY=" in written
    assert "real-secret-value" not in written
    try:
        write_api_key_env_template(path, source="api:shodan")
    except FileExistsError:
        pass
    else:
        raise AssertionError("template writer must not overwrite existing files by default")


def test_v16_api_key_env_template_filters_missing_and_required(monkeypatch):
    monkeypatch.setenv("HIBP_API_KEY", "configured-secret")
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)

    template = api_key_env_template(missing_only=True, include_optional=False)

    assert "SHODAN_API_KEY=" in template
    assert "configured-secret" not in template
    assert "HIBP_API_KEY=" not in template


def test_v19_encrypted_secret_store_configures_health_and_adapters(monkeypatch, tmp_path):
    import bedniiosint.catalog.adapters as adapters
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    monkeypatch.setenv("BEDNIIOSINT_SECRETS_KEY", "test-passphrase")
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)
    try:
        record = store_secret("SHODAN_API_KEY", "vault-secret")
        raw_store = (tmp_path / "_secrets.json").read_text(encoding="utf-8")

        assert record["name"] == "SHODAN_API_KEY"
        assert "vault-secret" not in raw_store
        assert secret_value("SHODAN_API_KEY") == "vault-secret"
        assert list_secrets()[0]["configured"] is True

        keys = {row.name: row for row in api_key_status()}
        health = {row.source_id: row for row in source_health()}
        assert keys["SHODAN_API_KEY"].configured
        assert health["api:shodan"].status == "available"

        calls = []

        class FakeResponse:
            status_code = 200
            headers = {"content-type": "application/json"}
            text = ""
            url = "https://api.shodan.io/shodan/host/8.8.8.8"

            def json(self):
                return {"data": []}

        def fake_request(method: str, url: str, **kwargs):
            calls.append((method, url, kwargs))
            return FakeResponse()

        monkeypatch.setattr(adapters, "request", fake_request)
        result = adapter_for("api:shodan").run("8.8.8.8", input_type="ip")

        assert result.status == "ok"
        assert calls[0][2]["params"] == {"api_key": "vault-secret"}
        assert delete_secret("SHODAN_API_KEY")
        assert not secret_value("SHODAN_API_KEY")
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v19_secret_store_audit_and_rotation_do_not_return_secrets(monkeypatch, tmp_path):
    import bedniiosint.core.secret_store as secret_store
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    original_iterations = secret_store.KDF_ITERATIONS
    object.__setattr__(settings, "db_dir", tmp_path)
    monkeypatch.setenv(SECRET_KEY_ENV, "audit-passphrase")
    try:
        monkeypatch.setattr(secret_store, "KDF_ITERATIONS", 1000)
        store_secret("SHODAN_API_KEY", "vault-secret")
        monkeypatch.setattr(secret_store, "KDF_ITERATIONS", original_iterations)

        audit = audit_secret_store()

        assert audit["secrets_returned"] is False
        assert audit["summary"]["records"] == 1
        assert audit["summary"]["authenticated"] == 1
        assert audit["summary"]["rotation_required"] == 1
        assert audit["records"][0]["status"] == "rotation_required"
        assert "vault-secret" not in json.dumps(audit)

        from typer.testing import CliRunner

        from bedniiosint.cli import app

        grouped_audit = CliRunner().invoke(app, ["api-keys", "store-audit", "--json"])
        legacy_audit = CliRunner().invoke(app, ["api-key-store-audit", "--json"])

        assert grouped_audit.exit_code == 0, grouped_audit.output
        assert legacy_audit.exit_code == 0, legacy_audit.output
        assert json.loads(grouped_audit.output)["summary"]["rotation_required"] == 1
        assert json.loads(legacy_audit.output)["summary"]["rotation_required"] == 1
        assert "vault-secret" not in grouped_audit.output
        assert "vault-secret" not in legacy_audit.output

        rotation = rotate_secret_store()
        rotated_audit = audit_secret_store()

        assert rotation["secrets_returned"] is False
        assert rotation["rotated"] == 1
        assert rotated_audit["summary"]["rotation_required"] == 0
        assert secret_value("SHODAN_API_KEY") == "vault-secret"
        assert "vault-secret" not in json.dumps(rotated_audit)
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)
        delete_secret("SHODAN_API_KEY", path=tmp_path / "_secrets.json")


def test_v21_secret_store_setup_template_is_safe_and_writable(tmp_path):
    cmd_template = secret_store_setup_template(profile="windows-cmd-user")
    ps_template = secret_store_setup_template(profile="powershell-user", placeholder="replace-me")

    assert "setx BEDNIIOSINT_SECRETS_KEY" in cmd_template
    assert "<set-a-long-passphrase>" in cmd_template
    assert "replace-me" in ps_template
    assert "vault-secret" not in cmd_template

    path = write_secret_store_setup_template(
        tmp_path / "secret-store-setup.ps1",
        profile="powershell-session",
        placeholder="replace-me",
    )
    written = path.read_text(encoding="utf-8")

    assert "$env:BEDNIIOSINT_SECRETS_KEY" in written
    assert "replace-me" in written
    try:
        write_secret_store_setup_template(path, profile="env-file")
    except FileExistsError:
        pass
    else:
        raise AssertionError("setup template writer must not overwrite existing files by default")


def test_v21_secret_store_setup_apply_is_safe_and_mockable(monkeypatch):
    import bedniiosint.core.secret_store as secret_store

    monkeypatch.delenv(SECRET_KEY_ENV, raising=False)
    session = apply_secret_store_setup(
        profile="powershell-session",
        passphrase="session-passphrase",
    )

    assert session == {
        "profile": "powershell-session",
        "status": "applied",
        "target": "current-process-environment",
        "persistent": False,
        "requires_restart": False,
        "secret_returned": False,
        "secret_file_written": False,
    }
    assert secret_store.os.environ[SECRET_KEY_ENV] == "session-passphrase"
    assert "session-passphrase" not in str(session)

    applied = {}

    def fake_set_windows_user_environment(name: str, value: str):
        applied[name] = value

    monkeypatch.setattr(secret_store.os, "name", "nt")
    monkeypatch.setattr(secret_store, "_set_windows_user_environment", fake_set_windows_user_environment)

    user = apply_secret_store_setup(
        profile="windows-cmd-user",
        passphrase="user-passphrase",
    )

    assert user["status"] == "applied"
    assert user["target"] == "windows-user-environment"
    assert user["persistent"] is True
    assert user["requires_restart"] is True
    assert user["secret_returned"] is False
    assert user["secret_file_written"] is False
    assert applied == {SECRET_KEY_ENV: "user-passphrase"}
    assert secret_store.os.environ[SECRET_KEY_ENV] == "user-passphrase"
    assert "user-passphrase" not in str(user)

    try:
        apply_secret_store_setup(profile="env-file", passphrase="file-passphrase")
    except ValueError as exc:
        assert "requires an explicit output path" in str(exc)
    else:
        raise AssertionError("file template profiles must not apply secrets directly")


def test_v21_secret_store_setup_apply_secret_file_requires_explicit_opt_in(tmp_path):
    path = tmp_path / "bedniiosint.env"

    try:
        apply_secret_store_setup(
            profile="env-file",
            passphrase="file-passphrase",
            out=path,
        )
    except ValueError as exc:
        assert "allow_secret_file=True" in str(exc)
    else:
        raise AssertionError("secret file apply must require explicit opt-in")

    result = apply_secret_store_setup(
        profile="env-file",
        passphrase="file-passphrase",
        out=path,
        allow_secret_file=True,
    )
    written = path.read_text(encoding="utf-8")

    assert result["status"] == "applied"
    assert result["target"] == str(path)
    assert result["persistent"] is True
    assert result["requires_restart"] is True
    assert result["secret_returned"] is False
    assert result["secret_file_written"] is True
    assert f"{SECRET_KEY_ENV}=file-passphrase" in written
    assert "file-passphrase" not in str(result)


def test_v21_secret_store_systemd_dropin_install_is_explicit_and_safe(tmp_path):
    commands = []

    def fake_runner(command, check):
        commands.append((command, check))

    try:
        install_secret_store_systemd_dropin(
            service="bedniiosint-worker",
            passphrase="systemd-passphrase",
            root=tmp_path,
        )
    except ValueError as exc:
        assert "allow_secret_file=True" in str(exc)
    else:
        raise AssertionError("systemd drop-in install must require secret-file opt-in")

    result = install_secret_store_systemd_dropin(
        service="bedniiosint-worker",
        passphrase="systemd-passphrase",
        root=tmp_path,
        allow_secret_file=True,
        reload_daemon=True,
        restart_service=True,
        runner=fake_runner,
    )
    dropin = tmp_path / "bedniiosint-worker.service.d" / "bedniiosint-secrets.conf"
    written = dropin.read_text(encoding="utf-8")

    assert result["target"] == "systemd-user-dropin"
    assert result["service"] == "bedniiosint-worker.service"
    assert result["path"] == str(dropin)
    assert result["secret_returned"] is False
    assert result["secret_file_written"] is True
    assert f'Environment="{SECRET_KEY_ENV}=systemd-passphrase"' in written
    assert "systemd-passphrase" not in str(result)
    assert commands == [
        (["systemctl", "--user", "daemon-reload"], True),
        (["systemctl", "--user", "restart", "bedniiosint-worker.service"], True),
    ]

    try:
        install_secret_store_systemd_dropin(
            service="../bad.service",
            passphrase="systemd-passphrase",
            root=tmp_path,
            allow_secret_file=True,
        )
    except ValueError as exc:
        assert "path separators" in str(exc)
    else:
        raise AssertionError("systemd service names must not allow path traversal")


def test_v16_source_verification_live_uses_adapter_health(monkeypatch):
    import bedniiosint.catalog.verify as verify

    calls = []

    def fake_adapter_health(source_id: str, *, target: str = "example.com", plugin_dir=None):
        calls.append((source_id, target, plugin_dir))
        return {
            "source_id": source_id,
            "status": "available",
            "checked_at": "2026-01-01T00:00:00+00:00",
            "status_code": 200,
            "latency_ms": 12,
            "error": "",
            "missing_env": [],
        }

    monkeypatch.setattr(verify, "adapter_health", fake_adapter_health)

    result = verify_sources(mode="live", source_id="api:crtsh", target="example.test")

    assert result["summary"]["passed"] == 1
    assert result["results"][0]["live_health"]["status"] == "available"
    assert result["results"][0]["target"] == "example.test"
    assert calls == [("api:crtsh", "example.test", None)]


def test_v27_live_validation_results_are_opt_in_persisted_and_redacted(tmp_path, monkeypatch):
    from typer.testing import CliRunner

    import bedniiosint.catalog.verify as verify
    from bedniiosint.cli import app
    from bedniiosint.config import settings

    secret = "super-secret-token"
    monkeypatch.setenv("BEDNIIOSINT_FAKE_API_KEY", secret)

    def fake_adapter_health(source_id: str, *, target: str = "example.com", plugin_dir=None):
        return {
            "source_id": source_id,
            "status": "available",
            "checked_at": "2026-01-01T00:00:00+00:00",
            "status_code": 200,
            "latency_ms": 12,
            "token": secret,
            "details": f"https://example.test/?api_key={secret}",
            "headers": {"Authorization": f"Bearer {secret}"},
            "missing_env": [],
        }

    monkeypatch.setattr(verify, "adapter_health", fake_adapter_health)
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        runner = CliRunner()
        result = runner.invoke(
            app,
            [
                "source-verify",
                "--mode",
                "live",
                "--source",
                "api:crtsh",
                "--target",
                "example.test",
                "--record-live-result",
                "--run-id",
                "mock-run-1",
                "--json",
            ],
        )

        assert result.exit_code == 0, result.output
        assert secret not in result.output
        payload = json.loads(result.output)
        assert payload["recording"]["recorded"] == 1
        assert payload["recording"]["redacted_rows"] == 1
        assert payload["results"][0]["live_health"]["token"] == "[redacted]"
        assert payload["results"][0]["target"] == "example.test"

        history = runner.invoke(app, ["live-results", "--run-id", "mock-run-1", "--json"])

        assert history.exit_code == 0, history.output
        assert secret not in history.output
        history_payload = json.loads(history.output)
        assert history_payload["summary"]["rows"] == 1
        assert history_payload["summary"]["redacted_rows"] == 1
        assert history_payload["results"][0]["source_id"] == "api:crtsh"
        assert history_payload["results"][0]["live_health"]["token"] == "[redacted]"

        markdown = runner.invoke(app, ["live-results", "--run-id", "mock-run-1", "--markdown"])

        assert markdown.exit_code == 0, markdown.output
        assert "# BEDNIIOSINT Live Validation Results" in markdown.output
        assert secret not in markdown.output
        assert "api:crtsh" in markdown.output

        csv_export = runner.invoke(app, ["live-results", "--run-id", "mock-run-1", "--format", "csv"])

        assert csv_export.exit_code == 0, csv_export.output
        assert csv_export.output.startswith("recorded_at,run_id,source_id")
        assert "api:crtsh" in csv_export.output
        assert secret not in csv_export.output

        out_path = tmp_path / "live-results.csv"
        file_export = runner.invoke(
            app,
            [
                "live-results",
                "--run-id",
                "mock-run-1",
                "--format",
                "csv",
                "--out",
                str(out_path),
            ],
        )

        assert file_export.exit_code == 0, file_export.output
        manifest_path = out_path.with_name(f"{out_path.name}.manifest.json")
        assert out_path.exists()
        assert manifest_path.exists()
        exported_bytes = out_path.read_bytes()
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        assert manifest["kind"] == "bedniiosint.live_validation_export_manifest"
        assert manifest["export"]["sha256"] == hashlib.sha256(exported_bytes).hexdigest()
        assert manifest["export"]["bytes"] == len(exported_bytes)
        assert manifest["audit_event"]["id"]
        assert manifest["audit_event"]["output_sha256"] == manifest["export"]["sha256"]
        assert secret not in manifest_path.read_text(encoding="utf-8")

        verified = runner.invoke(
            app,
            ["live-results-verify", str(manifest_path), "--audit-log", "--json"],
        )

        assert verified.exit_code == 0, verified.output
        assert secret not in verified.output
        verified_payload = json.loads(verified.output)
        assert verified_payload["valid"] is True
        assert verified_payload["checks"]["sha256"] is True
        assert verified_payload["checks"]["bytes"] is True
        assert verified_payload["checks"]["audit_log_found"] is True
        assert verified_payload["audit_event"]["id"] == manifest["audit_event"]["id"]
        assert verified_payload["secrets_returned"] is False

        tampered_path = tmp_path / "tampered-live-results.csv"
        tampered_path.write_bytes(exported_bytes + b"tampered")
        tampered = runner.invoke(
            app,
            [
                "live-results-verify",
                str(manifest_path),
                "--export",
                str(tampered_path),
                "--json",
            ],
        )

        assert tampered.exit_code != 0
        assert secret not in tampered.output
        tampered_payload = json.loads(tampered.output)
        assert tampered_payload["valid"] is False
        assert tampered_payload["checks"]["sha256"] is False
        assert "export SHA-256 does not match manifest" in tampered_payload["errors"]

        with sqlite3.connect(settings.db_path("_live_validation")) as conn:
            stored = conn.execute(
                'SELECT live_health_json FROM "livevalidationresult" WHERE run_id = ?',
                ("mock-run-1",),
            ).fetchone()[0]
        assert secret not in stored
        assert "[redacted]" in stored

        dry_run = runner.invoke(
            app,
            ["live-results-cleanup", "--run-id", "mock-run-1", "--json"],
        )

        assert dry_run.exit_code == 0, dry_run.output
        dry_payload = json.loads(dry_run.output)
        assert dry_payload["summary"]["matched"] == 1
        assert dry_payload["summary"]["deleted"] == 0
        assert dry_payload["summary"]["dry_run"] is True

        unsafe_apply = runner.invoke(app, ["live-results-cleanup", "--apply", "--json"])
        assert unsafe_apply.exit_code != 0

        applied = runner.invoke(
            app,
            ["live-results-cleanup", "--run-id", "mock-run-1", "--apply", "--json"],
        )

        assert applied.exit_code == 0, applied.output
        applied_payload = json.loads(applied.output)
        assert applied_payload["summary"]["matched"] == 1
        assert applied_payload["summary"]["deleted"] == 1

        audit = runner.invoke(app, ["live-results-audit", "--run-id", "mock-run-1", "--json"])

        assert audit.exit_code == 0, audit.output
        assert secret not in audit.output
        audit_payload = json.loads(audit.output)
        assert audit_payload["summary"]["rows"] >= 4
        actions = audit_payload["summary"]["actions"]
        assert actions["export"] >= 3
        assert actions["cleanup"] >= 2
        assert any(
            row["manifest_path"] == str(manifest_path)
            and row["output_sha256"] == manifest["export"]["sha256"]
            for row in audit_payload["results"]
            if row["action"] == "export"
        )
        assert any(row["applied"] for row in audit_payload["results"] if row["action"] == "cleanup")
        assert all(row["secrets_returned"] is False for row in audit_payload["results"])

        empty = runner.invoke(app, ["live-results", "--run-id", "mock-run-1", "--json"])
        assert json.loads(empty.output)["summary"]["rows"] == 0
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v08_registry_includes_local_plugin_manifest(tmp_path):
    plugin = tmp_path / "demo"
    plugin.mkdir()
    (plugin / "plugin.json").write_text(
        """{
  "name": "demo",
  "version": "0.1.0",
  "description": "Demo adapter.",
  "consumes": ["domain"],
  "produces": ["subdomain"],
  "entrypoint": "adapter:run",
  "auth": "api_key",
  "env_vars": ["DEMO_API_KEY"]
}""",
        encoding="utf-8",
    )

    entries = registry_entries(plugin_dir=tmp_path)
    plugins = {entry.id: entry for entry in entries if entry.kind == "plugin"}
    summary = registry_summary(entries)

    assert "plugin:demo" in plugins
    assert plugins["plugin:demo"].inputs == ["domain"]
    assert plugins["plugin:demo"].env_vars == ["DEMO_API_KEY"]
    assert summary["plugins"] == 1


def test_v08_local_plugin_adapter_runs(tmp_path):
    plugin = tmp_path / "demo"
    plugin.mkdir()
    (plugin / "plugin.json").write_text(
        """{
  "name": "demo",
  "version": "0.1.0",
  "description": "Demo adapter.",
  "consumes": ["domain"],
  "produces": ["subdomain"],
  "entrypoint": "adapter:run",
  "auth": "none",
  "env_vars": []
}""",
        encoding="utf-8",
    )
    (plugin / "adapter.py").write_text(
        """def run(target: str, **kwargs):
    return {"target": target, "kwargs": kwargs, "ok": True}

def parse(raw: dict, target: str):
    return {
        "entities": [{"type": "domain", "value": target}],
        "relations": [],
        "findings": [{"source_id": "demo", "entity_type": "domain", "entity_value": target, "status": "exists", "confidence": 0.8}],
        "timeline": [{"kind": "adapter_observed", "entity_type": "domain", "entity_value": target, "source": "demo", "confidence": 0.8}],
        "raw": raw,
    }

def health_check(**kwargs):
    return {"status": "available", "status_code": 200, "error": ""}
""",
        encoding="utf-8",
    )

    result = run_source("plugin:demo", "example.com", plugin_dir=tmp_path, limit=1)
    adapter = adapter_for("plugin:demo", plugin_dir=tmp_path)
    schema = adapter.schema()
    health = adapter.health_check()

    assert result.status == "ok"
    assert result.data["target"] == "example.com"
    assert result.data["kwargs"]["limit"] == 1
    assert result.normalized["entities"][0] == {"type": "domain", "value": "example.com"}
    assert result.normalized["timeline"][0]["kind"] == "adapter_observed"
    assert schema["input_schema"]["input_types"] == ["domain"]
    assert health.status == "available"


def test_v11_plugin_state_config_signature_and_disable(tmp_path, monkeypatch):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path / "state")
    monkeypatch.setenv("BEDNIIOSINT_PLUGIN_SIGNING_KEY", "secret")
    plugin = tmp_path / "demo"
    plugin.mkdir()
    manifest_path = plugin / "plugin.json"
    manifest_path.write_text(
        """{
  "name": "demo",
  "version": "0.1.0",
  "description": "Signed demo adapter.",
  "consumes": ["domain"],
  "produces": ["finding"],
  "entrypoint": "adapter:run",
  "auth": "none",
  "env_vars": []
}""",
        encoding="utf-8",
    )
    (plugin / "adapter.py").write_text(
        """def run(target: str, **kwargs):
    return {"target": target, "kwargs": kwargs}
""",
        encoding="utf-8",
    )
    try:
        signature = sign_plugin_manifest(manifest_path, "secret", key_id="test")
        set_plugin_config("demo", {"limit": 3})

        manifests = discover_plugin_manifests(tmp_path)
        result = run_source("plugin:demo", "example.com", plugin_dir=tmp_path)
        set_plugin_enabled("demo", False)
        disabled = discover_plugin_manifests(tmp_path)
        visible = all_plugin_manifests(tmp_path, include_disabled=True)

        assert signature["key_id"] == "test"
        assert manifests[0].signature_status["verified"] is True
        assert manifests[0].config == {"limit": 3}
        assert result.data["kwargs"]["limit"] == 3
        assert disabled == []
        assert any(row.name == "demo" and not row.enabled for row in visible)
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v14_plugin_manifest_validation_and_signed_enforcement(tmp_path, monkeypatch):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path / "state")
    monkeypatch.setenv("BEDNIIOSINT_PLUGIN_SIGNING_KEY", "secret")
    monkeypatch.setenv("BEDNIIOSINT_REQUIRE_SIGNED_PLUGINS", "1")
    unsigned = tmp_path / "unsigned"
    signed = tmp_path / "signed"
    invalid = tmp_path / "invalid"
    unsigned.mkdir()
    signed.mkdir()
    invalid.mkdir()
    unsigned_manifest = unsigned / "plugin.json"
    signed_manifest = signed / "plugin.json"
    invalid_manifest = invalid / "plugin.json"
    manifest_text = """{
  "name": "demo",
  "version": "0.1.0",
  "description": "Demo adapter.",
  "consumes": ["domain"],
  "produces": ["finding"],
  "entrypoint": "adapter:run",
  "auth": "none",
  "env_vars": []
}"""
    unsigned_manifest.write_text(manifest_text.replace('"demo"', '"unsigned"', 1), encoding="utf-8")
    signed_manifest.write_text(manifest_text.replace('"demo"', '"signed"', 1), encoding="utf-8")
    invalid_manifest.write_text(
        """{"name": "bad plugin", "version": "", "consumes": "domain", "produces": [], "entrypoint": "adapter"}""",
        encoding="utf-8",
    )
    try:
        sign_plugin_manifest(signed_manifest, "secret")

        invalid_report = validate_plugin_manifest(invalid_manifest)
        unsigned_report = validate_plugin_manifest(unsigned_manifest, require_valid_signature=True)
        manifests = discover_plugin_manifests(tmp_path)

        assert not invalid_report["valid"]
        assert "entrypoint must use module:function syntax" in invalid_report["errors"]
        assert "consumes must be a non-empty list of strings" in invalid_report["errors"]
        assert not unsigned_report["valid"]
        assert "plugin manifest must be signed" in unsigned_report["errors"]
        assert [row.name for row in manifests] == ["signed"]
        assert manifests[0].validation["signature_status"]["verified"] is True
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v08_catalog_http_adapter_prepares_endpoint():
    adapter = adapter_for("api:crtsh")
    method, url, selected = adapter.prepare("example.com", input_type="domain")
    schema = adapter.schema()
    bgp_schema = adapter_for("api:bgpview").schema()
    securitytrails_schema = adapter_for("api:securitytrails").schema()
    wikidata_schema = adapter_for("api:wikidata").schema()
    osintly_schema = adapter_for("api:osintly_api").schema()
    mastodon_method, mastodon_url, mastodon_selected = adapter_for("api:mastodon_lookup").prepare(
        "alice@mastodon.social",
        input_type="username",
    )
    nominatim_schema = adapter_for("api:nominatim").schema()
    open_measures_schema = adapter_for("api:open_measures").schema()

    assert method == "GET"
    assert url == "https://crt.sh/?q=%25.example.com&output=json"
    assert selected == "domain"
    assert mastodon_method == "GET"
    assert mastodon_url == "https://mastodon.social/api/v1/accounts/lookup?acct=alice@mastodon.social"
    assert mastodon_selected == "username"
    assert schema["adapter"] == "crtsh-adapter"
    assert bgp_schema["adapter"] == "network-registry-adapter"
    assert securitytrails_schema["adapter"] == "dns-intel-adapter"
    assert wikidata_schema["adapter"] == "knowledge-graph-adapter"
    assert osintly_schema["adapter"] == "aggregator-adapter"
    assert nominatim_schema["adapter"] == "location-geocoding-adapter"
    assert open_measures_schema["adapter"] == "social-intel-adapter"
    assert "normalized_schema" in schema


def test_v14_catalog_adapter_auth_headers_basic_auth_and_post_body(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    monkeypatch.setenv("SECURITYTRAILS_API_KEY", "st-secret")
    monkeypatch.setenv("OSINTLY_API_KEY", "osintly-secret")
    monkeypatch.setenv("CENSYS_API_ID", "censys-id")
    monkeypatch.setenv("CENSYS_API_SECRET", "censys-secret")
    calls = []

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json"}
        text = ""

        def __init__(self, url: str):
            self.url = url

        def json(self):
            return {"results": []}

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse(url)

    monkeypatch.setattr(adapters, "request", fake_request)

    securitytrails = adapter_for("api:securitytrails").run(
        "example.com",
        input_type="domain",
    )
    osintly = adapter_for("api:osintly_api").run(
        "alice@example.com",
        input_type="email",
    )
    censys = adapter_for("api:censys").health_check(
        target="example.com",
        input_type="domain",
    )

    assert securitytrails.status == "ok"
    assert osintly.status == "ok"
    assert censys.status == "available"
    assert calls[0][2]["headers"]["APIKEY"] == "st-secret"
    assert calls[1][0] == "POST"
    assert calls[1][1] == "https://api.osint.ly/search"
    assert calls[1][2]["headers"]["Authorization"] == "Bearer osintly-secret"
    assert calls[1][2]["json"] == {"target": "alice@example.com", "type": "email"}
    assert calls[2][1] == "https://search.censys.io/api/v2/hosts/search?q=example.com"
    assert calls[2][2]["auth"] == ("censys-id", "censys-secret")


def test_v12_source_specific_parsers_normalize_important_api_shapes():
    crtsh = {"id": "crtsh", "name": "crt.sh", "inputs": ["domain"]}
    rdap = {"id": "rdap", "name": "RDAP", "inputs": ["domain"]}
    phone = {"id": "numverify", "name": "Numverify", "inputs": ["phone"]}
    company = {"id": "opencorporates", "name": "OpenCorporates", "inputs": ["company"]}

    crtsh_result = AdapterResult(
        source_id="api:crtsh",
        target="example.com",
        status="ok",
        input_type="domain",
        status_code=200,
        data=[
            {"name_value": "*.www.example.com\nmail.example.com\nbad.test"},
            {"common_name": "api.example.com"},
        ],
    )
    rdap_result = AdapterResult(
        source_id="api:rdap",
        target="example.com",
        status="ok",
        input_type="domain",
        status_code=200,
        data={
            "handle": "D123",
            "events": [{"eventAction": "registration", "eventDate": "2020-01-01T00:00:00Z"}],
            "entities": [{"roles": ["registrar"], "handle": "REG"}],
        },
    )
    phone_result = AdapterResult(
        source_id="api:numverify",
        target="+15551234567",
        status="ok",
        input_type="phone",
        status_code=200,
        data={
            "valid": True,
            "international_format": "+1 555 123 4567",
            "carrier": "ExampleTel",
            "country_name": "United States",
            "line_type": "mobile",
        },
    )
    company_result = AdapterResult(
        source_id="api:opencorporates",
        target="Example Inc",
        status="ok",
        input_type="company",
        status_code=200,
        data={
            "results": {
                "companies": [
                    {
                        "company": {
                            "name": "Example Inc",
                            "company_number": "123",
                            "current_status": "Active",
                        }
                    }
                ]
            }
        },
    )

    crtsh_norm = parse_specialized(crtsh, crtsh_result)
    rdap_norm = parse_specialized(rdap, rdap_result)
    phone_norm = parse_specialized(phone, phone_result)
    company_norm = parse_specialized(company, company_result)

    assert {"type": "domain", "value": "www.example.com"} in crtsh_norm["entities"]
    assert {"type": "domain", "value": "bad.test"} not in crtsh_norm["entities"]
    assert any(row["kind"] == "registration" for row in rdap_norm["timeline"])
    assert {"type": "carrier", "value": "ExampleTel"} in phone_norm["entities"]
    assert any(row["rel"] == "has_registry_id" for row in company_norm["relations"])


def test_v13_source_specific_parsers_normalize_network_threat_and_aggregator_shapes():
    bgp = {"id": "bgpview", "name": "BGPView", "inputs": ["ip"]}
    securitytrails = {"id": "securitytrails", "name": "SecurityTrails", "inputs": ["domain"]}
    virustotal = {"id": "virustotal", "name": "VirusTotal", "inputs": ["domain"]}
    urlhaus = {"id": "urlhaus", "name": "URLhaus", "inputs": ["domain"]}
    wikidata = {"id": "wikidata", "name": "Wikidata", "inputs": ["company"]}
    osintly = {"id": "osintly_api", "name": "Osintly", "inputs": ["email"]}

    bgp_norm = parse_specialized(
        bgp,
        AdapterResult(
            source_id="api:bgpview",
            target="8.8.8.8",
            status="ok",
            input_type="ip",
            status_code=200,
            data=_source_fixture("bgpview"),
        ),
    )
    securitytrails_norm = parse_specialized(
        securitytrails,
        AdapterResult(
            source_id="api:securitytrails",
            target="example.com",
            status="ok",
            input_type="domain",
            status_code=200,
            data={
                "subdomains": ["www", "api.example.com", "bad.test"],
                "records": {"A": [{"value": "93.184.216.34"}]},
            },
        ),
    )
    vt_norm = parse_specialized(
        virustotal,
        AdapterResult(
            source_id="api:virustotal",
            target="example.com",
            status="ok",
            input_type="domain",
            status_code=200,
            data={
                "data": {
                    "id": "example.com",
                    "attributes": {
                        "reputation": -1,
                        "last_analysis_stats": {"malicious": 2, "suspicious": 1},
                        "last_dns_records": [{"type": "A", "value": "93.184.216.34"}],
                    },
                }
            },
        ),
    )
    urlhaus_norm = parse_specialized(
        urlhaus,
        AdapterResult(
            source_id="api:urlhaus",
            target="example.com",
            status="ok",
            input_type="domain",
            status_code=200,
            data=_source_fixture("urlhaus"),
        ),
    )
    wikidata_norm = parse_specialized(
        wikidata,
        AdapterResult(
            source_id="api:wikidata",
            target="Example Inc",
            status="ok",
            input_type="company",
            status_code=200,
            data=_source_fixture("wikidata"),
        ),
    )
    osintly_norm = parse_specialized(
        osintly,
        AdapterResult(
            source_id="api:osintly_api",
            target="alice@example.com",
            status="ok",
            input_type="email",
            status_code=200,
            data={
                "results": [
                    {"type": "username", "value": "alice", "relation": "uses_username"}
                ]
            },
        ),
    )

    assert {"type": "asn", "value": "AS15169"} in bgp_norm["entities"]
    assert {"type": "cidr", "value": "8.8.8.0/24"} in bgp_norm["entities"]
    assert {"type": "domain", "value": "www.example.com"} in securitytrails_norm["entities"]
    assert {"type": "domain", "value": "bad.test"} not in securitytrails_norm["entities"]
    assert {"type": "ip", "value": "93.184.216.34"} in securitytrails_norm["entities"]
    assert any(row["rel"] == "vt_dns_a" for row in vt_norm["relations"])
    assert any(row["type"] == "threat_verdict" for row in vt_norm["entities"])
    assert {"type": "url", "value": "http://bad.example/payload"} in urlhaus_norm["entities"]
    assert urlhaus_norm["timeline"][0]["kind"] == "urlhaus_observed"
    assert {"type": "wikidata_id", "value": "Q123"} in wikidata_norm["entities"]
    assert {"type": "username", "value": "alice"} in osintly_norm["entities"]
    assert any(row["rel"] == "uses_username" for row in osintly_norm["relations"])


def test_v16_p0_contract_parsers_cover_github_and_wayback():
    github = {"id": "github", "name": "GitHub", "inputs": ["username"]}
    wayback = {"id": "wayback_cdx", "name": "Wayback CDX", "inputs": ["domain"]}

    github_norm = parse_specialized(
        github,
        AdapterResult(
            source_id="api:github",
            target="alice",
            status="ok",
            input_type="username",
            status_code=200,
            url="https://api.github.com/users/alice",
            data=_source_fixture("github"),
        ),
    )
    wayback_norm = parse_specialized(
        wayback,
        AdapterResult(
            source_id="api:wayback_cdx",
            target="example.com",
            status="ok",
            input_type="domain",
            status_code=200,
            url="https://web.archive.org/cdx",
            data=_source_fixture("wayback_cdx"),
        ),
    )

    assert {"type": "username", "value": "alice"} in github_norm["entities"]
    assert {"type": "profile", "value": "https://github.com/alice"} in github_norm["entities"]
    assert github_norm["findings"][0]["source_id"] == "api:github"
    assert github_norm["findings"][0]["profile_url"] == "https://github.com/alice"
    assert github_norm["findings"][0]["confidence"] > 0
    assert {"type": "url", "value": "https://example.com/"} in wayback_norm["entities"]
    assert any(row["rel"] == "archived_url" for row in wayback_norm["relations"])
    assert wayback_norm["timeline"][0]["kind"] == "archived"


def test_github_profile_normalization_keeps_api_url_out_of_click_target():
    raw = AdapterResult(
        source_id="api:github",
        target="Cote4r",
        status="ok",
        input_type="username",
        status_code=200,
        url="https://api.github.com/users/Cote4r",
        data={
            "login": "Cote4r",
            "url": "https://api.github.com/users/Cote4r",
            "html_url": "https://github.com/Cote4r",
            "type": "User",
        },
    )
    raw.normalized = parse_specialized(
        {"id": "github", "name": "GitHub", "inputs": ["username"]},
        raw,
    )

    record = normalize_adapter_result(raw)

    assert raw.normalized["findings"][0]["profile_url"] == "https://github.com/Cote4r"
    assert record.url == "https://api.github.com/users/Cote4r"
    assert record.profile_url == "https://github.com/Cote4r"


def test_v15_p0_api_parsers_cover_breach_url_reputation_and_attack_surface():
    hibp = {"id": "hibp", "name": "HIBP", "inputs": ["email"]}
    urlscan = {"id": "urlscan", "name": "urlscan", "inputs": ["url"]}
    abuse = {"id": "abuseipdb", "name": "AbuseIPDB", "inputs": ["ip"]}
    greynoise = {"id": "greynoise", "name": "GreyNoise", "inputs": ["ip"]}
    shodan = {"id": "shodan", "name": "Shodan", "inputs": ["ip"]}

    hibp_norm = parse_specialized(
        hibp,
        AdapterResult(
            source_id="api:hibp",
            target="alice@example.com",
            status="ok",
            input_type="email",
            status_code=200,
            data=[
                {
                    "Name": "ExampleBreach",
                    "Domain": "example.com",
                    "BreachDate": "2024-01-02",
                }
            ],
        ),
    )
    urlscan_norm = parse_specialized(
        urlscan,
        AdapterResult(
            source_id="api:urlscan",
            target="https://example.com/login",
            status="ok",
            input_type="url",
            status_code=200,
            data={
                "results": [
                    {
                        "page": {
                            "url": "https://example.com/login",
                            "domain": "example.com",
                            "ip": "93.184.216.34",
                        },
                        "task": {"time": "2024-02-03T04:05:06Z"},
                    }
                ]
            },
        ),
    )
    abuse_norm = parse_specialized(
        abuse,
        AdapterResult(
            source_id="api:abuseipdb",
            target="93.184.216.34",
            status="ok",
            input_type="ip",
            status_code=200,
            data={
                "data": {
                    "abuseConfidenceScore": 42,
                    "totalReports": 7,
                    "isp": "ExampleNet",
                    "domain": "example.net",
                    "countryCode": "US",
                }
            },
        ),
    )
    greynoise_norm = parse_specialized(
        greynoise,
        AdapterResult(
            source_id="api:greynoise",
            target="93.184.216.34",
            status="ok",
            input_type="ip",
            status_code=200,
            data={
                "classification": "malicious",
                "noise": True,
                "riot": False,
                "name": "Example Scanner",
                "last_seen": "2024-03-04T00:00:00Z",
            },
        ),
    )
    shodan_norm = parse_specialized(
        shodan,
        AdapterResult(
            source_id="api:shodan",
            target="93.184.216.34",
            status="ok",
            input_type="ip",
            status_code=200,
            data={
                "data": [
                    {
                        "port": 443,
                        "hostnames": ["www.example.com"],
                    }
                ]
            },
        ),
    )

    assert {"type": "breach", "value": "ExampleBreach"} in hibp_norm["entities"]
    assert hibp_norm["timeline"][0]["kind"] == "breached"
    assert {"type": "ip", "value": "93.184.216.34"} in urlscan_norm["entities"]
    assert urlscan_norm["timeline"][0]["kind"] == "url_scanned"
    assert {"type": "company", "value": "ExampleNet"} in abuse_norm["entities"]
    assert any(row["type"] == "threat_verdict" for row in abuse_norm["entities"])
    assert {"type": "actor", "value": "Example Scanner"} in greynoise_norm["entities"]
    assert greynoise_norm["timeline"][0]["kind"] == "last_seen"
    assert {"type": "service", "value": "93.184.216.34:443"} in shodan_norm["entities"]
    assert {"type": "domain", "value": "www.example.com"} in shodan_norm["entities"]


def test_v17_p1_source_contract_fixtures_cover_keyed_threat_and_dns_sources():
    cases = [
        ({"id": "shodan", "name": "Shodan", "inputs": ["ip"]}, "8.8.8.8", "ip", _source_fixture("shodan"), ("service", "8.8.8.8:443")),
        ({"id": "censys", "name": "Censys", "inputs": ["ip"]}, "8.8.8.8", "ip", _source_fixture("censys"), ("service", "8.8.8.8:443")),
        ({"id": "securitytrails", "name": "SecurityTrails", "inputs": ["domain"]}, "example.com", "domain", _source_fixture("securitytrails"), ("domain", "api.example.com")),
        ({"id": "greynoise", "name": "GreyNoise", "inputs": ["ip"]}, "203.0.113.10", "ip", _source_fixture("greynoise"), ("actor", "Example Scanner")),
        ({"id": "alienvault_otx", "name": "OTX", "inputs": ["domain"]}, "example.com", "domain", _source_fixture("alienvault_otx"), ("validation", "validated_example")),
        ({"id": "threatfox", "name": "ThreatFox", "inputs": ["ip"]}, "203.0.113.10", "ip", _source_fixture("threatfox"), ("malware_family", "ExampleMalware")),
    ]

    for source, target, input_type, payload, expected in cases:
        normalized = parse_specialized(
            source,
            AdapterResult(
                source_id=f"api:{source['id']}",
                target=target,
                status="ok",
                input_type=input_type,
                status_code=200,
                data=payload,
            ),
        )
        assert {"type": expected[0], "value": expected[1]} in normalized["entities"]
        assert normalized["findings"][0]["confidence"] > 0


def test_v17_dns_parser_classifies_ip_domain_and_dns_record_answers():
    normalized = parse_specialized(
        {"id": "google_dns", "name": "Google DNS", "inputs": ["domain"]},
        AdapterResult(
            source_id="api:google_dns",
            target="example.com",
            status="ok",
            input_type="domain",
            status_code=200,
            data={
                "Answer": [
                    {"type": 1, "data": "93.184.216.34"},
                    {"type": 5, "data": "www.example.com."},
                    {"type": 16, "data": "v=spf1 include:example.net -all"},
                ]
            },
        ),
    )

    assert {"type": "ip", "value": "93.184.216.34"} in normalized["entities"]
    assert {"type": "domain", "value": "www.example.com"} in normalized["entities"]
    assert {"type": "dns_record", "value": "16:v=spf1 include:example.net -all"} in normalized["entities"]
    assert {
        "src_type": "domain",
        "src_value": "example.com",
        "rel": "dns_answer",
        "dst_type": "ip",
        "dst_value": "93.184.216.34",
    } in normalized["relations"]


def test_v17_new_runtime_catalog_sources_have_typed_parsers():
    catalog = load_catalog()
    ids = {row["id"] for row in catalog["api_sources"]}
    entries = {row.id: row for row in registry_entries()}

    for source_id in {
        "cloudflare_dns",
        "threatfox",
        "malwarebazaar",
        "gdelt",
        "common_crawl",
        "builtwith",
        "wappalyzer",
        "github_search",
        "youtube",
        "google_cse",
    }:
        assert source_id in ids
        assert entries[f"api:{source_id}"].source_maturity == "typed_parser"


def test_v18_search_and_media_api_fixtures_have_typed_parsers():
    cases = [
        ({"id": "github_search", "name": "GitHub Search API", "inputs": ["query"]}, "alice@example.com", "query", _source_fixture("github_search"), ("repository", "example/repo")),
        ({"id": "youtube", "name": "YouTube Data API", "inputs": ["query"]}, "example channel", "query", _source_fixture("youtube"), ("youtube_video", "abc123")),
        ({"id": "google_cse", "name": "Google CSE", "inputs": ["query"]}, "example report", "query", _source_fixture("google_cse"), ("url", "https://www.example.com/report")),
    ]

    for source, target, input_type, payload, expected in cases:
        normalized = parse_specialized(
            source,
            AdapterResult(
                source_id=f"api:{source['id']}",
                target=target,
                status="ok",
                input_type=input_type,
                status_code=200,
                data=payload,
            ),
        )
        assert {"type": expected[0], "value": expected[1]} in normalized["entities"]
        assert normalized["findings"][0]["confidence"] > 0


def test_v18_search_and_media_sources_verify_with_fixtures():
    for source_id in ("api:github_search", "api:youtube", "api:google_cse"):
        result = verify_sources(mode="fixture", source_id=source_id, fixture_dir=FIXTURE_ROOT)
        assert result["summary"]["passed"] == 1
        assert result["results"][0]["normalized_counts"]["entities"] >= 1


def test_v17_p2_source_contract_fixtures_cover_public_dataset_and_technology_sources():
    cases = [
        ({"id": "malwarebazaar", "name": "MalwareBazaar", "inputs": ["hash"]}, "a" * 64, "hash", _source_fixture("malwarebazaar"), ("malware_family", "ExampleMalware")),
        ({"id": "gdelt", "name": "GDELT", "inputs": ["query"]}, "Example Inc", "query", _source_fixture("gdelt"), ("url", "https://news.example/article")),
        ({"id": "common_crawl", "name": "Common Crawl", "inputs": ["domain"]}, "example.com", "domain", _source_fixture("common_crawl"), ("crawl_id", "CC-MAIN-2024-10")),
        ({"id": "builtwith", "name": "BuiltWith", "inputs": ["domain"]}, "example.com", "domain", _source_fixture("builtwith"), ("technology", "nginx 1.24")),
    ]

    for source, target, input_type, payload, expected in cases:
        normalized = parse_specialized(
            source,
            AdapterResult(
                source_id=f"api:{source['id']}",
                target=target,
                status="ok",
                input_type=input_type,
                status_code=200,
                data=payload,
            ),
        )
        assert {"type": expected[0], "value": expected[1]} in normalized["entities"]
        assert normalized["findings"][0]["confidence"] > 0


def test_v14_source_specific_parsers_cover_location_fediverse_and_social_intel():
    mastodon = {"id": "mastodon_lookup", "name": "Mastodon", "inputs": ["username"]}
    nominatim = {"id": "nominatim", "name": "Nominatim", "inputs": ["address"]}
    open_measures = {"id": "open_measures", "name": "Open Measures", "inputs": ["query"]}

    mastodon_norm = parse_specialized(
        mastodon,
        AdapterResult(
            source_id="api:mastodon_lookup",
            target="alice@mastodon.social",
            status="ok",
            input_type="username",
            url="https://mastodon.social/@alice",
            status_code=200,
            data={
                "id": "109876",
                "acct": "alice",
                "username": "alice",
                "url": "https://mastodon.social/@alice",
                "display_name": "Alice",
                "created_at": "2023-01-02T00:00:00Z",
            },
        ),
    )
    nominatim_norm = parse_specialized(
        nominatim,
        AdapterResult(
            source_id="api:nominatim",
            target="Berlin, Germany",
            status="ok",
            input_type="address",
            url="https://nominatim.openstreetmap.org/search",
            status_code=200,
            data=[
                {
                    "display_name": "Berlin, Germany",
                    "osm_type": "relation",
                    "osm_id": 62422,
                    "lat": "52.517",
                    "lon": "13.388",
                    "class": "boundary",
                    "type": "administrative",
                    "boundingbox": ["52.3", "52.7", "13.0", "13.7"],
                }
            ],
        ),
    )
    open_measures_norm = parse_specialized(
        open_measures,
        AdapterResult(
            source_id="api:open_measures",
            target="acme narrative",
            status="ok",
            input_type="query",
            url="https://api.openmeasures.io/",
            status_code=200,
            data={
                "results": [
                    {
                        "platform": "telegram",
                        "author": "alice",
                        "id": "post-1",
                        "url": "https://t.me/example/1",
                        "text": "acme narrative mention",
                        "narrative": "brand rumor",
                        "created_at": "2024-03-04T12:00:00Z",
                    }
                ]
            },
        ),
    )

    assert {"type": "username", "value": "alice@mastodon.social"} in mastodon_norm["entities"]
    assert {"type": "stable_id", "value": "109876"} in mastodon_norm["entities"]
    assert mastodon_norm["timeline"][0]["kind"] == "profile_created"
    assert {"type": "location", "value": "Berlin, Germany"} in nominatim_norm["entities"]
    assert {"type": "osm_id", "value": "relation/62422"} in nominatim_norm["entities"]
    assert {"type": "geo", "value": "52.517,13.388"} in nominatim_norm["entities"]
    assert {"type": "social_platform", "value": "telegram"} in open_measures_norm["entities"]
    assert {"type": "social_post", "value": "telegram:post-1"} in open_measures_norm["entities"]
    assert open_measures_norm["timeline"][0]["kind"] == "social_post_observed"
    assert any(row["rel"] == "matches_social_post" for row in open_measures_norm["relations"])


def test_username_profile_parser_treats_profile_url_as_record():
    source = {"id": "hackernews", "name": "Hacker News", "inputs": ["username"]}
    normalized = parse_specialized(
        source,
        AdapterResult(
            source_id="api:hackernews",
            target="alice",
            status="ok",
            input_type="username",
            url="https://news.ycombinator.com/user?id=alice",
            status_code=200,
            data={"url": "https://news.ycombinator.com/user?id=alice"},
        ),
    )

    finding = normalized["findings"][0]
    assert finding["status"] == "exists"
    assert finding["reject_reason"] == ""
    assert finding["confidence"] > 0
    assert {"type": "profile", "value": "https://news.ycombinator.com/user?id=alice"} in normalized["entities"]


def test_normalizer_respects_specialized_parser_status():
    result = AdapterResult(
        source_id="api:gitlab",
        target="missing-user",
        status="ok",
        input_type="username",
        url="https://gitlab.com/api/v4/users?username=missing-user",
        status_code=200,
        normalized={
            "entities": [{"type": "username", "value": "missing-user"}],
            "relations": [],
            "findings": [
                {
                    "status": "not_exists",
                    "confidence": 0.0,
                    "reject_reason": "no profile record",
                }
            ],
            "timeline": [],
        },
    )

    record = normalize_adapter_result(result)

    assert record.status == "not_exists"
    assert record.confidence == 0.0
    assert record.reject_reason == "no profile record"


def test_v12_source_pipeline_orchestrates_normalized_adapter_results(monkeypatch):
    from bedniiosint.core import source_pipeline

    def fake_run_source(source_id: str, target: str, **kwargs):
        normalized = {
            "entities": [
                {"type": kwargs["input_type"], "value": target},
                {"type": "source", "value": source_id},
            ],
            "relations": [
                {
                    "src_type": kwargs["input_type"],
                    "src_value": target,
                    "rel": "queried_in",
                    "dst_type": "source",
                    "dst_value": source_id,
                }
            ],
            "findings": [
                {
                    "source_id": source_id,
                    "entity_type": kwargs["input_type"],
                    "entity_value": target,
                    "status": "exists",
                    "confidence": 0.8,
                }
            ],
            "timeline": [],
            "raw": {"ok": True},
        }
        return AdapterResult(
            source_id=source_id,
            target=target,
            status="ok",
            input_type=kwargs["input_type"],
            status_code=200,
            normalized=normalized,
        )

    monkeypatch.setattr(source_pipeline, "run_source", fake_run_source)

    result = source_pipeline.run_source_pipeline(
        "example.com",
        input_type="domain",
        source_ids=["api:crtsh", "api:rdap"],
    ).as_dict()

    assert result["sources"] == ["api:crtsh", "api:rdap"]
    assert result["counts"]["ok"] == 2
    assert result["counts"]["entities"] == 4
    assert result["normalized"][0]["confidence"] == 0.8


def test_v25_domain_pipeline_includes_cloudflare_and_dns_corroboration(monkeypatch):
    from bedniiosint.core import source_pipeline

    def fake_run_source(source_id: str, target: str, **kwargs):
        answer = "93.184.216.34" if source_id in {"api:google_dns", "api:cloudflare_dns"} else "203.0.113.50"
        normalized = {
            "entities": [
                {"type": "domain", "value": target},
                {"type": "ip", "value": answer},
            ],
            "relations": [
                {
                    "src_type": "domain",
                    "src_value": target,
                    "rel": "dns_answer",
                    "dst_type": "ip",
                    "dst_value": answer,
                }
            ],
            "findings": [
                {
                    "source_id": source_id,
                    "entity_type": "domain",
                    "entity_value": target,
                    "status": "exists",
                    "confidence": 0.78,
                }
            ],
            "timeline": [],
            "raw": {"answer": answer},
        }
        return AdapterResult(
            source_id=source_id,
            target=target,
            status="ok",
            input_type=kwargs["input_type"],
            status_code=200,
            normalized=normalized,
        )

    monkeypatch.setattr(source_pipeline, "run_source", fake_run_source)

    sources = source_pipeline.pipeline_sources("domain")
    result = source_pipeline.run_source_pipeline(
        "example.com",
        input_type="domain",
        source_ids=["api:google_dns", "api:cloudflare_dns", "api:hackertarget"],
    ).as_dict()

    google = next(row for row in result["normalized"] if row["source_id"] == "api:google_dns")
    cloudflare = next(row for row in result["normalized"] if row["source_id"] == "api:cloudflare_dns")

    assert sources.index("api:cloudflare_dns") > sources.index("api:google_dns")
    assert {"type": "dns_corroboration", "value": "google_dns+cloudflare_dns:1"} in google["entities"]
    assert {"type": "dns_corroboration", "value": "google_dns+cloudflare_dns:1"} in cloudflare["entities"]
    assert {
        "src_type": "dns_corroboration",
        "src_value": "google_dns+cloudflare_dns:1",
        "rel": "matches_dns_answer",
        "dst_type": "ip",
        "dst_value": "93.184.216.34",
    } in google["relations"]
    assert google["timeline"][0]["kind"] == "dns_resolver_corroborated"
    assert "dns_corroboration" not in {
        entity["type"]
        for row in result["normalized"]
        if row["source_id"] == "api:hackertarget"
        for entity in row["entities"]
    }


def test_v13_pipeline_sources_include_keyed_aggregator_when_configured(monkeypatch):
    from bedniiosint.core.source_pipeline import pipeline_sources

    monkeypatch.delenv("OSINTLY_API_KEY", raising=False)
    monkeypatch.delenv("OPEN_MEASURES_API_KEY", raising=False)

    assert {"api:crtsh", "api:rdap", "api:hackertarget", "api:securitytrails"} <= set(
        pipeline_sources("domain")
    )
    assert {"api:ipwhois", "api:bgpview", "api:shodan", "api:abuseipdb"} <= set(
        pipeline_sources("ip")
    )
    assert {"api:blockchain_info", "api:blockstream", "api:blockchair"} <= set(
        pipeline_sources("wallet")
    )
    assert {"api:opencorporates", "api:companies_house", "api:wikidata"} <= set(
        pipeline_sources("company")
    )
    assert {"api:urlscan", "api:wayback_cdx", "api:virustotal", "api:urlhaus"} <= set(
        pipeline_sources("url")
    )
    assert "api:osintly_api" in pipeline_sources("email")
    assert "api:osintly_api" in pipeline_sources("phone")
    assert "api:osintly_api" not in pipeline_sources("email", available_only=True)
    assert pipeline_sources("address") == ["api:nominatim", "api:osintly_api"]
    assert pipeline_sources("place") == ["api:nominatim", "api:osintly_api"]
    assert {
        "api:gdelt",
        "api:github_search",
        "api:youtube",
        "api:google_cse",
        "api:open_measures",
        "api:osintly_api",
    } <= set(pipeline_sources("query"))
    assert pipeline_sources("image_url") == ["api:tineye"]
    assert pipeline_sources("fediverse_account") == ["api:mastodon_lookup"]
    available_query_sources = set(pipeline_sources("query", available_only=True))
    assert "api:gdelt" in available_query_sources
    assert "api:open_measures" not in available_query_sources
    assert "api:osintly_api" not in available_query_sources

    monkeypatch.setenv("OSINTLY_API_KEY", "configured")
    monkeypatch.setenv("OPEN_MEASURES_API_KEY", "configured")

    assert "api:osintly_api" in pipeline_sources("email", available_only=True)
    assert "api:osintly_api" in pipeline_sources("wallet", available_only=True)
    configured_query_sources = set(pipeline_sources("query", available_only=True))
    assert {"api:gdelt", "api:open_measures", "api:osintly_api"} <= configured_query_sources


def test_v12_source_pipeline_save_persists_one_aggregate_case(tmp_path, monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.core import source_pipeline
    from bedniiosint.core.case_workspace import get_workspace

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)

    def fake_run_source(source_id: str, target: str, **kwargs):
        suffix = source_id.rsplit(":", 1)[-1]
        normalized = {
            "entities": [
                {"type": kwargs["input_type"], "value": target},
                {"type": "domain", "value": f"{suffix}.example.com"},
            ],
            "relations": [
                {
                    "src_type": kwargs["input_type"],
                    "src_value": target,
                    "rel": "mentions_domain",
                    "dst_type": "domain",
                    "dst_value": f"{suffix}.example.com",
                }
            ],
            "findings": [
                {
                    "source_id": source_id,
                    "entity_type": kwargs["input_type"],
                    "entity_value": target,
                    "status": "exists",
                    "confidence": 0.82,
                }
            ],
            "timeline": [
                {
                    "kind": "adapter_observed",
                    "entity_type": kwargs["input_type"],
                    "entity_value": target,
                    "source": source_id,
                    "confidence": 0.82,
                }
            ],
            "raw": {"source": source_id},
        }
        return AdapterResult(
            source_id=source_id,
            target=target,
            status="ok",
            input_type=kwargs["input_type"],
            url=f"https://api.example.test/{suffix}",
            status_code=200,
            headers={"x-source": suffix},
            normalized=normalized,
        )

    monkeypatch.setattr(source_pipeline, "run_source", fake_run_source)
    try:
        result = source_pipeline.run_source_pipeline(
            "example.com",
            input_type="domain",
            source_ids=["api:crtsh", "api:rdap"],
            save=True,
            case_name="pipeline-case",
        ).as_dict()
        workspace = get_workspace("pipeline-case")

        assert result["persisted_case"]["counts"]["findings"] == 2
        assert result["persisted_case"]["counts"]["sources"] == 2
        assert workspace["counts"]["findings"] == 2
        assert workspace["counts"]["evidence"] == 2
        assert workspace["counts"]["relations"] >= 2
        assert {row["confidence"] for row in workspace["findings"]} == {0.87}
        assert all(
            "universal:independent_sources:+0.05:2" in row["matched_markers"]
            for row in workspace["findings"]
        )
        assert {row["headers"]["x-source"] for row in workspace["evidence"]} == {
            "crtsh",
            "rdap",
        }
        assert {row["source"] for row in workspace["timeline"]} == {
            "api:crtsh",
            "api:rdap",
        }
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v13_source_pipeline_captures_html_adapter_evidence(tmp_path, monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.core import source_pipeline
    from bedniiosint.core.case_workspace import get_workspace

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)

    def fake_run_source(source_id: str, target: str, **kwargs):
        normalized = {
            "entities": [{"type": kwargs["input_type"], "value": target}],
            "relations": [],
            "findings": [
                {
                    "source_id": source_id,
                    "entity_type": kwargs["input_type"],
                    "entity_value": target,
                    "status": "exists",
                    "confidence": 0.7,
                }
            ],
            "timeline": [],
            "raw": {"source": source_id},
        }
        return AdapterResult(
            source_id=source_id,
            target=target,
            status="ok",
            input_type=kwargs["input_type"],
            method="POST",
            url="https://example.test/page",
            status_code=200,
            text="<html><body>adapter html</body></html>",
            headers={"content-type": "text/html; charset=utf-8"},
            normalized=normalized,
        )

    monkeypatch.setattr(source_pipeline, "run_source", fake_run_source)
    try:
        result = source_pipeline.run_source_pipeline(
            "example.com",
            input_type="domain",
            source_ids=["api:crtsh"],
            save=True,
            case_name="html-pipeline",
        ).as_dict()
        workspace = get_workspace("html-pipeline")

        assert result["persisted_case"]["counts"]["evidence"] == 2
        assert {row["kind"] for row in workspace["attachments"]} == {
            "raw_json",
            "html_snapshot",
        }
        assert {row["content_type"] for row in workspace["evidence"]} == {
            "application/json",
            "text/html",
        }
        assert {row["method"] for row in workspace["evidence"]} == {"POST"}
        assert all(row["headers"]["content-type"] == "text/html; charset=utf-8" for row in workspace["evidence"])
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v10_adapter_parser_outputs_normalized_sections():
    source = {
        "id": "demo",
        "name": "Demo API",
        "inputs": ["domain"],
        "category": ["domain"],
        "auth": "none",
    }
    result = AdapterResult(
        source_id="api:demo",
        target="example.com",
        status="ok",
        input_type="domain",
        url="https://api.example.test/search?domain=example.com",
        status_code=200,
        data={"profile": "https://example.com/alice", "email": "alice@example.com"},
    )
    normalized = CatalogResponseParser(source).parse(result)
    result.normalized = normalized.as_dict()
    record = normalize_adapter_result(result)

    assert {"type": "domain", "value": "example.com"} in normalized.entities
    assert any(row["type"] == "email" and row["value"] == "alice@example.com" for row in normalized.entities)
    assert normalized.findings[0]["status"] == "exists"
    assert normalized.timeline[0]["kind"] == "adapter_observed"
    assert record.timeline[0]["source"] == "api:demo"
    assert record.confidence >= 0.75


def test_v10_adapter_health_contract_for_missing_keys(monkeypatch):
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)
    adapter = adapter_for("api:shodan")
    health = adapter.health_check(target="example.com")
    public = adapter_health("api:shodan", target="example.com")

    assert health.status == "missing_keys"
    assert health.missing_env == ["SHODAN_API_KEY"]
    assert public["status"] == "missing_keys"


def test_v13_catalog_adapter_health_uses_live_probe_without_parsing(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    calls = []

    class FakeResponse:
        def __init__(self, status_code: int, url: str):
            self.status_code = status_code
            self.url = url

    def fake_request(method: str, url: str):
        calls.append((method, url))
        return FakeResponse(404, url)

    monkeypatch.setattr(adapters, "request", fake_request)

    health = adapter_for("api:crtsh").health_check(target="missing.example")

    assert health.status == "available"
    assert health.status_code == 404
    assert health.latency_ms is not None
    assert calls == [("GET", "https://crt.sh/?q=%25.missing.example&output=json")]


def test_v13_catalog_adapter_health_classifies_server_errors(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    class FakeResponse:
        status_code = 503
        url = "https://crt.sh/"

    monkeypatch.setattr(adapters, "request", lambda method, url: FakeResponse())

    health = adapter_for("api:crtsh").health_check(target="example.com")

    assert health.status == "error"
    assert health.status_code == 503
    assert health.error == "HTTP 503"


def test_v13_catalog_adapter_health_missing_keys_skips_probe(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    monkeypatch.delenv("SHODAN_API_KEY", raising=False)

    def fail_request(method: str, url: str):
        raise AssertionError("missing-key health check must not probe network")

    monkeypatch.setattr(adapters, "request", fail_request)

    health = adapter_for("api:shodan").health_check()

    assert health.status == "missing_keys"
    assert health.status_code is None
    assert health.missing_env == ["SHODAN_API_KEY"]


def test_v15_catalog_adapter_uses_source_context_cache(tmp_path, monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    calls = []

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json"}
        text = ""
        url = "https://crt.sh/?q=%25.example.com&output=json"

        def json(self):
            return [{"name_value": "www.example.com"}]

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setattr(adapters, "request", fake_request)
    context = SourceRunContext(
        cache_enabled=True,
        cache_ttl_seconds=60,
        cache_dir=tmp_path,
        request_budget={"api:crtsh": 2},
    )

    first = adapter_for("api:crtsh").run("example.com", input_type="domain", context=context)
    second = adapter_for("api:crtsh").run("example.com", input_type="domain", context=context)

    assert first.status == "ok"
    assert not first.cache_hit
    assert second.status == "ok"
    assert second.cache_hit
    assert len(calls) == 1
    assert context.budget_remaining("api:crtsh") == 1
    assert {"type": "domain", "value": "www.example.com"} in second.normalized["entities"]


def test_source_context_cache_respects_provider_max_age(tmp_path, monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    calls = []

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json", "cache-control": "max-age=1"}
        text = ""
        url = "https://crt.sh/?q=%25.example.com&output=json"

        def json(self):
            return [{"name_value": "www.example.com"}]

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setattr(adapters, "request", fake_request)
    context = SourceRunContext(
        cache_enabled=True,
        cache_ttl_seconds=60,
        cache_dir=tmp_path,
    )

    first = adapter_for("api:crtsh").run("example.com", input_type="domain", context=context)
    second = adapter_for("api:crtsh").run("example.com", input_type="domain", context=context)
    cached_records = list(tmp_path.rglob("*.json"))
    payload = json.loads(cached_records[0].read_text(encoding="utf-8"))

    assert first.status == "ok"
    assert second.cache_hit
    assert len(calls) == 1
    assert payload["cache_ttl_seconds"] == 1
    assert payload["cache_control"] == "max-age=1"


def test_source_context_cache_respects_no_store(tmp_path, monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    calls = []

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json", "cache-control": "no-store"}
        text = ""
        url = "https://crt.sh/?q=%25.example.com&output=json"

        def json(self):
            return [{"name_value": "www.example.com"}]

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setattr(adapters, "request", fake_request)
    context = SourceRunContext(
        cache_enabled=True,
        cache_ttl_seconds=60,
        cache_dir=tmp_path,
    )

    first = adapter_for("api:crtsh").run("example.com", input_type="domain", context=context)
    second = adapter_for("api:crtsh").run("example.com", input_type="domain", context=context)

    assert first.status == "ok"
    assert not first.cache_hit
    assert second.status == "ok"
    assert not second.cache_hit
    assert len(calls) == 2
    assert list(tmp_path.rglob("*.json")) == []


def test_source_context_cache_redacts_secrets_on_disk(tmp_path, monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    class FakeResponse:
        status_code = 200
        headers = {
            "content-type": "application/json",
            "set-cookie": "session=secret-cookie",
            "x-source": "demo",
        }
        text = ""
        url = "https://crt.sh/?q=%25.example.com&output=json"

        def json(self):
            return {
                "name_value": "www.example.com",
                "api_key": "secret-value",
                "nested": {"token": "another-secret"},
            }

    def fake_request(method: str, url: str, **kwargs):
        return FakeResponse()

    monkeypatch.setattr(adapters, "request", fake_request)
    context = SourceRunContext(
        cache_enabled=True,
        cache_ttl_seconds=60,
        cache_dir=tmp_path,
    )

    result = adapter_for("api:crtsh").run(
        "example.com",
        input_type="domain",
        context=context,
    )
    payload = json.loads(next(tmp_path.rglob("*.json")).read_text(encoding="utf-8"))

    assert result.status == "ok"
    assert "secret-value" not in json.dumps(payload)
    assert "another-secret" not in json.dumps(payload)
    assert "secret-cookie" not in json.dumps(payload)
    assert payload["headers"]["set-cookie"] == "sess...[redacted]"
    assert payload["headers"]["x-source"] == "demo"
    assert payload["data"]["api_key"] == "secr...[redacted]"
    assert payload["data"]["nested"]["token"] == "anot...[redacted]"


def test_source_context_cache_ttl_can_be_set_per_source(tmp_path, monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json"}
        text = ""
        url = "https://crt.sh/?q=%25.example.com&output=json"

        def json(self):
            return [{"name_value": "www.example.com"}]

    monkeypatch.setattr(adapters, "request", lambda method, url, **kwargs: FakeResponse())
    context = SourceRunContext(
        cache_enabled=True,
        cache_ttl_seconds=0,
        cache_ttl_by_source=parse_cache_ttl_by_source("crtsh=45"),
        cache_dir=tmp_path,
    )

    first = adapter_for("api:crtsh").run("example.com", input_type="domain", context=context)
    second = adapter_for("api:crtsh").run("example.com", input_type="domain", context=context)
    payload = json.loads(next(tmp_path.rglob("*.json")).read_text(encoding="utf-8"))

    assert first.status == "ok"
    assert second.cache_hit
    assert payload["cache_ttl_seconds"] == 45


def test_source_cache_ttl_presets_use_source_policy_and_allow_overrides():
    presets = source_cache_ttl_presets(["api:crtsh", "api:shodan"])
    merged = merge_cache_ttl_presets({"api:crtsh": 45}, source_ids=["api:crtsh", "api:shodan"])

    assert presets["api:crtsh"] == 3600
    assert presets["api:shodan"] == 86400
    assert merged["api:crtsh"] == 45
    assert merged["api:shodan"] == 86400


def test_v15_catalog_adapter_budget_exhaustion_skips_network(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    def fail_request(method: str, url: str, **kwargs):
        raise AssertionError("budget-exhausted source must not call network")

    monkeypatch.setattr(adapters, "request", fail_request)
    context = SourceRunContext(request_budget={"api:crtsh": 0})

    result = adapter_for("api:crtsh").run("example.com", input_type="domain", context=context)

    assert result.status == "rate_limited"
    assert result.status_code is None
    assert "source budget exhausted" in result.error


def test_v23_rate_limit_budget_presets_and_wildcard_are_per_source():
    from bedniiosint.core.jobs import rate_limit_budget_presets, resolve_rate_limit_budget
    from bedniiosint.core.source_context import SourceBudgetExceeded

    budget = resolve_rate_limit_budget("api:crtsh=1", preset="conservative")
    presets = rate_limit_budget_presets()

    assert presets["smoke"]["api:shodan"] == 1
    assert presets["conservative"]["api:censys"] == 1
    assert presets["standard"]["api:virustotal"] == 2
    assert presets["standard"]["api:github"] == 5
    assert budget["*"] == 2
    assert budget["api:shodan"] == 1
    assert budget["api:censys"] == 1
    assert budget["api:crtsh"] == 1

    context = SourceRunContext(request_budget=budget)
    assert context.consume_budget("api:crtsh") == 0
    assert context.budget_remaining("api:rdap") == 2
    assert context.consume_budget("api:rdap") == 1
    assert context.budget_remaining("api:google_dns") == 2
    try:
        context.consume_budget("api:crtsh")
    except SourceBudgetExceeded:
        pass
    else:
        raise AssertionError("source-specific override should be exhausted")


def test_v23_budget_presets_cli_prints_provider_specific_limits():
    from typer.testing import CliRunner

    from bedniiosint.cli import app

    result = CliRunner().invoke(app, ["budget-presets"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["conservative"]["api:shodan"] == 1
    assert payload["standard"]["api:virustotal"] == 2
    assert payload["standard"]["api:github"] == 5


def test_v18_search_api_auth_uses_provider_specific_params(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    calls = []

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json"}
        text = ""
        url = "https://www.googleapis.com/customsearch/v1?q=example"

        def json(self):
            return {"items": []}

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setenv("GOOGLE_CSE_API_KEY", "cse-key")
    monkeypatch.setenv("GOOGLE_CSE_CX", "engine-id")
    monkeypatch.setenv("YOUTUBE_API_KEY", "youtube-key")
    monkeypatch.setattr(adapters, "request", fake_request)

    cse = adapter_for("api:google_cse").run("example", input_type="query")
    youtube = adapter_for("api:youtube").run("example", input_type="query")

    assert cse.status == "ok"
    assert youtube.status == "ok"
    assert calls[0][2]["params"] == {"key": "cse-key", "cx": "engine-id"}
    assert calls[1][2]["params"] == {"key": "youtube-key"}


def test_common_crawl_adapter_discovers_cdx_endpoint_and_queries_target(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    calls = []

    class FakeResponse:
        def __init__(self, url: str, data=None, text: str = "", content_type: str = "application/json"):
            self.status_code = 200
            self.headers = {"content-type": content_type}
            self.text = text
            self.url = url
            self._data = data

        def json(self):
            return self._data

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/collinfo.json"):
            return FakeResponse(
                url,
                data=[{"id": "CC-MAIN-2026-01", "cdx-api": "https://index.commoncrawl.org/CC-MAIN-2026-01-index?"}],
            )
        return FakeResponse(
            url,
            text='{"url":"https://www.example.com/about","status":"200","timestamp":"20260101000000","mime":"text/html"}\n',
            content_type="text/plain",
        )

    monkeypatch.setattr(adapters, "request", fake_request)

    result = adapter_for("api:common_crawl").run("example.com", input_type="domain")

    assert result.status == "ok"
    assert calls[0][1] == "https://index.commoncrawl.org/collinfo.json"
    assert calls[1][1] == "https://index.commoncrawl.org/CC-MAIN-2026-01-index"
    assert calls[1][2]["params"]["url"] == "*.example.com/*"
    assert calls[1][2]["params"]["output"] == "json"
    assert calls[1][2]["params"]["filter"] == "status:200"
    assert {"type": "url", "value": "https://www.example.com/about"} in result.normalized["entities"]
    assert result.normalized["findings"][0]["finding_type"] == "crawl_index"


def test_v15_catalog_adapter_scope_blocks_medium_risk_before_network(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    monkeypatch.delenv("SHODAN_API_KEY", raising=False)

    def fail_request(method: str, url: str, **kwargs):
        raise AssertionError("scope-blocked source must not call network")

    monkeypatch.setattr(adapters, "request", fail_request)
    context = SourceRunContext(legal_flags={"public_only": True})

    result = adapter_for("api:shodan").run("8.8.8.8", input_type="ip", context=context)

    assert result.status == "blocked_by_scope"
    assert result.missing_env == []
    assert "public_only" in result.error


def test_policy_catalog_blocks_sensitive_source_before_network(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    def fail_request(method: str, url: str, **kwargs):
        raise AssertionError("policy-blocked source must not call network")

    monkeypatch.setattr(adapters, "request", fail_request)
    context = SourceRunContext()

    result = adapter_for("api:twilio_lookup").run(
        "+15551234567",
        input_type="phone",
        context=context,
    )

    assert result.status == "blocked_by_scope"
    assert result.missing_env == []
    assert "explicit opt-in" in result.error


def test_upload_policy_allows_urlscan_lookup_but_blocks_submission(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    calls = []

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json"}
        text = ""
        url = "https://urlscan.io/api/v1/search/?q=domain:example.com"

        def json(self):
            return {"results": []}

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.delenv("URLSCAN_API_KEY", raising=False)
    monkeypatch.setattr(adapters, "request", fake_request)
    context = SourceRunContext()

    lookup = adapter_for("api:urlscan").run("example.com", input_type="domain", context=context)
    submission = adapter_for("api:urlscan").run("https://example.com/", input_type="url", context=context)

    assert lookup.status == "ok"
    assert calls[0][0] == "GET"
    assert submission.status == "blocked_by_scope"
    assert "submission/upload" in submission.error


def test_upload_policy_allows_urlscan_submission_with_explicit_opt_in(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    calls = []

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json"}
        text = ""
        url = "https://urlscan.io/api/v1/scan/"

        def json(self):
            return {
                "uuid": "scan-id",
                "api": "https://urlscan.io/api/v1/result/scan-id/",
                "result": "https://urlscan.io/result/scan-id/",
            }

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setenv("URLSCAN_API_KEY", "urlscan-secret")
    monkeypatch.setattr(adapters, "request", fake_request)
    context = SourceRunContext(legal_flags={"allow_uploads": True})

    result = adapter_for("api:urlscan").run("https://example.com/", input_type="url", context=context)

    assert result.status == "ok"
    assert result.method == "POST"
    assert calls[0][0] == "POST"
    assert calls[0][2]["headers"]["API-Key"] == "urlscan-secret"
    assert calls[0][2]["json"] == {"url": "https://example.com/", "visibility": "unlisted"}
    assert "urlscan-secret" not in str(result.as_dict())


def test_upload_policy_blocks_virustotal_file_upload_without_context(monkeypatch, tmp_path):
    import bedniiosint.catalog.adapters as adapters

    sample = tmp_path / "sample.bin"
    sample.write_bytes(b"sample upload")

    def fail_request(method: str, url: str, **kwargs):
        raise AssertionError("file upload must not call network without allow_uploads context")

    monkeypatch.setenv("VIRUSTOTAL_API_KEY", "vt-secret")
    monkeypatch.setattr(adapters, "request", fail_request)

    result = adapter_for("api:virustotal").run(str(sample), input_type="file")

    assert result.status == "blocked_by_scope"
    assert result.method == "POST"
    assert result.url == "https://www.virustotal.com/api/v3/files"
    assert "submission/upload" in result.error
    assert "vt-secret" not in str(result.as_dict())


def test_upload_policy_allows_virustotal_file_upload_with_explicit_opt_in(monkeypatch, tmp_path):
    import bedniiosint.catalog.adapters as adapters

    calls = []
    payload = b"sample upload"
    expected_sha256 = hashlib.sha256(payload).hexdigest()
    sample = tmp_path / "sample.bin"
    sample.write_bytes(payload)

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json"}
        text = ""
        url = "https://www.virustotal.com/api/v3/files"

        def json(self):
            return {
                "data": {
                    "id": "analysis-abc123",
                    "type": "analysis",
                    "links": {
                        "self": "https://www.virustotal.com/api/v3/analyses/analysis-abc123"
                    },
                }
            }

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setenv("VIRUSTOTAL_API_KEY", "vt-secret")
    monkeypatch.setattr(adapters, "request", fake_request)
    context = SourceRunContext(legal_flags={"allow_uploads": True})

    result = adapter_for("api:virustotal").run(str(sample), input_type="file", context=context)

    assert result.status == "ok"
    assert result.method == "POST"
    assert calls[0][0] == "POST"
    assert calls[0][1] == "https://www.virustotal.com/api/v3/files"
    assert calls[0][2]["headers"]["x-apikey"] == "vt-secret"
    filename, content, mime = calls[0][2]["files"]["file"]
    assert filename == "sample.bin"
    assert content == payload
    assert mime == "application/octet-stream"
    assert result.data["_bedniiosint_upload"]["sha256"] == expected_sha256
    assert result.normalized["findings"][0]["status"] == "submitted"
    assert {"type": "hash", "value": expected_sha256} in result.normalized["entities"]
    assert any(row["kind"] == "file_submitted" for row in result.normalized["timeline"])
    assert "vt-secret" not in str(result.as_dict())


def test_virustotal_upload_fixture_normalizes_analysis_and_privacy_warning():
    virustotal = {"id": "virustotal", "name": "VirusTotal", "inputs": ["file"]}
    fixture = _source_fixture("virustotal", "upload_ok")

    normalized = parse_specialized(
        virustotal,
        AdapterResult(
            source_id="api:virustotal",
            target="sample.bin",
            status="ok",
            input_type="file",
            status_code=200,
            data=fixture["__data"],
        ),
    )

    assert {"type": "analysis", "value": "analysis-abc123"} in normalized["entities"]
    assert {
        "type": "hash",
        "value": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    } in normalized["entities"]
    assert any(row["type"] == "privacy_warning" for row in normalized["entities"])
    assert normalized["findings"][0]["finding_type"] == "file_upload_virustotal"
    assert normalized["findings"][0]["status"] == "submitted"
    assert normalized["timeline"][0]["kind"] == "file_submitted"


def test_tineye_image_url_lookup_and_fixture_parser(monkeypatch):
    import bedniiosint.catalog.adapters as adapters

    calls = []

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json"}
        text = ""
        url = "https://api.tineye.com/rest/search/?image_url=https://example.test/image.jpg"

        def json(self):
            return _source_fixture("tineye")

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setenv("TINEYE_API_KEY", "tineye-secret")
    monkeypatch.setattr(adapters, "request", fake_request)
    context = SourceRunContext(legal_flags={"allow_sensitive_sources": True})

    result = adapter_for("api:tineye").run(
        "https://example.test/image.jpg",
        input_type="image_url",
        context=context,
    )

    assert result.status == "ok"
    assert result.method == "GET"
    assert calls[0][2]["headers"]["x-api-key"] == "tineye-secret"
    assert {"type": "image_match", "value": "https://images.example.test/match.jpg"} in result.normalized["entities"]
    assert {"type": "url", "value": "https://example.test/article"} in result.normalized["entities"]
    assert any(row["rel"] == "visually_matches" for row in result.normalized["relations"])
    assert result.normalized["findings"][0]["finding_type"] == "reverse_image_match"
    assert result.normalized["timeline"][0]["kind"] == "reverse_image_searched"
    assert "tineye-secret" not in str(result.as_dict())


def test_upload_policy_allows_tineye_image_upload_with_explicit_opt_in(monkeypatch, tmp_path):
    import bedniiosint.catalog.adapters as adapters

    calls = []
    payload = b"fake image"
    sample = tmp_path / "sample.jpg"
    sample.write_bytes(payload)

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "application/json"}
        text = ""
        url = "https://api.tineye.com/rest/search/"

        def json(self):
            return _source_fixture("tineye")

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setenv("TINEYE_API_KEY", "tineye-secret")
    monkeypatch.setattr(adapters, "request", fake_request)

    blocked = adapter_for("api:tineye").run(str(sample), input_type="image")
    context = SourceRunContext(
        legal_flags={"allow_uploads": True, "allow_sensitive_sources": True}
    )
    result = adapter_for("api:tineye").run(str(sample), input_type="image", context=context)

    assert blocked.status == "blocked_by_scope"
    assert "submission/upload" in blocked.error
    assert result.status == "ok"
    assert result.method == "POST"
    assert calls[0][0] == "POST"
    assert calls[0][1] == "https://api.tineye.com/rest/search/"
    assert calls[0][2]["headers"]["x-api-key"] == "tineye-secret"
    filename, content, mime = calls[0][2]["files"]["image_upload"]
    assert filename == "sample.jpg"
    assert content == payload
    assert mime == "image/jpeg"
    assert result.data["_bedniiosint_upload"]["sha256"] == hashlib.sha256(payload).hexdigest()
    assert result.normalized["findings"][0]["finding_type"] == "reverse_image_match"
    assert "tineye-secret" not in str(result.as_dict())


def test_v15_adapter_result_as_dict_redacts_secret_fields():
    result = AdapterResult(
        source_id="api:demo",
        target="example.com",
        status="ok",
        url="https://api.example.test/search?api_key=secret-value&query=example.com",
        error="failed: https://api.example.test/search?token=secret-value",
        headers={"set-cookie": "session=secret", "x-source": "demo"},
        data={"api_key": "secret-value", "nested": {"token": "another-secret"}},
    ).as_dict()

    assert result["url"] == "https://api.example.test/search?api_key=%5Bredacted%5D&query=example.com"
    assert result["error"] == "failed: https://api.example.test/search?token=%5Bredacted%5D"
    assert result["headers"]["set-cookie"] == "sess...[redacted]"
    assert result["headers"]["x-source"] == "demo"
    assert result["data"]["api_key"] == "secr...[redacted]"
    assert result["data"]["nested"]["token"] == "anot...[redacted]"


def test_v15_pipeline_run_api_passes_source_context(monkeypatch):
    import pytest

    import bedniiosint.web.app as web_app

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    captured = {}

    class FakePipelineResult:
        def as_dict(self):
            return {
                "target": "example.com",
                "input_type": "domain",
                "sources": ["api:crtsh"],
                "results": [],
                "normalized": [],
                "persisted": [],
                "persisted_case": {},
                "counts": {
                    "sources": 1,
                    "results": 0,
                    "ok": 0,
                    "missing_keys": 0,
                    "entities": 0,
                    "relations": 0,
                    "timeline": 0,
                },
            }

    def fake_run_source_pipeline(*args, **kwargs):
        captured["context"] = kwargs["context"]
        return FakePipelineResult()

    monkeypatch.setattr(search_router, "run_source_pipeline", fake_run_source_pipeline)
    endpoint = next(
        route.endpoint
        for route in web_app.app.routes
        if getattr(route, "path", "") == "/pipeline/run"
    )

    response = endpoint(
        target="example.com",
        input_type="domain",
        sources="api:crtsh",
        cache_ttl=30,
        request_budget="api:crtsh=1",
        budget_preset="conservative",
        timeout=3.5,
        rate_limit_delay=0.2,
        scope="case_scope",
        public_only=True,
        max_terms_risk="low",
    )

    assert response["counts"]["sources"] == 1
    assert captured["context"].scope == "case_scope"
    assert captured["context"].cache_ttl_seconds == 30
    assert captured["context"].request_budget["*"] == 2
    assert captured["context"].request_budget["api:crtsh"] == 1
    assert captured["context"].request_budget["api:shodan"] == 1
    assert captured["context"].request_budget["api:censys"] == 1
    assert captured["context"].timeout == 3.5
    assert captured["context"].rate_limit_delay == 0.2
    assert captured["context"].legal_flags == {
        "public_only": True,
        "max_terms_risk": "low",
        "allow_sensitive_sources": False,
        "allow_uploads": False,
        "allow_active_checks": False,
    }
    try:
        endpoint(target="example.com", request_budget="invalid")
    except Exception as exc:
        assert exc.status_code == 400
    else:
        raise AssertionError("invalid request_budget must raise HTTP 400")


def test_v08_adapter_generator_scaffolds_catalog_source(tmp_path):
    files = scaffold_adapter("crtsh", tmp_path)
    manifest = files["manifest"].read_text(encoding="utf-8")
    adapter = files["adapter"].read_text(encoding="utf-8")

    assert files["manifest"].exists()
    assert files["adapter"].exists()
    assert '"source_id": "crtsh"' in manifest
    assert "def run(" in adapter
    assert "def parse(" in adapter
    assert "def health_check(" in adapter
    assert "def schema(" in adapter
    assert "CONTRACT_VERSION = \"0.2\"" in adapter
    assert "BASE_URL = \"https://crt.sh\"" in adapter
    compile(adapter, str(files["adapter"]), "exec")


def test_v13_generated_adapter_module_matches_contract(tmp_path, monkeypatch):
    import importlib.util

    files = scaffold_adapter("crtsh", tmp_path)
    spec = importlib.util.spec_from_file_location("generated_crtsh", files["adapter"])
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)

    class FakeResponse:
        status_code = 200
        url = "https://crt.sh/?q=%25.example.com&output=json"
        headers = {"content-type": "application/json"}
        text = ""

        def json(self):
            return [{"name_value": "www.example.com"}]

    calls = []

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setattr(module, "request", fake_request)

    schema = module.schema()
    raw = module.run("example.com")
    normalized = module.parse(raw, "example.com")
    health = module.health_check(target="example.com")

    assert schema["contract_version"] == "0.2"
    assert schema["normalized_schema"]["findings"].startswith("list")
    assert raw["status"] == "ok"
    assert raw["headers"]["content-type"] == "application/json"
    assert {"type": "source", "value": "crtsh"} in normalized["entities"]
    assert normalized["findings"][0]["status"] == "exists"
    assert health["status"] == "available"
    assert calls[0][0] == "GET"


def test_v14_generated_adapter_uses_auth_headers_and_post_body(tmp_path, monkeypatch):
    import importlib.util

    monkeypatch.setenv("OSINTLY_API_KEY", "osintly-secret")
    files = scaffold_adapter("osintly_api", tmp_path)
    spec = importlib.util.spec_from_file_location("generated_osintly", files["adapter"])
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    calls = []

    class FakeResponse:
        status_code = 200
        url = "https://api.osint.ly/search"
        headers = {"content-type": "application/json"}
        text = ""

        def json(self):
            return {"results": [{"type": "username", "value": "alice"}]}

    def fake_request(method: str, url: str, **kwargs):
        calls.append((method, url, kwargs))
        return FakeResponse()

    monkeypatch.setattr(module, "request", fake_request)

    raw = module.run("alice@example.com", input_type="email")
    normalized = module.parse(raw, "alice@example.com")

    assert raw["status"] == "ok"
    assert raw["input_type"] == "email"
    assert raw["method"] == "POST"
    assert normalized["findings"][0]["entity_type"] == "email"
    assert calls[0][0] == "POST"
    assert calls[0][1] == "https://api.osint.ly/search"
    assert calls[0][2]["headers"] == {"Authorization": "Bearer osintly-secret"}
    assert calls[0][2]["json"] == {"target": "alice@example.com", "type": "email"}
    assert "client" in calls[0][2]


def test_v13_generated_adapter_missing_required_env_skips_network(tmp_path, monkeypatch):
    import importlib.util

    monkeypatch.delenv("SHODAN_API_KEY", raising=False)
    files = scaffold_adapter("shodan", tmp_path)
    spec = importlib.util.spec_from_file_location("generated_shodan", files["adapter"])
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)

    def fail_request(method: str, url: str, **kwargs):
        raise AssertionError("missing-key generated adapter must not call network")

    monkeypatch.setattr(module, "request", fail_request)

    raw = module.run("8.8.8.8")
    normalized = module.parse(raw, "8.8.8.8")
    health = module.health_check(target="8.8.8.8")

    assert raw["status"] == "missing_keys"
    assert raw["missing_env"] == ["SHODAN_API_KEY"]
    assert normalized["findings"][0]["status"] == "missing_keys"
    assert normalized["findings"][0]["confidence"] == 0.0
    assert health["status"] == "missing_keys"
