from __future__ import annotations

from bedniiosint.core.entity_resolution import resolve_entities


def test_entity_resolution_clusters_aliases_and_counts_evidence_signals():
    result = resolve_entities(
        [
            {"type": "username", "value": "Bob"},
            {"type": "person", "value": "Robert B"},
        ],
        [
            {
                "src_type": "username",
                "src_value": "Bob",
                "rel": "alias_of",
                "dst_type": "person",
                "dst_value": "Robert B",
            }
        ],
        findings=[
            {
                "id": 10,
                "source_id": "api:one",
                "entity_type": "username",
                "entity_value": "bob",
                "status": "exists",
                "confidence": 0.72,
            },
            {
                "id": 11,
                "source_id": "api:two",
                "entity_type": "username",
                "entity_value": "Bob",
                "status": "exists",
                "confidence": 0.88,
            },
            {
                "id": 12,
                "source_id": "api:people",
                "entity_type": "person",
                "entity_value": "Robert B",
                "status": "unknown",
                "confidence": 0.2,
            },
        ],
        evidence=[
            {"id": 100, "finding_id": 10, "sha256": "a" * 64, "url": "https://example.test/a"},
            {"id": 101, "finding_id": 11, "sha256": "b" * 64, "url": "https://example.test/b"},
        ],
    )

    username = next(row for row in result["canonical_entities"] if row["type"] == "username")
    cluster = result["entity_clusters"][0]

    assert username["value"] == "bob"
    assert username["source_ids"] == ["api:one", "api:two"]
    assert username["independent_sources"] == 2
    assert username["evidence_count"] == 2
    assert username["human_review_required"] is False
    assert result["alias_links"][0]["reason"] == "explicit_relation:alias_of"
    assert set(cluster["types"]) == {"person", "username"}
    assert cluster["alias_link_count"] == 1
    assert cluster["independent_sources"] == 2
    assert cluster["evidence_count"] == 2
    assert cluster["human_review_required"] is True
    assert result["counts"]["entity_clusters"] == 1
    assert result["counts"]["supported_by_findings"] == 2
    assert result["counts"]["needs_review"] == 1


def test_entity_resolution_marks_single_source_entities_for_review():
    result = resolve_entities(
        [{"type": "domain", "value": "Example.COM"}],
        findings=[
            {
                "id": 20,
                "source_name": "api:single",
                "entity_type": "domain",
                "entity_value": "example.com",
                "status": "exists",
                "confidence": 0.8,
            }
        ],
        evidence=[],
    )

    domain = result["canonical_entities"][0]

    assert domain["value"] == "example.com"
    assert domain["independent_sources"] == 1
    assert domain["human_review_required"] is True
    assert "needs independent corroboration" in domain["review_reasons"]
    assert "no captured evidence linked to finding" in domain["review_reasons"]
