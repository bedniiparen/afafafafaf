from __future__ import annotations

from typer.testing import CliRunner


def test_plugin_subapp_and_legacy_aliases_are_registered():
    from bedniiosint.cli import app

    runner = CliRunner()

    plugin_help = runner.invoke(app, ["plugin", "--help"])
    legacy_help = runner.invoke(app, ["plugins", "--help"])

    assert plugin_help.exit_code == 0
    assert legacy_help.exit_code == 0
    assert "generate-adapter" in plugin_help.output
    assert "Plugin directory" in legacy_help.output


def test_username_subapp_and_legacy_aliases_are_registered():
    from bedniiosint.cli import app

    runner = CliRunner()

    subapp_help = runner.invoke(app, ["username-tools", "--help"])
    legacy_sources = runner.invoke(app, ["username-sources", "--help"])
    legacy_run = runner.invoke(app, ["username", "--help"])

    assert subapp_help.exit_code == 0
    assert legacy_sources.exit_code == 0
    assert legacy_run.exit_code == 0
    assert "catalog-coverage" in subapp_help.output
    assert "Inspect username source catalog" in legacy_sources.output
    assert "Username to investigate" in legacy_run.output


def test_case_admin_subapp_and_legacy_aliases_are_registered():
    from bedniiosint.cli import app

    runner = CliRunner()

    subapp_help = runner.invoke(app, ["case-admin", "--help"])
    legacy_schema = runner.invoke(app, ["schema-status", "--help"])
    legacy_bundle = runner.invoke(app, ["evidence-bundle-inspect", "--help"])

    assert subapp_help.exit_code == 0
    assert legacy_schema.exit_code == 0
    assert legacy_bundle.exit_code == 0
    assert "evidence-inspect" in subapp_help.output
    assert "Print storage schema version" in legacy_schema.output
    assert "Inspect an evidence vault bundle" in legacy_bundle.output


def test_live_results_subapp_and_legacy_aliases_are_registered():
    from bedniiosint.cli import app

    runner = CliRunner()

    subapp_help = runner.invoke(app, ["live", "--help"])
    subcommand_help = runner.invoke(app, ["live", "results", "--help"])
    legacy_help = runner.invoke(app, ["live-results", "--help"])

    assert subapp_help.exit_code == 0
    assert subcommand_help.exit_code == 0
    assert legacy_help.exit_code == 0
    assert "results-cleanup" in subapp_help.output
    assert "persisted opt-in live validation results" in subcommand_help.output
    assert "persisted opt-in live validation results" in legacy_help.output


def test_case_subapp_and_legacy_runner_aliases_are_registered():
    from bedniiosint.cli import app

    runner = CliRunner()

    subapp_help = runner.invoke(app, ["case", "--help"])
    subcommand_help = runner.invoke(app, ["case", "find", "--help"])
    legacy_find = runner.invoke(app, ["find", "--help"])
    legacy_diff = runner.invoke(app, ["case-diff", "--help"])

    assert subapp_help.exit_code == 0
    assert subcommand_help.exit_code == 0
    assert legacy_find.exit_code == 0
    assert legacy_diff.exit_code == 0
    assert "media-verify-plan" in subapp_help.output
    assert "Auto-detect a target" in subcommand_help.output
    assert "Auto-detect a target" in legacy_find.output
    assert "Compare two case summaries" in legacy_diff.output


def test_source_subapp_and_legacy_source_aliases_are_registered():
    from bedniiosint.cli import app

    runner = CliRunner()

    subapp_help = runner.invoke(app, ["source", "--help"])
    source_run_help = runner.invoke(app, ["source", "run", "--help"])
    legacy_sources = runner.invoke(app, ["sources", "--help"])
    legacy_gate = runner.invoke(app, ["source-quality-gate", "--help"])

    assert subapp_help.exit_code == 0
    assert source_run_help.exit_code == 0
    assert legacy_sources.exit_code == 0
    assert legacy_gate.exit_code == 0
    assert "quality-gate" in subapp_help.output
    assert "Run a source registry adapter" in source_run_help.output
    assert "List the unified source registry" in legacy_sources.output
    assert "offline source quality gate" in legacy_gate.output


def test_search_subapp_and_legacy_search_aliases_are_registered():
    from bedniiosint.cli import app

    runner = CliRunner()

    subapp_help = runner.invoke(app, ["search", "--help"])
    run_help = runner.invoke(app, ["search", "run", "--help"])
    legacy_plan = runner.invoke(app, ["search-plan", "--help"])
    legacy_pipeline = runner.invoke(app, ["pipeline-run", "--help"])

    assert subapp_help.exit_code == 0
    assert run_help.exit_code == 0
    assert legacy_plan.exit_code == 0
    assert legacy_pipeline.exit_code == 0
    assert "pipeline-run" in subapp_help.output
    assert "investigate" in subapp_help.output
    assert "benchmark" in subapp_help.output
    assert "Run unified search" in run_help.output
    assert "Plan unified OSINT search" in legacy_plan.output
    assert "catalog source pipeline" in legacy_pipeline.output


def test_search_investigate_cli_writes_graph(tmp_path, monkeypatch):
    from bedniiosint.cli import app

    runner = CliRunner()

    def fake_recursive(target: str, **kwargs):
        return {
            "module": "auto_pivot",
            "seed": {"entity_type": kwargs.get("entity_type") or "username", "value": target},
            "nodes": [{"entity_type": "username", "value": target, "depth": 0, "result_count": 0}],
            "node_count": 1,
            "result_count": 0,
            "search_results": [],
            "correlations": [],
            "identities": [],
        }

    monkeypatch.setattr("bedniiosint.search.auto_pivot.run_recursive_investigation", fake_recursive)
    graph_path = tmp_path / "investigation.html"

    result = runner.invoke(
        app,
        [
            "search",
            "investigate",
            "alice",
            "--entity-type",
            "username",
            "--graph-out",
            str(graph_path),
        ],
    )

    assert result.exit_code == 0
    assert '"module": "auto_pivot"' in result.output
    assert graph_path.exists()
    assert "Investigation graph" in graph_path.read_text(encoding="utf-8")


def test_search_benchmark_cli_runs_dataset(tmp_path, monkeypatch):
    from bedniiosint.cli import app

    runner = CliRunner()
    dataset = tmp_path / "ground_truth.json"
    dataset.write_text(
        '[{"target":"alice","entity_type":"username","expected":["https://github.com/alice"]}]',
        encoding="utf-8",
    )

    def fake_pipeline(target: str, **kwargs):
        return {
            "search_results": [
                {
                    "id": "github:alice",
                    "source_id": "github",
                    "source_name": "GitHub",
                    "entity_input": target,
                    "entity_type": kwargs.get("entity_type") or "username",
                    "matched_entity": target,
                    "url": "https://github.com/alice",
                }
            ]
        }

    monkeypatch.setattr("bedniiosint.search.pipeline.run_planned_search_pipeline", fake_pipeline)

    result = runner.invoke(app, ["search", "benchmark", str(dataset)])
    markdown = runner.invoke(app, ["search", "benchmark", str(dataset), "--markdown"])

    assert result.exit_code == 0
    assert '"precision": 1.0' in result.output
    assert markdown.exit_code == 0
    assert "BEDNIIOSINT search benchmark" in markdown.output


def test_cti_subapp_and_legacy_cti_aliases_are_registered():
    from bedniiosint.cli import app

    runner = CliRunner()

    subapp_help = runner.invoke(app, ["cti", "--help"])
    sync_help = runner.invoke(app, ["cti", "sync", "--help"])
    legacy_sync = runner.invoke(app, ["cti-sync", "--help"])
    legacy_live_plan = runner.invoke(app, ["live-plan", "--help"])

    assert subapp_help.exit_code == 0
    assert sync_help.exit_code == 0
    assert legacy_sync.exit_code == 0
    assert legacy_live_plan.exit_code == 0
    assert "preflight" in subapp_help.output
    assert "OpenCTI/MISP" in sync_help.output
    assert "OpenCTI/MISP" in legacy_sync.output
    assert "live validation readiness" in legacy_live_plan.output
