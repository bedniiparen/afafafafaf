from __future__ import annotations

from typing import Any


def test_rank_and_score_prefers_relevant_result():
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.scoring import rank_and_score

    weak_relevant = SearchResult(
        id="relevant",
        source_id="api:one",
        source_name="One",
        entity_input="example.com",
        entity_type="domain",
        matched_entity="example.com",
        title="Example domain certificate transparency",
        snippet="example.com subdomain evidence",
        confidence_score=0.55,
    )
    strong_irrelevant = SearchResult(
        id="irrelevant",
        source_id="api:two",
        source_name="Two",
        entity_input="other.test",
        entity_type="domain",
        matched_entity="other.test",
        title="Different target",
        snippet="unrelated record",
        confidence_score=0.9,
    )

    ranked = rank_and_score("example.com certificate", [strong_irrelevant, weak_relevant])

    assert ranked[0].id == "relevant"
    assert ranked[0].normalized_data["relevance_score"] > ranked[1].normalized_data["relevance_score"]
    assert "ranking_score" in ranked[0].normalized_data


def test_presence_filter_drops_soft_404_before_ranking():
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.scoring import rank_and_score

    absent = SearchResult(
        id="absent",
        source_id="site",
        source_name="Site",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="User not found",
        snippet="This profile does not exist.",
        confidence_score=0.95,
        normalized_data={"status_code": 200},
    )
    found = SearchResult(
        id="found",
        source_id="github",
        source_name="GitHub",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice profile",
        snippet="Public profile for alice",
        confidence_score=0.65,
        normalized_data={"status_code": 200},
    )

    ranked = rank_and_score("alice", [absent, found])

    assert [result.id for result in ranked] == ["found"]
    assert found.normalized_data["presence_filter"]["dropped_absent"] == 1


def test_presence_filter_marks_uncertain_when_positive_signal_conflicts():
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.presence import apply_presence_filter, classify_presence

    result = SearchResult(
        id="username-hit",
        source_id="username",
        source_name="Username",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice",
        snippet="User not found banner in unrelated widget",
        confidence_score=0.8,
        normalized_data={"status": "exists", "markers": ["e_string:alice"]},
    )

    verdict = classify_presence(result)
    kept = apply_presence_filter([result])

    assert verdict.state == "uncertain"
    assert kept == [result]
    assert "presence_uncertain" in result.risk_flags
    assert result.confidence_score == 0.4


def test_presence_filter_can_keep_absent_for_audit():
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.presence import apply_presence_filter

    result = SearchResult(
        id="gone",
        source_id="site",
        source_name="Site",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice",
        snippet="",
        confidence_score=0.9,
        normalized_data={"status_code": 404},
    )

    kept = apply_presence_filter([result], drop_absent=False)

    assert kept == [result]
    assert result.confidence_score == 0.0
    assert "confirmed_absent" in result.risk_flags
    assert result.normalized_data["presence"]["state"] == "absent"


def test_candidate_verifier_drops_soft_404_candidate(monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.search import candidate_verify
    from bedniiosint.search.models import SearchResult

    original_drop_absent = settings.verify_candidate_drop_absent
    original_timeout = settings.verify_candidate_timeout
    object.__setattr__(settings, "verify_candidate_drop_absent", True)
    object.__setattr__(settings, "verify_candidate_timeout", 1.0)
    monkeypatch.setattr(
        candidate_verify,
        "_verify_one",
        lambda url: ("absent", "soft-404 / negative page (status 200)", 200),
    )
    result = SearchResult(
        id="genius-dead",
        source_id="dorking:profile:genius",
        source_name="Genius candidate",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        url="https://genius.com/artists/alice",
        tags=["candidate_url"],
        normalized_data={"verification_status": "unverified_candidate"},
    )

    try:
        verified = candidate_verify.verify_candidate_results([result])
    finally:
        object.__setattr__(settings, "verify_candidate_drop_absent", original_drop_absent)
        object.__setattr__(settings, "verify_candidate_timeout", original_timeout)

    assert verified == []
    assert result.normalized_data["candidate_verification"]["state"] == "absent"


def test_candidate_verifier_keeps_reachable_candidate(monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.search import candidate_verify
    from bedniiosint.search.models import SearchResult

    original_drop_absent = settings.verify_candidate_drop_absent
    original_timeout = settings.verify_candidate_timeout
    object.__setattr__(settings, "verify_candidate_drop_absent", True)
    object.__setattr__(settings, "verify_candidate_timeout", 1.0)
    monkeypatch.setattr(
        candidate_verify,
        "_verify_one",
        lambda url: ("present", "reachable (status 200)", 200),
    )
    result = SearchResult(
        id="github-alice",
        source_id="dorking:profile:github",
        source_name="GitHub candidate",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        url="https://github.com/alice",
        tags=["candidate_url"],
        confidence_score=0.0,
        normalized_data={"verification_status": "unverified_candidate"},
    )

    try:
        verified = candidate_verify.verify_candidate_results([result])
    finally:
        object.__setattr__(settings, "verify_candidate_drop_absent", original_drop_absent)
        object.__setattr__(settings, "verify_candidate_timeout", original_timeout)

    assert verified == [result]
    assert "reachable" in result.tags
    assert result.confidence_score == 0.35
    assert result.normalized_data["verification_status"] == "reachable_unconfirmed"
    assert result.normalized_data["candidate_verification"]["state"] == "present"


def test_candidate_verifier_can_keep_absent_for_audit(monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.search import candidate_verify
    from bedniiosint.search.models import SearchResult

    original_drop_absent = settings.verify_candidate_drop_absent
    original_timeout = settings.verify_candidate_timeout
    object.__setattr__(settings, "verify_candidate_drop_absent", False)
    object.__setattr__(settings, "verify_candidate_timeout", 1.0)
    monkeypatch.setattr(
        candidate_verify,
        "_verify_one",
        lambda url: ("absent", "soft-404 / negative page (status 200)", 200),
    )
    result = SearchResult(
        id="dead-candidate",
        source_id="dorking:profile:site",
        source_name="Site candidate",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        url="https://example.test/alice",
        tags=["candidate_url"],
        confidence_score=0.5,
        normalized_data={"verification_status": "unverified_candidate"},
    )

    try:
        verified = candidate_verify.verify_candidate_results([result])
    finally:
        object.__setattr__(settings, "verify_candidate_drop_absent", original_drop_absent)
        object.__setattr__(settings, "verify_candidate_timeout", original_timeout)

    assert verified == [result]
    assert result.confidence_score == 0.0
    assert "confirmed_absent" in result.risk_flags
    assert result.normalized_data["candidate_verification"]["state"] == "absent"


def test_identity_resolution_merges_correlated_results_and_annotates_members():
    from bedniiosint.search.identity import build_identities
    from bedniiosint.search.models import SearchResult

    github = SearchResult(
        id="github:alice",
        source_id="api:github",
        source_name="GitHub",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice",
        url="https://github.com/alice",
        confidence_score=0.9,
    )
    gravatar = SearchResult(
        id="gravatar:alice",
        source_id="api:gravatar",
        source_name="Gravatar",
        entity_input="alice@example.com",
        entity_type="email",
        matched_entity="alice@example.com",
        title="alice@example.com",
        url="https://www.gravatar.com/alice",
        confidence_score=0.85,
    )
    dead_candidate = SearchResult(
        id="genius:dead",
        source_id="dorking:profile:genius",
        source_name="Genius candidate",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Genius candidate",
        url="https://genius.com/artists/alice",
        tags=["candidate_url", "review_only"],
        confidence_score=0.0,
    )
    links = [
        {
            "kind": "shared_email",
            "key": "alice@example.com",
            "member_ids": ["github:alice", "gravatar:alice"],
            "sources": ["api:github", "api:gravatar"],
            "confidence": 0.9,
            "explanation": "Same email appears across independent sources.",
        }
    ]

    identities = build_identities([github, gravatar, dead_candidate], links)

    merged = next(identity for identity in identities if identity["member_count"] == 2)
    dead = next(identity for identity in identities if identity["member_result_ids"] == ["genius:dead"])
    assert merged["band"] == "confirmed"
    assert merged["confidence"] >= 0.75
    assert merged["linked_by"] == ["shared_email"]
    assert {row["entity_type"] for row in merged["identifiers"]} == {"email", "username"}
    assert github.normalized_data["identity"]["identity_id"] == merged["identity_id"]
    assert gravatar.normalized_data["identity"]["identity_id"] == merged["identity_id"]
    assert dead["band"] == "unconfirmed"
    assert dead["confidence"] == 0.0


def test_catalog_connector_score_applies_presence_filter():
    from bedniiosint.search.connectors.catalog import CatalogConnector
    from bedniiosint.search.models import SearchResult

    connector = CatalogConnector({"id": "test", "name": "Test"})
    absent = SearchResult(
        id="soft404",
        source_id="api:test",
        source_name="Test",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Profile not found",
        snippet="No such user",
        confidence_score=0.9,
        normalized_data={"status_code": 200},
    )
    found = SearchResult(
        id="ok",
        source_id="api:test",
        source_name="Test",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice",
        snippet="Public profile",
        confidence_score=0.6,
        normalized_data={"status_code": 200},
    )

    scored = connector.score([absent, found])

    assert [result.id for result in scored] == ["ok"]
    assert found.normalized_data["presence_filter"]["dropped_absent"] == 1


def test_canonicalize_dedupes_urls_and_boosts_corroboration():
    from bedniiosint.search.canonicalize import canonical_url, dedupe_and_merge
    from bedniiosint.search.models import SearchResult

    assert (
        canonical_url("http://m.Example.com/Alice/?utm_source=x&b=2&a=1#frag")
        == "https://example.com/alice?a=1&b=2"
    )
    first = SearchResult(
        id="one",
        source_id="api:one",
        source_name="One",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        url="https://www.example.com/alice?utm_campaign=x",
        confidence_score=0.6,
    )
    second = SearchResult(
        id="two",
        source_id="api:two",
        source_name="Two",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        url="http://m.example.com/alice/",
        confidence_score=0.7,
        tags=["external"],
    )

    merged = dedupe_and_merge([first, second])

    assert len(merged) == 1
    assert merged[0].id == "two"
    assert merged[0].confidence_score == 0.75
    assert "corroborated" in merged[0].tags
    assert merged[0].normalized_data["merged_sources"] == ["api:one", "api:two"]


def test_rank_and_score_dedupes_before_final_ranking():
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.scoring import rank_and_score

    left = SearchResult(
        id="left",
        source_id="api:left",
        source_name="Left",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice profile",
        url="https://www.example.com/alice?utm_source=feed",
        confidence_score=0.6,
    )
    right = SearchResult(
        id="right",
        source_id="api:right",
        source_name="Right",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice profile",
        url="https://example.com/alice",
        confidence_score=0.7,
    )

    ranked = rank_and_score("alice", [left, right])

    assert len(ranked) == 1
    assert ranked[0].id == "right"
    assert ranked[0].normalized_data["merged_count"] == 2
    assert ranked[0].normalized_data["ranking_score"] > 0


def test_control_probe_flags_false_positive_prone_site():
    from bedniiosint.search.control_probe import verify_presence

    def build_url(selector: str) -> str:
        return f"https://example.test/{selector}"

    def honest_fetch(url: str) -> dict[str, object]:
        return {"status_code": 200, "text": "profile alice"} if url.endswith("/alice") else {"status_code": 404, "text": "not found"}

    def always_positive(_url: str) -> dict[str, object]:
        return {"status_code": 200, "text": "profile page"}

    assert verify_presence(honest_fetch, build_url, "alice", "username").state == "found"
    uncertain = verify_presence(always_positive, build_url, "alice", "username")
    assert uncertain.state == "uncertain"
    assert "control selector" in uncertain.reason


def test_isotonic_calibration_predicts_and_tags_results(tmp_path):
    from bedniiosint.search.calibration import IsotonicCalibrator, calibrate_results
    from bedniiosint.search.models import SearchResult

    calibrator = IsotonicCalibrator().fit([0.1, 0.4, 0.8, 0.9], [0, 0, 1, 1])
    path = calibrator.save(tmp_path / "calibration.json")
    loaded = IsotonicCalibrator.load(path)
    result = SearchResult(
        id="cal",
        source_id="api",
        source_name="API",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        confidence_score=0.8,
    )

    calibrate_results([result], loaded, overwrite_confidence=True)

    assert loaded.fitted
    assert 0.0 <= loaded.predict(0.5) <= 1.0
    assert result.confidence_score == result.normalized_data["calibrated_confidence"]
    assert result.normalized_data["raw_confidence"] == 0.8


def test_rank_and_score_uses_optional_calibration_model(tmp_path):
    from bedniiosint.config import settings
    from bedniiosint.search.calibration import IsotonicCalibrator
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.scoring import rank_and_score

    model = IsotonicCalibrator().fit([0.0, 0.8, 1.0], [0.0, 0.4, 1.0])
    model_path = model.save(tmp_path / "calibration.json")
    original_model = settings.search_calibration_model
    original_overwrite = settings.search_calibration_overwrite
    object.__setattr__(settings, "search_calibration_model", str(model_path))
    object.__setattr__(settings, "search_calibration_overwrite", True)
    try:
        result = SearchResult(
            id="calibrated",
            source_id="api:cal",
            source_name="Cal",
            entity_input="alice",
            entity_type="username",
            matched_entity="alice",
            title="alice",
            confidence_score=0.8,
        )

        ranked = rank_and_score("alice", [result])

        assert ranked[0].confidence_score == 0.4
        assert ranked[0].normalized_data["calibrated_confidence"] == 0.4
        assert ranked[0].normalized_data["raw_confidence"] == 0.8
    finally:
        object.__setattr__(settings, "search_calibration_model", original_model)
        object.__setattr__(settings, "search_calibration_overwrite", original_overwrite)


def test_intl_query_expansion_and_planner_variants():
    from bedniiosint.search.planner import plan_search
    from bedniiosint.search.query_expansion_intl import expand_variants, has_cyrillic

    variants = expand_variants("Иван Петров", entity_type="username")

    assert has_cyrillic("Иван")
    assert "Ivan Petrov" in variants
    assert "ivanpetrov" in variants
    assert "ivan.petrov" in variants

    plan = plan_search("Иван Петров", entity_type="username", max_sources=1)
    assert any(row.kind == "intl_expansion" for row in plan.variant_details)
    assert any(
        detail.get("kind") == "intl_expansion"
        for query in plan.queries
        for detail in query.metadata.get("variant_details", [])
    )


def test_live_wave_emitter_and_auto_pivot_events(monkeypatch):
    from bedniiosint.search.auto_pivot import run_recursive_investigation
    from bedniiosint.search.live_events import WaveEmitter, sse_format

    def fake_pipeline(target: str, **kwargs):
        if target == "alice":
            return {
                "search_results": [
                    {
                        "id": "github:alice",
                        "source_id": "github",
                        "source_name": "GitHub",
                        "entity_type": "username",
                        "matched_entity": "alice",
                        "title": "alice",
                        "url": "https://github.com/alice",
                        "confidence_score": 0.8,
                    }
                ],
                "result_pivots": {"items": [{"pivot_type": "email", "value": "alice@example.com", "confidence": 0.9}]},
            }
        return {"search_results": [], "result_pivots": {"items": []}}

    monkeypatch.setattr("bedniiosint.search.auto_pivot.run_planned_search_pipeline", fake_pipeline)
    emitter = WaveEmitter(job_id=7)
    result = run_recursive_investigation(
        "alice",
        entity_type="username",
        max_depth=1,
        max_nodes=3,
        emitter=emitter,
        include_username_scan=False,
        concurrent=False,
    )
    kinds = [event["kind"] for event in emitter.buffer]

    assert result["live_events"] == emitter.buffer
    assert {"wave_started", "result", "pivot", "wave_completed", "done"} <= set(kinds)
    assert sse_format(emitter.buffer[0]).startswith("event: wave_started")


def test_benchmark_and_case_timeline_helpers():
    from bedniiosint.eval.benchmark import report_markdown, run_benchmark
    from bedniiosint.reports.case_timeline import build_timeline, timeline_markdown
    from bedniiosint.search.models import SearchResult

    prediction = SearchResult(
        id="github:alice",
        source_id="github",
        source_name="GitHub",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice",
        url="https://github.com/alice",
        confidence_score=0.9,
    )

    report = run_benchmark(
        [{"target": "alice", "entity_type": "username", "expected": ["https://github.com/alice"]}],
        lambda _target, _entity_type: [prediction],
    )
    payload = {
        "seed": {"entity_type": "username", "value": "alice"},
        "search_results": [prediction.as_dict()],
        "identities": [{"label": "alice", "status": "confirmed", "confidence": 0.9}],
        "correlations": [{"kind": "cross_platform_username", "explanation": "same handle", "confidence": 0.8}],
    }
    timeline = build_timeline(payload)

    assert report.precision == 1.0
    assert report.recall == 1.0
    assert "github" in report_markdown(report)
    assert [event["seq"] for event in timeline] == [1, 2, 3, 4]
    assert "Investigation timeline" in timeline_markdown(payload)


def test_async_pipeline_isolates_failed_connector():
    from bedniiosint.search.async_pipeline import run_connectors
    from bedniiosint.search.connectors.base import BaseConnector, QueryPlan
    from bedniiosint.search.models import SearchResult

    class GoodConnector(BaseConnector):
        source_id = "good"
        source_name = "Good"

        def run(self, query_plan: QueryPlan) -> dict[str, Any]:
            return {"target": query_plan.entity_input}

        def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
            return [raw_response]

        def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
            return [
                SearchResult(
                    id="good:1",
                    source_id=self.source_id,
                    source_name=self.source_name,
                    entity_input=parsed[0]["target"],
                    entity_type="domain",
                    matched_entity=parsed[0]["target"],
                    title="Good example.com result",
                    confidence_score=0.7,
                )
            ]

    class BadConnector(BaseConnector):
        source_id = "bad"
        source_name = "Bad"

        def run(self, query_plan: QueryPlan) -> dict[str, Any]:
            raise RuntimeError("boom")

        def parse(self, raw_response: dict[str, Any]) -> list[dict[str, Any]]:
            return []

        def normalize(self, parsed: list[dict[str, Any]]) -> list[SearchResult]:
            return []

    results = run_connectors(
        [BadConnector(), GoodConnector()],
        {"type": "domain", "value": "example.com"},
    )

    assert [result.source_id for result in results] == ["good"]
    assert results[0].normalized_data["ranking_score"] >= 0


def test_planned_search_pipeline_runs_v3_standalone_connector(monkeypatch):
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.pipeline import run_planned_search_pipeline

    calls: dict[str, Any] = {}

    def fake_run_connectors(connectors, entity, **kwargs):
        calls["connector_ids"] = [connector.source_id for connector in connectors]
        calls["entity"] = dict(entity)
        calls["kwargs"] = dict(kwargs)
        return [
            SearchResult(
                id="github_user:octocat",
                source_id="github_user",
                source_name="GitHub Profile",
                entity_input="octocat",
                entity_type="username",
                matched_entity="octocat",
                title="GitHub user octocat",
                url="https://github.com/octocat",
                confidence_score=0.8,
            )
        ]

    monkeypatch.setattr("bedniiosint.search.pipeline.run_standalone_connectors", fake_run_connectors)

    result = run_planned_search_pipeline(
        "octocat",
        entity_type="username",
        source_ids=["github_user"],
    )

    assert calls["connector_ids"] == ["github_user"]
    assert calls["entity"] == {"type": "username", "value": "octocat"}
    assert calls["kwargs"]["scope"] == result["plan"]["scope"]
    assert calls["kwargs"]["scope"] == "social_profiles"
    assert result["standalone_connector_ids"] == ["github_user"]
    assert result["catalog_source_ids"] == []
    assert result["counts"]["standalone_connectors"] == 1
    assert result["counts"]["standalone_results"] == 1
    assert result["search_results"][0]["source_id"] == "github_user"


def test_search_upgrade_auto_pivot_correlates_and_builds_identity(monkeypatch):
    from bedniiosint.search.auto_pivot import run_recursive_investigation

    calls: list[tuple[str, str]] = []

    def fake_pipeline(target: str, **kwargs):
        calls.append((kwargs.get("entity_type"), target))
        if target == "alice":
            return {
                "search_results": [
                    {
                        "id": "github:alice",
                        "source_id": "github",
                        "source_name": "GitHub",
                        "entity_type": "username",
                        "matched_entity": "alice",
                        "title": "alice",
                        "snippet": "Contact alice@example.com",
                        "url": "https://github.com/alice",
                        "confidence_score": 0.82,
                    }
                ],
                "result_pivots": {
                    "items": [
                        {"pivot_type": "email", "value": "alice@example.com", "confidence": 0.8},
                        {"pivot_type": "domain", "value": "example.com", "confidence": 0.4},
                    ]
                },
            }
        if target == "alice@example.com":
            return {
                "search_results": [
                    {
                        "id": "gravatar:alice",
                        "source_id": "gravatar",
                        "source_name": "Gravatar",
                        "entity_type": "email",
                        "matched_entity": "alice@example.com",
                        "title": "alice@example.com",
                        "snippet": "@alice profile",
                        "url": "https://www.gravatar.com/alice",
                        "confidence_score": 0.74,
                    }
                ],
                "result_pivots": {"items": []},
            }
        return {"search_results": [], "result_pivots": {"items": []}}

    monkeypatch.setattr("bedniiosint.search.auto_pivot.run_planned_search_pipeline", fake_pipeline)

    result = run_recursive_investigation(
        "alice",
        entity_type="username",
        max_depth=1,
        max_nodes=5,
        min_pivot_confidence=0.6,
        include_username_scan=False,
        concurrent=False,
    )

    assert calls == [("username", "alice"), ("email", "alice@example.com")]
    assert result["module"] == "auto_pivot"
    assert result["waves"] == {"0": ["alice"], "1": ["alice@example.com"]}
    assert result["node_count"] == 2
    assert result["result_count"] == 2
    assert result["search_results"][1]["autopivot"]["parent"] == "alice"
    assert result["correlations"][0]["kind"] == "shared_email"
    assert result["correlations"][0]["sources"] == ["github", "gravatar"]
    identity = result["identities"][0]
    assert identity["key"] == "username:alice"
    assert identity["emails"] == ["alice@example.com"]
    assert identity["source_count"] == 2
    assert identity["status"] == "confirmed"


def test_auto_pivot_returns_partial_results_after_deadline(monkeypatch):
    import time

    from bedniiosint.config import settings
    from bedniiosint.search.auto_pivot import run_recursive_investigation

    original_deadline = settings.investigation_deadline_seconds
    calls: list[str] = []

    def fake_pipeline(target: str, **kwargs):
        calls.append(target)
        time.sleep(0.02)
        return {
            "search_results": [{"id": f"row:{target}", "source_id": "fake", "matched_entity": target}],
            "result_pivots": {"items": [{"pivot_type": "username", "value": f"{target}2", "confidence": 0.9}]},
        }

    object.__setattr__(settings, "investigation_deadline_seconds", 0.01)
    monkeypatch.setattr("bedniiosint.search.auto_pivot.run_planned_search_pipeline", fake_pipeline)
    try:
        result = run_recursive_investigation(
            "alice",
            entity_type="username",
            max_depth=3,
            max_nodes=10,
            include_username_scan=False,
            concurrent=False,
        )
    finally:
        object.__setattr__(settings, "investigation_deadline_seconds", original_deadline)

    assert result["node_count"] >= 1
    assert result["node_count"] < 10
    assert result["frontier_remaining"] >= 1
    assert calls[0] == "alice"


def test_investigation_graph_exports_auto_pivot_payload():
    from bedniiosint.graph.investigation_graph import (
        build_investigation_graph,
        investigation_graph_cytoscape,
        investigation_graph_html,
    )

    payload = {
        "seed": {"entity_type": "username", "value": "alice"},
        "nodes": [
            {"entity_type": "username", "value": "alice", "depth": 0, "result_count": 1},
            {
                "entity_type": "email",
                "value": "alice@example.com",
                "depth": 1,
                "parent": "alice",
                "reason": "pivot:email",
                "result_count": 1,
            },
        ],
        "search_results": [
            {
                "id": "github:alice",
                "source_id": "github",
                "source_name": "GitHub",
                "entity_type": "username",
                "matched_entity": "alice",
                "title": "alice",
                "url": "https://github.com/alice",
                "confidence_score": 0.88,
                "autopivot": {"via": "alice", "depth": 0},
            }
        ],
        "identities": [
            {
                "key": "username:alice",
                "label": "alice",
                "confidence": 0.88,
                "status": "confirmed",
                "source_count": 2,
                "result_ids": ["github:alice"],
            }
        ],
        "correlations": [
            {
                "kind": "cross_platform_username",
                "key": "alice",
                "member_ids": ["github:alice"],
                "sources": ["github"],
                "confidence": 0.8,
                "explanation": "same username",
            }
        ],
    }

    graph = build_investigation_graph(payload)
    data = investigation_graph_cytoscape(payload)
    html = investigation_graph_html(payload)

    assert graph.number_of_nodes() >= 4
    assert graph.number_of_edges() >= 3
    assert data["metrics"]["nodes"] == graph.number_of_nodes()
    assert data["elements"]["nodes"]
    assert "Investigation graph" in html
    assert "alice" in html


def test_search_upgrade_playbooks_and_http_routes(monkeypatch):
    import bedniiosint.web.app as web_app
    import bedniiosint.web.routers.search as search_router
    from bedniiosint.config import settings
    from bedniiosint.search.playbooks import list_playbooks

    if not hasattr(web_app.app, "routes"):
        return

    assert hasattr(settings, "autopivot_max_depth")
    assert hasattr(settings, "autopivot_max_nodes")
    assert hasattr(settings, "autopivot_min_confidence")
    assert hasattr(settings, "autopivot_per_type_cap")
    assert {"username_deep", "email_to_identity", "domain_footprint", "quick_triage"} <= {
        row["id"] for row in list_playbooks()
    }

    def fake_recursive(target: str, **kwargs):
        return {
            "module": "auto_pivot",
            "seed": {"entity_type": kwargs.get("entity_type") or "username", "value": target},
            "nodes": [],
            "search_results": [],
            "correlations": [],
            "identities": [],
            "params": {"max_depth": kwargs.get("max_depth")},
        }

    def fake_playbook(playbook: str, target: str, **kwargs):
        return {
            "module": "auto_pivot",
            "playbook": {"id": playbook},
            "seed": {"value": target},
            "params": kwargs,
        }

    monkeypatch.setattr(search_router, "run_recursive_investigation", fake_recursive)
    monkeypatch.setattr(search_router, "run_playbook", fake_playbook)

    from fastapi.testclient import TestClient

    client = TestClient(web_app.app)
    investigate = client.get(
        "/search/investigate",
        params={"target": "alice", "entity_type": "username", "max_depth": 1},
    )
    assert investigate.status_code == 200
    assert investigate.json()["module"] == "auto_pivot"
    assert investigate.json()["params"]["max_depth"] == 1

    graph_html = client.get(
        "/search/investigate/graph",
        params={"target": "alice", "entity_type": "username", "fmt": "html"},
    )
    assert graph_html.status_code == 200
    assert "Investigation graph" in graph_html.text

    graph_json = client.get(
        "/search/investigate/graph",
        params={"target": "alice", "entity_type": "username", "fmt": "cytoscape"},
    )
    assert graph_json.status_code == 200
    assert "elements" in graph_json.json()

    timeline = client.get(
        "/search/investigate/timeline",
        params={"target": "alice", "entity_type": "username", "fmt": "json"},
    )
    assert timeline.status_code == 200
    assert timeline.json()["timeline"][0]["kind"] == "seed"

    timeline_md = client.get(
        "/search/investigate/timeline",
        params={"target": "alice", "entity_type": "username", "fmt": "markdown"},
    )
    assert timeline_md.status_code == 200
    assert "Investigation timeline" in timeline_md.text

    playbooks = client.get("/search/playbooks")
    assert playbooks.status_code == 200
    assert "username_deep" in {row["id"] for row in playbooks.json()["playbooks"]}

    run = client.get("/search/playbook/run", params={"playbook": "quick_triage", "target": "alice"})
    assert run.status_code == 200
    assert run.json()["playbook"]["id"] == "quick_triage"


def test_response_cache_memory_backend_roundtrips_bytes(tmp_path):
    from bedniiosint.config import settings
    from bedniiosint.core.response_cache import ResponseCache

    original_backend = settings.cache_backend
    original_enabled = settings.cache_enabled
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "cache_backend", "memory")
    object.__setattr__(settings, "cache_enabled", True)
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        cache = ResponseCache()
        key = cache.key("GET", "https://example.test", params={"q": "x"})
        cache.set(key, {"content": b"abc"}, ttl=60)
        assert key.startswith("bedniiosint:http:")
        assert cache.get(key) == {"content": b"abc"}
    finally:
        object.__setattr__(settings, "cache_backend", original_backend)
        object.__setattr__(settings, "cache_enabled", original_enabled)
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_embedding_cache_reuses_vectors(tmp_path):
    from bedniiosint.config import settings
    from bedniiosint.search import embedding_cache

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    embedding_cache._DB_CACHE.clear()
    calls = {"count": 0}

    def embedder(texts: list[str]) -> list[list[float]]:
        calls["count"] += 1
        return [[float(len(text)), float(index)] for index, text in enumerate(texts)]

    try:
        first = embedding_cache.embed_texts_cached(["alice", "example"], model="test", embedder=embedder)
        second = embedding_cache.embed_texts_cached(["alice", "example"], model="test", embedder=embedder)
    finally:
        embedding_cache._DB_CACHE.clear()
        object.__setattr__(settings, "db_dir", original_db_dir)

    assert first == [[5.0, 0.0], [7.0, 1.0]]
    assert second == first
    assert calls["count"] == 1


def test_storage_engine_sqlite_pragmas(tmp_path):
    from bedniiosint.storage.engine import get_engine

    engine = get_engine(f"sqlite:///{(tmp_path / 'case.db').as_posix()}")
    try:
        with engine.connect() as conn:
            assert conn.exec_driver_sql("PRAGMA busy_timeout").scalar() == 5000
            assert conn.exec_driver_sql("PRAGMA foreign_keys").scalar() == 1
    finally:
        engine.dispose()


def test_connector_registry_and_blocked_holehe_policy():
    from bedniiosint.config import settings
    from bedniiosint.search.connectors import CONNECTOR_CLASSES
    from bedniiosint.search.pipeline import SEARCH_TO_CATALOG_SOURCE_IDS
    from bedniiosint.search.source_registry import get_source

    expected = {
        "bluesky",
        "censys",
        "codeforces",
        "crtsh",
        "dockerhub",
        "github_user",
        "gitlab",
        "gravatar",
        "hackernews",
        "hackertarget",
        "hibp",
        "holehe",
        "hunter",
        "greynoise",
        "ipwhois",
        "lichess",
        "rdap",
        "reddit",
        "securitytrails",
        "shodan",
        "telegram_public",
        "urlscan",
        "virustotal",
        "wayback",
        "wikidata",
        "wmn",
        "youtube_handle",
        "vk_public",
    }
    expected |= {
        "steam_id",
        "twitch_user",
        "pinterest_user",
        "soundcloud_user",
        "medium_user",
        "devto_user",
        "patreon_user",
        "linktree_user",
        "lastfm_user",
        "letterboxd_user",
        "vimeo_user",
        "dailymotion_user",
        "deviantart_user",
        "replit_user",
        "kaggle_user",
        "behance_user",
        "dribbble_user",
        "keybase_user",
        "okru_user",
        "habr_user",
    }
    assert expected <= set(CONNECTOR_CLASSES)
    assert len(CONNECTOR_CLASSES) >= len(expected)
    assert hasattr(settings, "github_token")
    assert hasattr(settings, "ipinfo_token")
    for source_id in {"shodan", "censys", "hibp", "hunter", "holehe", "securitytrails"}:
        source = get_source(source_id)
        assert source["api_type"] in {"connector", "blocked_connector"}
        assert source["scopes"] == ["connector_api"]
    for source_id in expected - {"shodan", "censys", "hibp", "hunter", "holehe", "securitytrails", "virustotal"}:
        source = get_source(source_id)
        assert source["api_type"] in {"rest", "connector", "scrape", "http"}
        assert source["auth_required"] is False
    virustotal_source = get_source("virustotal")
    assert virustotal_source["api_type"] == "rest"
    assert virustotal_source["auth_required"] is True
    assert SEARCH_TO_CATALOG_SOURCE_IDS["shodan"] == ["api:shodan"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["censys"] == ["api:censys"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["hibp"] == ["api:hibp"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["hunter"] == ["api:hunter"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["holehe"] == []
    assert SEARCH_TO_CATALOG_SOURCE_IDS.get("wmn", []) == []

    original = {
        "shodan_api_key": settings.shodan_api_key,
        "censys_api_id": settings.censys_api_id,
        "censys_api_secret": settings.censys_api_secret,
        "hibp_api_key": settings.hibp_api_key,
        "hunter_api_key": settings.hunter_api_key,
        "securitytrails_api_key": settings.securitytrails_api_key,
        "virustotal_api_key": settings.virustotal_api_key,
    }
    for name in original:
        object.__setattr__(settings, name, "")
    try:
        shodan = CONNECTOR_CLASSES["shodan"]()
        shodan_plan = shodan.build_queries({"type": "ip", "value": "8.8.8.8"})
        assert shodan.run(shodan_plan)["status"] == "missing_keys"

        securitytrails = CONNECTOR_CLASSES["securitytrails"]()
        securitytrails_plan = securitytrails.build_queries({"type": "domain", "value": "example.com"})
        assert securitytrails.run(securitytrails_plan)["status"] == "missing_keys"

        virustotal = CONNECTOR_CLASSES["virustotal"]()
        virustotal_plan = virustotal.build_queries({"type": "domain", "value": "example.com"})
        assert virustotal.run(virustotal_plan)["status"] == "missing_keys"

        holehe = CONNECTOR_CLASSES["holehe"]()
        holehe_plan = holehe.build_queries({"type": "email", "value": "alice@example.com"})
        raw = holehe.run(holehe_plan)
        rows = holehe.normalize(holehe.parse(raw))

        assert raw["status"] == "blocked"
        assert rows[0].confidence_score == 0.0
        assert "blocked_source" in rows[0].risk_flags
        assert "not run" in rows[0].legal_notes
    finally:
        for name, value in original.items():
            object.__setattr__(settings, name, value)


def test_html_report_renders_scheme_safe_links():
    from bedniiosint.reports import html

    assert html._link("adobe.com") == (
        '<a href="https://adobe.com" target="_blank" rel="noopener">https://adobe.com</a>'
    )
    assert html._link("") == "-"
    assert html._link("not a url") == "not a url"


def test_hibp_normalize_turns_domain_into_https_url():
    from bedniiosint.search.connectors.hibp import HIBPConnector

    connector = HIBPConnector()
    results = connector.normalize(
        [
            {
                "email": "alice@example.com",
                "Name": "Adobe",
                "Title": "Adobe",
                "Domain": "adobe.com",
            }
        ]
    )

    assert results[0].url == "https://adobe.com"


def test_wayback_connector_uses_https_cdx_endpoint(monkeypatch):
    import bedniiosint.search.connectors.wayback as wayback_module
    from bedniiosint.search.connectors.wayback import WaybackConnector

    calls: list[str] = []

    class FakeResponse:
        status_code = 200
        content = b"[]"

        def json(self):
            return []

    def fake_request(_method: str, url: str, **_kwargs):
        calls.append(url)
        return FakeResponse()

    monkeypatch.setattr(wayback_module, "request", fake_request)

    connector = WaybackConnector()
    query_plan = connector.build_queries({"type": "domain", "value": "example.com"})
    connector.run(query_plan)

    assert calls == ["https://web.archive.org/cdx/search/cdx"]


def test_embedding_cache_resolves_configured_provider(tmp_path, monkeypatch):
    import sys
    import types

    from bedniiosint.config import settings
    from bedniiosint.search import embedding_cache

    provider = types.ModuleType("test_embed_provider")
    calls = {"count": 0}

    def embed(texts: list[str]) -> list[list[float]]:
        calls["count"] += 1
        return [[float(len(text))] for text in texts]

    provider.embed = embed
    monkeypatch.setitem(sys.modules, "test_embed_provider", provider)
    monkeypatch.setenv("EMBEDDING_PROVIDER", "test_embed_provider:embed")
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    embedding_cache._DB_CACHE.clear()
    try:
        vectors = embedding_cache.embed_texts_cached(["alice"], model="provider-test")
    finally:
        embedding_cache._DB_CACHE.clear()
        object.__setattr__(settings, "db_dir", original_db_dir)

    assert vectors == [[5.0]]
    assert calls["count"] == 1
