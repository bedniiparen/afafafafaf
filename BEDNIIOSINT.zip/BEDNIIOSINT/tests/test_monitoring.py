from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from typer.testing import CliRunner

from bedniiosint.cli import app
from bedniiosint.config import settings
from bedniiosint.core import monitoring


class DummyJob:
    id = 42
    case_name = "monitor-user-bob-20260608-120000"
    target = "bob"
    module = "username"
    status = "queued"

    def as_dict(self):
        return {
            "id": self.id,
            "case_name": self.case_name,
            "target": self.target,
            "module": self.module,
            "status": self.status,
        }


def test_monitor_schedule_due_and_dry_run(tmp_path: Path):
    now = datetime(2026, 6, 8, 12, 0, tzinfo=timezone.utc)
    path = tmp_path / "monitoring.json"

    added = monitoring.add_monitor_schedule(
        "bob",
        module="username",
        case_prefix="monitor-user-bob",
        interval_minutes=60,
        path=path,
        now=now,
    )
    due = monitoring.due_monitor_schedules(path=path, now=now)
    dry = monitoring.run_due_monitor_schedules(path=path, now=now, execute=False)
    listed = monitoring.list_monitor_schedules(path=path)

    assert added["created"] is True
    assert due["summary"]["due"] == 1
    assert dry["summary"]["processed"] == 1
    assert dry["summary"]["executed"] == 0
    assert dry["results"][0]["case"] == "monitor-user-bob-20260608-120000"
    assert listed["schedules"][0]["last_case"] is None
    assert listed["schedules"][0]["next_run_at"] == "2026-06-08T13:00:00+00:00"


def test_monitor_run_due_uses_job_queue_and_records_diff_alert(tmp_path: Path, monkeypatch):
    now = datetime(2026, 6, 8, 12, 0, tzinfo=timezone.utc)
    path = tmp_path / "monitoring.json"
    monitoring.add_monitor_schedule(
        "bob",
        module="username",
        case_prefix="monitor-user-bob",
        interval_minutes=60,
        path=path,
        now=now,
    )
    state = monitoring._load_state(path)
    state["schedules"][0]["last_case"] = "monitor-user-bob-previous"
    monitoring._write_state(state, path)

    created = {}

    def fake_create_job(target, **kwargs):
        created["target"] = target
        created.update(kwargs)
        return DummyJob()

    def fake_summary(case_name):
        if case_name.endswith("previous"):
            return {
                "meta": {"found": True},
                "entities": [{"type": "username", "value": "bob"}],
                "findings": [],
                "relations": [],
            }
        return {
            "meta": {"found": True},
            "entities": [{"type": "username", "value": "bob"}],
            "findings": [{"source_id": "api:test", "entity_value": "bob", "profile_url": "https://x/bob"}],
            "relations": [],
        }

    monkeypatch.setattr(monitoring, "create_job", fake_create_job)
    monkeypatch.setattr(monitoring, "run_job", lambda job_id, **kwargs: {"job": job_id, "status": "finished"})
    monkeypatch.setattr(monitoring, "job_as_dict", lambda job: job.as_dict())
    monkeypatch.setattr(monitoring, "build_case_summary", fake_summary)
    monkeypatch.setattr("bedniiosint.core.jobs.get_job", lambda job_id: None)

    result = monitoring.run_due_monitor_schedules(path=path, now=now, execute=True)
    listed = monitoring.list_monitor_schedules(path=path)

    assert created["target"] == "bob"
    assert created["module"] == "username"
    assert created["case_name"] == "monitor-user-bob-20260608-120000"
    assert result["summary"]["executed"] == 1
    assert result["summary"]["alerts"] == 1
    assert result["results"][0]["alert"]["changed"]["new_findings"] == 1
    assert listed["summary"]["alerts"] == 1
    assert listed["schedules"][0]["last_case"] == "monitor-user-bob-20260608-120000"


def test_monitor_cli_add_list_due_dry_run(tmp_path: Path, monkeypatch):
    runner = CliRunner()
    monkeypatch.setattr(monitoring, "_now", lambda: datetime(2026, 6, 8, 12, 0, tzinfo=timezone.utc))
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        add = runner.invoke(
            app,
            [
                "monitor",
                "add",
                "bob",
                "--module",
                "username",
                "--case-prefix",
                "monitor-user-bob",
                "--interval-minutes",
                "60",
            ],
        )
        listing = runner.invoke(app, ["monitor", "list", "--json"])
        due = runner.invoke(app, ["monitor", "due", "--json"])
        run_due = runner.invoke(app, ["monitor", "run-due", "--dry-run"])
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)

    assert add.exit_code == 0
    assert listing.exit_code == 0
    assert due.exit_code == 0
    assert run_due.exit_code == 0
    assert '"schedules": 1' in listing.output
    assert '"due": 1' in due.output
    assert '"executed": 0' in run_due.output


def test_monitoring_web_api_and_page(tmp_path: Path):
    import pytest

    import bedniiosint.web.app as web_app

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    from fastapi.testclient import TestClient

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        client = TestClient(web_app.app)
        add = client.post(
            "/monitoring/schedules",
            params={
                "target": "bob",
                "module": "username",
                "case_prefix": "monitor-user-bob",
                "interval_minutes": 60,
            },
        )
        listing = client.get("/monitoring.json")
        due = client.get("/monitoring/due")
        dry = client.post("/monitoring/run-due", params={"dry_run": True})
        page = client.get("/monitoring")
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)

    assert add.status_code == 200
    assert add.json()["schedule"]["target"] == "bob"
    assert listing.status_code == 200
    assert listing.json()["summary"]["schedules"] == 1
    assert due.status_code == 200
    assert due.json()["summary"]["due"] == 1
    assert dry.status_code == 200
    assert dry.json()["summary"]["executed"] == 0
    assert page.status_code == 200
    assert "Monitoring" in page.text
    assert "monitor-user-bob" in page.text


def test_monitoring_page_template_autoescapes_schedule_values(tmp_path: Path):
    import pytest

    import bedniiosint.web.app as web_app

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    from fastapi.testclient import TestClient

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        monitoring.add_monitor_schedule(
            '<script>alert("x")</script>',
            module="username",
            case_prefix="monitor-xss",
            interval_minutes=60,
        )
        page = TestClient(web_app.app).get("/monitoring")
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)

    assert page.status_code == 200
    assert '<script>alert("x")</script>' not in page.text
    assert "&lt;script&gt;alert" in page.text
    assert "/static/monitoring.css" in page.text
