from __future__ import annotations

from bedniiosint.core.pivoting import build_case_pivot_plan


def test_case_pivot_plan_requires_independent_confirmation():
    findings = [
        {
            "entity_type": "username",
            "entity_value": "alice",
            "source_id": "api:first",
            "status": "exists",
            "confidence": 0.9,
        },
        {
            "entity_type": "username",
            "entity_value": "alice",
            "source_id": "api:second",
            "status": "exists",
            "confidence": 0.82,
        },
        {
            "entity_type": "email",
            "entity_value": "alice@example.com",
            "source_id": "api:first",
            "status": "exists",
            "confidence": 0.7,
        },
    ]
    entities = [
        {"type": "username", "value": "Alice"},
        {"type": "email", "value": "alice@example.com"},
    ]

    plan = build_case_pivot_plan(findings, entities)
    steps = {(row["from_type"], row["from_value"], row["to_type"]): row for row in plan["steps"]}

    username_to_email = steps[("username", "alice", "email")]
    email_to_domain = steps[("email", "alice@example.com", "domain")]

    assert plan["style"] == "case_pivot_chain"
    assert username_to_email["ready"] is True
    assert username_to_email["independent_sources"] == 2
    assert "contact_discovery,email_enrichment" in username_to_email["command"]
    assert email_to_domain["ready"] is False
    assert email_to_domain["blocked_reason"] == "needs independent corroboration before automatic pivot"
    assert plan["summary"]["ready"] == 1
    assert plan["summary"]["blocked"] == 2
