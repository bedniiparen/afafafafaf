from __future__ import annotations

import xml.etree.ElementTree as ET


def _sample_results():
    return [
        {
            "id": "github:alice",
            "source_id": "github",
            "source_name": "GitHub",
            "entity_type": "username",
            "matched_entity": "alice",
            "title": "Alice GitHub",
            "url": "https://github.com/alice",
            "confidence_score": 0.9,
            "found_at": "2026-01-01T00:00:00Z",
        },
        {
            "id": "gitlab:alice",
            "source_id": "gitlab",
            "source_name": "GitLab",
            "entity_type": "username",
            "matched_entity": "alice",
            "title": "Alice GitLab",
            "url": "https://gitlab.com/alice",
            "confidence_score": 0.8,
            "found_at": "2026-01-02T00:00:00Z",
        },
    ]


def test_graphml_export_builds_valid_typed_graph(tmp_path):
    from bedniiosint.search.graphml_export import build_graph, to_graphml, write_graphml

    links = [
        {
            "kind": "cross_platform_username",
            "member_ids": ["github:alice", "gitlab:alice"],
            "confidence": 0.88,
        }
    ]

    nodes, edges = build_graph(_sample_results(), links, seed="alice", seed_type="username")
    xml = to_graphml(_sample_results(), links, seed="alice", seed_type="username")
    path = write_graphml(tmp_path / "case.graphml", _sample_results(), links, seed="alice")

    assert len(nodes) == 3
    assert any(edge["etype"] == "cross_platform_username" for edge in edges)
    assert "Alice GitHub" in xml
    assert ET.fromstring(xml).tag.endswith("graphml")
    assert path.endswith("case.graphml")


def test_source_health_grades_and_reports():
    from bedniiosint.search.source_health import SourceHealth

    now = [100.0]

    def clock():
        return now[0]

    health = SourceHealth(clock=clock)
    health.record("wmn", ok=True, latency=0.2, status="ok", results=3)
    health.record("wmn", ok=False, latency=0.4, error="timeout")
    health.record("github", ok=True, latency=0.1, status=200, results=1)

    rows = {row["source_id"]: row for row in health.snapshot()}
    markdown = health.report_markdown()

    assert rows["wmn"]["success_rate"] == 0.5
    assert rows["wmn"]["health"] == "failing"
    assert rows["github"]["health"] == "healthy"
    assert "Source health report" in markdown


def test_html_report_embeds_graph_and_sorted_timeline(tmp_path):
    from bedniiosint.search.html_report import render_html, write_report

    html = render_html(_sample_results(), [], case_name="Case Alice", seed="alice")
    path = write_report(tmp_path / "case.html", _sample_results(), [], case_name="Case Alice", seed="alice")

    assert "Case Alice" in html
    assert "github:alice" in html
    assert html.index("2026-01-01T00:00:00Z") < html.index("2026-01-02T00:00:00Z")
    assert path.endswith("case.html")


def test_layers_registry_runs_order_and_strict_mode():
    from bedniiosint.search.layers import Registry

    registry = Registry()

    @registry.analyzer("collect")
    def collect(ctx):
        return [{"id": "r1", "source_id": "test", "matched_entity": ctx.entity}]

    @registry.connector("link")
    def link(ctx):
        return [{"kind": "same", "member_ids": ["r1"], "confidence": 1.0}]

    @registry.visualizer("count")
    def count(ctx):
        return {"results": len(ctx.results), "links": len(ctx.links)}

    registry.register_playbook(
        {"name": "full", "analyzers": ["collect"], "connectors": ["link"], "visualizers": ["count"]}
    )
    registry.register_playbook({"name": "missing", "analyzers": ["nope"]})

    ctx = registry.run_playbook("full", "alice")

    assert ctx.log == ["analyzer:collect", "connector:link", "visualizer:count"]
    assert ctx.artifacts["count"] == {"results": 1, "links": 1}
    assert registry.run_playbook("missing", "alice").log == ["skip:nope"]
    try:
        registry.run_playbook("missing", "alice", strict=True)
    except KeyError as exc:
        assert "unknown stage" in str(exc)
    else:
        raise AssertionError("strict mode must fail on unknown stage")


def test_search_pipeline_includes_p2_artifacts_and_source_health(monkeypatch):
    import bedniiosint.search.pipeline as pipeline
    from bedniiosint.search.connectors.base import BaseConnector, QueryPlan
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.source_health import GLOBAL_SOURCE_HEALTH

    class FakeWmnConnector(BaseConnector):
        source_id = "wmn"
        source_name = "WMN"

        def run(self, query_plan: QueryPlan):
            return {"status": "ok", "items": [{"username": query_plan.entity_input}]}

        def parse(self, raw_response):
            return list(raw_response["items"])

        def normalize(self, parsed):
            return [
                SearchResult(
                    id="wmn:alice",
                    source_id="wmn",
                    source_name="WMN",
                    entity_input="alice",
                    entity_type="username",
                    matched_entity="alice",
                    title="Alice",
                    url="https://example.test/alice",
                    confidence_score=0.8,
                )
            ]

    GLOBAL_SOURCE_HEALTH.clear()
    monkeypatch.setitem(pipeline.CONNECTOR_CLASSES, "wmn", FakeWmnConnector)

    payload = pipeline.run_planned_search_pipeline(
        "alice",
        entity_type="username",
        source_ids=["wmn"],
        include_username_scan=False,
        include_dorking=False,
    )

    assert payload["standalone_connector_ids"] == ["wmn"]
    assert payload["visual_artifacts"]["graphml"].startswith("<?xml")
    assert "<html" in payload["visual_artifacts"]["html_report"]
    assert payload["source_health"]["sources"][0]["source_id"] == "wmn"
