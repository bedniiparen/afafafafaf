import os

import pytest

from bedniiosint.catalog import adapter_for, verify_sources
from bedniiosint.core.source_context import SourceRunContext


def _source_live_enabled() -> bool:
    return os.getenv("BEDNIIOSINT_SOURCE_LIVE_TESTS", "").strip() == "1"


def _media_live_enabled() -> bool:
    return os.getenv("BEDNIIOSINT_MEDIA_LIVE_TESTS", "").strip() == "1"


def _skip_unless_source_live() -> None:
    if not _source_live_enabled():
        pytest.skip("set BEDNIIOSINT_SOURCE_LIVE_TESTS=1 to run live source checks")


def _skip_unless_media_live() -> None:
    if not _media_live_enabled():
        pytest.skip("set BEDNIIOSINT_MEDIA_LIVE_TESTS=1 to run live media checks")


def test_live_source_verification_when_configured():
    _skip_unless_source_live()
    source_id = os.getenv("BEDNIIOSINT_SOURCE_LIVE_ID", "").strip()
    if not source_id:
        pytest.skip("set BEDNIIOSINT_SOURCE_LIVE_ID, e.g. api:shodan")
    target = os.getenv("BEDNIIOSINT_SOURCE_LIVE_TARGET", "").strip() or None
    allow_opt_in = os.getenv("BEDNIIOSINT_SOURCE_LIVE_ALLOW_OPT_IN", "").strip() == "1"

    result = verify_sources(
        mode="live",
        source_id=source_id,
        target=target,
        allow_opt_in=allow_opt_in,
    )

    assert result["summary"]["sources"] == 1, result
    assert result["summary"]["passed"] == 1, result


def test_live_tineye_image_url_when_configured():
    _skip_unless_media_live()
    if not os.getenv("TINEYE_API_KEY", "").strip():
        pytest.skip("set TINEYE_API_KEY for live TinEye checks")
    image_url = os.getenv("TINEYE_LIVE_IMAGE_URL", "").strip()
    if not image_url:
        pytest.skip("set TINEYE_LIVE_IMAGE_URL for live TinEye image URL lookup")

    context = SourceRunContext(legal_flags={"allow_sensitive_sources": True})
    result = adapter_for("api:tineye").run(image_url, input_type="image_url", context=context)

    assert result.status == "ok", result.as_dict()
    assert result.status_code is not None and result.status_code < 400
    assert result.normalized is not None


def test_live_tineye_image_upload_when_explicitly_enabled():
    _skip_unless_media_live()
    if os.getenv("BEDNIIOSINT_MEDIA_LIVE_UPLOAD", "").strip() != "1":
        pytest.skip("set BEDNIIOSINT_MEDIA_LIVE_UPLOAD=1 to upload a live media file")
    if not os.getenv("TINEYE_API_KEY", "").strip():
        pytest.skip("set TINEYE_API_KEY for live TinEye upload")
    image_path = os.getenv("TINEYE_LIVE_IMAGE_PATH", "").strip()
    if not image_path:
        pytest.skip("set TINEYE_LIVE_IMAGE_PATH for live TinEye upload")

    context = SourceRunContext(
        legal_flags={"allow_uploads": True, "allow_sensitive_sources": True}
    )
    result = adapter_for("api:tineye").run(image_path, input_type="image", context=context)

    assert result.status == "ok", result.as_dict()
    assert result.status_code is not None and result.status_code < 400
    assert result.normalized is not None
