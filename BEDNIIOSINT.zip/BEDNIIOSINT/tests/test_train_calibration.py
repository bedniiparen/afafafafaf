from __future__ import annotations

import json


def test_load_pairs_file_and_metrics(tmp_path):
    from bedniiosint.eval.train_calibration import (
        brier_score,
        expected_calibration_error,
        load_pairs_file,
        log_loss,
        reliability_table,
    )

    path = tmp_path / "pairs.json"
    path.write_text(
        json.dumps(
            [
                {"confidence": 0.8, "label": 1},
                {"score": 0.2, "correct": 0},
                {"prediction": {"confidence_score": 0.7}, "is_match": "match"},
            ]
        ),
        encoding="utf-8",
    )

    pairs = load_pairs_file(path)
    probs = [score for score, _ in pairs]
    labels = [label for _, label in pairs]

    assert pairs == [(0.8, 1), (0.2, 0), (0.7, 1)]
    assert round(brier_score(probs, labels), 4) == 0.0567
    assert round(log_loss(probs, labels), 4) == 0.2677
    assert expected_calibration_error(probs, labels, bins=2) == 0.2333
    assert reliability_table(probs, labels, bins=2)[0]["count"] == 1


def test_validate_pairs_file_accepts_real_review_rows(tmp_path):
    from bedniiosint.eval.train_calibration import validate_pairs_file

    path = tmp_path / "pairs.json"
    path.write_text(
        json.dumps(
            [
                {"prediction": {"confidence_score": 0.8}, "is_match": True},
                {"result": {"confidence": 0.2}, "is_match": "no_match"},
            ]
        ),
        encoding="utf-8",
    )

    assert validate_pairs_file(path) == []


def test_cross_validate_reports_raw_and_calibrated_metrics():
    from bedniiosint.eval.train_calibration import cross_validate

    pairs = [
        (0.15, 0),
        (0.18, 0),
        (0.22, 0),
        (0.28, 0),
        (0.34, 0),
        (0.39, 0),
        (0.44, 0),
        (0.49, 0),
        (0.51, 1),
        (0.56, 1),
        (0.61, 1),
        (0.66, 1),
        (0.72, 1),
        (0.78, 1),
        (0.84, 1),
        (0.9, 1),
    ]

    report = cross_validate(pairs, folds=4, seed=7)

    assert report["folds"] == 4
    assert set(report["raw"]) == {"brier", "log_loss", "ece"}
    assert set(report["calibrated"]) == {"brier", "log_loss", "ece"}
    assert report["calibrated"]["ece"] <= report["raw"]["ece"]


def test_collect_pairs_from_dataset_uses_benchmark_matching():
    from bedniiosint.eval.train_calibration import collect_pairs_from_dataset
    from bedniiosint.search.models import SearchResult

    def fake_search(target: str, entity_type: str):
        return [
            SearchResult(
                id="hit",
                source_id="github",
                source_name="GitHub",
                entity_input=target,
                entity_type=entity_type,
                matched_entity=target,
                url=f"https://github.com/{target}",
                confidence_score=0.82,
            ),
            SearchResult(
                id="miss",
                source_id="reddit",
                source_name="Reddit",
                entity_input=target,
                entity_type=entity_type,
                matched_entity=target,
                url=f"https://reddit.com/user/{target}",
                confidence_score=0.3,
            ),
        ]

    pairs = collect_pairs_from_dataset(
        [{"target": "alice", "entity_type": "username", "expected": ["https://github.com/alice"]}],
        fake_search,
    )

    assert pairs == [(0.82, 1), (0.3, 0)]


def test_train_calibration_main_writes_model_and_pairs(tmp_path):
    from bedniiosint.eval.train_calibration import main

    pairs_path = tmp_path / "pairs.json"
    model_path = tmp_path / "nested" / "calibration.json"
    saved_pairs_path = tmp_path / "nested" / "pairs-out.json"
    pairs_path.write_text(
        json.dumps(
            [
                {"confidence": 0.15, "label": 0},
                {"confidence": 0.2, "label": 0},
                {"confidence": 0.3, "label": 0},
                {"confidence": 0.4, "label": 0},
                {"confidence": 0.6, "label": 1},
                {"confidence": 0.7, "label": 1},
                {"confidence": 0.8, "label": 1},
                {"confidence": 0.9, "label": 1},
            ]
        ),
        encoding="utf-8",
    )

    exit_code = main(
        [
            "--pairs",
            str(pairs_path),
            "--out",
            str(model_path),
            "--save-pairs",
            str(saved_pairs_path),
            "--folds",
            "4",
        ]
    )

    model = json.loads(model_path.read_text(encoding="utf-8"))
    saved_pairs = json.loads(saved_pairs_path.read_text(encoding="utf-8"))
    assert exit_code == 0
    assert set(model) == {"thresholds", "calibrated"}
    assert model["thresholds"]
    assert saved_pairs[0] == {"confidence": 0.15, "label": 0}
