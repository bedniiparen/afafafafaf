from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any
import time
import warnings

import pytest
from typer.testing import CliRunner

from bedniiosint.catalog import registry_entries
from bedniiosint.catalog.adapters import AdapterResult, adapter_for
from bedniiosint.cli import app
from bedniiosint.core.source_pipeline import pipeline_sources
from bedniiosint.search.clustering import (
    annotate_result_clusters,
    cluster_search_results,
    entity_resolution_key,
    result_dedup_key,
)
from bedniiosint.search.connectors.base import BaseConnector, DummyConnector, QueryPlan
from bedniiosint.search.connectors.catalog import CatalogConnector
from bedniiosint.search.concurrent import run_catalog_sources_concurrently
from bedniiosint.search.dorking import build_dorking_results
from bedniiosint.search.evidence import (
    build_search_evidence,
    build_search_run_evidence,
    summarize_search_results,
)
from bedniiosint.search.event_graph import build_search_event_plan
from bedniiosint.search.explain import explain_search_run
from bedniiosint.search.investigation import build_investigation_plan
from bedniiosint.search.models import SearchResult
from bedniiosint.search.pipeline import (
    SEARCH_TO_CATALOG_SOURCE_IDS,
    run_planned_search_pipeline,
)
from bedniiosint.search.pivots import build_result_pivots
from bedniiosint.search.planner import (
    build_entity_variant_details,
    build_entity_variants,
    plan_search,
)
from bedniiosint.search.query_parser import parse_search_query
from bedniiosint.search.readiness import search_sources_status
from bedniiosint.search.report import build_search_report_summary, render_search_markdown
from bedniiosint.search.scoring import score_search_results
from bedniiosint.search.search_only_catalog import parse_markdown_sites
from bedniiosint.search.scope_resolver import resolve_scope
from bedniiosint.search.source_registry import (
    REQUIRED_SOURCE_FIELDS,
    UnknownSourceError,
    filter_sources,
    get_source,
    list_sources,
    load_source_registry,
    validate_source_registry,
)
from bedniiosint.search.username_candidates import build_username_site_candidates
from bedniiosint.search.username_scan import build_username_scan_results
from bedniiosint.modules.username.scanner import SiteResult


def test_source_registry_loads_successfully():
    registry = load_source_registry()
    assert registry.version >= 1
    assert len(registry.sources) >= 12
    assert validate_source_registry(registry)["sources"] == len(registry.sources)


def test_priority_public_profile_sources_are_registered():
    from bedniiosint.search.connectors import CONNECTOR_CLASSES

    expected = {"telegram_public", "youtube_handle", "vk_public"}
    extra_expected = {"steam_id", "twitch_user", "pinterest_user", "habr_user"}
    assert expected <= {row["id"] for row in list_sources()}
    assert expected <= set(CONNECTOR_CLASSES)
    assert extra_expected <= {row["id"] for row in list_sources()}
    assert extra_expected <= set(CONNECTOR_CLASSES)
    for source_id in expected | extra_expected:
        source = get_source(source_id)
        assert source["auth_required"] is False
        assert "username" in source["supported_entity_types"]


def test_every_source_has_required_fields():
    for source in list_sources():
        assert REQUIRED_SOURCE_FIELDS <= set(source)


def test_filter_by_entity_type_works():
    rows = filter_sources(entity_type="wallet")
    source_ids = {row["id"] for row in rows}
    assert "blockchain_explorer" in source_ids
    assert all("wallet" in row["supported_entity_types"] for row in rows)


def test_filter_by_scope_works():
    rows = filter_sources(scope="threat_intel")
    assert {"urlscan", "virustotal", "abuseipdb"} <= {row["id"] for row in rows}


def test_production_connector_groups_are_registered_and_mapped():
    source_ids = {row["id"] for row in list_sources()}
    expected = {
        "public_code_search",
        "archive_discovery",
        "contact_discovery",
        "social_profiles",
        "fediverse_profiles",
        "public_social_intel",
        "creator_video_search",
        "email_enrichment",
        "email_reputation",
        "ip_enrichment",
        "ip_behavior_reputation",
        "passive_dns_enrichment",
        "news_mentions",
        "media_reverse_search",
        "business_knowledge_graph",
        "geocode_public",
        "open_threat_feeds",
        "phone_lookup",
        "attack_surface",
        "technology_fingerprint",
        "osint_aggregator",
    }

    assert expected <= source_ids
    assert SEARCH_TO_CATALOG_SOURCE_IDS["email_enrichment"] == ["api:gravatar"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["passive_dns_enrichment"] == ["api:hackertarget"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["news_mentions"] == ["api:gdelt"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["media_reverse_search"] == ["api:tineye"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["creator_video_search"] == ["api:youtube"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["archive_discovery"] == ["api:wayback_cdx", "api:common_crawl"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["contact_discovery"] == ["api:hunter"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["fediverse_profiles"] == ["api:mastodon_lookup"]
    assert SEARCH_TO_CATALOG_SOURCE_IDS["osint_aggregator"] == ["api:osintly_api"]
    assert "api:alienvault_otx" in SEARCH_TO_CATALOG_SOURCE_IDS["open_threat_feeds"]
    assert "api:threatfox" in SEARCH_TO_CATALOG_SOURCE_IDS["open_threat_feeds"]
    assert "api:shodan" in SEARCH_TO_CATALOG_SOURCE_IDS["attack_surface"]


def test_expanded_search_groups_map_to_known_catalog_api_sources():
    catalog_ids = {entry.id for entry in registry_entries() if entry.kind == "api"}
    expanded_groups = {
        "public_code_search": ["api:github_search"],
        "archive_discovery": ["api:wayback_cdx", "api:common_crawl"],
        "contact_discovery": ["api:hunter"],
        "fediverse_profiles": ["api:mastodon_lookup"],
        "public_social_intel": ["api:open_measures"],
        "creator_video_search": ["api:youtube"],
        "passive_dns_enrichment": ["api:hackertarget"],
        "news_mentions": ["api:gdelt"],
        "media_reverse_search": ["api:tineye"],
        "ip_behavior_reputation": ["api:greynoise"],
        "osint_aggregator": ["api:osintly_api"],
    }

    for source_id, mapped_ids in expanded_groups.items():
        source = get_source(source_id)
        assert source["api_type"] == "catalog_adapter_group"
        assert SEARCH_TO_CATALOG_SOURCE_IDS[source_id] == mapped_ids
        assert set(mapped_ids) <= catalog_ids


def test_expanded_search_groups_are_filterable_by_new_entity_types():
    assert "media_reverse_search" in {
        row["id"] for row in filter_sources(entity_type="image_url")
    }
    assert "fediverse_profiles" in {
        row["id"] for row in filter_sources(entity_type="fediverse_account")
    }


def test_search_query_parser_extracts_scope_terms_sources_and_filters():
    parsed = parse_search_query(
        'ivanbeats /creator/music/beatmaking +producer -anime @creator_video_search region:us'
    )

    assert parsed.entity == "ivanbeats"
    assert parsed.scope_path == "/creator/music/beatmaking"
    assert parsed.boost_terms == ["producer"]
    assert parsed.exclude_terms == ["anime"]
    assert parsed.source_hints == ["creator_video_search"]
    assert parsed.filters == {"region": "us"}
    assert parsed.free_terms == ["us"]


def test_search_query_parser_keeps_control_filters_out_of_free_terms():
    parsed = parse_search_query(
        "scally milano /music platform:vk,instagram,youtube mode:deep limit:80 type:profile region:ru"
    )

    assert parsed.entity == "scally milano"
    assert parsed.scope_path == "/music"
    assert parsed.filters == {
        "platform": "vk,instagram,youtube",
        "mode": "deep",
        "limit": "80",
        "type": "profile",
        "region": "ru",
    }
    assert parsed.free_terms == ["ru"]


def test_scope_resolver_maps_aliases_to_registry_scope_and_sources():
    infra = resolve_scope("/infra", "domain")
    cyber = resolve_scope("/cyber/threatintel", "ip")
    music = resolve_scope("/music", "company")

    assert infra.path == "/infra/domain"
    assert infra.registry_scope == "infrastructure"
    assert {"rdap", "dns", "crtsh", "passive_dns_enrichment"} <= set(infra.source_ids)
    assert cyber.registry_scope == "threat_intel"
    assert {"urlscan", "open_threat_feeds", "ip_behavior_reputation"} <= set(cyber.source_ids)
    assert music.path == "/creator/music/beatmaking"
    assert music.registry_scope == "media"
    assert music.entity_type_hint == "username"
    assert {"creator_video_search", "public_social_intel", "social_profiles", "web_search"} <= set(music.source_ids)


def test_investigation_plan_suggests_routes_and_commands():
    plan = build_investigation_plan("example.com")

    assert plan["entity_input"] == "example.com"
    assert plan["entity_type"] == "domain"
    assert plan["routes"][0]["scope_path"] == "/infra/domain"
    assert "bedniiosint search-plan" in plan["routes"][0]["commands"]["plan"]
    assert plan["counts"]["routes"] >= 3


def test_search_sources_status_compact_omits_nested_catalog_payload():
    status = search_sources_status(compact=True)
    web_search = next(row for row in status["sources"] if row["source_id"] == "web_search")
    coverage = {
        row["target_type"]: row
        for row in status["summary"]["coverage_by_target_type"]
    }

    assert status["summary"]["compact"] is True
    assert {"username", "email", "domain", "ip", "url", "company"} <= set(coverage)
    assert coverage["domain"]["sources"] >= coverage["domain"]["implemented"] >= coverage["domain"]["configured"]
    assert coverage["domain"]["configured_label"] == (
        f"{coverage['domain']['configured']}/{coverage['domain']['implemented']}"
    )
    assert "mapped_catalog_sources" not in web_search
    assert web_search["catalog_source_ids"] == ["api:google_cse"]
    assert web_search["mapped_count"] == 1
    assert web_search["missing_env_vars"] == ["GOOGLE_CSE_API_KEY", "GOOGLE_CSE_CX"]


def test_search_sources_status_full_keeps_nested_catalog_payload():
    status = search_sources_status(compact=False)
    rdap = next(row for row in status["sources"] if row["source_id"] == "rdap")

    assert status["summary"]["compact"] is False
    assert rdap["mapped_catalog_sources"]
    assert rdap["mapped_catalog_sources"][0]["id"] == "api:rdap"


def test_unknown_source_handled_safely():
    with pytest.raises(UnknownSourceError) as exc:
        get_source("missing-source")
    assert "unknown source_id" in str(exc.value)
    assert "rdap" in str(exc.value)


def test_search_result_can_be_created_and_serialized():
    result = SearchResult(
        id="test:1",
        source_id="dummy",
        source_name="Dummy",
        entity_input="example.com",
        entity_type="domain",
        matched_entity="example.com",
        title="Example",
        confidence_score=0.5,
    )
    payload = result.as_dict()
    assert payload["source_id"] == "dummy"
    assert SearchResult.from_dict(payload).matched_entity == "example.com"


def test_priority_platform_scoring_boosts_social_profiles():
    result = SearchResult(
        id="telegram:1",
        source_id="telegram_public",
        source_name="Telegram (public)",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        detected_platform="telegram",
        confidence_score=0.5,
    )
    review_only = SearchResult(
        id="vk:review",
        source_id="vk_public",
        source_name="VK Profile",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        detected_platform="vk",
        tags=["review_only"],
        confidence_score=0.5,
    )

    score_search_results([result, review_only])

    assert result.confidence_score == 0.55
    assert "priority_platform" in result.tags
    assert review_only.confidence_score == 0.5
    assert "priority_platform" not in review_only.tags


def test_search_evidence_records_are_structured_and_hash_raw_data():
    record = {
        "source_id": "api:rdap",
        "target": "example.com",
        "status": "exists",
        "confidence": 0.82,
        "input_type": "domain",
        "method": "GET",
        "url": "https://rdap.org/domain/example.com",
        "status_code": 200,
        "title": "RDAP",
        "entities": [{"type": "domain", "value": "example.com"}],
        "relations": [
            {
                "src_type": "domain",
                "src_value": "example.com",
                "rel": "registered_by",
                "dst_type": "registrar",
                "dst_value": "Example Registrar",
            }
        ],
        "timeline": [
            {
                "kind": "registry_observed",
                "entity_type": "domain",
                "entity_value": "example.com",
                "source": "api:rdap",
                "confidence": 0.82,
                "description": "RDAP record observed",
            }
        ],
        "raw": {"handle": "EXAMPLE"},
    }
    evidence = build_search_evidence(record, source=get_source("rdap"))
    kinds = {row["kind"] for row in evidence}

    assert {
        "source_observation",
        "source_url",
        "normalized_entity",
        "normalized_relation",
        "timeline_event",
        "raw_hash",
    } <= kinds
    raw_hash = next(row for row in evidence if row["kind"] == "raw_hash")
    assert raw_hash["algorithm"] == "sha256"
    assert len(raw_hash["hash"]) == 64
    assert all(row.get("id") for row in evidence)


def test_base_connector_interface_exists():
    connector = BaseConnector({"id": "base-test", "name": "Base Test"})
    plan = connector.build_queries({"type": "domain", "value": "example.com"})
    assert isinstance(plan, QueryPlan)
    assert plan.source_id == "base-test"
    assert plan.queries == ["example.com"]
    with pytest.raises(NotImplementedError):
        connector.run(plan)


def test_dummy_connector_returns_normalized_search_result():
    connector = DummyConnector()
    query_plan = connector.build_queries({"type": "username", "value": "alice"})
    results = connector.normalize(connector.parse(connector.run(query_plan)))
    assert len(results) == 1
    assert results[0].source_id == "dummy"
    assert results[0].matched_entity == "alice"


def test_entity_variant_details_expand_email_and_url():
    email_variants = build_entity_variant_details("Alice@Example.com", "email")
    assert any(row.kind == "email_localpart" and row.value == "Alice" for row in email_variants)
    assert any(row.kind == "email_domain" and row.value == "example.com" for row in email_variants)
    assert "example.com" in build_entity_variants("https://example.com/path", "url")


def test_query_planner_v2_expands_aliases_and_warns_on_private_ip():
    url_variants = build_entity_variant_details("https://github.com/Alice-Example", "url")
    assert any(row.kind == "url_profile_username" and row.value == "Alice-Example" for row in url_variants)
    assert any(row.kind == "username_underscore" and row.value == "alice_example" for row in url_variants)

    company_variants = build_entity_variant_details("Example LLC", "company")
    assert any(row.kind == "company_without_suffix" and row.value == "Example" for row in company_variants)
    assert any(row.kind == "company_domain_guess" and row.value == "example.com" for row in company_variants)

    plan = plan_search("192.168.1.10", entity_type="ip")
    assert "private_ip_no_public_osint_lookup" in plan.warnings
    assert plan.sources == []


def test_search_planner_selects_high_value_domain_sources_without_auth_by_default():
    plan = plan_search("https://www.example.com/path", entity_type="domain", max_sources=8)
    source_ids = [source["id"] for source in plan.sources]
    assert "dns" in source_ids
    assert "rdap" in source_ids
    assert "crtsh" in source_ids
    assert "virustotal" not in source_ids
    assert any(variant.kind == "domain_host" for variant in plan.variant_details)
    assert all(query.metadata["variant_details"] for query in plan.queries)


def test_search_planner_routes_embedded_scope_and_cleans_entity():
    plan = plan_search("example.com /infra/domain +github -news")
    source_ids = {source["id"] for source in plan.sources}

    assert plan.entity_input == "example.com"
    assert plan.entity_type == "domain"
    assert plan.scope == "infrastructure"
    assert plan.parsed_query["scope_path"] == "/infra/domain"
    assert plan.resolved_scope["path"] == "/infra/domain"
    assert {"rdap", "dns", "crtsh", "passive_dns_enrichment"} <= source_ids
    assert "news_mentions" not in source_ids
    assert plan.source_routing["boost_terms"] == ["github"]
    assert plan.source_routing["exclude_terms"] == ["news"]


def test_search_planner_uses_source_hints_and_query_expansion():
    plan = plan_search(
        "ivanbeats /creator/video/youtube +producer -anime @youtube",
        include_auth_required=True,
    )

    assert plan.entity_input == "ivanbeats"
    assert [source["id"] for source in plan.sources] == ["creator_video_search", "youtube_handle"]
    query_plan = plan.queries[0]
    assert any("producer" in query for query in query_plan.queries)
    assert any("-anime" in query for query in query_plan.queries)
    assert query_plan.metadata["query_expansion"]["scope_path"] == "/creator/video/youtube"


def test_search_planner_routes_music_scope_to_artist_platforms():
    plan = plan_search("scally milano /music", include_auth_required=True)
    source_ids = {source["id"] for source in plan.sources}
    queries = " ".join(query for row in plan.queries for query in row.queries)
    dorking_rows = [row.as_dict() for row in build_dorking_results(plan)]
    urls = " ".join(row["url"] for row in dorking_rows)

    assert plan.entity_input == "scally milano"
    assert plan.entity_type == "username"
    assert plan.scope == "media"
    assert plan.resolved_scope["path"] == "/creator/music/beatmaking"
    assert {"creator_video_search", "public_social_intel", "social_profiles", "web_search"} <= source_ids
    assert "site:vk.com" in queries
    assert "site:instagram.com" in queries
    assert "site:genius.com/artists" in queries
    assert "site:music.yandex.ru" in queries
    assert "https://vk.com/scally-milano" in urls
    assert "https://www.instagram.com/scally-milano/" in urls
    assert "https://genius.com/artists/scally-milano" in urls
    assert "https://www.youtube.com/@scally-milano" in urls
    assert "https://music.yandex.ru/search?text=scally+milano" in urls
    assert dorking_rows[0]["source_id"].startswith("dorking:music_profile:")
    assert dorking_rows[0]["normalized_data"]["lead_kind"] == "direct_profile_candidate"
    assert dorking_rows[0]["normalized_data"]["candidate_rank"] == 1


def test_music_dorking_filters_platforms_and_caps_noise():
    plan = plan_search(
        "scally milano /music platform:vk,instagram,youtube mode:fast limit:40",
        include_auth_required=True,
    )
    dorking_rows = [row.as_dict() for row in build_dorking_results(plan)]
    urls = " ".join(row["url"] for row in dorking_rows)
    source_ids = {row["source_id"] for row in dorking_rows}

    assert len(dorking_rows) <= 40
    assert "https://vk.com/scally-milano" in urls
    assert "https://www.instagram.com/scally-milano/" in urls
    assert "https://www.youtube.com/@scally-milano" in urls
    assert "dorking:music_profile:genius" not in source_ids
    assert all("google.com/search" not in row["url"] for row in dorking_rows[:10])


def test_username_candidates_use_sherlock_catalog_regex_and_platform_filter():
    github = build_username_site_candidates(["alice"], platforms={"github"}, limit=5)
    illegal = build_username_site_candidates(
        ["bad/name"],
        platforms={"github"},
        include_illegal=True,
        limit=5,
    )
    legal_sources = {row.site_key for row in github}

    assert "github" in legal_sources
    assert any(row.display_url == "https://github.com/alice" for row in github)
    assert any(row.site_key == "github" and row.status == "illegal" for row in illegal)
    assert all(row.display_url == "" for row in illegal if row.status == "illegal")


def test_username_candidates_prioritize_high_value_sites_and_interleave_name_variants():
    rows = build_username_site_candidates(
        ["ivan_ivanov", "ivan-ivanov", "ivanivanov"],
        per_site_limit=2,
        limit=28,
    )
    keys = [row.site_key for row in rows]

    assert keys.count("vk") == 2
    assert keys.count("instagram") == 2
    assert keys.index("vk") < keys.index("instagram") < keys.index("telegram")
    assert keys.index("youtube") < keys.index("github") < keys.index("gitlab")
    assert any(row.display_url == "https://github.com/ivan-ivanov" for row in rows)
    assert all(row.site_key != "fosstodon" for row in rows[:12])


def test_username_candidates_expand_sherlock_placeholder_and_use_rank(monkeypatch):
    def fake_load_sites():
        return {
            "SlowForum": {
                "url": "https://slow.example/u/{}",
                "urlMain": "https://slow.example/",
                "cat": "misc",
                "rank": 9000,
                "regexCheck": r"^[a-z0-9_.-]+$",
            },
            "FastForum": {
                "url": "https://fast.example/u/{}",
                "urlMain": "https://fast.example/",
                "cat": "misc",
                "rank": 10,
                "regexCheck": r"^[a-z0-9_.-]+$",
            },
            "DisabledForum": {
                "url": "https://disabled.example/u/{}",
                "urlMain": "https://disabled.example/",
                "cat": "misc",
                "rank": 1,
                "regexCheck": r"^[a-z0-9_.-]+$",
                "disabled": True,
            },
            "HyphenOnly": {
                "url": "https://hyphen.example/u/{}",
                "urlMain": "https://hyphen.example/",
                "cat": "misc",
                "rank": 20,
                "regexCheck": r"^[a-z0-9-]+$",
            },
        }

    monkeypatch.setattr("bedniiosint.search.username_candidates.load_sites", fake_load_sites)
    rows = build_username_site_candidates(["john{?}doe"], limit=5)

    assert [row.site_name for row in rows[:3]] == ["FastForum", "FastForum", "FastForum"]
    assert rows[0].display_url == "https://fast.example/u/john_doe"
    assert any(row.site_name == "HyphenOnly" and row.username == "john-doe" for row in rows)
    assert all(row.site_name != "DisabledForum" for row in rows)
    assert all(row.username != "john{?}doe" for row in rows)


def test_search_only_catalog_parses_markdown_and_skips_username_overlap():
    text = """
    - [Example Forum](https://forum.example/users)
    - [GitHub](https://github.com)
    - https://archive.example/path
    - [Duplicate](https://forum.example/other)
    """
    rows = parse_markdown_sites(
        text,
        source="fixture",
        existing_hosts={"github.com"},
        skip_existing=True,
    )

    assert [row.host for row in rows] == ["forum.example", "archive.example"]
    assert rows[0].name == "Example Forum"
    assert rows[0].source == "fixture"


def test_dorking_auto_includes_search_only_domain_dorks(monkeypatch):
    from bedniiosint.search.search_only_catalog import SearchOnlySite

    monkeypatch.setattr(
        "bedniiosint.search.dorking.load_search_only_sites",
        lambda: [
            SearchOnlySite(
                name="Forum Example",
                host="forum.example",
                url="https://forum.example/",
                source="fixture",
                category="forum",
                license_note="public fixture",
            ),
            SearchOnlySite(
                name="Covered",
                host="github.com",
                url="https://github.com/",
                source="fixture",
                overlap_username_catalog=True,
            ),
        ],
    )
    plan = plan_search("alice /identity/username mode:fast limit:80", include_auth_required=True)
    rows = [row.as_dict() for row in build_dorking_results(plan)]
    search_only = [row for row in rows if row["source_id"].startswith("dorking:search_only:")]
    profile_index = next(i for i, row in enumerate(rows) if row["source_id"] == "dorking:profile:github")

    assert search_only
    assert search_only[0]["normalized_data"]["lead_kind"] == "search_only_domain_dork"
    assert search_only[0]["normalized_data"]["search_only_domain"] == "forum.example"
    assert 'site:forum.example "alice"' in search_only[0]["matched_variant"]
    assert rows.index(search_only[0]) > profile_index
    assert all(row["normalized_data"].get("search_only_domain") != "github.com" for row in search_only)


def test_dorking_platform_filter_disables_general_search_only_catalog(monkeypatch):
    from bedniiosint.search.search_only_catalog import SearchOnlySite

    monkeypatch.setattr(
        "bedniiosint.search.dorking.load_search_only_sites",
        lambda: [
            SearchOnlySite(
                name="Forum Example",
                host="forum.example",
                url="https://forum.example/",
                source="fixture",
            )
        ],
    )
    plan = plan_search("alice /identity/username platform:github mode:deep", include_auth_required=True)
    rows = [row.as_dict() for row in build_dorking_results(plan)]

    assert "dorking:profile:github" in {row["source_id"] for row in rows}
    assert not any(row["source_id"].startswith("dorking:search_only:") for row in rows)


def test_search_pipeline_strict_profile_results_drop_unverified_dorking(monkeypatch):
    def fake_run_source_pipeline(target: str, **kwargs):
        return FakePipelineResult(
            target=target,
            input_type=kwargs["input_type"],
            sources=kwargs["source_ids"],
            results=[],
            normalized=[],
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    monkeypatch.setattr("bedniiosint.search.pipeline.verify_candidate_results", lambda rows: rows)
    result = run_planned_search_pipeline(
        "alice",
        entity_type="username",
        source_ids=["web_search", "social_profiles"],
        include_auth_required=True,
        available_only=True,
        include_dorking=True,
    )

    assert result["counts"]["search_results"] == 0
    assert result["counts"]["dorking_results"] == 0
    assert result["result_group_counts"]["profiles"] == 0
    assert result["result_group_counts"]["review_search"] == 0


def test_search_pipeline_strict_profile_results_keep_reachable_candidate(monkeypatch):
    def fake_run_source_pipeline(target: str, **kwargs):
        return FakePipelineResult(
            target=target,
            input_type=kwargs["input_type"],
            sources=kwargs["source_ids"],
            results=[],
            normalized=[],
        )

    def fake_verify(rows):
        for row in rows:
            if row.source_id == "dorking:profile:github":
                row.tags.append("reachable")
                row.normalized_data["verification_status"] = "reachable_unconfirmed"
                row.normalized_data["candidate_verification"] = {
                    "state": "present",
                    "reason": "reachable (status 200)",
                    "status_code": 200,
                }
        return rows

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    monkeypatch.setattr("bedniiosint.search.pipeline.verify_candidate_results", fake_verify)
    result = run_planned_search_pipeline(
        "alice",
        entity_type="username",
        source_ids=["web_search", "social_profiles"],
        include_auth_required=True,
        available_only=True,
        include_dorking=True,
    )

    dorking_rows = [
        row for row in result["search_results"] if str(row["source_id"]).startswith("dorking:")
    ]
    assert [row["source_id"] for row in dorking_rows] == ["dorking:profile:github"]
    assert dorking_rows[0]["normalized_data"]["candidate_verification"]["state"] == "present"
    assert result["result_group_counts"]["profiles"] == 1
    assert result["result_group_counts"]["review_search"] == 0


def test_search_only_importer_can_build_from_local_disabled_sites(tmp_path, monkeypatch):
    from scripts import import_search_only_sources
    from bedniiosint.search.search_only_catalog import SearchOnlySite

    out = tmp_path / "search_only_sites.json"
    monkeypatch.setattr(import_search_only_sources, "fetch_text", lambda name: (_ for _ in ()).throw(RuntimeError("no net")))
    monkeypatch.setattr(
        import_search_only_sources,
        "username_catalog_disabled_search_sites",
        lambda: [
            SearchOnlySite(
                name="Disabled Forum",
                host="disabled.example",
                url="https://disabled.example/",
                source="fixture_local",
            )
        ],
    )
    monkeypatch.setattr(
        import_search_only_sources,
        "username_catalog_hosts",
        lambda: {"github.com", "disabled.example"},
    )

    assert import_search_only_sources.main(["--out", str(out)]) == 0
    payload = json.loads(out.read_text(encoding="utf-8"))
    assert payload["count"] == 1
    assert payload["sites"][0]["host"] == "disabled.example"


def test_dorking_uses_packaged_sherlock_style_catalog_for_profiles():
    plan = plan_search("alice /identity/username platform:github", include_auth_required=True)
    dorking_rows = [row.as_dict() for row in build_dorking_results(plan)]
    github = next(row for row in dorking_rows if row["source_id"] == "dorking:profile:github")

    assert github["url"] == "https://github.com/alice"
    assert github["normalized_data"]["lead_kind"] == "direct_profile_candidate"
    assert "sherlock_style" in github["tags"]
    assert github["normalized_data"]["verification_method"] == "sherlock_catalog_regex"
    assert github["normalized_data"]["status_model"] == "candidate_url_not_probed"
    assert github["normalized_data"]["produced_event_type"] == "PROFILE_CANDIDATE_URL"
    assert all("google.com/search" not in row["url"] for row in dorking_rows[:1])


def test_spiderfoot_style_event_plan_routes_music_username_sources():
    plan = plan_search("scally milano /music", include_auth_required=True)
    event_plan = build_search_event_plan(plan)
    route_ids = {row["source_id"] for row in event_plan["routes"]}
    hints = {row["id"] for row in event_plan["correlation_hints"]}
    produced = {row["event_type"] for row in event_plan["event_frontier"]}

    assert event_plan["style"] == "spiderfoot_event_fanout"
    assert "USERNAME" in {row["event_type"] for row in event_plan["target_events"]}
    assert "social_profiles" in route_ids
    assert "creator_video_search" in route_ids
    assert "dorking:sherlock_username_candidates" in route_ids
    assert "dorking:music_platform_candidates" in route_ids
    assert "PROFILE_CANDIDATE_URL" in produced
    assert "MUSIC_PROFILE_CANDIDATE" in produced
    assert "artist_to_music_platforms" in hints
    assert "music_platforms" in event_plan["result_groups_targeted"]


def test_result_pivots_extract_next_actions_from_profiles_email_and_domains():
    plan = plan_search("alice /identity/username", include_auth_required=True)
    results = [
        SearchResult(
            id="profile-one",
            source_id="dorking:profile:github",
            source_name="GitHub candidate",
            entity_input="alice",
            entity_type="username",
            matched_entity="alice",
            url="https://github.com/alice",
            normalized_data={
                "direct_candidate": True,
                "lead_kind": "direct_profile_candidate",
                "verification_status": "unverified_candidate",
                "result_group": "profiles",
            },
        ),
        SearchResult(
            id="email-one",
            source_id="api:hunter",
            source_name="Hunter",
            entity_input="example.com",
            entity_type="domain",
            matched_entity="example.com",
            normalized_data={
                "entities": [{"type": "email", "value": "artist@example.com"}],
                "result_group": "emails",
            },
            confidence_score=0.66,
        ),
    ]
    pivots = build_result_pivots(
        plan,
        results,
        {
            "profiles": {"result_ids": ["profile-one"]},
            "emails": {"result_ids": ["email-one"]},
        },
    )
    rows = pivots["items"]

    assert pivots["style"] == "spiderfoot_result_pivots"
    assert pivots["counts"]["by_type"]["profile"] == 1
    assert any(row["pivot_type"] == "username" and row["value"] == "alice" for row in rows)
    assert any(row["pivot_type"] == "email" and row["value"] == "artist@example.com" for row in rows)
    assert any(row["pivot_type"] == "domain" and row["value"] == "example.com" for row in rows)
    assert pivots["next_actions"][0]["command"].startswith("bedniiosint search-run")


def test_username_scan_results_wrap_parallel_scanner_status(monkeypatch):
    async def fake_scan_username(username, sites, **kwargs):
        assert username == "alice"
        assert kwargs["limit"] == 25
        return [
            SiteResult(
                site_name="GitHub",
                url_main="https://github.com/",
                category="coding",
                probe_url="https://github.com/alice",
                display_url="https://github.com/alice",
                status="exists",
                status_code=200,
                final_url="https://github.com/alice",
                redirected=False,
                page_title="alice",
                matched_markers=["e_code:200", "score:username:url"],
                confidence=0.88,
                source_reliability=1.0,
                reliability_note="control usernames did not match",
                control_passed=True,
                body_sha256="a" * 64,
                body_len=1200,
            )
        ]

    monkeypatch.setattr(
        "bedniiosint.search.username_scan.load_sites",
        lambda: {"GitHub": {"url": "https://github.com/{}"}},
    )
    monkeypatch.setattr("bedniiosint.search.username_scan.scan_username", fake_scan_username)
    plan = plan_search("alice /identity/username verify_limit:25", include_auth_required=True)
    rows = [row.as_dict() for row in build_username_scan_results(plan)]

    assert rows[0]["source_id"] == "username_scan:github"
    assert rows[0]["url"] == "https://github.com/alice"
    assert rows[0]["confidence_score"] == 0.88
    assert rows[0]["normalized_data"]["lead_kind"] == "verified_profile"
    assert rows[0]["raw_data"]["status"] == "exists"


def test_search_planner_expands_cyrillic_names_for_social_lookup():
    variants = build_entity_variant_details("Иван Иванов", "username")
    values = {row.value for row in variants}

    assert {"ivan_ivanov", "ivan-ivanov", "ivan.ivanov", "ivanivanov"} <= values
    assert {"ivanov_ivan", "ivanov-ivan"} <= values
    assert {"иван_иванов", "иван-иванов"} <= values

    plan = plan_search("Иван Иванов /identity/username", include_auth_required=True)
    source_ids = {source["id"] for source in plan.sources}
    queries = " ".join(query for row in plan.queries for query in row.queries)
    dorking_rows = [row.as_dict() for row in build_dorking_results(plan)]
    urls = " ".join(row["url"] for row in dorking_rows)
    top_source_ids = [row["source_id"] for row in dorking_rows[:18]]

    assert plan.entity_input == "Иван Иванов"
    assert plan.entity_type == "username"
    assert plan.scope == "social_profiles"
    assert {"social_profiles", "creator_video_search", "public_social_intel"} <= source_ids
    assert "Иван Иванов" in queries
    assert "ivan_ivanov" in queries
    assert "https://vk.com/ivan_ivanov" in urls
    assert "https://www.instagram.com/ivan_ivanov/" in urls
    assert "https://www.youtube.com/@ivan_ivanov" in urls
    assert "https://github.com/ivan-ivanov" in urls
    assert top_source_ids.index("dorking:profile:vk") < top_source_ids.index("dorking:profile:instagram")
    assert "dorking:profile:youtube" in top_source_ids
    assert "dorking:profile:github" in top_source_ids


def test_search_planner_routes_cyrillic_music_names_to_music_platforms():
    plan = plan_search("скалли милано /music", include_auth_required=True)
    queries = " ".join(query for row in plan.queries for query in row.queries)
    dorking_rows = [row.as_dict() for row in build_dorking_results(plan)]
    urls = " ".join(row["url"] for row in dorking_rows)

    assert plan.entity_input == "скалли милано"
    assert plan.entity_type == "username"
    assert plan.scope == "media"
    assert plan.resolved_scope["path"] == "/creator/music/beatmaking"
    assert "site:vk.com" in queries
    assert "skalli-milano" in queries
    assert "https://vk.com/skalli-milano" in urls
    assert "https://www.instagram.com/skalli-milano/" in urls
    assert "https://genius.com/artists/skalli-milano" in urls
    assert "https://www.youtube.com/@skalli-milano" in urls


def test_search_planner_uses_expanded_public_sources_and_keeps_keyed_sources_opt_in():
    public_plan = plan_search("Example Inc", entity_type="company")
    public_source_ids = {source["id"] for source in public_plan.sources}

    assert "news_mentions" in public_source_ids
    assert "archive_discovery" in public_source_ids
    assert "creator_video_search" not in public_source_ids
    assert "public_social_intel" not in public_source_ids
    assert "public_code_search" not in public_source_ids
    assert "contact_discovery" not in public_source_ids

    keyed_plan = plan_search(
        "Example Inc",
        entity_type="company",
        include_auth_required=True,
    )
    keyed_source_ids = {source["id"] for source in keyed_plan.sources}

    assert "creator_video_search" in keyed_source_ids
    assert "public_social_intel" in keyed_source_ids
    assert "public_code_search" in keyed_source_ids
    assert "contact_discovery" in keyed_source_ids


def test_fediverse_and_reverse_image_sources_are_explicit_entity_types():
    fediverse = plan_search(
        "alice@mastodon.social",
        entity_type="fediverse_account",
    )
    assert [source["id"] for source in fediverse.sources] == ["fediverse_profiles"]

    image = plan_search(
        "https://example.com/image.jpg",
        entity_type="image_url",
        include_auth_required=True,
    )
    assert [source["id"] for source in image.sources] == ["media_reverse_search"]


def test_search_planner_can_include_auth_sources_explicitly():
    plan = plan_search(
        "8.8.8.8",
        entity_type="ip",
        source_ids=["abuseipdb"],
        include_auth_required=True,
    )
    assert [source["id"] for source in plan.sources] == ["abuseipdb"]
    assert plan.queries[0].source_id == "abuseipdb"


def test_catalog_connector_runs_mapped_catalog_adapter_without_network(monkeypatch):
    calls = []

    def fake_run_source(source_id: str, target: str, **kwargs):
        calls.append((source_id, target, kwargs))
        return AdapterResult(
            source_id=source_id,
            target=target,
            status="ok",
            input_type="domain",
            url=f"https://example.test/{source_id}",
            data={"domain": target},
            normalized={
                "entities": [{"type": "domain", "value": target}],
                "findings": [
                    {
                        "finding_type": "registry_record",
                        "status": "exists",
                        "confidence": 0.82,
                    }
                ],
                "timeline": [],
            },
        )

    monkeypatch.setattr("bedniiosint.search.connectors.catalog.run_source", fake_run_source)
    connector = CatalogConnector(get_source("rdap"))
    query_plan = connector.build_queries({"type": "domain", "value": "example.com"})
    results = connector.explain(connector.score(connector.normalize(connector.parse(connector.run(query_plan)))))

    assert calls == [("api:rdap", "example.com", calls[0][2])]
    result = results[0]
    assert result.source_id == "api:rdap"
    assert result.entity_type == "domain"
    assert result.confidence_score == 0.82
    assert "single_source" in result.risk_flags
    assert "catalog_connector" in result.tags
    assert "public_registry" in result.legal_notes
    assert "rdap -> api:rdap" in result.explanation


def test_catalog_connector_scores_multi_adapter_mapping(monkeypatch):
    def fake_run_source(source_id: str, target: str, **kwargs):
        return AdapterResult(
            source_id=source_id,
            target=target,
            status="ok",
            input_type="domain",
            url=f"https://example.test/{source_id}",
            data={"domain": target, "source": source_id},
            normalized={
                "entities": [{"type": "domain", "value": target}],
                "findings": [
                    {
                        "finding_type": "dns_record",
                        "status": "exists",
                        "confidence": 0.75,
                    }
                ],
                "timeline": [],
            },
        )

    monkeypatch.setattr("bedniiosint.search.connectors.catalog.run_source", fake_run_source)
    connector = CatalogConnector(get_source("dns"))
    query_plan = connector.build_queries({"type": "domain", "value": "example.com"})
    results = connector.explain(
        connector.score(connector.normalize(connector.parse(connector.run(query_plan))))
    )

    assert [result.source_id for result in results] == ["api:google_dns", "api:cloudflare_dns"]
    assert [result.confidence_score for result in results] == [0.8, 0.8]
    assert all("corroborated" in result.tags for result in results)


def test_catalog_adapter_can_prepare_image_url_queries():
    adapter = adapter_for("api:tineye")
    method, url, selected = adapter.prepare(
        "https://example.com/image.jpg",
        input_type="image_url",
    )

    assert method == "GET"
    assert selected == "image_url"
    assert "image_url=https://example.com/image.jpg" in url


@dataclass
class FakePipelineResult:
    target: str
    input_type: str
    sources: list[str]
    results: list[dict[str, Any]]
    normalized: list[dict[str, Any]]

    def as_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "input_type": self.input_type,
            "sources": self.sources,
            "results": self.results,
            "normalized": self.normalized,
            "persisted": [],
            "persisted_case": {},
            "counts": {"sources": len(self.sources), "results": len(self.results)},
        }


def test_search_pipeline_maps_search_sources_to_catalog_and_scores(monkeypatch):
    calls = []

    def fake_run_source_pipeline(target: str, **kwargs):
        calls.append((target, kwargs))
        sources = kwargs["source_ids"]
        normalized = [
            {
                "source_id": source_id,
                "target": target,
                "status": "exists",
                "confidence": 0.8,
                "input_type": "domain",
                "url": f"https://example.test/{source_id}",
                "title": source_id,
                "entities": [{"type": "domain", "value": target}],
                "relations": [],
                "timeline": [],
                "raw": {"source": source_id},
                "reject_reason": "",
            }
            for source_id in sources
        ]
        return FakePipelineResult(
            target=target,
            input_type="domain",
            sources=sources,
            results=[{"source_id": source_id, "status": "ok"} for source_id in sources],
            normalized=normalized,
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    result = run_planned_search_pipeline("example.com", entity_type="domain", source_ids=["dns"])

    assert calls[0][1]["source_ids"] == SEARCH_TO_CATALOG_SOURCE_IDS["dns"]
    assert result["catalog_source_ids"] == ["api:google_dns", "api:cloudflare_dns"]
    assert result["search_results"][0]["confidence_score"] == 0.85
    assert result["search_results"][0]["context_match_score"] == 1.0
    assert result["search_results"][0]["legal_notes"]
    assert "corroborated" in result["search_results"][0]["tags"]
    assert result["search_results"][0]["normalized_data"]["search_scoring"] == {
        "base_confidence": 0.8,
        "final_confidence": 0.85,
        "independent_sources": 2,
        "context_match_score": 1.0,
    }
    assert result["evidence_summary"]["source_count"] == 2
    assert result["evidence_summary"]["corroborated_entities"] >= 1
    assert result["evidence_summary"]["evidence_kinds"]["raw_hash"] == 2
    assert any(
        row["entity_type"] == "domain" and row["entity_value"] == "example.com"
        for row in result["evidence_summary"]["entities"]
    )
    assert result["run_evidence"]["schema_version"] == "1.0"
    assert result["run_evidence"]["query"]["entity_input"] == "example.com"
    assert result["run_evidence"]["planned_sources"][0]["source_id"] == "dns"
    assert result["run_evidence"]["executed_sources"][0]["raw_hash"]
    assert result["run_evidence"]["evidence_hash"] == result["run_summary"]["evidence_hash"]
    assert result["run_summary"]["confidence_bands"]["high"] == 2
    assert result["run_summary"]["counts"]["raw_hashes"] >= 2
    assert result["dedup_summary"]["clusters"] == 1
    assert result["result_clusters"][0]["status"] == "confirmed"
    assert result["report_summary"]["cluster_status_counts"]["confirmed"] == 1
    assert result["identities"]
    assert result["identities"][0]["band"] == "confirmed"
    assert result["identities"][0]["member_count"] == 2
    assert result["identities"][0]["linked_by"] == ["shared_external_link"]
    assert all("identity" in row["normalized_data"] for row in result["search_results"])
    assert "# Search Report: example.com" in result["report_markdown"]


def test_search_pipeline_runs_cleaned_entity_from_query_language(monkeypatch):
    calls = []

    def fake_run_source_pipeline(target: str, **kwargs):
        calls.append((target, kwargs))
        return FakePipelineResult(
            target=target,
            input_type=kwargs["input_type"],
            sources=kwargs["source_ids"],
            results=[],
            normalized=[],
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    result = run_planned_search_pipeline(
        "example.com /infra/domain",
        include_auth_required=True,
        source_ids=["rdap"],
    )

    assert calls[0][0] == "example.com"
    assert calls[0][1]["input_type"] == "domain"
    assert result["target"] == "example.com /infra/domain"
    assert result["entity_input"] == "example.com"
    assert result["resolved_target"] == "example.com"
    assert result["run_evidence"]["query"]["entity_input"] == "example.com"


def test_search_run_explain_dry_run_reports_selected_and_skipped_adapters():
    result = explain_search_run(
        "example.com",
        entity_type="domain",
        source_ids=["web_search", "rdap"],
        include_auth_required=True,
        configured_only=True,
    )

    assert result["dry_run"] is True
    assert result["planned_catalog_source_ids"] == ["api:rdap", "api:google_cse"]
    assert result["catalog_source_ids"] == ["api:rdap"]
    assert result["skipped_catalog_sources"] == [
        {
            "source_id": "api:google_cse",
            "reason": "not_configured",
            "missing_env_vars": ["GOOGLE_CSE_API_KEY", "GOOGLE_CSE_CX"],
        }
    ]
    web_search = next(row for row in result["sources"] if row["source_id"] == "web_search")
    assert web_search["run_status"] == "all_catalog_adapters_skipped"
    assert web_search["catalog_adapters"][0]["missing_env_vars"] == [
        "GOOGLE_CSE_API_KEY",
        "GOOGLE_CSE_CX",
    ]
    rdap = next(row for row in result["sources"] if row["source_id"] == "rdap")
    assert rdap["run_status"] == "will_run"
    assert result["search_results"] == []
    assert result["pipeline"] == {}
    assert result["run_evidence"]["query"]["entity_input"] == "example.com"
    assert result["run_evidence"]["skipped_sources"][0]["source_id"] == "api:google_cse"
    assert result["run_summary"]["counts"]["skipped_sources"] == 1
    assert result["run_summary"]["missing_key_sources"] == ["api:google_cse"]


def test_search_run_explain_compact_omits_nested_registry_and_adapter_payloads():
    result = explain_search_run(
        "example.com",
        entity_type="domain",
        source_ids=["web_search", "rdap"],
        include_auth_required=True,
        configured_only=True,
        compact=True,
    )

    assert result["compact"] is True
    assert result["plan"]["source_ids"] == ["rdap", "web_search"]
    assert "sources" not in result["plan"]
    web_search = next(row for row in result["sources"] if row["source_id"] == "web_search")
    assert "catalog_adapters" not in web_search
    assert web_search["skipped_catalog_sources"][0]["source_id"] == "api:google_cse"


def test_search_run_explain_reports_auth_excluded_sources():
    result = explain_search_run("example.com", entity_type="domain")
    skipped = {row["source_id"]: row for row in result["skipped_search_sources"]}

    assert "web_search" in skipped
    assert "auth_required_excluded" in skipped["web_search"]["reasons"]


def test_search_pipeline_configured_only_filters_unconfigured_catalog_adapters(monkeypatch):
    calls = []

    def fake_run_source_pipeline(target: str, **kwargs):
        calls.append((target, kwargs))
        sources = kwargs["source_ids"]
        normalized = [
            {
                "source_id": source_id,
                "target": target,
                "status": "exists",
                "confidence": 0.8,
                "input_type": "domain",
                "url": f"https://example.test/{source_id}",
                "title": source_id,
                "entities": [{"type": "domain", "value": target}],
                "relations": [],
                "timeline": [],
                "raw": {"source": source_id},
                "reject_reason": "",
            }
            for source_id in sources
        ]
        return FakePipelineResult(
            target=target,
            input_type="domain",
            sources=sources,
            results=[{"source_id": source_id, "status": "ok"} for source_id in sources],
            normalized=normalized,
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    result = run_planned_search_pipeline(
        "example.com",
        entity_type="domain",
        source_ids=["web_search", "rdap"],
        include_auth_required=True,
        available_only=True,
    )

    assert calls[0][1]["source_ids"] == ["api:rdap"]
    assert result["planned_catalog_source_ids"] == ["api:rdap", "api:google_cse"]
    assert result["catalog_source_ids"] == ["api:rdap"]
    assert result["skipped_catalog_sources"][0]["source_id"] == "api:google_cse"
    assert result["counts"]["skipped_catalog_sources"] == 1


def test_search_pipeline_fans_out_query_oriented_catalog_adapters(monkeypatch):
    calls = []

    def fake_run_source_pipeline(target: str, **kwargs):
        calls.append((target, kwargs))
        source_id = kwargs["source_ids"][0]
        normalized = [
            {
                "source_id": source_id,
                "target": target,
                "status": "exists",
                "confidence": 0.55,
                "input_type": kwargs["input_type"],
                "url": f"https://example.test/search?q={target}",
                "title": target,
                "entities": [{"type": "query", "value": target}],
                "relations": [],
                "timeline": [],
                "raw": {"query": target},
                "reject_reason": "",
            }
        ]
        return FakePipelineResult(
            target=target,
            input_type=kwargs["input_type"],
            sources=kwargs["source_ids"],
            results=[{"source_id": source_id, "status": "ok"}],
            normalized=normalized,
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    result = run_planned_search_pipeline(
        "Example Inc",
        entity_type="company",
        source_ids=["web_search"],
        include_auth_required=True,
    )

    targets = [target for target, _ in calls]
    assert len(calls) > 1
    assert all(call[1]["source_ids"] == ["api:google_cse"] for call in calls)
    assert all(call[1]["input_type"] == "query" for call in calls)
    assert "Example Inc" in targets
    assert any("site:" in target for target in targets)
    assert result["counts"]["search_results"] == len(calls)
    assert result["pipeline"]["results"][0]["search_fanout"]["original_target"] == "Example Inc"


def test_search_pipeline_fans_out_variant_sources_with_company_domain_guess(monkeypatch):
    calls = []

    def fake_run_source_pipeline(target: str, **kwargs):
        calls.append((target, kwargs))
        return FakePipelineResult(
            target=target,
            input_type=kwargs["input_type"],
            sources=kwargs["source_ids"],
            results=[],
            normalized=[],
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    run_planned_search_pipeline(
        "Example Inc",
        entity_type="company",
        source_ids=["contact_discovery"],
        include_auth_required=True,
    )

    assert calls
    assert ("example.com", {
        "input_type": "domain",
        "source_ids": ["api:hunter"],
        "available_only": False,
        "save": False,
        "case_name": None,
        "plugin_dir": None,
        "context": None,
    }) in calls


def test_search_pipeline_does_not_fall_back_to_default_sources_after_filtering(monkeypatch):
    def fake_run_source_pipeline(*args, **kwargs):
        raise AssertionError("filtered empty catalog source list must not run default pipeline sources")

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    monkeypatch.setattr("bedniiosint.search.pipeline.verify_candidate_results", lambda rows: rows)
    result = run_planned_search_pipeline(
        "alice",
        entity_type="username",
        source_ids=["web_search"],
        include_auth_required=True,
        available_only=True,
    )

    assert result["catalog_source_ids"] == []
    assert result["planned_catalog_source_ids"] == ["api:google_cse"]
    assert result["counts"]["catalog_sources"] == 0
    assert result["counts"]["search_results"] == 0
    assert result["counts"]["skipped_catalog_sources"] == 1


def test_search_pipeline_adds_review_only_dorking_and_social_leads(monkeypatch):
    from bedniiosint.config import settings

    calls = []
    original_strict = settings.strict_profile_results
    object.__setattr__(settings, "strict_profile_results", False)

    def fake_run_source_pipeline(target: str, **kwargs):
        calls.append((target, kwargs))
        return FakePipelineResult(
            target=target,
            input_type=kwargs["input_type"],
            sources=kwargs["source_ids"],
            results=[],
            normalized=[],
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    try:
        result = run_planned_search_pipeline(
            "alice",
            entity_type="username",
            source_ids=["web_search", "social_profiles"],
            include_auth_required=True,
            available_only=True,
            include_dorking=True,
        )
    finally:
        object.__setattr__(settings, "strict_profile_results", original_strict)

    dorking_rows = [
        row for row in result["search_results"] if str(row["source_id"]).startswith("dorking:")
    ]
    queries = " ".join(str(row.get("raw_data", {}).get("query") or "") for row in dorking_rows)
    urls = " ".join(str(row.get("url") or "") for row in dorking_rows)

    assert calls
    assert result["counts"]["dorking_results"] == len(dorking_rows)
    assert result["counts"]["dorking_results"] >= 20
    assert "site:x.com" in queries
    assert "site:instagram.com" in queries
    assert "site:linkedin.com/in" in queries
    assert "site:github.com" in queries
    assert "https://github.com/alice" in urls
    assert result["result_group_counts"]["profiles"] >= 1
    assert result["result_group_counts"]["review_search"] >= 1
    assert any(
        item["url"] == "https://github.com/alice"
        for item in result["result_groups"]["profiles"]["items"]
    )
    assert all(
        "google.com/search" not in item["url"]
        for item in result["result_groups"]["profiles"]["items"]
    )
    assert any(
        "google.com/search" in item["url"]
        for item in result["result_groups"]["review_search"]["items"]
    )
    assert all(row["confidence_score"] == 0.0 for row in dorking_rows)
    assert all("review_only" in row["tags"] for row in dorking_rows)
    assert all("manual_verification_required" in row["risk_flags"] for row in dorking_rows)
    assert result["source_event_plan"]["style"] == "spiderfoot_event_fanout"
    assert "dorking:sherlock_username_candidates" in {
        row["source_id"] for row in result["source_event_plan"]["routes"]
    }
    assert any(
        row["event_type"] == "PROFILE_CANDIDATE_URL"
        for row in result["source_event_plan"]["event_frontier"]
    )
    assert result["result_pivots"]["style"] == "spiderfoot_result_pivots"
    assert result["result_pivots"]["counts"]["by_type"]["profile"] >= 1
    assert any(
        row["pivot_type"] == "username" and row["value"] == "alice"
        for row in result["result_pivots"]["items"]
    )
    assert result["report_summary"]["coverage"]["dorking_results"] == len(dorking_rows)
    assert any("dorking and social leads" in item for item in result["report_summary"]["next_steps"])


def test_search_pipeline_persists_review_only_dorking_leads(tmp_path: Path, monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.storage.models import Evidence, Finding
    from bedniiosint.storage.sqlite import Storage

    original_db_dir = settings.db_dir
    original_strict = settings.strict_profile_results
    object.__setattr__(settings, "db_dir", tmp_path)
    object.__setattr__(settings, "strict_profile_results", False)

    def fake_run_source_pipeline(target: str, **kwargs):
        return FakePipelineResult(
            target=target,
            input_type=kwargs["input_type"],
            sources=kwargs["source_ids"],
            results=[],
            normalized=[],
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    monkeypatch.setattr("bedniiosint.search.pipeline.verify_candidate_results", lambda rows: rows)
    try:
        result = run_planned_search_pipeline(
            "alice",
            entity_type="username",
            source_ids=["web_search"],
            include_auth_required=True,
            available_only=True,
            include_dorking=True,
            save=True,
            case_name="dork-save",
        )

        storage = Storage(settings.db_path("dork-save"))
        with storage.session() as session:
            findings = session.query(Finding).all()
            evidence = session.query(Evidence).all()

        assert result["persisted_review_only"]["counts"]["findings"] == result["counts"]["dorking_results"]
        assert findings
        assert evidence
        assert all(row.finding_type == "dorking_lead" for row in findings)
        assert all(row.status in {"candidate", "unknown"} for row in findings)
        assert any(row.status == "candidate" and "candidate_url" in row.matched_markers for row in findings)
        assert all(
            row.status == "candidate" if "candidate_url" in row.matched_markers else row.status == "unknown"
            for row in findings
        )
        assert all(float(row.confidence or 0.0) == 0.0 for row in findings)
        assert all("review_only" in row.matched_markers for row in findings)
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)
        object.__setattr__(settings, "strict_profile_results", original_strict)


def test_search_pipeline_adds_domain_dorks_for_infrastructure_pivots(monkeypatch):
    def fake_run_source_pipeline(target: str, **kwargs):
        return FakePipelineResult(
            target=target,
            input_type=kwargs["input_type"],
            sources=kwargs["source_ids"],
            results=[],
            normalized=[],
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_source_pipeline", fake_run_source_pipeline)
    monkeypatch.setattr("bedniiosint.search.pipeline.verify_candidate_results", lambda rows: rows)
    result = run_planned_search_pipeline(
        "example.com",
        entity_type="domain",
        source_ids=["web_search"],
        include_auth_required=True,
        available_only=True,
        include_dorking=True,
    )

    queries = [
        str(row.get("raw_data", {}).get("query") or "")
        for row in result["search_results"]
        if str(row["source_id"]).startswith("dorking:")
    ]
    joined = " ".join(queries)

    assert result["counts"]["search_results"] == result["counts"]["dorking_results"]
    assert "filetype:pdf" in joined
    assert "inurl:admin" in joined
    assert "security.txt" in joined
    assert "site:crt.sh" in joined
    assert "site:urlscan.io" in joined
    assert "site:web.archive.org" in joined


def test_search_pipeline_can_use_concurrent_runner(monkeypatch):
    calls = []

    def fake_concurrent_runner(target: str, **kwargs):
        calls.append((target, kwargs))
        sources = kwargs["source_ids"]
        normalized = [
            {
                "source_id": source_id,
                "target": target,
                "status": "exists",
                "confidence": 0.7,
                "input_type": "domain",
                "url": f"https://example.test/{source_id}",
                "title": source_id,
                "entities": [{"type": "domain", "value": target}],
                "relations": [],
                "timeline": [],
                "raw": {"source": source_id},
                "reject_reason": "",
            }
            for source_id in sources
        ]
        return FakePipelineResult(
            target=target,
            input_type="domain",
            sources=sources,
            results=[{"source_id": source_id, "status": "ok"} for source_id in sources],
            normalized=normalized,
        )

    monkeypatch.setattr("bedniiosint.search.pipeline.run_catalog_sources_concurrently", fake_concurrent_runner)
    result = run_planned_search_pipeline(
        "example.com",
        entity_type="domain",
        source_ids=["dns"],
        concurrent=True,
        max_workers=3,
    )

    assert calls[0][1]["max_workers"] == 3
    assert result["execution"] == {"mode": "concurrent", "max_workers": 3}
    assert result["counts"]["search_results"] == 2


def test_search_evidence_summary_counts_sources_and_risks():
    results = [
        SearchResult(
            id="one",
            source_id="api:one",
            source_name="One",
            entity_input="example.com",
            entity_type="domain",
            matched_entity="example.com",
            evidence=[
                {"kind": "normalized_entity", "entity_type": "domain", "entity_value": "example.com"}
            ],
            confidence_score=0.7,
            risk_flags=["single_source"],
            legal_notes="public registry",
        ),
        SearchResult(
            id="two",
            source_id="api:two",
            source_name="Two",
            entity_input="example.com",
            entity_type="domain",
            matched_entity="example.com",
            evidence=[
                {"kind": "normalized_entity", "entity_type": "domain", "entity_value": "example.com"}
            ],
            confidence_score=0.8,
            legal_notes="public dns",
        ),
    ]
    summary = summarize_search_results(results)

    assert summary["source_count"] == 2
    assert summary["evidence_items"] == 2
    assert summary["evidence_kinds"] == {"normalized_entity": 2}
    assert summary["entities"][0]["corroborated"] is True
    assert summary["risk_flags"] == {"single_source": 1}


def test_search_result_clustering_deduplicates_entities_and_marks_results():
    results = [
        SearchResult(
            id="one",
            source_id="api:one",
            source_name="One",
            entity_input="Example.COM",
            entity_type="domain",
            matched_entity="Example.COM",
            evidence=[{"id": "ev1", "kind": "normalized_entity"}],
            confidence_score=0.72,
        ),
        SearchResult(
            id="two",
            source_id="api:two",
            source_name="Two",
            entity_input="example.com",
            entity_type="domain",
            matched_entity="example.com",
            evidence=[{"id": "ev2", "kind": "normalized_entity"}],
            confidence_score=0.8,
        ),
    ]
    annotate_result_clusters(results)
    clusters = cluster_search_results(results)

    assert len(clusters) == 1
    assert clusters[0]["status"] == "confirmed"
    assert clusters[0]["source_count"] == 2
    assert entity_resolution_key(results[0]) == "domain|example.com"
    assert result_dedup_key(results[0]).startswith("domain|example.com|api:one")
    assert results[0].normalized_data["search_dedup"]["cluster_id"] == clusters[0]["cluster_id"]


def test_search_report_summary_and_markdown_are_human_readable():
    payload = {
        "target": "example.com",
        "entity_input": "example.com",
        "entity_type": "domain",
        "scope": "public_osint",
        "counts": {"search_results": 1},
        "search_source_ids": ["dns"],
        "catalog_source_ids": ["api:google_dns"],
        "skipped_catalog_sources": [],
        "run_summary": {
            "counts": {"planned_sources": 1, "executed_sources": 1},
            "missing_key_sources": [],
            "evidence_hash": "abc",
        },
        "run_evidence": {"repro_command": "bedniiosint search-run example.com"},
        "result_clusters": [
            {
                "status": "confirmed",
                "entity_type": "domain",
                "entity_value": "example.com",
                "max_confidence": 0.86,
                "source_count": 2,
                "evidence_count": 4,
            }
        ],
    }
    summary = build_search_report_summary(payload)
    markdown = render_search_markdown({**payload, "report_summary": summary})

    assert summary["headline"] == "1 confirmed cluster(s) found."
    assert summary["next_steps"]
    assert "## Coverage" in markdown
    assert "domain=example.com" in markdown


def test_concurrent_runner_returns_pipeline_result_in_source_order(monkeypatch):
    calls = []

    def fake_run_source(source_id: str, target: str, **kwargs):
        calls.append(source_id)
        return AdapterResult(
            source_id=source_id,
            target=target,
            status="ok",
            input_type=kwargs["input_type"],
            data={"source": source_id},
            normalized={
                "entities": [{"type": kwargs["input_type"], "value": target}],
                "relations": [],
                "findings": [{"status": "exists", "confidence": 0.6}],
                "timeline": [],
                "raw": {"source": source_id},
            },
        )

    monkeypatch.setattr("bedniiosint.search.concurrent.run_source", fake_run_source)
    result = run_catalog_sources_concurrently(
        "example.com",
        input_type="domain",
        source_ids=["api:one", "api:two"],
        max_workers=2,
    )

    assert set(calls) == {"api:one", "api:two"}
    assert result.sources == ["api:one", "api:two"]
    assert [row["source_id"] for row in result.results] == ["api:one", "api:two"]


def test_concurrent_runner_skips_source_after_hard_timeout(monkeypatch):
    from bedniiosint.config import settings

    original_timeout = settings.search_source_timeout

    def adapter_result(source_id: str) -> AdapterResult:
        return AdapterResult(
            source_id=source_id,
            target="example.com",
            status="ok",
            input_type="domain",
            data={"source": source_id},
            normalized={
                "entities": [{"type": "domain", "value": "example.com"}],
                "relations": [],
                "findings": [{"status": "exists", "confidence": 0.6}],
                "timeline": [],
                "raw": {"source": source_id},
            },
        )

    def fake_run_source(source_id: str, target: str, **kwargs):
        if source_id == "api:slow":
            time.sleep(2.0)
        return adapter_result(source_id)

    object.__setattr__(settings, "search_source_timeout", 0.01)
    monkeypatch.setattr("bedniiosint.search.concurrent.run_source", fake_run_source)
    started = time.monotonic()
    try:
        result = run_catalog_sources_concurrently(
            "example.com",
            input_type="domain",
            source_ids=["api:fast", "api:slow"],
            max_workers=2,
        )
    finally:
        object.__setattr__(settings, "search_source_timeout", original_timeout)

    assert time.monotonic() - started < 1.7
    assert [row["source_id"] for row in result.results] == ["api:fast"]


def test_search_run_evidence_envelope_serializes_and_hashes_deterministically():
    result = SearchResult(
        id="result-one",
        source_id="api:rdap",
        source_name="RDAP",
        entity_input="example.com",
        entity_type="domain",
        matched_entity="example.com",
        raw_data={"handle": "EXAMPLE"},
        evidence=[{"id": "ev-one", "kind": "raw_hash", "hash": "abc"}],
        confidence_score=0.82,
        legal_notes="public_registry",
    )
    plan = plan_search("example.com", entity_type="domain", source_ids=["rdap"])
    pipeline = {
        "results": [
            {
                "source_id": "api:rdap",
                "status": "ok",
                "input_type": "domain",
                "method": "GET",
                "url": "https://rdap.org/domain/example.com",
                "status_code": 200,
                "data": {"handle": "EXAMPLE"},
                "text": "",
                "normalized": {"entities": [{"type": "domain", "value": "example.com"}]},
            }
        ]
    }

    first = build_search_run_evidence(
        entity_input="example.com",
        entity_type="domain",
        scope="public_osint",
        plan=plan.as_dict(),
        pipeline=pipeline,
        results=[result],
        started_at="2026-06-07T00:00:00+00:00",
        finished_at="2026-06-07T00:00:01+00:00",
    )
    second = build_search_run_evidence(
        entity_input="example.com",
        entity_type="domain",
        scope="public_osint",
        plan=plan.as_dict(),
        pipeline=pipeline,
        results=[result],
        started_at="2026-06-07T00:00:00+00:00",
        finished_at="2026-06-07T00:00:01+00:00",
    )

    payload = first.as_dict()
    assert payload["run_id"] == second.run_id
    assert payload["evidence_hash"] == second.evidence_hash
    assert payload["raw_hashes"]
    assert payload["summary"]["confidence_bands"]["high"] == 1
    assert payload["summary"]["evidence_ids"] == ["ev-one"]
    assert "bedniiosint search-run example.com" in payload["repro_command"]


def test_search_run_evidence_handles_empty_results_and_skipped_sources():
    plan = plan_search(
        "example.com",
        entity_type="domain",
        source_ids=["web_search"],
        include_auth_required=True,
    )
    envelope = build_search_run_evidence(
        entity_input="example.com",
        entity_type="domain",
        scope="public_osint",
        plan=plan.as_dict(),
        pipeline={},
        results=[],
        skipped_catalog_sources=[
            {
                "source_id": "api:google_cse",
                "reason": "not_configured",
                "missing_env_vars": ["GOOGLE_CSE_API_KEY", "GOOGLE_CSE_CX"],
            }
        ],
        started_at="2026-06-07T00:00:00+00:00",
        finished_at="2026-06-07T00:00:01+00:00",
        include_auth_required=True,
        configured_only=True,
    )

    assert envelope.result_count == 0
    assert envelope.skipped_sources[0]["reason"] == "not_configured"
    assert envelope.summary["counts"]["results"] == 0
    assert envelope.summary["missing_key_sources"] == ["api:google_cse"]
    assert "--configured-only" in envelope.repro_command


def test_old_cli_commands_are_not_broken():
    runner = CliRunner()
    result = runner.invoke(app, ["pipeline-run", "--help"])
    assert result.exit_code == 0
    assert "Run the catalog source pipeline" in result.output


def test_new_search_cli_commands_are_available():
    runner = CliRunner()
    result = runner.invoke(app, ["search-plan", "example.com", "--entity-type", "domain", "--max-sources", "1"])
    assert result.exit_code == 0
    assert '"entity_type": "domain"' in result.output


def test_search_plan_cli_accepts_embedded_scope_language():
    runner = CliRunner()
    result = runner.invoke(app, ["search-plan", "example.com /infra/domain +github", "--max-sources", "2"])

    assert result.exit_code == 0
    assert '"entity_input": "example.com"' in result.output
    assert '"scope_path": "/infra/domain"' in result.output
    assert '"registry_scope": "infrastructure"' in result.output


def test_investigation_plan_cli_is_available():
    runner = CliRunner()
    result = runner.invoke(app, ["investigation-plan", "example.com"])

    assert result.exit_code == 0
    assert '"entity_type": "domain"' in result.output
    assert '"/infra/domain"' in result.output


def test_search_sources_cli_defaults_to_compact_and_full_is_available():
    runner = CliRunner()
    compact = runner.invoke(app, ["search-sources", "--entity-type", "domain"])
    full = runner.invoke(app, ["search-sources", "--entity-type", "domain", "--full"])

    assert compact.exit_code == 0
    assert full.exit_code == 0
    assert '"compact": true' in compact.output
    assert '"missing_env_vars"' in compact.output
    assert '"mapped_catalog_sources"' not in compact.output
    assert '"readiness"' in full.output
    assert '"mapped_catalog_sources"' in full.output


def test_search_run_cli_dry_run_explains_without_running_adapters():
    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "search-run",
            "example.com",
            "--entity-type",
            "domain",
            "--source",
            "web_search",
            "--source",
            "rdap",
            "--include-auth-required",
            "--configured-only",
            "--dry-run",
        ],
    )

    assert result.exit_code == 0
    assert '"dry_run": true' in result.output
    assert '"compact": true' in result.output
    assert '"planned_catalog_source_ids"' in result.output
    assert '"api:google_cse"' in result.output
    assert '"reason": "not_configured"' in result.output
    assert '"api:rdap"' in result.output
    assert '"catalog_adapters"' not in result.output
    assert '"run_summary"' in result.output
    assert '"missing_key_sources"' in result.output
    assert '"run_evidence"' in result.output


def test_search_run_api_dry_run_includes_run_summary():
    import bedniiosint.web.app as web_app

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Using `httpx` with `starlette.testclient` is deprecated.*",
        )
        from fastapi.testclient import TestClient

        client = TestClient(web_app.app)

    response = client.get(
        "/search/run",
        params={
            "target": "example.com",
            "entity_type": "domain",
            "source": "web_search,rdap",
            "include_auth_required": "true",
            "configured_only": "true",
            "dry_run": "true",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["run_summary"]["missing_key_sources"] == ["api:google_cse"]
    assert payload["run_evidence"]["skipped_sources"][0]["source_id"] == "api:google_cse"
    assert payload["run_evidence"]["repro_command"]


def test_search_plan_and_investigation_plan_api_accept_query_language():
    import bedniiosint.web.app as web_app

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Using `httpx` with `starlette.testclient` is deprecated.*",
        )
        from fastapi.testclient import TestClient

        client = TestClient(web_app.app)

    plan_response = client.get(
        "/search/plan",
        params={"target": "example.com /infra/domain +github", "max_sources": "2"},
    )
    investigation_response = client.get(
        "/investigation/plan",
        params={"target": "example.com"},
    )

    assert plan_response.status_code == 200
    plan_payload = plan_response.json()
    assert plan_payload["entity_input"] == "example.com"
    assert plan_payload["resolved_scope"]["path"] == "/infra/domain"
    assert plan_payload["source_routing"]["boost_terms"] == ["github"]

    assert investigation_response.status_code == 200
    investigation_payload = investigation_response.json()
    assert investigation_payload["entity_type"] == "domain"
    assert investigation_payload["routes"][0]["scope_path"] == "/infra/domain"


def test_search_run_cli_summary_and_markdown_outputs_are_available():
    runner = CliRunner()
    summary = runner.invoke(
        app,
        [
            "search-run",
            "example.com",
            "--entity-type",
            "domain",
            "--source",
            "rdap",
            "--dry-run",
            "--summary",
        ],
    )
    markdown = runner.invoke(
        app,
        [
            "search-run",
            "example.com",
            "--entity-type",
            "domain",
            "--source",
            "rdap",
            "--dry-run",
            "--markdown",
        ],
    )

    assert summary.exit_code == 0
    assert '"headline"' in summary.output
    assert markdown.exit_code == 0
    assert "# Search Report: example.com" in markdown.output


def test_search_run_cli_dry_run_full_keeps_adapter_details():
    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "search-run",
            "example.com",
            "--entity-type",
            "domain",
            "--source",
            "web_search",
            "--include-auth-required",
            "--dry-run",
            "--full",
        ],
    )

    assert result.exit_code == 0
    assert '"compact": false' in result.output
    assert '"catalog_adapters"' in result.output
    assert '"setup_hint"' in result.output


def test_old_search_pipeline_without_scope_still_works():
    assert "api:rdap" in pipeline_sources("domain")
    assert "api:gdelt" in pipeline_sources("query")
    assert pipeline_sources("image_url") == ["api:tineye"]
    assert pipeline_sources("fediverse_account") == ["api:mastodon_lookup"]
    plan = plan_search("example.com", entity_type="domain", max_sources=2)
    assert plan.scope == "infrastructure"
    assert plan.resolved_scope["path"] == "/infra/domain"
    assert plan.sources
    public_plan = plan_search("example.com", entity_type="domain", scope="public_osint", max_sources=2)
    assert public_plan.scope == "public_osint"
    assert public_plan.sources
