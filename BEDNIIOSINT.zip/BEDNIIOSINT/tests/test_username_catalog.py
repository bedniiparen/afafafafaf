from __future__ import annotations

import json
from pathlib import Path

from bedniiosint.modules.username.catalog import (
    import_site_catalog,
    merge_site_catalogs,
    username_catalog_coverage,
)
from bedniiosint.modules.username.scanner import load_sites, select_sites, site_catalog_stats
from bedniiosint.config import DEFAULT_SITES_FILE


def test_username_catalog_import_normalizes_list_format(tmp_path: Path):
    catalog = tmp_path / "external.json"
    catalog.write_text(
        json.dumps(
            {
                "sites": [
                    {
                        "name": "ExampleSocial",
                        "uri": "https://social.example/{}",
                        "main_url": "https://social.example/",
                        "category": "social",
                        "error_type": "message",
                        "m_string": "not found",
                    },
                    {"name": "Broken", "category": "misc"},
                ]
            }
        ),
        encoding="utf-8",
    )

    result = import_site_catalog(catalog)

    assert result.total == 2
    assert result.valid == 1
    assert result.invalid == 1
    assert result.sites["ExampleSocial"]["url"] == "https://social.example/{}"
    assert result.sites["ExampleSocial"]["cat"] == "social"
    assert result.sites["ExampleSocial"]["provenance"]["source"] == "external"
    assert any(issue.site == "Broken" and issue.severity == "error" for issue in result.issues)


def test_username_catalog_import_normalizes_sherlock_format(tmp_path: Path):
    catalog = tmp_path / "sherlock.json"
    catalog.write_text(
        json.dumps(
            {
                "$schema": "data.schema.json",
                "ExampleSherlock": {
                    "url": "https://example.test/u/{}",
                    "urlMain": "https://example.test/",
                    "urlProbe": "https://example.test/api/users/{}",
                    "errorType": "status_code",
                    "errorCode": 404,
                    "request_method": "POST",
                    "request_payload": {"username": "{}"},
                    "headers": {"Content-Type": "application/json"},
                    "regexCheck": "^[A-Za-z0-9_]+$",
                    "username_claimed": "alice",
                },
            }
        ),
        encoding="utf-8",
    )

    result = import_site_catalog(catalog, source_label="Sherlock")
    site = result.sites["ExampleSherlock"]

    assert result.total == 1
    assert result.valid == 1
    assert site["uri_check"] == "https://example.test/api/users/{}"
    assert site["m_code"] == 404
    assert site["request_payload"] == {"username": "{}"}
    assert site["provenance"] == {
        "source": "Sherlock",
        "original_name": "ExampleSherlock",
    }


def test_username_catalog_import_preserves_sherlock_error_type_lists(tmp_path: Path):
    catalog = tmp_path / "sherlock-list.json"
    catalog.write_text(
        json.dumps(
            {
                "ExampleMultiMethod": {
                    "url": "https://example.test/u/{}",
                    "urlMain": "https://example.test/",
                    "errorType": ["message", "status_code"],
                    "errorMsg": ["not found", "missing user"],
                    "errorCode": [404, 410],
                    "username_claimed": "alice",
                    "tags": ["gaming"],
                    "isNSFW": False,
                },
            }
        ),
        encoding="utf-8",
    )

    result = import_site_catalog(catalog, source_label="Sherlock")
    site = result.sites["ExampleMultiMethod"]

    assert site["errorType"] == ["message", "status_code"]
    assert site["m_code"] == [404, 410]
    assert site["errorMsg"] == ["not found", "missing user"]
    assert site["tags"] == ["gaming"]
    assert site["isNSFW"] is False


def test_username_catalog_import_normalizes_nested_maigret_format(tmp_path: Path):
    catalog = tmp_path / "maigret.json"
    catalog.write_text(
        json.dumps(
            {
                "sites": {
                    "sites": {
                        "ExampleMaigret": {
                            "url": "https://social.example/{username}",
                            "checkType": "message",
                            "presenseStrs": ["profile-header"],
                            "absenceStrs": ["missing user"],
                            "tags": ["ru", "social"],
                            "alexaRank": 10,
                        }
                    },
                    "engines": {},
                }
            }
        ),
        encoding="utf-8",
    )

    result = import_site_catalog(catalog, source_label="maigret")
    site = result.sites["ExampleMaigret"]

    assert result.total == 1
    assert result.valid == 1
    assert site["url"] == "https://social.example/{username}"
    assert site["errorType"] == "message"
    assert site["e_string"] == ["profile-header"]
    assert site["m_string"] == ["missing user"]
    assert site["cat"] == "social"
    assert site["rank"] == 10


def test_username_catalog_import_expands_maigret_engine_templates(tmp_path: Path):
    catalog = tmp_path / "maigret-engines.json"
    catalog.write_text(
        json.dumps(
            {
                "sites": {
                    "sites": {
                        "ForumExample": {
                            "urlMain": "https://forum.example",
                            "urlSubpath": "/community",
                            "engine": "phpBB",
                            "tags": ["forum"],
                        }
                    },
                    "engines": {
                        "phpBB": {
                            "site": {
                                "checkType": "message",
                                "absenceStrs": ["No members found"],
                                "presenseStrs": ["memberlist.php?mode=viewprofile"],
                                "url": "{urlMain}{urlSubpath}/memberlist.php?username={username}",
                            }
                        }
                    },
                }
            }
        ),
        encoding="utf-8",
    )

    result = import_site_catalog(catalog, source_label="maigret")
    site = result.sites["ForumExample"]

    assert result.valid == 1
    assert site["url"] == "https://forum.example/community/memberlist.php?username={username}"
    assert site["errorType"] == "message"
    assert site["m_string"] == ["No members found"]
    assert site["e_string"] == ["memberlist.php?mode=viewprofile"]
    assert site["cat"] == "forum"
    assert site["engine"] == "phpBB"


def test_username_catalog_import_normalizes_nexfil_list_format(tmp_path: Path):
    catalog = tmp_path / "nexfil.json"
    catalog.write_text(
        json.dumps(
            [
                {
                    "url": "https://archive.example/@{}",
                    "test": "string",
                    "data": "cannot find account",
                }
            ]
        ),
        encoding="utf-8",
    )

    result = import_site_catalog(catalog, source_label="nexfil")
    site = next(iter(result.sites.values()))

    assert result.total == 1
    assert result.valid == 1
    assert site["url"] == "https://archive.example/@{}"
    assert site["errorType"] == "message"
    assert site["m_string"] == "cannot find account"
    assert site["provenance"]["source"] == "nexfil"


def test_username_catalog_category_uses_mapped_tags(tmp_path: Path):
    catalog = tmp_path / "maigret-tags.json"
    catalog.write_text(
        json.dumps(
            {
                "sites": {
                    "ExamplePhoto": {
                        "url": "https://photo.example/{username}",
                        "tags": ["us", "photo"],
                    },
                    "ExampleForum": {
                        "url": "https://forum.example/{username}",
                        "tags": ["forum"],
                    },
                }
            }
        ),
        encoding="utf-8",
    )

    result = import_site_catalog(catalog)

    assert result.sites["ExamplePhoto"]["cat"] == "images"
    assert result.sites["ExampleForum"]["cat"] == "forum"


def test_username_catalog_merge_dedupes_and_writes_scanner_format(tmp_path: Path):
    base = tmp_path / "base.json"
    incoming = tmp_path / "incoming.json"
    out = tmp_path / "merged.json"
    base.write_text(
        json.dumps(
            {
                "sites": {
                    "GitHub": {
                        "url": "https://github.com/{}",
                        "urlMain": "https://github.com/",
                        "cat": "coding",
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    incoming.write_text(
        json.dumps(
            {
                "GitHub": {"url": "https://github.com/{}", "cat": "coding"},
                "NewForum": {"url": "https://forum.example/u/{}", "cat": "social"},
            }
        ),
        encoding="utf-8",
    )

    result = merge_site_catalogs(base, [incoming], out)
    merged = json.loads(out.read_text(encoding="utf-8"))

    assert result["added"] == 1
    assert result["skipped"] == 1
    assert result["stats"]["sites"] == 2
    assert "NewForum" in merged["sites"]
    assert merged["sites"]["NewForum"]["provenance"]["source"] == "incoming"


def test_username_catalog_merge_overwrite_keeps_local_base_rows(tmp_path: Path):
    base = tmp_path / "base.json"
    incoming = tmp_path / "incoming.json"
    out = tmp_path / "merged.json"
    base.write_text(
        json.dumps(
            {
                "sites": {
                    "GitHub": {
                        "url": "https://github.com/{}",
                        "cat": "coding",
                        "regexCheck": r"^[A-Za-z0-9-]+$",
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    incoming.write_text(
        json.dumps(
            {
                "GitHub": {
                    "url": "https://github.com/{}",
                    "cat": "misc",
                    "provenance": {"source": "nexfil"},
                }
            }
        ),
        encoding="utf-8",
    )

    result = merge_site_catalogs(base, [incoming], out, overwrite=True)
    merged = json.loads(out.read_text(encoding="utf-8"))

    assert result["replaced"] == 0
    assert result["skipped"] == 1
    assert merged["sites"]["GitHub"]["cat"] == "coding"
    assert "regexCheck" in merged["sites"]["GitHub"]


def test_username_catalog_coverage_benchmarks_external_catalogs(tmp_path: Path):
    base = tmp_path / "base.json"
    incoming = tmp_path / "incoming.json"
    base.write_text(
        json.dumps(
            {
                "sites": {
                    "GitHub": {
                        "url": "https://github.com/{}",
                        "urlMain": "https://github.com/",
                        "cat": "coding",
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    incoming.write_text(
        json.dumps(
            {
                "GitHub": {"url": "https://github.com/{}", "cat": "coding"},
                "NewForum": {"url": "https://forum.example/u/{}", "cat": "social"},
                "VideoSite": {"url": "https://video.example/{}", "cat": "video"},
            }
        ),
        encoding="utf-8",
    )

    result = username_catalog_coverage(base, [incoming], sample_limit=1)
    row = result["imports"][0]

    assert result["summary"]["base_sites"] == 1
    assert result["summary"]["external_valid"] == 3
    assert result["summary"]["overlap"] == 1
    assert result["summary"]["unique_missing"] == 2
    assert result["summary"]["potential_total_after_merge"] == 3
    assert row["coverage"] == 0.333
    assert row["missing_by_category"] == {"social": 1, "video": 1}
    assert len(row["missing_sample"]) == 1
    assert "license" in result["license_note"].lower()


def test_username_catalog_coverage_cli_outputs_json(tmp_path: Path):
    from typer.testing import CliRunner

    from bedniiosint.cli import app

    base = tmp_path / "base.json"
    incoming = tmp_path / "incoming.json"
    base.write_text(
        json.dumps({"sites": {"GitHub": {"url": "https://github.com/{}"}}}),
        encoding="utf-8",
    )
    incoming.write_text(
        json.dumps({"GitHub": {"url": "https://github.com/{}"}, "New": {"url": "https://n.example/{}"}}),
        encoding="utf-8",
    )

    result = CliRunner().invoke(
        app,
        [
            "username-catalog-coverage",
            str(incoming),
            "--base",
            str(base),
            "--sample-limit",
            "5",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["summary"]["overlap"] == 1
    assert payload["summary"]["unique_missing"] == 1


def test_packaged_username_catalog_scales_to_500_plus_sources():
    sites = load_sites(DEFAULT_SITES_FILE)
    stats = site_catalog_stats(sites)
    selected = select_sites(sites, offset=495, limit=10)

    assert stats["sites"] >= 500
    assert stats["supports_external_catalog"]
    assert len(selected) >= 5
    assert any(site.get("provenance", {}).get("source") for site in sites.values())
