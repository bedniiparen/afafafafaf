import asyncio

from bedniiosint.search.async_pipeline import run_connectors
from bedniiosint.search.connectors.base import BaseConnector, QueryPlan
from bedniiosint.search.models import SearchResult


class _FakeConnector(BaseConnector):
    source_id = "fake"
    source_name = "Fake"
    supports_async = False

    def run(self, query_plan: QueryPlan):
        return {"status": "ok", "value": query_plan.entity_input}

    def parse(self, raw):
        return [raw]

    def normalize(self, parsed):
        value = parsed[0]["value"]
        return [
            SearchResult(
                id=f"{self.source_id}:1",
                source_id=self.source_id,
                source_name=self.source_name,
                entity_input=value,
                entity_type="username",
                matched_entity=value,
                confidence_score=0.5,
            )
        ]


class _AsyncConnector(_FakeConnector):
    source_id = "fake_async"
    source_name = "Fake Async"
    supports_async = True

    async def arun(self, query_plan: QueryPlan):
        await asyncio.sleep(0)
        return {"status": "ok", "value": query_plan.entity_input.upper()}


def test_sync_connector_runs_through_async_pipeline():
    out = run_connectors([_FakeConnector()], {"type": "username", "value": "alice"})
    assert any(r.matched_entity == "alice" for r in out)


def test_async_connector_arun_is_used():
    out = run_connectors([_AsyncConnector()], {"type": "username", "value": "alice"})
    assert any(r.matched_entity == "ALICE" for r in out)
