import asyncio

from bedniiosint.core.confidence import (
    ConfidenceInput,
    ScoreSignal,
    UniversalConfidenceContext,
    compute_confidence,
    score_signals,
    score_universal,
)
from bedniiosint.core.http import HttpPolicy, _async_wait_rate_limit, request
from bedniiosint.core.source_reliability import (
    reliability_from_calibration,
    reliability_from_history,
)
from bedniiosint.core.target import auto_case_name, detect_module, safe_case_name
from bedniiosint.modules.username import validators
from bedniiosint.modules.username.false_positive import evaluate
from bedniiosint.modules.username.scanner import (
    _Probe,
    build_url,
    classify,
    select_sites,
    site_catalog_stats,
)


def test_url_generation():
    assert build_url("https://x.com/{}", "bob") == "https://x.com/bob"
    assert build_url("https://x.com/{account}", "bob") == "https://x.com/bob"
    assert build_url("https://x.com/{username}", "bob") == "https://x.com/bob"


def test_target_detection_and_case_names():
    assert detect_module("user@example.com") == "email"
    assert detect_module("8.8.8.8") == "ip"
    assert detect_module("+15551234567") == "phone"
    assert detect_module("https://example.com/p") == "url"
    assert detect_module("0x" + "a" * 40) == "wallet"
    assert detect_module("Example Inc") == "company"
    assert detect_module("Иван Иванов") == "username"
    assert detect_module("ООО Ромашка") == "company"
    assert detect_module("example.com") == "domain"
    assert detect_module("bedniiparen") == "username"
    assert safe_case_name("bad case!*") == "badcase"
    assert auto_case_name("email", "USER@Example.COM") == "email-user_at_example-com"


def test_regex_filter():
    assert validators.passes_regex("good_name", "^[a-z_]+$")
    assert not validators.passes_regex("BAD!!", "^[a-z_]+$")
    assert validators.passes_regex("anything", None)


def test_control_username_is_long_and_unique():
    a = validators.random_control_username(20)
    b = validators.random_control_username(20)
    assert a != b and len(a) > 20 and a.startswith("zz")


def test_username_site_catalog_stats_and_chunk_selection():
    sites = {
        "GitHub": {"cat": "coding", "url": "https://github.com/{}"},
        "Instagram": {
            "cat": "social",
            "url": "https://instagram.com/{}",
            "protection": ["captcha"],
        },
        "Reddit": {"cat": "social", "url": "https://reddit.com/user/{}"},
        "OldForum": {
            "cat": "social",
            "url": "https://old.example/u/{}",
            "disabled": True,
        },
    }
    stats = site_catalog_stats(sites)
    selected = select_sites(
        sites,
        categories=["social"],
        include_protected=False,
        offset=0,
        limit=10,
    )
    chunk = select_sites(sites, offset=1, limit=1)

    assert stats["sites"] == 4
    assert stats["categories"] == {"coding": 1, "social": 3}
    assert stats["protected"] == 1
    assert list(selected) == ["Reddit"]
    assert list(chunk) == ["Instagram"]
    assert "OldForum" not in select_sites(sites)
    assert "OldForum" in select_sites(sites, include_disabled=True)


def test_confidence_scaled_by_reliability():
    base = ConfidenceInput(True, True, True, True, True, source_reliability=1.0)
    full = compute_confidence(base)
    half = compute_confidence(ConfidenceInput(True, True, True, True, True, 0.5))
    assert full == 1.0
    assert half == round(full * 0.5, 3)


def test_scoring_result_records_markers_and_reject_reason():
    scoring = score_signals(
        [
            ScoreSignal("valid_format", 0.3, True),
            ScoreSignal("mx_records", 0.3, False, "no MX records"),
        ],
        reject_reason="invalid selector",
    )
    assert scoring.confidence == 0.3
    assert scoring.matched_markers == [
        "score:valid_format:0.30",
        "score:mx_records:miss:no MX records",
    ]
    assert scoring.reject_reason == "invalid selector"


def test_universal_confidence_boosts_penalizes_and_records_history():
    strong = score_universal(
        [ScoreSignal("direct_match", 0.6, True)],
        context=UniversalConfidenceContext(
            target_type="email",
            independent_sources=3,
            source_reliability=1.0,
        ),
    )
    weaker = score_universal(
        [ScoreSignal("direct_match", 0.6, True)],
        context=UniversalConfidenceContext(
            target_type="email",
            independent_sources=1,
            source_reliability=1.0,
            source_success_count=1,
            source_error_count=1,
            weak_data=True,
        ),
    )
    reliability, note = reliability_from_history(0.8, success_count=3, error_count=1)

    assert strong.confidence == 0.7
    assert weaker.confidence < strong.confidence
    assert any("universal:independent_sources" in marker for marker in strong.matched_markers)
    assert any("universal:source_history" in marker for marker in weaker.matched_markers)
    assert any("universal:weak_data" in marker for marker in weaker.matched_markers)
    assert reliability < 0.8
    assert "error_rate" in note


def test_classify_status_code():
    site = {
        "errorType": "status_code",
        "e_code": 200,
        "m_code": 404,
        "url": "https://x/{}",
    }
    assert classify(site, _Probe(200, "u", False, "ok", "", True), "u")[0] == "exists"
    assert (
        classify(site, _Probe(404, "u", False, "no", "", True), "u")[0]
        == "not_exists"
    )
    assert classify(site, _Probe(None, "u", False, "", "", False), "u")[0] == "unknown"


def test_classify_message():
    site = {"errorType": "message", "m_string": "not found", "url": "https://x/{}"}
    probe = _Probe(200, "u", False, "user not found here", "", True)
    assert classify(site, probe, "u")[0] == "not_exists"


def test_classify_sherlock_error_type_list_and_waf():
    site = {
        "errorType": ["message", "status_code"],
        "errorMsg": ["not found"],
        "m_code": [404, 410],
        "url": "https://x/{}",
    }

    assert classify(site, _Probe(200, "u", False, "profile page", "", True), "u")[0] == "exists"
    assert classify(site, _Probe(404, "u", False, "not found", "", True), "u")[0] == "not_exists"

    waf_html = '<span id="challenge-error-text">blocked</span>'
    status, markers = classify(site, _Probe(403, "u", False, waf_html, "", True), "u")
    assert status == "waf"
    assert markers == ["waf:cloudflare_error"]


def test_classify_global_missing_page():
    site = {"errorType": "status_code", "e_code": 200, "url": "https://x/{}"}
    html = "<h1>Page not found</h1><p>This page no longer exists.</p>"
    status, markers = classify(site, _Probe(200, "u", False, html, "", True), "u")
    assert status == "not_exists"
    assert markers == ["global_missing:page_not_found"]


def test_false_positive_rejects_low_reliability():
    v = evaluate(
        status="exists",
        source_reliability=0.2,
        min_reliability=0.35,
        control_passed=True,
    )
    assert v.rejected

    v2 = evaluate(
        status="exists",
        source_reliability=0.9,
        min_reliability=0.35,
        control_passed=False,
    )
    assert v2.rejected

    v3 = evaluate(
        status="exists",
        source_reliability=0.9,
        min_reliability=0.35,
        control_passed=True,
    )
    assert not v3.rejected


def test_reliability_penalises_false_controls():
    rel, _ = reliability_from_calibration(
        controls_claimed_exist=2,
        controls_total=2,
        avg_similarity_real_vs_control=0.5,
    )
    assert rel < 0.5
    good, _ = reliability_from_calibration(
        controls_claimed_exist=0,
        controls_total=2,
        avg_similarity_real_vs_control=0.3,
    )
    assert good == 1.0


def test_http_request_retries_transient_status():
    class FakeClient:
        def __init__(self):
            self.calls = 0

        def request(self, method: str, url: str, **kwargs):
            import httpx

            self.calls += 1
            status = 503 if self.calls == 1 else 200
            return httpx.Response(
                status,
                request=httpx.Request(method, url),
                headers={"content-type": "text/plain"},
                text="ok",
            )

    client = FakeClient()
    response = request(
        "GET",
        "https://example.test",
        client=client,
        policy=HttpPolicy(max_retries=1, backoff=0, rate_limit_delay=0),
    )

    assert response.status_code == 200
    assert client.calls == 2


def test_async_rate_limiter_can_run_on_multiple_event_loops():
    policy = HttpPolicy(rate_limit_delay=0.001)

    async def wait_once():
        await _async_wait_rate_limit("https://loop-switch.example.test/path", policy)

    asyncio.run(wait_once())
    asyncio.run(wait_once())
