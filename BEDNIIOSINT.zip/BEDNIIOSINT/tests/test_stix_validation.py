from bedniiosint.reports.stix import case_summary_to_stix, validate_stix_bundle


def _summary() -> dict:
    return {
        "meta": {"case": "demo"},
        "entities": [
            {"type": "email", "value": "a@example.com"},
            {"type": "domain", "value": "example.com"},
        ],
        "findings": [
            {
                "id": "f1",
                "entity_type": "email",
                "entity_value": "a@example.com",
                "status": "exists",
                "confidence": 0.9,
                "source_name": "api:hibp",
            }
        ],
        "relations": [
            {
                "src_type": "email",
                "src_value": "a@example.com",
                "rel": "linked-to",
                "dst_type": "domain",
                "dst_value": "example.com",
            }
        ],
        "evidence": [{"finding_id": "f1", "sha256": "abc123", "url": "https://example.com/x"}],
    }


def test_generated_bundle_is_valid():
    bundle = case_summary_to_stix(_summary())
    assert validate_stix_bundle(bundle) == []


def test_validator_flags_dangling_relationship():
    bundle = {
        "type": "bundle",
        "id": "bundle--x",
        "spec_version": "2.1",
        "objects": [
            {
                "type": "relationship",
                "id": "relationship--1",
                "spec_version": "2.1",
                "created": "2026-01-01T00:00:00+00:00",
                "modified": "2026-01-01T00:00:00+00:00",
                "relationship_type": "related-to",
                "source_ref": "url--missing",
                "target_ref": "url--missing2",
            }
        ],
    }
    errors = validate_stix_bundle(bundle)
    assert any("dangling" in e for e in errors)
