﻿from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import warnings

import pytest

from bedniiosint.catalog.adapters import AdapterResult
from bedniiosint.config import settings
from bedniiosint.core import jobs
from bedniiosint.core.case_workspace import get_workspace
from bedniiosint.modules.username.scanner import SiteResult
from bedniiosint.storage.models import Case
from bedniiosint.storage.sqlite import Storage


def _site_result(source: str) -> SiteResult:
    return SiteResult(
        site_name=source,
        url_main=f"https://{source.lower()}.example",
        category="social",
        probe_url=f"https://{source.lower()}.example/bob",
        display_url=f"https://{source.lower()}.example/bob",
        status="exists",
        status_code=200,
        final_url=f"https://{source.lower()}.example/bob",
        redirected=False,
        page_title="Bob",
        matched_markers=["e_code:200"],
        confidence=0.9,
        source_reliability=0.9,
        reliability_note="test",
        control_passed=True,
        body_sha256="abc",
        body_len=3,
    )


def test_job_worker_retries_and_records_source_events(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    calls = {"count": 0}

    def fake_run_module(module: str, case_name: str, target: str):
        calls["count"] += 1
        if calls["count"] == 1:
            raise RuntimeError("flaky source")
        return {"module": module, "case": case_name, "target": target}

    monkeypatch.setattr(jobs, "_run_module", fake_run_module)
    try:
        job = jobs.create_job("bob@example.com", module="email", max_retries=1)

        result = jobs.run_worker_once()
        saved = jobs.get_job(job.id)
        events = [jobs.job_event_as_dict(event) for event in jobs.list_job_events(job.id)]

        assert result["status"] == "finished"
        assert saved.status == "finished"
        assert saved.completed_sources == 1
        assert saved.progress == 1.0
        assert calls["count"] == 2
        assert [event["attempt"] for event in events if event["kind"] == "source_started"] == [1, 2]
        assert any(event["kind"] == "retry" and event["message"] == "flaky source" for event in events)
        assert events[-1]["kind"] == "finished"
        assert jobs.worker_status()["jobs_run"] >= 1
    finally:
        jobs.stop_worker()
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_job_queue_claim_removes_job_from_queued_selection(tmp_path: Path):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        job = jobs.create_job("bob@example.com", module="email")

        claimed = jobs._claim_next_queued_job(worker_id="unit-worker")
        next_job = jobs._next_queued_job()
        saved = jobs.get_job(job.id)

        assert claimed.id == job.id
        assert saved.status == "claimed"
        assert saved.current_source == "worker"
        assert saved.claimed_by == "unit-worker"
        assert saved.claimed_at is not None
        assert saved.heartbeat_at is not None
        assert next_job is None
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_auto_job_case_names_do_not_reuse_existing_case_without_resume(tmp_path: Path):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("company_search-scally-milano"))
        with storage.session() as session:
            session.add(
                Case(
                    name="company_search-scally-milano",
                    target="scally milano",
                    module="company_search",
                )
            )
            session.commit()

        fresh = jobs.create_job("scally milano", module="company_search")
        explicit = jobs.create_job(
            "scally milano",
            module="company_search",
            case_name="company_search-scally-milano",
        )
        resumed = jobs.create_job("scally milano", module="company_search", resume=True)

        assert fresh.case_name == "company_search-scally-milano-2"
        assert explicit.case_name == "company_search-scally-milano"
        assert resumed.case_name == "company_search-scally-milano"
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_worker_exception_marks_claimed_job_failed(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        job = jobs.create_job("bob@example.com", module="email")

        def explode(job_id: int, **kwargs):
            raise RuntimeError("worker crash")

        monkeypatch.setattr(jobs, "run_job", explode)

        result = jobs.run_worker_once()
        saved = jobs.get_job(job.id)
        events = jobs.list_job_events(job.id)
        status = jobs.worker_status()

        assert result == {"job": job.id, "status": "failed", "error": "worker crash"}
        assert saved.status == "failed"
        assert saved.current_source == ""
        assert saved.error == "worker crash"
        assert saved.finished_at is not None
        assert events[-1].kind == "failed"
        assert events[-1].message == "worker crash"
        assert status["last_error"] == "worker crash"
        assert status["status_counts"]["failed"] == 1
        assert status["active"] == 0
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_worker_status_counts_active_claimed_and_running_jobs(tmp_path: Path):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        queued = jobs.create_job("queued@example.com", module="email")
        claimed = jobs.create_job("claimed@example.com", module="email")
        running = jobs.create_job("running@example.com", module="email")
        finished = jobs.create_job("finished@example.com", module="email")
        stale = datetime.now(timezone.utc) - timedelta(seconds=10)
        jobs.update_job(
            claimed.id,
            status="claimed",
            claimed_by="dead-worker",
            claimed_at=stale,
            heartbeat_at=stale,
        )
        jobs.update_job(running.id, status="running")
        jobs.update_job(finished.id, status="finished")

        status = jobs.worker_status(stale_after_seconds=1)
        idle = jobs.wait_for_worker_idle(timeout=0.01)

        assert status["queued"] == 1
        assert status["claimed"] == 1
        assert status["stale_active"] == 1
        assert status["active"] == 3
        assert status["status_counts"]["queued"] == 1
        assert status["status_counts"]["claimed"] == 1
        assert status["status_counts"]["running"] == 1
        assert status["status_counts"]["finished"] == 1
        assert not idle

        jobs.update_job(queued.id, status="finished")
        jobs.update_job(claimed.id, status="failed")
        jobs.update_job(running.id, status="cancelled")

        assert jobs.worker_status()["active"] == 0
        assert jobs.wait_for_worker_idle(timeout=0.01)
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_stale_claimed_job_is_recovered_and_run_by_worker(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    calls = {"count": 0}

    def fake_run_module(module: str, case_name: str, target: str):
        calls["count"] += 1
        return {"module": module}

    monkeypatch.setattr(jobs, "_run_module", fake_run_module)
    try:
        job = jobs.create_job("bob@example.com", module="email")
        stale = datetime.now(timezone.utc) - timedelta(seconds=60)
        jobs.update_job(
            job.id,
            status="claimed",
            current_source="worker",
            claimed_by="dead-worker",
            claimed_at=stale,
            heartbeat_at=stale,
        )

        recovered = jobs.recover_stale_jobs(stale_after_seconds=1)
        requeued = jobs.get_job(job.id)

        assert recovered["requeued"] == 1
        assert recovered["jobs"][0]["job"] == job.id
        assert requeued.status == "queued"
        assert requeued.resume is True
        assert requeued.claimed_by == ""
        assert requeued.claimed_at is None
        assert requeued.heartbeat_at is None
        assert jobs.list_job_events(job.id)[-1].kind == "requeued_stale"

        result = jobs.run_worker_once(stale_after_seconds=1, worker_id="live-worker")
        saved = jobs.get_job(job.id)

        assert result["status"] == "finished"
        assert saved.status == "finished"
        assert saved.claimed_by == "live-worker"
        assert saved.claimed_at is not None
        assert saved.heartbeat_at is not None
        assert calls["count"] == 1
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_finished_job_is_not_rerun_by_run_job(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    calls = {"count": 0}

    def fake_run_module(module: str, case_name: str, target: str):
        calls["count"] += 1
        return {"module": module}

    monkeypatch.setattr(jobs, "_run_module", fake_run_module)
    try:
        job = jobs.create_job("bob@example.com", module="email")
        first = jobs.run_job(job.id)
        second = jobs.run_job(job.id)

        assert first["status"] == "finished"
        assert second == {"job": job.id, "status": "finished"}
        assert calls["count"] == 1
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_job_cancel_before_run_records_cancelled_event(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    monkeypatch.setattr(
        jobs,
        "_run_module",
        lambda module, case_name, target: (_ for _ in ()).throw(AssertionError("should not run")),
    )
    try:
        job = jobs.create_job("bob@example.com", module="email")
        jobs.cancel_job(job.id)

        result = jobs.run_job(job.id)
        saved = jobs.get_job(job.id)
        kinds = [event.kind for event in jobs.list_job_events(job.id)]

        assert result["status"] == "cancelled"
        assert saved.status == "cancelled"
        assert "cancel_requested" in kinds
        assert "cancelled" in kinds
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_job_rate_limit_budget_skips_source_without_running(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    called = {"value": False}

    def fake_run_module(module: str, case_name: str, target: str):
        called["value"] = True
        return {}

    monkeypatch.setattr(jobs, "_run_module", fake_run_module)
    try:
        job = jobs.create_job(
            "bob@example.com",
            module="email",
            rate_limit_budget={"email": 0},
        )

        result = jobs.run_job(job.id)
        saved = jobs.get_job(job.id)
        events = jobs.list_job_events(job.id)

        assert result["status"] == "finished"
        assert saved.status == "finished"
        assert saved.completed_sources == 1
        assert not called["value"]
        assert any(
            event.kind == "source_skipped" and event.status == "rate_limited"
            for event in events
        )
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_username_job_resume_skips_completed_sources(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    scanned: list[str] = []
    persisted: list[list[str]] = []

    monkeypatch.setattr(
        jobs,
        "load_sites",
        lambda path=None: {
            "One": {"url": "https://one.example/{account}"},
            "Two": {"url": "https://two.example/{account}"},
        },
    )

    def fake_scan(username: str, source_name: str, site: dict):
        scanned.append(source_name)
        return _site_result(source_name)

    def fake_persist(case_name: str, username: str, results: list[SiteResult]):
        persisted.append([result.site_name for result in results])
        return {"persisted": persisted[-1]}

    monkeypatch.setattr(jobs, "_scan_username_site", fake_scan)
    monkeypatch.setattr(jobs, "_persist_username_results", fake_persist)
    try:
        job = jobs.create_job("bob", module="username", resume=True)
        jobs.add_job_event(
            job.id,
            kind="source_finished",
            source="One",
            status="finished",
            progress=0.5,
        )

        result = jobs.run_job(job.id, resume=True)
        saved = jobs.get_job(job.id)

        assert result["status"] == "finished"
        assert scanned == ["Two"]
        assert persisted == [["Two"]]
        assert saved.completed_sources == 2
        assert saved.progress == 1.0
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_username_job_cancel_requested_during_last_source_stays_cancelled(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    persisted: list[str] = []

    monkeypatch.setattr(
        jobs,
        "load_sites",
        lambda path=None: {"One": {"url": "https://one.example/{account}"}},
    )

    try:
        job = jobs.create_job("bob", module="username")

        def fake_scan(username: str, source_name: str, site: dict):
            jobs.cancel_job(job.id)
            return _site_result(source_name)

        def fake_persist(case_name: str, username: str, results: list[SiteResult]):
            persisted.extend(result.site_name for result in results)
            return {"persisted": persisted}

        monkeypatch.setattr(jobs, "_scan_username_site", fake_scan)
        monkeypatch.setattr(jobs, "_persist_username_results", fake_persist)

        result = jobs.run_job(job.id)
        saved = jobs.get_job(job.id)
        events = jobs.list_job_events(job.id)

        assert result["status"] == "cancelled"
        assert saved.status == "cancelled"
        assert persisted == ["One"]
        assert events[-1].kind == "cancelled"
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_pipeline_job_retries_sources_and_persists_aggregate_case(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    calls: dict[str, int] = {}
    heartbeat_sources: list[str] = []

    monkeypatch.setattr(
        jobs,
        "_pipeline_source_ids",
        lambda input_type: ["api:crtsh", "api:rdap"],
    )

    def fake_pipeline_source(source_id: str, target: str, input_type: str):
        calls[source_id] = calls.get(source_id, 0) + 1
        if source_id == "api:crtsh" and calls[source_id] == 1:
            raise RuntimeError("temporary source error")
        suffix = source_id.rsplit(":", 1)[-1]
        return AdapterResult(
            source_id=source_id,
            target=target,
            status="ok",
            input_type=input_type,
            url=f"https://api.example.test/{suffix}",
            status_code=200,
            headers={"x-source": suffix},
            normalized={
                "entities": [
                    {"type": input_type, "value": target},
                    {"type": "domain", "value": f"{suffix}.example.com"},
                ],
                "relations": [
                    {
                        "src_type": input_type,
                        "src_value": target,
                        "rel": "mentions_domain",
                        "dst_type": "domain",
                        "dst_value": f"{suffix}.example.com",
                    }
                ],
                "findings": [
                    {
                        "source_id": source_id,
                        "entity_type": input_type,
                        "entity_value": target,
                        "status": "exists",
                        "confidence": 0.8,
                    }
                ],
                "timeline": [
                    {
                        "kind": "adapter_observed",
                        "entity_type": input_type,
                        "entity_value": target,
                        "source": source_id,
                        "confidence": 0.8,
                    }
                ],
                "raw": {},
            },
        )

    monkeypatch.setattr(jobs, "_run_pipeline_source", fake_pipeline_source)
    original_heartbeat_job = jobs.heartbeat_job

    def tracked_heartbeat(job_id: int, worker_id: str | None = None):
        current = jobs.get_job(job_id)
        heartbeat_sources.append(current.current_source if current is not None else "")
        return original_heartbeat_job(job_id, worker_id=worker_id)

    monkeypatch.setattr(jobs, "heartbeat_job", tracked_heartbeat)
    try:
        job = jobs.create_job("example.com", module="domain_pipeline", max_retries=1)
        result = jobs.run_job(job.id)
        saved = jobs.get_job(job.id)
        events = [jobs.job_event_as_dict(event) for event in jobs.list_job_events(job.id)]
        workspace = get_workspace("domain_pipeline-example-com")

        assert result["status"] == "finished"
        assert result["result"]["counts"]["findings"] == 2
        assert saved.status == "finished"
        assert saved.total_sources == 2
        assert saved.completed_sources == 2
        assert calls["api:crtsh"] == 2
        assert calls["api:rdap"] == 1
        assert {"api:crtsh", "api:rdap"}.issubset(set(heartbeat_sources))
        assert any(event["kind"] == "retry" and event["source"] == "api:crtsh" for event in events)
        assert [event["source"] for event in events if event["kind"] == "source_finished"] == [
            "api:crtsh",
            "api:rdap",
        ]
        assert workspace["counts"]["findings"] == 2
        assert {row["headers"]["x-source"] for row in workspace["evidence"]} == {
            "crtsh",
            "rdap",
        }
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_pipeline_job_cancel_requested_during_last_source_stays_cancelled(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)

    monkeypatch.setattr(jobs, "_pipeline_source_ids", lambda input_type: ["api:crtsh"])

    try:
        job = jobs.create_job("example.com", module="domain_pipeline")

        def fake_pipeline_source(source_id: str, target: str, input_type: str):
            jobs.cancel_job(job.id)
            return AdapterResult(
                source_id=source_id,
                target=target,
                status="ok",
                input_type=input_type,
                url="https://api.example.test/crtsh",
                status_code=200,
                normalized={
                    "entities": [{"type": input_type, "value": target}],
                    "relations": [],
                    "findings": [
                        {
                            "source_id": source_id,
                            "entity_type": input_type,
                            "entity_value": target,
                            "status": "exists",
                            "confidence": 0.8,
                        }
                    ],
                    "timeline": [],
                    "raw": {},
                },
            )

        monkeypatch.setattr(jobs, "_run_pipeline_source", fake_pipeline_source)

        result = jobs.run_job(job.id)
        saved = jobs.get_job(job.id)
        events = jobs.list_job_events(job.id)
        workspace = get_workspace("domain_pipeline-example-com")

        assert result["status"] == "cancelled"
        assert saved.status == "cancelled"
        assert events[-1].kind == "cancelled"
        assert workspace["counts"]["findings"] == 1
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_search_job_runs_unified_search_pipeline_concurrently(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    monkeypatch.delenv("BEDNIIOSINT_SEARCH_JOB_WORKERS", raising=False)
    calls: list[dict] = []

    def fake_search_pipeline(target: str, **kwargs):
        calls.append(kwargs)
        return {
            "target": target,
            "counts": {"search_sources": len(kwargs["search_plan"].sources), "search_results": 2},
            "dedup_summary": {"clusters": 1},
            "search_results": [{"id": "one"}, {"id": "two"}],
            "result_clusters": [{"cluster_id": "cluster-one"}],
        }

    monkeypatch.setattr("bedniiosint.search.pipeline.run_planned_search_pipeline", fake_search_pipeline)
    try:
        job = jobs.create_job("example.com", module="search")
        result = jobs.run_job(job.id)
        saved = jobs.get_job(job.id)
        events = [event.kind for event in jobs.list_job_events(job.id)]

        assert job.module == "domain_search"
        assert result["status"] == "finished"
        assert result["result"]["dedup_summary"]["clusters"] == 1
        assert saved.status == "finished"
        assert saved.progress == 1.0
        assert calls[0]["concurrent"] is True
        assert calls[0]["max_workers"] == 8
        assert calls[0]["available_only"] is True
        assert calls[0]["include_dorking"] is True
        assert "search_planned" in events
        assert events[-1] == "finished"
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_investigate_job_uses_recursive_investigation(tmp_path: Path, monkeypatch):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    calls: list[dict] = []

    def fake_recursive(target: str, **kwargs):
        calls.append({"target": target, **kwargs})
        return {
            "module": "auto_pivot",
            "seed": {"entity_type": kwargs["entity_type"], "value": target},
            "node_count": 2,
            "result_count": 1,
            "search_results": [{"id": "one"}],
            "correlations": [{"kind": "shared_email"}],
            "identities": [],
        }

    monkeypatch.setattr("bedniiosint.search.auto_pivot.run_recursive_investigation", fake_recursive)
    try:
        job = jobs.create_job("alice", module="investigate")
        result = jobs.run_job(job.id)
        saved = jobs.get_job(job.id)
        events = [event.kind for event in jobs.list_job_events(job.id)]

        assert job.module == "investigate"
        assert result["status"] == "finished"
        assert result["result"]["module"] == "auto_pivot"
        assert saved.status == "finished"
        assert saved.progress == 1.0
        assert calls[0]["target"] == "alice"
        assert calls[0]["entity_type"] == "username"
        assert calls[0]["save"] is True
        assert calls[0]["case_name"] == job.case_name
        assert "investigation_planned" in events
        assert events[-1] == "finished"
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_jobs_dashboard_exposes_worker_events_and_budget_controls(tmp_path: Path):
    from bedniiosint.web.routers.jobs import _jobs_html

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        job = jobs.create_job("bob@example.com", module="email", max_retries=2)
        html = _jobs_html()

        assert "/jobs/worker/status" in html
        assert "/jobs/worker/start" in html
        assert "/jobs/worker/stop" in html
        assert f"/jobs/{job.id}/events" in html
        assert f"/jobs/{job.id}/resume" in html
        assert 'name="max_retries"' in html
        assert 'name="rate_limit_budget"' in html
        assert "Start immediately" in html
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_home_header_keeps_tabs_right_and_hides_sources_plugins_links():
    import bedniiosint.web.app as web_app

    header = web_app._header_html("home")
    html = web_app._index_html()
    static_dir = Path(web_app.__file__).with_name("static")
    app_css = (static_dir / "app.css").read_text(encoding="utf-8")
    refresh_css = (static_dir / "refresh.css").read_text(encoding="utf-8")
    app_js = (static_dir / "app.js").read_text(encoding="utf-8")
    home_css = (static_dir / "home.css").read_text(encoding="utf-8")
    home_js = (static_dir / "home.js").read_text(encoding="utf-8")

    assert '<h1 class="brand-logo wordmark reveal"' in html
    assert '/static/app.css?v=' in html
    assert '/static/refresh.css?v=' in html
    assert '/static/app.js?v=' in html
    assert (
        html.index('/static/app.css?v=')
        < html.index('/static/refresh.css?v=')
        < html.index('/static/app.js?v=')
    )
    assert '/static/home.css?v=' in html
    assert '/static/home.js?v=' in html
    assert "<style>{_base_css()" not in html
    assert 'action="/jobs" method="post"' in html
    assert 'name="module" value="investigate"' in html
    assert 'id="moduleInput"' in html
    assert 'name="run_now" value="1"' in html
    assert 'class="google-search-field"' in html
    assert 'id="clearSearch"' not in html
    assert 'class="clear"' not in html
    assert 'class="search-actions actions reveal"' in html
    assert 'id="searchBtn"' in html
    assert ">Search<" in html
    assert 'id="startBtn"' not in html
    assert 'id="deepBtn"' not in html
    assert "Deep investigate" not in html
    assert 'id="feelingButton"' in html
    assert 'class="scope-chip tile"' in html
    assert 'class="home-meta coverage reveal"' in html
    assert 'class="recent-line reveal"' in html
    assert 'id="loadingJobId"' in html
    assert ".hero {" in home_css
    assert ".search-box" in home_css
    assert ".reveal" in home_css
    assert ".ripple" in home_css
    assert "prefers-reduced-motion" in home_css
    assert "STATIC_PLACEHOLDER" in home_js
    assert "prefers-reduced-motion: reduce" in home_js
    assert 'event.key === "/"' in home_js
    assert "await streamJob(job.id)" in home_js
    assert "new EventSource" in home_js
    assert "/events/stream" in home_js
    assert 'moduleInput.value = "investigate"' in home_js
    assert "deepBtn" not in home_js
    assert 'moduleInput.value = "search"' not in home_js
    assert "new URLSearchParams(new FormData(searchForm))" in home_js
    assert 'class="brand-mini"' in header
    assert 'class="lang-switch"' in header
    assert 'data-lang-option="en"' in header
    assert 'data-lang-option="ru"' in header
    assert 'id="themeToggle"' in header
    assert 'data-theme-menu-toggle' in header
    assert 'id="themeMenu"' in header
    assert 'class="theme-dot"' in header
    assert "bedniiosint.lang" in app_js
    assert "bedniiosint.theme" in app_js
    assert "BEDNIIOSINT - DESIGN REFRESH LAYER" in refresh_css
    assert "DESIGN REFRESH LAYER (v3)" in refresh_css
    assert ".theme-menu" in refresh_css
    assert ".tab-count" in refresh_css
    assert ".conf-why" in refresh_css
    assert ".overview-card" in refresh_css
    assert "prefers-reduced-motion" in refresh_css
    assert "const THEMES = ['dark', 'light', 'midnight', 'ocean', 'forest', 'sunset', 'mono'];" in app_js
    assert "function buildThemeMenu()" in app_js
    assert "data-theme-select" in app_js
    assert "window.bedniiosintRerender" in app_js
    assert "'Priority Leads': '\\u041f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0435" in app_js
    assert "Theme: " in app_js
    assert "'Midnight': '\\u041f\\u043e\\u043b\\u043d\\u043e\\u0447\\u044c'" in app_js
    assert ".summary-list" in app_js
    assert "#drawerContent" in app_js
    assert 'href="/sources"' not in header
    assert 'href="/plugins"' not in header
    assert ".topbar {" in app_css
    assert ".lang-switch," in app_css
    assert ".brand-logo {" in app_css
    assert ".google-search-field {" in app_css
    assert 'html[data-theme="light"]' in app_css
    for theme in ("midnight", "ocean", "forest", "sunset", "mono"):
        assert f'html[data-theme="{theme}"]' in app_css
    login_html = web_app._login_html('<script>alert("x")</script>')
    assert '/static/app.css?v=' in login_html
    assert '/static/refresh.css?v=' in login_html
    assert "&lt;script&gt;" in login_html
    assert ("&#34;x&#34;" in login_html) or ("&quot;x&quot;" in login_html)
    assert '<script>alert("x")</script>' not in login_html
    assert '/static/login.css?v=' in login_html
    assert "<style>" not in login_html
    assert "hero-panel" not in html
    assert "health-panel" not in html
    assert "recent-panel" not in html


def test_web_static_assets_are_cacheable_and_job_events_stream(tmp_path: Path, monkeypatch):
    import bedniiosint.web.app as web_app
    import bedniiosint.web.routers.jobs as jobs_router

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    monkeypatch.delenv("BEDNIIOSINT_WEB_TOKEN", raising=False)

    async def fake_job_event_stream(job_id: int):
        yield jobs_router._sse_event("job", {"id": job_id, "status": "queued"})
        yield jobs_router._sse_event("done", {"id": job_id, "status": "queued"})

    monkeypatch.setattr(jobs_router, "_job_event_stream", fake_job_event_stream)
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="Using `httpx` with `starlette.testclient` is deprecated.*",
            )
            from fastapi.testclient import TestClient

            client = TestClient(web_app.app)

        css = client.get("/static/app.css")
        refresh_css = client.get("/static/refresh.css")
        home_css = client.get("/static/home.css")
        login_css = client.get("/static/login.css")
        workspace_css = client.get("/static/workspace.css")
        cytoscape_js = client.get("/static/vendor/cytoscape.min.js")
        graph_cy_js = client.get("/static/graph_cy.js")
        js = client.get("/static/app.js")
        home_js = client.get("/static/home.js")
        workspace_js = client.get("/static/workspace.js")
        assert css.status_code == 200
        assert refresh_css.status_code == 200
        assert home_css.status_code == 200
        assert login_css.status_code == 200
        assert workspace_css.status_code == 200
        assert cytoscape_js.status_code == 200
        assert graph_cy_js.status_code == 200
        assert js.status_code == 200
        assert home_js.status_code == 200
        assert workspace_js.status_code == 200
        assert "public, max-age=86400" in css.headers.get("cache-control", "")
        assert "public, max-age=86400" in refresh_css.headers.get("cache-control", "")
        assert "public, max-age=86400" in home_css.headers.get("cache-control", "")
        assert "public, max-age=86400" in workspace_css.headers.get("cache-control", "")
        assert "public, max-age=86400" in cytoscape_js.headers.get("cache-control", "")
        assert "public, max-age=86400" in graph_cy_js.headers.get("cache-control", "")
        assert "public, max-age=86400" in workspace_js.headers.get("cache-control", "")
        assert "html[data-theme=\"light\"]" in css.text
        assert "html[data-theme=\"midnight\"]" in css.text
        assert "html[data-theme=\"ocean\"]" in css.text
        assert "html[data-theme=\"forest\"]" in css.text
        assert "html[data-theme=\"sunset\"]" in css.text
        assert "html[data-theme=\"mono\"]" in css.text
        assert "BEDNIIOSINT - DESIGN REFRESH LAYER" in refresh_css.text
        assert "DESIGN REFRESH LAYER (v3)" in refresh_css.text
        assert ".theme-menu" in refresh_css.text
        assert ".tab-count" in refresh_css.text
        assert ".conf-why" in refresh_css.text
        assert ".overview-card" in refresh_css.text
        assert "#cyGraph" in refresh_css.text
        assert ".search-box" in home_css.text
        assert ".ripple" in home_css.text
        assert ".login-shell" in login_css.text
        assert ".workspace-shell" in workspace_css.text
        assert "bedniiosint.theme" in js.text
        assert "THEMES.indexOf(current)" in js.text
        assert "new EventSource" in home_js.text
        assert "cytoscape" in cytoscape_js.text
        assert "interactive investigation graph" in graph_cy_js.text
        assert "const CASE_NAME" in workspace_js.text

        job = jobs.create_job("example.com", module="domain")
        stream = client.get(f"/jobs/{job.id}/events/stream")
        assert stream.status_code == 200
        assert stream.headers["content-type"].startswith("text/event-stream")
        assert "event: job" in stream.text
        assert '"status": "queued"' in stream.text
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_jobs_forms_redirect_back_to_jobs_page(tmp_path: Path, monkeypatch):
    import bedniiosint.web.app as web_app

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    monkeypatch.delenv("BEDNIIOSINT_WEB_TOKEN", raising=False)
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="Using `httpx` with `starlette.testclient` is deprecated.*",
            )
            from fastapi.testclient import TestClient

            client = TestClient(web_app.app)

        response = client.post(
            "/jobs",
            data={
                "target": "scally milano",
                "module": "company",
                "resume": "on",
            },
            follow_redirects=False,
        )

        assert response.status_code == 303
        assert response.headers["location"] == "/jobs"
        saved = jobs.list_jobs()[0]
        assert saved.status == "queued"
        assert saved.resume is True
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_home_job_fetch_receives_json_instead_of_html_redirect(tmp_path: Path, monkeypatch):
    import bedniiosint.web.app as web_app
    import bedniiosint.web.routers.jobs as jobs_router

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    monkeypatch.delenv("BEDNIIOSINT_WEB_TOKEN", raising=False)
    monkeypatch.setattr(jobs_router, "run_job", lambda job_id, **kwargs: {"job": job_id, "status": "finished"})
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="Using `httpx` with `starlette.testclient` is deprecated.*",
            )
            from fastapi.testclient import TestClient

            client = TestClient(web_app.app)

        response = client.post(
            "/jobs",
            data={
                "target": "example.com",
                "module": "auto",
                "run_now": "1",
                "max_retries": "1",
            },
            headers={
                "Accept": "application/json",
                "X-Requested-With": "XMLHttpRequest",
            },
            follow_redirects=False,
        )

        assert response.status_code == 200
        payload = response.json()
        assert payload["id"] is not None
        assert payload["case_name"] == "domain-example-com"
        assert payload["status"] == "queued"
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)

