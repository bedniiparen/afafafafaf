from __future__ import annotations

import json
from html import escape
from pathlib import Path

from bedniiosint.core.redaction import redact_url
from bedniiosint.reports.case_html import write_case_html
from bedniiosint.reports.json import write_json
from bedniiosint.reports.markdown import write_case_markdown
from bedniiosint.reports.view_model import (
    build_graph_summary,
    build_report_view_model,
    build_timeline_summary,
)


def _sample_summary() -> dict:
    return {
        "meta": {
            "case": "company-acme",
            "found": True,
            "run_count": 1,
            "runs": [
                {
                    "id": 1,
                    "name": "company-acme",
                    "target": "Acme Corp",
                    "module": "company",
                    "created_at": "2026-06-07T10:00:00+00:00",
                }
            ],
        },
        "entities": [
            {"id": 1, "type": "company", "value": "Acme Corp", "created_at": "2026-06-07T10:00:00+00:00"},
            {"id": 2, "type": "domain", "value": "acme.example", "created_at": "2026-06-07T10:00:01+00:00"},
        ],
        "all_findings": [
            {
                "id": 1,
                "source_name": "RegistrySource",
                "source_id": "api:registry",
                "source_reliability": 0.9,
                "entity_type": "company",
                "entity_value": "Acme Corp",
                "finding_type": "registry_record",
                "status": "exists",
                "confidence": 0.92,
                "matched_markers": "exact_entity_match,score:registry_match:0.30",
                "confidence_reason": "registry profile matched",
                "captured_at": "2026-06-07T10:02:00+00:00",
            },
            {
                "id": 2,
                "source_name": "company-analyzer",
                "source_id": "module:company",
                "source_reliability": 0.7,
                "entity_type": "company",
                "entity_value": "Acme Corp",
                "finding_type": "observation",
                "profile_url": "https://acme.example",
                "status": "exists",
                "confidence": 0.0,
                "matched_markers": "score:registry_match:miss:no registry matches,score:domain_dns:miss:guessed domain has no A records",
                "captured_at": "2026-06-07T10:03:00+00:00",
            },
            {
                "id": 3,
                "source_name": "BadSource",
                "source_id": "bad",
                "entity_type": "company",
                "entity_value": "Acme Corp Ltd",
                "finding_type": "observation",
                "status": "not_exists",
                "confidence": 0.0,
                "rejected": True,
                "reject_reason": "same-name false positive",
                "captured_at": "2026-06-07T10:04:00+00:00",
            },
        ],
        "findings": [],
        "evidence": [
            {
                "id": 1,
                "finding_id": 1,
                "url": "https://registry.example/acme",
                "sha256": "a" * 64,
                "artifact_path": "registry.json",
                "source_module": "company",
                "content_type": "application/json",
                "captured_at": "2026-06-07T10:02:00+00:00",
            },
            {
                "id": 2,
                "finding_id": 2,
                "url": "https://acme.example",
                "sha256": "a" * 64,
                "artifact_path": "acme.html",
                "source_module": "company",
                "content_type": "text/html",
                "captured_at": "2026-06-07T10:03:00+00:00",
            },
        ],
        "sources": [
            {"source_id": "api:registry", "name": "RegistrySource", "category": "business", "success_count": 1, "error_count": 0, "health_status": "available", "reliability": 0.9},
            {"source_id": "api:error", "name": "ErrorSource", "category": "business", "success_count": 0, "error_count": 1, "health_status": "error", "reliability": 0.5},
            {"source_id": "api:timeout", "name": "TimeoutSource", "category": "business", "success_count": 0, "error_count": 1, "health_status": "error", "last_error": "request timeout", "reliability": 0.5},
            {"source_id": "api:missing", "name": "MissingKeySource", "category": "business", "success_count": 0, "error_count": 0, "health_status": "missing_keys", "reliability": 0.5},
        ],
        "relations": [
            {
                "id": 1,
                "src_type": "company",
                "src_value": "Acme Corp",
                "rel": "possible_domain",
                "dst_type": "domain",
                "dst_value": "acme.example",
            },
            {
                "id": 2,
                "src_type": "company",
                "src_value": "Acme Corp",
                "rel": "same_as",
                "dst_type": "company",
                "dst_value": "ACME CORP",
            }
        ],
        "attachments": [],
        "timeline": [],
        "notes": [],
        "graph": {"nodes": 2, "edges": 1, "hubs": []},
    }


def test_report_view_model_builds_professional_sections():
    view = build_report_view_model(_sample_summary())
    sections = view["sections"]

    assert view["metadata"]["target"] == "Acme Corp"
    assert view["metadata"]["entity_type"] == "company"
    assert sections["executive_summary"]["case_status"] in {"Confirmed findings present", "Needs corroboration", "Needs review"}
    assert sections["executive_summary"]["overall_confidence"]["label"]
    assert sections["key_findings"][0]["title"] != "observation"
    assert any("Possible related domain" in row["title"] for row in sections["key_findings"])
    assert "None confidence (0%); weakness: single-source observation" in sections["key_findings"][1]["confidence"]["explanation"]
    assert any(
        any("; single-source, verify independently" in item for item in row["confidence"]["explanation"])
        for row in sections["key_findings"]
    )
    assert sections["result_clusters"]["by_name"]["Rejected / false positives"]["count"] == 1
    assert sections["result_clusters"]["by_name"]["Weak observations"]["count"] >= 1
    assert sections["entity_correlation"]["summary"]["entity_clusters"] >= 2
    assert sections["entity_correlation"]["summary"]["alias_links"] == 1
    assert sections["entity_correlation"]["review_queue"]
    assert view["raw_appendix"]["primary"] is False


def test_source_evidence_actions_graph_and_timeline_sections_are_structured():
    view = build_report_view_model(_sample_summary())
    sections = view["sections"]

    coverage = sections["source_coverage"]["summary"]
    assert coverage["successful_sources"] == 1
    assert coverage["failed_sources"] == 1
    assert coverage["timed_out_sources"] == 1
    assert coverage["missing_api_keys"] == 1

    evidence = sections["evidence_summary"]
    assert evidence["total_evidence_files"] == 2
    assert evidence["hash_records"] == 2
    assert evidence["duplicate_evidence"] == ["a" * 64]
    assert evidence["manifest"]["hash_algorithm"] == "sha256"

    actions = sections["recommended_next_actions"]
    assert any(row["scope"] == "/business/registry" for row in actions)
    assert any(row["scope"] == "/infra/dns" for row in actions)
    assert sections["graph_relationships"]["sparse"] is True
    assert sections["timeline"]["events"]


def test_html_and_json_reports_render_required_sections(tmp_path: Path):
    summary = _sample_summary()
    html_path = write_case_html(summary, tmp_path / "case.html")
    markdown_path = write_case_markdown(summary, tmp_path / "case.md")
    json_path = write_json(build_report_view_model(summary), tmp_path / "case-technical.json")

    html = html_path.read_text(encoding="utf-8")
    markdown = markdown_path.read_text(encoding="utf-8")
    payload = json.loads(json_path.read_text(encoding="utf-8"))

    for label in (
        "A. Cover / Case Metadata",
        "B. Executive Summary",
        "C. Key Findings",
        "D. Entity Overview",
        "D2. Entity Correlation",
        "F. Evidence Summary",
        "G. Source Coverage",
        "H. Confidence Breakdown",
        "K. Unconfirmed Hypotheses",
        "L. False Positive Risks",
        "M. Recommended Next Actions",
        "N. Raw Appendix",
    ):
        assert label in html
    assert "<details" in html
    assert payload["kind"] == "bedniiosint.technical_report"
    assert "executive_summary" in payload["sections"]
    assert "entity_correlation" in payload["sections"]
    assert "raw_appendix" in payload
    assert "## Entity Correlation" in markdown
    assert "### Alias Links" in markdown


def test_html_report_wraps_long_unbroken_values(tmp_path: Path):
    summary = _sample_summary()
    long_error = "timeout-" + ("x" * 260)
    long_url = "https://example.com/" + ("deep/" * 8) + ("a" * 260) + "?token=" + ("b" * 120)
    long_artifact = "artifacts/" + ("c" * 260) + ".json"
    summary["sources"][0]["last_error"] = long_error
    summary["evidence"][0]["url"] = long_url
    summary["evidence"][0]["artifact_path"] = long_artifact

    html = write_case_html(summary, tmp_path / "long-values.html").read_text(encoding="utf-8")

    for css in (
        'class="table-wrap"',
        "table-layout:fixed",
        "overflow-wrap:anywhere",
        "word-wrap:break-word",
        "word-break:break-word",
        "hyphens:auto",
        "break-inside:auto",
    ):
        assert css in html
    assert escape(long_error) in html
    assert f'<a href="{escape(redact_url(long_url))}"' in html
    assert ("b" * 120) not in html
    assert escape(long_artifact) in html


def test_graph_summary_and_empty_timeline_edge_cases():
    graph = build_graph_summary([], [], [])
    timeline = build_timeline_summary([], [], [])

    assert graph["sparse"] is True
    assert "Sparse graph" in graph["sparse_graph_explanation"]
    assert timeline["empty"] is True
    assert "No timeline events" in timeline["empty_explanation"]


def test_report_view_model_keeps_dorking_and_raw_noise_out_of_analyst_sections():
    summary = {
        "meta": {
            "case": "company_search-scally-milano",
            "found": True,
            "run_count": 2,
            "runs": [{"target": "scally milano", "module": "search_dorking"}],
        },
        "entities": [
            {"type": "company", "value": "scally milano"},
            {"type": "domain", "value": "FutureTask.java"},
            {"type": "domain", "value": "about.json"},
            {"type": "domain", "value": "example.com"},
        ],
        "all_findings": [
            {
                "id": 1,
                "source_name": "api:peeringdb",
                "source_id": "api:peeringdb",
                "entity_type": "company",
                "entity_value": "scally milano",
                "finding_type": "pipeline_adapter_result",
                "status": "exists",
                "confidence": 75.0,
                "profile_url": "https://www.peeringdb.com/api/net?name__contains=scally%20milano",
            },
            {
                "id": 2,
                "source_name": "Bing Dork",
                "source_id": "dorking:bing",
                "entity_type": "url",
                "entity_value": "https://www.bing.com/search?q=scally+milano",
                "finding_type": "dorking_lead",
                "status": "unknown",
                "confidence": 0.0,
                "matched_markers": "review_only,dorking,manual_verification_required,no_confirmation_signals",
            },
        ],
        "evidence": [{"id": 1, "finding_id": 1, "sha256": "b" * 64, "artifact_path": "peeringdb.json"}],
        "sources": [
            {"source_id": "api:peeringdb", "name": "PeeringDB", "success_count": 1},
            {
                "source_id": "dorking:bing",
                "name": "Bing Dork",
                "category": "search_dorking",
                "success_count": 1,
            },
        ],
        "relations": [],
        "timeline": [],
    }
    summary["evidence"].append(
        {
            "id": 2,
            "finding_id": 2,
            "sha256": "c" * 64,
            "artifact_path": "dorking/bing.json",
            "source_module": "search_dorking",
        }
    )

    view = build_report_view_model(summary)
    sections = view["sections"]
    key_findings = sections["key_findings"]
    entities = sections["entity_overview"]["all_entities"]
    clusters = sections["result_clusters"]["by_name"]
    evidence = sections["evidence_summary"]
    coverage = sections["source_coverage"]

    assert view["metadata"]["entity_type"] == "company"
    assert sections["executive_summary"]["counts"]["findings"] == 1
    assert sections["executive_summary"]["counts"]["review_only_leads"] == 1
    assert key_findings[0]["entity_value"] == "scally milano"
    assert "bing.com/search" not in str(key_findings)
    assert key_findings[0]["confidence"]["label"] == "Medium / 75%"
    assert "FutureTask.java" not in str(entities)
    assert "about.json" not in str(entities)
    assert any(row["type"] == "company" and row["value"] == "scally milano" for row in entities)
    assert clusters["Weak observations"]["count"] == 0
    assert clusters["Review-only leads"]["count"] == 1
    assert evidence["total_evidence_files"] == 1
    assert evidence["review_only_evidence_files"] == 1
    assert coverage["summary"]["sources_checked"] == 2
    assert coverage["summary"]["review_only_source_templates"] == 1
    assert [row["source"] for row in coverage["rows"]] == ["api:peeringdb", "dorking:review_queue"]


def test_report_view_model_keeps_direct_profile_candidates_reportable():
    summary = {
        "meta": {
            "case": "username_search-bedniiparen",
            "found": True,
            "runs": [{"target": "bedniiparen", "module": "search_dorking"}],
        },
        "entities": [{"type": "username", "value": "bedniiparen"}],
        "all_findings": [
            {
                "id": 1,
                "source_name": "GitHub Profile Candidate",
                "source_id": "dorking:profile:github",
                "entity_type": "url",
                "entity_value": "https://github.com/bedniiparen",
                "finding_type": "dorking_lead",
                "status": "unknown",
                "confidence": 0.0,
                "profile_url": "https://github.com/bedniiparen",
                "matched_markers": "review_only,dorking,manual_verification_required,no_confirmation_signals",
            },
            {
                "id": 2,
                "source_name": "Google Dork",
                "source_id": "dorking:google",
                "entity_type": "url",
                "entity_value": "https://www.google.com/search?q=bedniiparen",
                "finding_type": "dorking_lead",
                "status": "unknown",
                "confidence": 0.0,
                "profile_url": "https://www.google.com/search?q=bedniiparen",
                "matched_markers": "review_only,dorking,manual_verification_required,no_confirmation_signals",
            },
        ],
        "evidence": [
            {"id": 1, "finding_id": 1, "sha256": "a" * 64, "artifact_path": "dorking/github.json", "source_module": "search_dorking"},
            {"id": 2, "finding_id": 2, "sha256": "b" * 64, "artifact_path": "dorking/google.json", "source_module": "search_dorking"},
        ],
        "sources": [
            {"source_id": "dorking:profile:github", "name": "GitHub Profile Candidate", "category": "search_dorking", "success_count": 1},
            {"source_id": "dorking:google", "name": "Google Dork", "category": "search_dorking", "success_count": 1},
        ],
        "relations": [],
        "timeline": [],
    }

    view = build_report_view_model(summary)
    sections = view["sections"]

    assert sections["executive_summary"]["counts"]["findings"] == 1
    assert sections["executive_summary"]["counts"]["review_only_leads"] == 1
    assert sections["key_findings"][0]["title"] == "Profile URL candidate"
    assert sections["key_findings"][0]["entity_value"] == "https://github.com/bedniiparen"
    assert "google.com/search" not in str(sections["key_findings"])
    assert sections["result_clusters"]["by_name"]["Public profiles"]["count"] == 1
    assert sections["result_clusters"]["by_name"]["Review-only leads"]["count"] == 1
    assert sections["evidence_summary"]["total_evidence_files"] == 1
    assert sections["evidence_summary"]["review_only_evidence_files"] == 1
