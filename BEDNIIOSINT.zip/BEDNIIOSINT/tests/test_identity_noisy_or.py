from bedniiosint.search.identity import _noisy_or, build_identities
from bedniiosint.search.models import SearchResult


def test_noisy_or_math():
    assert _noisy_or([]) == 0.0
    assert abs(_noisy_or([0.5, 0.5]) - 0.75) < 1e-9
    assert abs(_noisy_or([1.0, 0.3]) - 1.0) < 1e-9


def _result(rid: str, source: str, value: str, conf: float) -> SearchResult:
    return SearchResult(
        id=rid,
        source_id=source,
        source_name=source,
        entity_input=value,
        entity_type="username",
        matched_entity=value,
        confidence_score=conf,
    )


def test_build_identities_merges_linked_results():
    r1 = _result("r1", "api:github", "alice", 0.6)
    r2 = _result("r2", "api:gitlab", "alice", 0.6)
    links = [
        {"kind": "cross_platform_username", "confidence": 0.8, "member_ids": ["r1", "r2"]}
    ]
    personas = build_identities([r1, r2], links)
    assert len(personas) == 1
    persona = personas[0]
    assert set(persona["member_result_ids"]) == {"r1", "r2"}
    assert persona["source_count"] == 2
    assert persona["confidence"] > 0.6
    assert persona["confidence"] <= 1.0
