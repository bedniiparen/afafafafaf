from __future__ import annotations

import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import pytest

from bedniiosint.evidence.bundle import (
    import_evidence_bundle,
    inspect_evidence_bundle,
    write_evidence_bundle,
)
from bedniiosint.evidence.hashing import sha256_file
from bedniiosint.storage.models import Attachment, Case, Evidence, Finding
from bedniiosint.storage.sqlite import Storage


def test_evidence_bundle_signs_hashes_and_imports_artifacts(tmp_path: Path):
    storage = Storage(tmp_path / "case.db")
    artifact = tmp_path / "artifact.json"
    artifact.write_text('{"raw": true}', encoding="utf-8")

    with storage.session() as session:
        case = Case(name="bundle-case", target="bob", module="test")
        session.add(case)
        session.commit()
        session.refresh(case)
        finding = Finding(
            case_id=case.id,
            source_name="source-a",
            entity_value="bob",
            profile_url="https://example.test/bob?api_key=secret",
            status="exists",
        )
        session.add(finding)
        session.commit()
        session.refresh(finding)
        session.add(
            Evidence(
                case_id=case.id,
                finding_id=finding.id,
                url="https://example.test/bob?api_key=secret",
                final_url="https://example.test/bob",
                http_status=200,
                sha256=sha256_file(artifact),
                body_len=artifact.stat().st_size,
                source_module="test",
                artifact_path=str(artifact),
                query_params_json='{"api_key": "secret"}',
            )
        )
        session.add(
            Attachment(
                case_id=case.id,
                finding_id=finding.id,
                kind="raw_json",
                path=str(artifact),
                sha256=sha256_file(artifact),
                mime="application/json",
                source_adapter_version="adapter/1.0",
            )
        )
        session.commit()
        case_id = case.id

    bundle = write_evidence_bundle(
        storage,
        case_id,
        tmp_path / "bundle-case-evidence-bundle.zip",
        signing_key="secret-key",
        key_id="test-key",
    )
    inspected = inspect_evidence_bundle(bundle, signing_key="secret-key")
    imported = import_evidence_bundle(bundle, tmp_path / "imported")

    assert bundle.exists()
    assert inspected["signature_verified"] is True
    assert inspected["signature"]["key_id"] == "test-key"
    assert inspected["manifest"]["bundle"]["artifact_count"] == 1
    assert inspected["manifest"]["evidence"][0]["query_params"]["api_key"] == "[redacted]"
    assert all(row["present"] and row["sha256_ok"] for row in inspected["files"])
    assert (tmp_path / "imported" / "evidence-manifest.json").exists()
    assert any("artifacts" in path for path in imported["extracted"])


def test_evidence_bundle_import_rejects_unsafe_paths(tmp_path: Path):
    bundle = tmp_path / "unsafe.zip"
    with ZipFile(bundle, "w", ZIP_DEFLATED) as archive:
        archive.writestr("evidence-manifest.json", "{}")
        archive.writestr("../escape.txt", "no")

    with pytest.raises(ValueError):
        import_evidence_bundle(bundle, tmp_path / "out")


def test_evidence_bundle_import_rejects_tampered_artifact(tmp_path: Path):
    good = tmp_path / "good.zip"
    bad = tmp_path / "bad.zip"
    artifact = tmp_path / "artifact.json"
    artifact.write_text('{"raw": true}', encoding="utf-8")
    digest = sha256_file(artifact)
    manifest = {
        "schema_version": "0.3",
        "bundle": {"artifact_count": 1},
        "bundle_files": [
            {
                "role": "attachment",
                "id": 1,
                "archive_path": "artifacts/attachments/1-artifact.json",
                "sha256": digest,
            }
        ],
    }
    with ZipFile(good, "w", ZIP_DEFLATED) as archive:
        archive.writestr("evidence-manifest.json", json.dumps(manifest))
        archive.writestr("artifacts/attachments/1-artifact.json", artifact.read_text())
    with ZipFile(bad, "w", ZIP_DEFLATED) as archive:
        archive.writestr("evidence-manifest.json", json.dumps(manifest))
        archive.writestr("artifacts/attachments/1-artifact.json", '{"raw": false}')

    imported = import_evidence_bundle(good, tmp_path / "good-out")
    with pytest.raises(ValueError, match="integrity check failed"):
        import_evidence_bundle(bad, tmp_path / "bad-out")

    assert imported["files"][0]["sha256_ok"] is True


def test_evidence_bundle_import_rejects_signature_mismatch(tmp_path: Path):
    storage = Storage(tmp_path / "case.db")
    artifact = tmp_path / "signed.json"
    artifact.write_text('{"signed": true}', encoding="utf-8")

    with storage.session() as session:
        case = Case(name="signed-case", target="bob", module="test")
        session.add(case)
        session.commit()
        session.refresh(case)
        finding = Finding(case_id=case.id, source_name="source-a", entity_value="bob", status="exists")
        session.add(finding)
        session.commit()
        session.refresh(finding)
        session.add(
            Attachment(
                case_id=case.id,
                finding_id=finding.id,
                kind="raw_json",
                path=str(artifact),
                sha256=sha256_file(artifact),
            )
        )
        session.commit()
        case_id = case.id

    bundle = write_evidence_bundle(
        storage,
        case_id,
        tmp_path / "signed-case-evidence-bundle.zip",
        signing_key="right-key",
    )

    assert import_evidence_bundle(bundle, tmp_path / "signed-out", signing_key="right-key")[
        "signature_verified"
    ] is True
    with pytest.raises(ValueError, match="signature verification failed"):
        import_evidence_bundle(bundle, tmp_path / "signed-bad", signing_key="wrong-key")
