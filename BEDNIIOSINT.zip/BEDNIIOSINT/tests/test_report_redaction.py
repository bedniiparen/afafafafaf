from __future__ import annotations

import json

from bedniiosint.reports.case_html import write_case_html
from bedniiosint.reports.csv import write_case_csv
from bedniiosint.reports.json import write_json
from bedniiosint.reports.markdown import write_case_markdown


def test_report_exports_redact_url_query_and_header_secrets(tmp_path):
    secret = "super-secret-token"
    summary = {
        "meta": {
            "found": True,
            "case_name": "redaction",
            "case_title": "Redaction",
            "target": "bob",
            "entity_type": "username",
            "search_module": "username",
            "scope": "passive",
            "runs_count": 1,
            "report_version": "test",
            "legal_privacy_note": "public OSINT only",
        },
        "findings": [
            {
                "source_name": "Example",
                "source_id": "api:example",
                "entity_type": "username",
                "entity_value": "bob",
                "finding_type": "profile",
                "status": "exists",
                "confidence": 0.91,
                "confidence_reason": f"checked https://example.test/bob?token={secret}",
                "profile_url": f"https://example.test/bob?api_key={secret}&ok=1",
                "final_url": f"https://example.test/bob?api_key={secret}&ok=1",
            }
        ],
        "sources": [
            {
                "source_id": "api:example",
                "name": "Example",
                "auth": "api_key",
                "last_error": f"failed https://example.test/?token={secret}",
            }
        ],
        "evidence": [
            {
                "url": f"https://example.test/evidence?api_key={secret}",
                "final_url": f"https://example.test/evidence?api_key={secret}",
                "headers": {"Authorization": f"Bearer {secret}"},
                "query_params": {"api_key": secret},
                "sha256": "a" * 64,
            }
        ],
        "entities": [{"type": "username", "value": "bob"}],
        "relations": [],
        "attachments": [],
        "timeline": [],
        "notes": [],
        "source_health_history": {
            "rows": [
                {
                    "source_id": "api:example",
                    "auth": "api_key",
                    "last_error": f"failed https://example.test/?token={secret}",
                    "notes": "auth=api_key",
                }
            ]
        },
    }

    json_path = write_json(summary, tmp_path / "case.json")
    csv_paths = write_case_csv(summary, tmp_path, "case")
    markdown_path = write_case_markdown(summary, tmp_path / "case.md")
    html_path = write_case_html(summary, tmp_path / "case.html")

    exported_text = "\n".join(
        [
            json_path.read_text(encoding="utf-8"),
            csv_paths["findings"].read_text(encoding="utf-8"),
            csv_paths["sources"].read_text(encoding="utf-8"),
            csv_paths["evidence"].read_text(encoding="utf-8"),
            markdown_path.read_text(encoding="utf-8"),
            html_path.read_text(encoding="utf-8"),
        ]
    )
    exported_json = json.loads(json_path.read_text(encoding="utf-8"))

    assert secret not in exported_text
    assert "api_key=%5Bredacted%5D" in exported_text
    assert exported_json["sources"][0]["auth"] == "api_key"
    assert "auth=api_key" in exported_text
