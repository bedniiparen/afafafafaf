from __future__ import annotations

import json


class _Response:
    def __init__(self, status_code: int, text: str = "", content: bytes = b"") -> None:
        self.status_code = status_code
        self.text = text
        self.content = content


def test_avatar_hash_attach_and_near_duplicate_correlations(monkeypatch):
    import bedniiosint.search.avatar_hash as avatar_hash

    monkeypatch.setattr(avatar_hash, "_HAS_PIL", True)
    monkeypatch.setattr(avatar_hash, "dhash", lambda _data, hash_size=8: "ff00")

    rows = [
        {
            "id": "left",
            "source_id": "github",
            "normalized_data": {"avatar_url": "https://img.example/a.png"},
        },
        {
            "id": "right",
            "source_id": "gitlab",
            "normalized_data": {"avatar_phash": "ff01"},
        },
    ]

    count = avatar_hash.attach_avatar_hashes(rows, fetch_bytes=lambda _url: b"image")
    links = avatar_hash.avatar_correlations(rows, max_distance=1)

    assert count == 1
    assert rows[0]["normalized_data"]["avatar_hash"] == "ff00"
    assert len(links) == 1
    assert links[0].kind == "shared_avatar_hash"
    assert links[0].member_ids == ["left", "right"]


def test_correlation_rules_load_json_and_apply(tmp_path):
    from bedniiosint.search.correlation_rules import apply_rules, load_rules

    path = tmp_path / "rules.json"
    path.write_text(
        json.dumps(
            {
                "rules": [
                    {
                        "id": "same_name",
                        "kind": "same_display_name",
                        "group_by": "normalized_data.full_name",
                        "where": [
                            {
                                "field": "confidence_score",
                                "op": "gte",
                                "value": 0.5,
                            }
                        ],
                        "min_members": 2,
                        "min_sources": 2,
                        "confidence": 0.7,
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    rows = [
        {
            "id": "a",
            "source_id": "github",
            "confidence_score": 0.8,
            "normalized_data": {"full_name": "Alice Smith"},
        },
        {
            "id": "b",
            "source_id": "gitlab",
            "confidence_score": 0.9,
            "normalized_data": {"full_name": "Alice Smith"},
        },
        {
            "id": "low",
            "source_id": "other",
            "confidence_score": 0.2,
            "normalized_data": {"full_name": "Alice Smith"},
        },
    ]

    links = apply_rules(rows, load_rules(path))

    assert len(links) == 1
    assert links[0].kind == "same_display_name"
    assert links[0].sources == ["github", "gitlab"]
    assert links[0].confidence == 0.7


def test_profile_extract_and_enrich_results():
    from bedniiosint.search.profile_extract import enrich_results, extract_profile

    html = """
    <html>
      <head>
        <title>Alice Smith</title>
        <meta property="og:description" content="Security researcher @alice">
        <meta property="og:image" content="https://img.example/alice.png">
      </head>
      <body>
        contact alice@example.com
        <a href="https://example.com">site</a>
      </body>
    </html>
    """
    profile = extract_profile(html)
    rows = [
        {
            "id": "profile",
            "url": "https://profile.example/alice",
            "confidence_score": 0.7,
            "normalized_data": {},
        }
    ]

    count = enrich_results(rows, fetch_text=lambda _url: (200, html))

    assert profile["full_name"] == "Alice Smith"
    assert profile["emails"] == ["alice@example.com"]
    assert "alice" in profile["handles"]
    assert count == 1
    assert rows[0]["confidence_score"] == 0.75
    assert rows[0]["normalized_data"]["avatar_url"] == "https://img.example/alice.png"
    assert {"type": "email", "value": "alice@example.com"} in rows[0]["normalized_data"]["pivots"]


def test_host_throttle_adapts_and_negative_cache_short_circuits():
    from bedniiosint.search.host_throttle import HostThrottle, NegativeCache, throttled_request

    now = [0.0]

    def clock() -> float:
        return now[0]

    def sleep(seconds: float) -> None:
        now[0] += seconds

    throttle = HostThrottle(default_rate=1.0, burst=1.0, min_rate=0.25, recover_step=0.5, clock=clock, sleep=sleep)
    cache = NegativeCache(ttl=10.0, clock=clock)
    url = "https://example.test/missing"

    assert throttle.acquire(url) == 0.0
    assert throttle.acquire(url) == 1.0
    throttle.record(url, 429)
    assert throttle.rate_for(url) == 0.5
    for _ in range(5):
        throttle.record(url, 200)
    assert throttle.rate_for(url) == 1.0

    calls = {"count": 0}

    def fake_request(_method: str, _url: str, **_kwargs):
        calls["count"] += 1
        return _Response(404)

    first = throttled_request("GET", url, throttle=throttle, negative_cache=cache, request_fn=fake_request)
    second = throttled_request("GET", url, throttle=throttle, negative_cache=cache, request_fn=fake_request)

    assert first.status_code == 404
    assert second is None
    assert calls["count"] == 1
