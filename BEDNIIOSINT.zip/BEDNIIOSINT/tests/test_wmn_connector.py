from __future__ import annotations

import json


class _FakeResponse:
    def __init__(self, status_code: int, text: str) -> None:
        self.status_code = status_code
        self.text = text


def test_wmn_connector_detects_found_and_filters_missing(tmp_path, monkeypatch):
    import bedniiosint.search.connectors.wmn as wmn_module
    from bedniiosint.search.connectors.wmn import WmnConnector

    manifest = {
        "sites": [
            {
                "name": "FoundSite",
                "cat": "social",
                "uri_check": "https://found.example/{account}",
                "uri_pretty": "https://found.example/u/{account}",
                "e_code": 200,
                "e_string": "profile:alice",
            },
            {
                "name": "MissingSite",
                "cat": "social",
                "uri_check": "https://missing.example/{account}",
                "e_code": 200,
                "m_string": "not found",
            },
        ]
    }
    path = tmp_path / "wmn-data.json"
    path.write_text(json.dumps(manifest), encoding="utf-8")

    def fake_request(_method: str, url: str, **_kwargs):
        if "found.example" in url:
            return _FakeResponse(200, "profile:alice")
        return _FakeResponse(200, "not found")

    monkeypatch.setattr(wmn_module, "request", fake_request)
    connector = WmnConnector({"wmn_data_path": str(path), "wmn_workers": 2})
    plan = connector.build_queries({"type": "username", "value": "alice"})

    raw = connector.run(plan)
    parsed = connector.parse(raw)
    rows = connector.normalize(parsed)

    assert raw["status"] == "ok"
    assert raw["checked"] == 2
    assert len(rows) == 1
    assert rows[0].source_id == "wmn"
    assert rows[0].url == "https://found.example/u/alice"
    assert rows[0].normalized_data["presence_state"] == "found"
    assert rows[0].confidence_score >= 0.78


def test_wmn_connector_empty_when_manifest_missing(tmp_path, monkeypatch):
    import bedniiosint.search.connectors.wmn as wmn_module
    from bedniiosint.search.connectors.wmn import WmnConnector

    monkeypatch.setattr(wmn_module, "_default_data_paths", lambda: ("",))
    connector = WmnConnector({"wmn_data_path": str(tmp_path / "missing.json")})
    plan = connector.build_queries({"type": "username", "value": "alice"})

    raw = connector.run(plan)

    assert raw == {"status": "empty", "reason": "wmn-data.json not found", "items": []}
