from bedniiosint.core.case_diff import diff_case_summaries
from bedniiosint.storage.models import Case, Entity, Finding
from bedniiosint.storage.sqlite import Storage


def test_diff_case_summaries_reports_added_and_removed_rows():
    previous = {
        "entities": [
            {"type": "domain", "value": "old.example"},
            {"type": "username", "value": "alice"},
        ],
        "findings": [
            {
                "source_id": "api:github",
                "entity_type": "username",
                "entity_value": "alice",
                "status": "exists",
            }
        ],
        "relations": [
            {
                "src_type": "username",
                "src_value": "alice",
                "rel": "mentions",
                "dst_type": "domain",
                "dst_value": "old.example",
            }
        ],
    }
    current = {
        "entities": [
            {"type": "username", "value": "alice"},
            {"type": "domain", "value": "new.example"},
        ],
        "findings": [
            {
                "source_id": "api:github",
                "entity_type": "username",
                "entity_value": "alice",
                "status": "exists",
            },
            {
                "source_id": "api:crtsh",
                "entity_type": "domain",
                "entity_value": "new.example",
                "status": "exists",
            },
        ],
        "relations": [],
    }

    diff = diff_case_summaries(previous, current)

    assert diff["summary"] == {
        "new_entities": 1,
        "removed_entities": 1,
        "new_findings": 1,
        "removed_findings": 0,
        "new_relations": 0,
        "removed_relations": 1,
    }
    assert diff["entities"]["added"][0]["value"] == "new.example"
    assert diff["entities"]["removed"][0]["value"] == "old.example"


def test_case_diff_api_compares_saved_cases(tmp_path):
    import pytest

    import bedniiosint.web.app as web_app
    from bedniiosint.config import settings

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")
    from fastapi.testclient import TestClient

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path / "cases")
    try:
        old_storage = Storage(settings.db_path("old-case"))
        with old_storage.session() as session:
            case = Case(name="old-case", target="alice", module="username")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(Entity(case_id=case.id, type="username", value="alice"))
            session.add(
                Finding(
                    case_id=case.id,
                    entity_type="username",
                    entity_value="alice",
                    source_name="github",
                    source_id="api:github",
                    status="exists",
                    confidence=0.8,
                )
            )

        new_storage = Storage(settings.db_path("new-case"))
        with new_storage.session() as session:
            case = Case(name="new-case", target="alice", module="username")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(Entity(case_id=case.id, type="username", value="alice"))
            session.add(Entity(case_id=case.id, type="domain", value="example.com"))
            session.add(
                Finding(
                    case_id=case.id,
                    entity_type="domain",
                    entity_value="example.com",
                    source_name="crtsh",
                    source_id="api:crtsh",
                    status="exists",
                    confidence=0.7,
                )
            )

        response = TestClient(web_app.app).get(
            "/cases/diff",
            params={"previous": "old-case", "current": "new-case"},
        )

        assert response.status_code == 200
        payload = response.json()
        assert payload["summary"]["new_entities"] == 1
        assert payload["summary"]["new_findings"] == 1
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_case_diff_cli_and_monitor_subcommand_read_json_files(tmp_path):
    from typer.testing import CliRunner

    from bedniiosint.cli import app

    previous = tmp_path / "previous.json"
    current = tmp_path / "current.json"
    previous.write_text(
        '{"entities":[{"type":"username","value":"alice"}],"findings":[],"relations":[]}',
        encoding="utf-8",
    )
    current.write_text(
        '{"entities":[{"type":"username","value":"alice"},{"type":"domain","value":"example.com"}],"findings":[],"relations":[]}',
        encoding="utf-8",
    )
    runner = CliRunner()

    top_level = runner.invoke(app, ["case-diff", str(previous), str(current)])
    grouped = runner.invoke(app, ["monitor", "diff", str(previous), str(current)])

    assert top_level.exit_code == 0, top_level.output
    assert grouped.exit_code == 0, grouped.output
    assert '"new_entities": 1' in top_level.output
    assert '"new_entities": 1' in grouped.output
