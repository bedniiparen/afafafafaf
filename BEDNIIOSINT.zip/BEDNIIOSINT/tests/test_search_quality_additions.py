from __future__ import annotations


def test_libravatar_email_spec_is_keyless_and_status_based(monkeypatch):
    from bedniiosint.search import account_existence

    spec = next(row for row in account_existence.EMAIL_SPECS if row["platform"] == "libravatar")

    def fake_http(_method, url, **_kwargs):
        assert "seccdn.libravatar.org/avatar/" in url
        assert "d=404" in url
        return 200, ""

    monkeypatch.setattr(account_existence, "_http", fake_http)

    result = account_existence._run_email_spec(
        spec,
        "Alice@Example.com",
        github_token=None,
    )

    assert result is not None
    assert result.source_id == "api:account_existence:libravatar"
    assert result.confidence_score == spec["confidence"]
    assert result.normalized_data["account_existence"]["state"] == "present"


def test_local_hash_embedder_is_deterministic_and_normalized():
    from bedniiosint.search.local_embedder import hash_embed_texts

    first = hash_embed_texts(["alice github profile"], dimensions=32)
    second = hash_embed_texts(["alice github profile"], dimensions=32)
    empty = hash_embed_texts([""], dimensions=32)

    assert first == second
    assert len(first[0]) == 32
    assert round(sum(value * value for value in first[0]), 6) == 1.0
    assert len(empty[0]) == 32


def test_embedding_cache_resolves_local_alias(tmp_path, monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.search import embedding_cache

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    embedding_cache._DB_CACHE.clear()
    monkeypatch.setenv("BEDNIIOSINT_EMBEDDING_PROVIDER", "hash")
    try:
        vectors = embedding_cache.embed_texts_cached(["alice", "alice profile"])
    finally:
        embedding_cache._DB_CACHE.clear()
        object.__setattr__(settings, "db_dir", original_db_dir)

    assert vectors is not None
    assert len(vectors) == 2
    assert len(vectors[0]) == len(vectors[1])


def test_rank_results_uses_local_embedder_when_rerank_enabled(tmp_path, monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.search import embedding_cache
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.ranking import rank_results

    original_db_dir = settings.db_dir
    original_rerank = settings.embedding_rerank_enabled
    original_provider = settings.embedding_provider
    object.__setattr__(settings, "db_dir", tmp_path)
    object.__setattr__(settings, "embedding_rerank_enabled", True)
    object.__setattr__(settings, "embedding_provider", "")
    embedding_cache._DB_CACHE.clear()
    monkeypatch.delenv("BEDNIIOSINT_EMBEDDING_PROVIDER", raising=False)
    monkeypatch.delenv("EMBEDDING_PROVIDER", raising=False)
    try:
        results = [
            SearchResult(
                id="a",
                source_id="test",
                source_name="Test",
                entity_input="alice",
                entity_type="username",
                matched_entity="alice",
                title="Alice developer profile",
            )
        ]
        ranked = rank_results("alice developer", results)
    finally:
        embedding_cache._DB_CACHE.clear()
        object.__setattr__(settings, "db_dir", original_db_dir)
        object.__setattr__(settings, "embedding_rerank_enabled", original_rerank)
        object.__setattr__(settings, "embedding_provider", original_provider)

    assert ranked[0].normalized_data["semantic_score"] > 0


def test_search_result_fts_indexes_and_searches_results(tmp_path):
    from bedniiosint.search.models import SearchResult
    from bedniiosint.storage.fts import SearchResultFtsIndex

    result = SearchResult(
        id="github:alice",
        source_id="github",
        source_name="GitHub",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice public profile",
        url="https://github.com/alice",
        snippet="Developer profile with repositories",
        confidence_score=0.9,
    )
    index = SearchResultFtsIndex(tmp_path / "case.db")

    keys = index.index_results([result], case_name="demo")
    hits = index.search("github alice repositories", case_name="demo")

    assert keys == ["demo\x1fgithub:alice"]
    assert hits[0].result_id == "github:alice"
    assert hits[0].payload["source_id"] == "github"
    assert hits[0].as_dict()["case_name"] == "demo"


def test_search_pipeline_indexes_results_when_saved(tmp_path, monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.search.models import SearchResult
    from bedniiosint.search.pipeline import _index_saved_search_results
    from bedniiosint.storage.fts import SearchResultFtsIndex

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    result = SearchResult(
        id="github:alice",
        source_id="github",
        source_name="GitHub",
        entity_input="alice",
        entity_type="username",
        matched_entity="alice",
        title="Alice profile",
        url="https://github.com/alice",
    ).as_dict()
    try:
        summary = _index_saved_search_results(case_name="demo", result_dicts=[result])
        hits = SearchResultFtsIndex(settings.db_path("demo")).search("alice github", case_name="demo")
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)

    assert summary["enabled"] is True
    assert summary["indexed"] == 1
    assert hits[0].result_id == "github:alice"


def test_search_index_web_endpoint_reads_saved_fts(tmp_path, monkeypatch):
    from bedniiosint.config import settings
    from bedniiosint.search.models import SearchResult
    from bedniiosint.storage.fts import SearchResultFtsIndex
    from bedniiosint.web.routers import search as search_router

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    SearchResultFtsIndex(settings.db_path("demo")).index_result(
        SearchResult(
            id="github:alice",
            source_id="github",
            source_name="GitHub",
            entity_input="alice",
            entity_type="username",
            matched_entity="alice",
            title="Alice profile",
            url="https://github.com/alice",
        ),
        case_name="demo",
    )
    try:
        payload = search_router.search_index_payload(query="alice github", case="demo", source=None, limit=10)
        html = search_router.search_index_view_html(query="alice", case="demo")
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)

    assert payload["count"] == 1
    assert payload["results"][0]["result_id"] == "github:alice"
    assert "Alice profile" in html


def test_benchmark_script_threshold_failures():
    import argparse

    from bedniiosint.eval.benchmark import BenchmarkReport
    from scripts.run_benchmark import _threshold_failures

    report = BenchmarkReport(
        precision=0.8,
        recall=0.4,
        f1=0.55,
        mrr=0.5,
        per_source={"github": {"precision": 0.25, "retrieved": 4, "hits": 1}},
        source_recall={"github": {"recall": 0.5, "expected": 2, "hits": 1}},
    )
    args = argparse.Namespace(
        min_precision=0.7,
        min_recall=0.5,
        min_f1=None,
        min_mrr=None,
        per_source_min_precision=["github=0.3"],
        source_min_recall=["github=0.7"],
    )

    assert _threshold_failures(report, args) == [
        "recall 0.4000 < 0.5000",
        "github precision 0.2500 < 0.3000",
        "github recall 0.5000 < 0.7000",
    ]


def test_benchmark_script_replay_and_record(tmp_path, monkeypatch):
    from scripts import run_benchmark

    dataset = tmp_path / "ground_truth.json"
    replay = tmp_path / "replay.json"
    record = tmp_path / "record.json"
    dataset.write_text(
        '[{"target":"alice","entity_type":"username","expected":["github:alice"]}]',
        encoding="utf-8",
    )
    replay.write_text(
        '{"username::alice":[{"source_id":"api:github","entity_input":"alice","matched_entity":"alice"}]}',
        encoding="utf-8",
    )

    replay_exit = run_benchmark.main(
        [
            "--dataset",
            str(dataset),
            "--replay",
            str(replay),
            "--min-recall",
            "1.0",
        ]
    )

    monkeypatch.setattr(
        run_benchmark,
        "run_planned_search_pipeline",
        lambda target, **kwargs: {
            "search_results": [
                {
                    "source_id": "api:github",
                    "entity_input": target,
                    "matched_entity": target,
                }
            ]
        },
    )
    record_exit = run_benchmark.main([str(dataset), "--record", str(record)])

    assert replay_exit == 0
    assert record_exit == 0
    assert "username::alice" in record.read_text(encoding="utf-8")


def test_collect_cases_writes_payload(tmp_path):
    from scripts.collect_cases import collect

    def fake_pipeline(target: str, **kwargs):
        return {
            "search_results": [
                {
                    "id": "github:alice",
                    "source_id": "github",
                    "entity_input": target,
                    "matched_entity": target,
                    "url": "https://github.com/alice",
                }
            ]
        }

    written = collect(
        [{"target": "alice", "entity_type": "username"}],
        tmp_path,
        pipeline=fake_pipeline,
        max_results=1,
    )

    payload = __import__("json").loads(written[0].read_text(encoding="utf-8"))
    assert payload["target"] == "alice"
    assert payload["entity_type"] == "username"
    assert payload["search_results"][0]["source_id"] == "github"


def test_make_dataset_scaffold_finalize_and_validate(tmp_path):
    import json

    from scripts import make_dataset

    payload = tmp_path / "payload.json"
    review = tmp_path / "review.json"
    ground_truth = tmp_path / "ground_truth.json"
    pairs = tmp_path / "pairs.json"
    payload.write_text(
        json.dumps(
            {
                "search_results": [
                    {
                        "source_id": "github",
                        "entity_input": "alice",
                        "matched_entity": "alice",
                        "url": "https://github.com/alice",
                        "confidence_score": 0.8,
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    assert make_dataset.main(
        [
            "scaffold-gt",
            str(payload),
            "--target",
            "alice",
            "--entity-type",
            "username",
            "--out",
            str(review),
        ]
    ) == 0
    reviewed = json.loads(review.read_text(encoding="utf-8"))
    reviewed["candidates"][0]["keep"] = True
    review.write_text(json.dumps(reviewed), encoding="utf-8")

    assert make_dataset.main(["finalize-gt", str(review), "--out", str(ground_truth)]) == 0
    assert make_dataset.main(["scaffold-pairs", str(payload), "--out", str(pairs)]) == 0
    pair_rows = json.loads(pairs.read_text(encoding="utf-8"))
    pair_rows[0]["label"] = 1
    pair_rows.append({"confidence": 0.1, "label": 0})
    pairs.write_text(json.dumps(pair_rows), encoding="utf-8")

    assert make_dataset.main(
        ["validate", "--ground-truth", str(ground_truth), "--pairs", str(pairs)]
    ) == 0


def test_train_ranker_writes_weights(tmp_path):
    import json

    from scripts.train_ranker import main, train_pairwise

    rows = [
        {
            "target": "alice",
            "label": 1,
            "signals": {"status_exists": True, "control_passed": True},
        },
        {
            "target": "alice",
            "label": 0,
            "signals": {"status_exists": False, "control_passed": False},
        },
    ]
    weights, method, pairs = train_pairwise(rows, iterations=10)
    path = tmp_path / "rows.json"
    out = tmp_path / "ranker.json"
    path.write_text(json.dumps(rows), encoding="utf-8")

    assert pairs == 1
    assert method == "pairwise_ranknet_normalized_positive_coefficients"
    assert sum(weights.values()) > 0
    assert main(["--rows", str(path), "--out", str(out), "--iterations", "10"]) == 0
    assert "weights" in json.loads(out.read_text(encoding="utf-8"))


def test_benchmark_dataset_validation_and_source_recall():
    from bedniiosint.eval.benchmark import (
        dataset_summary,
        report_markdown,
        run_benchmark,
        validate_dataset,
    )
    from bedniiosint.search.models import SearchResult

    dataset = [
        {
            "target": "alice",
            "entity_type": "username",
            "expected": ["github:alice", "https://github.com/alice"],
        }
    ]

    report = run_benchmark(
        dataset,
        lambda target, entity_type: [
            SearchResult(
                id="github:alice",
                source_id="api:github",
                source_name="GitHub",
                entity_input=target,
                entity_type=entity_type,
                matched_entity=target,
                url="https://github.com/alice",
                confidence_score=0.9,
            )
        ],
    )

    assert validate_dataset(dataset) == []
    assert dataset_summary(dataset)["expected_by_source"] == {"github": 1}
    assert report.source_recall["github"]["recall"] == 1.0
    assert "Source recall" in report_markdown(report)


def test_benchmark_matches_source_qualified_url_targets():
    from bedniiosint.eval.benchmark import dataset_summary, run_benchmark
    from bedniiosint.search.models import SearchResult

    dataset = [
        {
            "target": "https://www.python.org/",
            "entity_type": "url",
            "expected": ["urlscan:https://www.python.org/"],
        }
    ]

    report = run_benchmark(
        dataset,
        lambda target, entity_type: [
            SearchResult(
                id="urlscan:python",
                source_id="api:urlscan",
                source_name="urlscan",
                entity_input=target,
                entity_type=entity_type,
                matched_entity=target,
                confidence_score=0.9,
            )
        ],
    )

    assert dataset_summary(dataset)["expected_by_source"] == {"urlscan": 1}
    assert report.recall == 1.0
    assert report.source_recall["urlscan"]["recall"] == 1.0
