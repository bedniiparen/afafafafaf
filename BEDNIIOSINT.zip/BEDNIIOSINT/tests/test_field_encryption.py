from __future__ import annotations

import base64
import json
from pathlib import Path

import pytest

from bedniiosint.core.field_encryption import (
    ENCRYPTION_PASSPHRASE_ENV,
    ENCRYPTION_SALT_ENV,
    ENVELOPE_PREFIX,
    decrypt_json_field,
    decrypt_json_field_if_needed,
    encrypt_json_field,
    encrypt_json_field_if_configured,
    field_encryption_status,
)
from bedniiosint.core.live_validation_results import (
    live_validation_history,
    record_live_validation_results,
)
from bedniiosint.storage.models import LiveValidationResult
from bedniiosint.storage.sqlite import Storage


def test_field_encryption_round_trip_and_tamper_detection():
    payload = {"token": "secret-value", "nested": {"count": 3}}
    envelope = encrypt_json_field(payload, passphrase="passphrase", deployment_salt="deployment")

    assert envelope.startswith(ENVELOPE_PREFIX)
    assert "secret-value" not in envelope
    assert decrypt_json_field(envelope, passphrase="passphrase", deployment_salt="deployment") == payload

    encoded = envelope[len(ENVELOPE_PREFIX) :]
    data = json.loads(base64.urlsafe_b64decode(encoded.encode("ascii")).decode("utf-8"))
    ciphertext = bytearray(base64.urlsafe_b64decode(data["ciphertext"].encode("ascii")))
    ciphertext[0] ^= 1
    data["ciphertext"] = base64.urlsafe_b64encode(bytes(ciphertext)).decode("ascii")
    tampered = ENVELOPE_PREFIX + base64.urlsafe_b64encode(
        json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).decode("ascii")

    with pytest.raises(ValueError, match="authentication failed"):
        decrypt_json_field(tampered, passphrase="passphrase", deployment_salt="deployment")


def test_field_encryption_is_plain_json_without_passphrase(monkeypatch):
    monkeypatch.delenv(ENCRYPTION_PASSPHRASE_ENV, raising=False)
    monkeypatch.delenv(ENCRYPTION_SALT_ENV, raising=False)

    payload = {"value": "visible"}
    stored = encrypt_json_field_if_configured(payload)

    assert stored == '{"value": "visible"}'
    assert decrypt_json_field_if_needed(stored, {}) == payload
    assert field_encryption_status()["enabled"] is False
    assert field_encryption_status()["secrets_returned"] is False


def test_live_validation_json_fields_encrypt_at_rest_when_configured(monkeypatch, tmp_path: Path):
    monkeypatch.setenv(ENCRYPTION_PASSPHRASE_ENV, "local-passphrase")
    monkeypatch.setenv(ENCRYPTION_SALT_ENV, "deployment-salt")
    storage = Storage(tmp_path / "live.db")
    verification = {
        "mode": "live",
        "results": [
            {
                "source_id": "api:example",
                "name": "Example",
                "target": "example.com",
                "status": "available",
                "reason": "fixture",
                "verification_status": "ok",
                "health_status": "available",
                "checks": [{"name": "reachable", "ok": True}],
                "errors": [],
                "live_health": {"public": "visible"},
            }
        ],
    }

    record_live_validation_results(
        verification,
        run_id="run-1",
        target="example.com",
        allow_opt_in=True,
        network_required=True,
        storage=storage,
    )

    with storage.session() as session:
        row = session.query(LiveValidationResult).all()[0]
        assert row.live_health_json.startswith(ENVELOPE_PREFIX)
        assert "visible" not in row.live_health_json
        assert row.checks_json.startswith(ENVELOPE_PREFIX)

    history = live_validation_history(storage=storage)
    assert history["summary"]["secrets_returned"] is False
    assert history["results"][0]["live_health"] == {"public": "visible"}
    assert history["results"][0]["checks"] == [{"name": "reachable", "ok": True}]
