from pathlib import Path

from bedniiosint.config import settings
from bedniiosint.core.case_workspace import get_finding_detail, get_workspace
from bedniiosint.storage.models import Case, Evidence, Finding, Source
from bedniiosint.storage.sqlite import Storage
from bedniiosint.web.presenters import (
    build_case_presentation,
    build_case_workspace_model,
    build_finding_display,
    classify_finding_cluster,
    classify_result_status,
    extract_platform,
    humanize_matched_markers,
)


def _company_observation(confidence: float = 0.0, rejected: bool = False) -> dict:
    return {
        "id": 1,
        "case_id": 1,
        "source_name": "company-analyzer",
        "source_id": "module:company",
        "source_reliability": 0.7,
        "entity_value": "scally milano",
        "entity_type": "company",
        "finding_type": "observation",
        "profile_url": "https://scallymilano.com",
        "status": "exists",
        "matched_markers": (
            "score:domain_dns:miss:guessed domain has no A/AAAA records,"
            "score:registry_match:miss:no registry matches,"
            "score:domain_registration:miss:no domain registration date"
        ),
        "confidence": confidence,
        "rejected": rejected,
        "reject_reason": "not confirmed" if rejected else "",
        "captured_at": "2026-06-07T12:00:00+00:00",
    }


def test_company_raw_observation_becomes_possible_domain_display():
    display = build_finding_display(
        _company_observation(),
        [{"sha256": "a" * 64, "body_len": 123, "http_status": 200}],
        independent_sources=1,
        target="scally milano",
    )

    assert display["verdict"] == "Weak"
    assert display["display_entity_type"] == "domain"
    assert display["display_entity_value"] == "scallymilano.com"
    assert display["what_found"] == "Possible domain"
    assert "Domain-like match" in display["why_it_matters"]
    assert "No registry match was found." in display["weaknesses"]
    assert "Confidence is 0%" in display["confidence_explanation"][0]
    assert any("/infra/domain" in action for action in display["recommended_actions"])
    assert any("/business/registry" in action for action in display["recommended_actions"])
    assert display["raw_available"] is True


def test_music_platform_candidates_are_grouped_as_music_data():
    display = build_finding_display(
        {
            "id": 2,
            "source_name": "Genius artist candidate",
            "source_id": "dorking:music_profile:genius",
            "entity_type": "url",
            "entity_value": "https://genius.com/artists/scally-milano",
            "finding_type": "dorking_lead",
            "profile_url": "https://genius.com/artists/scally-milano",
            "status": "unknown",
            "confidence": 0.0,
            "matched_markers": "review_only,dorking,manual_verification_required,candidate_url",
        },
        [],
        target="scally milano",
    )

    assert display["data_category"] == "music_platforms"
    assert display["data_category_label"] == "Music platforms"
    assert display["primary_link"] == "https://genius.com/artists/scally-milano"


def test_github_api_user_url_is_rewritten_to_public_profile_link():
    finding = {
        "id": 3,
        "source_name": "GitHub",
        "source_id": "api:github",
        "entity_type": "username",
        "entity_value": "Cote4r",
        "finding_type": "pipeline_adapter_result",
        "profile_url": "https://api.github.com/users/Cote4r",
        "status": "exists",
        "confidence": 0.8,
    }
    display = build_finding_display(finding, [], target="Cote4r")
    model = build_case_workspace_model(
        {
            "findings": [{**finding, "display": display, "primary_link": display["primary_link"]}],
            "evidence": [],
            "attachments": [],
            "sources": [],
            "relations": [],
            "notes": [],
            "timeline": [],
            "counts": {},
            "meta": {"case": "github-case", "target": "Cote4r"},
        }
    )

    row = model["tables"]["profiles"]["rows"][0]

    assert display["primary_link"] == "https://github.com/Cote4r"
    assert row["url"] == "https://github.com/Cote4r"
    assert row["actions"][0]["url"] == "https://github.com/Cote4r"


def test_profile_api_urls_are_rewritten_to_public_profile_links():
    cases = [
        (
            "Hacker News",
            "api:hackernews",
            "https://hacker-news.firebaseio.com/v0/user/alice.json",
            "alice",
            "https://news.ycombinator.com/user?id=alice",
        ),
        (
            "GitLab",
            "api:gitlab",
            "https://gitlab.com/api/v4/users?username=alice",
            "alice",
            "https://gitlab.com/alice",
        ),
        (
            "Codeforces",
            "api:codeforces",
            "https://codeforces.com/api/user.info?handles=alice",
            "alice",
            "https://codeforces.com/profile/alice",
        ),
        (
            "Bluesky",
            "api:bluesky",
            "https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor=alice.bsky.social",
            "alice.bsky.social",
            "https://bsky.app/profile/alice.bsky.social",
        ),
        (
            "Docker Hub",
            "api:dockerhub",
            "https://hub.docker.com/v2/users/alice/",
            "alice",
            "https://hub.docker.com/u/alice",
        ),
        (
            "crates.io",
            "api:cratesio",
            "https://crates.io/api/v1/users/alice",
            "alice",
            "https://crates.io/users/alice",
        ),
        (
            "Lichess",
            "api:lichess",
            "https://lichess.org/api/user/alice",
            "alice",
            "https://lichess.org/@/alice",
        ),
        (
            "Duolingo",
            "api:duolingo",
            "https://www.duolingo.com/2017-06-30/users?username=alice&_=1",
            "alice",
            "https://www.duolingo.com/profile/alice",
        ),
        (
            "Reddit",
            "api:reddit",
            "https://www.reddit.com/user/alice/about.json",
            "alice",
            "https://www.reddit.com/user/alice",
        ),
        (
            "Gravatar",
            "api:gravatar",
            "https://www.gravatar.com/abc123.json",
            "alice",
            "https://www.gravatar.com/abc123",
        ),
    ]

    for source_name, source_id, api_url, entity_value, expected in cases:
        display = build_finding_display(
            {
                "id": 10,
                "source_name": source_name,
                "source_id": source_id,
                "entity_type": "username",
                "entity_value": entity_value,
                "finding_type": "pipeline_adapter_result",
                "profile_url": api_url,
                "status": "exists",
                "confidence": 0.8,
            },
            [],
            target=entity_value,
        )

        assert display["primary_link"] == expected


def test_markers_and_cluster_classification_are_human_readable():
    marker_text = (
        "score:registry_match:miss:no registry matches,"
        "score:domain_dns:0.40,"
        "universal:weak_data:-0.15"
    )
    markers = humanize_matched_markers(marker_text)

    assert "No registry match was found." in markers["weaknesses"]
    assert "Domain DNS signal is present." in markers["positive"]
    assert "Evidence is sparse or weak." in markers["weaknesses"]
    assert classify_finding_cluster({"confidence": 0.0, "display": {"display_entity_type": "company"}}) == "Weak observations"
    assert classify_finding_cluster({"confidence": 0.8}) == "Confirmed matches"
    assert classify_finding_cluster({"confidence": 0.5}) == "Likely matches"
    assert classify_finding_cluster({"confidence": 0.2, "rejected": True}) == "Rejected / false positives"


def test_case_presentation_builds_summary_clusters_and_next_actions():
    finding = _company_observation()
    presentation = build_case_presentation(
        {
            "case": "company-scally-milano",
            "target": "scally milano",
            "module": "company",
            "entity_type": "company",
            "last_updated": "2026-06-07T12:00:00+00:00",
            "runs": [
                {"target": "scally milano", "module": "company"},
                {"target": "scallymilano.com", "module": "domain_pipeline"},
            ],
            "findings": [finding],
            "entities": [
                {"type": "company", "value": "scally milano"},
                {"type": "domain", "value": "scallymilano.com"},
            ],
            "relations": [],
            "sources": [{"name": "company-analyzer", "success_count": 1, "error_count": 0}],
            "evidence": [{"finding_id": 1, "sha256": "a" * 64}],
            "attachments": [],
            "evidence_by_finding": {1: [{"finding_id": 1, "sha256": "a" * 64}]},
            "attachments_by_finding": {},
        }
    )

    summary = presentation["summary"]
    assert summary["target"] == "scally milano"
    assert summary["run_segments"] == 2
    assert "same case name" in summary["case_lineage_warning"]
    assert summary["overall_confidence"]["label"] == "None / 0%"
    assert summary["case_status"] == "Needs review"
    assert "Possible domain: scallymilano.com." in summary["what_found"]
    assert summary["clusters"]["categories"]["Weak observations"]
    assert presentation["findings"][0]["what_found"] == "Possible domain"
    assert presentation["confidence_breakdown"]["negative"]
    assert presentation["unconfirmed_hypotheses"]


def test_workspace_api_payload_includes_presentation_layer(tmp_path: Path):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("presented"))
        with storage.session() as session:
            case = Case(name="presented", target="scally milano", module="company")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(
                Source(
                    case_id=case.id,
                    name="company-analyzer",
                    source_id="module:company",
                    url_main="https://scallymilano.com",
                    category="company",
                    reliability=0.7,
                    success_count=1,
                )
            )
            finding = Finding(**_company_observation())
            finding.id = None
            finding.case_id = case.id
            session.add(finding)
            session.commit()
            session.refresh(finding)
            session.add(
                Evidence(
                    case_id=case.id,
                    finding_id=finding.id,
                    url="https://scallymilano.com",
                    final_url="https://scallymilano.com",
                    http_status=200,
                    sha256="b" * 64,
                    body_len=55,
                    source_module="company",
                )
            )
            session.commit()
            finding_id = finding.id

        workspace = get_workspace("presented")
        detail = get_finding_detail("presented", finding_id)

        assert workspace["presentation"]["summary"]["case_status"] == "Needs review"
        assert workspace["presentation"]["clusters"]["categories"]["Weak observations"]
        assert workspace["findings"][0]["display"]["what_found"] == "Possible domain"
        assert detail["finding"]["display"]["confidence"]["label"] == "None / 0%"
        assert detail["finding"]["display"]["evidence_chain"]["sha256"] == "b" * 64
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_username_workspace_separates_profiles_from_search_leads_and_raw_graph(tmp_path: Path):
    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("username_search-bedniiparen"))
        with storage.session() as session:
            case = Case(
                name="username_search-bedniiparen",
                target="bedniiparen",
                module="search_dorking",
            )
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(
                Source(
                    case_id=case.id,
                    name="Google Dork",
                    source_id="dorking:google",
                    url_main="https://www.google.com/search?q=bedniiparen",
                    category="search_dorking",
                    reliability=0.25,
                    success_count=1,
                )
            )
            session.add(
                Source(
                    case_id=case.id,
                    name="GitHub Profile Candidate",
                    source_id="dorking:profile:github",
                    url_main="https://github.com/bedniiparen",
                    category="search_dorking",
                    reliability=0.25,
                    success_count=1,
                )
            )
            session.add(
                Source(
                    case_id=case.id,
                    name="GitLab API",
                    source_id="api:gitlab",
                    url_main="https://gitlab.com/bedniiparen",
                    category="username_pipeline",
                    reliability=0.8,
                    success_count=1,
                )
            )
            session.add(
                Finding(
                    case_id=case.id,
                    source_name="Google Dork",
                    source_id="dorking:google",
                    source_reliability=0.25,
                    entity_type="url",
                    entity_value="https://www.google.com/search?q=bedniiparen",
                    finding_type="dorking_lead",
                    profile_url="https://www.google.com/search?q=bedniiparen",
                    status="unknown",
                    confidence=0.0,
                    matched_markers="review_only,dorking,manual_verification_required,no_confirmation_signals",
                )
            )
            session.add(
                Finding(
                    case_id=case.id,
                    source_name="GitHub Profile Candidate",
                    source_id="dorking:profile:github",
                    source_reliability=0.25,
                    entity_type="url",
                    entity_value="https://github.com/bedniiparen",
                    finding_type="dorking_lead",
                    profile_url="https://github.com/bedniiparen",
                    status="unknown",
                    confidence=0.0,
                    matched_markers="review_only,dorking,manual_verification_required,no_confirmation_signals",
                )
            )
            session.add(
                Finding(
                    case_id=case.id,
                    source_name="GitLab API",
                    source_id="api:gitlab",
                    source_reliability=0.8,
                    entity_type="username",
                    entity_value="bedniiparen",
                    finding_type="username_profile",
                    profile_url="https://gitlab.com/bedniiparen",
                    status="exists",
                    confidence=0.8,
                    rejected=True,
                    reject_reason="no profile record",
                )
            )
            session.commit()

        workspace = get_workspace("username_search-bedniiparen")
        summary = workspace["presentation"]["summary"]
        clusters = workspace["presentation"]["clusters"]["categories"]

        assert summary["entity_type"] == "username"
        assert summary["findings_count"] == 1
        assert summary["profile_candidates"] == 1
        assert summary["review_only_search_leads"] == 1
        assert summary["rejected_findings"] == 1
        assert workspace["findings"][0]["display"]["what_found"] == "Profile URL candidate"
        assert workspace["generated_url_candidates"] == []
        assert "google.com/search" not in str(workspace["findings"])
        assert "github.com/bedniiparen" in str(workspace["findings"])
        assert "google.com/search" in str(workspace["review_only_search_leads"])
        assert clusters["Profile URL candidates"]
        assert clusters["Review-only search leads"]
        assert workspace["graph"]["metrics"] == {"nodes": 2, "edges": 1}
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def _workspace_model_fixture() -> dict:
    findings = [
        {
            "id": 10,
            "source_name": "Instagram profile candidate",
            "source_id": "dorking:profile:instagram",
            "source_reliability": 0.25,
            "entity_type": "url",
            "entity_value": "https://instagram.com/scallymilano",
            "finding_type": "dorking_lead",
            "profile_url": "https://instagram.com/scallymilano",
            "status": "unknown",
            "confidence": 0.0,
            "matched_markers": "review_only,dorking,manual_verification_required,candidate_url",
            "captured_at": "2026-06-07T10:00:00+00:00",
        },
        {
            "id": 11,
            "source_name": "VK API",
            "source_id": "api:vk",
            "source_reliability": 0.9,
            "entity_type": "username",
            "entity_value": "scallymilano",
            "finding_type": "username_profile",
            "profile_url": "https://vk.com/scallymilano",
            "status": "exists",
            "confidence": 0.88,
            "matched_markers": "status_exists,username_in_final_url",
            "captured_at": "2026-06-07T10:05:00+00:00",
        },
        {
            "id": 15,
            "source_name": "Instagram indexed lead",
            "source_id": "dorking:social:instagram",
            "source_reliability": 0.25,
            "entity_type": "url",
            "entity_value": "https://instagram.com/scallymilano",
            "finding_type": "dorking_lead",
            "profile_url": "https://instagram.com/scallymilano",
            "status": "unknown",
            "confidence": 0.0,
            "matched_markers": "review_only,dorking,manual_verification_required",
            "captured_at": "2026-06-07T10:05:10+00:00",
        },
        {
            "id": 12,
            "source_name": "Google Dork",
            "source_id": "dorking:google",
            "source_reliability": 0.25,
            "entity_type": "url",
            "entity_value": "https://www.google.com/search?q=scally+milano",
            "finding_type": "dorking_lead",
            "profile_url": "https://www.google.com/search?q=scally+milano",
            "status": "unknown",
            "confidence": 0.0,
            "matched_markers": "review_only,dorking,manual_verification_required",
            "captured_at": "2026-06-07T10:06:00+00:00",
        },
        {
            "id": 13,
            "source_name": "Domain source",
            "source_id": "api:domain",
            "source_reliability": 0.75,
            "entity_type": "domain",
            "entity_value": "scallymilano.com",
            "finding_type": "domain_record",
            "profile_url": "https://scallymilano.com",
            "status": "exists",
            "confidence": 0.7,
            "matched_markers": "status_exists",
            "captured_at": "2026-06-07T10:07:00+00:00",
        },
        {
            "id": 14,
            "source_name": "Email source",
            "source_id": "api:email",
            "source_reliability": 0.75,
            "entity_type": "email",
            "entity_value": "hello@scallymilano.com",
            "finding_type": "email",
            "profile_url": "",
            "status": "exists",
            "confidence": 0.65,
            "matched_markers": "status_exists",
            "captured_at": "2026-06-07T10:08:00+00:00",
        },
    ]
    presentation = build_case_presentation(
        {
            "case": "music-scally-milano",
            "target": "scally milano",
            "module": "search_dorking",
            "entity_type": "username",
            "last_updated": "2026-06-07T10:10:00+00:00",
            "runs": [{"target": "scally milano /music", "module": "search_dorking"}],
            "findings": findings,
            "entities": [],
            "relations": [],
            "sources": [
                {"name": "OkSource", "source_id": "api:ok", "success_count": 1, "health_status": "available"},
                {"name": "Instagram profile candidate", "source_id": "dorking:profile:instagram", "url_main": "https://instagram.com/scallymilano", "success_count": 1, "health_status": "unknown"},
                {"name": "TimeoutSource", "source_id": "api:timeout", "error_count": 1, "health_status": "error", "last_error": "request timeout"},
                {"name": "ErrorSource", "source_id": "api:error", "error_count": 1, "health_status": "error", "last_error": "HTTP 503"},
                {"name": "MissingKeySource", "source_id": "api:missing", "health_status": "missing_keys"},
            ],
            "evidence": [
                {
                    "id": 1,
                    "finding_id": 11,
                    "url": "https://vk.com/scallymilano",
                    "http_status": 200,
                    "sha256": "c" * 64,
                    "source_module": "vk",
                    "captured_at": "2026-06-07T10:05:30+00:00",
                },
                {
                    "id": 2,
                    "finding_id": 15,
                    "url": "https://instagram.com/scallymilano",
                    "http_status": 200,
                    "sha256": "d" * 64,
                    "source_module": "dorking",
                    "captured_at": "2026-06-07T10:05:40+00:00",
                }
            ],
            "attachments": [],
            "evidence_by_finding": {
                11: [{"finding_id": 11, "url": "https://vk.com/scallymilano", "sha256": "c" * 64, "captured_at": "2026-06-07T10:05:30+00:00"}],
                15: [{"finding_id": 15, "url": "https://instagram.com/scallymilano", "sha256": "d" * 64, "captured_at": "2026-06-07T10:05:40+00:00"}],
            },
            "attachments_by_finding": {},
        }
    )
    return build_case_workspace_model(
        {
            "case": "music-scally-milano",
            "target": "scally milano",
            "meta": {"case": "music-scally-milano", "target": "scally milano"},
            "counts": {},
            "findings": presentation["findings"],
            "review_only_search_leads": presentation["review_only_search_leads"],
            "rejected_findings": presentation["rejected_findings"],
            "presentation": presentation,
            "sources": [
                {"name": "OkSource", "source_id": "api:ok", "success_count": 1, "health_status": "available"},
                {"name": "Instagram profile candidate", "source_id": "dorking:profile:instagram", "url_main": "https://instagram.com/scallymilano", "success_count": 1, "health_status": "unknown"},
                {"name": "TimeoutSource", "source_id": "api:timeout", "error_count": 1, "health_status": "error", "last_error": "request timeout"},
                {"name": "ErrorSource", "source_id": "api:error", "error_count": 1, "health_status": "error", "last_error": "HTTP 503"},
                {"name": "MissingKeySource", "source_id": "api:missing", "health_status": "missing_keys"},
            ],
            "evidence": [
                {
                    "id": 1,
                    "finding_id": 11,
                    "url": "https://vk.com/scallymilano",
                    "http_status": 200,
                    "sha256": "c" * 64,
                    "source_module": "vk",
                    "captured_at": "2026-06-07T10:05:30+00:00",
                },
                {
                    "id": 2,
                    "finding_id": 15,
                    "url": "https://instagram.com/scallymilano",
                    "http_status": 200,
                    "sha256": "d" * 64,
                    "source_module": "dorking",
                    "captured_at": "2026-06-07T10:05:40+00:00",
                }
            ],
            "attachments": [],
            "evidence_by_finding": {
                11: [{"finding_id": 11, "url": "https://vk.com/scallymilano", "sha256": "c" * 64, "captured_at": "2026-06-07T10:05:30+00:00"}],
                15: [{"finding_id": 15, "url": "https://instagram.com/scallymilano", "sha256": "d" * 64, "captured_at": "2026-06-07T10:05:40+00:00"}],
            },
            "attachments_by_finding": {},
            "relations": [],
            "graph": {"metrics": {"nodes": 0, "edges": 0}, "nodes": [], "edges": []},
            "manifest": {},
            "integrity": {},
        }
    )


def test_workspace_model_profiles_statuses_filters_and_counts():
    model = _workspace_model_fixture()
    profiles = model["tables"]["profiles"]
    profile_rows = profiles["rows"]
    candidate = next(row for row in profile_rows if row["platform"] == "Instagram")
    found = next(row for row in profile_rows if row["platform"] == "VK")

    assert candidate["status"] == "candidate"
    assert candidate["result_label"] == "Candidate profile URL"
    assert "found profile" not in candidate["result_label"].lower()
    assert found["status"] == "found"
    assert profile_rows[0]["platform"] == "VK"
    assert {"platform", "status", "confidence", "signals", "actions"}.issubset(found)
    assert found["confidence"]["reasons"]
    assert "actions" not in {column["key"] for column in profiles["columns"]}
    assert {"status", "platform", "candidate_status", "site_category", "confidence_band", "source"}.issubset(profiles["filters"])
    assert model["overview"]["counts"]["profiles"] == 2
    assert model["overview"]["counts"]["emails"] == 1
    assert model["overview"]["counts"]["domains"] == 1
    assert model["overview"]["counts"]["sources"] == 5
    assert model["overview"]["counts"]["evidence"] == 2


def test_workspace_model_keeps_search_dorks_and_empty_api_out_of_primary_links(tmp_path: Path):
    empty_api_artifact = tmp_path / "peeringdb-empty.json"
    empty_api_artifact.write_text(
        '{"raw":{"data":{"data":[],"meta":{}}},"url":"https://www.peeringdb.com/api/net?name__contains=scally%20milano"}',
        encoding="utf-8",
    )
    findings = [
        {
            "id": 21,
            "source_name": "Dork: Bluesky",
            "source_id": "dorking:music_search:bsky",
            "source_reliability": 0.25,
            "entity_type": "url",
            "entity_value": "https://www.google.com/search?q=site%3Absky.app%2Fprofile+%22scally+milano%22",
            "finding_type": "dorking_lead",
            "profile_url": "https://www.google.com/search?q=site%3Absky.app%2Fprofile+%22scally+milano%22",
            "status": "unknown",
            "confidence": 0.0,
            "page_title": 'Google dork: site:bsky.app/profile "scally milano"',
            "matched_markers": "review_only,dorking,manual_verification_required,no_confirmation_signals",
            "captured_at": "2026-06-07T10:00:00+00:00",
        },
        {
            "id": 22,
            "source_name": "api:peeringdb",
            "source_id": "api:peeringdb",
            "source_reliability": 0.75,
            "entity_type": "company",
            "entity_value": "scally milano",
            "finding_type": "pipeline_adapter_result",
            "profile_url": "https://www.peeringdb.com/api/net?name__contains=scally%20milano",
            "status": "exists",
            "status_code": 200,
            "confidence": 0.75,
            "page_title": "adapter=api:peeringdb status=exists",
            "matched_markers": "pipeline:normalized",
            "captured_at": "2026-06-07T10:01:00+00:00",
        },
    ]
    evidence = [
        {
            "id": 31,
            "finding_id": 22,
            "url": "https://www.peeringdb.com/api/net?name__contains=scally%20milano",
            "http_status": 200,
            "sha256": "e" * 64,
            "body_len": 24,
            "source_module": "api:peeringdb",
            "artifact_path": str(empty_api_artifact),
            "captured_at": "2026-06-07T10:01:10+00:00",
        }
    ]
    base = {
        "case": "music-scally-empty-api",
        "target": "scally milano",
        "module": "search_dorking",
        "entity_type": "username",
        "findings": findings,
        "sources": [],
        "evidence": evidence,
        "attachments": [],
        "evidence_by_finding": {22: evidence},
        "attachments_by_finding": {},
    }
    presentation = build_case_presentation(base)
    model = build_case_workspace_model(
        {
            **base,
            "meta": {"case": "music-scally-empty-api", "target": "scally milano"},
            "counts": {},
            "findings": presentation["findings"],
            "review_only_search_leads": presentation["review_only_search_leads"],
            "rejected_findings": presentation["rejected_findings"],
            "presentation": presentation,
            "relations": [],
            "graph": {"metrics": {"nodes": 0, "edges": 0}, "nodes": [], "edges": []},
            "manifest": {},
            "integrity": {},
        }
    )

    assert "google.com/search" not in str(model["tables"]["profiles"]["rows"])
    search_lead = next(row for row in model["tables"]["mentions"]["rows"] if row["source"] == "Dork: Bluesky")
    assert search_lead["url"] == ""
    assert all(action.get("type") != "open" for action in search_lead["actions"])
    api_row = next(row for row in model["tables"]["mentions"]["rows"] if row["source"] == "api:peeringdb")
    assert api_row["status"] == "unavailable"
    assert api_row["confidence"]["percent"] == 0
    assert api_row["confidence"]["reasons"] == ["Source API returned an empty response - nothing to confirm."]
    assert api_row["url"] == ""
    assert api_row["empty_api_response"] is True
    assert all(action.get("type") != "open" for action in api_row["actions"])


def test_workspace_model_evidence_sources_exports_raw_and_labels():
    model = _workspace_model_fixture()
    evidence_row = model["tables"]["evidence"]["rows"][0]
    source_statuses = {row["status"] for row in model["tables"]["sources"]["rows"]}
    export_keys = {row["key"] for row in model["exports"]["items"]}

    assert {"hash", "timestamp", "url"}.issubset(evidence_row)
    for key in ("profiles", "emails", "phones", "domains", "mentions", "sources", "evidence"):
        assert "actions" not in {column["key"] for column in model["tables"][key]["columns"]}
    assert {"candidate", "timeout", "error", "missing_key"}.issubset(source_statuses)
    generated_source = next(row for row in model["tables"]["sources"]["rows"] if row["source_id"] == "dorking:profile:instagram")
    assert all(action.get("type") != "open" for action in generated_source["actions"])
    assert {"current_table_csv", "current_table_json", "evidence_bundle"}.issubset(export_keys)
    assert "raw" in model["tabs"]
    assert "raw" not in model["tables"]
    assert "proof" not in str(model["tables"]["evidence"]).lower()
    assert extract_platform("https://music.yandex.ru/artist/123") == "Yandex Music"
    assert classify_result_status({"source_id": "dorking:profile:youtube", "profile_url": "https://youtube.com/@scallymilano", "status": "unknown"}) == "candidate"


def test_unavailable_profile_text_is_not_actionable_profile_link():
    presentation = build_case_presentation(
        {
            "case": "dead-profile",
            "target": "scally milano",
            "module": "search_dorking",
            "entity_type": "username",
            "findings": [
                {
                    "id": 77,
                    "source_name": "VK indexed lead",
                    "source_id": "dorking:social:vk",
                    "entity_type": "url",
                    "entity_value": "https://vk.com/deadprofile",
                    "finding_type": "dorking_lead",
                    "profile_url": "https://vk.com/deadprofile",
                    "status": "unknown",
                    "confidence": 0.0,
                    "page_title": "Ресурс (Profile) недоступен",
                    "confidence_reason": "Возможно, ссылка недействительна или профиль удалён.",
                    "matched_markers": "review_only,dorking,manual_verification_required",
                }
            ],
            "sources": [],
            "evidence": [],
            "attachments": [],
            "evidence_by_finding": {},
            "attachments_by_finding": {},
        }
    )
    model = build_case_workspace_model(
        {
            "case": "dead-profile",
            "target": "scally milano",
            "meta": {"case": "dead-profile", "target": "scally milano"},
            "counts": {},
            "findings": presentation["findings"],
            "review_only_search_leads": presentation["review_only_search_leads"],
            "rejected_findings": presentation["rejected_findings"],
            "presentation": presentation,
            "sources": [],
            "evidence": [],
            "attachments": [],
            "evidence_by_finding": {},
            "attachments_by_finding": {},
            "relations": [],
            "graph": {"metrics": {"nodes": 0, "edges": 0}, "nodes": [], "edges": []},
            "manifest": {},
            "integrity": {},
        }
    )
    row = model["tables"]["profiles"]["rows"][0]

    assert row["status"] == "unavailable"
    assert all(action.get("type") != "open" for action in row["actions"])
