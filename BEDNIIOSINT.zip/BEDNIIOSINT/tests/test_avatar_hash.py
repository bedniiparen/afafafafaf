from bedniiosint.search.avatar_hash import (
    avatar_correlations,
    hamming_distance,
    hashes_match,
)


def test_hamming_distance_basics():
    assert hamming_distance("00", "00") == 0
    assert hamming_distance("00", "01") == 1
    assert hamming_distance(None, "ff") == 64


def test_hashes_match_threshold():
    assert hashes_match("ffff", "ffff", max_distance=0)
    assert not hashes_match("0000", "ffff", max_distance=4)


def _members(link):
    if isinstance(link, dict):
        return set(link["member_ids"])
    return set(getattr(link, "member_ids"))


def test_avatar_correlations_links_identical_hash_across_sources():
    results = [
        {"id": "r1", "source_id": "api:github", "normalized_data": {"avatar_phash": "ffaa0011"}},
        {"id": "r2", "source_id": "api:gitlab", "normalized_data": {"avatar_phash": "ffaa0011"}},
    ]
    links = avatar_correlations(results, max_distance=2, min_sources=2)
    assert len(links) == 1
    assert _members(links[0]) == {"r1", "r2"}


def test_avatar_correlations_ignores_single_source():
    results = [
        {"id": "r1", "source_id": "api:github", "normalized_data": {"avatar_phash": "ffaa0011"}},
        {"id": "r2", "source_id": "api:github", "normalized_data": {"avatar_phash": "ffaa0011"}},
    ]
    assert avatar_correlations(results, max_distance=2, min_sources=2) == []
