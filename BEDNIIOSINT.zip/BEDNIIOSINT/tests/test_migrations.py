import sqlite3

from bedniiosint.storage.migrations import LATEST_SCHEMA_VERSION, migration_status
from bedniiosint.storage.sqlite import Storage


def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {row["name"] for row in conn.execute(f'PRAGMA table_info("{table}")')}


def _indexes(conn: sqlite3.Connection) -> set[str]:
    return {
        row["name"]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'index'"
        )
    }


def test_storage_runs_versioned_migrations_for_fresh_db(tmp_path):
    path = tmp_path / "fresh.db"

    Storage(path)

    with sqlite3.connect(path) as conn:
        conn.row_factory = sqlite3.Row
        status = migration_status(conn)
        tables = {
            row["name"]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            )
        }
        indexes = _indexes(conn)

    assert status["current_version"] == LATEST_SCHEMA_VERSION
    assert status["latest_version"] == LATEST_SCHEMA_VERSION
    assert status["pending"] == []
    assert {row["version"] for row in status["applied"]} == {1, 2, 3, 4, 5, 6, 7, 8}
    assert {
        "case",
        "finding",
        "evidence",
        "relation",
        "timelineevent",
        "analystnote",
        "scanjob",
        "scanjobevent",
        "livevalidationresult",
        "livevalidationauditevent",
        "schemamigration",
    }.issubset(tables)
    assert {
        "idx_case_name",
        "idx_scanjob_status",
        "idx_note_case_entity",
        "idx_livevalidation_source",
        "idx_livevalidation_run",
        "idx_livevalidationaudit_action",
        "idx_livevalidationaudit_run",
    }.issubset(indexes)


def test_storage_migrates_legacy_schema_with_existing_history(tmp_path):
    path = tmp_path / "legacy.db"
    with sqlite3.connect(path) as conn:
        conn.execute(
            'CREATE TABLE "case" ('
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "name TEXT, target TEXT, module TEXT, created_at TEXT)"
        )
        conn.execute(
            'CREATE TABLE "schemamigration" ('
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "version INTEGER, name TEXT, applied_at TEXT)"
        )
        conn.execute(
            'INSERT INTO "schemamigration" (version, name, applied_at) '
            'VALUES (3, "legacy auto alter", "2024-01-01T00:00:00+00:00")'
        )

    Storage(path)

    with sqlite3.connect(path) as conn:
        conn.row_factory = sqlite3.Row
        status = migration_status(conn)
        finding_columns = _columns(conn, "finding")
        evidence_columns = _columns(conn, "evidence")
        relation_columns = _columns(conn, "relation")
        scan_job_columns = _columns(conn, "scanjob")
        scan_job_event_columns = _columns(conn, "scanjobevent")
        live_columns = _columns(conn, "livevalidationresult")
        live_audit_columns = _columns(conn, "livevalidationauditevent")
        note_columns = _columns(conn, "analystnote")
        indexes = _indexes(conn)

    assert status["current_version"] == LATEST_SCHEMA_VERSION
    assert status["pending"] == []
    assert {row["version"] for row in status["applied"]} == {1, 2, 3, 4, 5, 6, 7, 8}
    assert "legacy auto alter" in {row["name"] for row in status["applied"]}
    assert {"source_id", "source_reliability", "recheck_at"}.issubset(
        finding_columns
    )
    assert {
        "headers_json",
        "query_params_json",
        "adapter_version",
        "artifact_path",
    }.issubset(evidence_columns)
    assert {"src_type", "src_value", "rel", "dst_type", "dst_value"}.issubset(
        relation_columns
    )
    assert {"entity_type", "entity_value", "note", "created_at"}.issubset(
        note_columns
    )
    assert {
        "max_retries",
        "rate_limit_budget_json",
        "resume",
        "claimed_by",
        "claimed_at",
        "heartbeat_at",
    }.issubset(scan_job_columns)
    assert {"attempt", "budget_remaining"}.issubset(scan_job_event_columns)
    assert {"source_id", "run_id", "live_health_json", "redacted"}.issubset(live_columns)
    assert {
        "action",
        "filters_json",
        "matched",
        "affected",
        "output_sha256",
        "output_bytes",
        "manifest_path",
        "created_at",
    }.issubset(live_audit_columns)
    assert {
        "idx_finding_case_source_id",
        "idx_scanjobevent_job",
        "idx_livevalidation_source",
        "idx_livevalidationaudit_action",
    }.issubset(indexes)
