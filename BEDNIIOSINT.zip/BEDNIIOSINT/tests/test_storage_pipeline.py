import json
import shutil
import subprocess
import warnings
from pathlib import Path

from bedniiosint.core.case_summary import build_case_summary
from bedniiosint.core.case import UsernameCase
from bedniiosint.core.case_admin import archive_case, import_case_archive, merge_cases, schema_status
from bedniiosint.core.case_email import EmailCase
from bedniiosint.core.case_extra import IPCase
from bedniiosint.core.artifacts import capture_html_result, capture_raw_result
from bedniiosint.core.case_workspace import (
    WorkspaceFilters,
    add_manual_event,
    add_manual_relation,
    add_note,
    delete_manual_relation,
    dedupe_case,
    get_finding_detail,
    get_workspace,
    merge_entities,
    split_entity,
    update_manual_relation,
)
from bedniiosint.core.plugins import all_plugin_manifests, all_plugins, discover_plugin_manifests, get
from bedniiosint.core.recheck import recheck_finding
from bedniiosint.core.source_record import record_source
from bedniiosint.core.timeline import add_event, get_timeline
from bedniiosint.core.media_verification import (
    build_media_verification_workflow,
    write_media_verification_markdown,
)
from bedniiosint.evidence.manifest import evidence_manifest
from bedniiosint.graph.builder import build_graph, graph_metrics
from bedniiosint.graph.export import to_cytoscape, to_gexf, to_graphml
from bedniiosint.reports.csv import write_case_csv
from bedniiosint.reports.case_html import write_case_html
from bedniiosint.reports.markdown import write_case_markdown
from bedniiosint.reports.cti_sync import (
    delete_opencti_stix_core_object,
    delete_misp_event,
    preflight_misp,
    preflight_opencti,
    patch_opencti_object_fields,
    read_opencti_stix_core_object,
    read_misp_event,
    sync_misp,
    sync_opencti,
)
from bedniiosint.reports.misp import case_summary_to_misp_event, write_misp_event
from bedniiosint.reports.opencti import case_summary_to_opencti_envelope, write_opencti_envelope
from bedniiosint.reports.stix import (
    case_summary_to_stix,
    case_summary_to_taxii_envelope,
    stix_bundle_to_case_summary,
)
from bedniiosint.modules.url.profile_parser import ProfileData
from bedniiosint.modules.username.scanner import SiteResult
from bedniiosint.modules.domain.passive_tools import run_passive_tools
from bedniiosint.storage.models import Attachment, Case, Entity, Evidence, Finding, Relation, Source, TimelineEvent
from bedniiosint.storage.sqlite import Storage


def test_storage_graph_timeline_pipeline(tmp_path: Path):
    storage = Storage(tmp_path / "case.db")
    with storage.session() as session:
        case = Case(name="pipe", target="bob", module="test")
        session.add(case)
        session.commit()
        session.refresh(case)
        session.add(Entity(case_id=case.id, type="username", value="bob"))
        session.add(Entity(case_id=case.id, type="profile", value="https://x/bob"))
        session.add(
            Relation(
                case_id=case.id,
                src_type="username",
                src_value="bob",
                rel="same_username",
                dst_type="profile",
                dst_value="https://x/bob",
            )
        )
        finding = Finding(
            case_id=case.id,
            source_name="Test API",
            source_id="api:test",
            entity_type="username",
            entity_value="bob",
            finding_type="profile",
            profile_url="https://x/bob",
            status="exists",
            confidence=0.9,
        )
        session.add(finding)
        session.commit()
        session.refresh(finding)
        session.add(
            Evidence(
                case_id=case.id,
                finding_id=finding.id,
                url="https://api.example.test/bob",
                final_url="https://api.example.test/bob",
                sha256="a" * 64,
                body_len=10,
                source_module="test",
                artifact_path="vault/example.json",
            )
        )
        session.commit()
        case_id = case.id

    add_event(
        storage,
        case_id,
        kind="first_seen",
        entity_type="profile",
        entity_value="https://x/bob",
        source="test",
        description="Profile discovered",
    )

    graph = build_graph(storage, case_id)
    metrics = graph_metrics(graph)
    edge = list(graph.edges(data=True))[0][2]
    cytoscape = to_cytoscape(graph)
    graphml = to_graphml(graph)
    gexf = to_gexf(graph)
    timeline = get_timeline(storage, case_id)

    assert metrics["nodes"] == 2
    assert metrics["edges"] == 1
    assert metrics["average_weight"] >= 0.75
    assert metrics["strong_edges"] == 1
    assert edge["provenance"]["source_ids"] == ["api:test"]
    assert edge["provenance"]["evidence_count"] == 1
    assert edge["evidence_count"] == 1
    assert edge["provenance"]["evidence_refs"][0]["sha256"] == "a" * 64
    assert edge["provenance"]["evidence_refs"][0]["artifact_path"] == "vault/example.json"
    assert edge["confidence"] == 0.9
    assert cytoscape["elements"]["edges"][0]["data"]["provenance"]["source_ids"] == ["api:test"]
    assert cytoscape["elements"]["edges"][0]["data"]["evidence_refs"][0]["sha256"] == "a" * 64
    assert '<data key="weight">' in graphml
    assert 'weight="' in gexf
    assert timeline[0]["kind"] == "first_seen"


def test_plugin_registry_has_expected_modules():
    names = {plugin.name for plugin in all_plugins()}
    assert {
        "username",
        "email",
        "domain",
        "metadata",
        "ip",
        "phone",
        "url",
        "wallet",
        "company",
    }.issubset(names)
    assert get("email").consumes == ["email"]


def test_v08_local_plugin_manifest_discovery(tmp_path: Path):
    plugin_dir = tmp_path / "plugins" / "demo"
    plugin_dir.mkdir(parents=True)
    (plugin_dir / "plugin.json").write_text(
        """{
  "name": "demo",
  "version": "0.1.0",
  "description": "Demo local plugin.",
  "consumes": ["domain"],
  "produces": ["profile"],
  "entrypoint": "adapter:run",
  "auth": "api_key",
  "env_vars": ["DEMO_API_KEY"]
}""",
        encoding="utf-8",
    )

    local = discover_plugin_manifests(tmp_path / "plugins")
    all_manifests = all_plugin_manifests(tmp_path / "plugins")

    assert local[0].name == "demo"
    assert local[0].env_vars == ["DEMO_API_KEY"]
    assert "username" in {manifest.name for manifest in all_manifests}
    assert "demo" in {manifest.name for manifest in all_manifests}


def test_unified_case_report_and_dashboard_import(tmp_path: Path):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("unified"))
        with storage.session() as session:
            case = Case(name="unified", target="bob", module="test")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(Entity(case_id=case.id, type="username", value="bob"))
            session.add(
                Source(
                    case_id=case.id,
                    name="DemoSource",
                    source_id="demo",
                    url_main="https://example.test",
                    category="profile",
                    adapter="catalog-http",
                    success_count=1,
                    error_count=0,
                    health_status="available",
                    notes="checked source",
                )
            )
            session.add(
                Source(
                    case_id=case.id,
                    name="MissingKeySource",
                    source_id="api:missing",
                    url_main="https://missing.example.test",
                    category="profile",
                    adapter="catalog-http",
                    success_count=0,
                    error_count=0,
                    health_status="missing_keys",
                    notes="required API keys missing",
                )
            )
            session.add(
                Finding(
                    case_id=case.id,
                    source_name="DemoSource",
                    source_id="demo",
                    entity_type="username",
                    entity_value="bob",
                    status="exists",
                    profile_url="https://example.test/bob",
                    matched_markers="username, profile page",
                    confidence=0.82,
                    confidence_reason="direct profile marker",
                )
            )
            session.add(
                Finding(
                    case_id=case.id,
                    source_name="MissingKeySource",
                    source_id="api:missing",
                    entity_type="username",
                    entity_value="bob",
                    status="missing_keys",
                    confidence=0.0,
                    rejected=True,
                    reject_reason="required API keys missing",
                )
            )
            session.commit()

        summary = build_case_summary("unified")
        out = write_case_html(summary, tmp_path / "unified.html")
        markdown = write_case_markdown(summary, tmp_path / "unified.md")
        opencti_path = write_opencti_envelope(summary, tmp_path / "unified-opencti.json")
        misp_path = write_misp_event(summary, tmp_path / "unified-misp.json")
        csv_paths = write_case_csv(summary, tmp_path, "unified")

        import bedniiosint.web.app as web_app

        assert summary["meta"]["found"]
        assert summary["entities"][0]["value"] == "bob"
        assert summary["source_coverage"]["summary"]["recorded_sources"] == 2
        assert summary["source_coverage"]["summary"]["checked"] == 1
        assert summary["source_coverage"]["summary"]["missing_keys"] == 1
        assert summary["source_health_history"]["summary"]["sources"] == 2
        assert summary["source_health_history"]["summary"]["healthy"] == 1
        assert summary["source_health_history"]["summary"]["missing_keys"] == 1
        assert summary["risk_summary"]["confidence_score"] == 82.0
        assert summary["risk_summary"]["confidence_band_counts"]["high"] == 1
        assert summary["risk_summary"]["review_required"] == 1
        assert "case-exposure indicator" in summary["risk_summary"]["note"]
        assert summary["findings"][0]["independent_corroboration_count"] == 1
        assert summary["findings"][0]["human_review_required"] is True
        assert "needs independent corroboration" in summary["findings"][0]["human_review_reasons"]
        assert summary["findings"][0]["source_risk_label"].startswith("terms:")
        assert summary["pivot_plan"]["style"] == "case_pivot_chain"
        assert summary["pivot_plan"]["summary"]["blocked"] >= 1
        assert summary["pivot_plan"]["steps"][0]["safety_gate"] == "independent_corroboration_required"
        html = out.read_text(encoding="utf-8")
        assert html.startswith("<!DOCTYPE html>")
        assert "Independent Corroboration" in html
        assert "Source risk:" in html
        assert "Human review:" in html
        assert "Not Confirmed / Review Queue" in html
        assert "Risk And Confidence Summary" in html
        assert "Pivot Plan" in html
        assert "independent_corroboration_required" in html
        assert "risk_score" in html
        assert "Next Steps" in html
        assert "Why Matched / Review Notes" in html
        assert "Coverage Summary" in html
        assert "Source Health History" in html
        assert "missing_keys" in html
        assert "matched markers: username, profile page" in html
        assert "direct profile marker" in html
        markdown_text = markdown.read_text(encoding="utf-8")
        opencti = json.loads(opencti_path.read_text(encoding="utf-8"))
        misp = json.loads(misp_path.read_text(encoding="utf-8"))
        direct_opencti = case_summary_to_opencti_envelope(summary)
        direct_misp = case_summary_to_misp_event(summary)
        assert markdown_text.startswith("# BEDNIIOSINT Case Report: unified")
        assert "## Risk And Confidence Summary" in markdown_text
        assert "## Pivot Plan" in markdown_text
        assert "independent_corroboration_required" in markdown_text
        assert "## Source Health History" in markdown_text
        assert "- Confidence score: 82.0" in markdown_text
        assert "- Missing keys: 1" in markdown_text
        assert "## Next Steps" in markdown_text
        assert "corrob 1" in markdown_text
        assert "Source risk:" in markdown_text
        assert "Why matched: matched markers: username, profile page" in markdown_text
        assert opencti["type"] == "opencti-import-envelope"
        assert opencti["stix_bundle"]["type"] == "bundle"
        assert direct_opencti["case"] == "unified"
        assert misp["Event"]["info"] == "BEDNIIOSINT case unified"
        assert direct_misp["Event"]["info"] == "BEDNIIOSINT case unified"
        assert any(row["value"] == "bob" for row in misp["Event"]["Attribute"])
        assert csv_paths["entities"].read_text(encoding="utf-8").startswith(
            "type,value,created_at"
        )
        assert csv_paths["source_health_history"].read_text(encoding="utf-8").startswith(
            "observed_at,run_id,run_module,run_target,source_id"
        )
        assert callable(web_app.app)
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v25_source_policy_labels_are_persisted_and_reported(tmp_path: Path):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("policy-labels"))
        with storage.session() as session:
            case = Case(name="policy-labels", target="example.com", module="pipeline")
            session.add(case)
            session.commit()
            session.refresh(case)

            shodan = record_source(
                session,
                case_id=case.id,
                name="api:shodan",
                category="Exposed services / internet scan data",
                notes="passive exposure enrichment",
            )
            hibp = record_source(
                session,
                case_id=case.id,
                name="api:hibp",
                category="Breach exposure through legal APIs",
                notes="legal breach exposure lookup",
            )
            session.add(
                Finding(
                    case_id=case.id,
                    source_name=shodan.name,
                    source_id=shodan.source_id,
                    entity_type="domain",
                    entity_value="example.com",
                    status="exists",
                    confidence=0.8,
                )
            )
            session.add(
                Finding(
                    case_id=case.id,
                    source_name=hibp.name,
                    source_id=hibp.source_id,
                    entity_type="email",
                    entity_value="user@example.com",
                    status="exists",
                    confidence=0.7,
                )
            )
            session.commit()

        summary = build_case_summary("policy-labels")
        sources = {row["source_id"]: row for row in summary["sources"]}
        coverage_rows = {row["source"]: row for row in summary["source_coverage"]["rows"]}
        html = write_case_html(summary, tmp_path / "policy-labels.html").read_text(encoding="utf-8")
        markdown = write_case_markdown(summary, tmp_path / "policy-labels.md").read_text(encoding="utf-8")
        csv_paths = write_case_csv(summary, tmp_path, "policy-labels")
        sources_csv = csv_paths["sources"].read_text(encoding="utf-8")

        assert sources["api:shodan"]["collection_mode"] == "passive_lookup"
        assert sources["api:shodan"]["sensitivity"] == "standard"
        assert "passive_only" in sources["api:shodan"]["policy_labels"]
        assert "policy_labels=passive_only" in sources["api:shodan"]["notes"]
        assert sources["api:hibp"]["sensitivity"] == "sensitive_data"
        assert "sensitive_data" in sources["api:hibp"]["policy_labels"]
        assert "policy_labels=sensitive_data" in sources["api:hibp"]["notes"]
        assert coverage_rows["api:shodan"]["collection_mode"] == "passive_lookup"
        assert coverage_rows["api:hibp"]["sensitivity"] == "sensitive_data"
        assert summary["source_coverage"]["summary"]["passive_only_sources"] == 1
        assert summary["source_coverage"]["summary"]["sensitive_data_sources"] == 1
        assert "passive_only" in html
        assert "sensitive_data" in html
        assert "passive_only" in markdown
        assert "sensitive_data" in markdown
        assert "policy_labels" in sources_csv
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_cti_sync_dry_run_and_mocked_posts(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    summary = {
        "meta": {"case": "sync-case", "found": True},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }
    calls = []

    class Response:
        def __init__(self, status_code: int = 200, data: dict | None = None):
            self.status_code = status_code
            self._data = data or {}

        def json(self):
            return self._data

    def fail_request(*args, **kwargs):
        raise AssertionError("dry-run must not call network")

    monkeypatch.setattr(cti_sync, "request", fail_request)
    dry_opencti = sync_opencti(summary, url="https://opencti.example/graphql")
    dry_misp = sync_misp(summary, url="https://misp.example")

    assert dry_opencti.status == "dry_run"
    assert dry_misp.status == "dry_run"
    assert dry_opencti.payload_counts["stix_objects"] >= 1
    assert dry_misp.payload_counts["attributes"] >= 1

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/events/add"):
            return Response(200, {"Event": {"id": "42", "uuid": "event-uuid"}})
        return Response()

    monkeypatch.setattr(cti_sync, "request", fake_request)
    sent_opencti = sync_opencti(
        summary,
        url="https://opencti.example/import",
        token="opencti-secret",
        dry_run=False,
    )
    sent_misp = sync_misp(
        summary,
        url="https://misp.example",
        api_key="misp-secret",
        dry_run=False,
    )

    assert sent_opencti.as_dict()["status"] == "ok"
    assert sent_misp.as_dict()["status"] == "ok"
    assert calls[0][0] == "POST"
    assert calls[0][2]["headers"]["Authorization"] == "Bearer opencti-secret"
    assert calls[1][1] == "https://misp.example/events/add"
    assert calls[1][2]["headers"]["Authorization"] == "misp-secret"
    assert sent_misp.remote_id == "42"
    assert sent_misp.remote_uuid == "event-uuid"
    assert "opencti-secret" not in str(sent_opencti.as_dict())
    assert "misp-secret" not in str(sent_misp.as_dict())


def test_cti_preflight_checks_opencti_and_misp_without_case_payload(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    calls = []

    class Response:
        def __init__(self, status_code: int, data: dict):
            self.status_code = status_code
            self._data = data

        def json(self):
            return self._data

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/graphql"):
            assert kwargs["json"]["query"].startswith("query BedniiosintPreflight")
            return Response(200, {"data": {"about": {"version": "6.0.0"}}})
        if url.endswith("/servers/getVersion"):
            return Response(200, {"version": "2.4.190"})
        return Response(404, {})

    monkeypatch.setattr(cti_sync, "request", fake_request)

    opencti = preflight_opencti(url="https://opencti.example", token="opencti-secret")
    misp = preflight_misp(url="https://misp.example", api_key="misp-secret")
    missing_opencti = preflight_opencti(url="https://opencti.example/graphql", token="")

    assert opencti.status == "ok"
    assert opencti.url == "https://opencti.example/graphql"
    assert opencti.details["version"] == "6.0.0"
    assert misp.status == "ok"
    assert misp.url == "https://misp.example/servers/getVersion"
    assert misp.details["version"] == "2.4.190"
    assert missing_opencti.status == "missing_token"
    assert calls[0][0] == "POST"
    assert calls[0][2]["headers"]["Authorization"] == "Bearer opencti-secret"
    assert calls[1][0] == "GET"
    assert calls[1][2]["headers"]["Authorization"] == "misp-secret"
    assert "opencti-secret" not in str(opencti.as_dict())
    assert "misp-secret" not in str(misp.as_dict())


def test_misp_lifecycle_read_back_and_delete_are_explicit(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    summary = {
        "meta": {"case": "sync-case", "found": True},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }
    calls = []

    class Response:
        def __init__(self, status_code: int, data: dict):
            self.status_code = status_code
            self._data = data

        def json(self):
            return self._data

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/events/add"):
            return Response(200, {"Event": {"id": "42", "uuid": "event-uuid"}})
        if url.endswith("/events/view/42"):
            return Response(
                200,
                {
                    "Event": {
                        "id": "42",
                        "uuid": "event-uuid",
                        "Attribute": [{"type": "domain", "value": "example.com"}],
                    }
                },
            )
        if url.endswith("/events/delete/42"):
            return Response(200, {"saved": True})
        return Response(404, {})

    monkeypatch.setattr(cti_sync, "request", fake_request)

    result = sync_misp(
        summary,
        url="https://misp.example",
        api_key="misp-secret",
        dry_run=False,
        read_back=True,
        delete_after=True,
    )
    read = read_misp_event(url="https://misp.example", event_id="42", api_key="misp-secret")
    deleted = delete_misp_event(url="https://misp.example", event_id="42", api_key="misp-secret")

    assert result.status == "ok"
    assert result.remote_id == "42"
    assert [row["action"] for row in result.lifecycle] == ["read_back", "delete"]
    assert result.lifecycle[0]["details"]["attributes"] == 1
    assert read.status == "ok"
    assert read.details["attributes"] == 1
    assert deleted.status == "ok"
    assert [call[0] for call in calls[:3]] == ["POST", "GET", "DELETE"]
    assert calls[1][1] == "https://misp.example/events/view/42"
    assert calls[2][1] == "https://misp.example/events/delete/42"
    assert "misp-secret" not in str(result.as_dict())
    assert "misp-secret" not in str(read.as_dict())
    assert "misp-secret" not in str(deleted.as_dict())


def test_opencti_lifecycle_read_back_and_delete_are_explicit(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    summary = {
        "meta": {"case": "sync-case", "found": True},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }
    calls = []

    class Response:
        def __init__(self, status_code: int, data: dict):
            self.status_code = status_code
            self._data = data

        def json(self):
            return self._data

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/import"):
            return Response(200, {"data": {"id": "opencti--1"}})
        query = kwargs["json"]["query"]
        if "BedniiosintReadStixCoreObject" in query:
            return Response(
                200,
                {
                    "data": {
                        "stixCoreObject": {
                            "id": "opencti--1",
                            "standard_id": "identity--abc",
                            "entity_type": "Identity",
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:00:00Z",
                        }
                    }
                },
            )
        if "BedniiosintDeleteStixCoreObject" in query:
            return Response(200, {"data": {"stixCoreObjectEdit": {"delete": True}}})
        return Response(404, {})

    monkeypatch.setattr(cti_sync, "request", fake_request)

    result = sync_opencti(
        summary,
        url="https://opencti.example/import",
        token="opencti-secret",
        dry_run=False,
        read_back=True,
        delete_after=True,
    )
    read = read_opencti_stix_core_object(
        url="https://opencti.example",
        object_id="opencti--1",
        token="opencti-secret",
    )
    deleted = delete_opencti_stix_core_object(
        url="https://opencti.example",
        object_id="opencti--1",
        token="opencti-secret",
    )

    assert result.status == "ok"
    assert result.remote_id == "opencti--1"
    assert [row["action"] for row in result.lifecycle] == ["read_back", "delete"]
    assert result.lifecycle[0]["details"]["entity_type"] == "Identity"
    assert result.lifecycle[1]["details"]["deleted"] is True
    assert read.status == "ok"
    assert read.details["standard_id"] == "identity--abc"
    assert deleted.status == "ok"
    assert deleted.details["deleted"] is True
    assert [call[0] for call in calls[:3]] == ["POST", "POST", "POST"]
    assert calls[1][1] == "https://opencti.example/graphql"
    assert calls[1][2]["json"]["variables"] == {"id": "opencti--1"}
    assert calls[2][2]["json"]["variables"] == {"id": "opencti--1"}
    assert "opencti-secret" not in str(result.as_dict())
    assert "opencti-secret" not in str(read.as_dict())
    assert "opencti-secret" not in str(deleted.as_dict())


def test_opencti_field_patch_is_explicit_and_token_safe(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    summary = {
        "meta": {"case": "sync-case", "found": True},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }
    calls = []

    class Response:
        def __init__(self, status_code: int, data: dict):
            self.status_code = status_code
            self._data = data

        def json(self):
            return self._data

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/import"):
            return Response(200, {"data": {"id": "opencti--1"}})
        query = kwargs["json"]["query"]
        if "BedniiosintPatchOpenCtiObject" in query:
            assert "identityEdit" in query
            assert kwargs["json"]["variables"] == {
                "id": "opencti--1",
                "input": [
                    {
                        "key": "description",
                        "value": ["updated"],
                        "operation": "replace",
                    }
                ],
            }
            return Response(
                200,
                {
                    "data": {
                        "identityEdit": {
                            "fieldPatch": {
                                "id": "opencti--1",
                                "standard_id": "identity--abc",
                                "entity_type": "Identity",
                                "created_at": "2024-01-01T00:00:00Z",
                                "updated_at": "2024-01-01T00:01:00Z",
                            }
                        }
                    }
                },
            )
        return Response(404, {})

    monkeypatch.setattr(cti_sync, "request", fake_request)

    result = sync_opencti(
        summary,
        url="https://opencti.example/import",
        token="opencti-secret",
        dry_run=False,
        patch_fields={"description": "updated"},
        patch_mutation="identityEdit",
    )

    assert result.status == "ok"
    assert result.remote_id == "opencti--1"
    assert [row["action"] for row in result.lifecycle] == ["field_patch"]
    patch = result.lifecycle[0]
    assert patch["status"] == "ok"
    assert patch["details"]["mutation"] == "identityEdit"
    assert patch["details"]["patched_keys"] == ["description"]
    assert patch["details"]["standard_id"] == "identity--abc"
    assert calls[1][1] == "https://opencti.example/graphql"
    assert "opencti-secret" not in str(result.as_dict())


def test_opencti_field_patch_infers_mutation_from_remote_entity_type(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    summary = {
        "meta": {"case": "sync-case", "found": True},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }
    calls = []

    class Response:
        def __init__(self, status_code: int, data: dict):
            self.status_code = status_code
            self._data = data

        def json(self):
            return self._data

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/import"):
            return Response(200, {"data": {"id": "opencti--1"}})
        query = kwargs["json"]["query"]
        if "BedniiosintReadStixCoreObject" in query:
            return Response(
                200,
                {
                    "data": {
                        "stixCoreObject": {
                            "id": "opencti--1",
                            "standard_id": "identity--abc",
                            "entity_type": "Identity",
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:00:00Z",
                        }
                    }
                },
            )
        if "BedniiosintPatchOpenCtiObject" in query:
            assert "identityFieldPatch" in query
            assert "fieldPatch(input" not in query
            assert kwargs["json"]["variables"] == {
                "id": "opencti--1",
                "input": [
                    {
                        "key": "description",
                        "value": ["updated"],
                        "operation": "replace",
                    }
                ],
            }
            return Response(
                200,
                {
                    "data": {
                        "identityFieldPatch": {
                            "id": "opencti--1",
                            "standard_id": "identity--abc",
                            "entity_type": "Identity",
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:01:00Z",
                        }
                    }
                },
            )
        return Response(404, {})

    monkeypatch.setattr(cti_sync, "request", fake_request)

    result = sync_opencti(
        summary,
        url="https://opencti.example/import",
        token="opencti-secret",
        dry_run=False,
        patch_fields={"description": "updated"},
    )

    assert result.status == "ok"
    assert [row["action"] for row in result.lifecycle] == ["infer_mutation", "field_patch"]
    assert result.lifecycle[0]["status"] == "ok"
    assert result.lifecycle[0]["details"] == {
        "entity_type": "Identity",
        "mutation": "identityFieldPatch",
    }
    assert result.lifecycle[1]["status"] == "ok"
    assert result.lifecycle[1]["details"]["mutation"] == "identityFieldPatch"
    assert [call[0] for call in calls] == ["POST", "POST", "POST"]
    assert calls[1][1] == "https://opencti.example/graphql"
    assert calls[2][1] == "https://opencti.example/graphql"
    assert "opencti-secret" not in str(result.as_dict())


def test_opencti_field_patch_inference_requires_known_entity_type(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    summary = {
        "meta": {"case": "sync-case", "found": True},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }
    calls = []

    class Response:
        def __init__(self, status_code: int, data: dict):
            self.status_code = status_code
            self._data = data

        def json(self):
            return self._data

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/import"):
            return Response(200, {"data": {"id": "opencti--1"}})
        query = kwargs["json"]["query"]
        if "BedniiosintReadStixCoreObject" in query:
            return Response(
                200,
                {
                    "data": {
                        "stixCoreObject": {
                            "id": "opencti--1",
                            "standard_id": "x-custom--abc",
                            "entity_type": "X-Custom",
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:00:00Z",
                        }
                    }
                },
            )
        if "BedniiosintOpenCtiMutationFields" in query:
            return Response(
                200,
                {
                    "data": {
                        "__schema": {
                            "mutationType": {
                                "fields": [
                                    {"name": "identityFieldPatch"},
                                    {"name": "reportFieldPatch"},
                                ]
                            }
                        }
                    }
                },
            )
        raise AssertionError("unknown entity type must not attempt field patch")

    monkeypatch.setattr(cti_sync, "request", fake_request)

    result = sync_opencti(
        summary,
        url="https://opencti.example/import",
        token="opencti-secret",
        dry_run=False,
        patch_fields={"description": "updated"},
    )

    assert result.status == "ok"
    assert [row["action"] for row in result.lifecycle] == [
        "schema_introspection",
        "infer_mutation",
        "field_patch",
    ]
    assert result.lifecycle[0]["status"] == "ok"
    assert result.lifecycle[0]["details"]["field_patch_mutation_count"] == 2
    assert result.lifecycle[1]["status"] == "error"
    assert result.lifecycle[1]["details"]["entity_type"] == "X-Custom"
    assert result.lifecycle[2]["status"] == "error"
    assert "could not be inferred" in result.lifecycle[2]["error"]
    assert [call[0] for call in calls] == ["POST", "POST", "POST"]
    assert "opencti-secret" not in str(result.as_dict())


def test_opencti_field_patch_infers_custom_mutation_from_schema(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    summary = {
        "meta": {"case": "sync-case", "found": True},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }
    calls = []

    class Response:
        def __init__(self, status_code: int, data: dict):
            self.status_code = status_code
            self._data = data

        def json(self):
            return self._data

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/import"):
            return Response(200, {"data": {"id": "opencti--1"}})
        query = kwargs["json"]["query"]
        if "BedniiosintReadStixCoreObject" in query:
            return Response(
                200,
                {
                    "data": {
                        "stixCoreObject": {
                            "id": "opencti--1",
                            "standard_id": "x-custom--abc",
                            "entity_type": "X-Custom",
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:00:00Z",
                        }
                    }
                },
            )
        if "BedniiosintOpenCtiMutationFields" in query:
            return Response(
                200,
                {
                    "data": {
                        "__schema": {
                            "mutationType": {
                                "fields": [
                                    {"name": "identityFieldPatch"},
                                    {"name": "xCustomFieldPatch"},
                                ]
                            }
                        }
                    }
                },
            )
        if "BedniiosintPatchOpenCtiObject" in query:
            assert "xCustomFieldPatch" in query
            return Response(
                200,
                {
                    "data": {
                        "xCustomFieldPatch": {
                            "id": "opencti--1",
                            "standard_id": "x-custom--abc",
                            "entity_type": "X-Custom",
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:01:00Z",
                        }
                    }
                },
            )
        return Response(404, {})

    monkeypatch.setattr(cti_sync, "request", fake_request)

    result = sync_opencti(
        summary,
        url="https://opencti.example/import",
        token="opencti-secret",
        dry_run=False,
        patch_fields={"description": "updated"},
    )

    assert result.status == "ok"
    assert [row["action"] for row in result.lifecycle] == [
        "schema_introspection",
        "infer_mutation",
        "field_patch",
    ]
    assert result.lifecycle[0]["status"] == "ok"
    assert result.lifecycle[1]["details"] == {
        "entity_type": "X-Custom",
        "mutation": "xCustomFieldPatch",
    }
    assert result.lifecycle[2]["status"] == "ok"
    assert result.lifecycle[2]["details"]["mutation"] == "xCustomFieldPatch"
    assert [call[0] for call in calls] == ["POST", "POST", "POST", "POST"]
    assert "opencti-secret" not in str(result.as_dict())


def test_opencti_field_patch_uses_custom_map_when_introspection_disabled(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    summary = {
        "meta": {"case": "sync-case", "found": True},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }
    calls = []

    class Response:
        def __init__(self, status_code: int, data: dict):
            self.status_code = status_code
            self._data = data

        def json(self):
            return self._data

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        if url.endswith("/import"):
            return Response(200, {"data": {"id": "opencti--1"}})
        query = kwargs["json"]["query"]
        if "BedniiosintReadStixCoreObject" in query:
            return Response(
                200,
                {
                    "data": {
                        "stixCoreObject": {
                            "id": "opencti--1",
                            "standard_id": "x-private--abc",
                            "entity_type": "X-Private",
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:00:00Z",
                        }
                    }
                },
            )
        if "BedniiosintOpenCtiMutationFields" in query:
            raise AssertionError("custom patch map must avoid schema introspection")
        if "BedniiosintPatchOpenCtiObject" in query:
            assert "privateObjectFieldPatch" in query
            return Response(
                200,
                {
                    "data": {
                        "privateObjectFieldPatch": {
                            "id": "opencti--1",
                            "standard_id": "x-private--abc",
                            "entity_type": "X-Private",
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:01:00Z",
                        }
                    }
                },
            )
        return Response(404, {})

    monkeypatch.setattr(cti_sync, "request", fake_request)

    result = sync_opencti(
        summary,
        url="https://opencti.example/import",
        token="opencti-secret",
        dry_run=False,
        patch_fields={"description": "updated"},
        patch_mutation_map={"X-Private": "privateObjectFieldPatch"},
    )

    assert result.status == "ok"
    assert [row["action"] for row in result.lifecycle] == ["infer_mutation", "field_patch"]
    assert result.lifecycle[0]["status"] == "ok"
    assert result.lifecycle[0]["details"] == {
        "entity_type": "X-Private",
        "mutation": "privateObjectFieldPatch",
    }
    assert result.lifecycle[1]["status"] == "ok"
    assert result.lifecycle[1]["details"]["mutation"] == "privateObjectFieldPatch"
    assert [call[0] for call in calls] == ["POST", "POST", "POST"]
    assert "opencti-secret" not in str(result.as_dict())


def test_opencti_field_patch_rejects_invalid_mutation_before_network(monkeypatch):
    import bedniiosint.reports.cti_sync as cti_sync

    calls = []

    def fake_request(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("invalid mutation must not call network")

    monkeypatch.setattr(cti_sync, "request", fake_request)

    result = patch_opencti_object_fields(
        url="https://opencti.example",
        object_id="opencti--1",
        token="opencti-secret",
        fields={"description": "updated"},
        edit_mutation="__schemaEdit",
    )

    assert result.status == "error"
    assert result.action == "field_patch"
    assert "mutation" in result.error
    assert calls == []


def test_email_scoring_reasons_persist_to_legacy_finding_columns(tmp_path: Path):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        result = EmailCase("email-score", "not-an-email").run()
        storage = Storage(settings.db_path("email-score"))
        with storage.session() as session:
            finding = session.query(Finding).filter(Finding.case_id == 1).first()
            source = session.query(Source).filter(Source.case_id == 1).first()
            evidence = session.query(Evidence).filter(Evidence.case_id == 1).first()
            attachment = session.query(Attachment).filter(Attachment.case_id == 1).first()

        assert result["result"]["confidence"] == 0.0
        assert result["result"]["reject_reason"] == "invalid email format"
        assert finding is not None
        assert finding.confidence == 0.0
        assert finding.matched_markers == "score:valid_format:miss:invalid email format"
        assert finding.reject_reason == "invalid email format"
        assert finding.rejected
        assert source is not None
        assert source.name == "email-analyzer"
        assert source.category == "email"
        assert source.reliability < 0.78
        assert evidence is not None
        assert evidence.source_module == "email"
        assert evidence.sha256
        assert attachment is not None
        assert attachment.kind == "raw_json"
        assert attachment.mime == "application/json"
        assert Path(attachment.path).exists()
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_domain_passive_tools_use_passive_commands(monkeypatch):
    import bedniiosint.modules.domain.passive_tools as passive_tools

    calls = []

    class Completed:
        def __init__(self, stdout: str):
            self.returncode = 0
            self.stdout = stdout
            self.stderr = ""

    def fake_run(command, **kwargs):
        calls.append((command, kwargs))
        if command[0] == "amass":
            return Completed("www.example.com\nexample.com\nignored.example.net\n")
        return Completed('{"host":"api.example.com","source":"crtsh"}\n')

    monkeypatch.setattr(passive_tools.shutil, "which", lambda tool: f"C:/tools/{tool}.exe")
    monkeypatch.setattr(passive_tools.subprocess, "run", fake_run)

    result = run_passive_tools("example.com", tools=["amass", "subfinder"], timeout=7.5)

    assert [call[0] for call in calls] == [
        ["amass", "enum", "-passive", "-d", "example.com"],
        ["subfinder", "-silent", "-d", "example.com", "-json"],
    ]
    assert all(call[1]["shell"] is False for call in calls)
    assert all(call[1]["timeout"] == 7.5 for call in calls)
    assert {row["subdomain"] for row in result["subdomains"]} == {
        "www.example.com",
        "api.example.com",
    }


def test_domain_passive_tools_case_persists_outputs(tmp_path: Path, monkeypatch):
    from bedniiosint.config import settings
    import bedniiosint.core.case_domain_passive_tools as passive_case

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        def fake_run_passive_tools(domain, *, tools=None, timeout=60.0):
            return {
                "domain": domain,
                "mode": "passive_external_tools",
                "tools": [{"tool": "subfinder", "status": "ok"}],
                "subdomains": [
                    {"subdomain": "api.example.com", "source": "subfinder", "resolves": None, "a": []}
                ],
            }

        monkeypatch.setattr(passive_case, "run_passive_tools", fake_run_passive_tools)

        result = passive_case.DomainPassiveToolsCase("passive-domain", "example.com").run()
        storage = Storage(settings.db_path("passive-domain"))
        with storage.session() as session:
            entities = session.query(Entity).filter(Entity.case_id == 1).all()
            relations = session.query(Relation).filter(Relation.case_id == 1).all()
            finding = session.query(Finding).filter(Finding.case_id == 1).first()
            evidence = session.query(Evidence).filter(Evidence.case_id == 1).first()

        assert result["meta"]["module"] == "domain_passive_tools"
        assert {"example.com", "api.example.com"} <= {row.value for row in entities}
        assert relations[0].rel == "subdomain_of"
        assert finding is not None
        assert finding.source_id == "module:domain_passive_tools"
        assert finding.status == "exists"
        assert evidence is not None
        assert evidence.source_module == "domain_passive_tools"
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_media_verification_workflow_for_file_and_url(tmp_path: Path):
    media = tmp_path / "sample.jpg"
    media.write_bytes(b"fake-jpeg-bytes")

    file_workflow = build_media_verification_workflow(media)
    url_workflow = build_media_verification_workflow("https://example.com/video.mp4")
    out = write_media_verification_markdown(file_workflow, tmp_path / "media-workflow.md")
    markdown = out.read_text(encoding="utf-8")

    assert file_workflow["target_type"] == "file"
    assert file_workflow["schema_version"] == "2.0"
    assert file_workflow["evidence"]["sha256"]
    assert file_workflow["evidence"]["media_kind"] == "image"
    assert file_workflow["evidence"]["gps_status"] in {"not_found", "present_redacted"}
    assert file_workflow["privacy"]["third_party_upload_default"] == "disabled"
    assert any(row["provider"] == "TinEye API" for row in file_workflow["reverse_search_plan"])
    assert any(row["requires_upload"] for row in file_workflow["reverse_search_plan"])
    assert any(row["provider"].startswith("Wayback") for row in file_workflow["archive_plan"])
    assert file_workflow["geolocation_plan"]
    assert file_workflow["timeline_plan"]
    assert any(row["category"] == "reverse_search" for row in file_workflow["checks"])
    assert all("evidence_to_record" in row for row in file_workflow["checks"])
    assert "not_confirmed" in {row["status"] for row in file_workflow["checks"]}
    assert url_workflow["target_type"] == "url"
    assert url_workflow["evidence"]["host"] == "example.com"
    assert url_workflow["evidence"]["media_kind"] == "video"
    assert "Media Verification Workflow" in markdown
    assert "## Archive Search" in markdown
    assert "## Reverse Search" in markdown
    assert "## Geolocation" in markdown
    assert "## Timeline" in markdown
    assert "do not upload private media" in markdown


def test_recheck_builtin_analyzer_finding(tmp_path: Path):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        EmailCase("builtin-recheck", "not-an-email").run()
        storage = Storage(settings.db_path("builtin-recheck"))
        with storage.session() as session:
            finding = session.query(Finding).filter(Finding.case_id == 1).first()

        summary = recheck_finding("builtin-recheck", finding.id)
        with storage.session() as session:
            cases = session.query(Case).all()

        assert summary["meta"]["rechecked_finding_id"] == finding.id
        assert summary["meta"]["recheck_module"] == "email"
        assert len(cases) == 2
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v03_ip_source_reliability_and_rejection(tmp_path: Path):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        result = IPCase("ip-score", "not-an-ip").run()
        storage = Storage(settings.db_path("ip-score"))
        with storage.session() as session:
            finding = session.query(Finding).filter(Finding.case_id == 1).first()
            source = session.query(Source).filter(Source.case_id == 1).first()

        assert result["result"]["reject_reason"] == "invalid IP address"
        assert finding is not None
        assert finding.rejected
        assert finding.reject_reason == "invalid IP address"
        assert "score:valid_ip:miss:invalid IP address" in finding.matched_markers
        assert source is not None
        assert source.name == "ip-analyzer"
        assert source.category == "ip"
        assert source.reliability < 0.76
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_dashboard_v01_pages_render(tmp_path: Path):
    import bedniiosint.web.app as web_app
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("dash"))
        with storage.session() as session:
            case = Case(name="dash", target="bob", module="test")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(Entity(case_id=case.id, type="username", value="bob"))
            session.add(Entity(case_id=case.id, type="profile", value="https://x/bob"))
            session.add(
                Relation(
                    case_id=case.id,
                    src_type="username",
                    src_value="bob",
                    rel="same_username",
                    dst_type="profile",
                    dst_value="https://x/bob",
                )
            )
            session.commit()
            case_id = case.id

        add_event(
            storage,
            case_id,
            kind="first_seen",
            entity_type="profile",
            entity_value="https://x/bob",
        )
        summary = build_case_summary("dash")
        files = web_app._write_outputs("dash", "case", summary)
        from bedniiosint.web.routers.reports import reports_html as render_reports_html

        reports_html = render_reports_html(web_app._reports_dir, web_app._evidence_bundle_inspection)
        from bedniiosint.web.routers.plugins import plugins_html as render_plugins_html

        plugins_html = render_plugins_html()

        from bedniiosint.web.routers.sources import sources_html as render_sources_html

        sources_html = render_sources_html(runnable=True)
        assert "Sources" in sources_html
        assert "Target Coverage" in sources_html
        assert "Configured search sources by target type" in sources_html
        assert "Source Maintenance" in sources_html
        assert "/sources/maintenance" in sources_html
        assert "/search/sources?compact=true" in sources_html
        assert "/live-plan" in sources_html
        assert "/live-results/view" in sources_html
        assert "module:username" in sources_html
        assert "Runnable" in sources_html
        from bedniiosint.web.routers.live_results import live_results_html as render_live_results_html

        live_results_html = render_live_results_html()
        assert "Live Validation Results" in live_results_html
        assert "Retention guidance" in live_results_html
        assert "Retention Cleanup" in live_results_html
        assert "Audit Evidence" in live_results_html
        assert "/live-results/audit" in live_results_html
        assert "SHA-256" in live_results_html
        assert "format=csv" in live_results_html
        assert "format=markdown" in live_results_html
        assert 'action="/live-results/cleanup"' in live_results_html
        assert "/live-results?" in live_results_html
        assert "Plugins" in plugins_html
        assert "/plugins.json" in plugins_html
        assert "/plugins/username/config" in plugins_html
        assert "Reports" in reports_html
        assert "Manifest JSON" in reports_html
        assert "Integrity" in reports_html
        assert "/reports/verify" in reports_html
        assert "Report Verify" in reports_html
        assert "Bundle ZIP" in reports_html
        if hasattr(web_app.app, "routes"):
            with warnings.catch_warnings():
                warnings.filterwarnings(
                    "ignore",
                    message="Using `httpx` with `starlette.testclient` is deprecated.*",
                )
                from fastapi.testclient import TestClient

                client = TestClient(web_app.app)
            report_verify = client.get("/reports/verify", params={"case": "dash"})
            assert report_verify.status_code == 200
            report_verify_payload = report_verify.json()
            assert report_verify_payload["valid"] is True
            assert report_verify_payload["secrets_returned"] is False
            assert report_verify_payload["checks"]["sha256"] is True
            evidence_inspect = client.get("/reports/evidence-bundle/dash/inspect")
            assert evidence_inspect.status_code == 200
            assert evidence_inspect.json()["valid"] is False
        from bedniiosint.web.routers.visualizations import (
            graph_html as render_graph_html,
            timeline_html as render_timeline_html,
        )

        graph_html = render_graph_html("dash", build_graph(storage, case_id))
        timeline_html = render_timeline_html("dash", summary["timeline"])
        assert "Graph: dash" in graph_html
        assert "/static/graph.js?v=" in graph_html
        assert "Timeline: dash" in timeline_html
        assert "/static/timeline.js?v=" in timeline_html
        case_html = web_app._case_html("dash", summary, files)
        static_dir = Path(web_app.__file__).with_name("static")
        workspace_js = (static_dir / "workspace.js").read_text(encoding="utf-8")
        graph_cy_js = (static_dir / "graph_cy.js").read_text(encoding="utf-8")
        cytoscape_js = (static_dir / "vendor" / "cytoscape.min.js").read_text(encoding="utf-8")
        graph_js = (static_dir / "graph.js").read_text(encoding="utf-8")
        timeline_js = (static_dir / "timeline.js").read_text(encoding="utf-8")
        assert "Target: bob" in case_html
        assert "case-sidebar" in case_html
        assert "Target Search" not in case_html
        assert '<button type="submit">Run</button>' not in case_html
        assert "Loading structured data" in case_html
        assert 'data-table-panel="profiles"' in case_html
        assert 'data-table-search="profiles"' in case_html
        assert 'role="tab" data-tab="profiles"' in case_html
        assert 'aria-controls="tab-emails"' in case_html
        assert 'href="#tab-profiles"' in case_html
        assert 'class="tab-count" data-tab-count="profiles"' in case_html
        assert 'id="overviewTableCards"' not in case_html
        assert "/static/workspace-tabs.js?v=" in case_html
        for tab in ("Overview", "Profiles", "Emails", "Phones", "Domains", "Mentions", "Sources", "Evidence", "Graph", "Exports"):
            assert f">{tab}<" in case_html
        assert ">Raw<" not in case_html
        assert 'id="evidenceDrawer"' in case_html
        assert 'id="caseSidebarToggle"' in case_html
        assert 'id="drawerToggle"' in case_html
        assert 'id="profilesSearch"' in case_html
        assert 'id="graphRelationFilter"' in case_html
        assert 'id="graphHideSources"' in case_html
        assert 'id="graphHideWeak"' in case_html
        assert 'id="cyGraph"' in case_html
        assert 'id="workspaceGraphCanvas"' not in case_html
        assert "/static/app.css?v=" in case_html
        assert "/static/refresh.css?v=" in case_html
        assert "/static/workspace.css?v=" in case_html
        assert case_html.index("/static/app.css?v=") < case_html.index("/static/workspace.css?v=")
        assert case_html.index("/static/workspace.css?v=") < case_html.index("/static/refresh.css?v=")
        assert "/static/workspace.js?v=" in case_html
        assert "/static/vendor/cytoscape.min.js" in case_html
        assert "/static/graph_cy.js" in case_html
        assert "<style>" not in case_html
        assert "<script>\nconst CASE_NAME" not in case_html
        assert "const graphData" not in graph_html
        assert "const timelineData" not in timeline_html
        assert "const graphData" in graph_js
        assert "const timelineData" in timeline_js
        assert "function showTab(key)" in workspace_js
        assert "function showWorkspaceTab(key" in workspace_js
        assert "function updateTabCounts()" in workspace_js
        assert "window.bedniiosintRerender" in workspace_js
        assert "function platformPriorityBoost(row)" in workspace_js
        assert "function wtr(value)" in workspace_js
        assert "document.addEventListener('click'" in workspace_js
        assert ".tab-button,[data-open-tab]" in workspace_js
        assert "history.replaceState(null, '', `#tab-${selected}`)" in workspace_js
        assert "showTab(button.dataset.tab)" in workspace_js
        assert "toggleAttribute('hidden'" not in workspace_js
        workspace_tabs_js = (static_dir / "workspace-tabs.js").read_text(encoding="utf-8")
        assert "window.bedniiosintShowWorkspaceTab" in workspace_tabs_js
        assert "document.addEventListener('click'" in workspace_tabs_js
        assert "closestTarget(event, '.tab-button,[data-open-tab]')" in workspace_tabs_js
        assert "toggleAttribute('hidden'" not in workspace_tabs_js
        assert "hashchange" in workspace_tabs_js
        assert r"^https?:\/\//i" in workspace_js
        assert r"^https?:\\/\\//i" not in workspace_js
        node = shutil.which("node")
        if node:
            for script in (
                static_dir / "workspace.js",
                static_dir / "graph_cy.js",
                static_dir / "vendor" / "cytoscape.min.js",
            ):
                subprocess.run(
                    [node, "--check", str(script)],
                    check=True,
                    capture_output=True,
                    text=True,
                )
        app_css = (static_dir / "app.css").read_text(encoding="utf-8")
        workspace_css = (static_dir / "workspace.css").read_text(encoding="utf-8")
        refresh_css = (static_dir / "refresh.css").read_text(encoding="utf-8")
        assert "html, body { max-width: 100%; overflow-x: hidden; }" in app_css
        assert ".workspace-table th{" in workspace_css and "white-space:nowrap" in workspace_css
        assert ".drawer{" in workspace_css and "calc(100vw - 24px)" in workspace_css
        assert "#cyGraph" in refresh_css
        assert "cytoscape" in graph_cy_js
        assert "The Cytoscape Consortium" in cytoscape_js
        assert "3.x-fallback" not in cytoscape_js
        assert 'id="relationsBody"' in case_html
        assert 'id="mergeForm"' in case_html
        assert 'id="splitForm"' in case_html
        assert "Priority Leads" in case_html
        assert "Confidence is scored from source signals" in case_html
        assert "Graph editing" in case_html
        assert "Row Inspector" not in case_html
        assert 'id="dedupeCase"' in case_html
        assert "Export Center" in case_html
        assert "/cases/${encodeURIComponent(CASE_NAME)}/workspace" in workspace_js
        assert "/cases/${encodeURIComponent(CASE_NAME)}/findings/" in workspace_js
        assert "/cases/${encodeURIComponent(CASE_NAME)}/relations" in workspace_js
        assert "/relations/${encodeURIComponent(state.editingRelationId)}" in workspace_js
        assert "method: state.editingRelationId ? 'PUT' : 'POST'" in workspace_js
        assert "method:'DELETE'" in workspace_js
        assert "/cases/${encodeURIComponent(CASE_NAME)}/entities/merge" in workspace_js
        assert "/cases/${encodeURIComponent(CASE_NAME)}/entities/split" in workspace_js
        assert "/cases/${encodeURIComponent(CASE_NAME)}/dedupe" in workspace_js
        assert "/cases/${encodeURIComponent(CASE_NAME)}/notes" in workspace_js
        assert "/cases/dash/graph" in case_html
        assert "GraphML" in case_html
        assert "GEXF" in case_html
        assert "STIX JSON" in case_html
        assert "TAXII JSON" in case_html
        assert "OpenCTI JSON" in case_html
        assert "MISP JSON" in case_html
        assert "Markdown Report" in case_html
        assert "Integrity Summary" in case_html
        assert "Evidence Bundle" in case_html
        assert "Case Archive" in case_html
        assert "Bundle ZIP" in case_html
        assert "csv_findings" in files and files["csv_findings"].exists()
        assert "case_markdown" in files and files["case_markdown"].exists()
        assert "stix" in files and files["stix"].exists()
        assert "taxii" in files and files["taxii"].exists()
        assert "opencti" in files and files["opencti"].exists()
        assert "misp" in files and files["misp"].exists()
        assert "manifest" in files and files["manifest"].exists()
        report_html = files["case_html"].read_text(encoding="utf-8")
        report_markdown = files["case_markdown"].read_text(encoding="utf-8")
        stix = json.loads(files["stix"].read_text(encoding="utf-8"))
        taxii = json.loads(files["taxii"].read_text(encoding="utf-8"))
        opencti = json.loads(files["opencti"].read_text(encoding="utf-8"))
        misp = json.loads(files["misp"].read_text(encoding="utf-8"))
        assert "Executive Summary" in report_html
        assert "Confidence Methodology" in report_html
        assert "Investigator Review" in report_html
        assert "Needs verification" in report_html
        assert "Independent Corroboration" in report_html
        assert "Not Confirmed / Review Queue" in report_html
        assert "Legal and Privacy Scope" in report_html
        assert "Source Coverage" in report_html
        assert "public, permissioned OSINT workflows" in report_html
        assert "Graph Snapshot" in report_html
        assert "Evidence Appendix" in report_html
        assert report_markdown.startswith("# BEDNIIOSINT Case Report: dash")
        assert "## Strongest Signals" in report_markdown
        assert stix["type"] == "bundle"
        assert taxii["type"] == "taxii-collection-envelope"
        assert opencti["type"] == "opencti-import-envelope"
        assert misp["Event"]["info"] == "BEDNIIOSINT case dash"
        assert taxii["objects"]
        assert any(row["type"] == "relationship" for row in stix["objects"])
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_dashboard_home_is_plain_and_history_can_be_cleared(tmp_path: Path):
    import bedniiosint.web.app as web_app
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path / "cases")
    try:
        reports_dir = tmp_path / "reports_out"
        storage = Storage(settings.db_path("dash-history"))
        with storage.session() as session:
            case = Case(name="dash-history", target="wallet-target", module="wallet")
            session.add(case)
            session.commit()
        vault_dir = settings.db_dir / "dash-history_vault"
        vault_dir.mkdir(parents=True)
        (vault_dir / "snapshot.html").write_text("<html>evidence</html>", encoding="utf-8")
        reports_dir.mkdir()
        (reports_dir / "dash-history-case.html").write_text("<html>report</html>", encoding="utf-8")
        (reports_dir / "dash-history-technical.json").write_text("{}", encoding="utf-8")
        (reports_dir / "dash-history-evidence-bundle.zip").write_bytes(b"zip")
        (reports_dir / "reports-manifest.json").write_text("{}", encoding="utf-8")
        (settings.db_dir / "_jobs.db").write_text("jobs", encoding="utf-8")

        home = web_app._index_html()
        header = web_app._header_html("home")
        history = web_app._history_html()

        assert 'class="brand"' not in header
        assert "/api-keys" not in header
        assert "/reports" not in header
        assert "Investigate public traces across usernames" not in home
        assert "wordmark" in home
        assert "data-module=\"auto\"" not in home
        assert 'name="module" value="investigate"' in home
        assert 'class="brand-logo wordmark reveal"' in home
        assert 'class="google-search-form search"' in home
        assert 'class="home-meta coverage reveal"' in home
        assert "Source Health</h2>" not in home
        assert "Recent Cases" not in home
        assert "Clear History" in history
        assert len(web_app._case_rows()) == 1

        deleted_count = web_app._clear_history()
        assert deleted_count == 1
        assert web_app._case_rows() == []
        assert not (settings.db_dir / "dash-history.db").exists()
        assert not vault_dir.exists()
        assert not (reports_dir / "dash-history-case.html").exists()
        assert not (reports_dir / "dash-history-technical.json").exists()
        assert not (reports_dir / "dash-history-evidence-bundle.zip").exists()
        assert not (reports_dir / "reports-manifest.json").exists()
        assert (settings.db_dir / "_jobs.db").exists()
        assert "No history yet." in web_app._history_html()
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_stix_export_includes_evidence_artifacts_and_links():
    summary = {
        "meta": {"case": "stix-artifacts"},
        "entities": [{"type": "email", "value": "alice@example.com"}],
        "findings": [
            {
                "id": 42,
                "entity_type": "email",
                "entity_value": "alice@example.com",
                "source_name": "breach-check",
                "status": "exists",
                "confidence": 0.83,
                "profile_url": "https://source.example/alice",
            }
        ],
        "relations": [],
        "evidence": [
            {
                "id": 7,
                "finding_id": 42,
                "url": "https://source.example/alice",
                "final_url": "https://source.example/alice",
                "http_status": 200,
                "sha256": "a" * 64,
                "source_module": "email",
                "adapter_version": "1.2.3",
                "content_type": "text/html",
                "method": "GET",
                "artifact_path": "evidence/stix-artifacts/7.html",
            }
        ],
        "attachments": [
            {
                "id": 8,
                "finding_id": 42,
                "path": "evidence/stix-artifacts/8.raw.json",
                "sha256": "b" * 64,
                "mime": "application/json",
                "source_adapter_version": "4.5.6",
            }
        ],
    }

    stix = case_summary_to_stix(summary)
    artifacts = [row for row in stix["objects"] if row["type"] == "artifact"]
    relationships = [row for row in stix["objects"] if row["type"] == "relationship"]

    evidence_artifact = next(row for row in artifacts if row["x_bedniiosint_role"] == "evidence")
    attachment_artifact = next(
        row for row in artifacts if row["x_bedniiosint_role"] == "attachment"
    )
    assert evidence_artifact["hashes"]["SHA-256"] == "a" * 64
    assert evidence_artifact["mime_type"] == "text/html"
    assert evidence_artifact["x_bedniiosint_http_method"] == "GET"
    assert evidence_artifact["x_bedniiosint_http_status"] == 200
    assert evidence_artifact["x_bedniiosint_source_module"] == "email"
    assert attachment_artifact["hashes"]["SHA-256"] == "b" * 64
    assert attachment_artifact["mime_type"] == "application/json"
    assert attachment_artifact["x_bedniiosint_adapter_version"] == "4.5.6"
    assert any(
        row["relationship_type"] == "evidenced-by"
        and row["source_ref"].startswith("observed-data--")
        and row["target_ref"].startswith("artifact--")
        for row in relationships
    )


def test_taxii_envelope_and_stix_import_roundtrip_shape():
    summary = {
        "meta": {"case": "taxii-roundtrip"},
        "entities": [{"type": "domain", "value": "example.com"}],
        "findings": [
            {
                "id": 1,
                "entity_type": "domain",
                "entity_value": "example.com",
                "source_name": "dns",
                "status": "exists",
                "confidence": 0.91,
                "profile_url": "https://example.com",
            }
        ],
        "relations": [],
        "evidence": [],
        "attachments": [],
    }

    envelope = case_summary_to_taxii_envelope(summary)
    imported = stix_bundle_to_case_summary(
        {"type": "bundle", "objects": envelope["objects"]},
        case_name="imported-taxii",
    )

    assert envelope["type"] == "taxii-collection-envelope"
    assert envelope["taxii_version"] == "2.1"
    assert envelope["collection"]["media_type"] == "application/taxii+json;version=2.1"
    assert imported["meta"]["case"] == "imported-taxii"
    assert imported["entities"] == [{"type": "domain", "value": "example.com"}]
    assert imported["findings"][0]["source_name"] == "dns"
    assert imported["findings"][0]["confidence"] == 0.91


def test_web_openapi_documents_json_api_schemas():
    import pytest

    import bedniiosint.web.app as web_app

    if not hasattr(web_app.app, "openapi"):
        pytest.skip("FastAPI is not installed in this test environment")

    schema = web_app.app.openapi()
    contract = web_app.api_schema_contract()
    components = schema["components"]["schemas"]
    paths = schema["paths"]

    for name in contract["models"]:
        assert name in components

    for route in contract["routes"]:
        schema_ref = paths[route["path"]][route["method"].lower()]["responses"]["200"]["content"][
            "application/json"
        ]["schema"]
        model = route["response_model"]
        if model.startswith("list["):
            assert schema_ref["items"]["$ref"] == f"#/components/schemas/{model[5:-1]}"
        else:
            assert schema_ref["$ref"] == f"#/components/schemas/{model}"


def test_web_json_api_schema_contract_matches_route_decorators():
    import re

    import bedniiosint.web.app as web_app

    app_source_path = Path(web_app.__file__)
    router_source_paths = sorted(app_source_path.parent.joinpath("routers").glob("*.py"))
    schema_source_paths = sorted(app_source_path.parent.glob("schemas.py"))
    source = "\n".join(
        path.read_text(encoding="utf-8")
        for path in [app_source_path, *router_source_paths, *schema_source_paths]
    )
    contract = web_app.api_schema_contract()
    contract_routes = {
        (row["method"].lower(), row["path"]): row["response_model"]
        for row in contract["routes"]
    }
    decorator_routes = {}
    for line in source.splitlines():
        match = re.search(
            r"@(app|router)\.(get|post|put|delete)\(\"([^\"]+)\".*response_model=([^,\)]+)",
            line,
        )
        if match:
            decorator_routes[(match.group(2), match.group(3))] = match.group(4).strip()
    model_classes = set(re.findall(r"^    class (\w+API)\(", source, flags=re.MULTILINE))

    assert decorator_routes == contract_routes
    assert set(contract["models"]) <= model_classes
    assert {
        "PipelineSourcesAPI",
        "PipelineRunAPI",
        "WorkerStatusAPI",
        "WorkspaceAPI",
        "EvidenceManifestAPI",
        "GraphAPI",
    } <= set(contract["models"])


def test_web_security_requires_auth_and_csrf_when_token_configured(monkeypatch):
    import pytest

    monkeypatch.setenv("BEDNIIOSINT_WEB_TOKEN", "secret-token")
    import bedniiosint.web.app as web_app

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Using `httpx` with `starlette.testclient` is deprecated.*",
        )
        from fastapi.testclient import TestClient

        client = TestClient(web_app.app)

    assert client.get("/auth/status").json()["enabled"] is True
    assert client.get("/jobs.json").status_code == 401
    assert (
        client.get(
            "/jobs.json",
            headers={"Authorization": "Bearer secret-token"},
        ).status_code
        == 200
    )
    assert (
        client.post(
            "/jobs/worker/stop",
            headers={"Authorization": "Bearer secret-token"},
        ).status_code
        == 403
    )
    assert (
        client.post(
            "/jobs/worker/stop",
            headers={
                "Authorization": "Bearer secret-token",
                "X-CSRF-Token": web_app.csrf_token(),
            },
        ).status_code
        == 200
    )

    login = client.post("/auth/login", data={"token": "secret-token"})
    assert login.status_code == 200
    assert client.get("/jobs.json").status_code == 200

    html = web_app._secure_html(
        '<html><head></head><body><form method="post" action="/jobs"></form></body></html>'
    )
    assert 'name="csrf-token"' in html
    assert 'name="_csrf"' in html


def test_web_api_key_page_stores_and_deletes_encrypted_keys(monkeypatch, tmp_path: Path):
    import pytest

    import bedniiosint.web.app as web_app
    from bedniiosint.config import settings
    from bedniiosint.core.secret_store import secret_value

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    monkeypatch.setenv("BEDNIIOSINT_SECRETS_KEY", "web-test-passphrase")
    monkeypatch.delenv("BEDNIIOSINT_WEB_TOKEN", raising=False)
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="Using `httpx` with `starlette.testclient` is deprecated.*",
            )
            from fastapi.testclient import TestClient

            client = TestClient(web_app.app)

        page = client.get("/api-keys")
        assert page.status_code == 200
        assert 'action="/api-keys"' in page.text
        assert "P1 Keyed Source Setup" in page.text
        assert "/api-keys/setup?priority=P1" in page.text
        assert "SHODAN_API_KEY" in page.text
        assert "Save Key" in page.text

        setup = client.get("/api-keys/setup?priority=P1")
        assert setup.status_code == 200
        setup_payload = setup.json()
        setup_rows = {row["source_id"]: row for row in setup_payload["sources"]}
        assert setup_payload["summary"]["priorities"] == ["P1"]
        assert "api:shodan" in setup_rows
        assert "SHODAN_API_KEY" in setup_rows["api:shodan"]["missing_env"]

        saved = client.post(
            "/api-keys",
            data={"name": "SHODAN_API_KEY", "value": "web-vault-secret"},
        )
        assert saved.status_code == 200
        assert "Stored SHODAN_API_KEY" in saved.text
        assert "web-vault-secret" not in saved.text
        assert "web-vault-secret" not in client.get("/api-keys/setup?priority=P1").text
        assert secret_value("SHODAN_API_KEY") == "web-vault-secret"
        assert "web-vault-secret" not in (tmp_path / "_secrets.json").read_text(encoding="utf-8")
        assert "Delete Store Key" in saved.text

        deleted = client.post("/api-keys/SHODAN_API_KEY/delete")
        assert deleted.status_code == 200
        assert "Deleted SHODAN_API_KEY" in deleted.text
        assert not secret_value("SHODAN_API_KEY")
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_web_api_key_routes_are_split_into_router_module():
    import bedniiosint.web.app as web_app
    import bedniiosint.web.routers.api_keys as api_keys_router

    app_source = Path(web_app.__file__).read_text(encoding="utf-8")
    router_source = Path(api_keys_router.__file__).read_text(encoding="utf-8")

    assert '@app.get("/api-keys"' not in app_source
    assert '@app.post("/api-keys"' not in app_source
    assert '@router.get("/api-keys"' in router_source
    assert '@router.post("/api-keys"' in router_source


def test_web_api_key_first_run_passphrase_wizard_is_runtime_only(monkeypatch, tmp_path: Path):
    import os

    import pytest

    import bedniiosint.web.app as web_app
    from bedniiosint.config import settings
    from bedniiosint.core.secret_store import SECRET_KEY_ENV, secret_value

    if not hasattr(web_app.app, "routes"):
        pytest.skip("FastAPI is not installed in this test environment")

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    monkeypatch.delenv(SECRET_KEY_ENV, raising=False)
    monkeypatch.delenv("BEDNIIOSINT_WEB_TOKEN", raising=False)
    monkeypatch.delenv("SHODAN_API_KEY", raising=False)
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="Using `httpx` with `starlette.testclient` is deprecated.*",
            )
            from fastapi.testclient import TestClient

            client = TestClient(web_app.app)

        page = client.get("/api-keys")
        assert page.status_code == 200
        assert "Initialize Encrypted Store" in page.text
        assert 'action="/api-keys/passphrase"' in page.text

        enabled = client.post(
            "/api-keys/passphrase",
            data={"passphrase": "runtime-only-passphrase"},
        )
        assert enabled.status_code == 200
        assert f"{SECRET_KEY_ENV} is set for this running dashboard process" in enabled.text
        assert "runtime-only-passphrase" not in enabled.text
        assert os.environ[SECRET_KEY_ENV] == "runtime-only-passphrase"
        assert "Initialize Encrypted Store" not in enabled.text

        saved = client.post(
            "/api-keys",
            data={"name": "SHODAN_API_KEY", "value": "wizard-secret"},
        )
        assert saved.status_code == 200
        assert "wizard-secret" not in saved.text
        assert secret_value("SHODAN_API_KEY") == "wizard-secret"
        store_text = (tmp_path / "_secrets.json").read_text(encoding="utf-8")
        assert "wizard-secret" not in store_text
        assert "runtime-only-passphrase" not in store_text
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_workspace_report_outputs_include_pdf_when_renderer_available(tmp_path: Path, monkeypatch):
    import bedniiosint.web.app as web_app
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path / "cases")

    def fake_html_to_pdf(html_path: Path, pdf_path: Path):
        assert html_path.exists()
        pdf_path.write_bytes(b"%PDF-1.7\n")
        return pdf_path

    monkeypatch.setattr(web_app, "html_to_pdf", fake_html_to_pdf)
    try:
        storage = Storage(settings.db_path("pdf-case"))
        with storage.session() as session:
            case = Case(name="pdf-case", target="bob", module="test")
            session.add(case)
            session.commit()

        summary = build_case_summary("pdf-case")
        files = web_app._write_outputs("pdf-case", "case", summary)
        html = web_app._case_html("pdf-case", summary, files)

        assert files["case_pdf"].exists()
        assert files["case_pdf"].read_bytes().startswith(b"%PDF")
        assert "PDF Report" in html
        assert "/reports/pdf-case-case.pdf" in html
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_case_workspace_ui_handles_empty_and_unicode_cases(tmp_path: Path):
    import bedniiosint.web.app as web_app
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("пустой-кейс"))
        with storage.session() as session:
            case = Case(name="пустой-кейс", target="валя", module="company")
            session.add(case)
            session.commit()

        summary = build_case_summary("пустой-кейс")
        files = web_app._write_outputs("пустой-кейс", "case", summary)
        html = web_app._case_html("пустой-кейс", summary, files)

        assert "Target: валя" in html
        assert "валя" in html
        assert "No selection." in html
        assert "Loading structured data" in html
        assert 'id="tab-raw"' in html
        assert "No graph nodes match the current filters." in html
        assert "%D0%BF%D1%83%D1%81%D1%82%D0%BE%D0%B9-%D0%BA%D0%B5%D0%B9%D1%81-case.json" in html
        assert "/reports/bundle/%D0%BF%D1%83%D1%81%D1%82%D0%BE%D0%B9-%D0%BA%D0%B5%D0%B9%D1%81" in html
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_v04_report_manifest_groups_case_bundle(tmp_path: Path):
    import hashlib

    from typer.testing import CliRunner

    from bedniiosint.cli import app
    from bedniiosint.reports.manifest import (
        report_manifest,
        verify_report_manifest,
        write_case_bundle,
        write_report_manifest,
    )

    (tmp_path / "alpha-case.html").write_text("<html></html>", encoding="utf-8")
    (tmp_path / "alpha-case.json").write_text("{}", encoding="utf-8")
    (tmp_path / "alpha-case.md").write_text("# alpha", encoding="utf-8")
    (tmp_path / "alpha-stix.json").write_text("{}", encoding="utf-8")
    (tmp_path / "alpha-opencti.json").write_text("{}", encoding="utf-8")
    (tmp_path / "alpha-misp.json").write_text("{}", encoding="utf-8")
    bundle = write_case_bundle(tmp_path, "alpha")
    manifest = report_manifest(tmp_path)

    cases = {row["case"]: row for row in manifest["cases"]}
    alpha_files = [row["name"] for row in manifest["files"] if row["case"] == "alpha"]

    assert bundle.exists()
    assert "alpha" in cases
    assert "alpha-bundle.zip" in alpha_files
    assert "alpha-opencti.json" in alpha_files
    assert "alpha-misp.json" in alpha_files
    assert any(
        row["name"] == "alpha-case.md" and row["kind"] == "markdown"
        for row in manifest["files"]
    )
    markdown_row = next(row for row in manifest["files"] if row["name"] == "alpha-case.md")
    assert markdown_row["sha256"] == hashlib.sha256((tmp_path / "alpha-case.md").read_bytes()).hexdigest()
    assert "alpha-bundle" not in cases

    manifest_path = write_report_manifest(tmp_path)
    verified = verify_report_manifest(manifest_path, case_name="alpha")

    assert verified["valid"] is True
    assert verified["checks"]["sha256"] is True
    assert verified["checks"]["sizes"] is True
    assert verified["secrets_returned"] is False

    cli_verified = CliRunner().invoke(
        app,
        ["reports-verify", str(manifest_path), "--case", "alpha", "--json"],
    )
    cli_group_verified = CliRunner().invoke(
        app,
        ["reports", "verify", str(manifest_path), "--case", "alpha", "--json"],
    )
    cli_group_help = CliRunner().invoke(app, ["reports", "write", "--help"])

    assert cli_verified.exit_code == 0, cli_verified.output
    assert json.loads(cli_verified.output)["valid"] is True
    assert cli_group_verified.exit_code == 0, cli_group_verified.output
    assert json.loads(cli_group_verified.output)["valid"] is True
    assert cli_group_help.exit_code == 0, cli_group_help.output
    assert "Write a unified report bundle" in cli_group_help.output

    (tmp_path / "alpha-case.md").write_text("# tampered", encoding="utf-8")
    tampered = verify_report_manifest(manifest_path, case_name="alpha")

    assert tampered["valid"] is False
    tampered_markdown = next(row for row in tampered["files"] if row["name"] == "alpha-case.md")
    assert tampered_markdown["sha256_ok"] is False

    cli_tampered = CliRunner().invoke(
        app,
        ["reports-verify", str(manifest_path), "--case", "alpha", "--json"],
    )

    assert cli_tampered.exit_code != 0
    assert json.loads(cli_tampered.output)["checks"]["sha256"] is False


def test_integrity_hash_regressions_detect_newlines_and_missing_vault_artifacts(tmp_path: Path):
    from bedniiosint.evidence.hashing import sha256_file
    from bedniiosint.evidence.snapshot import save_html_snapshot, save_json_snapshot

    html_path, html_digest = save_html_snapshot(
        "<html>\n<body>alpha</body>\n</html>\n",
        tmp_path / "vault" / "html",
        "alpha",
    )
    json_path, json_digest = save_json_snapshot(
        {"lines": ["alpha\nbeta", "gamma"], "nested": {"value": "x\ny"}},
        tmp_path / "vault" / "raw",
        "alpha",
    )

    assert sha256_file(html_path) == html_digest
    assert sha256_file(json_path) == json_digest


def test_v09_case_workspace_forensic_trail_and_manual_workflow(tmp_path: Path):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("workspace"))
        with storage.session() as session:
            case = Case(name="workspace", target="bob", module="test")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(Entity(case_id=case.id, type="username", value="bob"))
            session.add(
                Source(
                    case_id=case.id,
                    name="Example",
                    source_id="api:example",
                    url_main="https://example.test",
                    category="profile",
                    adapter="catalog-http",
                    reliability=0.8,
                    success_count=8,
                    error_count=2,
                    health_status="available",
                    version="1.2.3",
                )
            )
            finding = Finding(
                case_id=case.id,
                source_name="Example",
                source_id="api:example",
                source_reliability=0.8,
                entity_type="username",
                entity_value="bob",
                finding_type="profile",
                profile_url="https://example.test/bob?api_key=secret",
                status="exists",
                confidence=0.91,
                confidence_reason="direct profile marker",
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            case_id = case.id
            finding_id = finding.id

        capture_raw_result(
            storage,
            case_name="workspace",
            case_id=case_id,
            finding_id=finding_id,
            source_module="test",
            payload={"profile": "bob"},
            url="https://example.test/bob?api_key=secret",
            final_url="https://example.test/bob",
            http_status=200,
            confidence=0.91,
            name_hint="Example",
            headers={"content-type": "application/json"},
            adapter_version="adapter/1.2.3",
        )

        note = add_note(
            "workspace",
            entity_type="username",
            entity_value="bob",
            note="Manual analyst note",
        )
        event = add_manual_event(
            "workspace",
            kind="posted",
            entity_type="profile",
            entity_value="https://example.test/bob",
            confidence=0.7,
            description="Manual event",
        )
        relation = add_manual_relation(
            "workspace",
            src_type="username",
            src_value="bob",
            rel="analyst_links",
            dst_type="profile",
            dst_value="https://example.test/bob",
        )

        workspace = get_workspace(
            "workspace",
            filters=WorkspaceFilters(source="api:example", min_confidence=0.9),
        )
        detail = get_finding_detail("workspace", finding_id)
        manifest = evidence_manifest(storage, case_id)

        assert workspace["counts"]["findings"] == 1
        assert workspace["sources"][0]["health"]["historical_success_rate"] == 0.8
        assert workspace["findings"][0]["evidence_count"] == 1
        assert workspace["integrity"]["secrets_returned"] is False
        assert workspace["integrity"]["evidence_vault"]["files"] >= 1
        assert workspace["integrity"]["evidence_vault"]["covered"] >= 1
        assert workspace["integrity"]["evidence_vault"]["sha256_ok"] >= 1
        assert "reports" in workspace["integrity"]
        assert workspace["notes"][0]["id"] == note["id"]
        assert event["confidence"] == 0.7
        assert relation["rel"] == "analyst_links"
        assert detail["attachments"][0]["preview"].startswith("{")
        assert detail["evidence"][0]["adapter_version"] == "adapter/1.2.3"
        assert detail["evidence"][0]["query_params"]["api_key"] == "[redacted]"
        assert manifest["schema_version"] == "0.3"
        assert manifest["forensic"]["chain_of_custody"]
        assert manifest["evidence"][0]["query_params"]["api_key"] == "[redacted]"
        assert manifest["chain_of_custody"][0]["source_adapter_version"] == "adapter/1.2.3"
        artifact_path = Path(workspace["integrity"]["evidence_vault"]["items"][0]["path"])
        artifact_path.unlink()
        missing_workspace = get_workspace("workspace")
        assert missing_workspace["integrity"]["evidence_vault"]["existing"] == 0
        assert missing_workspace["integrity"]["evidence_vault"]["sha256_ok"] == 0
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_evidence_vault_html_capture_adds_optional_screenshot_attachment(
    tmp_path: Path,
    monkeypatch,
):
    import bedniiosint.evidence.capture as capture_module
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)

    def fake_capture_screenshot(url: str, vault_dir: Path, name_hint: str, timeout_ms: int = 15000):
        vault_dir.mkdir(parents=True, exist_ok=True)
        path = vault_dir / f"{name_hint}.png"
        path.write_bytes(b"\x89PNG\r\n\x1a\nscreenshot")
        return path

    monkeypatch.setattr(capture_module, "screenshots_available", lambda: True)
    monkeypatch.setattr(capture_module, "capture_screenshot", fake_capture_screenshot)
    try:
        storage = Storage(settings.db_path("shot-case"))
        with storage.session() as session:
            case = Case(name="shot-case", target="https://example.test", module="url")
            session.add(case)
            session.commit()
            session.refresh(case)
            finding = Finding(
                case_id=case.id,
                source_name="urlscan",
                source_id="api:urlscan",
                entity_type="url",
                entity_value="https://example.test",
                status="exists",
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            case_id = case.id
            finding_id = finding.id

        capture_html_result(
            storage,
            case_name="shot-case",
            case_id=case_id,
            finding_id=finding_id,
            source_module="url_pipeline",
            html="<html><body>screen me</body></html>",
            url="https://example.test/?api_key=secret",
            final_url="https://example.test/final",
            http_status=200,
            confidence=0.8,
            name_hint="urlscan",
            headers={"content-type": "text/html"},
            method="POST",
            adapter_version="adapter/shot",
        )
        workspace = get_workspace("shot-case")
        manifest = evidence_manifest(storage, case_id)

        attachments = {row["kind"]: row for row in workspace["attachments"]}
        screenshot = attachments["screenshot"]
        html = attachments["html_snapshot"]
        screenshot_manifest = next(row for row in manifest["attachments"] if row["kind"] == "screenshot")
        custody = next(row for row in manifest["chain_of_custody"] if row["kind"] == "screenshot")

        assert workspace["counts"]["attachments"] == 2
        assert workspace["counts"]["evidence"] == 1
        assert screenshot["mime"] == "image/png"
        assert screenshot["source_adapter_version"] == "adapter/shot"
        assert screenshot["metadata"]["method"] == "POST"
        assert screenshot["metadata"]["related_html_sha256"] == html["sha256"]
        assert screenshot_manifest["artifact"]["exists"] is True
        assert custody["metadata"]["final_url"] == "https://example.test/final"
        assert custody["source_adapter_version"] == "adapter/shot"
        assert manifest["evidence"][0]["query_params"]["api_key"] == "[redacted]"
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_graph_editor_entity_merge_split_and_relation_mutations(tmp_path: Path):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("graph-edit"))
        with storage.session() as session:
            case = Case(name="graph-edit", target="bob", module="test")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(Entity(case_id=case.id, type="username", value="bob"))
            session.add(Entity(case_id=case.id, type="profile", value="https://x/bob"))
            finding = Finding(
                case_id=case.id,
                source_name="Example",
                source_id="api:example",
                entity_type="username",
                entity_value="bob",
                finding_type="profile",
                profile_url="https://x/bob",
                status="exists",
                confidence=0.9,
            )
            session.add(finding)
            session.commit()
            case_id = case.id

        add_manual_event(
            "graph-edit",
            kind="seen",
            entity_type="username",
            entity_value="bob",
            description="Original event",
        )
        add_note(
            "graph-edit",
            entity_type="username",
            entity_value="bob",
            note="Original note",
        )
        relation = add_manual_relation(
            "graph-edit",
            src_type="username",
            src_value="bob",
            rel="same_username",
            dst_type="profile",
            dst_value="https://x/bob",
        )

        updated = update_manual_relation(
            "graph-edit",
            relation["id"],
            src_type="username",
            src_value="bob",
            rel="owns_profile",
            dst_type="profile",
            dst_value="https://x/bob",
        )
        split = split_entity(
            "graph-edit",
            entity_type="username",
            entity_value="bob",
            new_type="alias",
            new_value="bobby",
            rel="alias_of",
            note="Split alias",
        )
        merged = merge_entities(
            "graph-edit",
            from_type="username",
            from_value="bob",
            into_type="person",
            into_value="Robert B",
            note="Merged username into person",
        )

        workspace = get_workspace("graph-edit")
        entity_pairs = {(row["type"], row["value"]) for row in workspace["entities"]}
        relation_pairs = {
            (row["src_type"], row["src_value"], row["rel"], row["dst_type"], row["dst_value"])
            for row in workspace["relations"]
        }
        notes = {(row["entity_type"], row["entity_value"], row["note"]) for row in workspace["notes"]}

        assert updated["rel"] == "owns_profile"
        assert split["relation"]["rel"] == "alias_of"
        assert merged["changed"]["findings"] == 1
        assert ("person", "Robert B") in entity_pairs
        assert ("alias", "bobby") in entity_pairs
        assert ("username", "bob") not in entity_pairs
        assert ("person", "Robert B", "owns_profile", "profile", "https://x/bob") in relation_pairs
        assert ("alias", "bobby", "alias_of", "person", "Robert B") in relation_pairs
        assert ("person", "Robert B", "Original note") in notes
        assert ("person", "Robert B", "Merged username into person") in notes
        assert ("alias", "bobby", "Split alias") in notes
        assert workspace["findings"][0]["entity_type"] == "person"
        assert workspace["findings"][0]["entity_value"] == "Robert B"
        assert workspace["timeline"][0]["entity_type"] == "person"
        assert workspace["timeline"][0]["entity_value"] == "Robert B"
        resolution = workspace["entity_resolution"]
        canonical_people = [
            row
            for row in resolution["canonical_entities"]
            if row["type"] == "person" and row["value"] == "robert b"
        ]
        assert canonical_people
        assert "Robert B" in canonical_people[0]["display_values"]
        assert resolution["alias_links"][0]["rel"] == "alias_of"
        assert resolution["alias_links"][0]["reason"] == "explicit_relation:alias_of"

        deleted = delete_manual_relation("graph-edit", relation["id"])
        assert deleted["deleted"]
        workspace = get_workspace("graph-edit")
        assert all(row["id"] != relation["id"] for row in workspace["relations"])
        assert workspace["graph"]["metrics"]["nodes"] >= 2
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_case_dedupe_preserves_finding_references(tmp_path: Path):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        storage = Storage(settings.db_path("dedupe"))
        raw_path = tmp_path / "raw.json"
        raw_path.write_text("{}", encoding="utf-8")
        with storage.session() as session:
            case = Case(name="dedupe", target="bob", module="test")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(Entity(case_id=case.id, type="username", value="bob"))
            session.add(Entity(case_id=case.id, type="username", value="bob"))
            session.add(
                Relation(
                    case_id=case.id,
                    src_type="username",
                    src_value="bob",
                    rel="same",
                    dst_type="profile",
                    dst_value="https://x/bob",
                )
            )
            session.add(
                Relation(
                    case_id=case.id,
                    src_type="username",
                    src_value="bob",
                    rel="same",
                    dst_type="profile",
                    dst_value="https://x/bob",
                )
            )
            low = Finding(
                case_id=case.id,
                source_name="Example",
                source_id="api:example",
                entity_type="username",
                entity_value="bob",
                finding_type="profile",
                profile_url="https://x/bob",
                status="exists",
                confidence=0.4,
            )
            high = Finding(
                case_id=case.id,
                source_name="Example",
                source_id="api:example",
                entity_type="username",
                entity_value="bob",
                finding_type="profile",
                profile_url="https://x/bob",
                status="exists",
                confidence=0.9,
            )
            session.add(low)
            session.add(high)
            session.commit()
            session.refresh(low)
            session.refresh(high)
            session.add(
                Evidence(
                    case_id=case.id,
                    finding_id=low.id,
                    url="https://x/bob",
                    final_url="https://x/bob",
                    sha256="abc",
                )
            )
            session.add(
                Attachment(
                    case_id=case.id,
                    finding_id=low.id,
                    kind="raw_json",
                    path=str(raw_path),
                    sha256="abc",
                    mime="application/json",
                )
            )
            session.add(
                TimelineEvent(
                    case_id=case.id,
                    finding_id=low.id,
                    kind="seen",
                    entity_type="username",
                    entity_value="bob",
                )
            )
            session.commit()
            keep_id = high.id

        result = dedupe_case("dedupe")
        workspace = get_workspace("dedupe")
        with storage.session() as session:
            evidence = session.query(Evidence).filter(Evidence.case_id == 1).first()
            attachment = session.query(Attachment).filter(Attachment.case_id == 1).first()
            event = session.query(TimelineEvent).filter(TimelineEvent.case_id == 1).first()

        assert result["removed"] == {"entities": 1, "relations": 1, "findings": 1}
        assert workspace["counts"]["entities"] == 1
        assert workspace["counts"]["relations"] == 1
        assert workspace["counts"]["findings"] == 1
        assert workspace["findings"][0]["confidence"] == 0.9
        assert evidence.finding_id == keep_id
        assert attachment.finding_id == keep_id
        assert event.finding_id == keep_id
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_case_merge_archive_import_and_schema_status(tmp_path: Path):
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)
    try:
        target_storage = Storage(settings.db_path("target"))
        with target_storage.session() as session:
            case = Case(name="target", target="alice", module="test")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(Entity(case_id=case.id, type="username", value="alice"))
            session.add(
                Finding(
                    case_id=case.id,
                    source_name="target-source",
                    entity_value="alice",
                    status="exists",
                    confidence=0.5,
                )
            )
            session.commit()

        source_storage = Storage(settings.db_path("source"))
        with source_storage.session() as session:
            case = Case(name="source", target="bob", module="test")
            session.add(case)
            session.commit()
            session.refresh(case)
            session.add(Entity(case_id=case.id, type="username", value="bob"))
            finding = Finding(
                case_id=case.id,
                source_name="source-source",
                entity_value="bob",
                status="exists",
                confidence=0.9,
            )
            session.add(finding)
            session.commit()
            session.refresh(finding)
            session.add(
                Evidence(
                    case_id=case.id,
                    finding_id=finding.id,
                    url="https://example.test/bob",
                    final_url="https://example.test/bob",
                    http_status=200,
                    sha256="abc",
                    body_len=3,
                )
            )
            session.add(
                Attachment(
                    case_id=case.id,
                    finding_id=finding.id,
                    kind="raw_json",
                    path="artifact.json",
                    sha256="abc",
                )
            )
            session.add(
                TimelineEvent(
                    case_id=case.id,
                    finding_id=finding.id,
                    kind="observed",
                    entity_type="username",
                    entity_value="bob",
                )
            )
            session.commit()

        merged = merge_cases("target", "source")
        workspace = get_workspace("target")
        with target_storage.session() as session:
            source_finding = (
                session.query(Finding)
                .filter(Finding.source_name == "source-source")
                .first()
            )
            evidence = (
                session.query(Evidence)
                .filter(Evidence.url == "https://example.test/bob")
                .first()
            )

        archive = archive_case("target", tmp_path / "archives")
        imported = import_case_archive(archive, case_name="imported")
        imported_summary = build_case_summary("imported")
        schema = schema_status("imported")

        assert merged["merged"]["findings"] == 1
        assert workspace["counts"]["findings"] == 2
        assert source_finding is not None
        assert evidence.finding_id == source_finding.id
        assert archive.exists()
        assert imported["case"] == "imported"
        assert imported_summary["meta"]["found"]
        assert schema["current_version"] >= 3
        assert schema["applied"]
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)


def test_username_high_confidence_enrichment(tmp_path: Path, monkeypatch):
    import bedniiosint.core.case as case_module
    from bedniiosint.config import settings

    original_db_dir = settings.db_dir
    object.__setattr__(settings, "db_dir", tmp_path)

    def fake_fetch_and_parse(url: str):
        return (
            ProfileData(
                avatar_url="https://cdn.example/avatar.png",
                social_links={"github": ["https://github.com/bob"]},
                emails=["bob@example.com"],
                wallets={"eth": ["0x" + "a" * 40]},
            ),
            "<html><body>bob@example.com</body></html>",
            200,
        )

    monkeypatch.setattr(case_module, "fetch_and_parse", fake_fetch_and_parse)
    try:
        result = SiteResult(
            site_name="Example",
            url_main="https://example.com",
            category="social",
            probe_url="https://example.com/bob",
            display_url="https://example.com/bob",
            status="exists",
            status_code=200,
            final_url="https://example.com/bob",
            redirected=False,
            page_title="Bob",
            matched_markers=["e_code:200"],
            confidence=1.0,
            source_reliability=1.0,
            reliability_note="ok",
            control_passed=True,
            body_sha256="abc",
            body_len=3,
        )
        summary = UsernameCase("enriched", "bob")._persist([result])
        storage = Storage(settings.db_path("enriched"))
        with storage.session() as session:
            entities = session.query(Entity).filter(Entity.case_id == 1).all()
            relations = session.query(Relation).filter(Relation.case_id == 1).all()
            events = session.query(TimelineEvent).filter(TimelineEvent.case_id == 1).all()
            attachments = session.query(Attachment).filter(Attachment.case_id == 1).all()

        entity_values = {entity.value for entity in entities}
        relation_names = {relation.rel for relation in relations}

        assert summary["high"][0]["site"] == "Example"
        assert "bob@example.com" in entity_values
        assert "https://cdn.example/avatar.png" in entity_values
        assert {"same_social_link", "uses_email", "has_avatar", "uses_eth_wallet"}.issubset(
            relation_names
        )
        assert events and events[0].kind == "first_seen"
        attachment_kinds = {attachment.kind for attachment in attachments}
        assert {"raw_json", "html_snapshot"}.issubset(attachment_kinds)
    finally:
        object.__setattr__(settings, "db_dir", original_db_dir)
