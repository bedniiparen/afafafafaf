from __future__ import annotations

from pathlib import Path

import pytest

from bedniiosint.storage.models import ALL_MODELS

sqlalchemy = pytest.importorskip("sqlalchemy")


def test_sqlalchemy_metadata_matches_legacy_storage_models():
    from bedniiosint.storage.sqlalchemy_schema import STORAGE_METADATA

    assert set(STORAGE_METADATA.tables) == {model.table_name() for model in ALL_MODELS}
    for model in ALL_MODELS:
        table = STORAGE_METADATA.tables[model.table_name()]
        assert tuple(table.columns.keys()) == model.__columns__
        for column_name in model.__columns__:
            column = table.columns[column_name]
            assert column.primary_key is ("PRIMARY KEY" in model.__types__[column_name].upper())


def test_sqlalchemy_metadata_can_create_existing_tables(tmp_path: Path):
    from sqlalchemy import create_engine, inspect

    from bedniiosint.storage.sqlalchemy_schema import STORAGE_METADATA

    db_path = tmp_path / "case.db"
    engine = create_engine(f"sqlite:///{db_path}")
    STORAGE_METADATA.create_all(engine)
    inspector = inspect(engine)

    assert set(inspector.get_table_names()) == {model.table_name() for model in ALL_MODELS}
    for model in ALL_MODELS:
        created_columns = tuple(column["name"] for column in inspector.get_columns(model.table_name()))
        assert created_columns == model.__columns__


def test_sqlmodel_schema_mirrors_legacy_models_when_installed():
    pytest.importorskip("sqlmodel")

    from bedniiosint.storage.sqlmodel_schema import SQLMODEL_BY_LEGACY

    assert set(SQLMODEL_BY_LEGACY) == set(ALL_MODELS)
    for model in ALL_MODELS:
        sql_model = SQLMODEL_BY_LEGACY[model]
        assert sql_model.__tablename__ == model.table_name()
        assert tuple(sql_model.__table__.columns.keys()) == model.__columns__


def test_sqlmodel_repository_matches_repository_contract_when_installed(tmp_path: Path):
    pytest.importorskip("sqlmodel")

    from bedniiosint.storage.models import Case
    from bedniiosint.storage.sqlmodel_schema import SQLModelRepository
    from bedniiosint.storage.sqlite import Storage

    storage = Storage(tmp_path / "case.db")
    repo = SQLModelRepository(storage.db_path, Case)

    row = repo.add(Case(name="sqlmodel-case", target="alice", module="username"))
    assert row.id is not None
    assert repo.count_by(name="sqlmodel-case") == 1

    row.target = "alice@example.com"
    repo.update(row)

    updated = repo.get(row.id)
    assert updated is not None
    assert updated.target == "alice@example.com"
    assert repo.delete(row) is True
    assert repo.get(row.id) is None
