@echo off
setlocal
cd /d "%~dp0"
title BEDNIIOSINT Launcher

set "BOOTSTRAP=%~dp0scripts\bootstrap_windows.ps1"
if not exist "%BOOTSTRAP%" (
    echo BEDNIIOSINT startup file is missing:
    echo %BOOTSTRAP%
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%BOOTSTRAP%" %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
    echo.
    echo BEDNIIOSINT did not start. See the message above.
    pause
)
exit /b %EXIT_CODE%
