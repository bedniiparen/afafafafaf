# OSINT Sources Catalog for BEDNIIOSINT

Date: 2026-06-06

This document is the readable companion to `data/osint_sources_catalog.json`.
The JSON file is the card-level source of truth with fields for URL, docs,
input types, output data, auth, free tier, risk, quality, complexity, priority,
module name, integration notes, normalized output example and verification
links.

## Current BEDNIIOSINT Inventory

BEDNIIOSINT already has a useful base:

- Built-in modules: username, email, domain, IP, phone, wallet, company,
  metadata and URL/profile analysis.
- Current source registry: 56 API/source entries in
  `bedniiosint/catalog/osint_sources.json`.
- Existing pipeline families: username, email, domain, IP, phone, wallet,
  company, URL, address/place and generic query.
- Existing architecture: source adapter registry, generic HTTP adapters,
  normalization, source provenance, evidence capture, confidence scoring,
  source reliability, cache/rate-limit context, legal scope flags, job queue,
  graph export, STIX JSON export, HTML/PDF/CSV/JSON reports and tests.
- Search-only dork expansion: normal `search-run --dorking` can add low-priority
  manual `site:domain "target"` leads from public domain discovery lists without
  mixing those domains into the verified username scanner.

The project is strongest in:

- username checks with false-positive controls;
- basic email/domain/IP/phone/wallet/company/metadata modules;
- evidence and report generation;
- graph and timeline output;
- generic adapter scaffolding.

The project is still weak in:

- successful live verification against user-provided commercial API keys;
- passive internet-exposure intelligence depth;
- legal breach exposure breadth beyond HIBP;
- media verification workflows;
- public datasets and news/media correlation;
- jurisdiction-specific business registry breadth;
- STIX/TAXII import/export interoperability beyond basic export;
- live media/provider checks with real provider accounts.

## Catalog Summary

- Total sources/tools/workflows cataloged: 89
- P0: 13
- P1: 32
- P2: 34
- P3: 5
- Reject: 5

P0 means high product value, legally usable in normal public OSINT workflows
and worth implementing first. Reject means do not integrate.

## Full Readable Catalog

| Source | Category | Type | Priority | Risk | Product value | Integration decision |
|---|---|---:|---:|---:|---:|---|
| RDAP.org | WHOIS / RDAP | API | P0 | low | high | Keep as core domain/IP registration source. |
| crt.sh | Certificate transparency | website/API | P0 | low | high | Keep as first CT subdomain source. |
| Google Public DNS over HTTPS | DNS | API | P0 | low | high | Keep as core DNS enrichment. |
| Cloudflare DNS over HTTPS | DNS | API | P1 | low | medium | Add as second resolver for corroboration. |
| SecurityTrails API | Domain intelligence | API | P1 | medium | high | Add for historical DNS/subdomains when key exists. |
| Shodan API | Exposed services | API | P1 | medium | high | Add passive service exposure enrichment. |
| Censys Search API | Exposed services | API | P1 | medium | high | Add passive host/cert/service enrichment. |
| VirusTotal API v3 | URL/hash/domain reputation | API | P0 | medium | high | Add lookup-first reputation adapter. |
| urlscan.io API | URL reputation | API | P0 | medium | high | Add search/result first; submission opt-in only. |
| AbuseIPDB API | IP reputation | API | P1 | medium | medium | Add as corroborating IP abuse score. |
| GreyNoise API | IP intelligence | API | P1 | low | high | Add internet-noise classification. |
| AlienVault OTX | Threat intelligence | API | P1 | medium | high | Add pulse/IOC enrichment with confidence caveats. |
| URLhaus API | Malware / TI | API | P0 | low | high | Add safe URL/hash malware lookup. |
| ThreatFox API | Malware / TI | API | P1 | low | high | Add IOC enrichment. |
| MalwareBazaar API | File hash reputation | API | P1 | medium | medium | Lookup hashes only; no malware download. |
| Have I Been Pwned API | Legal breach exposure | API | P0 | medium | high | Keep/add as only default breach source. |
| EmailRep | Email intelligence | API | P1 | medium | medium | Add reputation signal with caveats. |
| Hunter.io API | Email intelligence | API | P1 | medium | medium | Add domain/company email pattern enrichment. |
| Gravatar | Email intelligence | website/API | P2 | medium | medium | Keep as public profile/avatar hint. |
| GitHub REST API | Developer footprint | API | P0 | low | high | Keep as core developer footprint source. |
| GitLab REST API | Developer footprint | API | P1 | low | medium | Add after GitHub. |
| Reddit API | Public social media | API | P2 | medium | medium | Optional official public-content adapter. |
| YouTube Data API v3 | Media search | API | P2 | medium | medium | Optional channel/video metadata adapter. |
| Google Programmable Search | Search engines | API | P2 | medium | medium | Optional search enrichment. |
| Wayback CDX API | Archive search | API | P0 | low | high | Keep/add as core historical URL source. |
| archive.today / archive.is | Archive search | website | P3 | medium | medium | Manual links only; no default automation. |
| OpenCorporates API | Company lookup | API | P1 | medium | high | Add legal entity enrichment. |
| Companies House API | Business registry | API | P1 | medium | high | Add UK registry adapter. |
| Wikidata API / SPARQL | Graph enrichment | API/dataset | P0 | low | high | Keep/add canonical IDs and graph links. |
| OpenSanctions | Public datasets | API/dataset | P2 | high | medium | Compliance/threat-intel mode only. |
| GDELT 2.1 API | News/media | API/dataset | P2 | medium | medium | Add media timeline enrichment later. |
| Common Crawl Index | Public datasets | API/dataset | P2 | medium | medium | Add historical URL discovery later. |
| BuiltWith API | Web technology | API | P2 | medium | medium | Optional paid tech-stack source. |
| Wappalyzer API | Web technology | API | P2 | medium | medium | Optional tech-stack corroboration. |
| BGPView API | ASN / BGP | API | P0 | low | high | Keep as core ASN enrichment. |
| PeeringDB API | ASN / BGP | API | P1 | low | medium | Add network/org graph context. |
| IPinfo API | IP intelligence | API | P1 | medium | high | Add token-backed richer IP context. |
| ipwho.is | IP intelligence | API | P0 | low | high | Keep as no-key IP context source. |
| Nominatim | Maps/geolocation | API | P1 | medium | medium | Add strict policy-compliant geocoder. |
| Overpass API | Maps/geolocation | API | P2 | medium | medium | Add later for geo context. |
| TinEye API | Reverse image search | API | P2 | medium | medium | Optional media verification with consent. |
| ExifTool | Metadata | open-source tool | P0 | low | high | Keep as core local metadata extractor. |
| InVID-WeVerify plugin | Media verification | free/open tool | P2 | medium | medium | Use workflow ideas; API not confirmed. |
| Blockchain.com Explorer API | Blockchain lookup | API | P1 | medium | medium | Keep/add BTC public lookup. |
| Blockchair API | Crypto intelligence | API | P1 | medium | medium | Add multi-chain lookup with chain-aware schema. |
| Blockscout API | Blockchain lookup | API/open platform | P2 | medium | medium | Add EVM explorer pattern later. |
| Twilio Lookup API | Phone intelligence | API | P1 | high | medium | Authorized phone mode only. |
| Veriphone API | Phone intelligence | API | P2 | medium | medium | Optional phone validation source. |
| numverify API | Phone intelligence | API | P2 | medium | low | Lower priority after local libphonenumber. |
| OpenCTI connectors | STIX/TAXII TI | open-source collection | P1 | medium | high | Study connector mapping; integrate patterns. |
| MISP API | STIX/TAXII TI | API/open platform | P1 | medium | high | Add import/export compatibility later. |
| SpiderFoot | OSINT platform | open-source tool | P1 | medium | high | Study module/event architecture. |
| Maltego Transform Hub | Graph enrichment | platform | P2 | medium | high | Study transform UX and graph model. |
| Recon-ng | OSINT framework | open-source tool | P2 | medium | medium | Study workspaces/marketplace only. |
| theHarvester | Domain intelligence | open-source tool | P1 | medium | high | Study source categories; reimplement cleanly. |
| Sherlock | Username search | open-source tool | P1 | medium | high | Use as coverage benchmark. |
| Maigret | Username search | open-source tool | P1 | medium | high | Use as coverage/report benchmark. |
| WhatsMyName | Username search | dataset/tool | P1 | medium | high | Use after license/ToS review. |
| Nexfil | Username search | open-source tool | P1 | medium | medium | Import additional URL templates with attribution. |
| Amass | Domain intelligence | open-source tool | P1 | medium | high | Study passive enum and graph model. |
| Subfinder | Domain intelligence | open-source tool | P1 | medium | high | Study passive source handling. |
| Nuclei templates | Active checks | open-source templates | P2 | high | medium | Opt-in authorized active-check plugin only. |
| Metagoofil | Metadata | open-source tool | P2 | high | medium | Workflow idea only; avoid default harvesting. |
| FOCA | Metadata | open-source tool | P3 | high | low | Historical benchmark; prefer ExifTool. |
| Photon | Crawling | open-source tool | P3 | high | low | Avoid default crawler; scoped opt-in only. |
| OSINT Framework | OSINT catalog | website/catalog | P2 | low | medium | Taxonomy/discovery reference. |
| Bellingcat Toolkit | OSINT catalog | website/catalog | P1 | low | high | Media verification workflow reference. |
| Awesome OSINT | OSINT catalog | GitHub catalog | P2 | low | medium | Discovery seed only. |
| API-s-for-OSINT | OSINT API catalog | GitHub catalog | P1 | low | high | API discovery seed. |
| Cyber Detective OSINT Map | OSINT catalog | website/catalog | P2 | low | medium | Tool discovery seed. |
| GHunt | Google account OSINT | open-source tool | reject | high | medium | Do not integrate; ToS/privacy risk. |
| Holehe | Email enumeration | open-source tool | reject | high | medium | Do not integrate; reset/register enumeration. |
| Social Analyzer | Social media automation | open-source tool | reject | high | medium | Do not integrate; automation/ToS risk. |
| Raw leaked databases / combolists | Breach data | dataset | reject | high | reject | Never integrate. |
| Credential stuffing / account checks | Prohibited workflow | workflow | reject | high | reject | Never implement. |

## BEDNIIOSINT Gap Analysis

| Category | Exists now | Current quality | Missing sources | Recommended sources | Priority | Difficulty | User value |
|---|---:|---|---|---|---:|---:|---:|
| Domain/DNS/RDAP | yes | good baseline | historical DNS depth | SecurityTrails | P1 | medium | high |
| Certificate transparency | yes | good | secondary CT sources | CertSpotter-style adapter later, Censys certs | P1 | medium | high |
| IP/ASN | partial | useful baseline | better ASN/org/noise context | BGPView, PeeringDB, GreyNoise, IPinfo | P0/P1 | low/medium | high |
| Internet exposure | partial | cataloged, key-dependent | Shodan/Censys typed adapters | Shodan, Censys | P1 | medium | high |
| URL/hash reputation | partial | cataloged | safer TI normalization | VirusTotal, urlscan, URLhaus, ThreatFox | P0/P1 | medium | high |
| Legal breach exposure | partial | HIBP only | no alternative legal sources | HIBP only by default | P0 | medium | high |
| Username search | yes | strong local checks | coverage benchmark/license review | Sherlock, Maigret, WhatsMyName | P1 | medium | high |
| Email intelligence | partial | DNS/Gravatar/HIBP | reputation and domain email context | EmailRep, Hunter | P1 | medium | medium |
| Phone intelligence | partial | local parsing | authorized carrier/line data | Twilio Lookup, Veriphone | P1/P2 | medium | medium |
| Company registry | partial | OpenCorporates optional | jurisdiction depth | Companies House, Wikidata, OpenCorporates | P1 | medium | high |
| Developer footprint | partial | GitHub/GitLab cataloged | deeper graph from repos/orgs | GitHub REST, GitLab REST | P0/P1 | medium | high |
| Archive search | partial | Wayback cataloged | report-ready timeline | Wayback CDX | P0 | low | high |
| Media verification | no/weak | metadata only | image reverse search, keyframes | TinEye, InVID workflow | P2 | medium/high | medium |
| Maps/geolocation | partial | Nominatim cataloged | policy-safe geo workflow | Nominatim, Overpass | P1/P2 | medium | medium |
| STIX/TAXII | partial | STIX export exists | import/connector compatibility | MISP, OpenCTI | P1/P2 | high | high |
| Public datasets/news | weak | limited | media and public datasets | GDELT, Common Crawl, OpenSanctions | P2 | high | medium |
| Legal/privacy controls | partial | improved flags exist | per-source policy enforcement | legal filter + source context | P0 | medium | high |
| Tests/mocks | yes | strict gate green | live-account validation | user-provided API accounts | P1 | medium | high |

## Verification Notes

- API limits/prices are marked `not confirmed` unless the current exact values
  were confirmed from official docs during implementation planning.
- Catalog sites are discovery references only; they are not authoritative proof
  of API behavior.
- Open-source project code must not be copied without license review, especially
  GPL/AGPL projects.
- High-risk people, phone, breach and social sources must not be default bulk
  workflows.
