# Data Layer Migration

The current storage layer uses a hand-written mini ORM in `storage/models.py`
and `storage/sqlite.py`. This keeps the project dependency-light, but it is not
the right long-term layer for a large OSS project.

## Target

- SQLModel models for cases, entities, findings, relations, evidence,
  attachments, timeline events, jobs, source health and live validation.
- A thin repository layer so the rest of the code does not depend on SQLModel
  query syntax.
- Alembic-style migrations or a small migration runner built on SQLAlchemy.
- Compatibility readers for old SQLite case databases.

## Safe Migration Path

1. Add SQLAlchemy/SQLModel tables beside existing models.
2. Introduce repositories with the same behavior as current helper functions.
3. Add dual-write tests for critical case flows.
4. Add importer from legacy SQLite schema to SQLModel schema.
5. Switch read paths one domain at a time.
6. Remove the hand-written ORM only after all tests and legacy import pass.

## Current Increment

- `bedniiosint/storage/sqlalchemy_schema.py` builds SQLAlchemy `MetaData` from
  the current `ALL_MODELS` registry.
- `bedniiosint/storage/repositories.py` adds a thin SQLAlchemy repository layer.
- `core/case_lookup.py` now reads case rows and IDs through `CaseRepository`,
  making case lookup the first production read path moved off the hand-written
  query API.
- `core/case_summary.py` now reads case-scoped findings, entities, relations,
  evidence, sources, attachments and notes through `ModelRepository`
  `list_by_values()` instead of legacy `session.query(...)`.
- Tests verify that generated SQLAlchemy tables and columns match the legacy
  model schema and can create the current SQLite tables.
- Dual-path tests verify that rows written by legacy storage are readable by
  `CaseRepository`/`ModelRepository`, and rows written by `CaseRepository`
  remain readable by the legacy session.
- Most runtime reads/writes still use `storage/sqlite.py`; the next safe step is
  moving another table family behind repositories.

## Risk

This is a schema-level migration. It must not be done as a blind rewrite inside
the web UI or CLI refactor. The safe unit is one table family at a time.
