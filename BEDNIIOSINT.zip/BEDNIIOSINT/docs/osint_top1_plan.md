# BEDNIIOSINT Top-1 Plan

Goal: make BEDNIIOSINT a strong legal OSINT case builder, not an unsafe
scraper. The fastest path is to improve source quality, normalization,
evidence, reports and test discipline.

## Final Metrics From This Research Pass

- Sources/tools/workflows cataloged: 89
- Runtime API/source entries with offline quality gate coverage: 56
- P0 sources: 13
- P1 sources: 32
- Reject entries: 5
- Machine-readable catalog: `data/osint_sources_catalog.json`

## Top 20 Sources to Add First

1. RDAP.org
2. crt.sh
3. Google Public DNS over HTTPS
4. Cloudflare DNS over HTTPS
5. URLhaus
6. VirusTotal lookup
7. urlscan.io search/result
8. Have I Been Pwned
9. GitHub REST API
10. Wayback CDX
11. Wikidata
12. BGPView
13. ipwho.is
14. GreyNoise
15. SecurityTrails
16. Censys
17. Shodan
18. AlienVault OTX
19. ThreatFox
20. OpenCorporates / Companies House

## Top 10 Open-Source Projects to Learn From

1. SpiderFoot: event/module graph.
2. OpenCTI connectors: connector discipline and STIX mapping.
3. MISP: event/attribute model and TI exchange.
4. theHarvester: domain investigation source breadth.
5. Sherlock: username coverage.
6. Maigret: username report shape.
7. WhatsMyName: source definition schema.
8. Amass: passive domain graph.
9. Subfinder: source configuration and passive discovery.
10. Recon-ng: workspace/module marketplace ideas.

## Top 10 Weak BEDNIIOSINT Categories

1. Keyed passive internet-exposure APIs.
2. Legal breach exposure beyond HIBP.
3. Media/photo/video verification.
4. Public datasets and news/media timelines.
5. Business registry coverage outside OpenCorporates.
6. STIX/TAXII import and connector compatibility.
7. Live validation against real user-provided API accounts.
8. Source health/maintenance dashboarding.
9. Per-source legal/privacy enforcement in UI.
10. High-quality official API setup guidance.

## Product Architecture Target

BEDNIIOSINT should converge on:

- unified source adapter interface;
- module registry with source policy;
- normalized entity schema;
- source provenance for every finding;
- confidence scoring with independent corroboration;
- deterministic deduplication;
- cache and rate limiter;
- retries/backoff;
- API key/secrets manager using env vars first;
- resumable job queue;
- error taxonomy;
- report enrichment;
- graph relationship model;
- mocked API response tests.

## What to Do First

1. Treat `data/osint_sources_catalog.json` as the product source backlog.
2. Keep P0 typed parsers and strict source-quality gate green.
3. Add source policy enforcement to pipeline source selection.
4. Expand reports with:
   - independent corroboration count;
   - not confirmed section;
   - source risk label;
   - human review flag.
5. Add keyed-source setup UI for P1 APIs.
6. Add media verification only after upload/privacy safeguards.
7. Keep reject workflows out of the product.

## Recently Closed

- Strict offline source-quality gate is green for 56 runtime API/source entries.
- Worker/job durability uses claimed worker ids, claim timestamps, heartbeat
  timestamps and stale job recovery.
- Domain pipeline corroborates matching Google DNS and Cloudflare DNS answers.
- Persisted source provenance and reports include passive-only and
  sensitive-data policy labels.
- `/api-keys` includes a P1 keyed-source setup panel; `/api-keys/setup` returns
  a safe JSON plan with blank env-var templates only.
- `source-maintenance`, `/sources/maintenance` and the dashboard `/sources`
  maintenance panel provide offline source readiness scoring, fixture coverage,
  top actions and live-validation summaries without provider network calls.
- Unified reports now include report-ready source health history in
  JSON/HTML/Markdown and CSV exports.
- `live-plan --account-runbook` exports an offline keyed-provider account
  validation runbook with env var names and safe opt-in commands, without
  printing secret values.
- `source-verify --mode live --record-live-result` and `live-results` provide
  mocked-test-covered, opt-in persistence/reporting for user-approved live
  validation outcomes with secret redaction.
- `/live-results` and `/live-results/view` add dashboard/API access to
  persisted live-validation history with source/run filters and retention
  guidance.
- Live-validation history now has explicit CSV/JSON/Markdown export and
  retention cleanup controls; cleanup is dry-run until an apply control is set.
- Live-validation export/cleanup actions now write audit events available from
  CLI and dashboard/API, with filters/counts/channel labels and no secret
  values.
- Live-validation file exports now write sidecar hash manifests with SHA-256,
  byte size and audit event linkage; web exports return matching hash and audit
  headers without storing secret values.
- `live-results-verify` verifies exported live-validation history files against
  sidecar manifests offline and can cross-check embedded audit event metadata
  against the local audit database without provider network calls.
- `reports-manifest.json` now records SHA-256 evidence for generated report
  artifacts and `reports-verify` checks report files against the manifest
  offline, including tamper and missing-file detection.
- `/reports` now surfaces report integrity status, `/reports/verify` exposes
  report manifest verification as JSON, and
  `/reports/evidence-bundle/{case}/inspect` exposes evidence bundle integrity
  status without provider network calls.
- Case workspace exports now include an `integrity` summary for report
  manifest verification, evidence bundle inspection and evidence vault artifact
  hash coverage; snapshot files are written as exact UTF-8 bytes so stored
  SHA-256 values match disk artifacts.
- Integrity regression tests now cover byte-stable snapshot hashes, tampered
  report artifacts and missing evidence vault artifacts without network calls.

## Data Not Confirmed

The catalog intentionally marks these as `not confirmed` unless they should be
checked during implementation:

- exact free-tier limits;
- current paid prices;
- current per-minute/day quotas;
- SDK versions;
- maintenance status for each GitHub project;
- per-source license compatibility for code reuse.

## Files Created

- `docs/osint_sources_catalog.md`
- `data/osint_sources_catalog.json`
- `docs/osint_api_integration_roadmap.md`
- `docs/osint_competitor_source_analysis.md`
- `docs/osint_legal_privacy_filter.md`
- `docs/osint_top1_plan.md`

## Next Codex Prompt

Continue P1 hardening without adding risky production behavior. Add signed or
hashed case archive integrity inspection so archived case databases and vault
files can be verified before import/restore. Keep `source-quality-gate
--strict` green, do not add default live calls, active scans, social scraping,
uploads or rejected sources.
