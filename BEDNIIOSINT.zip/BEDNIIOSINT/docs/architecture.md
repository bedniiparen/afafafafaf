# Architecture

BEDNIIOSINT is a passive-first OSINT case builder.

## Runtime Layers

- `bedniiosint.web`: FastAPI dashboard and browser workspace.
- `bedniiosint.cli`: Typer command line entrypoint.
- `bedniiosint.core`: case orchestration, jobs, evidence, timeline, source
  context, cache policy, monitoring schedules and legal controls.
- `bedniiosint.catalog`: source registry, adapters, parsers, fixture
  verification and source quality gate.
- `bedniiosint.modules`: built-in analyzers for username, email, domain, IP,
  phone, wallet, company, URL and metadata.
- `bedniiosint.reports`: report view model, HTML/Markdown/CSV/STIX/MISP/OpenCTI
  exports and integrity manifests.
- `bedniiosint.storage`: current SQLite persistence layer.

## Data Flow

1. A target is parsed and mapped to a module or search plan.
2. Source adapters run under `SourceRunContext`.
3. Rate limits, request budgets, legal flags and cache policy are applied before
   network calls.
4. Raw responses are normalized into entities, findings, relations, evidence
   and timeline rows.
5. Evidence artifacts are hashed and linked to reports.
6. Optional monitor schedules re-run cases through the job queue and diff new
   summaries against previous runs.
7. The workspace renders analytical views and exports.

## Strong Boundaries

- Adapters must not return secrets.
- Upload/submission sources must require explicit opt-in.
- Search-engine dorks must not be mixed with verified profile URLs.
- Evidence must keep provenance, hashes and source context.
