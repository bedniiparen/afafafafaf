# Changelog

All notable changes to BEDNIIOSINT are tracked here.

## 0.7.0 - Unreleased

### Added

- Cross-platform launcher in `scripts/start.py`.
- One-click Windows launcher `start.bat`.
- One-click Windows cleanup launcher `clear.bat`.
- Unix launcher `scripts/start.sh`, infra shortcuts and Docker files under
  `infra/`.
- GitHub Actions CI skeleton with compile, lint, format, type-check, tests and
  coverage gate.
- Pre-commit configuration.
- Cache-Control-aware source cache metadata.
- Threat model, architecture and migration docs.

### Changed

- Windows startup now uses a single official batch file: `start.bat`.
- Project root now exposes only `start.bat`, `clear.bat` and folders; support
  files live under `docs/project`, `requirements`, `config` and `infra`.
- History cleanup removes case databases, vaults and report exports.
- SQLite initialization closes connections explicitly.

### Removed

- Shutdown command from `FINAL_REPORT.md`.
