# BEDNIIOSINT v0.6 - OSINT Case Builder

An OSINT case builder with username, email, domain, IP, phone, wallet,
company, metadata and URL/profile analysis, a SQLite case database, hashed
evidence vault, graph export, timeline, JSON/HTML/CSV reports, and a FastAPI
dashboard base.

## Install

One-click Windows launcher:

```bat
start.bat
```

`start.bat` checks for Python 3.11+, installs Python 3.12 through `winget`
when possible, creates `runtime/.venv`, installs dependencies and opens the dashboard.

One-click Windows cleanup:

```bat
clear.bat
```

`clear.bat` removes local generated data and heavy runtime files:
`runtime/cases`, `runtime/reports_out`, `runtime/.venv`, caches, logs,
`.env` and `.env.*` secrets. It keeps source code, docs, data catalogs and
`config/env.example`. Use `clear.bat -KeepVenv`
to keep the virtual environment. Cleanup is non-interactive by default.

Launcher safety check:

```bat
start.bat --check --no-install
python scripts\verify_launchers.py
```

Cross-platform dashboard launcher:

```bash
python scripts/start.py
```

Platform wrappers:

```bash
# Windows
start.bat

# Linux/macOS
./scripts/start.sh
```

Docker:

```bash
docker compose -f infra/docker/docker-compose.yml up --build
```

Make/just shortcuts:

```bash
make -f infra/Makefile dev
make -f infra/Makefile test
make -f infra/Makefile start

just dev
just test
just start
```

Manual install:

```bash
python -m venv runtime\.venv
runtime\.venv\Scripts\activate
pip install -r requirements\base.txt
```

Development tools:

```bash
pip install -r requirements/dev.txt
```

Full optional stack:

```bash
pip install -r requirements/base.txt
```

Or install the full pinned-style dependency list:

```bash
pip install -r requirements/base.txt
```

## Usage

```bash
bedniiosint username torvalds --case linus-investigation --html --json
bedniiosint email user@example.com --case email-case
bedniiosint domain example.com --case domain-case --no-resolve
bedniiosint ip 8.8.8.8 --case ip-case
bedniiosint phone +15551234567 --case phone-case
bedniiosint url https://example.com --case url-case
bedniiosint wallet 0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa --case wallet-case
bedniiosint company "Acme Corp" --case company-case
bedniiosint metadata .\sample.jpg --case file-case
bedniiosint find user@example.com
bedniiosint graph linus-investigation
bedniiosint timeline linus-investigation
bedniiosint report linus-investigation --pdf --csv
bedniiosint reports-verify runtime/reports_out/reports-manifest.json --case linus-investigation --json
bedniiosint case-diff old-case new-case --table
bedniiosint monitor diff old-case new-case --table
bedniiosint monitor add example.com --module domain --interval-minutes 1440
bedniiosint monitor due --json
bedniiosint monitor run-due --dry-run
bedniiosint sources --input domain --runnable --endpoints
bedniiosint source-run api:crtsh example.com --input domain --cache-ttl-source api:crtsh=3600
bedniiosint search-plan "example.com /infra/domain +github -news"
bedniiosint search-run "ivanbeats /creator/video/youtube +producer -anime" --include-auth-required --cache-ttl-source api:github=900 --dry-run
bedniiosint investigation-plan example.com
bedniiosint username-catalog-coverage external-sites.json --sample-limit 20
```

Outputs:

- `runtime/reports_out/<case>.html` and `runtime/reports_out/<case>.json` for username scans
- `runtime/reports_out/<case>-case.html` and `runtime/reports_out/<case>-case.json` for unified reports
- `runtime/reports_out/<case>-findings.csv`, `entities.csv`, `relations.csv`,
  `evidence.csv`, and `attachments.csv` for CSV exports
- `runtime/reports_out/reports-manifest.json` with size and SHA-256 evidence for
  generated report artifacts; verify it offline with `reports-verify` or from
  the dashboard/API at `/reports/verify`
- `runtime/cases/<case>.db`
- `runtime/cases/<case>_vault/` for HTML/raw snapshots and optional screenshots, with
  artifact hashes checked in the case workspace integrity summary

Cache:

- Source-response caching is enabled with conservative per-source TTL presets
  derived from source policy/auth/quota metadata.
- `--cache-ttl N` sets a default fallback TTL.
- `--cache-ttl-source source=seconds` overrides the policy TTL for a specific
  source.
- Provider `Cache-Control` is respected: `no-store`, `no-cache` and `private`
  disable caching; `max-age` caps the local TTL.
- Cached records redact secret fields, cookies and secret query parameters.

Monitoring foundation:

- `bedniiosint case-diff previous current` compares two saved case summaries or
  two JSON summary files and reports added/removed entities, findings and
  relations.
- `bedniiosint monitor add TARGET --module auto --interval-minutes N` stores a
  resumable monitor schedule in `runtime/cases/monitoring.json`.
- `bedniiosint monitor due` shows schedules whose `next_run_at` is due.
- `bedniiosint monitor run-due` creates a queued job through the existing job
  system, runs it, diffs against the previous case for that schedule and records
  an alert when entities, findings or relations changed. Use `--dry-run` to
  advance/check schedules without executing scans.
- The dashboard exposes the same state at `/monitoring`, `/monitoring.json`,
  `/monitoring/due` and `/monitoring/run-due`.
- Alerts are written to `runtime/cases/monitor_notifications.jsonl`. Set
  `BEDNIIOSINT_MONITOR_WEBHOOK_URL` to POST redacted alert payloads to a webhook.

Dashboard:

```bash
uvicorn bedniiosint.web.app:app
```

Dashboard pages:

- `/` search with target type auto-detection
- `/history` case history
- `/monitoring` schedules and case-diff alerts
- `/sources` unified source registry
- `/reports` generated report files
- `/reports/verify` report manifest integrity status and
  `/reports/evidence-bundle/<case>/inspect` evidence bundle integrity status
- `/case/<case>` case workspace with report/evidence vault integrity summary
- `/graph/<case>` visual graph
- `/timeline/<case>` visual timeline

## Modules

- `username`: calibrated account checks, anti-false-positive controls, profile
  enrichment for high-confidence findings.
- `email`: format, MX/SPF/DMARC, Gravatar, HaveIBeenPwned when `HIBP_API_KEY`
  is supplied.
- `domain`: DNS, RDAP, CT-log subdomains, optional subdomain resolution.
- `domain_passive_tools`: opt-in wrappers for local Amass/Subfinder passive
  subdomain enumeration. These tools are not called by the default `domain`
  module and active scan flags are not used.
- `ip`: public IP validation, geo/ASN/ISP enrichment and reverse DNS.
- `phone`: libphonenumber-backed parsing, country, carrier, timezone and type.
- `wallet`: BTC/ETH format detection and public explorer lookup.
- `company`: guessed domain and optional OpenCorporates lookup.
- `metadata`: SHA-256 and ExifTool-backed metadata when `exiftool` exists.
- `url`: title, description, avatar, outbound/social links, emails, wallets.

## Source Registry

BEDNIIOSINT includes `bedniiosint/catalog/osint_sources.json`: a curated OSINT
source/API inventory distilled from Sherlock, Maigret, SpiderFoot, Recon-ng,
theHarvester, GHunt, Holehe, PhoneInfoga, Social Analyzer, WhatsMyName,
API-s-for-OSINT, public-apis, OSINT Framework, Bellingcat Toolkit, and OSINT.ly.
It stores public API metadata, endpoint templates, adapter/parser ideas, report
formats, confidence signals, false-positive controls, graph/entity model ideas,
and useful dependencies. It does not include credentials or GPL/AGPL code.

`bedniiosint.catalog.registry` merges the catalog with built-in modules, local
plugin manifests and generic HTTP adapters for API entries. Registry rows now
include adapter ids, auth fields, input/output schemas, required environment
variables, runnable status and configured status. `bedniiosint source-run`
executes `module:*`, `api:*` or `plugin:*` sources and preserves raw adapter
output as JSON.

Useful source diagnostics:

```bash
bedniiosint source-verify --mode contract --runnable
bedniiosint source-verify --mode fixture --source api:shodan --fixture-dir tests/fixtures/sources
bedniiosint source-verify --mode fixture --source api:youtube --fixture-dir tests/fixtures/sources --fixture schema_changed
bedniiosint source-verify --mode fixture --source api:virustotal --fixture-dir tests/fixtures/sources --fixture upload_ok
bedniiosint source-verify --mode fixture --source api:tineye --fixture-dir tests/fixtures/sources
bedniiosint source-verify --mode live-plan --source api:shodan
bedniiosint source-verify --mode live --source api:crtsh --target example.com --record-live-result --run-id provider-check-001
bedniiosint source-quality-gate --priority P1 --fixture-dir tests/fixtures/sources
bedniiosint source-maintenance --fixture-dir tests/fixtures/sources
bedniiosint live-plan
bedniiosint live-plan --runbook --out live-validation-runbook.md
bedniiosint live-plan --account-runbook --out live-account-runbook.md
bedniiosint live-results --markdown --out live-results.md
bedniiosint live-results --format csv --out live-results.csv
# File exports also write <output>.manifest.json with SHA-256/size audit evidence
bedniiosint live-results-verify live-results.csv.manifest.json --audit-log --json
bedniiosint live-results-cleanup --older-than-days 30
bedniiosint live-results-cleanup --older-than-days 30 --apply
bedniiosint live-results-audit --json
# Dashboard: open /live-results/view for persisted live-validation history
bedniiosint budget-presets
bedniiosint api-key-template --missing-only --out config/bedniiosint.env.example
# Dashboard: open /api-keys for the P1 keyed-source setup panel or /api-keys/setup?priority=P1 for JSON
bedniiosint api-key-store-setup --profile windows-cmd-user
bedniiosint api-key-store-setup --profile windows-cmd-user --apply
bedniiosint api-key-store-setup --profile env-file --out bedniiosint.env --apply --allow-secret-file
bedniiosint api-key-store-setup --profile systemd-env --apply --allow-secret-file --install-service bedniiosint-worker --reload-service
set BEDNIIOSINT_SECRETS_KEY=change-me
bedniiosint api-key-store-set SHODAN_API_KEY
bedniiosint api-key-store-list
bedniiosint media-verify-plan sample.jpg --out sample-media-workflow.md
bedniiosint pipeline-run example.com --input domain --budget-preset conservative --public-only
bedniiosint source-run api:virustotal sample.bin --input file --allow-uploads
bedniiosint source-run api:tineye sample.jpg --input image --allow-uploads --allow-sensitive-sources
bedniiosint cti-preflight --opencti-url https://opencti.example --misp-url https://misp.example
bedniiosint cti-sync my-case --opencti-url https://opencti.example/import
bedniiosint cti-sync my-case --opencti-url https://opencti.example/import --send --opencti-patch description=reviewed
bedniiosint cti-sync my-case --opencti-url https://opencti.example/import --send --opencti-patch-mutation identityFieldPatch --opencti-patch description=reviewed
bedniiosint cti-sync my-case --opencti-url https://opencti.example/import --send --opencti-patch-map X-Private=privateObjectFieldPatch --opencti-patch description=reviewed
bedniiosint cti-sync my-case --misp-url https://misp.example --send --read-back
```

`username-catalog-coverage` compares the packaged username site catalog against
external Sherlock/Maigret/WhatsMyName/Nexfil-style JSON files without copying
upstream data blindly. It reports overlap, missing candidates, category gaps and
a license/ToS review reminder before any merge.

Search-only domain catalogs are folded into normal dorking output automatically:
`bedniiosint search-run ... --dorking` still uses one search action, but adds
low-priority manual `site:domain "target"` leads from
`bedniiosint/data/search_only_sites.json`. These rows are review-only and are not
treated as verified username profile templates. Rebuild the optional public
domain list with `python -m scripts.import_search_only_sources`.

`source-verify --mode contract` and `--mode live-plan` do not use the network.
`source-quality-gate` is also offline: it checks API source docs/policy/risk,
cache/quota metadata, parser maturity, `ok` fixtures and error/rate-limit/schema
fixture variants. Use `--strict` to treat warnings as failures.
`live-plan` checks whether a source is ready for a live probe and reports missing
keys or required legal/privacy opt-in. `--mode fixture` reads
`tests/fixtures/sources/<source>/<fixture>.json`; use `--fixture ok` for happy
paths and variants such as `rate_limited`, `http_error` or `schema_changed` for
error-path parser contracts. `--mode live` runs adapter health probes and skips
sources that need missing API keys or explicit legal/privacy opt-in.
`source-verify --mode live --record-live-result` persists the opt-in live
validation outcome after redacting secret-like fields and configured secret
values. It is never enabled by default. `bedniiosint live-results` reports the
persisted history as a table, JSON or Markdown without printing secret values.
The dashboard exposes the same history at `/live-results` for JSON and
`/live-results/view` for a filtered HTML view with source/run filters and
retention guidance. Use `/live-results/export` or `live-results --format csv`
for CSV export. File exports written with `--out` also write a sidecar
`<output>.manifest.json` containing the export SHA-256, byte size and audit
event id; web exports return the same hash/size evidence in
`X-BEDNIIOSINT-Export-SHA256`, `X-BEDNIIOSINT-Export-Bytes` and
`X-BEDNIIOSINT-Audit-Event-ID` headers. `live-results-verify` checks an export
against its sidecar manifest offline and can also compare the embedded audit
event against the local audit database with `--audit-log`. Use
`live-results-cleanup` or the dashboard cleanup form for retention cleanup;
cleanup is dry-run unless `--apply` or the dashboard Apply checkbox is
explicitly set. Export and cleanup actions are recorded in a separate audit
log, available through `live-results-audit` or `/live-results/audit`; audit
events store filters, counts, output path labels, output hashes and action
channel, not secret values.
`bedniiosint live-plan` checks the CTI/source/media live-test environment
without making network requests or printing secret values. Add `--runbook` to
render a Markdown checklist with required environment variable names, missing
variables, commands and upload/CTI safety notes. Add `--account-runbook` to
render keyed-provider account validation commands for P0/P1 runnable APIs using
environment variable names only; add `--priority P0,P1` to change the source
priority filter and `--out PATH` to write JSON or Markdown output to disk.
`source-maintenance` and `/sources/maintenance` combine registry health,
fixture coverage, top remediation actions and live-readiness counts without
making provider network calls.
`budget-presets` prints the named source request-budget presets without making
network requests. `source-run`, `pipeline-run` and `/pipeline/run` accept
`--budget-preset smoke`, `conservative` or `standard`; presets include
provider-specific limits for high-cost keyed APIs such as Shodan, Censys,
SecurityTrails, VirusTotal, TinEye, HIBP, Hunter and Google CSE. Manual
`--request-budget api:source=limit` values override preset entries.
`api-key-template` writes blank values only. The encrypted local store is
passphrase-based through `BEDNIIOSINT_SECRETS_KEY`; environment variables still
take precedence at runtime. The dashboard page `/api-keys` can also save or
delete encrypted local store entries when `BEDNIIOSINT_SECRETS_KEY` is set; it
shows only key names/status, never stored values. If the dashboard starts
without `BEDNIIOSINT_SECRETS_KEY`, `/api-keys` offers a first-run setup form
that sets the passphrase for the current process only; configure the environment
variable in your shell or service before restarting.
`api-key-store-setup` prints safe setup commands/templates for cmd,
PowerShell, systemd, Docker or env-file workflows using a placeholder instead
of a real passphrase; use `--out` to write the template. `--apply` is available
for session profiles and Windows user profiles. Windows user apply writes
`BEDNIIOSINT_SECRETS_KEY` through the current user's Environment registry key,
does not echo the passphrase, and requires new shells/services to be restarted.
For `systemd-env`, `docker-env` and `env-file`, `--apply` requires `--out` and
`--allow-secret-file` because the written deployment file contains the real
passphrase; file permissions are restricted to the owner where the OS allows it.
For user-level systemd services, `--profile systemd-env --apply
--allow-secret-file --install-service NAME` writes a drop-in under the user
systemd config directory. Add `--reload-service` or `--restart-service` only
when you want Codex/BEDNIIOSINT to invoke `systemctl --user` for that service.

`media-verify-plan` creates a structured local verification workflow for
images/video URLs: hash preservation, EXIF/container metadata review,
archive-search plan, geolocation checklist, reverse-search plan, timeline
corroboration and artifact collection. It does not upload media or automate
third-party reverse-search sites. The workflow keeps third-party upload disabled
by default and marks reverse-image matches as analyst review signals, not
identity proof.

VirusTotal file submission is available only as an explicit source run with
`--allow-uploads` and `VIRUSTOTAL_API_KEY`. BEDNIIOSINT uses the direct
small-file upload endpoint, records the local SHA-256 and a privacy warning in
normalized output, and does not cache upload requests. Use hash lookup for
private or large files unless an analyst has approved submission.
TinEye reverse-image search is available as `image_url` lookup with
`TINEYE_API_KEY` and as local `image` upload only when both `--allow-uploads`
and `--allow-sensitive-sources` are set. Reverse-image matches are review-only
signals, not identity proof.

Live source checks are opt-in:

```bash
set BEDNIIOSINT_SOURCE_LIVE_TESTS=1
set BEDNIIOSINT_SOURCE_LIVE_ID=api:tineye
set BEDNIIOSINT_SOURCE_LIVE_TARGET=https://example.com/image.jpg
set BEDNIIOSINT_SOURCE_LIVE_ALLOW_OPT_IN=1
pytest -q tests/test_source_live.py
```

TinEye live media checks additionally use `BEDNIIOSINT_MEDIA_LIVE_TESTS=1`,
`TINEYE_API_KEY` and `TINEYE_LIVE_IMAGE_URL`. Local image upload requires the
extra `BEDNIIOSINT_MEDIA_LIVE_UPLOAD=1` and `TINEYE_LIVE_IMAGE_PATH`.

Unified reports can also emit local connector-friendly files:

```bash
bedniiosint report my-case --stix --opencti --misp
```

Unified JSON, HTML and Markdown reports include `source_coverage`: recorded
sources, checked/skipped/missing-key/error counts, and expected pipeline sources
that were not recorded in the case. They also include `source_health_history`,
with latest source health, health states and per-run history rows; CSV export
writes this as `<case>-source_health_history.csv`. Reports also include
`risk_summary`, with a case-exposure risk score, a separate confidence score,
confidence-band counts, corroboration count and evidence-gap drivers.

OpenCTI export wraps the STIX 2.1 bundle in an import envelope. MISP export
creates an unpublished local event JSON with `to_ids=false` attributes so OSINT
observations stay review-only until an analyst promotes them.
`cti-preflight` checks OpenCTI GraphQL and MISP version endpoints with the
configured token/key without sending case data. `cti-sync` is dry-run by default;
`--send` is required before it performs HTTP POST requests. Tokens are resolved
from environment variables or the encrypted secret store (`OPENCTI_TOKEN`,
`MISP_API_KEY`). For MISP, `cti-sync --send --read-back` reads the created event
back when the server returns an event id/uuid, and `--delete-after` can remove
that created event for test cleanup. For OpenCTI, `--read-back` and
`--delete-after` use GraphQL `stixCoreObject` lifecycle operations when the
configured import endpoint returns a remote object id. Advanced OpenCTI field
reconciliation is explicit: pass one or more `--opencti-patch key=value`
fields. BEDNIIOSINT reads the remote object metadata and infers common
type-specific `*FieldPatch` mutations such as `identityFieldPatch`. For custom
entity types, it can use GraphQL schema introspection to match generated
`*FieldPatch` names when the server exposes them. Pass
`--opencti-patch-mutation identityFieldPatch` or wrapper mutations such as
`identityEdit` when introspection is disabled or the target OpenCTI schema needs
an override. For reusable custom-type inference on servers where introspection
is disabled, pass `--opencti-patch-map EntityType=mutation`.

Live CTI checks are opt-in and skipped by normal tests:

```bash
set BEDNIIOSINT_CTI_LIVE_TESTS=1
set OPENCTI_URL=https://opencti.example
set OPENCTI_TOKEN=...
set MISP_URL=https://misp.example
set MISP_API_KEY=...
pytest -q tests/test_cti_live.py
```

Live POST tests require an additional `BEDNIIOSINT_CTI_LIVE_SEND=1`. OpenCTI
send tests also require `OPENCTI_SYNC_URL`, the exact endpoint that accepts the
BEDNIIOSINT OpenCTI import envelope. Set `BEDNIIOSINT_CTI_LIVE_READ_BACK=1` to
attempt OpenCTI read-back when the import endpoint returns a remote object id.
Set `BEDNIIOSINT_CTI_LIVE_PATCH=1` and `OPENCTI_PATCH_FIELD=key=value` to run
a live OpenCTI field patch. `OPENCTI_PATCH_MUTATION` is optional and overrides
the inferred mutation. `OPENCTI_PATCH_MAP=EntityType=mutation` is optional and
provides a custom inference map when introspection is disabled.
MISP send tests use `MISP_URL` and create an unpublished review event. Set
`BEDNIIOSINT_CTI_LIVE_CLEANUP=1` to delete created live test objects after
read-back.

The runtime API catalog includes GitHub developer search, YouTube Data API and
Google Programmable Search entries with typed parsers. These sources need their
official API keys for live runs (`GITHUB_TOKEN`, `YOUTUBE_API_KEY`,
`GOOGLE_CSE_API_KEY` and `GOOGLE_CSE_CX`), but their fixture parsers can be
verified offline.

## Confidence, Reliability and False Positives

For every site, BEDNIIOSINT probes random impossible usernames before trusting
an `exists` result. If the site also claims those exist, or responds
near-identically to real and control queries, reliability drops and the finding
is rejected under `Removed false positives`. Confidence is the sum of weighted
signals, scaled by source reliability.

All modules now use a shared scoring model based on named signals. Score markers
are stored in `Finding.matched_markers`, rejected findings use
`Finding.rejected` and `Finding.reject_reason`, and module reliability is stored
in `Source.reliability`. This keeps confidence, source reliability and
anti-false-positive reasons visible in reports without requiring a database
migration.

## Run Tests

```bash
pytest -q
```

## Optional Runtime Components

- DNS, graph, reports, web and screenshot dependencies are listed in
  `requirements/base.txt`.
- `playwright install chromium` enables screenshots.
- `weasyprint` enables PDF conversion via `bedniiosint.reports.pdf`.
- `exiftool` enables deep file metadata.
- `HIBP_API_KEY` enables breach lookup.
- `OPENCORPORATES_API_TOKEN` enables company registry lookup.

## Legal / Ethical

Use only for authorized investigations and public OSINT workflows. OSINT is not
unauthorized access.

## License

MIT. See `LICENSE`.
