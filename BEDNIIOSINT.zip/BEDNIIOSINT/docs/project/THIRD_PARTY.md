# Third-Party Attributions

BEDNIIOSINT itself is MIT-compatible project code. No API keys, secrets,
tokens, cookies or credentials were copied from any source.

## Code Patterns / Detection Model

- **Sherlock** (sherlock-project) - MIT License. Detection model:
  `status_code`, `message`, `response_url`, plus `regexCheck`, `urlProbe`,
  `request_method`, `request_payload`, and `username_claimed`. Re-implemented;
  no source files copied verbatim. https://github.com/sherlock-project/sherlock
- **Maigret** (soxoj/maigret) - MIT License. Concept: dossier building,
  false-positive control username testing, and response-ratio comparison.
  Re-implemented independently. https://github.com/soxoj/maigret
- **SpiderFoot** (smicallef/spiderfoot) - MIT License. Concept only: module
  consume/produce contract and post-collection correlation engine.
- **API-s-for-OSINT** by cipher387 - CC0-1.0. Public API names,
  documentation URLs and category ideas are summarized in the source catalog.
- **public-apis** - MIT License. Public API discovery and auth/HTTPS/CORS
  classification ideas are summarized in the source catalog.
- **OSINT Framework** - catalog hierarchy and tool-tag ideas only.
- **Bellingcat Online Investigation Toolkit** - public tool/category
  documentation ideas only.
- **OSINT.ly** - public documentation facts and module-marketplace concepts
  only; no proprietary module data or credentials copied.

## Data

- **Sherlock** (sherlock-project) - MIT License. The packaged username
  `sites.json` includes imported site detection rows from Sherlock upstream
  `data.json`; imported rows preserve `provenance.source` and
  `provenance.original_name`. https://github.com/sherlock-project/sherlock
- **WhatsMyName** by Micah Hoffman - data licensed CC BY-SA 4.0. Schema fields
  adopted: `cat`, `e_code`, `e_string`, `m_code`, `m_string`, `uri_pretty`,
  `strip_bad_char`, `protection`, and `known`. The derived `sites.json` data
  file is distributed under CC BY-SA 4.0 with attribution and ShareAlike.
  https://github.com/WebBreacher/WhatsMyName
- **Nexfil** by thewhiteh4t - MIT License. Additional username URL templates
  and string-based not-found markers are imported into `sites.json`; imported
  rows preserve `provenance.source` and `provenance.original_name`.
  https://github.com/thewhiteh4t/nexfil
- **Snoop** public `websites.md` list - used only as a search-only domain
  discovery list for manual `site:domain "target"` dorks. Snoop `BDdemo`,
  `BDfull` and `BDflag` database files are not imported or bundled.
  https://github.com/snooppr/snoop

## Concepts Only

- Recon-ng (GPLv3): workspace-as-database concept.
- theHarvester (GPL): multi-source aggregation concept.
- GHunt (AGPL): Google-account entity concept only.
- Holehe / PhoneInfoga (GPLv3): future email/phone module concepts.
- Social Analyzer (AGPL): rating/filtering and screenshot concept only.
- Maltego, Hunchly (proprietary): entity-graph model and evidence capture with
  hashes.

## External Tools

- Cytoscape.js - MIT License. Vendored browser bundle used for the interactive
  case graph UI. https://github.com/cytoscape/cytoscape.js
- ExifTool (Artistic/GPL) - planned as an external binary integration; no code
  copied.

## Additional Sources Used In v0.2-v0.5

- crt.sh (Certificate Transparency) - public CT-log search service queried, not
  copied.
- rdap.org - RDAP bootstrap aggregator queried as a public service.
- Gravatar - public profile/avatar API; email hashing uses trim + lowercase.
- HaveIBeenPwned - breach API queried only with a user-supplied key.
- Google Public DNS - DNS-over-HTTPS JSON API fallback used for DNS records
  when dnspython is unavailable or local DNS returns no answer.
- ipwho.is / IPWhois.io - public IP geolocation API queried for IP OSINT.
- OpenCorporates - company search API queried only when
  `OPENCORPORATES_API_TOKEN` is supplied by the user.
- phonenumbers - Apache-2.0 Python port of Google's libphonenumber used for
  offline phone parsing and validation.
- dnspython (BSD) - DNS resolution dependency, not vendored.
- Playwright (Apache-2.0) - optional screenshot capture dependency.
- WeasyPrint (BSD-3) - optional PDF rendering dependency.
- FastAPI (MIT) / Uvicorn (BSD) - web dashboard dependencies.
- ExifTool by Phil Harvey (Artistic/GPL) - invoked as an external binary; no
  code copied.

## Source Registry v0.6

- The unified source registry combines BEDNIIOSINT's own runnable modules with
  public API metadata already listed in `bedniiosint/catalog/osint_sources.json`.
- Registry fields such as auth mode, environment-variable hints, input types,
  runnable status and configured status are original BEDNIIOSINT metadata.
- No third-party API keys, credentials, cookies, proprietary module definitions,
  GPL/AGPL implementation code or commercial transform logic are included.

## Confidence / Reliability v0.6

- Shared score signals, source reliability weights, rejection reasons and
  legacy-column persistence are original BEDNIIOSINT implementation details.
- The model is inspired by common OSINT validation practice and previously
  documented project concepts, but no competitor scoring implementation was
  copied.

No credentials, cookies, tokens or API keys from any project are included.
