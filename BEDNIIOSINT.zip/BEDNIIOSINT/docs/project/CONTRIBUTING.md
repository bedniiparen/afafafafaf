# Contributing

## Setup

```bash
python -m venv runtime/.venv
python -m pip install -r requirements/base.txt
python -m pip install -r requirements/dev.txt
pre-commit install
```

## Before A PR

Run:

```bash
ruff check bedniiosint tests
black --check bedniiosint tests
mypy bedniiosint
pytest -q
```

Add offline tests for new behavior. New source adapters need fixture-backed
parser tests and clear labels for auth, cost, terms risk, and opt-in behavior.

## New Sources

Add only public, legally usable, passive-first sources by default. Do not copy
GPL/AGPL module code into this project without a license review. Reimplement
source-specific mapping cleanly and keep provider ToS risk visible in the
catalog and UI.
