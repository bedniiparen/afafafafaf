# Security Policy

## Reporting A Vulnerability

Report vulnerabilities through a private GitHub Security Advisory or by email to
`security@example.invalid`.

Do not open a public issue for exploitable security defects, leaked secrets, or
provider abuse paths.

## Scope

- BEDNIIOSINT is passive-first and public-data-first.
- The project must not implement credential stuffing, stolen-data ingestion,
  account takeover checks, or private-data scraping.
- Risky provider actions such as submissions, uploads, active checks, and
  phone/carrier lookups must stay explicit opt-in workflows.
- Reports and exports must redact configured secrets and API keys.
- API keys use the encrypted secret store; sensitive runtime JSON fields can use
  optional at-rest field encryption via `BEDNIIOSINT_ENCRYPTION_PASSPHRASE`.

## Supported Versions

Security fixes target the latest released minor version. Development snapshots
receive fixes through normal pull requests and release notes.
