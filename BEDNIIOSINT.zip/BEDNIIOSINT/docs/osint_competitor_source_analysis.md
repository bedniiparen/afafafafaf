# Competitor and Source Architecture Analysis

This document records what BEDNIIOSINT should learn from major OSINT tools and
catalogs without copying unsafe workflows or incompatible code.

## Tool/Catalog Benchmarks

| Tool/source | What it does well | What BEDNIIOSINT should adopt | What not to copy |
|---|---|---|---|
| OSINT Framework | Broad taxonomy and discovery UX | Category taxonomy and source discovery checklist | Treating catalog links as verified APIs |
| Bellingcat Toolkit | Practical verification workflows | Media verification checklist and human-review language | Any source without official doc verification |
| Awesome OSINT | Broad community tool discovery | Discovery seed for future source review | Stale links or unverified claims |
| API-s-for-OSINT | API-oriented discovery | API backlog source | API claims without official docs |
| Cyber Detective map | Investigator-friendly categorization | Visual category planning | Unreviewed external tools |
| SpiderFoot | Event-driven module graph | Module/event model, scan graph, source breadth | License-incompatible implementation code |
| Maltego Transform Hub | Transform/graph UX | Transform-like source adapter UX | Closed platform assumptions |
| OpenCTI connectors | Connector ecosystem and STIX mapping | Connector pattern, STIX object discipline | Copying connector code without license review |
| Recon-ng | Workspace/module marketplace | Workspace model and marketplace idea | GPL code in MIT project |
| theHarvester | Domain source breadth | Source categories and domain investigation outputs | GPL implementation code |
| Sherlock | Username coverage | Coverage benchmark and site response modeling | Blind social-site scraping |
| Maigret | Username reports and metadata | Report shape and site metadata ideas | Unreviewed site DB copying |
| WhatsMyName | Username site definitions | Site schema ideas after license review | Per-site ToS violations |
| Amass | Passive domain enum graph | Passive source orchestration and graph | Active enum by default |
| Subfinder | Source-configured passive discovery | Per-source key/config design | Unbounded passive source calls |
| Nuclei | Template ecosystem | Optional authorized active-check plugin model | Default scanning |
| Metagoofil | Document metadata workflow | Metadata report ideas | Automated document harvesting by default |
| FOCA | Historical metadata analysis | Metadata category coverage | Legacy/maintenance assumptions |
| Photon | URL discovery crawler | Scoped crawler design cautions | Default crawling |
| GHunt | Google-account OSINT coverage | Privacy warning example | Product integration |
| Holehe | Email registration enumeration | Risk example | Product integration |
| PhoneInfoga | Phone parsing/workflow | Local phone parsing UX and report ideas | Unverified carrier/social lookups |
| Social Analyzer | Social profile automation | Profile-candidate UX ideas | Browser automation/social scraping |

## Strong Platform Patterns to Copy Conceptually

1. Source modules must be small and independently testable.
2. Every result needs provenance, timestamp and source reliability.
3. Graph edges should carry confidence and evidence references.
4. User-facing reports need caveats, not only raw findings.
5. Keyed/commercial APIs need configured/missing-key states in UI.
6. Risky sources need opt-in modes and scope controls.
7. API responses need fixture-based tests.
8. Catalog entries need lifecycle metadata: maintained, stale, risky,
   catalog-only, generic HTTP or typed parser.
9. The product should distinguish:
   - public OSINT;
   - threat intelligence;
   - legal breach notification;
   - prohibited stolen data or account-checking.

## Source Gaps Compared to Mature Tools

BEDNIIOSINT is behind mature tools in:

- number of real API connectors;
- web technology and exposed-service enrichment;
- media verification workflow;
- business registry breadth;
- STIX/TAXII interoperability;
- source-specific mocked API contract tests;
- source health and maintenance dashboards;
- official API setup guidance in UI;
- per-source legal/privacy policy enforcement.

BEDNIIOSINT is already competitive for a small local tool in:

- unified case storage;
- evidence capture;
- reports and graph export;
- source provenance direction;
- job queue and resumable runs;
- false-positive controls for username checks.

## Integration Principles

- Prefer official APIs over scraping.
- Prefer passive lookup over active probing.
- Prefer source-level confidence over binary "found/not found".
- Prefer public/legal breach notification APIs over breach datasets.
- Prefer local metadata extraction over automated harvesting.
- Prefer explicit user opt-in for any upload, scan, phone lookup or social
  platform automation.

