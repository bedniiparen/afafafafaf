# Release Checklist

BEDNIIOSINT uses semver-style releases from `config/pyproject.toml`.

## Versioning

- Patch: bug fixes, source contract fixes, docs and test-only changes.
- Minor: new sources, new CLI/API commands, report sections and backwards
  compatible schema additions.
- Major: removed commands, incompatible database/report/API changes, changed
  legal/safety defaults.

## Before Tagging

1. Update `config/pyproject.toml` version.
2. Update `docs/project/CHANGELOG.md`.
3. Run `python -m compileall -q bedniiosint tests`.
4. Run `python -m pytest -q --cov=bedniiosint --cov-fail-under=85`.
5. Run `python -m build` and `python -m twine check dist/*`.
6. Confirm `runtime/cases`, `runtime/reports_out`, caches and `runtime/.venv` are not included
   in the package or release artifacts.

## Publish

- Create a GitHub Release for the version tag.
- `.github/workflows/release.yml` builds the package, checks metadata and
  publishes through PyPI trusted publishing from the `pypi` environment.
- Manual `workflow_dispatch` can build artifacts without publishing by leaving
  `publish=false`.
