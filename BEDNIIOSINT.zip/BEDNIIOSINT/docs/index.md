# BEDNIIOSINT

BEDNIIOSINT is a legal-first OSINT case builder for public, permissioned
investigations.

## Quick Start

One-click Windows launcher:

```cmd
start.bat
```

It checks for Python 3.11+, installs Python 3.12 through `winget` when
possible, creates `runtime/.venv`, installs dependencies and opens the dashboard.

One-click Windows cleanup:

```cmd
clear.bat
```

It removes local runtime cases, reports, `.env` secrets, caches, logs and
`runtime/.venv` immediately, while keeping source code, docs, catalogs and
`config/env.example`.

```bash
python scripts/start.py
```

On Windows:

```cmd
start.bat
```

On Linux/macOS:

```bash
./scripts/start.sh
```

With Docker:

```bash
docker compose -f infra/docker/docker-compose.yml up --build
```

## Core Guarantees

- Passive-first defaults.
- Evidence provenance and SHA-256 integrity.
- Explicit opt-in for sensitive, upload or active workflows.
- Redaction of secrets in output paths.
- Candidate URLs separated from confirmed profiles.
