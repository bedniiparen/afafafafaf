# Threat Model

BEDNIIOSINT is designed for public, permissioned OSINT workflows.

## What The Tool Does

- Looks up public usernames, domains, IPs, URLs, emails, phones, wallets,
  companies and metadata.
- Preserves source provenance and evidence hashes.
- Separates candidates, confirmed findings and rejected/false-positive results.
- Supports opt-in API enrichment when the user provides legitimate credentials.

## What The Tool Must Not Do

- No credential stuffing.
- No login attempts against third-party accounts.
- No password reset or registration enumeration workflows.
- No raw leaked database or combolist integration.
- No malware downloads.
- No default active scanning against targets.
- No bypassing provider terms or access controls.

## Secrets

- Secrets must be stored only through the configured secret store.
- The local secret store uses passphrase-derived encryption metadata
  (`pbkdf2-sha256`, per-record salt/nonce/tag). `api-key-store-audit` checks
  store version, KDF metadata, iteration policy and record authentication
  without returning secret values.
- `api-key-store-rotate` re-encrypts stored API keys with the current KDF
  policy after the passphrase is available.
- Optional field encryption is enabled with
  `BEDNIIOSINT_ENCRYPTION_PASSPHRASE`; `BEDNIIOSINT_ENCRYPTION_SALT` can add a
  deployment salt. New live-validation JSON payload fields are stored as
  authenticated envelopes instead of plaintext when this is configured.
- Exports must redact API keys, tokens, cookies, passwords and authorization
  headers.
- URLs in evidence and errors must redact secret query parameters.
- Secret redaction must be covered by tests for JSON, HTML, CSV, STIX, MISP,
  OpenCTI, bundles and logs.
- Current tests cover JSON/HTML/Markdown/CSV report redaction, evidence bundle
  query-parameter redaction, workspace/evidence manifests and CTI client
  responses that must not echo API keys.

## Cache And Provider Safety

- Cache keys must include source, target, method, URL and request parameters.
- Upload/submission requests must not be cached.
- `Cache-Control: no-store`, `no-cache` and `private` must disable caching.
- `Cache-Control: max-age` must cap local TTL.
- Per-source TTL should be configured conservatively for paid or sensitive APIs.
- Default cache TTL presets are derived from source policy/auth/quota metadata;
  explicit CLI/API overrides win when supplied.

## Monitor Alerts

- Monitor alerts are local by default and are appended to
  `runtime/cases/monitor_notifications.jsonl`.
- Webhook delivery is disabled unless `BEDNIIOSINT_MONITOR_WEBHOOK_URL` is set.
- Alert payloads pass through secret and URL-query redaction before local or
  webhook delivery.

## Legal Scope Flags

- `public_only`: run only low-risk public sources.
- `allow_sensitive_sources`: required for sensitive people, breach, phone or
  social-intel enrichments.
- `allow_uploads`: required before submitting files/URLs to providers.
- `allow_active_checks`: required before active checks.
