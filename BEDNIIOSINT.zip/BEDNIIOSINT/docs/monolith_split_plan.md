# Monolith Split Plan

`web/app.py` and `cli.py` are too large for comfortable review and external
contribution. They should be split without changing behavior.

## FastAPI Routers

- `web/routers/cases.py`: started with `/cases/diff`.
- `web/routers/reports.py`: report center, manifest, verification, case archive,
  report bundles and evidence bundles are moved out of `web/app.py`.
- `web/routers/search.py`: search page, jobs, search API.
- `web/routers/sources.py`: source health, maintenance, verification and
  username source catalog API.
- `web/routers/api_keys.py`: API key setup page, keyed-source setup API and
  encrypted store passphrase/save/delete routes are moved out of `web/app.py`.
- `web/routers/auth.py`: login, logout and security status.
- `web/schemas.py`: shared response models for routes moved out of `app.py`.

## Typer Sub-Applications

- `cli_api_keys.py`: API key setup, safe `.env` templates and encrypted
  secret-store audit/rotation are available under `api-keys ...`; old
  top-level `api-key-*` commands remain registered as compatibility aliases.
- `cli_monitor.py`: started with `monitor diff`.
- `cli_jobs.py`: resumable scan job commands are available under `jobs ...`;
  old top-level `job-*` commands remain registered as compatibility aliases.
- `cli_reports.py`: report writing and report-manifest verification are
  available under `reports ...`; old top-level `report` and `reports-verify`
  commands remain registered as compatibility aliases.
- `cli_cases.py`
- `cli_search.py`
- `cli_sources.py`
- `cli_live.py`
- `cli_admin.py`

## Safe Sequence

1. Move pure HTML/render helper functions into presenter modules.
2. Move route functions into routers while preserving URL paths.
3. Keep `web/app.py` as composition root only.
4. Move Typer command groups behind sub-apps while preserving command names.
5. Add route and CLI contract tests after each move.
