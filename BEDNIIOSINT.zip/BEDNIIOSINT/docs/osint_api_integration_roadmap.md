# OSINT API Integration Roadmap

This roadmap implements the catalog without turning BEDNIIOSINT into a risky
scraper. The order favors public, legal, high-value, low-surprise sources first.

## Implementation Status

Implemented:

- Machine-readable source policy loading from `data/osint_sources_catalog.json`.
- Runtime policy enforcement for catalog API adapters:
  - reject sources are blocked;
  - sensitive/opt-in sources are blocked unless context explicitly allows them;
  - `public_only` and `max_terms_risk` gates now understand `reject`.
- Registry risk labels now prefer the researched policy catalog.
- Source registry and health output now expose priority, product value, setup
  guidance and explicit opt-in state.
- CLI and API pipeline runs accept explicit legal flags for sensitive sources,
  upload/submission workflows and active checks.
- urlscan submissions and similar upload-like POST workflows are blocked unless
  upload opt-in is set.
- urlscan submission execution is covered by an explicit opt-in path that
  requires `allow_uploads` and a configured API key; lookup mode stays
  available without upload opt-in.
- VirusTotal direct small-file submission is covered by an explicit opt-in path
  that requires `allow_uploads` and `VIRUSTOTAL_API_KEY`; upload requests are
  not cached and normalized output includes SHA-256 plus a privacy warning.
- Fixture verification supports per-fixture input/target overrides, so upload
  parser contracts can run offline without touching real providers.
- TinEye reverse-image search is available as keyed `image_url` lookup and as
  local `image` upload only when both upload and sensitive-source opt-ins are
  set; fixture coverage verifies the parser offline.
- `media-verify-plan` emits a structured v2 image/video verification workflow:
  local hash/metadata preservation, archive search, reverse-search,
  geolocation, timeline corroboration and artifact collection with uploads
  disabled by default.
- Generic keyed-source live verification and TinEye media live checks are
  available in `tests/test_source_live.py`; they are skipped by default and
  require explicit environment opt-in plus real credentials.
- `live-plan` reports CTI/source/media live validation readiness without
  network calls and without returning secret values.
- `live-plan --runbook` exports a Markdown live-validation checklist with env
  var names, missing vars, commands and upload/CTI safety notes, still without
  returning secret values.
- `live-plan --account-runbook` exports an offline keyed-provider account
  validation runbook for selected source priorities, listing env var names and
  safe live-check commands without secret values.
- `source-verify --mode live --record-live-result` persists explicitly
  approved live validation outcomes after redacting secret-like fields and
  configured secret values.
- `live-results` reports persisted live validation history as table, JSON or
  Markdown without making network calls or printing secret values.
- `/live-results` and `/live-results/view` expose the same persisted history in
  the dashboard/API with source/run filters and retention guidance, still
  without initiating live checks.
- `live-results --format csv`, `/live-results/export` and
  `live-results-cleanup` provide explicit export and retention cleanup controls;
  cleanup remains dry-run unless an apply control is set.
- `live-results-audit` and `/live-results/audit` record export/cleanup audit
  evidence with filters, counts, channel and output labels, without secret
  values.
- `live-results --out ...` writes a sidecar `<output>.manifest.json` with
  SHA-256, byte size and audit event linkage; `/live-results/export` returns
  matching hash, byte-count and audit-event headers.
- `live-results-verify` verifies exported live-validation history files
  against sidecar manifests offline and can compare the embedded audit event
  against the local audit database without making network calls.
- `source-maintenance`, `/sources/maintenance` and the dashboard `/sources`
  maintenance panel provide offline source maintenance scoring, fixture
  coverage, top actions and live-readiness summaries.
- `source-run`, `pipeline-run` and the pipeline API support named request
  budget presets (`smoke`, `conservative`, `standard`) with per-source wildcard
  semantics, explicit source overrides and provider-specific limits for
  high-cost keyed APIs.
- `api-key-setup` CLI guidance and source setup hints are available for keyed
  APIs.
- API keys can be saved/deleted from the dashboard `/api-keys` page using the
  encrypted local store. Environment variables still take precedence.
- The dashboard has a first-run passphrase wizard for
  `BEDNIIOSINT_SECRETS_KEY`; it enables the encrypted store for the current
  process without writing the passphrase to disk.
- `api-key-store-setup` exports safe placeholder-based setup templates for
  `BEDNIIOSINT_SECRETS_KEY` across cmd, PowerShell, systemd, Docker and env-file
  workflows.
- `api-key-store-setup --apply` can apply `BEDNIIOSINT_SECRETS_KEY` for current
  process profiles and Windows user environment profiles without printing the
  passphrase.
- `api-key-store-setup --apply --allow-secret-file --out ...` can write
  systemd/Docker/env-file deployment snippets containing the real passphrase
  with owner-only permissions where supported.
- `api-key-store-setup --profile systemd-env --apply --allow-secret-file
  --install-service ...` can install a systemd drop-in and optionally run
  daemon reload/restart for user or system services.
- `cti-preflight` checks OpenCTI GraphQL and MISP version endpoints before
  sending case payloads.
- Live OpenCTI/MISP preflight and send tests exist in `tests/test_cti_live.py`.
  They are skipped by default and require explicit environment opt-in before
  touching real servers.
- MISP sync now supports explicit read-back and cleanup deletion for the created
  event when the server returns a remote event id/uuid.
- OpenCTI sync now supports explicit GraphQL `stixCoreObject` read-back and
  deletion when the configured import endpoint returns a remote object id.
- OpenCTI sync supports explicit field reconciliation via caller-provided
  type-specific GraphQL patch/edit mutations such as `identityFieldPatch` or
  `identityEdit` plus repeatable `key=value` field patches.
- OpenCTI field reconciliation now infers common type-specific `*FieldPatch`
  mutations from remote `stixCoreObject.entity_type` metadata and still accepts
  explicit mutation overrides for target-instance schema differences.
- OpenCTI field reconciliation can fall back to GraphQL mutation schema
  introspection to infer generated custom-type `*FieldPatch` mutations when the
  target server exposes them.
- OpenCTI field reconciliation accepts explicit per-entity-type mutation maps
  for servers that disable schema introspection or use custom/non-generated
  mutation names.
- Runtime catalog entries and typed parsers exist for Cloudflare DNS, ThreatFox,
  MalwareBazaar, GDELT, Common Crawl, BuiltWith and Wappalyzer.
- Mock fixture structure for P0/P1/P2 parser contracts:
  - `tests/fixtures/sources/github/ok.json`
  - `tests/fixtures/sources/wayback_cdx/ok.json`
  - `tests/fixtures/sources/urlhaus/ok.json`
  - `tests/fixtures/sources/wikidata/ok.json`
  - `tests/fixtures/sources/bgpview/ok.json`
- P1/P2 fixtures for Shodan, Censys, SecurityTrails, GreyNoise, AlienVault OTX,
  ThreatFox, MalwareBazaar, GDELT, Common Crawl and BuiltWith.
- Contract tests for normalized parser output across the implemented P0/P1/P2
  fixtures.
- Case HTML reports now include independent corroboration and review queue
  sections.
- Unified JSON/HTML/Markdown reports include structured source coverage:
  checked, skipped, missing-key, error and expected-but-not-recorded pipeline
  source counts.
- Unified JSON/HTML/Markdown reports and CSV exports include structured source
  health history: latest state by source plus per-run observed health rows.
- Unified JSON/HTML/Markdown reports include `risk_summary`, separating a
  case-exposure risk score from the average confidence score and listing score
  drivers.
- `reports-manifest.json` includes SHA-256 evidence for generated report
  artifacts and `reports-verify` verifies report files against the manifest
  offline, including tamper/missing-file detection.
- `/reports` now surfaces report integrity status, `/reports/verify` exposes
  report manifest verification as JSON, and
  `/reports/evidence-bundle/{case}/inspect` exposes evidence bundle integrity
  checks without opening the ZIP manually.
- Case workspace exports now include an `integrity` summary covering report
  manifest verification, evidence bundle inspection and evidence vault artifact
  hash coverage; HTML/raw snapshots are written as exact UTF-8 bytes so stored
  SHA-256 values match disk artifacts on Windows and Unix.
- Integrity regression tests cover byte-stable snapshot hashes, tampered report
  artifacts and missing evidence vault artifacts without network calls.
- STIX export includes evidence artifacts; TAXII-compatible envelope export and
  STIX bundle import helpers are implemented.
- Job queue durability is heartbeat-backed:
  - `ScanJob` stores worker claim and heartbeat fields;
  - job durability landed in schema migration `5`; current storage schema is
    `8` after live-validation export hash manifest persistence;
  - workers claim jobs with worker id and heartbeat;
  - stale claimed/running jobs can be recovered to queued;
  - worker status reports claimed and stale active counts.
- `username-catalog-coverage` benchmarks the packaged username catalog against
  external Sherlock/Maigret/WhatsMyName-style JSON files without copying
  upstream data, reporting overlap, missing candidates and category gaps.
- `source-quality-gate` runs an offline per-source quality gate for docs/policy
  metadata, legal risk, cache/quota policy, parser maturity, `ok` fixtures and
  error/rate-limit/schema fixture variants; `--strict` treats warnings as
  failures.
- The strict offline source-quality gate is green for all runtime API entries:
  56 checked, 56 passed, 0 warnings, 0 failures.
- Domain pipelines now run both Google Public DNS and Cloudflare DNS where
  selected, classify DNS A/AAAA answers as `ip` entities, and annotate matching
  resolver answers as normalized DNS corroboration evidence.

Still not implemented:

- Successful live external API verification against user-provided real
  credentials/network access.
- Successful live media reverse-search validation against user-provided real
  provider accounts.
- Live OpenCTI custom mutation-map validation against a real instance with
  schema introspection disabled.

## Phase 0: Guardrails Before More Sources

1. Freeze the source adapter contract:
   - `source_id`
   - `target`
   - `input_type`
   - `status`
   - `confidence`
   - `normalized.entities`
   - `normalized.relations`
   - `normalized.findings`
   - `normalized.timeline`
   - `raw/evidence`
2. Add per-source policy fields to runtime decisions:
   - `tos_privacy_risk`
   - `public_only`
   - `cache_policy`
   - `quota_policy`
   - `requires_human_review`
3. Require mocked API fixtures for every new adapter.
4. Default to lookup-only workflows for reputation and archive APIs.
5. Default to no upload for URLs/files/images unless the user explicitly opts in.

## Phase 1: P0 Sources

| Source | Module | Why first | Acceptance criteria |
|---|---|---|---|
| RDAP.org | `api_rdap` | Legal, public domain/IP registration | normalized registrar/events/entities, tests |
| crt.sh | `api_crtsh` | Strong CT subdomain source | suffix filtering, dedupe, wildcard handling |
| Google DNS | `api_google_dns` | Reliable no-key DNS | A/AAAA/MX/TXT/NS/CNAME normalization |
| VirusTotal | `api_virustotal` | High value URL/hash/domain reputation | lookup-only default, no private upload |
| urlscan.io | `api_urlscan` | URL evidence and page graph | search/result first, submission opt-in |
| URLhaus | `api_urlhaus` | Safe malware URL/hash source | IOC/findings normalization |
| HIBP | `api_hibp` | Legal breach exposure | no secrets/dumps, breach metadata only |
| GitHub REST | `api_github` | Developer footprint | users/repos/org graph, rate-limit handling |
| Wayback CDX | `api_wayback_cdx` | Archive evidence | capture timeline and status/digest fields |
| Wikidata | `api_wikidata` | Canonical graph enrichment | same-as links with provenance caveats |
| BGPView | `api_bgpview` | ASN/IP context | ASN/prefix/org graph nodes |
| ipwho.is | `api_ipwhois` | No-key IP geo/ASN | approximate geo caveat |
| ExifTool | `local_exiftool` | Local file evidence | sensitive GPS handling in report |

## Phase 2: P1 Sources

Add keyed/high-value sources after P0 contract tests are stable:

- Cloudflare DNS as resolver corroboration.
- SecurityTrails for historical DNS.
- Shodan and Censys for passive internet exposure.
- GreyNoise for internet-noise separation.
- AlienVault OTX and ThreatFox for TI enrichment.
- MalwareBazaar for hash lookup only.
- EmailRep and Hunter for email/domain context.
- GitLab for developer footprint.
- OpenCorporates and Companies House for company registries.
- PeeringDB and IPinfo for ASN/IP context.
- Nominatim for policy-compliant geocoding.
- Blockchain.com and Blockchair for public blockchain lookup.
- Twilio Lookup only in authorized phone intelligence mode.
- OpenCTI and MISP compatibility patterns.

## Phase 3: P2/P3 Sources

Use these after product controls are mature:

- Reddit and YouTube official APIs for public media/social context.
- Google Programmable Search as optional search enrichment.
- OpenSanctions only in compliance/legal mode.
- GDELT and Common Crawl for media/public dataset enrichment.
- BuiltWith/Wappalyzer for web technology fingerprinting.
- TinEye/InVID workflow for media verification.
- Overpass for geo context.
- Nuclei only as explicit authorized active-check plugin.
- Metagoofil/FOCA/Photon as workflow benchmarks, not default automation.

## Implementation Task Backlog

### Adapter Platform

1. Add a `SourcePolicy` model that loads from the catalog.
2. Enforce `max_terms_risk` in `source-run` and `pipeline-run`.
3. Add `requires_opt_in_upload` for media reverse search providers beyond the
   current urlscan and VirusTotal guarded execution paths.
4. Add per-source mock fixture loading:
   - `tests/fixtures/sources/<source_id>/ok.json`
   - `tests/fixtures/sources/<source_id>/not_found.json`
   - `tests/fixtures/sources/<source_id>/rate_limited.json`
5. Add contract tests for normalized output.

### P0 Adapter Tasks

1. Harden `api_crtsh` typed parser.
2. Harden `api_rdap` typed parser for domain and IP.
3. Add Cloudflare/Google resolver comparison. Done: domain pipeline includes
   both resolvers and emits `dns_resolver_corroborated` timeline evidence when
   answers match.
4. Add URLhaus typed parser.
5. Add Wayback CDX typed parser.
6. Add GitHub REST typed parser with token optionality.
7. Add Wikidata SPARQL/API typed parser.
8. Add BGPView typed parser.
9. Add report sections:
   - source coverage
   - unverified claims
   - independent corroboration count
   - legal/privacy scope

### P1 Adapter Tasks

1. Add keyed source configuration checklist for Shodan, Censys,
   SecurityTrails, GreyNoise, VirusTotal, Hunter, Twilio and IPinfo. Done:
   `/api-keys` now shows a P1 keyed-source setup panel and `/api-keys/setup`
   returns a safe JSON plan with blank env-var templates only.
2. Add OS-specific secure installer/service integration for encrypted API key
   storage.
3. Tune provider-specific rate-limit preset values against real account quotas
   after live validation.
4. Add "passive only" labels for Shodan/Censys/Amass/Subfinder-style data.
   Done: source policy, persisted source notes, case summaries, HTML/Markdown
   reports and CSV source exports include policy labels.
5. Add "sensitive data" labels for phone, breach and sanctions data. Done:
   policy context marks sensitive data sources and reports surface the caveat.

## Architecture Recommendation

BEDNIIOSINT should keep this shape:

- `SourceAdapter`: one source, one target, one normalized result.
- `SourceRegistry`: catalog + built-ins + plugins + local config.
- `SourcePolicy`: legal risk, cache, quota, upload, active/passive flags.
- `Normalizer`: maps raw output to entities/relations/findings/timeline.
- `EvidenceStore`: raw JSON, request metadata, response metadata, hashes.
- `ConfidenceEngine`: source reliability + target-specific signals +
  independent corroboration.
- `EntityResolution`: deterministic same-as clusters first; no opaque identity
  inference without evidence.
- `JobQueue`: resumable, heartbeat-backed, cache-aware pipeline runs.
- `ReportRenderer`: human-readable summaries with source provenance and caveats.
- `TestHarness`: mocked API responses and normalization contract tests.

## Definition of Done for Each New Source

- Official docs URL recorded.
- Legal/privacy risk assigned.
- API key/env var documented if needed.
- Cache/rate-limit policy assigned.
- Typed parser added or explicitly marked generic.
- Normalized entities/relations/findings produced.
- Raw evidence preserved.
- Unit tests cover success, missing, rate-limit and error cases.
- Report output shows source, timestamp, confidence and caveats.
