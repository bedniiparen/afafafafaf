# Top-1 OSS Backlog

This backlog tracks the large items that should not be done as risky blind
rewrites.

## P0

- Finish SQLModel migration one table family at a time. Case lookup and summary
  read paths are started on the SQLAlchemy repository layer.
- Split `web/app.py` into FastAPI routers while preserving all routes. API keys,
  cases, sources, monitoring and reports routers are started.
- Split `cli.py` into Typer sub-apps while preserving command names. API keys,
  monitoring, jobs and reports sub-apps are started; old aliases are still
  registered.
- Expand redaction tests across every export path.
- Extend scheduled monitoring notifications. CLI schedules, due-run execution,
  web/API alert view, JSON state, JSONL notifications and optional webhook
  delivery are started.
- Continue security hardening. Secret-store KDF audit and rotation commands are
  started; broaden tests across every secret-bearing export/log path.

## P1

- Safe username catalog merge from compatible external catalogs after license
  review.
- More passive DNS and CT providers.
- ASN/BGP enrichment beyond the current baseline.
- Jurisdiction-specific business registry adapters.
- Per-source cache TTL presets are started; refine exact TTLs when provider
  docs/quotas are confirmed.
- More notification adapters for monitor alerts.

## P2

- Docs site publication workflow.
- PyPI release workflow is started with `.github/workflows/release.yml`.
- Semver release checklist is started in `docs/release.md`.
- External contributor guide and issue templates.

## Do Not Regress

- Username false-positive controls.
- Evidence vault SHA-256 manifests.
- Legal-first passive defaults.
- Fixture-backed offline quality gate.
