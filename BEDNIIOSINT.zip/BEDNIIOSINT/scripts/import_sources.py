from __future__ import annotations

"""Fetch and merge external username-check catalogs into sites.json."""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx

from bedniiosint.modules.username.catalog import (
    merge_site_catalogs,
    username_catalog_coverage,
)


REPO = Path(__file__).resolve().parents[1]
BASE = REPO / "bedniiosint" / "modules" / "username" / "sites.json"
IMPORT_DIR = REPO / "data" / "imports"
PACKAGED_WMN = REPO / "bedniiosint" / "data" / "wmn-data.json"
OUT = BASE

SOURCES = {
    "sherlock": (
        [
            "https://raw.githubusercontent.com/sherlock-project/sherlock/master/sherlock_project/resources/data.json",
            "https://raw.githubusercontent.com/sherlock-project/sherlock/main/sherlock_project/resources/data.json",
            "https://raw.githubusercontent.com/sherlock-project/sherlock/master/sherlock/resources/data.json",
            "https://raw.githubusercontent.com/sherlock-project/sherlock/main/sherlock/resources/data.json",
        ],
        "flat_dict",
    ),
    "maigret": (
        [
            "https://raw.githubusercontent.com/soxoj/maigret/main/maigret/resources/data.json",
            "https://raw.githubusercontent.com/soxoj/maigret/master/maigret/resources/data.json",
        ],
        "flat_dict",
    ),
    "whatsmyname": (
        [
            "https://raw.githubusercontent.com/WebBreacher/WhatsMyName/main/wmn-data.json",
            "https://raw.githubusercontent.com/WebBreacher/WhatsMyName/master/wmn-data.json",
        ],
        "wmn",
    ),
    "nexfil": (
        [
            "https://raw.githubusercontent.com/thewhiteh4t/nexfil/main/src/nexfil/url_store.json",
            "https://raw.githubusercontent.com/thewhiteh4t/nexfil/master/src/nexfil/url_store.json",
        ],
        "nexfil",
    ),
}


def _nexfil_name(url: str, index: int) -> str:
    parsed = urlparse(url)
    host = parsed.netloc.lower().removeprefix("www.")
    base = host.split(".", 1)[0] if host else f"nexfil_{index}"
    path_tokens = [
        token
        for token in re.split(r"[^A-Za-z0-9]+", parsed.path)
        if token and "{" not in token and token.lower() not in {"u", "user", "users", "profile"}
    ]
    suffix = "_" + path_tokens[0].lower() if path_tokens else ""
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{base}{suffix}").strip("_") or f"nexfil_{index}"


def _wrap_nexfil(raw: Any) -> Any:
    sites: dict[str, dict[str, Any]] = {}
    if not isinstance(raw, list):
        return {"sites": sites}
    seen: dict[str, int] = {}
    for index, item in enumerate(raw, start=1):
        if not isinstance(item, dict) or not item.get("url"):
            continue
        url = str(item["url"])
        base_name = _nexfil_name(url, index)
        seen[base_name] = seen.get(base_name, 0) + 1
        name = base_name if seen[base_name] == 1 else f"{base_name}_{seen[base_name]}"
        site: dict[str, Any] = {
            "url": url,
            "errorType": "status_code",
            "cat": "misc",
            "provenance_format": "nexfil",
        }
        if item.get("test") == "string" and item.get("data"):
            site["errorType"] = "message"
            site["m_string"] = item["data"]
        elif item.get("test"):
            site["nexfil_test"] = item.get("test")
            site["nexfil_data"] = item.get("data")
        sites[name] = site
    return {"sites": sites}


def _wrapped_payload(raw: Any, kind: str) -> Any:
    if kind == "flat_dict":
        if isinstance(raw, dict) and isinstance(raw.get("sites"), dict):
            return {"sites": raw["sites"]}
        return {"sites": raw if isinstance(raw, dict) else {}}
    if kind == "nexfil":
        return _wrap_nexfil(raw)
    return raw


def _selected_sources(names: list[str] | None = None) -> dict[str, tuple[list[str], str]]:
    selected = list(names or [])
    if not selected:
        return dict(SOURCES)
    unknown = sorted(set(selected) - set(SOURCES))
    if unknown:
        raise ValueError("unknown source(s): " + ", ".join(unknown))
    return {name: SOURCES[name] for name in selected}


def fetch_all(names: list[str] | None = None) -> list[Path]:
    IMPORT_DIR.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    with httpx.Client(timeout=60, follow_redirects=True) as client:
        for name, (urls, kind) in _selected_sources(names).items():
            response: httpx.Response | None = None
            errors: list[str] = []
            for url in urls:
                print(f"[fetch] {name} <- {url}")
                try:
                    candidate = client.get(url)
                    candidate.raise_for_status()
                except httpx.HTTPError as exc:
                    errors.append(f"{url}: {exc}")
                    continue
                response = candidate
                break
            if response is None:
                print(f"[fetch] {name} failed; tried {len(urls)} URL(s)", file=sys.stderr)
                for error in errors:
                    print(f"        {error}", file=sys.stderr)
                continue
            payload = _wrapped_payload(response.json(), kind)
            dst = IMPORT_DIR / f"{name}.json"
            dst.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            print(f"        saved -> {dst}")
            paths.append(dst)
    return paths


def existing_files(names: list[str] | None = None) -> list[Path]:
    selected = _selected_sources(names)
    paths = [
        IMPORT_DIR / f"{name}.json"
        for name in selected
        if (IMPORT_DIR / f"{name}.json").exists()
    ]
    if "whatsmyname" in selected and not any(path.stem == "whatsmyname" for path in paths) and PACKAGED_WMN.exists():
        paths.append(PACKAGED_WMN)
    return paths


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Fetch and merge Sherlock/Maigret/WhatsMyName/Nexfil username catalogs."
    )
    parser.add_argument("--dry-run", action="store_true", help="Report coverage without writing sites.json")
    parser.add_argument("--offline", action="store_true", help="Use already-downloaded data/imports/*.json")
    parser.add_argument("--overwrite", action="store_true", help="Replace duplicate existing site definitions")
    parser.add_argument(
        "--source",
        action="append",
        choices=sorted(SOURCES),
        help="Limit import to one source; repeatable",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        paths = existing_files(args.source) if args.offline else fetch_all(args.source)
    except (httpx.HTTPError, json.JSONDecodeError, OSError, ValueError) as exc:
        print(f"Import fetch failed: {exc}", file=sys.stderr)
        return 2
    if not paths:
        print("No import files found. Run without --offline first.", file=sys.stderr)
        return 1

    coverage = username_catalog_coverage(BASE, paths)
    print("\n[coverage] base sites:", coverage["summary"]["base_sites"])
    print("[coverage] external valid:", coverage["summary"]["external_valid"])
    print("[coverage] unique missing:", coverage["summary"]["unique_missing"])
    print(
        "[coverage] potential total after merge:",
        coverage["summary"]["potential_total_after_merge"],
    )

    result = merge_site_catalogs(
        BASE,
        paths,
        OUT,
        overwrite=args.overwrite,
        dry_run=args.dry_run,
    )
    print("[merge] added:", result["added"])
    print("[merge] replaced:", result["replaced"])
    print("[merge] skipped:", result["skipped"])
    print("[merge] TOTAL sites now:", result["stats"]["sites"])
    if args.dry_run:
        print("(dry-run: sites.json was NOT modified)")
    else:
        print(f"(written to {OUT})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
