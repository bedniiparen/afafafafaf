param(
    [switch]$Yes,
    [switch]$KeepVenv
)

$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $PSScriptRoot
$ResolvedRoot = (Resolve-Path -LiteralPath $Root).Path
Set-Location $ResolvedRoot

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Test-InsideRoot {
    param([string]$Path)
    try {
        $resolved = (Resolve-Path -LiteralPath $Path -ErrorAction Stop).Path
    } catch {
        return $false
    }
    return $resolved -eq $ResolvedRoot -or $resolved.StartsWith($ResolvedRoot + [IO.Path]::DirectorySeparatorChar)
}

function Add-ExistingTarget {
    param(
        [System.Collections.Generic.List[string]]$Targets,
        [string]$Path
    )
    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }
    if (-not (Test-InsideRoot -Path $Path)) {
        Write-Host "Skipping unsafe path outside project: $Path" -ForegroundColor Yellow
        return
    }
    $Targets.Add((Resolve-Path -LiteralPath $Path).Path)
}

function Add-GlobTargets {
    param(
        [System.Collections.Generic.List[string]]$Targets,
        [string]$Pattern,
        [string[]]$ExcludeNames = @()
    )
    Get-ChildItem -Path $ResolvedRoot -Force -File -Filter $Pattern -ErrorAction SilentlyContinue | ForEach-Object {
        if ($ExcludeNames -contains $_.Name) {
            return
        }
        Add-ExistingTarget -Targets $Targets -Path $_.FullName
    }
}

function Remove-Target {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        return $false
    }
    if (-not (Test-InsideRoot -Path $Path)) {
        Write-Host "Skipping unsafe path outside project: $Path" -ForegroundColor Yellow
        return $false
    }
    Remove-Item -LiteralPath $Path -Recurse -Force
    return $true
}

function Get-DisplayPath {
    param([string]$Path)
    if ($Path -eq $ResolvedRoot) {
        return "."
    }
    if ($Path.StartsWith($ResolvedRoot + [IO.Path]::DirectorySeparatorChar)) {
        return $Path.Substring($ResolvedRoot.Length + 1)
    }
    return $Path
}

$targets = [System.Collections.Generic.List[string]]::new()

$directories = @(
    "runtime\cases",
    "runtime\reports_out",
    "runtime\.pytest_cache",
    "runtime\.mypy_cache",
    "runtime\.ruff_cache",
    "runtime\htmlcov",
    "runtime\dist",
    "runtime\build",
    "runtime\site",
    "runtime\tmp",
    "runtime\temp",
    "runtime\cache",
    "cases",
    "reports_out",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "config\.pytest_cache",
    "config\.mypy_cache",
    "config\.ruff_cache",
    "htmlcov",
    "dist",
    "build",
    "tmp",
    "temp",
    "cache"
)

if (-not $KeepVenv) {
    $directories += "runtime\.venv"
    $directories += ".venv"
}

foreach ($name in $directories) {
    Add-ExistingTarget -Targets $targets -Path (Join-Path $ResolvedRoot $name)
}

Get-ChildItem -Path $ResolvedRoot -Force -Directory -Filter "*_vault" -ErrorAction SilentlyContinue | ForEach-Object {
    Add-ExistingTarget -Targets $targets -Path $_.FullName
}

Get-ChildItem -Path $ResolvedRoot -Force -Directory -Filter "*.egg-info" -ErrorAction SilentlyContinue | ForEach-Object {
    Add-ExistingTarget -Targets $targets -Path $_.FullName
}

foreach ($rootName in @("bedniiosint", "tests", "scripts", "tools")) {
    $scanRoot = Join-Path $ResolvedRoot $rootName
    if (-not (Test-Path -LiteralPath $scanRoot)) {
        continue
    }
    Get-ChildItem -Path $scanRoot -Force -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue | ForEach-Object {
        Add-ExistingTarget -Targets $targets -Path $_.FullName
    }
    Get-ChildItem -Path $scanRoot -Force -Recurse -File -Include "*.pyc","*.pyo" -ErrorAction SilentlyContinue | ForEach-Object {
        Add-ExistingTarget -Targets $targets -Path $_.FullName
    }
}

foreach ($fileName in @(".env", ".coverage", "bedniiosint.env", "config\.env", "config\bedniiosint.env")) {
    Add-ExistingTarget -Targets $targets -Path (Join-Path $ResolvedRoot $fileName)
}

Add-GlobTargets -Targets $targets -Pattern ".env.*" -ExcludeNames @(".env.example")
Add-GlobTargets -Targets $targets -Pattern "*.log"

$runtimeRoot = Join-Path $ResolvedRoot "runtime"
if (Test-Path -LiteralPath $runtimeRoot) {
    Get-ChildItem -Path $runtimeRoot -Force -File -Filter "*-check.html" -ErrorAction SilentlyContinue | ForEach-Object {
        Add-ExistingTarget -Targets $targets -Path $_.FullName
    }
}

$uniqueTargets = $targets | Sort-Object -Unique

if (-not $uniqueTargets) {
    Write-Host "Nothing to clear."
    exit 0
}

Write-Step "BEDNIIOSINT cleanup will remove these generated files and folders"
$uniqueTargets | ForEach-Object {
    $relative = Get-DisplayPath -Path $_
    Write-Host "- $relative"
}

Write-Host ""
Write-Host "Kept: source code, docs, data catalogs, requirements, Docker files, README and config\env.example." -ForegroundColor Green
Write-Host "Removed: runtime cases, reports, local secrets/env files, caches, logs and virtualenv unless --KeepVenv is used." -ForegroundColor Yellow

# clear.bat is intentionally non-interactive: double-clicking it should clean
# generated data immediately. -Yes remains accepted for old scripts/docs.

$removed = 0
foreach ($target in $uniqueTargets) {
    if (Remove-Target -Path $target) {
        $removed += 1
    }
}

Write-Step "Cleanup complete"
Write-Host "Removed $removed item(s)."
Write-Host "Run start.bat to recreate runtime\.venv and start the dashboard."
exit 0
