from __future__ import annotations

"""Fetch public discovery-only domain catalogs for search-engine dorks."""

import argparse
import sys
from pathlib import Path

import httpx

from bedniiosint.search.search_only_catalog import (
    DEFAULT_SEARCH_ONLY_FILE,
    dedupe_sites,
    parse_markdown_sites,
    username_catalog_disabled_search_sites,
    username_catalog_hosts,
    write_catalog,
)


REPO = Path(__file__).resolve().parents[1]
IMPORT_DIR = REPO / "data" / "imports"
OUT = DEFAULT_SEARCH_ONLY_FILE

SOURCES = {
    "snoop_websites": {
        "urls": [
            "https://raw.githubusercontent.com/snooppr/snoop/master/websites.md",
            "https://raw.githubusercontent.com/snooppr/snoop/main/websites.md",
        ],
        "category": "public_profile_discovery",
        "license_note": (
            "Snoop public websites.md discovery list; BDdemo/BDfull/BDflag data is not imported."
        ),
    }
}


def fetch_text(name: str) -> str:
    source = SOURCES[name]
    errors: list[str] = []
    with httpx.Client(timeout=60, follow_redirects=True) as client:
        for url in source["urls"]:
            print(f"[fetch] {name} <- {url}")
            try:
                response = client.get(url)
                response.raise_for_status()
            except httpx.HTTPError as exc:
                errors.append(f"{url}: {exc}")
                continue
            IMPORT_DIR.mkdir(parents=True, exist_ok=True)
            dst = IMPORT_DIR / f"{name}.md"
            dst.write_text(response.text, encoding="utf-8")
            print(f"        saved -> {dst}")
            return response.text
    for error in errors:
        print(f"        {error}", file=sys.stderr)
    raise RuntimeError(f"{name} fetch failed")


def existing_text(name: str) -> str:
    path = IMPORT_DIR / f"{name}.md"
    if not path.exists():
        raise FileNotFoundError(f"{path} not found; run without --offline first")
    return path.read_text(encoding="utf-8-sig")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build search-only public domain dork catalog.")
    parser.add_argument("--offline", action="store_true", help="Use data/imports/*.md instead of network")
    parser.add_argument(
        "--offline-local",
        action="store_true",
        help="Build only from packaged local catalogs; no network and no cached markdown required",
    )
    parser.add_argument("--dry-run", action="store_true", help="Report counts without writing JSON")
    parser.add_argument("--strict", action="store_true", help="Fail if any remote source cannot be fetched")
    parser.add_argument(
        "--include-overlap",
        action="store_true",
        help="Keep domains already covered by username sites.json",
    )
    parser.add_argument("--out", type=Path, default=OUT, help="Output search_only_sites.json path")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    existing_hosts = username_catalog_hosts()
    all_rows = username_catalog_disabled_search_sites()
    print("[local] disabled username rows as search-only domains:", len(all_rows))
    remote_errors: list[str] = []
    try:
        if not args.offline_local:
            for name, source in SOURCES.items():
                try:
                    text = existing_text(name) if args.offline else fetch_text(name)
                except (OSError, RuntimeError, httpx.HTTPError) as exc:
                    remote_errors.append(f"{name}: {exc}")
                    print(f"[warn] skipped {name}: {exc}", file=sys.stderr)
                    continue
                rows = parse_markdown_sites(
                    text,
                    source=name,
                    category=str(source["category"]),
                    license_note=str(source["license_note"]),
                    existing_hosts=existing_hosts,
                    skip_existing=not args.include_overlap,
                )
                print(f"[parse] {name}: {len(rows)} domain(s)")
                all_rows.extend(rows)
    except (OSError, RuntimeError, httpx.HTTPError) as exc:
        print(f"Search-only import failed: {exc}", file=sys.stderr)
        return 2

    all_rows = dedupe_sites(all_rows)
    if remote_errors and args.strict:
        print("Search-only import failed in strict mode:", file=sys.stderr)
        for error in remote_errors:
            print(f"        {error}", file=sys.stderr)
        return 2
    if remote_errors and not all_rows:
        print("Search-only import failed: no local or remote rows available", file=sys.stderr)
        return 2
    print("[coverage] username catalog hosts:", len(existing_hosts))
    print("[coverage] search-only unique:", len({row.host for row in all_rows}))
    print("[coverage] potential dork domains:", len(all_rows))
    if args.dry_run:
        print("(dry-run: search-only catalog was NOT modified)")
        return 0

    write_catalog(
        args.out,
        all_rows,
        source_notes=[
            "Imported from public website/link lists only.",
            "No Snoop BDdemo, BDfull or BDflag data is bundled.",
        ],
    )
    print(f"(written to {args.out})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
