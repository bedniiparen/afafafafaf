from __future__ import annotations

import argparse
import os
from pathlib import Path
import py_compile
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / "runtime"


def _run(args: list[str], *, cwd: Path = ROOT) -> subprocess.CompletedProcess:
    return subprocess.run(args, cwd=cwd, text=True, capture_output=True)


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)


def _powershell() -> str | None:
    return shutil.which("powershell.exe") or shutil.which("powershell") or shutil.which("pwsh")


def check_root_layout() -> None:
    root_files = sorted(path.name for path in ROOT.iterdir() if path.is_file())
    _require(root_files == ["clear.bat", "start.bat"], f"Unexpected root files: {root_files}")
    for rel in (
        "scripts/start.py",
        "scripts/bootstrap_windows.ps1",
        "scripts/clear_windows.ps1",
        "requirements/base.txt",
        "config/env.example",
        "bedniiosint/web/app.py",
    ):
        _require((ROOT / rel).exists(), f"Required project file is missing: {rel}")


def check_python_syntax() -> None:
    py_compile.compile(str(ROOT / "scripts" / "start.py"), doraise=True)
    py_compile.compile(str(ROOT / "scripts" / "clean.py"), doraise=True)


def check_powershell_syntax() -> None:
    ps = _powershell()
    if ps is None:
        print("PowerShell not found; skipped PowerShell syntax check.")
        return
    command = (
        "$errors=$null; "
        "[System.Management.Automation.PSParser]::Tokenize("
        "(Get-Content -Raw -Path scripts\\clear_windows.ps1), [ref]$errors) > $null; "
        "if ($errors) { $errors | Format-List *; exit 1 }"
    )
    result = _run([ps, "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command])
    _require(result.returncode == 0, result.stderr or result.stdout or "PowerShell syntax check failed")


def check_start_no_server() -> None:
    venv_python = ROOT / "runtime" / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not venv_python.exists():
        print("runtime/.venv is missing; start.bat will recreate it on real launch.")
        return
    result = _run([sys.executable, "scripts/start.py", "--check", "--no-install"])
    _require(result.returncode == 0, result.stderr or result.stdout or "start.py --check failed")


def check_isolated_clear() -> None:
    ps = _powershell()
    if ps is None:
        print("PowerShell not found; skipped isolated clear check.")
        return

    sandbox = RUNTIME / "_launcher_verify"
    if sandbox.exists():
        shutil.rmtree(sandbox)
    try:
        (sandbox / "scripts").mkdir(parents=True)
        shutil.copy2(ROOT / "scripts" / "clear_windows.ps1", sandbox / "scripts" / "clear_windows.ps1")

        for rel in (
            "start.bat",
            "clear.bat",
            "bedniiosint/keep.py",
            "docs/keep.md",
            "data/catalog.json",
            "requirements/base.txt",
            "config/env.example",
            "runtime/.venv/keep.txt",
            "runtime/cases/case.db",
            "runtime/reports_out/report.html",
            "runtime/cache/cache.bin",
            "runtime/ui-check.html",
            "config/.pytest_cache/cache.bin",
            "tools/__pycache__/tool.pyc",
            ".env",
            ".env.local",
            "bedniiosint.env",
            "debug.log",
        ):
            path = sandbox / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("verify", encoding="utf-8")

        result = _run(
            [
                ps,
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(sandbox / "scripts" / "clear_windows.ps1"),
                "-KeepVenv",
            ],
            cwd=sandbox,
        )
        _require(result.returncode == 0, result.stderr or result.stdout or "isolated clear failed")

        kept = (
            "start.bat",
            "clear.bat",
            "bedniiosint/keep.py",
            "docs/keep.md",
            "data/catalog.json",
            "requirements/base.txt",
            "config/env.example",
            "runtime/.venv/keep.txt",
        )
        removed = (
            "runtime/cases",
            "runtime/reports_out",
            "runtime/cache",
            "runtime/ui-check.html",
            "config/.pytest_cache",
            "tools/__pycache__",
            ".env",
            ".env.local",
            "bedniiosint.env",
            "debug.log",
        )
        for rel in kept:
            _require((sandbox / rel).exists(), f"clear removed required file: {rel}")
        for rel in removed:
            _require(not (sandbox / rel).exists(), f"clear left generated file: {rel}")
    finally:
        if sandbox.exists():
            shutil.rmtree(sandbox)


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify BEDNIIOSINT start.bat and clear.bat safety.")
    parser.add_argument(
        "--skip-start-check",
        action="store_true",
        help="Skip start.py --check and only validate static launcher safety.",
    )
    args = parser.parse_args()

    check_root_layout()
    check_python_syntax()
    check_powershell_syntax()
    check_isolated_clear()
    if not args.skip_start_check:
        check_start_no_server()
    print("Launcher verification OK.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
