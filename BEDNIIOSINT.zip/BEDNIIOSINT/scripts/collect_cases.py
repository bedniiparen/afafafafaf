from __future__ import annotations

"""Batch-collect real pipeline payloads to feed benchmark dataset tools."""

import argparse
import json
import re
import sys
from collections.abc import Callable, Iterable
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _slug(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")[:80] or "target"


def _normalize_targets(raw: Iterable[Any]) -> list[dict[str, str]]:
    targets: list[dict[str, str]] = []
    for item in raw:
        if isinstance(item, str):
            clean = item.strip()
            if clean:
                targets.append({"target": clean, "entity_type": ""})
            continue
        if isinstance(item, dict) and item.get("target"):
            targets.append(
                {
                    "target": str(item["target"]).strip(),
                    "entity_type": str(item.get("entity_type") or "").strip(),
                }
            )
    return [row for row in targets if row["target"]]


def _default_pipeline() -> Callable[..., dict[str, Any]]:
    from bedniiosint.search.pipeline import run_planned_search_pipeline

    return run_planned_search_pipeline


def collect(
    targets: list[dict[str, str]],
    out_dir: Path,
    *,
    pipeline: Callable[..., dict[str, Any]] | None = None,
    max_sources: int | None = None,
    concurrent: bool = False,
    max_workers: int = 8,
    include_username_scan: bool = False,
    max_results: int | None = None,
) -> list[Path]:
    run = pipeline or _default_pipeline()
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for index, entry in enumerate(targets, start=1):
        target = entry["target"]
        entity_type = entry.get("entity_type") or None
        print(f"[{index}/{len(targets)}] {entity_type or 'auto'}: {target}")
        payload = run(
            target,
            entity_type=entity_type,
            max_sources=max_sources,
            concurrent=concurrent,
            max_workers=max_workers,
            include_username_scan=include_username_scan,
        )
        results = list(payload.get("search_results") or [])
        normalized_results = [
            row.as_dict() if hasattr(row, "as_dict") else dict(row)
            for row in results
            if row is not None
        ]
        if max_results is not None:
            normalized_results = normalized_results[:max_results]
        slug = f"{_slug(entity_type or 'auto')}_{_slug(target)}.json"
        path = out_dir / slug
        path.write_text(
            json.dumps(
                {
                    "target": target,
                    "entity_type": entity_type or "",
                    "search_results": normalized_results,
                },
                ensure_ascii=False,
                indent=2,
                default=str,
            ),
            encoding="utf-8",
        )
        written.append(path)
        print(f"    saved {len(normalized_results)} result(s) -> {path}")
    return written


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Batch-collect pipeline payloads for benchmarking")
    parser.add_argument("--targets", help="JSON list of targets")
    parser.add_argument("--target", action="append", default=[], help="single target; repeatable")
    parser.add_argument("--out", default="runtime/cases")
    parser.add_argument("--max-sources", type=int, default=None)
    parser.add_argument("--concurrent", action="store_true")
    parser.add_argument("--max-workers", type=int, default=8)
    parser.add_argument("--username-scan", action="store_true")
    parser.add_argument("--max-results", type=int, default=None, help="cap results saved per case")
    args = parser.parse_args(argv)

    raw: list[Any] = []
    if args.targets:
        raw = json.loads(Path(args.targets).read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            print("--targets must point to a JSON list", file=sys.stderr)
            return 2
    raw.extend(args.target)
    targets = _normalize_targets(raw)
    if not targets:
        print("No targets given. Use --targets file.json or --target value.", file=sys.stderr)
        return 2

    written = collect(
        targets,
        Path(args.out),
        max_sources=args.max_sources,
        concurrent=args.concurrent,
        max_workers=args.max_workers,
        include_username_scan=args.username_scan,
        max_results=args.max_results,
    )
    print(f"\nDone: {len(written)} case file(s) under {args.out}")
    print(
        "Next: python -m scripts.make_dataset scaffold-gt "
        f"{args.out}/*.json --target <name> --entity-type <type>"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
