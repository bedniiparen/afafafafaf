from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from bedniiosint.eval.benchmark import (
    dataset_summary,
    load_dataset,
    report_markdown,
    run_benchmark,
    validate_dataset,
)
from bedniiosint.search.pipeline import run_planned_search_pipeline


def _case_key(target: str, entity_type: str) -> str:
    return f"{entity_type}::{target}"


def _build_search_fn(args: argparse.Namespace):
    def search_fn(target: str, entity_type: str):
        payload = run_planned_search_pipeline(
            target,
            entity_type=entity_type,
            scope=args.scope,
            max_sources=args.max_sources,
            include_auth_required=args.include_auth_required,
            source_ids=args.source or None,
            available_only=args.configured_only,
            concurrent=args.concurrent,
            max_workers=args.max_workers,
            include_dorking=args.include_dorking,
            include_username_scan=args.include_username_scan,
        )
        return payload.get("search_results") or []

    return search_fn


def _replay_search_fn(path: str | Path):
    fixture = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(fixture, dict):
        raise ValueError(f"replay fixture {path} must be a JSON object keyed by case")

    def search_fn(target: str, entity_type: str):
        return list(fixture.get(_case_key(target, entity_type)) or [])

    return search_fn


def _recording_search_fn(inner, sink: dict[str, list[dict[str, Any]]]):
    def search_fn(target: str, entity_type: str):
        predictions = list(inner(target, entity_type))
        rows: list[dict[str, Any]] = []
        for pred in predictions:
            rows.append(pred.as_dict() if hasattr(pred, "as_dict") else dict(pred))
        sink[_case_key(target, entity_type)] = rows
        return predictions

    return search_fn


def _parse_source_thresholds(items: list[str] | None) -> dict[str, float]:
    thresholds: dict[str, float] = {}
    for item in items or []:
        if "=" not in item:
            raise ValueError(f"source threshold must be source=value: {item}")
        source, _, value = item.partition("=")
        source = source.strip()
        if not source:
            raise ValueError(f"source threshold has empty source: {item}")
        thresholds[source] = float(value)
    return thresholds


def _threshold_failures(report: Any, args: argparse.Namespace) -> list[str]:
    checks = {
        "precision": args.min_precision,
        "recall": args.min_recall,
        "f1": args.min_f1,
        "mrr": args.min_mrr,
    }
    failures: list[str] = []
    for name, minimum in checks.items():
        if minimum is None:
            continue
        value = float(getattr(report, name))
        if value < float(minimum):
            failures.append(f"{name} {value:.4f} < {float(minimum):.4f}")
    for source, minimum in _parse_source_thresholds(
        getattr(args, "per_source_min_precision", [])
    ).items():
        stats = report.per_source.get(source)
        value = float(stats.get("precision", 0.0)) if stats else 0.0
        if value < minimum:
            failures.append(f"{source} precision {value:.4f} < {minimum:.4f}")
    for source, minimum in _parse_source_thresholds(
        getattr(args, "source_min_recall", [])
    ).items():
        stats = report.source_recall.get(source)
        value = float(stats.get("recall", 0.0)) if stats else 0.0
        if value < minimum:
            failures.append(f"{source} recall {value:.4f} < {minimum:.4f}")
    return failures


def _write_output(path: Path | None, text: str) -> None:
    if path is None:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run BEDNIIOSINT ground-truth search benchmark with optional CI gates."
    )
    parser.add_argument("dataset", nargs="?", type=Path, help="Path to ground-truth JSON dataset")
    parser.add_argument("--dataset", dest="dataset_option", type=Path, help="Path to ground-truth JSON dataset")
    parser.add_argument("--out", type=Path, help="Write report.json and report.md under this directory")
    parser.add_argument("--json-out", type=Path, help="Write machine-readable report JSON")
    parser.add_argument("--markdown-out", type=Path, help="Write Markdown report")
    parser.add_argument("--markdown", action="store_true", help="Print Markdown instead of JSON")
    parser.add_argument("--replay", type=Path, help="Score against a recorded fixture; no live search")
    parser.add_argument("--record", type=Path, help="Run live search and snapshot predictions to this fixture")
    parser.add_argument("--max-sources", type=int, default=None)
    parser.add_argument("--source", action="append", default=[], help="Limit to search source id; repeatable")
    parser.add_argument("--scope", default=None)
    parser.add_argument("--validate-only", action="store_true", help="Validate dataset shape without running search")
    parser.add_argument("--min-cases", type=int, default=1, help="Minimum labeled cases for dataset validation")
    parser.add_argument("--min-entity-types", type=int, default=1, help="Minimum distinct entity types for validation")
    parser.add_argument("--include-auth-required", action="store_true")
    parser.add_argument("--configured-only", action="store_true")
    parser.add_argument("--concurrent", action="store_true")
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--include-dorking", action="store_true")
    parser.add_argument("--include-username-scan", action="store_true")
    parser.add_argument("--min-precision", type=float)
    parser.add_argument("--min-recall", type=float)
    parser.add_argument("--min-f1", type=float)
    parser.add_argument("--min-mrr", type=float)
    parser.add_argument(
        "--per-source-min-precision",
        action="append",
        default=[],
        help="Per-source precision gate as source=value; repeatable",
    )
    parser.add_argument(
        "--source-min-recall",
        action="append",
        default=[],
        help="Expected-source recall gate as source=value; repeatable",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    dataset_path = args.dataset_option or args.dataset
    if dataset_path is None:
        print("dataset is required (positional or --dataset)", file=sys.stderr)
        return 2
    if args.replay and args.record:
        print("--replay and --record are mutually exclusive", file=sys.stderr)
        return 2

    dataset = load_dataset(dataset_path)
    issues = validate_dataset(
        dataset,
        min_cases=args.min_cases,
        min_entity_types=args.min_entity_types,
    )
    if args.validate_only:
        payload = {
            "valid": not any(issue.level == "error" for issue in issues),
            "summary": dataset_summary(dataset),
            "issues": [issue.as_dict() for issue in issues],
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0 if payload["valid"] else 2
    errors = [issue for issue in issues if issue.level == "error"]
    if errors:
        print(
            json.dumps(
                {
                    "valid": False,
                    "summary": dataset_summary(dataset),
                    "issues": [issue.as_dict() for issue in issues],
                },
                indent=2,
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        return 2

    record_sink: dict[str, list[dict[str, Any]]] = {}
    try:
        if args.replay:
            search_fn = _replay_search_fn(args.replay)
        else:
            search_fn = _build_search_fn(args)
            if args.record:
                search_fn = _recording_search_fn(search_fn, record_sink)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    report = run_benchmark(dataset, search_fn)
    report_json = json.dumps(report.to_dict(), indent=2, ensure_ascii=False, default=str)
    report_md = report_markdown(report)

    if args.out is not None:
        _write_output(args.out / "report.json", report_json)
        _write_output(args.out / "report.md", report_md)
    _write_output(args.json_out, report_json)
    _write_output(args.markdown_out, report_md)
    if args.record:
        _write_output(
            args.record,
            json.dumps(record_sink, indent=2, ensure_ascii=False, default=str),
        )
    print(report_md if args.markdown else report_json)

    failures = _threshold_failures(report, args)
    if failures:
        print("Benchmark gate failed: " + "; ".join(failures), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
