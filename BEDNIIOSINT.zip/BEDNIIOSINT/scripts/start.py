from __future__ import annotations

import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import webbrowser


ROOT = Path(__file__).resolve().parents[1]
VENV = ROOT / "runtime" / ".venv"
REQUIREMENTS = ROOT / "requirements" / "base.txt"
MINIMAL_PACKAGES = (
    "fastapi>=0.111",
    "uvicorn>=0.30",
    "jinja2>=3.1",
    "httpx>=0.27",
    "typer>=0.12",
    "rich>=13.7",
    "pydantic>=2.7",
    "sqlalchemy>=2.0",
    "sqlmodel>=0.0.21",
    "beautifulsoup4>=4.12",
    "lxml>=5.2",
    "networkx>=3.3",
    "dnspython>=2.6",
)
REQUIRED_IMPORTS = (
    "fastapi",
    "uvicorn",
    "httpx",
    "typer",
    "rich",
    "pydantic",
    "sqlalchemy",
    "sqlmodel",
    "bs4",
    "lxml",
    "jinja2",
    "networkx",
    "dns.resolver",
    "bedniiosint.web.app",
)


def _venv_python() -> Path:
    if os.name == "nt":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def _run(args: list[str], *, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(args, cwd=ROOT, check=check)


def _run_text(args: list[str], *, check: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(args, cwd=ROOT, check=check, capture_output=True, text=True)


def _require_supported_python() -> None:
    if sys.version_info < (3, 11):
        version = ".".join(str(part) for part in sys.version_info[:3])
        raise SystemExit(f"Python 3.11+ is required; detected Python {version}.")


def _python_usable(python: Path) -> bool:
    if not python.exists():
        return False
    try:
        return _run_text([str(python), "-c", "import sys; print(sys.executable)"], check=False).returncode == 0
    except OSError:
        return False


def _create_venv(python: Path) -> None:
    if _python_usable(python):
        return
    if VENV.exists():
        print("Recreating broken virtual environment...")
        shutil.rmtree(VENV, ignore_errors=True)
    print("Creating virtual environment...")
    VENV.parent.mkdir(parents=True, exist_ok=True)
    _run([sys.executable, "-m", "venv", str(VENV)])


def _missing_imports(python: Path) -> list[str]:
    check = (
        "import importlib, json; "
        f"mods={list(REQUIRED_IMPORTS)!r}; "
        "missing=[]\n"
        "for name in mods:\n"
        "    try:\n"
        "        importlib.import_module(name)\n"
        "    except Exception as exc:\n"
        "        missing.append(f'{name}: {type(exc).__name__}: {exc}')\n"
        "print(json.dumps(missing))\n"
        "raise SystemExit(1 if missing else 0)"
    )
    result = _run_text([str(python), "-c", check], check=False)
    try:
        import json

        parsed = json.loads(result.stdout.strip() or "[]")
    except Exception:
        parsed = []
    if isinstance(parsed, list):
        return [str(item) for item in parsed]
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "dependency check failed").strip()
        return [detail]
    return []


def _imports_available(python: Path) -> bool:
    return not _missing_imports(python)


def _flag_enabled(name: str) -> bool:
    return name in sys.argv[1:]


def _install_dependencies(python: Path) -> None:
    _run([str(python), "-m", "ensurepip", "--upgrade"], check=False)
    _run([str(python), "-m", "pip", "install", "--upgrade", "pip"], check=False)
    print("Installing required dashboard dependencies...")
    _run([str(python), "-m", "pip", "install", *MINIMAL_PACKAGES])
    if REQUIREMENTS.exists():
        print("Installing full dependencies from requirements/base.txt...")
        result = _run([str(python), "-m", "pip", "install", "-r", str(REQUIREMENTS)], check=False)
        if result.returncode != 0:
            print("Full dependency install failed; continuing with the required dashboard stack.")
        return
    print("Installing package with optional dependencies...")
    result = _run([str(python), "-m", "pip", "install", "-e", ".[all]"], check=False)
    if result.returncode != 0:
        print("Full optional install failed; continuing with the required dashboard stack.")


def _ensure_dependencies(python: Path) -> None:
    missing = _missing_imports(python)
    if not missing:
        return
    if _flag_enabled("--no-install"):
        names = ", ".join(item.split(":", 1)[0] for item in missing)
        raise SystemExit(f"Launcher check failed: missing dependencies ({names}).")
    print("Missing required dependencies:")
    for item in missing:
        print(f"  - {item}")
    _install_dependencies(python)
    missing = _missing_imports(python)
    if missing:
        names = ", ".join(item.split(":", 1)[0] for item in missing)
        raise SystemExit(
            "Startup failed: required dependencies are still missing "
            f"({names}). Check your internet connection and run start.bat again."
        )


def _port_free(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.2)
        return sock.connect_ex((host, port)) != 0


def _find_port(host: str, start: int, end: int) -> int:
    for port in range(start, end + 1):
        if _port_free(host, port):
            return port
    raise SystemExit(f"No free port found in range {start}-{end}.")


def main() -> int:
    _require_supported_python()
    os.chdir(ROOT)
    check_only = _flag_enabled("--check")
    host = os.environ.get("BEDNIIOSINT_HOST", "127.0.0.1")
    port_start = int(os.environ.get("BEDNIIOSINT_PORT", "8000"))
    port_end = int(os.environ.get("BEDNIIOSINT_PORT_MAX", "8020"))

    python = _venv_python()
    if check_only and _flag_enabled("--no-install"):
        if not _python_usable(python):
            print("BEDNIIOSINT launcher check OK. runtime/.venv will be created on real launch.")
            return 0
        if _missing_imports(python):
            print("BEDNIIOSINT launcher check OK. runtime/.venv dependencies will be installed on real launch.")
            return 0
    _create_venv(python)
    _ensure_dependencies(python)
    if check_only:
        print("BEDNIIOSINT launcher check OK.")
        return 0

    port = _find_port(host, port_start, port_end)
    url = f"http://{host}:{port}"
    print(f"Starting BEDNIIOSINT dashboard: {url}")
    if os.environ.get("BEDNIIOSINT_NO_BROWSER", "").lower() not in {"1", "true", "yes"}:
        webbrowser.open(url)
    return _run(
        [
            str(python),
            "-m",
            "uvicorn",
            "bedniiosint.web.app:app",
            "--host",
            host,
            "--port",
            str(port),
        ]
    ).returncode


if __name__ == "__main__":
    raise SystemExit(main())
