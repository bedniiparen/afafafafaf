from __future__ import annotations

"""Build and validate benchmark ground-truth and calibration datasets."""

import argparse
import glob
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

VALID_ENTITY_TYPES = {"username", "email", "domain", "phone", "name", "ip", "url", "query"}


def _load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _iter_results(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, dict):
        payload = payload.get("search_results") or []
    if not isinstance(payload, list):
        return []
    return [dict(row) for row in payload if isinstance(row, dict)]


def _candidate_key(row: dict[str, Any]) -> str:
    url = str(row.get("url") or "").strip()
    if url:
        return url
    source_id = str(row.get("source_id") or "").strip().lower()
    matched = str(row.get("matched_entity") or row.get("entity_input") or "").strip().lower()
    if source_id and matched:
        return f"{source_id}:{matched}"
    return source_id or matched


def _expand(paths: list[str]) -> list[str]:
    expanded: list[str] = []
    for pattern in paths:
        hits = glob.glob(pattern)
        expanded.extend(hits if hits else [pattern])
    return expanded


def _row_score(row: dict[str, Any]) -> float | None:
    for key in ("confidence", "score", "confidence_score"):
        value = row.get(key)
        if value is None:
            continue
        try:
            return float(value)
        except (TypeError, ValueError):
            continue
    for parent in ("prediction", "result"):
        nested = row.get(parent)
        if isinstance(nested, dict):
            for key in ("confidence", "score", "confidence_score"):
                value = nested.get(key)
                if value is None:
                    continue
                try:
                    return float(value)
                except (TypeError, ValueError):
                    continue
    return None


def _row_label(row: dict[str, Any]) -> int | None:
    for key in ("label", "correct", "is_match", "matched", "positive"):
        if key not in row:
            continue
        value = row.get(key)
        if isinstance(value, str):
            clean = value.strip().lower()
            if clean in {"1", "true", "yes", "match", "matched", "positive", "hit"}:
                return 1
            if clean in {"0", "false", "no", "no_match", "negative", "miss"}:
                return 0
        return 1 if value else 0
    return None


def _validate_ground_truth(path: str | Path) -> tuple[list[str], int]:
    data = _load_json(path)
    errors: list[str] = []
    if not isinstance(data, list):
        return ["ground-truth must be a JSON list"], 0
    for index, case in enumerate(data):
        where = f"ground_truth[{index}]"
        if not isinstance(case, dict):
            errors.append(f"{where}: not an object")
            continue
        if not str(case.get("target") or "").strip():
            errors.append(f"{where}: empty target")
        entity_type = str(case.get("entity_type") or "").strip()
        if entity_type and entity_type not in VALID_ENTITY_TYPES:
            errors.append(f"{where}: unknown entity_type {entity_type!r}")
        expected = case.get("expected")
        if not isinstance(expected, list) or not expected:
            errors.append(f"{where}: expected must be a non-empty list")
    return errors, len(data)


def _validate_pairs(path: str | Path) -> tuple[list[str], tuple[int, int]]:
    data = _load_json(path)
    errors: list[str] = []
    if not isinstance(data, list):
        return ["pairs must be a JSON list"], (0, 0)
    pos = neg = 0
    for index, row in enumerate(data):
        where = f"pairs[{index}]"
        if not isinstance(row, dict):
            errors.append(f"{where}: not an object")
            continue
        score = _row_score(row)
        if score is None:
            errors.append(f"{where}: missing numeric confidence/score")
        elif not 0.0 <= score <= 1.0:
            errors.append(f"{where}: confidence/score must be between 0 and 1")
        label = _row_label(row)
        if label is None:
            errors.append(f"{where}: missing label/correct/is_match")
        else:
            pos += 1 if label else 0
            neg += 0 if label else 1
    if data and (pos == 0 or neg == 0):
        errors.append("pairs must contain both positive and negative labels")
    return errors, (pos, neg)


def cmd_validate(args: argparse.Namespace) -> int:
    errors: list[str] = []
    if args.ground_truth:
        gt_errors, count = _validate_ground_truth(args.ground_truth)
        errors.extend(gt_errors)
        if not gt_errors:
            print(f"OK: {args.ground_truth} ({count} cases)")
    if args.pairs:
        pair_errors, (pos, neg) = _validate_pairs(args.pairs)
        errors.extend(pair_errors)
        if not pair_errors:
            print(f"OK: {args.pairs} ({pos} positive / {neg} negative)")
    if not args.ground_truth and not args.pairs:
        print("Nothing to validate: pass --ground-truth and/or --pairs", file=sys.stderr)
        return 2
    for error in errors:
        print(f"INVALID: {error}", file=sys.stderr)
    return 1 if errors else 0


def cmd_scaffold_gt(args: argparse.Namespace) -> int:
    keys: list[str] = []
    seen: set[str] = set()
    for path in _expand(args.payloads):
        for row in _iter_results(_load_json(path)):
            key = _candidate_key(row)
            if key and key not in seen:
                seen.add(key)
                keys.append(key)
    scaffold = {
        "target": args.target,
        "entity_type": args.entity_type,
        "_instructions": "Set keep=true for genuine hits, then run finalize-gt.",
        "candidates": [{"key": key, "keep": False} for key in keys],
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(scaffold, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote {len(keys)} candidate(s) to {out}. Flip real hits to keep=true.")
    return 0


def cmd_scaffold_pairs(args: argparse.Namespace) -> int:
    rows: list[dict[str, Any]] = []
    for path in _expand(args.payloads):
        for row in _iter_results(_load_json(path)):
            score = _row_score(row)
            if score is None:
                continue
            rows.append(
                {
                    "key": _candidate_key(row),
                    "source_id": row.get("source_id") or "",
                    "target": row.get("entity_input") or "",
                    "confidence": round(float(score), 4),
                    "label": None,
                }
            )
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote {len(rows)} pair stub(s) to {out}. Set each label to 0 or 1.")
    return 0


def cmd_finalize_gt(args: argparse.Namespace) -> int:
    scaffold = _load_json(args.reviewed)
    expected = [
        str(candidate.get("key") or "")
        for candidate in scaffold.get("candidates", [])
        if isinstance(candidate, dict) and candidate.get("keep") and candidate.get("key")
    ]
    if not expected:
        print("No candidates marked keep=true; nothing to add.", file=sys.stderr)
        return 1
    entry = {
        "target": str(scaffold["target"]),
        "entity_type": str(scaffold.get("entity_type") or "username"),
        "expected": expected,
    }
    out = Path(args.out)
    existing: list[Any] = []
    if out.is_file():
        loaded = _load_json(out)
        existing = loaded if isinstance(loaded, list) else []
    existing = [
        row
        for row in existing
        if not (
            isinstance(row, dict)
            and row.get("target") == entry["target"]
            and row.get("entity_type") == entry["entity_type"]
        )
    ]
    existing.append(entry)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Added {entry['target']!r} ({len(expected)} expected) -> {out} ({len(existing)} cases)")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Benchmark dataset builder / validator")
    sub = parser.add_subparsers(dest="command", required=True)

    p_val = sub.add_parser("validate", help="validate ground_truth.json and/or pairs.json")
    p_val.add_argument("--ground-truth")
    p_val.add_argument("--pairs")
    p_val.set_defaults(func=cmd_validate)

    p_gt = sub.add_parser("scaffold-gt", help="build a ground-truth review file from payloads")
    p_gt.add_argument("payloads", nargs="+")
    p_gt.add_argument("--target", required=True)
    p_gt.add_argument("--entity-type", default="username")
    p_gt.add_argument("--out", default="benchmark/_review_gt.json")
    p_gt.set_defaults(func=cmd_scaffold_gt)

    p_pairs = sub.add_parser("scaffold-pairs", help="build calibration pair stubs from payloads")
    p_pairs.add_argument("payloads", nargs="+")
    p_pairs.add_argument("--out", default="benchmark/pairs.todo.json")
    p_pairs.set_defaults(func=cmd_scaffold_pairs)

    p_fin = sub.add_parser("finalize-gt", help="convert a reviewed scaffold into ground_truth.json")
    p_fin.add_argument("reviewed")
    p_fin.add_argument("--out", default="benchmark/ground_truth.json")
    p_fin.set_defaults(func=cmd_finalize_gt)

    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
