from __future__ import annotations

import os
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DIRS = (
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "htmlcov",
    "dist",
    "build",
    "config/.pytest_cache",
    "config/.mypy_cache",
    "config/.ruff_cache",
    "runtime/.pytest_cache",
    "runtime/.mypy_cache",
    "runtime/.ruff_cache",
    "runtime/htmlcov",
    "runtime/dist",
    "runtime/build",
    "runtime/site",
)
DEFAULT_FILE_PATTERNS = (".coverage", "runtime/cases/_http_cache.sqlite")
DEFAULT_FILE_GLOBS = ("runtime/*-check.html",)
GENERATED_DIRS = ("runtime/cases", "runtime/reports_out")


def _inside_root(path: Path) -> bool:
    resolved_root = ROOT.resolve()
    resolved = path.resolve()
    return resolved == resolved_root or resolved.is_relative_to(resolved_root)


def _remove(path: Path) -> bool:
    if not path.exists() or not _inside_root(path):
        return False
    if path.is_dir():
        shutil.rmtree(path)
        return True
    path.unlink()
    return True


def main() -> int:
    removed: list[str] = []
    include_generated = os.environ.get("BEDNIIOSINT_CLEAN_GENERATED", "").lower() in {
        "1",
        "true",
        "yes",
    }

    targets = list(DEFAULT_DIRS)
    if include_generated:
        targets.extend(GENERATED_DIRS)

    for name in targets:
        path = ROOT / name
        if _remove(path):
            removed.append(str(path.relative_to(ROOT)))

    for name in DEFAULT_FILE_PATTERNS:
        path = ROOT / name
        if _remove(path):
            removed.append(str(path.relative_to(ROOT)))

    for pattern in DEFAULT_FILE_GLOBS:
        for path in ROOT.glob(pattern):
            if _remove(path):
                removed.append(str(path.relative_to(ROOT)))

    for root_name in ("bedniiosint", "tests", "scripts", "tools"):
        root = ROOT / root_name
        if not root.exists():
            continue
        for cache_dir in root.rglob("__pycache__"):
            if _remove(cache_dir):
                removed.append(str(cache_dir.relative_to(ROOT)))
        for compiled in root.rglob("*.py[co]"):
            if _remove(compiled):
                removed.append(str(compiled.relative_to(ROOT)))

    if removed:
        print("Removed:")
        for item in removed:
            print(f"- {item}")
    else:
        print("Nothing to clean.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
