from __future__ import annotations

"""Pairwise learning-to-rank over confidence signals."""

import argparse
import json
import math
import random
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from bedniiosint.core.confidence_weights import DEFAULT_WEIGHTS

SIGNAL_FIELDS = tuple(DEFAULT_WEIGHTS)


def _sigmoid(value: float) -> float:
    if value >= 40:
        return 1.0
    if value <= -40:
        return 0.0
    return 1.0 / (1.0 + math.exp(-value))


def _features(row: dict[str, Any]) -> dict[str, float]:
    signals = row.get("signals")
    source = signals if isinstance(signals, dict) else row
    out: dict[str, float] = {}
    for field in SIGNAL_FIELDS:
        if field not in source:
            continue
        try:
            out[field] = 1.0 if bool(source.get(field)) else 0.0
        except Exception:
            out[field] = 0.0
    return out


def _label(row: dict[str, Any]) -> int | None:
    for key in ("label", "correct", "is_match", "matched", "positive"):
        if key not in row:
            continue
        value = row.get(key)
        if isinstance(value, str):
            clean = value.strip().lower()
            if clean in {"1", "true", "yes", "match", "matched", "positive", "hit"}:
                return 1
            if clean in {"0", "false", "no", "no_match", "negative", "miss"}:
                return 0
        return 1 if value else 0
    return None


def _dot(coeffs: dict[str, float], feats: dict[str, float]) -> float:
    return sum(coeffs[field] * feats.get(field, 0.0) for field in SIGNAL_FIELDS)


def _build_pairs(rows: list[dict[str, Any]]) -> list[tuple[dict[str, float], dict[str, float]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        key = str(row.get("query") or row.get("target") or "__all__")
        groups[key].append(row)

    pairs: list[tuple[dict[str, float], dict[str, float]]] = []
    for members in groups.values():
        positives = [row for row in members if _label(row) == 1 and _features(row)]
        negatives = [row for row in members if _label(row) == 0 and _features(row)]
        for positive in positives:
            for negative in negatives:
                pairs.append((_features(positive), _features(negative)))
    return pairs


def train_pairwise(
    rows: list[dict[str, Any]],
    *,
    iterations: int = 1500,
    learning_rate: float = 0.2,
    l2: float = 0.01,
    seed: int = 13,
) -> tuple[dict[str, float], str, int]:
    pairs = _build_pairs(rows)
    if not pairs:
        return dict(DEFAULT_WEIGHTS), "insufficient_pairs_defaults", 0

    coeffs = {field: 0.0 for field in SIGNAL_FIELDS}
    random.Random(seed).shuffle(pairs)
    n = float(len(pairs))
    for _ in range(max(1, iterations)):
        grad = {field: 0.0 for field in SIGNAL_FIELDS}
        for positive, negative in pairs:
            diff = {
                field: positive.get(field, 0.0) - negative.get(field, 0.0)
                for field in SIGNAL_FIELDS
            }
            err = _sigmoid(_dot(coeffs, diff)) - 1.0
            for field in SIGNAL_FIELDS:
                grad[field] += err * diff[field]
        for field in SIGNAL_FIELDS:
            coeffs[field] -= learning_rate * ((grad[field] / n) + l2 * coeffs[field])

    positive_coeffs = {field: max(0.0, coeffs[field]) for field in SIGNAL_FIELDS}
    total = sum(positive_coeffs.values())
    if total <= 0:
        return dict(DEFAULT_WEIGHTS), "degenerate_defaults", len(pairs)
    weights = {field: round(positive_coeffs[field] / total, 4) for field in SIGNAL_FIELDS}
    return weights, "pairwise_ranknet_normalized_positive_coefficients", len(pairs)


def pair_accuracy(weights: dict[str, float], rows: list[dict[str, Any]]) -> float | None:
    pairs = _build_pairs(rows)
    if not pairs:
        return None
    correct = sum(1 for positive, negative in pairs if _dot(weights, positive) > _dot(weights, negative))
    return round(correct / len(pairs), 4)


def _load_rows(path: str | Path) -> list[dict[str, Any]]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise ValueError("--rows must point to a JSON list")
    return [
        dict(row)
        for row in raw
        if isinstance(row, dict) and _label(row) is not None and _features(row)
    ]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Pairwise LTR over confidence signals")
    parser.add_argument("--rows", required=True, help="labeled signal rows JSON")
    parser.add_argument("--out", default="eval/calibration.json")
    parser.add_argument("--iterations", type=int, default=1500)
    parser.add_argument("--learning-rate", type=float, default=0.2)
    parser.add_argument("--l2", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=13)
    args = parser.parse_args(argv)

    try:
        rows = _load_rows(args.rows)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    if not rows:
        print("No labeled signal rows with usable features found.", file=sys.stderr)
        return 1

    weights, method, pair_count = train_pairwise(
        rows,
        iterations=args.iterations,
        learning_rate=args.learning_rate,
        l2=args.l2,
        seed=args.seed,
    )
    accuracy = pair_accuracy(weights, rows)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(
            {
                "weights": weights,
                "meta": {
                    "rows": len(rows),
                    "pairs": pair_count,
                    "pairwise_accuracy": accuracy,
                    "method": method,
                    "fields": list(SIGNAL_FIELDS),
                },
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"Trained on {len(rows)} rows / {pair_count} pairs (pairwise accuracy {accuracy}).")
    print(f"Weights: {weights}")
    print(f"Saved ranker weights -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
