param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$StartArgs
)

$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Refresh-Path {
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"
}

function Test-PythonCandidate {
    param(
        [string]$Command,
        [string[]]$Args = @()
    )
    try {
        $cmd = Get-Command $Command -ErrorAction Stop
        & $cmd.Source @Args -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)" *> $null
        if ($LASTEXITCODE -eq 0) {
            return @{
                Command = $cmd.Source
                Args = $Args
            }
        }
    } catch {
        return $null
    }
    return $null
}

function Find-Python {
    $candidates = @(
        @{ Command = "py"; Args = @("-3.12") },
        @{ Command = "py"; Args = @("-3.11") },
        @{ Command = "py"; Args = @("-3") },
        @{ Command = "python"; Args = @() },
        @{ Command = "python3"; Args = @() }
    )
    foreach ($candidate in $candidates) {
        $found = Test-PythonCandidate -Command $candidate.Command -Args $candidate.Args
        if ($found) {
            return $found
        }
    }
    return $null
}

function Install-PythonWithWinget {
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) {
        return $false
    }

    Write-Step "Python 3.11+ was not found. Installing Python 3.12 with winget"
    & $winget.Source install --id Python.Python.3.12 -e --source winget --scope user --accept-package-agreements --accept-source-agreements --silent
    if ($LASTEXITCODE -ne 0) {
        Write-Step "User-scope install did not finish. Trying default winget install"
        & $winget.Source install --id Python.Python.3.12 -e --source winget --accept-package-agreements --accept-source-agreements --silent
    }
    if ($LASTEXITCODE -ne 0) {
        Write-Step "Silent winget install did not finish. Trying interactive winget install"
        & $winget.Source install --id Python.Python.3.12 -e --source winget --accept-package-agreements --accept-source-agreements
    }
    Refresh-Path
    return $true
}

try {
    Write-Step "Starting BEDNIIOSINT one-click launcher"
    $python = Find-Python
    if (-not $python) {
        $installed = Install-PythonWithWinget
        if ($installed) {
            $python = Find-Python
        }
    }

    if (-not $python) {
        Write-Host ""
        Write-Host "Python 3.11+ and winget were not found on this Windows system." -ForegroundColor Yellow
        Write-Host "The Python download page will open now. Install Python, then run start.bat again." -ForegroundColor Yellow
        Start-Process "https://www.python.org/downloads/windows/"
        exit 1
    }

    $pythonCommand = [string]$python["Command"]
    $pythonArgs = [string[]]$python["Args"]
    $display = "$pythonCommand $($pythonArgs -join ' ')".Trim()
    Write-Step "Using $display"
    & $pythonCommand @pythonArgs "scripts\start.py" @StartArgs
    exit $LASTEXITCODE
} catch {
    Write-Host ""
    Write-Host "BEDNIIOSINT startup failed:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
